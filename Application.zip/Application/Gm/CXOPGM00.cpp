//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39D9EAEC0363.cm preserve=no
//	$Date:   Nov 10 2021 23:41:34  $ $Author:   e5643436  $
//	$Revision:   1.49.2.5  $
//## end module%39D9EAEC0363.cm

//## begin module%39D9EAEC0363.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39D9EAEC0363.cp

//## Module: CXOPGM00%39D9EAEC0363; Package body
//## Subsystem: GM%39D9EAA1031F
//## Source file: C:\Devel\Dn\Server\Application\Gm\CXOPGM00.cpp

//## begin module%39D9EAEC0363.additionalIncludes preserve=no
//## end module%39D9EAEC0363.additionalIncludes

//## begin module%39D9EAEC0363.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),ENVAR('TASK=GM'))
#endif
#include "CXODDB16.hpp"
#include "CXODBC27.hpp"
#include "CXODSX44.hpp"
#ifndef CXOSSX35_h
#include "CXODSX35.hpp"
#endif
#ifndef CXOPTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOPIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOPTM01_h
#include "CXODTM01.hpp"
#endif
#include "CXODJX12.hpp"
//## end module%39D9EAEC0363.includes

#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSSX49_h
#include "CXODSX49.hpp"
#endif
#ifndef CXOSNC02_h
#include "CXODNC02.hpp"
#endif
#ifndef CXOSNC05_h
#include "CXODNC05.hpp"
#endif
#ifndef CXOSNC03_h
#include "CXODNC03.hpp"
#endif
#ifndef CXOSNC04_h
#include "CXODNC04.hpp"
#endif
#ifndef CXOSVC03_h
#include "CXODVC03.hpp"
#endif
#ifndef CXOSVC01_h
#include "CXODVC01.hpp"
#endif
#ifndef CXOSVC04_h
#include "CXODVC04.hpp"
#endif
#ifndef CXOSVC02_h
#include "CXODVC02.hpp"
#endif
#ifndef CXOSVC06_h
#include "CXODVC06.hpp"
#endif
#ifndef CXOSVC05_h
#include "CXODVC05.hpp"
#endif
#ifndef CXOSVC15_h
#include "CXODVC15.hpp"
#endif
#ifndef CXOSVC16_h
#include "CXODVC16.hpp"
#endif
#ifndef CXOSNC08_h
#include "CXODNC08.hpp"
#endif
#ifndef CXOSNC07_h
#include "CXODNC07.hpp"
#endif
#ifndef CXOSNC06_h
#include "CXODNC06.hpp"
#endif
#ifndef CXOSNC15_h
#include "CXODNC15.hpp"
#endif
#ifndef CXOSUC13_h
#include "CXODUC13.hpp"
#endif
#ifndef CXOSUC17_h
#include "CXODUC17.hpp"
#endif
#ifndef CXOSNC18_h
#include "CXODNC18.hpp"
#endif
#ifndef CXOSNC20_h
#include "CXODNC20.hpp"
#endif
#ifndef CXOSRC12_h
#include "CXODRC12.hpp"
#endif
#ifndef CXOSNC21_h
#include "CXODNC21.hpp"
#endif
#ifndef CXOSNC23_h
#include "CXODNC23.hpp"
#endif
#ifndef CXOSNC22_h
#include "CXODNC22.hpp"
#endif
#ifndef CXOSUC23_h
#include "CXODUC23.hpp"
#endif
#ifndef CXOSVC23_h
#include "CXODVC23.hpp"
#endif
#ifndef CXOSVC24_h
#include "CXODVC24.hpp"
#endif
#ifndef CXOSNC26_h
#include "CXODNC26.hpp"
#endif
#ifndef CXOSNC24_h
#include "CXODNC24.hpp"
#endif
#ifndef CXOSNC25_h
#include "CXODNC25.hpp"
#endif
#ifndef CXOSVC26_h
#include "CXODVC26.hpp"
#endif
#ifndef CXOSVC28_h
#include "CXODVC28.hpp"
#endif
#ifndef CXOSSX07_h
#include "CXODSX07.hpp"
#endif
#ifndef CXOSSX15_h
#include "CXODSX15.hpp"
#endif
#ifndef CXOSSX19_h
#include "CXODSX19.hpp"
#endif
#ifndef CXOSSX23_h
//#include "CXODSX23.hpp"
#endif
#ifndef CXOSRP08_h
//#include "CXODRP08.hpp"
#endif
#ifndef CXOSRP11_h
//#include "CXODRP11.hpp"
#endif
#ifndef CXOSEC25_h
#include "CXODEC25.hpp"
#endif
#ifndef CXOPGM00_h
#include "CXODGM00.hpp"
#endif


//## begin module%39D9EAEC0363.declarations preserve=no
//## end module%39D9EAEC0363.declarations

//## begin module%39D9EAEC0363.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new GenericMaintenance();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%39D9EAEC0363.additionalDeclarations


// Class GenericMaintenance 

GenericMaintenance::GenericMaintenance()
  //## begin GenericMaintenance::GenericMaintenance%39D9E8E60083_const.hasinit preserve=no
      : m_pContactCreateCommand(0),
        m_pContactDeleteCommand(0),
        m_pContactReadCommand(0),
        m_pContactUpdateCommand(0),
        m_pWorkQueueDeleteCommand(0),
        m_pWorkQueueCreateCommand(0),
        m_pWorkQueueListCommand(0),
        m_pWorkQueueUpdateCommand(0),
        m_pWorkQueueListUpdateCommand(0),
        m_pWorkQueueReadCommand(0),
        m_pWorkQueueConstraintListCommand(0),
        m_pWorkQueueUserListCommand(0),
        m_pCardAcceptorListCommand(0),
        m_pDeviceListCommand(0),
        m_pEntityListCommand(0),
        m_pReportingLevelListCommand(0),
        m_pGetConfigurationDataCommand(0),
        m_pMaintenanceCommand(0),
        m_pInstitutionBinListCommand(0),
        m_pInstitutionListCommand(0),
        m_pRepositoryStatusCommand(0),
        m_pContactListCommand(0),
        m_pProcessorListCommand(0),
        m_pMerchantListCommand(0),
        m_pCreateUserBatchCommand(0),
        m_pUserBatchListCommand(0),
        m_pUserBatchRetrieveCommand(0),
        m_pProcessorGroupListCommand(0),
        m_pUserLogonGetCommand(0),
        m_pUserLogonSetAssociationCommand(0),
        m_pDeleteUserBatchCommand(0),
        m_pClaimInitiationCommand(0),
        m_pKeyRetrieveCommand(0),
        m_pAuthenticateUserCommand(0),
        m_pOperatorCommand(0),
        m_pCaseAssignmentListCommand(0),
        m_pCaseLockCommand(0),
        m_pConfigurationListCommand(0)
  //## end GenericMaintenance::GenericMaintenance%39D9E8E60083_const.hasinit
  //## begin GenericMaintenance::GenericMaintenance%39D9E8E60083_const.initialization preserve=yes
        ,m_pInstitutionListCommand2(0)
  //## end GenericMaintenance::GenericMaintenance%39D9E8E60083_const.initialization
{
  //## begin GenericMaintenance::GenericMaintenance%39D9E8E60083_const.body preserve=yes
   memcpy(m_sID,"GM00",4);
  //## end GenericMaintenance::GenericMaintenance%39D9E8E60083_const.body
}


GenericMaintenance::~GenericMaintenance()
{
  //## begin GenericMaintenance::~GenericMaintenance%39D9E8E60083_dest.body preserve=yes
   delete m_pRepositoryStatusCommand;
   delete m_pInstitutionListCommand;
   delete m_pInstitutionBinListCommand;
   delete m_pEntityListCommand;
   delete m_pReportingLevelListCommand;
   delete m_pCardAcceptorListCommand;
   delete m_pDeviceListCommand;
   delete m_pWorkQueueConstraintListCommand;
   delete m_pWorkQueueUserListCommand;
   delete m_pWorkQueueReadCommand;
   delete m_pWorkQueueListUpdateCommand;
   delete m_pWorkQueueCreateCommand;
   delete m_pWorkQueueUpdateCommand;
   delete m_pWorkQueueDeleteCommand;
   delete m_pWorkQueueListCommand;
   delete m_pContactListCommand;
   delete m_pContactReadCommand;
   delete m_pContactCreateCommand;
   delete m_pContactUpdateCommand;
   delete m_pContactDeleteCommand;
   delete m_pGetConfigurationDataCommand;
   delete m_pMaintenanceCommand;
   delete m_pMerchantListCommand;
   delete m_pProcessorListCommand;
   delete m_pCreateUserBatchCommand;
   delete m_pUserBatchListCommand;
   delete m_pUserBatchRetrieveCommand;
   delete m_pProcessorGroupListCommand;
   delete m_pUserLogonGetCommand;
   delete m_pUserLogonSetAssociationCommand;
   delete m_pDeleteUserBatchCommand;
   delete m_pClaimInitiationCommand;
   delete m_pKeyRetrieveCommand;
   delete m_pAuthenticateUserCommand;
   delete m_pConfigurationListCommand;
   delete m_pCaseAssignmentListCommand;
   delete m_pInstitutionListCommand2;
   delete m_pCaseLockCommand;
  //## end GenericMaintenance::~GenericMaintenance%39D9E8E60083_dest.body
}



//## Other Operations (implementation)
int GenericMaintenance::initialize ()
{
  //## begin GenericMaintenance::initialize%39D9EA4102B3.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = ServiceApplication::initialize();
   UseCase hUseCase("CLIENT","## GM00 START GM");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   database::CRTransactionTypeIndicator::instance();
   m_pMaintenanceCommand = new MaintenanceCommand(0);
   m_pGetConfigurationDataCommand = new GetConfigurationDataCommand(m_pMaintenanceCommand);
   m_pContactDeleteCommand = new ContactDeleteCommand(m_pGetConfigurationDataCommand);
   m_pContactUpdateCommand = new ContactUpdateCommand(m_pContactDeleteCommand);
   m_pContactCreateCommand = new ContactCreateCommand(m_pContactUpdateCommand);
   m_pContactReadCommand = new ContactReadCommand(m_pContactCreateCommand);
   m_pContactListCommand = new ContactListCommand(m_pContactReadCommand);
   m_pWorkQueueListCommand = new WorkQueueListCommand(m_pContactListCommand);
   m_pWorkQueueDeleteCommand = new WorkQueueDeleteCommand(m_pWorkQueueListCommand);
   m_pWorkQueueUpdateCommand = new WorkQueueUpdateCommand(m_pWorkQueueDeleteCommand);
   m_pWorkQueueCreateCommand = new WorkQueueCreateCommand(m_pWorkQueueUpdateCommand);
   m_pWorkQueueListUpdateCommand = new WorkQueueListUpdateCommand(m_pWorkQueueCreateCommand);
   m_pWorkQueueReadCommand = new WorkQueueReadCommand(m_pWorkQueueListUpdateCommand);
   m_pWorkQueueUserListCommand = new WorkQueueUserListCommand(m_pWorkQueueReadCommand);
   m_pWorkQueueConstraintListCommand = new WorkQueueConstraintListCommand(m_pWorkQueueUserListCommand);
   m_pDeviceListCommand = new DeviceListCommand(m_pWorkQueueConstraintListCommand);
   m_pCardAcceptorListCommand = new CardAcceptorListCommand(m_pDeviceListCommand);
   m_pReportingLevelListCommand = new ReportingLevelListCommand(m_pCardAcceptorListCommand);
   m_pEntityListCommand = new EntityListCommand(m_pReportingLevelListCommand);
   m_pInstitutionBinListCommand = new InstitutionBinListCommand(m_pEntityListCommand);
   m_pInstitutionListCommand = new entitycommand::InstitutionListCommand(m_pInstitutionBinListCommand);
   m_pMerchantListCommand = new MerchantListCommand(m_pInstitutionListCommand);
   m_pProcessorListCommand = new ProcessorListCommand(m_pMerchantListCommand);
   m_pCreateUserBatchCommand = new CreateUserBatchCommand(m_pProcessorListCommand);
   m_pUserBatchListCommand = new UserBatchListCommand(m_pCreateUserBatchCommand);
   m_pUserBatchRetrieveCommand = new UserBatchRetrieveCommand(m_pUserBatchListCommand);
   m_pDeleteUserBatchCommand = new DeleteUserBatchCommand(m_pUserBatchRetrieveCommand);
   m_pRepositoryStatusCommand = new RepositoryStatusCommand(m_pDeleteUserBatchCommand);
   m_pProcessorGroupListCommand = new ProcessorGroupListCommand(m_pRepositoryStatusCommand);
   m_pUserLogonGetCommand = new UserLogonGetCommand(m_pProcessorGroupListCommand);
   m_pUserLogonSetAssociationCommand = new UserLogonSetAssociationCommand(m_pUserLogonGetCommand);
   m_pAuthenticateCommand = new restcommand::AuthenticateCommand(m_pUserLogonSetAssociationCommand);
   m_pKeyRetrieveCommand = new soapcommand::KeyRetrieveCommand(m_pAuthenticateCommand);
   m_pClaimInitiationCommand = new soapcommand::ClaimInitiationCommand(m_pKeyRetrieveCommand);
   m_pAuthenticateUserCommand = new soapcommand::AuthenticateUserCommand(m_pClaimInitiationCommand);
   m_pCaseAssignmentListCommand = new soapcommand::CaseAssignmentListCommand(m_pAuthenticateUserCommand);
   m_pInstitutionListCommand2 = new soapcommand::InstitutionListCommand(m_pCaseAssignmentListCommand);
   m_pCaseLockCommand = new emscommand::CaseLockCommand(m_pInstitutionListCommand2);
   m_pConfigurationListCommand = new soapcommand::ConfigurationListCommand(m_pCaseLockCommand);
   m_pHashUpdateCommand = new HashUpdateCommand();
#ifndef MVS
   Database::instance()->attach(new DNSecurity());
#endif
   Database::instance()->connect();
   Queue::attach("@##SERVER",Queue::CX_DISTRIBUTION_QUEUE);
   return 0;
  //## end GenericMaintenance::initialize%39D9EA4102B3.body
}

int GenericMaintenance::onMessage (Message& hMessage)
{
  //## begin GenericMaintenance::onMessage%39D9EA4102EF.body preserve=yes
   if (hMessage.messageID() != "S0003D"
      && hMessage.messageID() != "S0004D"
      && hMessage.messageID() != "S0005D")
      return 0;
   Transaction::instance()->begin();
   string strTimeStamp(Clock::instance()->getYYYYMMDDHHMMSS(true));
   Transaction::instance()->setTimeStamp(strTimeStamp += "00");
   m_pConfigurationListCommand->update(Message::instance(Message::INBOUND));
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      Database::instance()->rollback();
   else
      Database::instance()->commit();
   Transaction::instance()->commit();
   idle();
   return 0;
  //## end GenericMaintenance::onMessage%39D9EA4102EF.body
}

// Additional Declarations
  //## begin GenericMaintenance%39D9E8E60083.declarations preserve=yes
  //## end GenericMaintenance%39D9E8E60083.declarations

//## begin module%39D9EAEC0363.epilog preserve=yes
//## end module%39D9EAEC0363.epilog
