//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39D9EAC903DB.cm preserve=no
//	$Date:   Nov 10 2021 23:37:40  $ $Author:   e5643436  $
//	$Revision:   1.35.2.5  $
//## end module%39D9EAC903DB.cm

//## begin module%39D9EAC903DB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39D9EAC903DB.cp

//## Module: CXOPGM00%39D9EAC903DB; Package specification
//## Subsystem: GM%39D9EAA1031F
//## Source file: C:\Devel\Dn\Server\Application\Gm\CXODGM00.hpp

#ifndef CXOPGM00_h
#define CXOPGM00_h 1

//## begin module%39D9EAC903DB.additionalIncludes preserve=no
//## end module%39D9EAC903DB.additionalIncludes

//## begin module%39D9EAC903DB.includes preserve=yes
// $Date:   Nov 10 2021 23:37:40  $ $Author:   e5643436  $ $Revision:   1.35.2.5  $
//## end module%39D9EAC903DB.includes

#ifndef CXOSPS03_h
#include "CXODPS03.hpp"
#endif

//## Modelname: DataNavigator Foundation::ViewCommand_CAT%394E26F50072
namespace viewcommand {
class WorkQueueReadCommand;
} // namespace viewcommand

//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
class CaseLockCommand;
} // namespace emscommand

//## Modelname: Transaction Research and Adjustments::RupayTransactionInterface_CAT%5787EBA80104
namespace rupaytransactioninterface {
class RupayPresentmentUpdateInterface;
class RupayPresentmentInterface;
} // namespace rupaytransactioninterface

//## Modelname: DataNavigator Foundation::EntityCommand_CAT%394E2706012A
namespace entitycommand {
class ProcessorGroupListCommand;
class UserLogonSetAssociationCommand;
class UserLogonGetCommand;
class ProcessorListCommand;
class MerchantListCommand;
class ContactListCommand;
class InstitutionListCommand;
class InstitutionBinListCommand;
class ReportingLevelListCommand;
class CardAcceptorListCommand;
class DeviceListCommand;
class EntityListCommand;
class ContactDeleteCommand;
class ContactUpdateCommand;
class ContactReadCommand;
class ContactCreateCommand;
} // namespace entitycommand

//## Modelname: DataNavigator Foundation::RepositoryCommand_CAT%394E267C0078
namespace repositorycommand {
class RepositoryStatusCommand;
} // namespace repositorycommand

namespace viewcommand {
class WorkQueueUpdateCommand;
} // namespace viewcommand

//## Modelname: DataNavigator Foundation::UserCommand_CAT%394E26E302E3
namespace usercommand {
class CreateUserBatchCommand;
} // namespace usercommand

namespace viewcommand {
class WorkQueueUserListCommand;
class WorkQueueConstraintListCommand;
class WorkQueueCreateCommand;
class WorkQueueDeleteCommand;
class WorkQueueListCommand;
class WorkQueueListUpdateCommand;
class DeleteUserBatchCommand;
class HashUpdateCommand;
class UserBatchRetrieveCommand;
class UserBatchListCommand;
} // namespace viewcommand

namespace usercommand {
class MaintenanceCommand;
class GetConfigurationDataCommand;
} // namespace usercommand

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: DataNavigator Foundation::SOAPCommand_CAT%4DC0633D0140
namespace soapcommand {
class OperatorCommand;
class AuthenticateUserCommand;
class KeyRetrieveCommand;
class ClaimInitiationCommand;
class ConfigurationListCommand;
class CaseAssignmentListCommand;
} // namespace soapcommand

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class MidnightAlarm;

} // namespace timer

//## begin module%39D9EAC903DB.declarations preserve=no
//## end module%39D9EAC903DB.declarations

//## begin module%39D9EAC903DB.additionalDeclarations preserve=yes
//## end module%39D9EAC903DB.additionalDeclarations


//## begin GenericMaintenance%39D9E8E60083.preface preserve=yes
//## end GenericMaintenance%39D9E8E60083.preface

//## Class: GenericMaintenance%39D9E8E60083
//	<body>
//	<title>CG
//	<h1>GM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The Generic Maintenance service retrieves and maintains
//	information in the DataNavigator Configuration
//	Repository.
//	This includes entity information (institutions,
//	merchants and devices) as well as end user defined
//	contact information and work queue definitions.
//	</p>
//	<img src=CXOCGM00.gif>
//	</body>
//	<body>
//	<title>OG
//	<h1>GM
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The Generic Maintenance service retrieves and maintains
//	information in the DataNavigator Configuration
//	Repository.
//	This includes entity information (institutions,
//	merchants and devices) as well as end user defined
//	contact information and work queue definitions.
//	</p>
//	<img src=CXOOGM00.gif>
//	</p>
//	<h2>TS
//	<h3>DataNavigator Client
//	<p>
//	<b>Issue:</b>  End user reporting problems with services
//	provided by Generic Maintenance.
//	<p>
//	<b>Resolution:</b>  Refer to the Troubleshooting tips
//	for the Client Interface in the <i>DataNavigator Server
//	Operations Guide: Foundation</i> manual.
//	</p>
//	</body>
//## Category: DataNavigator Foundation::Application::GenericMaintenance_CAT%39D9E8810042
//## Subsystem: GM%39D9EAA1031F
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..1



//## Uses: <unnamed>%39D9EA4F0209;reusable::Transaction { -> F}
//## Uses: <unnamed>%39D9EA57005C;IF::Message { -> F}
//## Uses: <unnamed>%39D9EA640263;database::Database { -> F}
//## Uses: <unnamed>%39EB44BD022D;IF::Queue { -> F}
//## Uses: <unnamed>%3A26A3DF005C;timer::Clock { -> F}
//## Uses: <unnamed>%3A3A47B203E4;monitor::UseCase { -> F}
//## Uses: <unnamed>%40AA500F009C;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%5BA944F301A4;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%618BD70D01BA;soapcommand::ConfigurationListCommand { -> F}

class GenericMaintenance : public process::ServiceApplication  //## Inherits: <unnamed>%3BCED73D01F4
{
  //## begin GenericMaintenance%39D9E8E60083.initialDeclarations preserve=yes
  //## end GenericMaintenance%39D9E8E60083.initialDeclarations

  public:
    //## Constructors (generated)
      GenericMaintenance();

    //## Destructor (generated)
      virtual ~GenericMaintenance();


    //## Other Operations (specified)
      //## Operation: initialize%39D9EA4102B3
      virtual int initialize ();

    // Additional Public Declarations
      //## begin GenericMaintenance%39D9E8E60083.public preserve=yes
      //## end GenericMaintenance%39D9E8E60083.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%39D9EA4102EF
      virtual int onMessage (Message& hMessage);

    // Additional Protected Declarations
      //## begin GenericMaintenance%39D9E8E60083.protected preserve=yes
      //## end GenericMaintenance%39D9E8E60083.protected

  private:
    // Additional Private Declarations
      //## begin GenericMaintenance%39D9E8E60083.private preserve=yes
      //## end GenericMaintenance%39D9E8E60083.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A3E440144
      //## Role: GenericMaintenance::<m_pContactCreateCommand>%3A3A3E4501BD
      //## begin GenericMaintenance::<m_pContactCreateCommand>%3A3A3E4501BD.role preserve=no  public: entitycommand::ContactCreateCommand { -> RFHgN}
      entitycommand::ContactCreateCommand *m_pContactCreateCommand;
      //## end GenericMaintenance::<m_pContactCreateCommand>%3A3A3E4501BD.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A3E47029D
      //## Role: GenericMaintenance::<m_pContactDeleteCommand>%3A3A3E48023A
      //## begin GenericMaintenance::<m_pContactDeleteCommand>%3A3A3E48023A.role preserve=no  public: entitycommand::ContactDeleteCommand { -> RFHgN}
      entitycommand::ContactDeleteCommand *m_pContactDeleteCommand;
      //## end GenericMaintenance::<m_pContactDeleteCommand>%3A3A3E48023A.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A3E4A0215
      //## Role: GenericMaintenance::<m_pContactReadCommand>%3A3A3E4B0162
      //## begin GenericMaintenance::<m_pContactReadCommand>%3A3A3E4B0162.role preserve=no  public: entitycommand::ContactReadCommand { -> RFHgN}
      entitycommand::ContactReadCommand *m_pContactReadCommand;
      //## end GenericMaintenance::<m_pContactReadCommand>%3A3A3E4B0162.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A3E4D015B
      //## Role: GenericMaintenance::<m_pContactUpdateCommand>%3A3A3E4E00EE
      //## begin GenericMaintenance::<m_pContactUpdateCommand>%3A3A3E4E00EE.role preserve=no  public: entitycommand::ContactUpdateCommand { -> RFHgN}
      entitycommand::ContactUpdateCommand *m_pContactUpdateCommand;
      //## end GenericMaintenance::<m_pContactUpdateCommand>%3A3A3E4E00EE.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A3FB60222
      //## Role: GenericMaintenance::<m_pWorkQueueDeleteCommand>%3A3A3FB7030A
      //## begin GenericMaintenance::<m_pWorkQueueDeleteCommand>%3A3A3FB7030A.role preserve=no  public: viewcommand::WorkQueueDeleteCommand { -> RFHgN}
      viewcommand::WorkQueueDeleteCommand *m_pWorkQueueDeleteCommand;
      //## end GenericMaintenance::<m_pWorkQueueDeleteCommand>%3A3A3FB7030A.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A3FB902DB
      //## Role: GenericMaintenance::<m_pWorkQueueCreateCommand>%3A3A3FBA02F0
      //## begin GenericMaintenance::<m_pWorkQueueCreateCommand>%3A3A3FBA02F0.role preserve=no  public: viewcommand::WorkQueueCreateCommand { -> RFHgN}
      viewcommand::WorkQueueCreateCommand *m_pWorkQueueCreateCommand;
      //## end GenericMaintenance::<m_pWorkQueueCreateCommand>%3A3A3FBA02F0.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A3FBC01BD
      //## Role: GenericMaintenance::<m_pWorkQueueListCommand>%3A3A3FBD01E6
      //## begin GenericMaintenance::<m_pWorkQueueListCommand>%3A3A3FBD01E6.role preserve=no  public: viewcommand::WorkQueueListCommand { -> RFHgN}
      viewcommand::WorkQueueListCommand *m_pWorkQueueListCommand;
      //## end GenericMaintenance::<m_pWorkQueueListCommand>%3A3A3FBD01E6.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A3FBF027F
      //## Role: GenericMaintenance::<m_pWorkQueueUpdateCommand>%3A3A3FC00349
      //## begin GenericMaintenance::<m_pWorkQueueUpdateCommand>%3A3A3FC00349.role preserve=no  public: viewcommand::WorkQueueUpdateCommand { -> RFHgN}
      viewcommand::WorkQueueUpdateCommand *m_pWorkQueueUpdateCommand;
      //## end GenericMaintenance::<m_pWorkQueueUpdateCommand>%3A3A3FC00349.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A3FC30068
      //## Role: GenericMaintenance::<m_pWorkQueueListUpdateCommand>%3A3A3FC400C4
      //## begin GenericMaintenance::<m_pWorkQueueListUpdateCommand>%3A3A3FC400C4.role preserve=no  public: viewcommand::WorkQueueListUpdateCommand { -> RFHgN}
      viewcommand::WorkQueueListUpdateCommand *m_pWorkQueueListUpdateCommand;
      //## end GenericMaintenance::<m_pWorkQueueListUpdateCommand>%3A3A3FC400C4.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A3FC70259
      //## Role: GenericMaintenance::<m_pWorkQueueReadCommand>%3A3A3FC80296
      //## begin GenericMaintenance::<m_pWorkQueueReadCommand>%3A3A3FC80296.role preserve=no  public: viewcommand::WorkQueueReadCommand { -> RFHgN}
      viewcommand::WorkQueueReadCommand *m_pWorkQueueReadCommand;
      //## end GenericMaintenance::<m_pWorkQueueReadCommand>%3A3A3FC80296.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A476D03A9
      //## Role: GenericMaintenance::<m_pWorkQueueConstraintListCommand>%3A3A476E03DC
      //## begin GenericMaintenance::<m_pWorkQueueConstraintListCommand>%3A3A476E03DC.role preserve=no  public: viewcommand::WorkQueueConstraintListCommand { -> RFHgN}
      viewcommand::WorkQueueConstraintListCommand *m_pWorkQueueConstraintListCommand;
      //## end GenericMaintenance::<m_pWorkQueueConstraintListCommand>%3A3A476E03DC.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A477101F6
      //## Role: GenericMaintenance::<m_pWorkQueueUserListCommand>%3A3A477200FD
      //## begin GenericMaintenance::<m_pWorkQueueUserListCommand>%3A3A477200FD.role preserve=no  public: viewcommand::WorkQueueUserListCommand { -> RFHgN}
      viewcommand::WorkQueueUserListCommand *m_pWorkQueueUserListCommand;
      //## end GenericMaintenance::<m_pWorkQueueUserListCommand>%3A3A477200FD.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A9C700348
      //## Role: GenericMaintenance::<m_pCardAcceptorListCommand>%3A3A9C7102EF
      //## begin GenericMaintenance::<m_pCardAcceptorListCommand>%3A3A9C7102EF.role preserve=no  public: entitycommand::CardAcceptorListCommand { -> RFHgN}
      entitycommand::CardAcceptorListCommand *m_pCardAcceptorListCommand;
      //## end GenericMaintenance::<m_pCardAcceptorListCommand>%3A3A9C7102EF.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A9C7400E1
      //## Role: GenericMaintenance::<m_pDeviceListCommand>%3A3A9C7500A6
      //## begin GenericMaintenance::<m_pDeviceListCommand>%3A3A9C7500A6.role preserve=no  public: entitycommand::DeviceListCommand { -> RFHgN}
      entitycommand::DeviceListCommand *m_pDeviceListCommand;
      //## end GenericMaintenance::<m_pDeviceListCommand>%3A3A9C7500A6.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A9C770009
      //## Role: GenericMaintenance::<m_pEntityListCommand>%3A3A9C77032A
      //## begin GenericMaintenance::<m_pEntityListCommand>%3A3A9C77032A.role preserve=no  public: entitycommand::EntityListCommand { -> RFHgN}
      entitycommand::EntityListCommand *m_pEntityListCommand;
      //## end GenericMaintenance::<m_pEntityListCommand>%3A3A9C77032A.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3A3A9C790373
      //## Role: GenericMaintenance::<m_pReportingLevelListCommand>%3A3A9C7B0159
      //## begin GenericMaintenance::<m_pReportingLevelListCommand>%3A3A9C7B0159.role preserve=no  public: entitycommand::ReportingLevelListCommand { -> RFHgN}
      entitycommand::ReportingLevelListCommand *m_pReportingLevelListCommand;
      //## end GenericMaintenance::<m_pReportingLevelListCommand>%3A3A9C7B0159.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3B94E0D4002E
      //## Role: GenericMaintenance::<m_pGetConfigurationDataCommand>%3B94E0D5003E
      //## begin GenericMaintenance::<m_pGetConfigurationDataCommand>%3B94E0D5003E.role preserve=no  public: usercommand::GetConfigurationDataCommand { -> RFHgN}
      usercommand::GetConfigurationDataCommand *m_pGetConfigurationDataCommand;
      //## end GenericMaintenance::<m_pGetConfigurationDataCommand>%3B94E0D5003E.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3BCED92D00CB
      //## Role: GenericMaintenance::<m_pMaintenanceCommand>%3BCED92D03C8
      //## begin GenericMaintenance::<m_pMaintenanceCommand>%3BCED92D03C8.role preserve=no  public: usercommand::MaintenanceCommand { -> RFHgN}
      usercommand::MaintenanceCommand *m_pMaintenanceCommand;
      //## end GenericMaintenance::<m_pMaintenanceCommand>%3BCED92D03C8.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3CC977C00000
      //## Role: GenericMaintenance::<m_pInstitutionBinListCommand>%3CC977C0036B
      //## begin GenericMaintenance::<m_pInstitutionBinListCommand>%3CC977C0036B.role preserve=no  public: entitycommand::InstitutionBinListCommand { -> RFHgN}
      entitycommand::InstitutionBinListCommand *m_pInstitutionBinListCommand;
      //## end GenericMaintenance::<m_pInstitutionBinListCommand>%3CC977C0036B.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3E97F61000FA
      //## Role: GenericMaintenance::<m_pInstitutionListCommand>%3E97F610035B
      //## begin GenericMaintenance::<m_pInstitutionListCommand>%3E97F610035B.role preserve=no  public: entitycommand::InstitutionListCommand { -> RFHgN}
      entitycommand::InstitutionListCommand *m_pInstitutionListCommand;
      //## end GenericMaintenance::<m_pInstitutionListCommand>%3E97F610035B.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%3F58C6130213
      //## Role: GenericMaintenance::<m_pRepositoryStatusCommand>%3F58C6140138
      //## begin GenericMaintenance::<m_pRepositoryStatusCommand>%3F58C6140138.role preserve=no  public: repositorycommand::RepositoryStatusCommand { -> RFHgN}
      repositorycommand::RepositoryStatusCommand *m_pRepositoryStatusCommand;
      //## end GenericMaintenance::<m_pRepositoryStatusCommand>%3F58C6140138.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%40165F17038A
      //## Role: GenericMaintenance::<m_pContactListCommand>%40165F18036B
      //## begin GenericMaintenance::<m_pContactListCommand>%40165F18036B.role preserve=no  public: entitycommand::ContactListCommand { -> RFHgN}
      entitycommand::ContactListCommand *m_pContactListCommand;
      //## end GenericMaintenance::<m_pContactListCommand>%40165F18036B.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%42DFB7BD004E
      //## Role: GenericMaintenance::<m_pProcessorListCommand>%42DFB7BE009C
      //## begin GenericMaintenance::<m_pProcessorListCommand>%42DFB7BE009C.role preserve=no  public: entitycommand::ProcessorListCommand { -> RFHgN}
      entitycommand::ProcessorListCommand *m_pProcessorListCommand;
      //## end GenericMaintenance::<m_pProcessorListCommand>%42DFB7BE009C.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%42DFB7C5008C
      //## Role: GenericMaintenance::<m_pMerchantListCommand>%42DFB7C6001F
      //## begin GenericMaintenance::<m_pMerchantListCommand>%42DFB7C6001F.role preserve=no  public: entitycommand::MerchantListCommand { -> RFHgN}
      entitycommand::MerchantListCommand *m_pMerchantListCommand;
      //## end GenericMaintenance::<m_pMerchantListCommand>%42DFB7C6001F.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%498E099C0280
      //## Role: GenericMaintenance::<m_pCreateUserBatchCommand>%498E099D0280
      //## begin GenericMaintenance::<m_pCreateUserBatchCommand>%498E099D0280.role preserve=no  public: usercommand::CreateUserBatchCommand { -> RFHgN}
      usercommand::CreateUserBatchCommand *m_pCreateUserBatchCommand;
      //## end GenericMaintenance::<m_pCreateUserBatchCommand>%498E099D0280.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%49B1E3E30399
      //## Role: GenericMaintenance::<m_pUserBatchListCommand>%49B1E3E5005D
      //## begin GenericMaintenance::<m_pUserBatchListCommand>%49B1E3E5005D.role preserve=no  public: viewcommand::UserBatchListCommand { -> RFHgN}
      viewcommand::UserBatchListCommand *m_pUserBatchListCommand;
      //## end GenericMaintenance::<m_pUserBatchListCommand>%49B1E3E5005D.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%49C4D4DD02DE
      //## Role: GenericMaintenance::<m_pUserBatchRetrieveCommand>%49C4D4DF006D
      //## begin GenericMaintenance::<m_pUserBatchRetrieveCommand>%49C4D4DF006D.role preserve=no  public: viewcommand::UserBatchRetrieveCommand { -> RFHgN}
      viewcommand::UserBatchRetrieveCommand *m_pUserBatchRetrieveCommand;
      //## end GenericMaintenance::<m_pUserBatchRetrieveCommand>%49C4D4DF006D.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%4B66DEBD018D
      //## Role: GenericMaintenance::<m_pProcessorGroupListCommand>%4B66DEBE014F
      //## begin GenericMaintenance::<m_pProcessorGroupListCommand>%4B66DEBE014F.role preserve=no  public: entitycommand::ProcessorGroupListCommand { -> RFHgN}
      entitycommand::ProcessorGroupListCommand *m_pProcessorGroupListCommand;
      //## end GenericMaintenance::<m_pProcessorGroupListCommand>%4B66DEBE014F.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%4B66DECA014E
      //## Role: GenericMaintenance::<m_pUserLogonGetCommand>%4B66DECB0268
      //## begin GenericMaintenance::<m_pUserLogonGetCommand>%4B66DECB0268.role preserve=no  public: entitycommand::UserLogonGetCommand { -> RFHgN}
      entitycommand::UserLogonGetCommand *m_pUserLogonGetCommand;
      //## end GenericMaintenance::<m_pUserLogonGetCommand>%4B66DECB0268.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%4B66DED403DE
      //## Role: GenericMaintenance::<m_pUserLogonSetAssociationCommand>%4B66DED600D1
      //## begin GenericMaintenance::<m_pUserLogonSetAssociationCommand>%4B66DED600D1.role preserve=no  public: entitycommand::UserLogonSetAssociationCommand { -> RFHgN}
      entitycommand::UserLogonSetAssociationCommand *m_pUserLogonSetAssociationCommand;
      //## end GenericMaintenance::<m_pUserLogonSetAssociationCommand>%4B66DED600D1.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%5182C4F300BE
      //## Role: GenericMaintenance::<m_pHashUpdateCommand>%5182C4F40078
      //## begin GenericMaintenance::<m_pHashUpdateCommand>%5182C4F40078.role preserve=no  public: viewcommand::HashUpdateCommand { -> RFHgN}
      viewcommand::HashUpdateCommand *m_pHashUpdateCommand;
      //## end GenericMaintenance::<m_pHashUpdateCommand>%5182C4F40078.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%5278136A0341
      //## Role: GenericMaintenance::<m_pDeleteUserBatchCommand>%5278136C0142
      //## begin GenericMaintenance::<m_pDeleteUserBatchCommand>%5278136C0142.role preserve=no  public: viewcommand::DeleteUserBatchCommand { -> RFHgN}
      viewcommand::DeleteUserBatchCommand *m_pDeleteUserBatchCommand;
      //## end GenericMaintenance::<m_pDeleteUserBatchCommand>%5278136C0142.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%5419EE340367
      //## Role: GenericMaintenance::<m_pClaimInitiationCommand>%5419EE3503D4
      //## begin GenericMaintenance::<m_pClaimInitiationCommand>%5419EE3503D4.role preserve=no  public: soapcommand::ClaimInitiationCommand { -> RFHgN}
      soapcommand::ClaimInitiationCommand *m_pClaimInitiationCommand;
      //## end GenericMaintenance::<m_pClaimInitiationCommand>%5419EE3503D4.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%55561CD60041
      //## Role: GenericMaintenance::<m_pKeyRetrieveCommand>%55561CD7008E
      //## begin GenericMaintenance::<m_pKeyRetrieveCommand>%55561CD7008E.role preserve=no  public: soapcommand::KeyRetrieveCommand { -> RFHgN}
      soapcommand::KeyRetrieveCommand *m_pKeyRetrieveCommand;
      //## end GenericMaintenance::<m_pKeyRetrieveCommand>%55561CD7008E.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%57B321E1000A
      //## Role: GenericMaintenance::<m_pAuthenticateUserCommand>%57B321E2020C
      //## begin GenericMaintenance::<m_pAuthenticateUserCommand>%57B321E2020C.role preserve=no  public: soapcommand::AuthenticateUserCommand { -> RFHgN}
      soapcommand::AuthenticateUserCommand *m_pAuthenticateUserCommand;
      //## end GenericMaintenance::<m_pAuthenticateUserCommand>%57B321E2020C.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%58B5D247023D
      //## Role: GenericMaintenance::<m_pOperatorCommand>%58B5D2490093
      //## begin GenericMaintenance::<m_pOperatorCommand>%58B5D2490093.role preserve=no  public: soapcommand::OperatorCommand { -> RFHgN}
      soapcommand::OperatorCommand *m_pOperatorCommand;
      //## end GenericMaintenance::<m_pOperatorCommand>%58B5D2490093.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%5BBE2159023C
      //## Role: GenericMaintenance::<m_pCaseAssignmentListCommand>%5BBE216403DE
      //## begin GenericMaintenance::<m_pCaseAssignmentListCommand>%5BBE216403DE.role preserve=no  public: soapcommand::CaseAssignmentListCommand { -> RFHgN}
      soapcommand::CaseAssignmentListCommand *m_pCaseAssignmentListCommand;
      //## end GenericMaintenance::<m_pCaseAssignmentListCommand>%5BBE216403DE.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%613F927900C1
      //## Role: GenericMaintenance::<m_pCaseLockCommand>%613F92890310
      //## begin GenericMaintenance::<m_pCaseLockCommand>%613F92890310.role preserve=no  public: emscommand::CaseLockCommand { -> RFHgN}
      emscommand::CaseLockCommand *m_pCaseLockCommand;
      //## end GenericMaintenance::<m_pCaseLockCommand>%613F92890310.role

      //## Association: DataNavigator Foundation::Application::GenericMaintenance_CAT::<unnamed>%618BD7AB0107
      //## Role: GenericMaintenance::<m_pConfigurationListCommand>%618BD7BB00B5
      //## begin GenericMaintenance::<m_pConfigurationListCommand>%618BD7BB00B5.role preserve=no  public: soapcommand::ConfigurationListCommand { -> RFHgN}
      soapcommand::ConfigurationListCommand *m_pConfigurationListCommand;
      //## end GenericMaintenance::<m_pConfigurationListCommand>%618BD7BB00B5.role

    // Additional Implementation Declarations
      //## begin GenericMaintenance%39D9E8E60083.implementation preserve=yes
      soapcommand::InstitutionListCommand *m_pInstitutionListCommand2;
      restcommand::AuthenticateCommand *m_pAuthenticateCommand;
      //## end GenericMaintenance%39D9E8E60083.implementation
};

//## begin GenericMaintenance%39D9E8E60083.postscript preserve=yes
//## end GenericMaintenance%39D9E8E60083.postscript

//## begin module%39D9EAC903DB.epilog preserve=yes
//## end module%39D9EAC903DB.epilog


#endif
