//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%639B98BA0121.cm preserve=no
//## end module%639B98BA0121.cm

//## begin module%639B98BA0121.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%639B98BA0121.cp

//## Module: CXOPNX00%639B98BA0121; Package body
//## Subsystem: NX%639B9185038D
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Nx\CXOPNX00.cpp

//## begin module%639B98BA0121.additionalIncludes preserve=no
//## end module%639B98BA0121.additionalIncludes

//## begin module%639B98BA0121.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#include "CXODNS49.hpp"
//## end module%639B98BA0121.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSNR07_h
#include "CXODNR07.hpp"
#endif
#ifndef CXOSNR01_h
#include "CXODNR01.hpp"
#endif
#ifndef CXOSNR12_h
#include "CXODNR12.hpp"
#endif
#ifndef CXOSDB16_h
#include "CXODDB16.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSNS44_h
#include "CXODNS44.hpp"
#endif
#ifndef CXOSNS45_h
#include "CXODNS45.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOPNX00_h
#include "CXODNX00.hpp"
#endif


//## begin module%639B98BA0121.declarations preserve=no
//## end module%639B98BA0121.declarations

//## begin module%639B98BA0121.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new NetworkScrape();
   pApplication->parseCommandLine(argc, argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%639B98BA0121.additionalDeclarations


// Class NetworkScrape 

NetworkScrape::NetworkScrape()
  //## begin NetworkScrape::NetworkScrape%639B97AC024F_const.hasinit preserve=no
  //## end NetworkScrape::NetworkScrape%639B97AC024F_const.hasinit
  //## begin NetworkScrape::NetworkScrape%639B97AC024F_const.initialization preserve=yes
  //## end NetworkScrape::NetworkScrape%639B97AC024F_const.initialization
{
  //## begin NetworkScrape::NetworkScrape%639B97AC024F_const.body preserve=yes
   memcpy(m_sID,"NX00",4);
  //## end NetworkScrape::NetworkScrape%639B97AC024F_const.body
}


NetworkScrape::~NetworkScrape()
{
  //## begin NetworkScrape::~NetworkScrape%639B97AC024F_dest.body preserve=yes
  //## end NetworkScrape::~NetworkScrape%639B97AC024F_dest.body
}



//## Other Operations (implementation)
int NetworkScrape::initialize ()
{
  //## begin NetworkScrape::initialize%639B97AC0250.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("DR","## NX00 START NX");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   string strRecord;
   if (IF::Extract::instance()->getRecord("DFILES  NETFLE  ",strRecord))
      networkreconciliation::NetworkFile::instance();
   if (IF::Extract::instance()->getRecord("DFILES  NETRPT  ", strRecord))
      networkreconciliation::NetworkReport::instance();
   database::CRTransactionTypeIndicator::instance();
   entitysegment::Customer::instance();
   entitysegment::ProcessorGroup::instance();
   entitysegment::Processor::instance();
   entitysegment::Institution::instance();
   entitysegment::SwitchBusinessDay::instance();
   networkreconciliation::TotalType::instance();
   Database::instance()->connect();
   return iRC;
  //## end NetworkScrape::initialize%639B97AC0250.body
}

void NetworkScrape::update (reusable::Subject* pSubject)
{
  //## begin NetworkScrape::update%639B97AC0255.body preserve=yes
   Application::update(pSubject);
  //## end NetworkScrape::update%639B97AC0255.body
}

// Additional Declarations
  //## begin NetworkScrape%639B97AC024F.declarations preserve=yes
  //## end NetworkScrape%639B97AC024F.declarations

//## begin module%639B98BA0121.epilog preserve=yes
//## end module%639B98BA0121.epilog
