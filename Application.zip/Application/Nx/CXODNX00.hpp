//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%639B989F03CB.cm preserve=no
//## end module%639B989F03CB.cm

//## begin module%639B989F03CB.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%639B989F03CB.cp

//## Module: CXOPNX00%639B989F03CB; Package specification
//## Subsystem: NX%639B9185038D
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Nx\CXODNX00.hpp

#ifndef CXOPNX00_h
#define CXOPNX00_h 1

//## begin module%639B989F03CB.additionalIncludes preserve=no
//## end module%639B989F03CB.additionalIncludes

//## begin module%639B989F03CB.includes preserve=yes
//## end module%639B989F03CB.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
class Institution;
class Processor;
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class CRTransactionTypeIndicator;
} // namespace database

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;
} // namespace platform

//## Modelname: Reconciliation::NetworkReconciliation_CAT%5637978002B1
namespace networkreconciliation {
class NetworkFile;
class TotalType;
class NetworkReport;

} // namespace networkreconciliation

//## begin module%639B989F03CB.declarations preserve=no
//## end module%639B989F03CB.declarations

//## begin module%639B989F03CB.additionalDeclarations preserve=yes
//## end module%639B989F03CB.additionalDeclarations


//## begin NetworkScrape%639B97AC024F.preface preserve=yes
//## end NetworkScrape%639B97AC024F.preface

//## Class: NetworkScrape%639B97AC024F
//## Category: Reconciliation::NetworkScrape_CAT%639B908D00F3
//## Subsystem: NX%639B9185038D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%63A219AA01F4;monitor::UseCase { -> F}
//## Uses: <unnamed>%63A21A140195;database::Database { -> F}
//## Uses: <unnamed>%63A21CA1024E;IF::Extract { -> F}
//## Uses: <unnamed>%63A21D620296;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%63A21DAC0260;platform::Platform { -> F}
//## Uses: <unnamed>%63A21EF700B9;networkreconciliation::NetworkReport { -> F}
//## Uses: <unnamed>%642F237F013D;networkreconciliation::NetworkFile { -> F}
//## Uses: <unnamed>%642F23890087;networkreconciliation::TotalType { -> F}
//## Uses: <unnamed>%642F23E8016D;database::CRTransactionTypeIndicator { -> F}
//## Uses: <unnamed>%642F242802F5;entitysegment::Customer { -> F}
//## Uses: <unnamed>%642F242C00B5;entitysegment::Processor { -> F}
//## Uses: <unnamed>%642F242F02FD;entitysegment::Institution { -> F}
//## Uses: <unnamed>%642F24330205;entitysegment::SwitchBusinessDay { -> F}

class DllExport NetworkScrape : public process::Application  //## Inherits: <unnamed>%639B97AC0257
{
  //## begin NetworkScrape%639B97AC024F.initialDeclarations preserve=yes
  //## end NetworkScrape%639B97AC024F.initialDeclarations

  public:
    //## Constructors (generated)
      NetworkScrape();

    //## Destructor (generated)
      virtual ~NetworkScrape();


    //## Other Operations (specified)
      //## Operation: initialize%639B97AC0250
      int initialize ();

      //## Operation: update%639B97AC0255
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (reusable::Subject* pSubject);

    // Additional Public Declarations
      //## begin NetworkScrape%639B97AC024F.public preserve=yes
      //## end NetworkScrape%639B97AC024F.public

  protected:
    // Additional Protected Declarations
      //## begin NetworkScrape%639B97AC024F.protected preserve=yes
      //## end NetworkScrape%639B97AC024F.protected

  private:
    // Additional Private Declarations
      //## begin NetworkScrape%639B97AC024F.private preserve=yes
      //## end NetworkScrape%639B97AC024F.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin NetworkScrape%639B97AC024F.implementation preserve=yes
      //## end NetworkScrape%639B97AC024F.implementation

};

//## begin NetworkScrape%639B97AC024F.postscript preserve=yes
//## end NetworkScrape%639B97AC024F.postscript

//## begin module%639B989F03CB.epilog preserve=yes
//## end module%639B989F03CB.epilog


#endif
