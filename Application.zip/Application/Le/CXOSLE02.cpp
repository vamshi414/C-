//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%51DD568A01F9.cm preserve=no
//	$Date:   Dec 16 2020 11:25:30  $ $Author:   E5350313  $
//	$Revision:   1.7  $
//## end module%51DD568A01F9.cm

//## begin module%51DD568A01F9.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%51DD568A01F9.cp

//## Module: CXOSLE02%51DD568A01F9; Package body
//## Subsystem: LE%3597E9060357
//	.
//## Source file: C:\Dn_codes\V03.0A.R002\Dn\Server\Application\Le\CXOSLE02.cpp

//## begin module%51DD568A01F9.additionalIncludes preserve=no
//## end module%51DD568A01F9.additionalIncludes

//## begin module%51DD568A01F9.includes preserve=yes
#include "CXODBS14.hpp"
//## end module%51DD568A01F9.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSFC01_h
#include "CXODFC01.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSRS43_h
#include "CXODRS43.hpp"
#endif
#ifndef CXOSEX28_h
#include "CXODEX28.hpp"
#endif
#ifndef CXOSRS09_h
#include "CXODRS09.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSEC01_h
#include "CXODEC01.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSRSA7_h
#include "CXODRSA7.hpp"
#endif
#ifndef CXOSRC06_h
#include "CXODRC06.hpp"
#endif
#ifndef CXOSRC04_h
#include "CXODRC04.hpp"
#endif
#ifndef CXOSRC13_h
#include "CXODRC13.hpp"
#endif
#ifndef CXOSRC01_h
#include "CXODRC01.hpp"
#endif
#ifndef CXOSRC03_h
#include "CXODRC03.hpp"
#endif
#ifndef CXOSRC20_h
#include "CXODRC20.hpp"
#endif
#ifndef CXOSRC21_h
#include "CXODRC21.hpp"
#endif
#ifndef CXOSRC26_h
#include "CXODRC26.hpp"
#endif
#ifndef CXOSRC22_h
#include "CXODRC22.hpp"
#endif
#ifndef CXOSLE02_h
#include "CXODLE02.hpp"
#endif


//## begin module%51DD568A01F9.declarations preserve=no
//## end module%51DD568A01F9.declarations

//## begin module%51DD568A01F9.additionalDeclarations preserve=yes
//## end module%51DD568A01F9.additionalDeclarations


// Class Switch 

Switch::Switch()
  //## begin Switch::Switch%51DD563B02C8_const.hasinit preserve=no
      : m_pAddAdminCommand(0),
        m_pAddAuditMaintCommand(0),
        m_pAddCutoffCommand(0),
        m_pAddElectronicJournalCommand(0),
        m_pAddFinancialCommand(0),
        m_pAddStatusCommand(0),
        m_pAddExceptionCommand(0),
        m_pAddBulkDepositCommand(0),
        m_pAddAIMSBillingCommand(0),
        m_pAddLCMCommand(0)
  //## end Switch::Switch%51DD563B02C8_const.hasinit
  //## begin Switch::Switch%51DD563B02C8_const.initialization preserve=yes
  //## end Switch::Switch%51DD563B02C8_const.initialization
{
  //## begin Switch::Switch%51DD563B02C8_const.body preserve=yes
   memcpy(m_sID,"LE02",4);
   m_pAddAdminCommand = new AddAdminCommand();
   m_pAddAuditMaintCommand = new AddAuditMaintCommand();
   m_pAddBulkDepositCommand = new AddBulkDepositCommand();
   m_pAddCutoffCommand = new AddCutoffCommand();
   m_pAddElectronicJournalCommand = new AddElectronicJournalCommand();
   m_pAddExceptionCommand = new AddExceptionCommand();
   m_pAddFinancialCommand = (AddFinancialCommand*)DatabaseFactory::instance()->create("AddFinancialCommand");
   m_pAddStatusCommand = new AddStatusCommand();
   m_pAddLCMCommand = new AddLCMCommand();
   m_pAddAIMSBillingCommand = new AddAIMSBillingCommand();
  //## end Switch::Switch%51DD563B02C8_const.body
}


Switch::~Switch()
{
  //## begin Switch::~Switch%51DD563B02C8_dest.body preserve=yes
   delete m_pAddStatusCommand;
   delete m_pAddFinancialCommand;
   delete m_pAddExceptionCommand;
   delete m_pAddElectronicJournalCommand;
   delete m_pAddCutoffCommand;
   delete m_pAddBulkDepositCommand;
   delete m_pAddAuditMaintCommand;
   delete m_pAddAdminCommand;
   delete m_pAddLCMCommand;
   delete m_pAddAIMSBillingCommand;
  //## end Switch::~Switch%51DD563B02C8_dest.body
}



//## Other Operations (implementation)
bool Switch::onMessage (const Message& hMessage)
{
  //## begin Switch::onMessage%51DD565F034A.body preserve=yes
   bool b = true;
   if (!memcmp(hMessage.data() + 16,"S200",4))
   {
      UseCase hUseCase("DR","## DR05 LOAD FINANCIAL");
      m_pAddFinancialCommand->import(hMessage.data(),hMessage.dataLength());
      b = m_pAddFinancialCommand->execute();
      if (!memcmp(FinancialBaseSegment::instance()->zFIN_TYPE(),"800",3))
      {
         TransactionNotification hTransactionNotification;
         hTransactionNotification.execute();
      }
   }
   else
   if (!memcmp(hMessage.data() + 16,"S907",4))
   {
      UseCase hUseCase("DR","## DR06 LOAD STATUS");
      m_pAddStatusCommand->import(hMessage.data(),hMessage.dataLength());
      b = m_pAddStatusCommand->execute();
   }
   else
   if (!memcmp(hMessage.data() + 16,"E001",4))
   {
      UseCase hUseCase("DR","## DR98 LOAD EJ");
      m_pAddElectronicJournalCommand->import(hMessage.data(),hMessage.dataLength());
      b = m_pAddElectronicJournalCommand->execute();
   }
   else
   if (memcmp(hMessage.data() + 16,"L001",4) == 0
      && memcmp(hMessage.data() + 20 + sizeof(segListSegment),"S907",4) == 0) //added 4 for segment id
   {
      UseCase hUseCase("DR","## DR06 LOAD STATUS");
      m_pAddStatusCommand->import(hMessage.data(),hMessage.dataLength());
      char* psBuffer = (char*)*(m_pAddStatusCommand->getListSegment());
      UseCase::addItem(m_pAddStatusCommand->getListSegment()->itemCount());
      for (short j = 0;j < m_pAddStatusCommand->getListSegment()->itemCount();j++)
      {
         if (memcmp(psBuffer,"S907",4) == 0)
		 {
            psBuffer += 4; // skip over segment ID
			EntityStatusSegment::instance()->read(&psBuffer);
			b = m_pAddStatusCommand->execute();
		 }
		 else if (memcmp(psBuffer,"B001",4) == 0)
		 {
			 psBuffer += 4; // skip over segment ID
			 AIMSBillingSegment::instance()->read(&psBuffer);
			 b = m_pAddAIMSBillingCommand->execute();
		 }
         if (Transaction::instance()->getReturnCode() == Transaction::DATABASE_FAILURE)
            Database::instance()->setTransactionState(Database::COMMITREQUIRED);
      }
   }
   else
   if (!memcmp(hMessage.data() + 16,"F001",4))
   {
      UseCase hUseCase("DR","## DR07 LOAD FILE MAINT");
      m_pAddAuditMaintCommand->import(hMessage.data(),hMessage.dataLength());
      b = m_pAddAuditMaintCommand->execute();
	  if (AIMSBillingSegment::instance()->presence())
	     b = m_pAddAIMSBillingCommand->execute();
   }
   else
   if (memcmp(hMessage.data() + 16, "L001", 4) == 0
      && memcmp(hMessage.data() + 20 + sizeof(segListSegment), "F001", 4) == 0) //added 4 for segment id
   {
      UseCase hUseCase("DR", "## DR07 LOAD FILE MAINT");
      m_pAddAuditMaintCommand->import(hMessage.data(), hMessage.dataLength());
      char* psBuffer = (char*)*(m_pAddAuditMaintCommand->getListSegment());
      UseCase::addItem(m_pAddAuditMaintCommand->getListSegment()->itemCount());
      for (short j = 0; j < m_pAddAuditMaintCommand->getListSegment()->itemCount(); j++)
      {
         if (memcmp(psBuffer, "F001", 4) == 0)
         {
            psBuffer += 4; // skip over segment ID
            AuditMaintSegment::instance()->read(&psBuffer);
            b = m_pAddAuditMaintCommand->execute();
         }
         else if (memcmp(psBuffer, "B001", 4) == 0)
         {
            psBuffer += 4; // skip over segment ID
            AIMSBillingSegment::instance()->read(&psBuffer);
            b = m_pAddAIMSBillingCommand->execute();
         }
         if (Transaction::instance()->getReturnCode() == Transaction::DATABASE_FAILURE)
            Database::instance()->setTransactionState(Database::COMMITREQUIRED);
      }
   }
   else
   if (!memcmp(hMessage.data() + 16,"C001",4))
   {
      m_pAddCutoffCommand->import(hMessage.data(),hMessage.dataLength());
      b = m_pAddCutoffCommand->execute();
   }
   else
   if (memcmp(hMessage.data() + 16,"A001",4) == 0
      || (memcmp(hMessage.data() + 16,"L001",4) == 0
      && memcmp(hMessage.data() + 20 + sizeof(segListSegment),"A001",4) == 0))
   {
      m_pAddAdminCommand->import(hMessage.data(),hMessage.dataLength());
      b = m_pAddAdminCommand->execute();
      if (CutoffSegment::instance()->presence())
         m_pAddCutoffCommand->execute();
   }
   else
   if (memcmp(hMessage.data() + 16,"L001",4) == 0
      && memcmp(hMessage.data() + 20 + sizeof(segListSegment),"S318",4) == 0)
   {
      m_pAddBulkDepositCommand->import(hMessage.data(),hMessage.dataLength());
      b = m_pAddBulkDepositCommand->execute();
      if (Transaction::instance()->getReturnCode() == Transaction::DATABASE_FAILURE)
         Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   }
   else
   if (!memcmp(hMessage.data() + 16,"VEXP",4))
   {
      UseCase hUseCase("DR","## DR99 LOAD VNT",false,true);
      if (NationalException::instance()->getCaseCreateCommand() == 0)
         NationalException::instance()->setCaseCreateCommand(new CaseCreateCommand(0));
      b = NationalException::instance()->import(hMessage.data() + 20,(hMessage.dataLength() - 20),"VNT");
   }
   else
   if (!memcmp(hMessage.data() + 16,"S319",4))
   {
      m_pAddExceptionCommand->import(hMessage.data(),hMessage.dataLength());
      b = m_pAddExceptionCommand->execute();
      if (Transaction::instance()->getReturnCode() == Transaction::DATABASE_FAILURE)
         Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   }
   else
   if ((!memcmp(hMessage.data() + 16,"S600",4)) || (!memcmp(hMessage.data() + 16,"S450",4)))
   {
      m_pAddLCMCommand->import(hMessage.data(),hMessage.dataLength());
      b = m_pAddLCMCommand->execute();
      if (Transaction::instance()->getReturnCode() == Transaction::DATABASE_FAILURE)
         Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   }
   else
   if (memcmp(hMessage.data() + 16,"L001",4) == 0
	   && memcmp(hMessage.data() + 20 + sizeof(segListSegment),"B001",4) == 0)
   {
	   UseCase hUseCase("DR","## DR06 LOAD STATUS");
	   m_pAddAIMSBillingCommand->import(hMessage.data(), hMessage.dataLength());
	   char* psBuffer = (char*)*(m_pAddAIMSBillingCommand->getListSegment());
	   UseCase::addItem(m_pAddAIMSBillingCommand->getListSegment()->itemCount());
	   for (short j = 0; j < m_pAddAIMSBillingCommand->getListSegment()->itemCount(); j++)
	   {
		   psBuffer += 4; // skip over segment ID
		   AIMSBillingSegment::instance()->read(&psBuffer);
		   b = m_pAddAIMSBillingCommand->execute();
	   }
	   if (Transaction::instance()->getReturnCode() == Transaction::DATABASE_FAILURE)
		   Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   }
   else
   if (!memcmp(hMessage.data() + 16,"B001",4))
   {
	   m_pAddAIMSBillingCommand->import(hMessage.data(), hMessage.dataLength());
	   b = m_pAddAIMSBillingCommand->execute();
	   if (Transaction::instance()->getReturnCode() == Transaction::DATABASE_FAILURE)
		   Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   }
   if (Transaction::instance()->getReturnCode() == Transaction::DATABASE_FAILURE)
      Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   return b;
  //## end Switch::onMessage%51DD565F034A.body
}

// Additional Declarations
  //## begin Switch%51DD563B02C8.declarations preserve=yes
  //## end Switch%51DD563B02C8.declarations

//## begin module%51DD568A01F9.epilog preserve=yes
//## end module%51DD568A01F9.epilog
