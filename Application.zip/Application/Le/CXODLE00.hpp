//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36DEDD8100F7.cm preserve=no
//	$Date:   Dec 04 2014 16:11:24  $ $Author:   e1009839  $
//	$Revision:   1.48  $
//## end module%36DEDD8100F7.cm

//## begin module%36DEDD8100F7.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%36DEDD8100F7.cp

//## Module: CXOPLE00%36DEDD8100F7; Package specification
//## Subsystem: LE%3597E9060357
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\Dn\Server\Application\Le\CXODLE00.hpp

#ifndef CXOPLE00_h
#define CXOPLE00_h 1

//## begin module%36DEDD8100F7.additionalIncludes preserve=no
//## end module%36DEDD8100F7.additionalIncludes

//## begin module%36DEDD8100F7.includes preserve=yes
#include <set>
//## end module%36DEDD8100F7.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif
#ifndef CXOSPS03_h
#include "CXODPS03.hpp"
#endif

//## Modelname: DataNavigator Foundation::Partition_CAT%346B9162029B
namespace partition {
class PartitionControl;
} // namespace partition

//## Modelname: DataNavigator Foundation::RepositoryCommand_CAT%394E267C0078
namespace repositorycommand {
class AddFinancialCommand;
} // namespace repositorycommand

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class AuditSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::SwitchInterface_CAT%358EB6E20186
namespace switchinterface {
class Hash;
} // namespace switchinterface

class MAS;
class Switch;
class Model;
//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Sleep;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
class Interval;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class GMTClock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%36DEDD8100F7.declarations preserve=no
//## end module%36DEDD8100F7.declarations

//## begin module%36DEDD8100F7.additionalDeclarations preserve=yes
//## end module%36DEDD8100F7.additionalDeclarations


//## begin LoadEngine%34567B88036C.preface preserve=yes
//## end LoadEngine%34567B88036C.preface

//## Class: LoadEngine%34567B88036C
//	<body>
//	<title>CG
//	<h1>LE
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server imports financial, status,
//	administrative, ATM electronic journal and file
//	maintenance transactions from your switching platform.
//	Evidence of any issues detected during loading is saved
//	for correction by the Problem Transaction Manager.
//	<p>
//	The monthly tables populated during loading are
//	automatically created by the Locator Manager service.
//	</p>
//	<img src=CXOCLE00.gif>
//	<h2>FO
//	<h3>Data Repository Tables
//	<p>
//	The Load Engine services populate the following
//	transaction tables in the Data Repository:
//	<ul>
//	<li><i>custqual</i>.ATM_EJ_REC<i>yyyymm</i>
//	<li><i>custqual</i>.DEV_ADMIN_L<i>yyyymm</i>
//	<li><i>custqual</i>.DEV_ADMIN
//	<li><i>custqual</i>.FILE_MAINT_L<i>yyyymm</i>
//	<li><i>custqual</i>.FILE_MAINT
//	<li><i>custqual</i>.FIN_L<i>yyyymm</i>
//	<li><i>custqual</i>.FIN_RECORD<i>yyyymm</i>
//	<li><i>custqual</i>.PROBLEM_TRAN
//	<li><i>custqual</i>.STAT_REC_L<i>yyyymm</i>
//	<li><i>custqual</i>.STAT_REC
//	<li><i>custqual</i>.SUBJECT_STATE
//	<li><i>custqual</i>.T_ENTITY_CUTOFF
//	</ul>
//	</body>
//	<body>
//	<title>OG
//	<h1>LE
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server imports financial, status,
//	administrative and file maintenance transactions from
//	the acquiring platform EFT switch.
//	</p>
//	<img src=CXOOLE00.gif>
//	</body>
//## Category: DataNavigator Foundation::Application::LoadEngine_CAT%354B347F037A
//## Subsystem: LE%3597E9060357
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..n



//## Uses: <unnamed>%36DEDFF602C8;database::Database { -> F}
//## Uses: <unnamed>%36DEEA690329;IF::Extract { -> F}
//## Uses: <unnamed>%37FA12900322;IF::Sleep { -> F}
//## Uses: <unnamed>%39F44D42001F;monitor::UseCase { -> F}
//## Uses: <unnamed>%3A22965700DC;reusable::Transaction { -> F}
//## Uses: <unnamed>%40AA505E0177;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%40AA555001B5;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%482ADAA100DA;timer::GMTClock { -> F}
//## Uses: <unnamed>%51DD6A48005D;Switch { -> F}
//## Uses: <unnamed>%51DD6A53032E;MAS { -> F}
//## Uses: <unnamed>%5480D18601E4;switchinterface::Hash { -> F}

class LoadEngine : public process::ServiceApplication  //## Inherits: <unnamed>%3C554F21004E
{
  //## begin LoadEngine%34567B88036C.initialDeclarations preserve=yes
  //## end LoadEngine%34567B88036C.initialDeclarations

  public:
    //## Constructors (generated)
      LoadEngine();

    //## Destructor (generated)
      virtual ~LoadEngine();


    //## Other Operations (specified)
      //## Operation: initialize%36DEDE29035B
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>LE
      //	<h2>MS
      //	<h3>Scalability
      //	<p>
      //	The initial setup of the DataNavigator server installs
      //	three Load Engine services.
      //	The actual number can vary from 1 to as many as 99
      //	services.
      //	<p>
      //	An installation with a relatively low volume of
      //	transactions could be reduced to 1 or 2 services.
      //	An easy way to reduce the number is to defer the
      //	services that are not needed.
      //	This change can be reversed if volume increases over
      //	time.
      //	<p>
      //	An installation with high volume may benefit from
      //	additional loading services when the DataNavigator
      //	server fails to keep pace with the acquiring platform.
      //	At some point, contention issues within the database
      //	will limit the number of Load Engine services that can
      //	be configured.
      //	<p>
      //	The transaction loading process distributes work based
      //	on the number of active Load Engine services:
      //	<table>
      //	<tr>
      //	<th>Configuration
      //	<th>Distribution of work
      //	<tr>
      //	<td>1 Load Engine
      //	<td>All transactions are routed to the only Load Engine
      //	service.
      //	<tr>
      //	<td>2 Load Engines
      //	<td>Status, administrative and file maintenance
      //	transactions are routed to the first Load Engine service.
      //	Financial transactions are routed to the second Load
      //	Engine service.
      //	<tr>
      //	<td>Over 2 Load Engines
      //	<td>Status, administrative and file maintenance
      //	transactions are routed to the first Load Engine service.
      //	Financial transactions are balanced between remaining
      //	Load Engine services.
      //	</table>
      //	<p>
      //	Use the CR Client for the DataNavigator Server to defer
      //	existing Load Engine services or add new Load Engine
      //	services.
      //	</body>
      virtual int initialize ();

      //## Operation: onQuiesce%3C5ED851036B
      virtual int onQuiesce ();

      //## Operation: update%3C71344102BF
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin LoadEngine%34567B88036C.public preserve=yes
      //## end LoadEngine%34567B88036C.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%36DEDE560356
      virtual int onMessage (Message& hMessage);

    // Additional Protected Declarations
      //## begin LoadEngine%34567B88036C.protected preserve=yes
      //## end LoadEngine%34567B88036C.protected

  private:

    //## Other Operations (specified)
      //## Operation: allocateBuffers%36DEDE07012C
      void allocateBuffers (int lCount);

      //## Operation: commit%34F4651E028C
      //	Commit the current unit of work.
      //## Semantics:
      //	1. Call m_pDatabase->commit.
      //	2. m_lHashCount[0] += m_lHashCount[1].
      //	3. m_lHashCount[1] = 0.
      //	4. m_dHashTotal[0] += m_dHashTotal[1].
      //	5. m_dHashTotal[1] = 0.
      void commit ();

    // Additional Private Declarations
      //## begin LoadEngine%34567B88036C.private preserve=yes
      //## end LoadEngine%34567B88036C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DBRetry%4938012703DC
      //## begin LoadEngine::DBRetry%4938012703DC.attr preserve=no  private: string {U} 
      string m_strDBRetry;
      //## end LoadEngine::DBRetry%4938012703DC.attr

      //## Attribute: Insert%54807D5A0196
      //## begin LoadEngine::Insert%54807D5A0196.attr preserve=no  private: bool {V} false
      bool m_bInsert;
      //## end LoadEngine::Insert%54807D5A0196.attr

      //## Attribute: InactiveCount%54807DB000B9
      //## begin LoadEngine::InactiveCount%54807DB000B9.attr preserve=no  private: int {V} 3
      int m_iInactiveCount;
      //## end LoadEngine::InactiveCount%54807DB000B9.attr

      //## Attribute: QuiesceCount%49FA17AD0167
      //## begin LoadEngine::QuiesceCount%49FA17AD0167.attr preserve=no  private: int {V} 6
      int m_iQuiesceCount;
      //## end LoadEngine::QuiesceCount%49FA17AD0167.attr

      //## Attribute: TransactionHashCount%3C71356501E4
      //## begin LoadEngine::TransactionHashCount%3C71356501E4.attr preserve=no  private: int {V} 0
      int m_lTransactionHashCount;
      //## end LoadEngine::TransactionHashCount%3C71356501E4.attr

      //## Attribute: TransactionMaximum%36DEE08B02CC
      //## begin LoadEngine::TransactionMaximum%36DEE08B02CC.attr preserve=no  private: int {V} 200
      int m_lTransactionMaximum;
      //## end LoadEngine::TransactionMaximum%36DEE08B02CC.attr

      //## Attribute: TransactionMinimum%36DEE09C023B
      //## begin LoadEngine::TransactionMinimum%36DEE09C023B.attr preserve=no  private: int {V} 20
      int m_lTransactionMinimum;
      //## end LoadEngine::TransactionMinimum%36DEE09C023B.attr

      //## Attribute: TransactionSize%36DEE0B40163
      //## begin LoadEngine::TransactionSize%36DEE0B40163.attr preserve=no  private: int {V} 0
      int m_lTransactionSize;
      //## end LoadEngine::TransactionSize%36DEE0B40163.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%36DEE03200BC
      //## Role: LoadEngine::<m_pInterval>%36DEE032036F
      //## begin LoadEngine::<m_pInterval>%36DEE032036F.role preserve=no  public: monitor::Interval {1 -> 2RFHgN}
      monitor::Interval *m_pInterval[2];
      //## end LoadEngine::<m_pInterval>%36DEE032036F.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%36DEE0650340
      //## Role: LoadEngine::<m_hMessages>%36DEE066025B
      //## begin LoadEngine::<m_hMessages>%36DEE066025B.role preserve=no  public: IF::Message { -> 0..nVHgN}
      vector<IF::Message> m_hMessages;
      //## end LoadEngine::<m_hMessages>%36DEE066025B.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%36DEE0DB0281
      //## Role: LoadEngine::<m_pPartitionControl>%36DEE0DC0160
      //## begin LoadEngine::<m_pPartitionControl>%36DEE0DC0160.role preserve=no  public: partition::PartitionControl { -> RFHgN}
      partition::PartitionControl *m_pPartitionControl;
      //## end LoadEngine::<m_pPartitionControl>%36DEE0DC0160.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%3B1E9613017F
      //## Role: LoadEngine::<m_pAuditSegment>%3B1E96140112
      //## begin LoadEngine::<m_pAuditSegment>%3B1E96140112.role preserve=no  public: repositorysegment::AuditSegment { -> RFHgN}
      repositorysegment::AuditSegment *m_pAuditSegment;
      //## end LoadEngine::<m_pAuditSegment>%3B1E96140112.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%3C713479033C
      //## Role: LoadEngine::<m_hTimer>%3C71347A0242
      //## begin LoadEngine::<m_hTimer>%3C71347A0242.role preserve=no  public: timer::Timer { -> VHgN}
      timer::Timer m_hTimer;
      //## end LoadEngine::<m_hTimer>%3C71347A0242.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%51DD624000CD
      //## Role: LoadEngine::<m_pModel>%51DD624102D0
      //## begin LoadEngine::<m_pModel>%51DD624102D0.role preserve=no  public: Model { -> 2RFHgN}
      Model *m_pModel[2];
      //## end LoadEngine::<m_pModel>%51DD624102D0.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%5480ACFF03CA
      //## Role: LoadEngine::<m_pAddFinancialCommand>%5480AD01001F
      //## begin LoadEngine::<m_pAddFinancialCommand>%5480AD01001F.role preserve=no  public: repositorycommand::AddFinancialCommand { -> RFHgN}
      repositorycommand::AddFinancialCommand *m_pAddFinancialCommand;
      //## end LoadEngine::<m_pAddFinancialCommand>%5480AD01001F.role

    // Additional Implementation Declarations
      //## begin LoadEngine%34567B88036C.implementation preserve=yes
      map<string,pair<int,double>,less<string> > m_hBatches;
      set<string,less<string> > m_hRecovery;
      //## end LoadEngine%34567B88036C.implementation
};

//## begin LoadEngine%34567B88036C.postscript preserve=yes
//## end LoadEngine%34567B88036C.postscript

//## begin module%36DEDD8100F7.epilog preserve=yes
//## end module%36DEDD8100F7.epilog


#endif
