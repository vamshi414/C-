//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%51DD554A01AD.cm preserve=no
//	$Date:   Dec 04 2014 10:04:58  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%51DD554A01AD.cm

//## begin module%51DD554A01AD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%51DD554A01AD.cp

//## Module: CXOSLE01%51DD554A01AD; Package specification
//## Subsystem: LE%3597E9060357
//	.
//## Source file: C:\bV02.3B.R001\Windows\Build\Dn\Server\Application\Le\CXODLE01.hpp

#ifndef CXOSLE01_h
#define CXOSLE01_h 1

//## begin module%51DD554A01AD.additionalIncludes preserve=no
//## end module%51DD554A01AD.additionalIncludes

//## begin module%51DD554A01AD.includes preserve=yes
//## end module%51DD554A01AD.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;

} // namespace IF

//## begin module%51DD554A01AD.declarations preserve=no
//## end module%51DD554A01AD.declarations

//## begin module%51DD554A01AD.additionalDeclarations preserve=yes
//## end module%51DD554A01AD.additionalDeclarations


//## begin Model%51DD5498034E.preface preserve=yes
//## end Model%51DD5498034E.preface

//## Class: Model%51DD5498034E
//## Category: DataNavigator Foundation::Application::LoadEngine_CAT%354B347F037A
//## Subsystem: LE%3597E9060357
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%51DD561F02D4;IF::Message { -> F}

class DllExport Model : public reusable::Object  //## Inherits: <unnamed>%51DD54BC0122
{
  //## begin Model%51DD5498034E.initialDeclarations preserve=yes
  //## end Model%51DD5498034E.initialDeclarations

  public:
    //## Constructors (generated)
      Model();

    //## Destructor (generated)
      virtual ~Model();


    //## Other Operations (specified)
      //## Operation: onMessage%51DD54CA0272
      virtual bool onMessage (const IF::Message& hMessage) = 0;

    // Additional Public Declarations
      //## begin Model%51DD5498034E.public preserve=yes
      //## end Model%51DD5498034E.public

  protected:
    // Additional Protected Declarations
      //## begin Model%51DD5498034E.protected preserve=yes
      //## end Model%51DD5498034E.protected

  private:
    // Additional Private Declarations
      //## begin Model%51DD5498034E.private preserve=yes
      //## end Model%51DD5498034E.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin Model%51DD5498034E.implementation preserve=yes
      //## end Model%51DD5498034E.implementation

};

//## begin Model%51DD5498034E.postscript preserve=yes
//## end Model%51DD5498034E.postscript

//## begin module%51DD554A01AD.epilog preserve=yes
//## end module%51DD554A01AD.epilog


#endif
