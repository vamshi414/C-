//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%51DD568900CF.cm preserve=no
//	$Date:   Dec 17 2020 11:12:08  $ $Author:   e1032996  $
//	$Revision:   1.3  $
//## end module%51DD568900CF.cm

//## begin module%51DD568900CF.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%51DD568900CF.cp

//## Module: CXOSLE02%51DD568900CF; Package specification
//## Subsystem: LE%3597E9060357
//	.
//## Source file: C:\Dn_codes\V03.0A.R002\Dn\Server\Application\Le\CXODLE02.hpp

#ifndef CXOSLE02_h
#define CXOSLE02_h 1

//## begin module%51DD568900CF.additionalIncludes preserve=no
//## end module%51DD568900CF.additionalIncludes

//## begin module%51DD568900CF.includes preserve=yes
#include "CXODRS84.hpp"
//## end module%51DD568900CF.includes

#ifndef CXOSLE01_h
#include "CXODLE01.hpp"
#endif
#ifndef CXOSRC02_h
#include "CXODRC02.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class NationalException;
} // namespace ems

//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
class CaseCreateCommand;
} // namespace emscommand

//## Modelname: DataNavigator Foundation::RepositoryCommand_CAT%394E267C0078
namespace repositorycommand {
class AddCutoffCommand;
class AddFinancialCommand;
class AddAIMSBillingCommand;
class AddLCMCommand;
class AddBulkDepositCommand;
class AddExceptionCommand;
class AddElectronicJournalCommand;
class AddAdminCommand;
class AddStatusCommand;
} // namespace repositorycommand

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialBaseSegment;
class CutoffSegment;
class EntityStatusSegment;
class AIMSBillingSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::FraudCommand_CAT%3911A40B0089
namespace fraudcommand {
class TransactionNotification;
} // namespace fraudcommand

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ListSegment;

} // namespace segment

//## begin module%51DD568900CF.declarations preserve=no
//## end module%51DD568900CF.declarations

//## begin module%51DD568900CF.additionalDeclarations preserve=yes
//## end module%51DD568900CF.additionalDeclarations


//## begin Switch%51DD563B02C8.preface preserve=yes
//## end Switch%51DD563B02C8.preface

//## Class: Switch%51DD563B02C8
//## Category: DataNavigator Foundation::Application::LoadEngine_CAT%354B347F037A
//## Subsystem: LE%3597E9060357
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%51DD5672016A;IF::Message { -> F}
//## Uses: <unnamed>%51DD5F5F0301;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%51DD64710126;monitor::UseCase { -> F}
//## Uses: <unnamed>%51DD648B0133;fraudcommand::TransactionNotification { -> F}
//## Uses: <unnamed>%51DD64A8010B;repositorysegment::FinancialBaseSegment { -> F}
//## Uses: <unnamed>%51DD6A99035A;segment::ListSegment { -> F}
//## Uses: <unnamed>%51DD6AB70262;repositorysegment::EntityStatusSegment { -> F}
//## Uses: <unnamed>%51DD6AF50259;ems::NationalException { -> F}
//## Uses: <unnamed>%51DD6B65001E;repositorysegment::CutoffSegment { -> F}
//## Uses: <unnamed>%51DD6B8F01A8;reusable::Transaction { -> F}
//## Uses: <unnamed>%51DD6BB303B5;emscommand::CaseCreateCommand { -> F}
//## Uses: <unnamed>%51DD6BDF002B;database::Database { -> F}
//## Uses: <unnamed>%5C6A8A12022C;repositorysegment::AIMSBillingSegment { -> F}

class DllExport Switch : public Model  //## Inherits: <unnamed>%51DD565B0325
{
  //## begin Switch%51DD563B02C8.initialDeclarations preserve=yes
  //## end Switch%51DD563B02C8.initialDeclarations

  public:
    //## Constructors (generated)
      Switch();

    //## Destructor (generated)
      virtual ~Switch();


    //## Other Operations (specified)
      //## Operation: onMessage%51DD565F034A
      virtual bool onMessage (const Message& hMessage);

    // Additional Public Declarations
      //## begin Switch%51DD563B02C8.public preserve=yes
      //## end Switch%51DD563B02C8.public

  protected:
    // Additional Protected Declarations
      //## begin Switch%51DD563B02C8.protected preserve=yes
      //## end Switch%51DD563B02C8.protected

  private:
    // Additional Private Declarations
      //## begin Switch%51DD563B02C8.private preserve=yes
      //## end Switch%51DD563B02C8.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%51DD5A370328
      //## Role: Switch::<m_pAddAdminCommand>%51DD5A3801BD
      //## begin Switch::<m_pAddAdminCommand>%51DD5A3801BD.role preserve=no  public: repositorycommand::AddAdminCommand { -> RFHgN}
      repositorycommand::AddAdminCommand *m_pAddAdminCommand;
      //## end Switch::<m_pAddAdminCommand>%51DD5A3801BD.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%51DD5CCC0234
      //## Role: Switch::<m_pAddAuditMaintCommand>%51DD5CCD0194
      //## begin Switch::<m_pAddAuditMaintCommand>%51DD5CCD0194.role preserve=no  public: repositorycommand::AddAuditMaintCommand { -> RHgN}
      repositorycommand::AddAuditMaintCommand *m_pAddAuditMaintCommand;
      //## end Switch::<m_pAddAuditMaintCommand>%51DD5CCD0194.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%51DD5D500222
      //## Role: Switch::<m_pAddCutoffCommand>%51DD5D510250
      //## begin Switch::<m_pAddCutoffCommand>%51DD5D510250.role preserve=no  public: repositorycommand::AddCutoffCommand { -> RFHgN}
      repositorycommand::AddCutoffCommand *m_pAddCutoffCommand;
      //## end Switch::<m_pAddCutoffCommand>%51DD5D510250.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%51DD5DE003D7
      //## Role: Switch::<m_pAddElectronicJournalCommand>%51DD5DE1035C
      //## begin Switch::<m_pAddElectronicJournalCommand>%51DD5DE1035C.role preserve=no  public: repositorycommand::AddElectronicJournalCommand { -> RFHgN}
      repositorycommand::AddElectronicJournalCommand *m_pAddElectronicJournalCommand;
      //## end Switch::<m_pAddElectronicJournalCommand>%51DD5DE1035C.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%51DD5E3B02D2
      //## Role: Switch::<m_pAddFinancialCommand>%51DD5E3C021A
      //## begin Switch::<m_pAddFinancialCommand>%51DD5E3C021A.role preserve=no  public: repositorycommand::AddFinancialCommand { -> RFHgN}
      repositorycommand::AddFinancialCommand *m_pAddFinancialCommand;
      //## end Switch::<m_pAddFinancialCommand>%51DD5E3C021A.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%51DD5E9901AB
      //## Role: Switch::<m_pAddStatusCommand>%51DD5E9A0104
      //## begin Switch::<m_pAddStatusCommand>%51DD5E9A0104.role preserve=no  public: repositorycommand::AddStatusCommand { -> RFHgN}
      repositorycommand::AddStatusCommand *m_pAddStatusCommand;
      //## end Switch::<m_pAddStatusCommand>%51DD5E9A0104.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%54807FBB0091
      //## Role: Switch::<m_pAddExceptionCommand>%54807FBC01BA
      //## begin Switch::<m_pAddExceptionCommand>%54807FBC01BA.role preserve=no  public: repositorycommand::AddExceptionCommand { -> RFHgN}
      repositorycommand::AddExceptionCommand *m_pAddExceptionCommand;
      //## end Switch::<m_pAddExceptionCommand>%54807FBC01BA.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%54807FC40016
      //## Role: Switch::<m_pAddBulkDepositCommand>%54807FC500A2
      //## begin Switch::<m_pAddBulkDepositCommand>%54807FC500A2.role preserve=no  public: repositorycommand::AddBulkDepositCommand { -> RFHgN}
      repositorycommand::AddBulkDepositCommand *m_pAddBulkDepositCommand;
      //## end Switch::<m_pAddBulkDepositCommand>%54807FC500A2.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%5C6A87D702EC
      //## Role: Switch::<m_pAddAIMSBillingCommand>%5C6A87DB0256
      //## begin Switch::<m_pAddAIMSBillingCommand>%5C6A87DB0256.role preserve=no  public: repositorycommand::AddAIMSBillingCommand { -> RFHgN}
      repositorycommand::AddAIMSBillingCommand *m_pAddAIMSBillingCommand;
      //## end Switch::<m_pAddAIMSBillingCommand>%5C6A87DB0256.role

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%5C6A88670319
      //## Role: Switch::<m_pAddLCMCommand>%5C6A886A0270
      //## begin Switch::<m_pAddLCMCommand>%5C6A886A0270.role preserve=no  public: repositorycommand::AddLCMCommand { -> RFHgN}
      repositorycommand::AddLCMCommand *m_pAddLCMCommand;
      //## end Switch::<m_pAddLCMCommand>%5C6A886A0270.role

    // Additional Implementation Declarations
      //## begin Switch%51DD563B02C8.implementation preserve=yes
      //## end Switch%51DD563B02C8.implementation

};

//## begin Switch%51DD563B02C8.postscript preserve=yes
//## end Switch%51DD563B02C8.postscript

//## begin module%51DD568900CF.epilog preserve=yes
//## end module%51DD568900CF.epilog


#endif
