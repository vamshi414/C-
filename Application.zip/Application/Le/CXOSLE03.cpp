//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%51DD57850180.cm preserve=no
//	$Date:   Oct 11 2020 00:36:36  $ $Author:   e3028298  $
//	$Revision:   1.6  $
//## end module%51DD57850180.cm

//## begin module%51DD57850180.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%51DD57850180.cp

//## Module: CXOSLE03%51DD57850180; Package body
//## Subsystem: LE%3597E9060357
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Application\Le\CXOSLE03.cpp

//## begin module%51DD57850180.additionalIncludes preserve=no
//## end module%51DD57850180.additionalIncludes

//## begin module%51DD57850180.includes preserve=yes
//## end module%51DD57850180.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRC24_h
#include "CXODRC24.hpp"
#endif
#ifndef CXOSRC25_h
#include "CXODRC25.hpp"
#endif
#ifndef CXOSRC28_h
#include "CXODRC28.hpp"
#endif
#ifndef CXOSLE03_h
#include "CXODLE03.hpp"
#endif


//## begin module%51DD57850180.declarations preserve=no
//## end module%51DD57850180.declarations

//## begin module%51DD57850180.additionalDeclarations preserve=yes
//## end module%51DD57850180.additionalDeclarations


// Class MAS 

MAS::MAS()
  //## begin MAS::MAS%51DD5716025B_const.hasinit preserve=no
      : m_pAddTransactionCommand(0)
  //## end MAS::MAS%51DD5716025B_const.hasinit
  //## begin MAS::MAS%51DD5716025B_const.initialization preserve=yes
  //## end MAS::MAS%51DD5716025B_const.initialization
{
  //## begin MAS::MAS%51DD5716025B_const.body preserve=yes
   memcpy(m_sID,"LE03",4);
   if (Extract::instance()->getCustomCode() == "MPS")
      m_pAddTransactionCommand = new repositorycommand::MPSAddTransactionCommand;
   else
   if (Extract::instance()->getCustomCode() == "NPCI")
      m_pAddTransactionCommand = new repositorycommand::NPCIAddTransactionCommand;
   else
   if (Extract::instance()->getCustomCode() == "EGBL")
      m_pAddTransactionCommand = new repositorycommand::EglobalAddTransactionCommand;
   else
      m_pAddTransactionCommand = new repositorycommand::AddTransactionCommand;
  //## end MAS::MAS%51DD5716025B_const.body
}


MAS::~MAS()
{
  //## begin MAS::~MAS%51DD5716025B_dest.body preserve=yes
   delete m_pAddTransactionCommand;
  //## end MAS::~MAS%51DD5716025B_dest.body
}



//## Other Operations (implementation)
bool MAS::onMessage (const Message& hMessage)
{
  //## begin MAS::onMessage%51DD572C01C8.body preserve=yes
   bool b = true;
   if (!memcmp(hMessage.data() + 16,"L001",4))
   {
      UseCase hUseCase("DR","## DR05 LOAD FINANCIAL");
      m_pAddTransactionCommand->import(hMessage.data(),hMessage.dataLength());
      b = m_pAddTransactionCommand->execute();
   }
   if (reusable::Transaction::instance()->getReturnCode() == reusable::Transaction::DATABASE_FAILURE)
      Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   return b;
  //## end MAS::onMessage%51DD572C01C8.body
}

// Additional Declarations
  //## begin MAS%51DD5716025B.declarations preserve=yes
  //## end MAS%51DD5716025B.declarations

//## begin module%51DD57850180.epilog preserve=yes
//## end module%51DD57850180.epilog
