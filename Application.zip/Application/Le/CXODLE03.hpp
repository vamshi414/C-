//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%51DD578400D8.cm preserve=no
//	$Date:   Oct 11 2020 00:33:12  $ $Author:   e3028298  $
//	$Revision:   1.2  $
//## end module%51DD578400D8.cm

//## begin module%51DD578400D8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%51DD578400D8.cp

//## Module: CXOSLE03%51DD578400D8; Package specification
//## Subsystem: LE%3597E9060357
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Application\Le\CXODLE03.hpp

#ifndef CXOSLE03_h
#define CXOSLE03_h 1

//## begin module%51DD578400D8.additionalIncludes preserve=no
//## end module%51DD578400D8.additionalIncludes

//## begin module%51DD578400D8.includes preserve=yes
//## end module%51DD578400D8.includes

#ifndef CXOSRC19_h
#include "CXODRC19.hpp"
#endif
#ifndef CXOSLE01_h
#include "CXODLE01.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositoryCommand_CAT%394E267C0078
namespace repositorycommand {
class NPCIAddTransactionCommand;
} // namespace repositorycommand

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

namespace repositorycommand {
class MPSAddTransactionCommand;

} // namespace repositorycommand

namespace repositorycommand {
class EglobalAddTransactionCommand;
} // namespace repositorycommand
//## begin module%51DD578400D8.declarations preserve=no
//## end module%51DD578400D8.declarations

//## begin module%51DD578400D8.additionalDeclarations preserve=yes
//## end module%51DD578400D8.additionalDeclarations


//## begin MAS%51DD5716025B.preface preserve=yes
//## end MAS%51DD5716025B.preface

//## Class: MAS%51DD5716025B
//## Category: DataNavigator Foundation::Application::LoadEngine_CAT%354B347F037A
//## Subsystem: LE%3597E9060357
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%51DD57440103;IF::Message { -> F}
//## Uses: <unnamed>%51DDA1E00377;monitor::UseCase { -> F}
//## Uses: <unnamed>%51DDA1E4034C;reusable::Transaction { -> F}
//## Uses: <unnamed>%51DDA1E801A6;database::Database { -> F}
//## Uses: <unnamed>%59EDE84103AC;IF::Extract { -> F}
//## Uses: <unnamed>%59EDE92F006D;repositorycommand::NPCIAddTransactionCommand { -> F}
//## Uses: <unnamed>%59F8642C03DB;repositorycommand::MPSAddTransactionCommand { -> F}

class DllExport MAS : public Model  //## Inherits: <unnamed>%51DD57260159
{
  //## begin MAS%51DD5716025B.initialDeclarations preserve=yes
  //## end MAS%51DD5716025B.initialDeclarations

  public:
    //## Constructors (generated)
      MAS();

    //## Destructor (generated)
      virtual ~MAS();


    //## Other Operations (specified)
      //## Operation: onMessage%51DD572C01C8
      virtual bool onMessage (const Message& hMessage);

    // Additional Public Declarations
      //## begin MAS%51DD5716025B.public preserve=yes
      //## end MAS%51DD5716025B.public

  protected:
    // Additional Protected Declarations
      //## begin MAS%51DD5716025B.protected preserve=yes
      //## end MAS%51DD5716025B.protected

  private:
    // Additional Private Declarations
      //## begin MAS%51DD5716025B.private preserve=yes
      //## end MAS%51DD5716025B.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LoadEngine_CAT::<unnamed>%51DDA017023F
      //## Role: MAS::<m_pAddTransactionCommand>%51DDA01800F6
      //## begin MAS::<m_pAddTransactionCommand>%51DDA01800F6.role preserve=no  public: repositorycommand::AddTransactionCommand { -> RHgN}
      repositorycommand::AddTransactionCommand *m_pAddTransactionCommand;
      //## end MAS::<m_pAddTransactionCommand>%51DDA01800F6.role

    // Additional Implementation Declarations
      //## begin MAS%51DD5716025B.implementation preserve=yes
      //## end MAS%51DD5716025B.implementation

};

//## begin MAS%51DD5716025B.postscript preserve=yes
//## end MAS%51DD5716025B.postscript

//## begin module%51DD578400D8.epilog preserve=yes
//## end module%51DD578400D8.epilog


#endif
