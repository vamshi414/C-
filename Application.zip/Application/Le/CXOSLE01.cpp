//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%51DD554C011A.cm preserve=no
//	$Date:   Dec 04 2014 10:05:00  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%51DD554C011A.cm

//## begin module%51DD554C011A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%51DD554C011A.cp

//## Module: CXOSLE01%51DD554C011A; Package body
//## Subsystem: LE%3597E9060357
//	.
//## Source file: C:\bV02.3B.R001\Windows\Build\Dn\Server\Application\Le\CXOSLE01.cpp

//## begin module%51DD554C011A.additionalIncludes preserve=no
//## end module%51DD554C011A.additionalIncludes

//## begin module%51DD554C011A.includes preserve=yes
//## end module%51DD554C011A.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSLE01_h
#include "CXODLE01.hpp"
#endif


//## begin module%51DD554C011A.declarations preserve=no
//## end module%51DD554C011A.declarations

//## begin module%51DD554C011A.additionalDeclarations preserve=yes
//## end module%51DD554C011A.additionalDeclarations


// Class Model 

Model::Model()
  //## begin Model::Model%51DD5498034E_const.hasinit preserve=no
  //## end Model::Model%51DD5498034E_const.hasinit
  //## begin Model::Model%51DD5498034E_const.initialization preserve=yes
  //## end Model::Model%51DD5498034E_const.initialization
{
  //## begin Model::Model%51DD5498034E_const.body preserve=yes
  //## end Model::Model%51DD5498034E_const.body
}


Model::~Model()
{
  //## begin Model::~Model%51DD5498034E_dest.body preserve=yes
  //## end Model::~Model%51DD5498034E_dest.body
}


// Additional Declarations
  //## begin Model%51DD5498034E.declarations preserve=yes
  //## end Model%51DD5498034E.declarations

//## begin module%51DD554C011A.epilog preserve=yes
//## end module%51DD554C011A.epilog
