//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36DEDD82035B.cm preserve=no
//	$Date:   Sep 30 2021 04:57:56  $ $Author:   e3019097  $
//	$Revision:   1.103  $
//## end module%36DEDD82035B.cm

//## begin module%36DEDD82035B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%36DEDD82035B.cp

//## Module: CXOPLE00%36DEDD82035B; Package body
//## Subsystem: LE%3597E9060357
//	.
//## Source file: C:\bV02.5B.R001\Windows\Build\Dn\Server\Application\Le\CXOPLE00.cpp

//## begin module%36DEDD82035B.additionalIncludes preserve=no
//## end module%36DEDD82035B.additionalIncludes

//## begin module%36DEDD82035B.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#include "CXODDB50.hpp"
#include "CXODTM02.hpp"
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
//## end module%36DEDD82035B.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSTM11_h
#include "CXODTM11.hpp"
#endif
#ifndef CXOSLE02_h
#include "CXODLE02.hpp"
#endif
#ifndef CXOSLE03_h
#include "CXODLE03.hpp"
#endif
#ifndef CXOSSI05_h
#include "CXODSI05.hpp"
#endif
#ifndef CXOSMN03_h
#include "CXODMN03.hpp"
#endif
#ifndef CXOSPC01_h
#include "CXODPC01.hpp"
#endif
#ifndef CXOSRS10_h
#include "CXODRS10.hpp"
#endif
#ifndef CXOSLE01_h
#include "CXODLE01.hpp"
#endif
#ifndef CXOSRC01_h
#include "CXODRC01.hpp"
#endif
#ifndef CXOPLE00_h
#include "CXODLE00.hpp"
#endif


//## begin module%36DEDD82035B.declarations preserve=no
//## end module%36DEDD82035B.declarations

//## begin module%36DEDD82035B.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new LoadEngine();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%36DEDD82035B.additionalDeclarations


// Class LoadEngine 

LoadEngine::LoadEngine()
  //## begin LoadEngine::LoadEngine%34567B88036C_const.hasinit preserve=no
      : m_bInsert(false),
        m_iInactiveCount(3),
        m_iQuiesceCount(6),
        m_lTransactionHashCount(0),
        m_lTransactionMaximum(200),
        m_lTransactionMinimum(20),
        m_lTransactionSize(0),
        m_pPartitionControl(0),
        m_pAddFinancialCommand(0)
  //## end LoadEngine::LoadEngine%34567B88036C_const.hasinit
  //## begin LoadEngine::LoadEngine%34567B88036C_const.initialization preserve=yes
  //## end LoadEngine::LoadEngine%34567B88036C_const.initialization
{
  //## begin LoadEngine::LoadEngine%34567B88036C_const.body preserve=yes
   memcpy(m_sID,"LE00",4);
   m_pInterval[0] = 0;
   m_pInterval[1] = 0;
   m_bInsert = false;
   m_strDBRetry = "00001500";
  //## end LoadEngine::LoadEngine%34567B88036C_const.body
}


LoadEngine::~LoadEngine()
{
  //## begin LoadEngine::~LoadEngine%34567B88036C_dest.body preserve=yes
   delete m_pInterval[1];
   delete m_pInterval[0];
   m_hMessages.erase(m_hMessages.begin(),m_hMessages.end());
   delete m_pAddFinancialCommand;
   delete m_pPartitionControl;
   delete m_pModel[1];
   delete m_pModel[0];
   m_hBatches.erase(m_hBatches.begin(),m_hBatches.end());
   m_hRecovery.erase(m_hRecovery.begin(),m_hRecovery.end());
  //## end LoadEngine::~LoadEngine%34567B88036C_dest.body
}



//## Other Operations (implementation)
void LoadEngine::allocateBuffers (int lCount)
{
  //## begin LoadEngine::allocateBuffers%36DEDE07012C.body preserve=yes
   Message hMessage(4096);
   if (hMessage.buffer() != 0)
   {
      for (int i = 0;i < lCount;++i)
      {
         m_hMessages.push_back(hMessage);
         if (m_hMessages.back().buffer() == 0)
         {
            m_hMessages.pop_back();
            m_lTransactionMaximum = m_hMessages.size();
            break;
         }
      }
      m_lTransactionSize = m_hMessages.size();
   }
  //## end LoadEngine::allocateBuffers%36DEDE07012C.body
}

void LoadEngine::commit ()
{
  //## begin LoadEngine::commit%34F4651E028C.body preserve=yes
   UseCase hUseCase("DR","## DR51 LOAD COMMIT CHANGES");
   UseCase::addItem(m_lTransactionHashCount);
   if (Database::instance()->commit() != 0)
   {
      map<string,pair<int,double>,less<string> >::iterator pBatch;
      for (pBatch = m_hBatches.begin();pBatch != m_hBatches.end();++pBatch)
         (*pBatch).second.second = 0;
      UseCase::setSuccess(false);
   }
   if (Extract::instance()->getPerf() == "PERF")
   {
      char szTrace[256];
      Trace::put(szTrace, sprintf(szTrace, "Commit- TimeStamp[%s]", Clock::instance()->getYYYYMMDDHHMMSSHN(true).c_str()), true);
   }
   m_pInterval[1]->stop();
   // target 10 seconds elapsed time per COMMIT
   if (m_lTransactionHashCount == m_lTransactionSize)
   {
      m_lTransactionSize =
         (int)((double)(10000 / (double)m_pInterval[1]->getSample())
         * (double)m_lTransactionSize);
      if (m_lTransactionSize < m_lTransactionMinimum)
         m_lTransactionSize = m_lTransactionMinimum;
      else
      {
         if (m_lTransactionSize > m_lTransactionMaximum)
            m_lTransactionSize = m_lTransactionMaximum;
         if (m_lTransactionSize > m_hMessages.size())
            allocateBuffers(m_lTransactionSize - m_hMessages.size());
      }
   }
   m_lTransactionHashCount = 0;
   GMTClock::instance()->update(0);
   m_iInactiveCount = 0;
  //## end LoadEngine::commit%34F4651E028C.body
}

int LoadEngine::initialize ()
{
  //## begin LoadEngine::initialize%36DEDE29035B.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("DR","## DR04 START LE");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   string strClient("@##AI");
   strClient += Application::name()[4];
   setClient(strClient);
#ifndef MVS
   int i = 0;
   string strBuffer;
   bool bSkip = false;
   while (Extract::instance()->getRecord(i,strBuffer))
   {
      bSkip = strBuffer.length() > 31 && memcmp(strBuffer.data() + 24, "CXOP", 4) == 0;
      if (!bSkip && strBuffer.length() >= 16
         && strBuffer.substr(0,8) == "DQUEUE  "
         && strBuffer.substr(8,2) == "AI")
         addClient(strBuffer.substr(16,8));
      ++i;
   }
#endif
   string strDistributionQueue("@##LE");
   strDistributionQueue += Application::name()[4];
   setDistributionQueue(strDistributionQueue);
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->attach(this);
   database::DataModel::instance();
   Database::instance()->connect();
   m_pPartitionControl = new PartitionControl((PartitionAllocator*)DatabaseFactory::instance()->create("PartitionAllocator"));
   m_pAddFinancialCommand = (AddFinancialCommand*)DatabaseFactory::instance()->create("AddFinancialCommand");
   m_pModel[0] = new Switch;
   m_pModel[1] = new MAS;
   int lDBRetry = 0;
   Extract::instance()->getLong("DUSER   ","MIN=",&m_lTransactionMinimum);
   Extract::instance()->getLong("DUSER   ","MAX=",&m_lTransactionMaximum);
   Extract::instance()->getLong("DUSER   ","DBRETRY=",&lDBRetry);
   if (lDBRetry <= 60 && lDBRetry >= 10)
   {
      char szDBRetry[9];
      snprintf(szDBRetry,sizeof(szDBRetry),"%06d00",lDBRetry);
      m_strDBRetry.assign(szDBRetry,8);
   }
   allocateBuffers(m_lTransactionMinimum);
   if (m_hMessages.size() == 0)
      return -1;
   string strMember(image());
   strMember += name();
   m_pInterval[0] = new Interval("LE",strMember.c_str(),"AVETIME");
   m_pInterval[1] = new Interval("LE",strMember.c_str(),"AVECOMM");
   MinuteTimer::instance();
   m_hTimer.attach(this);
   m_hTimer.set("00001000");
   return 0;
  //## end LoadEngine::initialize%36DEDE29035B.body
}

int LoadEngine::onMessage (Message& hMessage)
{
  //## begin LoadEngine::onMessage%36DEDE560356.body preserve=yes
   if (hMessage.messageID() == "S0060D")
   {
      hHashMessage* pResponse = (hHashMessage*)hMessage.data();
      string strSourceID = string(pResponse->sSourceID,sizeof(pResponse->sSourceID));
      map<string,pair<int,double>,less<string> >::iterator pBatch;
      pBatch = m_hBatches.find(strSourceID);
      if (pBatch == m_hBatches.end())
      {
        pair<int,double> hPair(0,0);
        pair<map<string,pair<int,double>,less<string> >::iterator, bool> hResult;
        hResult = m_hBatches.insert(map<string,pair<int,double>,less<string> >::value_type(strSourceID,hPair));
        pBatch = hResult.first;
      }
      if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
         (*pBatch).second.second = 0;
      commit();
      if (!memcmp(pResponse->sOperation,"ZEROHASH",8))
      {
         set<string, less<string> >::iterator pSourceID;
         pSourceID = m_hRecovery.find(strSourceID);
         if (pSourceID != m_hRecovery.end())
            m_hRecovery.erase(pSourceID);
      }
      else
      {
         hMessage.reset("LE AI ","S0060R");
         strncpy(pResponse->sOperation,"HASHRESP",8);
         pResponse->dHashTotal = (*pBatch).second.second;
         pResponse->lTranCnt = (*pBatch).second.first;
         hMessage.setDataLength(sizeof(hHashMessage));
         hMessage.reply();
      }
      (*pBatch).second.second = 0;
      (*pBatch).second.first = 0;
      return 0;
   }
   if (hMessage.messageID() != (const char*)"S0002D"
      && hMessage.messageID() != (const char*)"S0012D")
      return ServiceApplication::onMessage(hMessage);
   string strSourceID;
   if (memcmp(hMessage.data(),"S207",4) == 0)
      strSourceID.assign(hMessage.data() + 8,8);
   map<string,pair<int,double>,less<string> >::iterator pBatch = m_hBatches.find(strSourceID);
   if (pBatch == m_hBatches.end())
   {
      pair<int,double> hPair(0,0);
      pair<map<string,pair<int,double>,less<string> >::iterator, bool> hResult = m_hBatches.insert(map<string,pair<int,double>,less<string> >::value_type(strSourceID,hPair));
      pBatch = hResult.first;
   }
   (*pBatch).second.first++;
   set<string, less<string> >::iterator pSourceID = m_hRecovery.find(strSourceID);
   if (pSourceID != m_hRecovery.end())
   {
      if (!memcmp(hMessage.data() + 16,"S200",4))
         m_pAddFinancialCommand->import(hMessage.data(),hMessage.dataLength()); //mask PAN
      return 0;
   }
   m_bInsert = true;
   (*pBatch).second.second += *((unsigned int*)(hMessage.data() + 4));
   int iRetry = 0;
   m_hMessages[m_lTransactionHashCount] = hMessage;
   int i = m_lTransactionHashCount;
   ++m_lTransactionHashCount;
   reusable::Transaction::instance()->begin();
   while (i < m_lTransactionHashCount)
   {
      m_pInterval[0]->start();
      // start commit interval (if not already started)
      m_pInterval[1]->start();
      int j = (hMessage.messageID() == (const char*)"S0002D") ? 0 : 1;
      if (!m_pModel[j]->onMessage(m_hMessages[i++]))
      {
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
         iRetry = 5;
      }
      if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      {
         Database::instance()->rollback();
         if (++iRetry > 5)
         {
            map<string,pair<int,double>,less<string> >::iterator pBatch;
            for (pBatch = m_hBatches.begin();pBatch != m_hBatches.end();++pBatch)
            {
               (*pBatch).second.second = 0;
               m_hRecovery.insert((*pBatch).first);
            }
         }
         else
         {
#ifdef MVS
            Sleep::goTo(m_strDBRetry.c_str());
#endif
            i = 0;
         }
      }
      else
      if (iRetry > 0)
      {
         Database::instance()->commit();
         GMTClock::instance()->update(0);
      }
      m_pInterval[0]->stop();
   }
   // commit if the queue is full
   if (m_lTransactionHashCount == m_lTransactionSize)
      commit();
   return 0;
  //## end LoadEngine::onMessage%36DEDE560356.body
}

int LoadEngine::onQuiesce ()
{
  //## begin LoadEngine::onQuiesce%3C5ED851036B.body preserve=yes
#ifdef MVS
   ServiceApplication::closeDoor();
   m_nState = Application::TASK_IN_QUIESCE;
   m_hTimer.set("00001000");
   return 0;
#else
   return Application::onQuiesce();
#endif
  //## end LoadEngine::onQuiesce%3C5ED851036B.body
}

void LoadEngine::update (Subject* pSubject)
{
  //## begin LoadEngine::update%3C71344102BF.body preserve=yes
   if (pSubject == &m_hTimer)
   {
      if (m_nState == Application::TASK_IN_QUIESCE)
      {
         int m = 0;
         map<string,pair<int,double>,less<string> >::iterator pBatch;
         for (pBatch = m_hBatches.begin();pBatch != m_hBatches.end();++pBatch)
            m += (*pBatch).second.first;
         if (m == 0 || --m_iQuiesceCount == 0)
            Application::onQuiesce();
         else
            m_hTimer.set("00001000");
         return;
      }
      if (m_bInsert)
          m_bInsert = false;
      else
      if (m_lTransactionHashCount > 0)
         commit();
      else
      {
         if (++m_iInactiveCount >= 6)
         { // let AI know we are here after 1 minute with no work
            ServiceApplication::idle();
            m_iInactiveCount = 0;
         }
      }
      m_hTimer.set("00001000");
      return;
   }
   if (pSubject == Database::instance()
      && Database::instance()->state() == Database::CONNECTED)
   {
      ServiceApplication::update(pSubject);
      ServiceApplication::idle();
      Database::instance()->commit();
      return;
   }
   ServiceApplication::update(pSubject);
  //## end LoadEngine::update%3C71344102BF.body
}

// Additional Declarations
  //## begin LoadEngine%34567B88036C.declarations preserve=yes
  //## end LoadEngine%34567B88036C.declarations

//## begin module%36DEDD82035B.epilog preserve=yes
//## end module%36DEDD82035B.epilog
