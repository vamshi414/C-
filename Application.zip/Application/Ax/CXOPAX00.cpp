//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4CF5A4CC02FD.cm preserve=no
//## end module%4CF5A4CC02FD.cm

//## begin module%4CF5A4CC02FD.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4CF5A4CC02FD.cp

//## Module: CXOPAX00%4CF5A4CC02FD; Package body
//## Subsystem: AX%4CF5A38002EB
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Ax\CXOPAX00.cpp

//## begin module%4CF5A4CC02FD.additionalIncludes preserve=no
//## end module%4CF5A4CC02FD.additionalIncludes

//## begin module%4CF5A4CC02FD.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#include "CXODNS40.hpp"
//## end module%4CF5A4CC02FD.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSRF01_h
#include "CXODRF01.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif
#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSRF19_h
#include "CXODRF19.hpp"
#endif
#ifndef CXOPAX00_h
#include "CXODAX00.hpp"
#endif


//## begin module%4CF5A4CC02FD.declarations preserve=no
//## end module%4CF5A4CC02FD.declarations

//## begin module%4CF5A4CC02FD.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new AutoConversion();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%4CF5A4CC02FD.additionalDeclarations


// Class AutoConversion 

AutoConversion::AutoConversion()
  //## begin AutoConversion::AutoConversion%4CF59DC201C4_const.hasinit preserve=no
      : m_pReconciliationFile(0)
  //## end AutoConversion::AutoConversion%4CF59DC201C4_const.hasinit
  //## begin AutoConversion::AutoConversion%4CF59DC201C4_const.initialization preserve=yes
  //## end AutoConversion::AutoConversion%4CF59DC201C4_const.initialization
{
  //## begin AutoConversion::AutoConversion%4CF59DC201C4_const.body preserve=yes
   memcpy(m_sID,"AX00",4);
  //## end AutoConversion::AutoConversion%4CF59DC201C4_const.body
}


AutoConversion::~AutoConversion()
{
  //## begin AutoConversion::~AutoConversion%4CF59DC201C4_dest.body preserve=yes
  //## end AutoConversion::~AutoConversion%4CF59DC201C4_dest.body
}



//## Other Operations (implementation)
int AutoConversion::initialize ()
{
  //## begin AutoConversion::initialize%4CF59DC201E6.body preserve=yes
   new dnplatform::DNPlatform();
   int i = Application::initialize();
   UseCase hUseCase("AUTO","## AX00 START AX");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   i = 0;
   string strRecord;
   while (IF::Extract::instance()->getRecord(i++,strRecord))
   {
      if (strRecord.length() > 16
         && strRecord.substr(0,13) == "DSPEC   RECON")
      {
         vector<string> hTokens;
         int i = Buffer::parse(strRecord.substr(16), " ", hTokens);
         if (i >= 4
            && ReconciliationFileFactory::instance()->verify(hTokens[1]))
         {
            map<string, reconciliationfile::ReconciliationFile>::iterator pCursor;
            pCursor = m_hFiles.find(hTokens[0]);
            reconciliationfile::ReconciliationFile hReconciliationFile;
            if (pCursor == m_hFiles.end())
            {
               hReconciliationFile.setClassName(hTokens[1]);
               hReconciliationFile.setGENNAM(hTokens[0]);
               hReconciliationFile.addEntity(hTokens[2], hTokens[3]);
               if (i >= 6 && hTokens[4] != "UC1" && hTokens[4] != "UC2")
                  hReconciliationFile.addEntity(hTokens[4], hTokens[5]);
               m_hFiles.insert(map<string, reconciliationfile::ReconciliationFile >::value_type(hTokens[0], hReconciliationFile));
               pCursor = m_hFiles.find(hTokens[0]);
            }
            else
            {
               (*pCursor).second.addEntity(hTokens[2], hTokens[3]);
               if (i >= 6 && hTokens[4] != "UC1" && hTokens[4] != "UC2")
                  (*pCursor).second.addEntity(hTokens[4], hTokens[5]);
            }
            vector<string>::iterator p;
            p = find(hTokens.begin(), hTokens.end(), "UC1");
            if (p != hTokens.end() && p + 1 != hTokens.end())
               (*pCursor).second.setRepositoryUseCase(*(p + 1));

            p = find(hTokens.begin(), hTokens.end(), "UC2");
            if (p != hTokens.end() && p + 1 != hTokens.end())
               (*pCursor).second.setTotalsCategoryUseCase(*(p + 1));
         }
      }
   }
   entitysegment::SwitchBusinessDay::instance();
   if (!m_hFiles.empty())
   {
      m_pCursor = m_hFiles.begin();
      MinuteTimer::instance()->attach(this);
   }
   Database::instance()->connect();
   return 0;
  //## end AutoConversion::initialize%4CF59DC201E6.body
}

int AutoConversion::onReset (IF::Message& hMessage)
{
  //## begin AutoConversion::onReset%4CF59DC201E7.body preserve=yes
#ifdef MVS
   Context hContext(Application::instance()->image(),Application::instance()->name());
   if (hMessage.context().length() >= 9
      && memcmp((char*)hMessage.context(),"COMPLETE-",9) == 0)
      hContext.put("XF0000","DC");
   else
   if (hMessage.context().length() >= 13
      && memcmp((char*)hMessage.context(),"RESEND",6) == 0)
   {
      string strCONTEXT_DATA;
      if (hContext.get("XF0000",strCONTEXT_DATA)
         && strCONTEXT_DATA.empty() == false
         && strCONTEXT_DATA != "DC")
         if (m_pReconciliationFile->getClassName() != "MCIINT")
            Job::submit("##CPAXAU","&GENNAM ",strCONTEXT_DATA.c_str());
         else
            Job::submit("##CPAXAI","&GENNAM ",strCONTEXT_DATA.c_str());
   }
   else
   if (!m_hFiles.empty())
      update(MinuteTimer::instance());
   Database::instance()->commit();
#endif
   return 0;
  //## end AutoConversion::onReset%4CF59DC201E7.body
}

void AutoConversion::update (Subject* pSubject)
{
  //## begin AutoConversion::update%4CF59DC201F5.body preserve=yes
   if (pSubject == MinuteTimer::instance())
   {
#ifdef MVS
      Context hContext(Application::instance()->image(),Application::instance()->name());
      string strCONTEXT_DATA;
      if (hContext.get("XF0000",strCONTEXT_DATA)
         && strCONTEXT_DATA.empty() == false
         && strCONTEXT_DATA != "DC")
      {
         if (Clock::instance()->getMinute() == 0
            || Clock::instance()->getMinute() == 30)
         {
            string strJob(Application::instance()->name().data(),2);
            if (m_pReconciliationFile->getClassName() !="MCIINT")
               strJob += "CPAXAU";
            else
               strJob += "CPAXAI";
            Console::display("ST147",strJob.c_str(),strCONTEXT_DATA.c_str());
         }
         return;
      }
#endif
      UseCase hUseCase("AUTO","## AX00 IMPORT FILES");
      for (;;)
      {
         m_pReconciliationFile = ReconciliationFileFactory::instance()->create((*m_pCursor).second.getClassName());
         if (!m_pReconciliationFile)
         {
            if (++m_pCursor == m_hFiles.end())
            {
               m_pCursor = m_hFiles.begin();
               break;
            }
            continue;
         }
         *m_pReconciliationFile = (*m_pCursor).second;
         if (m_pReconciliationFile->reFormat() == false
            && ++m_pCursor == m_hFiles.end())
         {
            delete m_pReconciliationFile;
            m_pReconciliationFile = 0;
            m_pCursor = m_hFiles.begin();
            break;
         }
         delete m_pReconciliationFile;
         m_pReconciliationFile = 0;
      }
   }
   Application::update(pSubject);
  //## end AutoConversion::update%4CF59DC201F5.body
}

// Additional Declarations
  //## begin AutoConversion%4CF59DC201C4.declarations preserve=yes
  //## end AutoConversion%4CF59DC201C4.declarations

//## begin module%4CF5A4CC02FD.epilog preserve=yes
//## end module%4CF5A4CC02FD.epilog
