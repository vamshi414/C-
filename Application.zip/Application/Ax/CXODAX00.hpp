//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4CF5A48D0212.cm preserve=no
//## end module%4CF5A48D0212.cm

//## begin module%4CF5A48D0212.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4CF5A48D0212.cp

//## Module: CXOPAX00%4CF5A48D0212; Package specification
//## Subsystem: AX%4CF5A38002EB
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Ax\CXODAX00.hpp

#ifndef CXOPAX00_h
#define CXOPAX00_h 1

//## begin module%4CF5A48D0212.additionalIncludes preserve=no
//## end module%4CF5A48D0212.additionalIncludes

//## begin module%4CF5A48D0212.includes preserve=yes
//## end module%4CF5A48D0212.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

namespace IF {
class Extract;
class Job;
class Console;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class MinuteTimer;
class Timer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class Context;
class Database;
} // namespace database

//## Modelname: Reconciliation::ReconciliationFile_CAT%439754C1037A
namespace reconciliationfile {
class ReconciliationFile;
class ReconciliationFileFactory;

} // namespace reconciliationfile

//## begin module%4CF5A48D0212.declarations preserve=no
//## end module%4CF5A48D0212.declarations

//## begin module%4CF5A48D0212.additionalDeclarations preserve=yes
//## end module%4CF5A48D0212.additionalDeclarations


//## begin AutoConversion%4CF59DC201C4.preface preserve=yes
//## end AutoConversion%4CF59DC201C4.preface

//## Class: AutoConversion%4CF59DC201C4
//	<body>
//	<title>CG
//	<h1>AX
//	<h2>AB
//	<!-- AutoConversion : General-->
//	<p>
//	The Auto Conversion service reads network files and maps
//	the transactions into a FIS Transaction Activity
//	(TXNACT) file.
//	This file is then sorted for input to the Auto
//	Reconciliation service.
//	The following network file formats are accepted:
//	<ul>
//	<li>AMXTLR - <a href="American Express
//	TILR.html">American Express TILR</a>
//	<li>CORTEX - FIS Cortex File
//	<li>DISARI - <a href="Discover Acquirer Report
//	Interface.html">Discover Acquirer Report Interface</a>
//	<li>ISOUSR - FIS Standard ISO User File
//	<li>MCI884 - MasterCard T884 File
//	<li>MCIINT - <a href="MasterCard TN70 File.html">Master
//	Card TN70 File</a>
//	<li>NYCEDF - NYCE network EDF
//	<li>TXNACT - <a href="FIS Transaction Activity
//	File.html">FIS Transaction Activity File</a>
//	<li>TXNATH - ATH (A Toda Hora) Interbank Network Activity
//	<li>TXNMCI - <a href="MasterCard IPM
//	Clearing.html">MasterCard IPM Clearing</a>
//	<li>TXNVNT - <a href="VISA BASE II Clearing.html">VISA
//	BASE II Clearing</a>
//	<li>VNT601 - <a href="VISA SMS 601C Report.html">VISA
//	SMS 601C Report</a>
//	<li>VNTSMS - VISA SMS
//	</ul>
//	<h3>System Flow
//	<p>
//	The Auto Conversion service (<i>ca</i>AX01) reads the
//	network unique file to map each transaction (which may
//	be in multiple logical records) into the FIS Transaction
//	Activity format.
//	The resulting output file is then sorted and passed to
//	the Auto Reconciliation service (<i>ca</i>AU01) .
//	</p>
//	<img src=CXOCAX00.gif>
//	</body>
//	<body>
//	<title>CG
//	<h1>AX
//	<h2>FI
//	<!-- AutoConversion : General-->
//	<h3>Extract File
//	<p>
//	Auto Conversion accepts any number of input transaction
//	logs.
//	Use the CR Client for the DataNavigator Server to define
//	each input file.
//	Site Specification data is used to further define each
//	file to indicate the type of file and the associated
//	issuer processor (IP) and/or acquirer processor (AP).
//	Files can also be configured for issuer processor group
//	(IG) and/or acquirer processor group (AG).
//	<p>
//	Here is an example extract:
//	<pre>
//	DMISC                                         00000000
//	00000000 00000000
//	DUSER   AX
//	DFILES  XF0000  CDNACMEP\XF0000\%date~%time~TXNACT.txt
//	DFILES  XF0001  CDNACMEP\XF0001\Pending\*.txt
//	DFILES  XF0002  CDNACMEP\XF0002\Pending\*.txt
//	DFILES  XF0003  CDNACMEP\XF0003\Pending\*.txt
//	DFILES  XF0004  CDNACMEP\XF0004\Pending\*.txt
//	DSPEC   RECON   XF0001 VNTSMS IP PRC001
//	DSPEC   RECON   XF0002 VNTSMS IP PRC002
//	DSPEC   RECON   XF0003 VNTSMS AP INT001
//	DSPEC   RECON   XF0003 VNTSMS AP INT002
//	DSPEC   RECON   XF0004 VNTSMS AP INT003 IP PRC003
//	</pre>
//	<p>
//	File definitions are in the Task Configuration folder in
//	the CR Client for the DataNavigator Server.
//	Custom Table Data is in the Custom Tables folder.
//	<h3>Sort Script
//	A <a href="../../Template/CXOXAXA2.txt">Perl script</a>
//	is used to sort the FIS Transaction Activity file and
//	copy for input to the Auto Reconciliation service.
//	</body>
//## Category: Reconciliation::AutoConversion_CAT%4CF5889001DE
//## Subsystem: AX%4CF5A38002EB
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4CF5B0A60316;database::Database { -> F}
//## Uses: <unnamed>%4CF5B1B50156;IF::Message { -> F}
//## Uses: <unnamed>%4CF5B1C10146;database::GlobalContext { -> F}
//## Uses: <unnamed>%4CF5B1C803E6;database::GlobalContext { -> F}
//## Uses: <unnamed>%4CF5B1CC03C7;monitor::UseCase { -> F}
//## Uses: <unnamed>%4CF5B1D003D7;reusable::Buffer { -> F}
//## Uses: <unnamed>%4CF5B1D40389;IF::Extract { -> F}
//## Uses: <unnamed>%4CF5B1DB027F;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%4CF5B1E10108;reconciliationfile::ReconciliationFileFactory { -> F}
//## Uses: <unnamed>%4CF6FA2901D8;timer::Timer { -> F}
//## Uses: <unnamed>%4D12C2CB0143;IF::Job { -> F}
//## Uses: <unnamed>%4D56046D00B2;database::Context { -> F}
//## Uses: <unnamed>%4D825970039A;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%4D825BE100B7;timer::Clock { -> F}
//## Uses: <unnamed>%4D88CF260284;IF::Console { -> F}

class DllExport AutoConversion : public process::Application  //## Inherits: <unnamed>%4CF59DC201F7
{
  //## begin AutoConversion%4CF59DC201C4.initialDeclarations preserve=yes
  //## end AutoConversion%4CF59DC201C4.initialDeclarations

  public:
    //## Constructors (generated)
      AutoConversion();

    //## Destructor (generated)
      virtual ~AutoConversion();


    //## Other Operations (specified)
      //## Operation: update%4CF59DC201F5
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin AutoConversion%4CF59DC201C4.public preserve=yes
      //## end AutoConversion%4CF59DC201C4.public

  protected:

    //## Other Operations (specified)
      //## Operation: onReset%4CF59DC201E7
      int onReset (IF::Message& hMessage);

    // Additional Protected Declarations
      //## begin AutoConversion%4CF59DC201C4.protected preserve=yes
      //## end AutoConversion%4CF59DC201C4.protected

  private:
    // Additional Private Declarations
      //## begin AutoConversion%4CF59DC201C4.private preserve=yes
      //## end AutoConversion%4CF59DC201C4.private

  private: //## implementation

    //## Other Operations (specified)
      //## Operation: initialize%4CF59DC201E6
      int initialize ();

    // Data Members for Class Attributes

      //## Attribute: Files%641B1E6A02C5
      //## begin AutoConversion::Files%641B1E6A02C5.attr preserve=no  private: map<string, reconciliationfile::ReconciliationFile> {V} 
      map<string, reconciliationfile::ReconciliationFile> m_hFiles;
      //## end AutoConversion::Files%641B1E6A02C5.attr

      //## Attribute: Cursor%641B1EB50399
      //## begin AutoConversion::Cursor%641B1EB50399.attr preserve=no  private: map<string, reconciliationfile::ReconciliationFile>::iterator {V} 
      map<string, reconciliationfile::ReconciliationFile>::iterator m_pCursor;
      //## end AutoConversion::Cursor%641B1EB50399.attr

    // Data Members for Associations

      //## Association: Reconciliation::AutoConversion_CAT::<unnamed>%4D560899019B
      //## Role: AutoConversion::<m_pReconciliationFile>%4D56089A0247
      //## begin AutoConversion::<m_pReconciliationFile>%4D56089A0247.role preserve=no  public: reconciliationfile::ReconciliationFile { -> RFHgN}
      reconciliationfile::ReconciliationFile *m_pReconciliationFile;
      //## end AutoConversion::<m_pReconciliationFile>%4D56089A0247.role

    // Additional Implementation Declarations
      //## begin AutoConversion%4CF59DC201C4.implementation preserve=yes
      //## end AutoConversion%4CF59DC201C4.implementation

};

//## begin AutoConversion%4CF59DC201C4.postscript preserve=yes
//## end AutoConversion%4CF59DC201C4.postscript

//## begin module%4CF5A48D0212.epilog preserve=yes
//## end module%4CF5A48D0212.epilog


#endif
