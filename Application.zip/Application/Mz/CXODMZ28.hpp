//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%66295F1A0109.cm preserve=no
//## end module%66295F1A0109.cm

//## begin module%66295F1A0109.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%66295F1A0109.cp

//## Module: CXOSMZ28%66295F1A0109; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ28.hpp

#ifndef CXOSMZ28_h
#define CXOSMZ28_h 1

//## begin module%66295F1A0109.additionalIncludes preserve=no
//## end module%66295F1A0109.additionalIncludes

//## begin module%66295F1A0109.includes preserve=yes
//## end module%66295F1A0109.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSMZ29_h
#include "CXODMZ29.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Buffer;
class Query;
class FormatSelectVisitor;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class EmailSegment;
} // namespace usersegment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Email;

} // namespace command

//## begin module%66295F1A0109.declarations preserve=no
//## end module%66295F1A0109.declarations

//## begin module%66295F1A0109.additionalDeclarations preserve=yes
//## end module%66295F1A0109.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::ExportFileFolder%66295E2503B9.preface preserve=yes
//## end metaoperator::ExportFileFolder%66295E2503B9.preface

//## Class: ExportFileFolder%66295E2503B9
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%66295E4F01A1;reusable::Query { -> F}
//## Uses: <unnamed>%66295E51035E;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%66295E5400E8;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%66295E560278;usersegment::EmailSegment { -> F}
//## Uses: <unnamed>%66295E590080;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%66295E5C009F;command::Email { -> F}
//## Uses: <unnamed>%662976030319;reusable::Buffer { -> F}
//## Uses: <unnamed>%662A62AC012A;reusable::FormatSelectVisitor { -> F}
//## Uses: <unnamed>%662A9A320183;timer::Date { -> F}

class DllExport ExportFileFolder : public reusable::Observer  //## Inherits: <unnamed>%66295E470078
{
  //## begin metaoperator::ExportFileFolder%66295E2503B9.initialDeclarations preserve=yes
  //## end metaoperator::ExportFileFolder%66295E2503B9.initialDeclarations

  public:
    //## Constructors (generated)
      ExportFileFolder();

    //## Destructor (generated)
      virtual ~ExportFileFolder();


    //## Other Operations (specified)
      //## Operation: add%6629741403E3
      void add (const string& strBuffer, vector<string>& hDX_FILE_TYPE);

      //## Operation: instance%6629625C0103
      static ExportFileFolder* instance ();

      //## Operation: report%6629602300F5
      bool report (command::Email* pEmail);

      //## Operation: update%66295FEA02A3
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin metaoperator::ExportFileFolder%66295E2503B9.public preserve=yes
      //## end metaoperator::ExportFileFolder%66295E2503B9.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::ExportFileFolder%66295E2503B9.protected preserve=yes
      //## end metaoperator::ExportFileFolder%66295E2503B9.protected

  private:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: DX_FILE_ID%662A4F9D0326
      const int getDX_FILE_ID () const
      {
        //## begin metaoperator::ExportFileFolder::getDX_FILE_ID%662A4F9D0326.get preserve=no
        return m_iDX_FILE_ID;
        //## end metaoperator::ExportFileFolder::getDX_FILE_ID%662A4F9D0326.get
      }


      //## Attribute: DX_FILE_TYPE%662A4FA401AE
      const string& getDX_FILE_TYPE () const
      {
        //## begin metaoperator::ExportFileFolder::getDX_FILE_TYPE%662A4FA401AE.get preserve=no
        return m_strDX_FILE_TYPE;
        //## end metaoperator::ExportFileFolder::getDX_FILE_TYPE%662A4FA401AE.get
      }


      //## Attribute: ENTITY_ID%662A4FAA0377
      const string& getENTITY_ID () const
      {
        //## begin metaoperator::ExportFileFolder::getENTITY_ID%662A4FAA0377.get preserve=no
        return m_strENTITY_ID;
        //## end metaoperator::ExportFileFolder::getENTITY_ID%662A4FAA0377.get
      }


      //## Attribute: ENTITY_TYPE%662A4FDC00A8
      const string& getENTITY_TYPE () const
      {
        //## begin metaoperator::ExportFileFolder::getENTITY_TYPE%662A4FDC00A8.get preserve=no
        return m_strENTITY_TYPE;
        //## end metaoperator::ExportFileFolder::getENTITY_TYPE%662A4FDC00A8.get
      }


      //## Attribute: SEQ_NO%662A4FC90346
      const string& getSEQ_NO () const
      {
        //## begin metaoperator::ExportFileFolder::getSEQ_NO%662A4FC90346.get preserve=no
        return m_strSEQ_NO;
        //## end metaoperator::ExportFileFolder::getSEQ_NO%662A4FC90346.get
      }


    // Additional Private Declarations
      //## begin metaoperator::ExportFileFolder%66295E2503B9.private preserve=yes
      //## end metaoperator::ExportFileFolder%66295E2503B9.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin metaoperator::ExportFileFolder::DX_FILE_ID%662A4F9D0326.attr preserve=no  private: int {V} 0
      int m_iDX_FILE_ID;
      //## end metaoperator::ExportFileFolder::DX_FILE_ID%662A4F9D0326.attr

      //## Attribute: hDX_FILE_TYPE%662974AE02CD
      //## begin metaoperator::ExportFileFolder::hDX_FILE_TYPE%662974AE02CD.attr preserve=no  private: set<string,less<string> > {U} 
      set<string,less<string> > m_hDX_FILE_TYPE;
      //## end metaoperator::ExportFileFolder::hDX_FILE_TYPE%662974AE02CD.attr

      //## begin metaoperator::ExportFileFolder::DX_FILE_TYPE%662A4FA401AE.attr preserve=no  private: string {V} 
      string m_strDX_FILE_TYPE;
      //## end metaoperator::ExportFileFolder::DX_FILE_TYPE%662A4FA401AE.attr

      //## begin metaoperator::ExportFileFolder::ENTITY_ID%662A4FAA0377.attr preserve=no  private: string {V} 
      string m_strENTITY_ID;
      //## end metaoperator::ExportFileFolder::ENTITY_ID%662A4FAA0377.attr

      //## begin metaoperator::ExportFileFolder::ENTITY_TYPE%662A4FDC00A8.attr preserve=no  private: string {V} 
      string m_strENTITY_TYPE;
      //## end metaoperator::ExportFileFolder::ENTITY_TYPE%662A4FDC00A8.attr

      //## Attribute: Index%662A9A72012C
      //## begin metaoperator::ExportFileFolder::Index%662A9A72012C.attr preserve=no  private: int {V} 0
      int m_iIndex;
      //## end metaoperator::ExportFileFolder::Index%662A9A72012C.attr

      //## Attribute: Instance%6629628601B2
      //## begin metaoperator::ExportFileFolder::Instance%6629628601B2.attr preserve=no  private: static ExportFileFolder* {V} 0
      static ExportFileFolder* m_pInstance;
      //## end metaoperator::ExportFileFolder::Instance%6629628601B2.attr

      //## begin metaoperator::ExportFileFolder::SEQ_NO%662A4FC90346.attr preserve=no  private: string {V} 
      string m_strSEQ_NO;
      //## end metaoperator::ExportFileFolder::SEQ_NO%662A4FC90346.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%66295E6B0108
      //## Role: ExportFileFolder::<m_pEmail>%66295E6C00C0
      //## begin metaoperator::ExportFileFolder::<m_pEmail>%66295E6C00C0.role preserve=no  public: command::Email { -> RFHgN}
      command::Email *m_pEmail;
      //## end metaoperator::ExportFileFolder::<m_pEmail>%66295E6C00C0.role

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%662A468D0261
      //## Role: ExportFileFolder::<m_hExportFile>%662A468E0353
      //## Qualifier: File%662A46A70182; string
      //## begin metaoperator::ExportFileFolder::<m_hExportFile>%662A468E0353.role preserve=no  public: metaoperator::ExportFile { -> VHgN}
      map<string, ExportFile, less<string> > m_hExportFile;
      //## end metaoperator::ExportFileFolder::<m_hExportFile>%662A468E0353.role

    // Additional Implementation Declarations
      //## begin metaoperator::ExportFileFolder%66295E2503B9.implementation preserve=yes
      //## end metaoperator::ExportFileFolder%66295E2503B9.implementation

};

//## begin metaoperator::ExportFileFolder%66295E2503B9.postscript preserve=yes
//## end metaoperator::ExportFileFolder%66295E2503B9.postscript

} // namespace metaoperator

//## begin module%66295F1A0109.epilog preserve=yes
//## end module%66295F1A0109.epilog


#endif
