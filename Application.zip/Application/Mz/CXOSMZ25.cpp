//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65B2AAFB027D.cm preserve=no
//## end module%65B2AAFB027D.cm

//## begin module%65B2AAFB027D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65B2AAFB027D.cp

//## Module: CXOSMZ25%65B2AAFB027D; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ25.cpp

//## begin module%65B2AAFB027D.additionalIncludes preserve=no
//## end module%65B2AAFB027D.additionalIncludes

//## begin module%65B2AAFB027D.includes preserve=yes
//## end module%65B2AAFB027D.includes

#ifndef CXOSMZ25_h
#include "CXODMZ25.hpp"
#endif
//## begin module%65B2AAFB027D.declarations preserve=no
//## end module%65B2AAFB027D.declarations

//## begin module%65B2AAFB027D.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Condition* createMatch()
   {
      return new metaoperator::Match();
   }
   const bool registered = metaoperator::ConditionFactory::instance()->registerCondition("match",createMatch);
}
//## end module%65B2AAFB027D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::Match 

//## begin metaoperator::Match::Result%65DF96C801FD.attr preserve=no  public: static short {V} -1
short Match::m_siResult = -1;
//## end metaoperator::Match::Result%65DF96C801FD.attr

Match::Match()
  //## begin Match::Match%65B2AA9F02E5_const.hasinit preserve=no
  //## end Match::Match%65B2AA9F02E5_const.hasinit
  //## begin Match::Match%65B2AA9F02E5_const.initialization preserve=yes
  //## end Match::Match%65B2AA9F02E5_const.initialization
{
  //## begin metaoperator::Match::Match%65B2AA9F02E5_const.body preserve=yes
   memcpy(m_sID,"MZ25",4);
  //## end metaoperator::Match::Match%65B2AA9F02E5_const.body
}


Match::~Match()
{
  //## begin metaoperator::Match::~Match%65B2AA9F02E5_dest.body preserve=yes
  //## end metaoperator::Match::~Match%65B2AA9F02E5_dest.body
}



//## Other Operations (implementation)
void Match::setToken (const vector<string>& hToken)
{
  //## begin metaoperator::Match::setToken%65B2AE680170.body preserve=yes
   Condition::setToken(hToken);
   if (hToken.size() > 3)
      Condition::addMatch(hToken[2],hToken[3]);
  //## end metaoperator::Match::setToken%65B2AE680170.body
}

bool Match::test ()
{
  //## begin metaoperator::Match::test%65B2AAC403E6.body preserve=yes
   if (m_hToken.size() < 4)
      return false;
   string strDatasetName;
   Condition::getValue(m_hToken[2],strDatasetName);
   if (strDatasetName.empty())
      return false;
   if (m_siResult < 1)
      m_siResult = Condition::match(m_hToken[2],m_hToken[3]) ? 1 : 0;
   return true;
  //## end metaoperator::Match::test%65B2AAC403E6.body
}

// Additional Declarations
  //## begin metaoperator::Match%65B2AA9F02E5.declarations preserve=yes
  //## end metaoperator::Match%65B2AA9F02E5.declarations

} // namespace metaoperator

//## begin module%65B2AAFB027D.epilog preserve=yes
//## end module%65B2AAFB027D.epilog
