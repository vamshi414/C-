//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6397F7ED0034.cm preserve=no
//## end module%6397F7ED0034.cm

//## begin module%6397F7ED0034.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6397F7ED0034.cp

//## Module: CXOSMZ10%6397F7ED0034; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ10.cpp

//## begin module%6397F7ED0034.additionalIncludes preserve=no
//## end module%6397F7ED0034.additionalIncludes

//## begin module%6397F7ED0034.includes preserve=yes
#include "CXODMZ23.hpp"
//## end module%6397F7ED0034.includes

#ifndef CXOSTM13_h
#include "CXODTM13.hpp"
#endif
#ifndef CXOSUS21_h
#include "CXODUS21.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSBS30_h
#include "CXODBS30.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMZ11_h
#include "CXODMZ11.hpp"
#endif
#ifndef CXOSMZ12_h
#include "CXODMZ12.hpp"
#endif
#ifndef CXOSMZ13_h
#include "CXODMZ13.hpp"
#endif
#ifndef CXOSMZ22_h
#include "CXODMZ22.hpp"
#endif
#ifndef CXOSMZ27_h
#include "CXODMZ27.hpp"
#endif
#ifndef CXOSMZ28_h
#include "CXODMZ28.hpp"
#endif
#ifndef CXOSBC25_h
#include "CXODBC25.hpp"
#endif
#ifndef CXOSMZ10_h
#include "CXODMZ10.hpp"
#endif


//## begin module%6397F7ED0034.declarations preserve=no
//## end module%6397F7ED0034.declarations

//## begin module%6397F7ED0034.additionalDeclarations preserve=yes
//## end module%6397F7ED0034.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::StatusEmail 

StatusEmail::StatusEmail()
  //## begin StatusEmail::StatusEmail%6397F6920027_const.hasinit preserve=no
      : m_pEmail(0)
  //## end StatusEmail::StatusEmail%6397F6920027_const.hasinit
  //## begin StatusEmail::StatusEmail%6397F6920027_const.initialization preserve=yes
  //## end StatusEmail::StatusEmail%6397F6920027_const.initialization
{
  //## begin metaoperator::StatusEmail::StatusEmail%6397F6920027_const.body preserve=yes
   memcpy(m_sID,"MZ10",4);
   HourAlarm::instance()->attach(this);
  //## end metaoperator::StatusEmail::StatusEmail%6397F6920027_const.body
}


StatusEmail::~StatusEmail()
{
  //## begin metaoperator::StatusEmail::~StatusEmail%6397F6920027_dest.body preserve=yes
   HourAlarm::instance()->detach(this);
  //## end metaoperator::StatusEmail::~StatusEmail%6397F6920027_dest.body
}



//## Other Operations (implementation)
bool StatusEmail::initialize ()
{
  //## begin metaoperator::StatusEmail::initialize%63987DDE0111.body preserve=yes
   Query hQuery;
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   ContactSegment::instance(ContactSegment::SENDER)->bind(hQuery);
   hQuery.setQualifier("QUALIFY","CONTACT_TYPE");
   hQuery.setQualifier("QUALIFY","STS_CUSTOMER");
   hQuery.join("CONTACT_TYPE","INNER","STS_CUSTOMER","CONTACT_ID");
   hQuery.setBasicPredicate("STS_CUSTOMER","CUST_ID","=",strCUST_ID.c_str());
   hQuery.setBasicPredicate("STS_CUSTOMER","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("STS_CUSTOMER","CC_STATE","=","A");
   hQuery.setBasicPredicate("CONTACT_TYPE","CONTACT_TYPE","=","ASG");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(hQuery) == false
      || pSelectStatement->getRows() == 0)
      return false;
   return true;
  //## end metaoperator::StatusEmail::initialize%63987DDE0111.body
}

bool StatusEmail::send ()
{
  //## begin metaoperator::StatusEmail::send%6397F91002D7.body preserve=yes
   string strDATE_RECON(entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(1));
   m_pEmail = new command::Email("OEMZ10","AP","PRC999",strDATE_RECON,Clock::instance()->getYYYYMMDDHHMMSS().substr(8,6),"CXOEMZ10");
   m_pEmail->add('C',ContactSegment::instance(ContactSegment::SENDER));
   strDATE_RECON.insert(6,1,'-');
   strDATE_RECON.insert(4,1,'-');
   usersegment::EmailSegment::instance()->reset();
   usersegment::EmailSegment::instance()->setDATE_RECON(strDATE_RECON);
   string strValue;
   Extract::instance()->getSpec("PROC",strValue);
   usersegment::EmailSegment::instance()->setServer(strValue);
   m_pEmail->add('Z',usersegment::EmailSegment::instance());
   m_pEmail->report('C');
   ExportFileFolder::instance()->report(m_pEmail);
   {
   AuditFolder x;
   x.report(m_pEmail);
   }
   {
   FileFolder x;
   x.report(m_pEmail);
   }
   {
   ClearingFolder x;
   x.report(m_pEmail);
   }
   {
   SettlementFolder x;
   x.report(m_pEmail);
   }
   {
   ReconciliationFileFolder x;
   x.report(m_pEmail);
   }
   {
   StatusFolder x;
   x.report(m_pEmail);
   }
   m_pEmail->report('T');
   m_pEmail->complete();
   delete m_pEmail;
   m_pEmail = 0;
   Database::instance()->commit();
   return true;
  //## end metaoperator::StatusEmail::send%6397F91002D7.body
}

void StatusEmail::update (Subject* pSubject)
{
  //## begin metaoperator::StatusEmail::update%6397F7A80112.body preserve=yes
   if (pSubject == 0)
      initialize();
   send();
  //## end metaoperator::StatusEmail::update%6397F7A80112.body
}

// Additional Declarations
  //## begin metaoperator::StatusEmail%6397F6920027.declarations preserve=yes
  //## end metaoperator::StatusEmail%6397F6920027.declarations

} // namespace metaoperator

//## begin module%6397F7ED0034.epilog preserve=yes
//## end module%6397F7ED0034.epilog
