//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6234D82C016B.cm preserve=no
//## end module%6234D82C016B.cm

//## begin module%6234D82C016B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6234D82C016B.cp

//## Module: CXOSMZ03%6234D82C016B; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ03.cpp

//## begin module%6234D82C016B.additionalIncludes preserve=no
//## end module%6234D82C016B.additionalIncludes

//## begin module%6234D82C016B.includes preserve=yes
#include "CXODDB25.hpp"
#include "CXODIF50.hpp"
#include "CXODTM04.hpp"
#include <sstream>
//## end module%6234D82C016B.includes

#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOPMZ00_h
#include "CXODMZ00.hpp"
#endif
#ifndef CXOSMZ03_h
#include "CXODMZ03.hpp"
#endif


//## begin module%6234D82C016B.declarations preserve=no
//## end module%6234D82C016B.declarations

//## begin module%6234D82C016B.additionalDeclarations preserve=yes
//## end module%6234D82C016B.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::Function 

Function::Function()
  //## begin Function::Function%6234A7200264_const.hasinit preserve=no
  //## end Function::Function%6234A7200264_const.hasinit
  //## begin Function::Function%6234A7200264_const.initialization preserve=yes
  //## end Function::Function%6234A7200264_const.initialization
{
  //## begin metaoperator::Function::Function%6234A7200264_const.body preserve=yes
   memcpy(m_sID,"MZ03",4);
  //## end metaoperator::Function::Function%6234A7200264_const.body
}


Function::~Function()
{
  //## begin metaoperator::Function::~Function%6234A7200264_dest.body preserve=yes
  //## end metaoperator::Function::~Function%6234A7200264_dest.body
}



//## Other Operations (implementation)
int Function::execute ()
{
  //## begin metaoperator::Function::execute%6234A764008C.body preserve=yes
   bool iSuccess = 0;
   string strValue;
   if (m_hToken[1] == "++"
      || m_hToken[1] == "--")
   {
      string strKey(m_hToken[2]);
      strKey.append(m_hToken[1][0] == '+' ? "+1" : "-1", 2);
      iSuccess = Condition::getValue(strKey,strValue) && MetaOperator::put(m_hToken[2],strValue.data()) ? 1 : -1;
      if (iSuccess == 1)
         Condition::setValue(m_hToken[2],strValue);
      if (IF::Trace::getEnable())
      {
         std::ostringstream oss;
         oss << "Function : " << m_hToken[1] << m_hToken[2] << " -> " << strValue << " -> " << (iSuccess == 1 ? "True" : "False");
         IF::Trace::put(oss.str().data());
      }
      return iSuccess;
   }
   if (IF::Trace::getEnable())
   {
      std::ostringstream oss;
      oss << "Function : " << m_hToken[1] << " -> Not Supported";
      IF::Trace::put(oss.str().data());
   }
   return iSuccess;
  //## end metaoperator::Function::execute%6234A764008C.body
}

void Function::setToken (const vector<string>& hToken)
{
  //## begin metaoperator::Function::setToken%6390FA8102AA.body preserve=yes
   for (int i = 0;i < hToken.size();++i)
      m_hToken.push_back(hToken[i]);
  //## end metaoperator::Function::setToken%6390FA8102AA.body
}

void Function::update (Subject* pSubject)
{
  //## begin metaoperator::Function::update%63B53F5803D8.body preserve=yes
  //## end metaoperator::Function::update%63B53F5803D8.body
}

// Additional Declarations
  //## begin metaoperator::Function%6234A7200264.declarations preserve=yes
  //## end metaoperator::Function%6234A7200264.declarations

} // namespace metaoperator

//## begin module%6234D82C016B.epilog preserve=yes
//## end module%6234D82C016B.epilog
