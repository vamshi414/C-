//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B46531011E.cm preserve=no
//## end module%63B46531011E.cm

//## begin module%63B46531011E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B46531011E.cp

//## Module: CXOSMZ15%63B46531011E; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ15.hpp

#ifndef CXOSMZ15_h
#define CXOSMZ15_h 1

//## begin module%63B46531011E.additionalIncludes preserve=no
//## end module%63B46531011E.additionalIncludes

//## begin module%63B46531011E.includes preserve=yes
//## end module%63B46531011E.includes

#ifndef CXOSMZ02_h
#include "CXODMZ02.hpp"
#endif
//## begin module%63B46531011E.declarations preserve=no
//## end module%63B46531011E.declarations

//## begin module%63B46531011E.additionalDeclarations preserve=yes
//## end module%63B46531011E.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::GlobalContext%63B4640B0132.preface preserve=yes
//## end metaoperator::GlobalContext%63B4640B0132.preface

//## Class: GlobalContext%63B4640B0132
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport GlobalContext : public Condition  //## Inherits: <unnamed>%63B4643A0366
{
  //## begin metaoperator::GlobalContext%63B4640B0132.initialDeclarations preserve=yes
  //## end metaoperator::GlobalContext%63B4640B0132.initialDeclarations

  public:
    //## Constructors (generated)
      GlobalContext();

    //## Destructor (generated)
      virtual ~GlobalContext();


    //## Other Operations (specified)
      //## Operation: test%63B46449017E
      virtual bool test ();

    // Additional Public Declarations
      //## begin metaoperator::GlobalContext%63B4640B0132.public preserve=yes
      //## end metaoperator::GlobalContext%63B4640B0132.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::GlobalContext%63B4640B0132.protected preserve=yes
      //## end metaoperator::GlobalContext%63B4640B0132.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::GlobalContext%63B4640B0132.private preserve=yes
      //## end metaoperator::GlobalContext%63B4640B0132.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin metaoperator::GlobalContext%63B4640B0132.implementation preserve=yes
      //## end metaoperator::GlobalContext%63B4640B0132.implementation

};

//## begin metaoperator::GlobalContext%63B4640B0132.postscript preserve=yes
//## end metaoperator::GlobalContext%63B4640B0132.postscript

} // namespace metaoperator

//## begin module%63B46531011E.epilog preserve=yes
//## end module%63B46531011E.epilog


#endif
