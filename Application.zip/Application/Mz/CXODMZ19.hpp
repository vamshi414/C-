//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B4A41C02EA.cm preserve=no
//## end module%63B4A41C02EA.cm

//## begin module%63B4A41C02EA.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B4A41C02EA.cp

//## Module: CXOSMZ19%63B4A41C02EA; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ19.hpp

#ifndef CXOSMZ19_h
#define CXOSMZ19_h 1

//## begin module%63B4A41C02EA.additionalIncludes preserve=no
//## end module%63B4A41C02EA.additionalIncludes

//## begin module%63B4A41C02EA.includes preserve=yes
//## end module%63B4A41C02EA.includes

#ifndef CXOSMZ03_h
#include "CXODMZ03.hpp"
#endif

//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
class Report;
} // namespace metaoperator

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%63B4A41C02EA.declarations preserve=no
//## end module%63B4A41C02EA.declarations

//## begin module%63B4A41C02EA.additionalDeclarations preserve=yes
//## end module%63B4A41C02EA.additionalDeclarations


namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::ConcatenateFiles%63B4A31E0171.preface preserve=yes
//## end metaoperator::ConcatenateFiles%63B4A31E0171.preface

//## Class: ConcatenateFiles%63B4A31E0171
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%63B5238801D5;reusable::Query { -> F}
//## Uses: <unnamed>%63B52399036C;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%63B523A2028C;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%63B5241F0257;Report { -> F}
//## Uses: <unnamed>%63C7F69F0291;IF::Extract { -> F}

class DllExport ConcatenateFiles : public Function  //## Inherits: <unnamed>%63B4A32C00AE
{
  //## begin metaoperator::ConcatenateFiles%63B4A31E0171.initialDeclarations preserve=yes
  //## end metaoperator::ConcatenateFiles%63B4A31E0171.initialDeclarations

  public:
    //## Constructors (generated)
      ConcatenateFiles();

    //## Destructor (generated)
      virtual ~ConcatenateFiles();


    //## Other Operations (specified)
      //## Operation: execute%63B4A3400207
      virtual int execute ();

      //## Operation: update%63B528090071
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin metaoperator::ConcatenateFiles%63B4A31E0171.public preserve=yes
      //## end metaoperator::ConcatenateFiles%63B4A31E0171.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::ConcatenateFiles%63B4A31E0171.protected preserve=yes
      //## end metaoperator::ConcatenateFiles%63B4A31E0171.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::ConcatenateFiles%63B4A31E0171.private preserve=yes
      //## end metaoperator::ConcatenateFiles%63B4A31E0171.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Command%63E6770E03CB
      //## begin metaoperator::ConcatenateFiles::Command%63E6770E03CB.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strCommand;
      //## end metaoperator::ConcatenateFiles::Command%63E6770E03CB.attr

      //## Attribute: DX_PATH%63B524B70367
      //## begin metaoperator::ConcatenateFiles::DX_PATH%63B524B70367.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strDX_PATH;
      //## end metaoperator::ConcatenateFiles::DX_PATH%63B524B70367.attr

      //## Attribute: Operator%63E67881027F
      //## begin metaoperator::ConcatenateFiles::Operator%63E67881027F.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strOperator;
      //## end metaoperator::ConcatenateFiles::Operator%63E67881027F.attr

      //## Attribute: Path%63E6A430000B
      //## begin metaoperator::ConcatenateFiles::Path%63E6A430000B.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strPath;
      //## end metaoperator::ConcatenateFiles::Path%63E6A430000B.attr

    // Additional Implementation Declarations
      //## begin metaoperator::ConcatenateFiles%63B4A31E0171.implementation preserve=yes
      //## end metaoperator::ConcatenateFiles%63B4A31E0171.implementation

};

//## begin metaoperator::ConcatenateFiles%63B4A31E0171.postscript preserve=yes
//## end metaoperator::ConcatenateFiles%63B4A31E0171.postscript

} // namespace metaoperator

//## begin module%63B4A41C02EA.epilog preserve=yes
//## end module%63B4A41C02EA.epilog


#endif
