//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64386179018B.cm preserve=no
//## end module%64386179018B.cm

//## begin module%64386179018B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64386179018B.cp

//## Module: CXOSMZ23%64386179018B; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ23.hpp

#ifndef CXOSMZ23_h
#define CXOSMZ23_h 1

//## begin module%64386179018B.additionalIncludes preserve=no
//## end module%64386179018B.additionalIncludes

//## begin module%64386179018B.includes preserve=yes
//## end module%64386179018B.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MidnightAlarm;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Email;
} // namespace command

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class EmailSegment;

} // namespace usersegment

//## begin module%64386179018B.declarations preserve=no
//## end module%64386179018B.declarations

//## begin module%64386179018B.additionalDeclarations preserve=yes
//## end module%64386179018B.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::FileFolder%643860CF02F2.preface preserve=yes
//## end metaoperator::FileFolder%643860CF02F2.preface

//## Class: FileFolder%643860CF02F2
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%643860ED0273;reusable::Query { -> F}
//## Uses: <unnamed>%643860EF00BC;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%643860F100CB;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%643860F300D6;usersegment::EmailSegment { -> F}
//## Uses: <unnamed>%64386B0C0262;timer::MidnightAlarm { -> F}

class DllExport FileFolder : public reusable::Observer  //## Inherits: <unnamed>%643860DC02FE
{
  //## begin metaoperator::FileFolder%643860CF02F2.initialDeclarations preserve=yes
  //## end metaoperator::FileFolder%643860CF02F2.initialDeclarations

  public:
    //## Constructors (generated)
      FileFolder();

    //## Destructor (generated)
      virtual ~FileFolder();


    //## Other Operations (specified)
      //## Operation: report%6438613E0029
      bool report (command::Email* pEmail);

      //## Operation: update%643861210140
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin metaoperator::FileFolder%643860CF02F2.public preserve=yes
      //## end metaoperator::FileFolder%643860CF02F2.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::FileFolder%643860CF02F2.protected preserve=yes
      //## end metaoperator::FileFolder%643860CF02F2.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::FileFolder%643860CF02F2.private preserve=yes
      //## end metaoperator::FileFolder%643860CF02F2.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BUCKET%6438625E01A7
      //## begin metaoperator::FileFolder::BUCKET%6438625E01A7.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strBUCKET;
      //## end metaoperator::FileFolder::BUCKET%6438625E01A7.attr

      //## Attribute: ITEM_COUNT%643862670151
      //## begin metaoperator::FileFolder::ITEM_COUNT%643862670151.attr preserve=no  private: int {V} 0
      int m_iITEM_COUNT;
      //## end metaoperator::FileFolder::ITEM_COUNT%643862670151.attr

      //## Attribute: MEMBER_NAME%6438624700C1
      //## begin metaoperator::FileFolder::MEMBER_NAME%6438624700C1.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strMEMBER_NAME;
      //## end metaoperator::FileFolder::MEMBER_NAME%6438624700C1.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%643862130058
      //## Role: FileFolder::<m_pEmail>%64386213031C
      //## begin metaoperator::FileFolder::<m_pEmail>%64386213031C.role preserve=no  public: command::Email { -> RFHgN}
      command::Email *m_pEmail;
      //## end metaoperator::FileFolder::<m_pEmail>%64386213031C.role

    // Additional Implementation Declarations
      //## begin metaoperator::FileFolder%643860CF02F2.implementation preserve=yes
      //## end metaoperator::FileFolder%643860CF02F2.implementation

};

//## begin metaoperator::FileFolder%643860CF02F2.postscript preserve=yes
//## end metaoperator::FileFolder%643860CF02F2.postscript

} // namespace metaoperator

//## begin module%64386179018B.epilog preserve=yes
//## end module%64386179018B.epilog


#endif
