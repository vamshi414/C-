//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B467A100B2.cm preserve=no
//## end module%63B467A100B2.cm

//## begin module%63B467A100B2.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B467A100B2.cp

//## Module: CXOSMZ18%63B467A100B2; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ18.cpp

//## begin module%63B467A100B2.additionalIncludes preserve=no
//## end module%63B467A100B2.additionalIncludes

//## begin module%63B467A100B2.includes preserve=yes
#include "CXODDB06.hpp"
//## end module%63B467A100B2.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSMZ01_h
#include "CXODMZ01.hpp"
#endif
#ifndef CXOSMZ03_h
#include "CXODMZ03.hpp"
#endif
#ifndef CXOSMZ18_h
#include "CXODMZ18.hpp"
#endif


//## begin module%63B467A100B2.declarations preserve=no
//## end module%63B467A100B2.declarations

//## begin module%63B467A100B2.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Condition* createScrape()
   {
      return new metaoperator::Scrape();
   }
   const bool registered = metaoperator::ConditionFactory::instance()->registerCondition("Scrape",createScrape);
}
//## end module%63B467A100B2.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::Scrape 

Scrape::Scrape()
  //## begin Scrape::Scrape%63B464EC02C9_const.hasinit preserve=no
  //## end Scrape::Scrape%63B464EC02C9_const.hasinit
  //## begin Scrape::Scrape%63B464EC02C9_const.initialization preserve=yes
  //## end Scrape::Scrape%63B464EC02C9_const.initialization
{
  //## begin metaoperator::Scrape::Scrape%63B464EC02C9_const.body preserve=yes
   memcpy(m_sID,"MZ18",4);
  //## end metaoperator::Scrape::Scrape%63B464EC02C9_const.body
}


Scrape::~Scrape()
{
  //## begin metaoperator::Scrape::~Scrape%63B464EC02C9_dest.body preserve=yes
  //## end metaoperator::Scrape::~Scrape%63B464EC02C9_dest.body
}



//## Other Operations (implementation)
bool Scrape::test ()
{
  //## begin metaoperator::Scrape::test%63B464FD0328.body preserve=yes
   string strDATE_RECON;
   Query hQuery;
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   vector<Function*>& hFunction = Rule::getRule()->getFunction();
   for (vector<Function*>::iterator pFunction = hFunction.begin(); pFunction != hFunction.end(); ++pFunction)
   {
      if ((*pFunction)->m_hToken.size() >= 4
         && (*pFunction)->m_hToken[1] == "TRIGGER")
      {
         hQuery.bind("DX_DATA_CONTROL","DATE_RECON",Column::STRING,&strDATE_RECON,0,"MAX");
         hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","=",(*pFunction)->m_hToken[2].c_str());
         hQuery.setBasicPredicate("DX_DATA_CONTROL","ENTITY_ID","=",(*pFunction)->m_hToken[3].c_str());
         if (pSelectStatement->execute(hQuery) == false)
            return false;
         break;
      }
      if ((*pFunction)->m_hToken.size() >= 4
         && (*pFunction)->m_hToken[1] == "set")
      {
         GlobalContext hGlobalContext((*pFunction)->m_hToken[2].c_str() + 1);
         hGlobalContext.get(strDATE_RECON);
         break;
      }
   }
   if (strDATE_RECON.empty())
   {
      entitysegment::SwitchBusinessDay::instance()->update(timer::MidnightAlarm::instance());
      strDATE_RECON = entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(0);
   }
   else
   {
      Date hDate(strDATE_RECON.c_str());
      hDate += 1;
      strDATE_RECON = hDate.asString("%Y%m%d");
   }
   string strREPORT_NAME;
   string strNETWORK_CYCLE;
   hQuery.reset();
   hQuery.setDistinct(true);
   hQuery.bind("T_RECON_TOTAL","NETWORK_CYCLE",Column::STRING,&strNETWORK_CYCLE);
   hQuery.bind("T_RECON_TOTAL","REPORT_NAME",Column::STRING,&strREPORT_NAME);
   hQuery.setBasicPredicate("T_RECON_TOTAL","DATE_RECON_ISS","=",strDATE_RECON.c_str());
   hQuery.getSearchCondition().append(" AND (");
   hQuery.setBasicPredicate("T_RECON_TOTAL","PROC_ID","=",m_hToken[3].c_str());
   hQuery.setBasicPredicate("T_RECON_TOTAL","INST_ID","=",m_hToken[3].c_str(),false,false);
   hQuery.getSearchCondition().append(")");
   hQuery.setBasicPredicate("T_RECON_TOTAL","REPORT_SOURCE","=","N");
   hQuery.setBasicPredicate("T_RECON_TOTAL","NETWORK_ID","=",m_hToken[2].c_str());
   strREPORT_NAME.assign("(",1);
   for (int i = 5;i < m_hToken.size();++i)
   {
      strREPORT_NAME.append("'",1);
      strREPORT_NAME += m_hToken[i];
      strREPORT_NAME.append("',",2);
   }
   strREPORT_NAME[strREPORT_NAME.size() - 1] = ')';
   hQuery.setBasicPredicate("T_RECON_TOTAL","REPORT_NAME","IN",strREPORT_NAME.c_str());
   if (!pSelectStatement->execute(hQuery))
      return false;
   bool b = pSelectStatement->getRows() >= (m_hToken.size() - 5) * atoi(m_hToken[4].c_str());
   setValue("DATE_RECON",strDATE_RECON);
   setValue("ENTITY_ID",m_hToken[3]);
   return b;
  //## end metaoperator::Scrape::test%63B464FD0328.body
}

// Additional Declarations
  //## begin metaoperator::Scrape%63B464EC02C9.declarations preserve=yes
  //## end metaoperator::Scrape%63B464EC02C9.declarations

} // namespace metaoperator

//## begin module%63B467A100B2.epilog preserve=yes
//## end module%63B467A100B2.epilog
