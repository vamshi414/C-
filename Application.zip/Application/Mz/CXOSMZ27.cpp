//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%661FE1DA0384.cm preserve=no
//## end module%661FE1DA0384.cm

//## begin module%661FE1DA0384.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%661FE1DA0384.cp

//## Module: CXOSMZ27%661FE1DA0384; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ27.cpp

//## begin module%661FE1DA0384.additionalIncludes preserve=no
//## end module%661FE1DA0384.additionalIncludes

//## begin module%661FE1DA0384.includes preserve=yes
//## end module%661FE1DA0384.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSUS21_h
#include "CXODUS21.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSBC25_h
#include "CXODBC25.hpp"
#endif
#ifndef CXOSMZ27_h
#include "CXODMZ27.hpp"
#endif


//## begin module%661FE1DA0384.declarations preserve=no
//## end module%661FE1DA0384.declarations

//## begin module%661FE1DA0384.additionalDeclarations preserve=yes
//## end module%661FE1DA0384.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::SettlementFolder 

SettlementFolder::SettlementFolder()
  //## begin SettlementFolder::SettlementFolder%661FE17700A0_const.hasinit preserve=no
      : m_pEmail(0)
  //## end SettlementFolder::SettlementFolder%661FE17700A0_const.hasinit
  //## begin SettlementFolder::SettlementFolder%661FE17700A0_const.initialization preserve=yes
  //## end SettlementFolder::SettlementFolder%661FE17700A0_const.initialization
{
  //## begin metaoperator::SettlementFolder::SettlementFolder%661FE17700A0_const.body preserve=yes
   memcpy(m_sID,"MZ27",4);
   for (int i = 0;i < 5;++i)
      for (int j = 0;j < 7;++j)
         m_dAMT_RECON_NET[i][j] = 0;
   m_hColumnA[101] = "Purchase";
   m_hColumnA[102] = "Purchase Reversal";
   m_hColumnA[111] = "Return";
   m_hColumnA[112] = "Return Reversal";
   m_hColumnA[121] = "Cash Advance";
   m_hColumnA[122] = "Cash Reversal";
   m_hColumnA[131] = "Quasi Cash";
   m_hColumnA[132] = "Quasi Cash Reversal";
   m_hColumnA[191] = "Other";
   m_hColumnA[192] = "Other Reversal";
   m_hColumnA[197] = "Pre-Edit Reject";
   m_hColumnA[198] = "New Suspense";
   m_hColumnA[199] = "Return Current";
   m_hColumnA[201] = "Interchange Fee";
   m_hColumnA[401] = "Chargeback";
   m_hColumnA[402] = "Chargeback Reversal";
   m_hColumnA[411] = "Representment";
   m_hColumnA[412] = "Representment Reversal";
   m_hColumnA[421] = "Prearbitration";
   m_hColumnA[431] = "Arbitration";
   m_hColumnA[432] = "Arbitration Reversal";
   m_hColumnA[441] = "Debit Adjustment";
   m_hColumnA[451] = "Credit Adjustment";
   m_hColumnA[501] = "Fee Collection";
   m_hColumnA[502] = "Fee Collection Return";
   m_hColumnA[511] = "Network Charges";
   m_hColumnA[601] = "Funds Disbursement";
   m_hColumnA[698] = "Cleared Suspense";
   m_hColumnA[699] = "Return Suspense";
   m_hColumnA[891] = "** Transaction";
   m_hColumnA[892] = "** Interchange fee";
   m_hColumnA[893] = "** Fee collection";
   m_hColumnA[901] = "** Deposit";
   m_iROW_NUMBER[0] = 0;
   m_iROW_NUMBER[1] = 0;
  //## end metaoperator::SettlementFolder::SettlementFolder%661FE17700A0_const.body
}


SettlementFolder::~SettlementFolder()
{
  //## begin metaoperator::SettlementFolder::~SettlementFolder%661FE17700A0_dest.body preserve=yes
  //## end metaoperator::SettlementFolder::~SettlementFolder%661FE17700A0_dest.body
}



//## Other Operations (implementation)
bool SettlementFolder::report (command::Email* pEmail)
{
  //## begin metaoperator::SettlementFolder::report%661FE2AB036C.body preserve=yes
   m_pEmail = pEmail;
   m_strPROC_ID[0].erase();
   m_strINST_ID[0].erase();
   Query hQuery;
   hQuery.attach(this);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   for (int i = 0;i < 2;++i)
   {
      usersegment::EmailSegment::instance()->setField("DATE",entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(i));
      m_pEmail->report('M');
      hQuery.reset();
      hQuery.join("PROCESSOR","INNER","INSTITUTION","PROC_ID");
      hQuery.join("INSTITUTION","LEFT OUTER","T_RECON_TOTAL","INST_ID");
      hQuery.join(0,"LEFT OUTER","T_RECON_TOTAL",entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(i).c_str(),"DATE_RECON_ISS");
      hQuery.setQualifier("QUALIFY","PROCESSOR");
      hQuery.setQualifier("QUALIFY","INSTITUTION");
      hQuery.bind("INSTITUTION","PROC_ID",Column::STRING,&m_strPROC_ID[1]);
      hQuery.bind("INSTITUTION","INST_ID",Column::STRING,&m_strINST_ID[1]);
      hQuery.bind("T_RECON_TOTAL","ENTITY_ROLE",Column::STRING,&m_strENTITY_ROLE);
      hQuery.bind("T_RECON_TOTAL","ROW_NUMBER",Column::LONG,&m_iROW_NUMBER[1]);
      hQuery.bind("T_RECON_TOTAL","REPORT_NAME",Column::STRING,&m_strREPORT_NAME);
      hQuery.bind("T_RECON_TOTAL","IMPACT_TO_ACQ",Column::STRING,&m_strIMPACT_TO_ACQ);
      hQuery.bind("T_RECON_TOTAL","AMT_RECON_NET",Column::DOUBLE,&m_dAMT_RECON_NET[0][6]);
      hQuery.setBasicPredicate("PROCESSOR","PROC_GRP_ID","<>","FIS");
      hQuery.setBasicPredicate("PROCESSOR","CC_CHANGE_GRP_ID","IS NULL");
      hQuery.setBasicPredicate("PROCESSOR","CC_STATE","=","A");
      hQuery.setBasicPredicate("INSTITUTION","CC_CHANGE_GRP_ID","IS NULL");
      hQuery.setBasicPredicate("INSTITUTION","CC_STATE","=","A");
      hQuery.setBasicPredicate("T_RECON_TOTAL","REPORT_SOURCE","=","N");
      hQuery.setBasicPredicate("T_RECON_TOTAL","AMT_RECON_NET","<>","0",true);
      hQuery.setGroupByClause("PROC_ID,INST_ID,ENTITY_ROLE,ROW_NUMBER,REPORT_NAME,IMPACT_TO_ACQ");
      hQuery.setOrderByClause("PROC_ID,INST_ID,ROW_NUMBER");
      if (!pSelectStatement->execute(hQuery))
         return false;
      if (pSelectStatement->getRows() > 0)
         report();
   }
   return true;
  //## end metaoperator::SettlementFolder::report%661FE2AB036C.body
}

bool SettlementFolder::report ()
{
  //## begin metaoperator::SettlementFolder::report%661FE2AE0345.body preserve=yes
   if (m_iROW_NUMBER[0] > 890)
   {
      int i = DEPOSIT;
      switch (m_iROW_NUMBER[0])
      {
         case 891:
            i = TRANSACTION;
            break;
         case 892:
            i = INTERCHANGE_FEE;
            break;
         case 893:
            i = FEE_COLLECTION;
            break;
      }
      for (int j = 0;j < 4;++j)
         m_dAMT_RECON_NET[0][j] += m_dAMT_RECON_NET[i][j];
   }
   usersegment::EmailSegment::instance()->setField("CATEGORY",m_hColumnA[m_iROW_NUMBER[0]]);
   char pszTemp[7] = {"012345"};
   char pszName[15] = {"AMT_RECON_NET0"};
   char szTemp[PERCENTF];
   for (int i = 0;i < 6;++i)
   {
      if (m_iROW_NUMBER[0] == 201
         && i < 2)
         snprintf(szTemp,PERCENTF,"%18.6f",m_dAMT_RECON_NET[0][i] / 1000000);
      else
         snprintf(szTemp,PERCENTF,"%18.2f",m_dAMT_RECON_NET[0][i] / 100);
      pszName[13] = pszTemp[i];
      usersegment::EmailSegment::instance()->setField(pszName,szTemp);
   }
   usersegment::EmailSegment::instance()->setField("Status","");
   if (m_iROW_NUMBER[0] < 201
      || (m_iROW_NUMBER[0] >= 400
      && m_iROW_NUMBER[0] < 500))
      usersegment::EmailSegment::instance()->setField("Status",
         m_dAMT_RECON_NET[0][0] == m_dAMT_RECON_NET[0][2]
         && m_dAMT_RECON_NET[0][1] == m_dAMT_RECON_NET[0][3]
         ? "OK" : "WARNING");
   if (m_iROW_NUMBER[0] == 891)
      usersegment::EmailSegment::instance()->setField("Status",
         m_dAMT_RECON_NET[0][0] == m_dAMT_RECON_NET[0][2]
         && m_dAMT_RECON_NET[0][1] == m_dAMT_RECON_NET[0][3]
         && m_dAMT_RECON_NET[0][0] == m_dAMT_RECON_NET[0][4]
         && m_dAMT_RECON_NET[0][1] == m_dAMT_RECON_NET[0][5]
         ? "OK" : "WARNING");
   if (m_iROW_NUMBER[0] == 892)
      usersegment::EmailSegment::instance()->setField("Status",
         m_dAMT_RECON_NET[0][2] == m_dAMT_RECON_NET[0][4]
         && m_dAMT_RECON_NET[0][3] == m_dAMT_RECON_NET[0][5]
         ? "OK" : "WARNING");
   return m_pEmail->report(m_iROW_NUMBER[0] == 901 ? 'O' : 'N');
  //## end metaoperator::SettlementFolder::report%661FE2AE0345.body
}

void SettlementFolder::update (Subject* pSubject)
{
  //## begin metaoperator::SettlementFolder::update%661FE29301F1.body preserve=yes
   if (m_strPROC_ID[0] != m_strPROC_ID[1]
      || m_strINST_ID[0] != m_strINST_ID[1]
      || m_iROW_NUMBER[0] != m_iROW_NUMBER[1])
   {
      if (!m_strPROC_ID[0].empty())
         report();
      for (int j = 0;j < 6;++j)
         m_dAMT_RECON_NET[0][j] = 0;
      if (m_strPROC_ID[0] != m_strPROC_ID[1]
         || m_strINST_ID[0] != m_strINST_ID[1])
         for (int i = TRANSACTION;i <= DEPOSIT;++i)
            for (int j = 0;j < 7;++j)
               m_dAMT_RECON_NET[i][j] = 0;
      m_strPROC_ID[0] = m_strPROC_ID[1];
      m_strINST_ID[0] = m_strINST_ID[1];
      m_iROW_NUMBER[0] = m_iROW_NUMBER[1];
      usersegment::EmailSegment::instance()->setField("PROC_ID",m_strPROC_ID[1]);
      usersegment::EmailSegment::instance()->setField("INST_ID",m_strINST_ID[1]);
   }
   int i = 2;
   if (m_strREPORT_NAME == "BASEII"
      || m_strREPORT_NAME == "IP755120"
      || m_strREPORT_NAME == "TX-100-01"
      || m_strREPORT_NAME == "GCMSCASE")
      i = 0;
   else
   if (m_iROW_NUMBER[1] == 511
      || m_iROW_NUMBER[1] > 890)
      i = 4;
   if (m_strIMPACT_TO_ACQ == "1")
      ++i;
   m_dAMT_RECON_NET[0][i] += m_dAMT_RECON_NET[0][6];
   if (m_iROW_NUMBER[1] < 201
      || (m_iROW_NUMBER[1] >= 400
      && m_iROW_NUMBER[1] < 500))
      m_dAMT_RECON_NET[TRANSACTION][i] += m_dAMT_RECON_NET[0][6];
   else
   if (m_iROW_NUMBER[1] == 201)
   {
      if (i < 2)
         m_dAMT_RECON_NET[INTERCHANGE_FEE][i] += m_dAMT_RECON_NET[0][6] / 10000;
      else
         m_dAMT_RECON_NET[INTERCHANGE_FEE][i] += m_dAMT_RECON_NET[0][6];
   }
   else
   if (m_iROW_NUMBER[1] == 501)
      m_dAMT_RECON_NET[FEE_COLLECTION][i] += m_dAMT_RECON_NET[0][6];
   if (m_iROW_NUMBER[1] == 201
      && i < 2)
      m_dAMT_RECON_NET[DEPOSIT][i] += m_dAMT_RECON_NET[0][6] / 10000;
   else
      m_dAMT_RECON_NET[DEPOSIT][i] += m_dAMT_RECON_NET[0][6];
  //## end metaoperator::SettlementFolder::update%661FE29301F1.body
}

// Additional Declarations
  //## begin metaoperator::SettlementFolder%661FE17700A0.declarations preserve=yes
  //## end metaoperator::SettlementFolder%661FE17700A0.declarations

} // namespace metaoperator

//## begin module%661FE1DA0384.epilog preserve=yes
//## end module%661FE1DA0384.epilog
