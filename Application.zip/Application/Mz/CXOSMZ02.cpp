//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6234D76A019C.cm preserve=no
//## end module%6234D76A019C.cm

//## begin module%6234D76A019C.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6234D76A019C.cp

//## Module: CXOSMZ02%6234D76A019C; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ02.cpp

//## begin module%6234D76A019C.additionalIncludes preserve=no
//## end module%6234D76A019C.additionalIncludes

//## begin module%6234D76A019C.includes preserve=yes
#include <sstream>
//## end module%6234D76A019C.includes

#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSMZ02_h
#include "CXODMZ02.hpp"
#endif


//## begin module%6234D76A019C.declarations preserve=no
//## end module%6234D76A019C.declarations

//## begin module%6234D76A019C.additionalDeclarations preserve=yes
//## end module%6234D76A019C.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::Condition 

//## begin metaoperator::Condition::Match%65B2AB6A02C7.attr preserve=no  private: static multimap<string,pair<string,bool>,less<string> >* {V} 0
multimap<string,pair<string,bool>,less<string> >* Condition::m_pMatch = 0;
//## end metaoperator::Condition::Match%65B2AB6A02C7.attr

//## begin metaoperator::Condition::Value%6234CB500115.attr preserve=no  private: static map<string,string,less<string> >* {V} 0
map<string,string,less<string> >* Condition::m_pValue = 0;
//## end metaoperator::Condition::Value%6234CB500115.attr

Condition::Condition()
  //## begin Condition::Condition%6234A6FA033D_const.hasinit preserve=no
  //## end Condition::Condition%6234A6FA033D_const.hasinit
  //## begin Condition::Condition%6234A6FA033D_const.initialization preserve=yes
  //## end Condition::Condition%6234A6FA033D_const.initialization
{
  //## begin metaoperator::Condition::Condition%6234A6FA033D_const.body preserve=yes
   memcpy(m_sID,"MZ02",4);
  //## end metaoperator::Condition::Condition%6234A6FA033D_const.body
}


Condition::~Condition()
{
  //## begin metaoperator::Condition::~Condition%6234A6FA033D_dest.body preserve=yes
  //## end metaoperator::Condition::~Condition%6234A6FA033D_dest.body
}



//## Other Operations (implementation)
void Condition::addMatch (const reusable::string& strFirst, const reusable::string& strSecond)
{
  //## begin metaoperator::Condition::addMatch%65B2ABC4028B.body preserve=yes
   if (!m_pMatch)
      m_pMatch = new multimap<string,pair<string,bool>,less<string> >;
   m_pMatch->insert(multimap<string,pair<string,bool>,less<string> >::value_type(strFirst,make_pair(strSecond,false)));
  //## end metaoperator::Condition::addMatch%65B2ABC4028B.body
}

void Condition::clear (const reusable::string& strFirst)
{
  //## begin metaoperator::Condition::clear%65B2DFBC0288.body preserve=yes
   if (!m_pMatch)
      return;
   string strEmpty;
   Condition::setValue(strFirst,strEmpty);
   pair<multimap<string,pair<string,bool>,less<string> >::iterator,multimap<string,pair<string,bool>,less<string> >::iterator> hRange = m_pMatch->equal_range(strFirst);
   multimap<string,pair<string,bool>,less<string> >::iterator pRange;
   for (pRange = hRange.first;pRange != hRange.second;++pRange)
      (*pRange).second.second = false;
  //## end metaoperator::Condition::clear%65B2DFBC0288.body
}

bool Condition::getValue (const reusable::string& strKey, reusable::string& strValue)
{
  //## begin metaoperator::Condition::getValue%634874DB0361.body preserve=yes
   if (strKey == "''")
   {
      strValue.erase();
      return true;
   }
   vector<string> hTokens;
   map<string,string,less<string> >::iterator p;
   if (Buffer::parse(strKey," +-",hTokens) > 1)
   {
      p = m_pValue->find(hTokens[0]);
      if (p == m_pValue->end())
         return false;
      Date hDate((*p).second.data());
      hDate = (strKey.find("+",hTokens[0].length(),1) != string::npos) ? hDate + atoi(hTokens[1].data()) : hDate - atoi(hTokens[1].data());
      strValue.assign(hDate.asString("%Y%m%d"));
      return true;
   }
   p = m_pValue->find(strKey);
   if (p == m_pValue->end())
   {
      if (strKey.substr(0,2) == "@@")
      {
         strValue.erase();
         return true;
      }
      return false;
   }
   strValue.assign((*p).second);
   return true;
  //## end metaoperator::Condition::getValue%634874DB0361.body
}

bool Condition::match (const reusable::string& strFirst, const reusable::string& strSecond)
{
  //## begin metaoperator::Condition::match%65B2D5AD0034.body preserve=yes
   if (!m_pMatch)
      return false;
   pair<multimap<string,pair<string,bool>,less<string> >::iterator,multimap<string,pair<string,bool>,less<string> >::iterator> hRange = m_pMatch->equal_range(strFirst);
   multimap<string,pair<string,bool>,less<string> >::iterator pRange;
   for (pRange = hRange.first;pRange != hRange.second;++pRange)
   {
      if ((*pRange).second.first == strSecond)
         return (*pRange).second.second;
   }
   return false;
  //## end metaoperator::Condition::match%65B2D5AD0034.body
}

void Condition::setMatch (const reusable::string& strFirst, const reusable::string& strBuffer)
{
  //## begin metaoperator::Condition::setMatch%65B2C8C90055.body preserve=yes
   if (!m_pMatch)
      return;
   pair<multimap<string,pair<string,bool>,less<string> >::iterator,multimap<string,pair<string,bool>,less<string> >::iterator> hRange = m_pMatch->equal_range(strFirst);
   multimap<string,pair<string,bool>,less<string> >::iterator pRange;
   for (pRange = hRange.first;pRange != hRange.second;++pRange)
   {
      if ((*pRange).second.second == false
         && (*pRange).second.first.length() <= strBuffer.length())
      {
         bool b = true;
         for (int i = 0;i < (*pRange).second.first.length();++i)
            if ((*pRange).second.first[i] != '_'
               && (*pRange).second.first[i] != strBuffer[i])
            {
               b = false;
               break;
            }
         (*pRange).second.second = b;
      }
   }
  //## end metaoperator::Condition::setMatch%65B2C8C90055.body
}

void Condition::setToken (const vector<string>& hToken)
{
  //## begin metaoperator::Condition::setToken%63B481D70114.body preserve=yes
   m_hToken = hToken;
  //## end metaoperator::Condition::setToken%63B481D70114.body
}

void Condition::setValue (const reusable::string& strFirst, const reusable::string& strSecond)
{
  //## begin metaoperator::Condition::setValue%6234CB800155.body preserve=yes
   if (!m_pValue)
      m_pValue = new map<string,string,less<string> >;
   map<string,string,less<string> >::iterator pValue = m_pValue->find(strFirst);
   if (pValue == m_pValue->end())
      m_pValue->insert(map<string,string>::value_type(strFirst,strSecond));
   else
      (*pValue).second = strSecond;
  //## end metaoperator::Condition::setValue%6234CB800155.body
}

void Condition::substitute (reusable::string& strValue)
{
  //## begin metaoperator::Condition::substitute%6348750803E6.body preserve=yes
   string strTemp;
   while (strValue.find("@") != string::npos)
   {
      vector<string> hTokens;
      Buffer::parse(strValue,"\\/~",hTokens);
      for (int i = 0;i < hTokens.size();i++)
      {
         if (hTokens[i][0] == '@')
         {

            if (Condition::getValue(hTokens[i],strTemp))
            {
               if (strTemp[0] == '2')
               {
                  strTemp.insert(6,"-");
                  strTemp.insert(4,"-");
               }
               strValue.replace(strValue.find(hTokens[i]),hTokens[i].length(),strTemp.data(),strTemp.length());
            }
            else
               return;
         }
      }
   }
  //## end metaoperator::Condition::substitute%6348750803E6.body
}

bool Condition::test ()
{
  //## begin metaoperator::Condition::test%6234A78500E5.body preserve=yes
   return true;
  //## end metaoperator::Condition::test%6234A78500E5.body
}

// Additional Declarations
  //## begin metaoperator::Condition%6234A6FA033D.declarations preserve=yes
  //## end metaoperator::Condition%6234A6FA033D.declarations

} // namespace metaoperator

//## begin module%6234D76A019C.epilog preserve=yes
//## end module%6234D76A019C.epilog
