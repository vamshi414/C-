//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6234D6B0038B.cm preserve=no
//## end module%6234D6B0038B.cm

//## begin module%6234D6B0038B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6234D6B0038B.cp

//## Module: CXOPMZ00%6234D6B0038B; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOPMZ00.cpp

//## begin module%6234D6B0038B.additionalIncludes preserve=no
//## end module%6234D6B0038B.additionalIncludes

//## begin module%6234D6B0038B.includes preserve=yes
//## end module%6234D6B0038B.includes

#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMZ02_h
#include "CXODMZ02.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
#ifndef CXOSMZ28_h
#include "CXODMZ28.hpp"
#endif
#ifndef CXOSNS44_h
#include "CXODNS44.hpp"
#endif
#ifndef CXOPMZ00_h
#include "CXODMZ00.hpp"
#endif


//## begin module%6234D6B0038B.declarations preserve=no
//## end module%6234D6B0038B.declarations

//## begin module%6234D6B0038B.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new metaoperator::MetaOperator();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%6234D6B0038B.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::MetaOperator 

//## begin metaoperator::MetaOperator::GlobalContext%6373EDA50075.attr preserve=no  private: static map<reusable::string, database::GlobalContext *, less<reusable::string> >* {V} 0
map<reusable::string, database::GlobalContext *, less<reusable::string> >* MetaOperator::m_pGlobalContext = 0;
//## end metaoperator::MetaOperator::GlobalContext%6373EDA50075.attr

MetaOperator::MetaOperator()
  //## begin MetaOperator::MetaOperator%6234A650019D_const.hasinit preserve=no
  //## end MetaOperator::MetaOperator%6234A650019D_const.hasinit
  //## begin MetaOperator::MetaOperator%6234A650019D_const.initialization preserve=yes
  //## end MetaOperator::MetaOperator%6234A650019D_const.initialization
{
  //## begin metaoperator::MetaOperator::MetaOperator%6234A650019D_const.body preserve=yes
   memcpy(m_sID,"MZ00",4);
  //## end metaoperator::MetaOperator::MetaOperator%6234A650019D_const.body
}


MetaOperator::~MetaOperator()
{
  //## begin metaoperator::MetaOperator::~MetaOperator%6234A650019D_dest.body preserve=yes
  //## end metaoperator::MetaOperator::~MetaOperator%6234A650019D_dest.body
}



//## Other Operations (implementation)
void MetaOperator::generate (const vector<string>& hMacro, const vector<string>& hVariables, vector<string>& hDX_FILE_TYPE)
{
  //## begin metaoperator::MetaOperator::generate%66AAFB6303AA.body preserve=yes
   string strBuffer;
   for (int i = 0;i < hMacro.size();++i)
   {
      strBuffer = hMacro[i];
      char* pszKey[9] = {"%1","%2","%3","%4","%5","%6","%7","%8","%9"};
      for (int j = 1;j < hVariables.size();++j)
      {
         size_t pos = strBuffer.find(pszKey[j - 1]);
         if (pos != string::npos)
            strBuffer.replace(pos,2,hVariables[j]);
      }
      size_t pos = string::npos;
      if (hVariables.size() > 2
         && hVariables[2] == "INSTITUTION"
         && (pos = strBuffer.find("INSTITUTION")) != string::npos)
      {
         string strTemp(strBuffer);
         pair<multimap<string,string,less<string> >::const_iterator,multimap<string,string,less<string> >::const_iterator> hRange =
            entitysegment::Processor::instance()->getInstitution().equal_range(hVariables[1]);
         for (multimap<string,string,less<string> >::const_iterator pRange = hRange.first;pRange != hRange.second;++pRange)
         {
            strBuffer.replace(pos,11,(*pRange).second);
            parse(strBuffer,hDX_FILE_TYPE);
            strBuffer = strTemp;
         }
      }
      else
         parse(strBuffer,hDX_FILE_TYPE);
   }
  //## end metaoperator::MetaOperator::generate%66AAFB6303AA.body
}

int MetaOperator::initialize ()
{
  //## begin metaoperator::MetaOperator::initialize%6234A6830366.body preserve=yes
   new dnplatform::DNPlatform();
   new segment::AuditEvent;
   int iRC = Application::initialize();
   UseCase hUseCase("LOG","## MZ00 START MZ");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   entitysegment::SwitchBusinessDay::instance();
   entitysegment::Processor::instance();
   Database::instance()->connect();
#ifdef MVS
   FlatFile hTemplate("JCL","DNDNMZ01");
#else
   FlatFile hTemplateFile("SOURCE","CXOXMZ01");
#endif
   if (!hTemplateFile.open())
      return -1;
   char* psBuffer = new char[256];
   memset(psBuffer,' ',256);
   size_t m = 0;
   string strBuffer;
   string strTemp(IF::Extract::instance()->getNode001());
#ifdef _WIN32
   strTemp.append("\\",1);
#else
   strTemp.append("/",1);
#endif
   strTemp += IF::Extract::instance()->getCustomerQualifier();
#ifdef _WIN32
   strTemp.append("\\",1);
#else
   strTemp.append("/",1);
#endif
   Condition::setValue("@TEMP",strTemp);
   vector<string> hDX_FILE_TYPE;
   vector<string> hMacro;
   bool bClear = false;
   m_hRule.reserve(256);
   while (hTemplateFile.read(psBuffer,256,&m))
   {
      if (psBuffer[0] == '*'
         || psBuffer[0] == '&')
         continue;
      strBuffer.assign(psBuffer,m);
#ifdef _WIN32
      std::replace(strBuffer.begin(),strBuffer.end(),'/','\\');
#else
      std::replace(strBuffer.begin(),strBuffer.end(),'\\','/');
#endif
      if (strBuffer[0] == 'M')
      {
         if (bClear)
            hMacro.clear();
         hMacro.push_back(strBuffer.substr(1));
         bClear = false;
      }
      else
      if (strBuffer[0] == 'G')
      {
         bClear = true;
         vector<string> hVariables;
         Buffer::parse(strBuffer," ",hVariables);
         generate(hMacro,hVariables,hDX_FILE_TYPE);
      }
      else
         parse(strBuffer,hDX_FILE_TYPE);
   }
   Database::instance()->commit();
   MinuteTimer::instance()->attach(this);
   m_hStatusEmail.update(0);
   return 0;
  //## end metaoperator::MetaOperator::initialize%6234A6830366.body
}

int MetaOperator::onReset (Message& hMessage)
{
  //## begin metaoperator::MetaOperator::onReset%6373DAAE023A.body preserve=yes
   if (hMessage.context() == "EMAIL")
   {
      m_hStatusEmail.send();
      return 0;  
   }
   for (int i = 0;i < m_hRule.size();++i)
      if (m_hRule[i].getName() == hMessage.context())
      {
         m_hRule[i].check(); // to set values
         m_hRule[i].execute();
         break;
      }
   return 0;
  //## end metaoperator::MetaOperator::onReset%6373DAAE023A.body
}

void MetaOperator::parse (const string& strBuffer, vector<string>& hDX_FILE_TYPE)
{
  //## begin metaoperator::MetaOperator::parse%66AA54FE0085.body preserve=yes
   string strTemp("PARSE: ");
   strTemp += strBuffer;
   IF::Trace::put(strTemp.data(),strTemp.length());
   if (strBuffer[0] == 'I')
   {
      if (!m_pGlobalContext)
         m_pGlobalContext = new map<string,GlobalContext*,less<string> >;
      vector<string> hTokens;
      if (Buffer::parse(strBuffer," ",hTokens) < 2)
         return;
      GlobalContext* pGlobalContext = new GlobalContext((hTokens[1]).c_str() + 1);
      m_pGlobalContext->insert(map<string,GlobalContext*,less<string> >::value_type(hTokens[1],pGlobalContext));
      if (hTokens.size() > 3
         && hTokens[2] == "="
         && pGlobalContext->get(m_strCONTEXT_DATA)
         && m_strCONTEXT_DATA.empty())
      {
         map<string,GlobalContext*,less<string> >::iterator p = m_pGlobalContext->find(hTokens[3]);
         if (p != m_pGlobalContext->end()
            && (*p).second->get(m_strCONTEXT_DATA))
         {
            if (hTokens.size() == 4)
               pGlobalContext->put(m_strCONTEXT_DATA.data());
            else
            if (hTokens.size() == 6
               && hTokens[4] == "-")
            {
               GlobalContext* p = new GlobalContext((hTokens[3]).c_str() + 1);
               p->get(m_strCONTEXT_DATA);
               Date hDate(m_strCONTEXT_DATA.c_str());
               hDate -= atoi(hTokens[5].c_str());
               m_strCONTEXT_DATA.assign(hDate.asString("%Y%m%d"));
               pGlobalContext->put(m_strCONTEXT_DATA.data());
            }
         }
      }
   }
   else
   if (strBuffer[0] == 'D')
   {
      vector<string> hTokens;
      if (Buffer::parse(strBuffer," ",hTokens) >= 3)
         Condition::setValue(hTokens[1],hTokens[3]);
   }
   else
   if (strBuffer[0] == 'X')
   {
      hDX_FILE_TYPE.clear();
      Buffer::parse(strBuffer.substr(2)," ",hDX_FILE_TYPE);
   }
   else
   if (strBuffer[0] == 'E')
   {
      vector<string> hTokens;
      if (Buffer::parse(strBuffer," ",hTokens) == 4
         && hTokens[3] == "INSTITUTION")
      {
         string strTemp;
         pair<multimap<string,string,less<string> >::const_iterator,multimap<string,string,less<string> >::const_iterator> hRange =
            entitysegment::Processor::instance()->getInstitution().equal_range(hTokens[2]);
         for (multimap<string,string,less<string> >::const_iterator pRange = hRange.first;pRange != hRange.second;++pRange)
         {
            strTemp.assign("E ");
            strTemp.append(hTokens[1]);
            strTemp.append(" ",1);
            strTemp.append((*pRange).second);
            ExportFileFolder::instance()->add(strTemp,hDX_FILE_TYPE);
         }
      }
      else
         ExportFileFolder::instance()->add(strBuffer,hDX_FILE_TYPE);
   }
   else
   if (strBuffer[0] == 'R')
   {
      Rule hRule(strBuffer.data() + 2);
      m_hRule.push_back(hRule);
   }
   else
   if ((strBuffer[0] == 'C'
      || strBuffer[0] == 'F')
      && m_hRule.size() > 0)
      m_hRule[m_hRule.size() - 1].add(strBuffer);
  //## end metaoperator::MetaOperator::parse%66AA54FE0085.body
}

bool MetaOperator::put (const string& strCONTEXT_KEY, const char* pszCONTEXT_DATA)
{
  //## begin metaoperator::MetaOperator::put%6373DBB7016F.body preserve=yes
   map<string,GlobalContext*,less<string> >::iterator p = m_pGlobalContext->find(strCONTEXT_KEY);
   if (p != m_pGlobalContext->end()
      && (*p).second->put(pszCONTEXT_DATA))
   {
      Database::instance()->commit();
      return true;
   }
   return false;
  //## end metaoperator::MetaOperator::put%6373DBB7016F.body
}

void MetaOperator::update (Subject* pSubject)
{
  //## begin metaoperator::MetaOperator::update%6234A68B01AE.body preserve=yes
   if (pSubject == MinuteTimer::instance())
   {
      if (m_pGlobalContext)
         for (map<string,GlobalContext*,less<string> >::iterator p = m_pGlobalContext->begin();p!=m_pGlobalContext->end();p++)
         {
            if ((*p).first.substr(0,2) != "@@")
            {
               (*p).second->get(m_strCONTEXT_DATA);
               Condition::setValue((*p).first,m_strCONTEXT_DATA);
            }
         }
      bool b = true;
      while (b)
      {
         b = false;
         entitysegment::SwitchBusinessDay::instance()->update(timer::MidnightAlarm::instance());
         for (vector<Rule>::iterator pRule = m_hRule.begin();pRule != m_hRule.end();pRule++)
            if ((*pRule).check())
            {
               (*pRule).execute();
               b = true;;
               break;
            }
         IF::Sleep::goTo("00000100");
      }
   }
   Application::update(pSubject);
  //## end metaoperator::MetaOperator::update%6234A68B01AE.body
}

// Additional Declarations
  //## begin metaoperator::MetaOperator%6234A650019D.declarations preserve=yes
  //## end metaoperator::MetaOperator%6234A650019D.declarations

} // namespace metaoperator

//## begin module%6234D6B0038B.epilog preserve=yes
//## end module%6234D6B0038B.epilog
