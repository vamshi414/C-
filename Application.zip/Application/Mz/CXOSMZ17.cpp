//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B4674A00C2.cm preserve=no
//## end module%63B4674A00C2.cm

//## begin module%63B4674A00C2.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B4674A00C2.cp

//## Module: CXOSMZ17%63B4674A00C2; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ17.cpp

//## begin module%63B4674A00C2.additionalIncludes preserve=no
//## end module%63B4674A00C2.additionalIncludes

//## begin module%63B4674A00C2.includes preserve=yes
//## end module%63B4674A00C2.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSMZ17_h
#include "CXODMZ17.hpp"
#endif


//## begin module%63B4674A00C2.declarations preserve=no
//## end module%63B4674A00C2.declarations

//## begin module%63B4674A00C2.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Condition* createReport()
   {
      return new metaoperator::Report();
   }
   const bool registered = metaoperator::ConditionFactory::instance()->registerCondition("Report",createReport);
}
#include "CXODTM06.hpp"
//## end module%63B4674A00C2.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::Report 

Report::Report()
  //## begin Report::Report%63B464B00009_const.hasinit preserve=no
  //## end Report::Report%63B464B00009_const.hasinit
  //## begin Report::Report%63B464B00009_const.initialization preserve=yes
  //## end Report::Report%63B464B00009_const.initialization
{
  //## begin metaoperator::Report::Report%63B464B00009_const.body preserve=yes
   memcpy(m_sID,"MZ17",4);
  //## end metaoperator::Report::Report%63B464B00009_const.body
}


Report::~Report()
{
  //## begin metaoperator::Report::~Report%63B464B00009_dest.body preserve=yes
  //## end metaoperator::Report::~Report%63B464B00009_dest.body
}



//## Other Operations (implementation)
bool Report::test ()
{
  //## begin metaoperator::Report::test%63B464C501EC.body preserve=yes
   if (m_hToken.size() != 3
      && m_hToken.size() != 5)
      return false;
   int iCount = 0;
   string strCONTEXT_DATA;
   string strCONTEXT_KEY("@");
   strCONTEXT_KEY += m_hToken[2];
   getValue(strCONTEXT_KEY,strCONTEXT_DATA);
   if (strCONTEXT_DATA.length() > 0)
   {
      Date hDate(strCONTEXT_DATA.c_str());
      hDate += 1;
      strCONTEXT_DATA.assign(hDate.asString("%Y%m%d"));
   }
   else
      Condition::getValue("@CLOSED",strCONTEXT_DATA);
   Query hQuery;
   hQuery.bind("DX_DATA_CONTROL","*",Column::LONG,&iCount,0,"COUNT");
   hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","=",m_hToken[2].c_str());
   if (m_hToken.size() > 3
      && atoi(m_hToken[3].c_str()) > 0 )
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_REPORT_ID","=",atoi(m_hToken[3].c_str()));
   hQuery.setBasicPredicate("DX_DATA_CONTROL","DATE_RECON","=",strCONTEXT_DATA.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_STATE","<>","DC");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(hQuery) == false
      || iCount > 0)
      return false;
   Condition::setValue("DX_FILE_TYPE",m_hToken[m_hToken.size() == 5 ? 4 : 2]);
   Condition::setValue("DATE_RECON",strCONTEXT_DATA);
   return true;
  //## end metaoperator::Report::test%63B464C501EC.body
}

// Additional Declarations
  //## begin metaoperator::Report%63B464B00009.declarations preserve=yes
  //## end metaoperator::Report%63B464B00009.declarations

} // namespace metaoperator

//## begin module%63B4674A00C2.epilog preserve=yes
//## end module%63B4674A00C2.epilog


// Detached code regions:
