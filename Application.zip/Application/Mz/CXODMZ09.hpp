//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6392A030011D.cm preserve=no
//## end module%6392A030011D.cm

//## begin module%6392A030011D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6392A030011D.cp

//## Module: CXOSMZ09%6392A030011D; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ09.hpp

#ifndef CXOSMZ09_h
#define CXOSMZ09_h 1

//## begin module%6392A030011D.additionalIncludes preserve=no
//## end module%6392A030011D.additionalIncludes

//## begin module%6392A030011D.includes preserve=yes
//## end module%6392A030011D.includes

#ifndef CXOSMZ03_h
#include "CXODMZ03.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CommandMessage;
} // namespace IF

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%6392A030011D.declarations preserve=no
//## end module%6392A030011D.declarations

//## begin module%6392A030011D.additionalDeclarations preserve=yes
//## end module%6392A030011D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::BusinessDayClose%63929FAA000D.preface preserve=yes
//## end metaoperator::BusinessDayClose%63929FAA000D.preface

//## Class: BusinessDayClose%63929FAA000D
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6392A005009B;IF::CommandMessage { -> F}
//## Uses: <unnamed>%6392A10102A4;process::Application { -> F}

class DllExport BusinessDayClose : public Function  //## Inherits: <unnamed>%63929FBA02FC
{
  //## begin metaoperator::BusinessDayClose%63929FAA000D.initialDeclarations preserve=yes
  //## end metaoperator::BusinessDayClose%63929FAA000D.initialDeclarations

  public:
    //## Constructors (generated)
      BusinessDayClose();

    //## Destructor (generated)
      virtual ~BusinessDayClose();


    //## Other Operations (specified)
      //## Operation: execute%63929FCE0113
      virtual int execute ();

    // Additional Public Declarations
      //## begin metaoperator::BusinessDayClose%63929FAA000D.public preserve=yes
      //## end metaoperator::BusinessDayClose%63929FAA000D.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::BusinessDayClose%63929FAA000D.protected preserve=yes
      //## end metaoperator::BusinessDayClose%63929FAA000D.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::BusinessDayClose%63929FAA000D.private preserve=yes
      //## end metaoperator::BusinessDayClose%63929FAA000D.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin metaoperator::BusinessDayClose%63929FAA000D.implementation preserve=yes
      //## end metaoperator::BusinessDayClose%63929FAA000D.implementation

};

//## begin metaoperator::BusinessDayClose%63929FAA000D.postscript preserve=yes
//## end metaoperator::BusinessDayClose%63929FAA000D.postscript

} // namespace metaoperator

//## begin module%6392A030011D.epilog preserve=yes
//## end module%6392A030011D.epilog


#endif
