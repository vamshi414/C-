//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%661FE1D800FF.cm preserve=no
//## end module%661FE1D800FF.cm

//## begin module%661FE1D800FF.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%661FE1D800FF.cp

//## Module: CXOSMZ27%661FE1D800FF; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ27.hpp

#ifndef CXOSMZ27_h
#define CXOSMZ27_h 1

//## begin module%661FE1D800FF.additionalIncludes preserve=no
//## end module%661FE1D800FF.additionalIncludes

//## begin module%661FE1D800FF.includes preserve=yes
//## end module%661FE1D800FF.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class EmailSegment;
} // namespace usersegment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Email;

} // namespace command

//## begin module%661FE1D800FF.declarations preserve=no
//## end module%661FE1D800FF.declarations

//## begin module%661FE1D800FF.additionalDeclarations preserve=yes
//## end module%661FE1D800FF.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::SettlementFolder%661FE17700A0.preface preserve=yes
//## end metaoperator::SettlementFolder%661FE17700A0.preface

//## Class: SettlementFolder%661FE17700A0
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%661FE1A400FA;reusable::Query { -> F}
//## Uses: <unnamed>%661FE1A50301;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%661FE1A7033A;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%661FE1AA02DF;usersegment::EmailSegment { -> F}
//## Uses: <unnamed>%661FE1AD0367;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%6620159001CD;command::Email { -> F}

class DllExport SettlementFolder : public reusable::Observer  //## Inherits: <unnamed>%661FE19C0397
{
  //## begin metaoperator::SettlementFolder%661FE17700A0.initialDeclarations preserve=yes
  public:
      enum Total
      {
         TRANSACTION = 1,
         INTERCHANGE_FEE,
         FEE_COLLECTION,
         DEPOSIT
      };
  //## end metaoperator::SettlementFolder%661FE17700A0.initialDeclarations

  public:
    //## Constructors (generated)
      SettlementFolder();

    //## Destructor (generated)
      virtual ~SettlementFolder();


    //## Other Operations (specified)
      //## Operation: report%661FE2AB036C
      bool report (command::Email* pEmail);

      //## Operation: report%661FE2AE0345
      bool report ();

      //## Operation: update%661FE29301F1
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin metaoperator::SettlementFolder%661FE17700A0.public preserve=yes
      //## end metaoperator::SettlementFolder%661FE17700A0.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: ColumnA%66203675013A
      //## begin metaoperator::SettlementFolder::ColumnA%66203675013A.attr preserve=no  private: map<int,string,less<int> > {V} 
      map<int,string,less<int> > m_hColumnA;
      //## end metaoperator::SettlementFolder::ColumnA%66203675013A.attr

    // Additional Protected Declarations
      //## begin metaoperator::SettlementFolder%661FE17700A0.protected preserve=yes
      //## end metaoperator::SettlementFolder%661FE17700A0.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::SettlementFolder%661FE17700A0.private preserve=yes
      //## end metaoperator::SettlementFolder%661FE17700A0.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: AMT_RECON_NET%6398AB5801ED
      //## begin metaoperator::SettlementFolder::AMT_RECON_NET%6398AB5801ED.attr preserve=no  private: double[5][7] {V} 
      double m_dAMT_RECON_NET[5][7];
      //## end metaoperator::SettlementFolder::AMT_RECON_NET%6398AB5801ED.attr

      //## Attribute: ENTITY_ROLE%66202E0A0190
      //## begin metaoperator::SettlementFolder::ENTITY_ROLE%66202E0A0190.attr preserve=no  private: string {V} 
      string m_strENTITY_ROLE;
      //## end metaoperator::SettlementFolder::ENTITY_ROLE%66202E0A0190.attr

      //## Attribute: IMPACT_TO_ACQ%6620339401CF
      //## begin metaoperator::SettlementFolder::IMPACT_TO_ACQ%6620339401CF.attr preserve=no  private: string {V} 
      string m_strIMPACT_TO_ACQ;
      //## end metaoperator::SettlementFolder::IMPACT_TO_ACQ%6620339401CF.attr

      //## Attribute: INST_ID%6398A66902A2
      //## begin metaoperator::SettlementFolder::INST_ID%6398A66902A2.attr preserve=no  private: string[2] {V} 
      string m_strINST_ID[2];
      //## end metaoperator::SettlementFolder::INST_ID%6398A66902A2.attr

      //## Attribute: PROC_ID%6398A669019B
      //## begin metaoperator::SettlementFolder::PROC_ID%6398A669019B.attr preserve=no  private: string[2] {V} 
      string m_strPROC_ID[2];
      //## end metaoperator::SettlementFolder::PROC_ID%6398A669019B.attr

      //## Attribute: REPORT_NAME%6398A66A0075
      //## begin metaoperator::SettlementFolder::REPORT_NAME%6398A66A0075.attr preserve=no  private: string {V} 
      string m_strREPORT_NAME;
      //## end metaoperator::SettlementFolder::REPORT_NAME%6398A66A0075.attr

      //## Attribute: ROW_NUMBER%6398A66A016F
      //## begin metaoperator::SettlementFolder::ROW_NUMBER%6398A66A016F.attr preserve=no  private: int[2] {V} 
      int m_iROW_NUMBER[2];
      //## end metaoperator::SettlementFolder::ROW_NUMBER%6398A66A016F.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%6620174002C3
      //## Role: SettlementFolder::<m_pEmail>%662017410232
      //## begin metaoperator::SettlementFolder::<m_pEmail>%662017410232.role preserve=no  public: command::Email { -> RFHgN}
      command::Email *m_pEmail;
      //## end metaoperator::SettlementFolder::<m_pEmail>%662017410232.role

    // Additional Implementation Declarations
      //## begin metaoperator::SettlementFolder%661FE17700A0.implementation preserve=yes
      //## end metaoperator::SettlementFolder%661FE17700A0.implementation

};

//## begin metaoperator::SettlementFolder%661FE17700A0.postscript preserve=yes
//## end metaoperator::SettlementFolder%661FE17700A0.postscript

} // namespace metaoperator

//## begin module%661FE1D800FF.epilog preserve=yes
//## end module%661FE1D800FF.epilog


#endif
