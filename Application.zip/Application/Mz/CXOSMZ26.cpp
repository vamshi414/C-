//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65F2FE730160.cm preserve=no
//## end module%65F2FE730160.cm

//## begin module%65F2FE730160.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65F2FE730160.cp

//## Module: CXOSMZ26%65F2FE730160; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ26.cpp

//## begin module%65F2FE730160.additionalIncludes preserve=no
//## end module%65F2FE730160.additionalIncludes

//## begin module%65F2FE730160.includes preserve=yes
//## end module%65F2FE730160.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSMZ26_h
#include "CXODMZ26.hpp"
#endif


//## begin module%65F2FE730160.declarations preserve=no
//## end module%65F2FE730160.declarations

//## begin module%65F2FE730160.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Condition* createTotal()
   {
      return new metaoperator::Total();
   }
   const bool registered = metaoperator::ConditionFactory::instance()->registerCondition("Total",createTotal);
}
//## end module%65F2FE730160.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::Total 

Total::Total()
  //## begin Total::Total%65F2F9BD035F_const.hasinit preserve=no
  //## end Total::Total%65F2F9BD035F_const.hasinit
  //## begin Total::Total%65F2F9BD035F_const.initialization preserve=yes
  //## end Total::Total%65F2F9BD035F_const.initialization
{
  //## begin metaoperator::Total::Total%65F2F9BD035F_const.body preserve=yes
   memcpy(m_sID,"MZ26",4);
  //## end metaoperator::Total::Total%65F2F9BD035F_const.body
}


Total::~Total()
{
  //## begin metaoperator::Total::~Total%65F2F9BD035F_dest.body preserve=yes
  //## end metaoperator::Total::~Total%65F2F9BD035F_dest.body
}



//## Other Operations (implementation)
bool Total::test ()
{
  //## begin metaoperator::Total::test%65F2FC7402C3.body preserve=yes
   if (m_hToken.size() < 8)
      return false;
   string strDatasetName;
   getValue(m_hToken[2],strDatasetName);
   if (strDatasetName.empty())
      return false;
   string strNETWORK_CYCLE;
   getValue(m_hToken[4],strNETWORK_CYCLE);
   string strDATE_RECON_ISS[2];
   Query hQuery;
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.bind("T_RECON_TOTAL","DATE_RECON_ISS",Column::STRING,&strDATE_RECON_ISS[0],0,"MAX");
   hQuery.setBasicPredicate("T_RECON_TOTAL","PROC_ID","=",m_hToken[3].c_str());
   hQuery.setBasicPredicate("T_RECON_TOTAL","REPORT_NAME","=",m_hToken[5].c_str());
   hQuery.setBasicPredicate("T_RECON_TOTAL","REPORT_SOURCE","=","N");
   hQuery.setBasicPredicate("T_RECON_TOTAL","NETWORK_ID","=","MCI");
   hQuery.setBasicPredicate("T_RECON_TOTAL","NETWORK_CYCLE","=",strNETWORK_CYCLE.c_str());
   if (!pSelectStatement->execute(hQuery))
      return false;
   hQuery.reset();
   hQuery.bind("T_RECON_TOTAL","DATE_RECON_ISS",Column::STRING,&strDATE_RECON_ISS[1],0,"MAX");
   hQuery.setBasicPredicate("T_RECON_TOTAL","PROC_ID","=",m_hToken[3].c_str());
   hQuery.setBasicPredicate("T_RECON_TOTAL","REPORT_NAME","=",m_hToken[7].c_str());
   hQuery.setBasicPredicate("T_RECON_TOTAL","REPORT_SOURCE","=","N");
   hQuery.setBasicPredicate("T_RECON_TOTAL","NETWORK_ID","=","MCI");
   hQuery.setBasicPredicate("T_RECON_TOTAL","NETWORK_CYCLE","=",strNETWORK_CYCLE.c_str());
   if (!pSelectStatement->execute(hQuery))
      return false;
   if (m_hToken[6] == ">")
      return strDATE_RECON_ISS[0] > strDATE_RECON_ISS[1];
   if (m_hToken[6] == "<")
      return strDATE_RECON_ISS[0] < strDATE_RECON_ISS[1];
   if (m_hToken[6] == "=")
      return strDATE_RECON_ISS[0] == strDATE_RECON_ISS[1];
   if (m_hToken[6] == ">=")
      return strDATE_RECON_ISS[0] >= strDATE_RECON_ISS[1];
   if (m_hToken[6] == "<=")
      return strDATE_RECON_ISS[0] <= strDATE_RECON_ISS[1];
   return false;
  //## end metaoperator::Total::test%65F2FC7402C3.body
}

// Additional Declarations
  //## begin metaoperator::Total%65F2F9BD035F.declarations preserve=yes
  //## end metaoperator::Total%65F2F9BD035F.declarations

} // namespace metaoperator

//## begin module%65F2FE730160.epilog preserve=yes
//## end module%65F2FE730160.epilog
