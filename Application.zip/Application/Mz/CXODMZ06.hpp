//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6390A36F00E4.cm preserve=no
//## end module%6390A36F00E4.cm

//## begin module%6390A36F00E4.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6390A36F00E4.cp

//## Module: CXOSMZ06%6390A36F00E4; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ06.hpp

#ifndef CXOSMZ06_h
#define CXOSMZ06_h 1

//## begin module%6390A36F00E4.additionalIncludes preserve=no
//## end module%6390A36F00E4.additionalIncludes

//## begin module%6390A36F00E4.includes preserve=yes
//## end module%6390A36F00E4.includes

#ifndef CXOSMZ03_h
#include "CXODMZ03.hpp"
#endif
//## begin module%6390A36F00E4.declarations preserve=no
//## end module%6390A36F00E4.declarations

//## begin module%6390A36F00E4.additionalDeclarations preserve=yes
//## end module%6390A36F00E4.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::CopyFile%6390A2D4002E.preface preserve=yes
//## end metaoperator::CopyFile%6390A2D4002E.preface

//## Class: CopyFile%6390A2D4002E
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport CopyFile : public Function  //## Inherits: <unnamed>%6390A320008C
{
  //## begin metaoperator::CopyFile%6390A2D4002E.initialDeclarations preserve=yes
  //## end metaoperator::CopyFile%6390A2D4002E.initialDeclarations

  public:
    //## Constructors (generated)
      CopyFile();

    //## Destructor (generated)
      virtual ~CopyFile();


    //## Other Operations (specified)
      //## Operation: execute%6390A34B02DC
      virtual int execute ();

    // Additional Public Declarations
      //## begin metaoperator::CopyFile%6390A2D4002E.public preserve=yes
      //## end metaoperator::CopyFile%6390A2D4002E.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::CopyFile%6390A2D4002E.protected preserve=yes
      //## end metaoperator::CopyFile%6390A2D4002E.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::CopyFile%6390A2D4002E.private preserve=yes
      //## end metaoperator::CopyFile%6390A2D4002E.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin metaoperator::CopyFile%6390A2D4002E.implementation preserve=yes
      //## end metaoperator::CopyFile%6390A2D4002E.implementation

};

//## begin metaoperator::CopyFile%6390A2D4002E.postscript preserve=yes
//## end metaoperator::CopyFile%6390A2D4002E.postscript

} // namespace metaoperator

//## begin module%6390A36F00E4.epilog preserve=yes
//## end module%6390A36F00E4.epilog


#endif
