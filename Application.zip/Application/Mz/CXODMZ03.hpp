//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6234D82A00CD.cm preserve=no
//## end module%6234D82A00CD.cm

//## begin module%6234D82A00CD.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6234D82A00CD.cp

//## Module: CXOSMZ03%6234D82A00CD; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ03.hpp

#ifndef CXOSMZ03_h
#define CXOSMZ03_h 1

//## begin module%6234D82A00CD.additionalIncludes preserve=no
//## end module%6234D82A00CD.additionalIncludes

//## begin module%6234D82A00CD.includes preserve=yes
//## end module%6234D82A00CD.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
#ifndef CXOSMZ04_h
#include "CXODMZ04.hpp"
#endif
#ifndef CXOSMZ02_h
#include "CXODMZ02.hpp"
#endif

//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
class MetaOperator;
} // namespace metaoperator

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;

} // namespace reusable

//## begin module%6234D82A00CD.declarations preserve=no
//## end module%6234D82A00CD.declarations

//## begin module%6234D82A00CD.additionalDeclarations preserve=yes
//## end module%6234D82A00CD.additionalDeclarations


namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::Function%6234A7200264.preface preserve=yes
//## end metaoperator::Function%6234A7200264.preface

//## Class: Function%6234A7200264
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6234E1810219;IF::Trace { -> }
//## Uses: <unnamed>%6234E4190089;Condition { -> }
//## Uses: <unnamed>%6234F450001A;reusable::Buffer { -> F}
//## Uses: <unnamed>%638FFFE50296;FunctionFactory { -> }
//## Uses: <unnamed>%6390004903B8;MetaOperator { -> F}
//## Uses: <unnamed>%6394B9C801EF;segment::AuditEvent { -> }
//## Uses: <unnamed>%63975F1102EC;database::Database { -> }

class DllExport Function : public reusable::Observer  //## Inherits: <unnamed>%63B53F40006C
{
  //## begin metaoperator::Function%6234A7200264.initialDeclarations preserve=yes
  //## end metaoperator::Function%6234A7200264.initialDeclarations

  public:
    //## Constructors (generated)
      Function();

    //## Destructor (generated)
      virtual ~Function();


    //## Other Operations (specified)
      //## Operation: execute%6234A764008C
      virtual int execute ();

      //## Operation: setToken%6390FA8102AA
      void setToken (const vector<string>& hToken);

      //## Operation: update%63B53F5803D8
      virtual void update (Subject* pSubject);

    // Data Members for Class Attributes

      //## Attribute: Token%6234AAB00250
      //## begin metaoperator::Function::Token%6234AAB00250.attr preserve=no  public: vector<string> {VA} 
      vector<string> m_hToken;
      //## end metaoperator::Function::Token%6234AAB00250.attr

    // Additional Public Declarations
      //## begin metaoperator::Function%6234A7200264.public preserve=yes
      //## end metaoperator::Function%6234A7200264.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: DATE_RECON%6394BBCB021B
      //## begin metaoperator::Function::DATE_RECON%6394BBCB021B.attr preserve=no  protected: string {VA} 
      string m_strDATE_RECON;
      //## end metaoperator::Function::DATE_RECON%6394BBCB021B.attr

    // Additional Protected Declarations
      //## begin metaoperator::Function%6234A7200264.protected preserve=yes
      //## end metaoperator::Function%6234A7200264.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::Function%6234A7200264.private preserve=yes
      //## end metaoperator::Function%6234A7200264.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin metaoperator::Function%6234A7200264.implementation preserve=yes
      //## end metaoperator::Function%6234A7200264.implementation

};

//## begin metaoperator::Function%6234A7200264.postscript preserve=yes
//## end metaoperator::Function%6234A7200264.postscript

} // namespace metaoperator

//## begin module%6234D82A00CD.epilog preserve=yes
//## end module%6234D82A00CD.epilog


#endif
