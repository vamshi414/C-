//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%639CCBA8017C.cm preserve=no
//## end module%639CCBA8017C.cm

//## begin module%639CCBA8017C.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%639CCBA8017C.cp

//## Module: CXOSMZ12%639CCBA8017C; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ12.hpp

#ifndef CXOSMZ12_h
#define CXOSMZ12_h 1

//## begin module%639CCBA8017C.additionalIncludes preserve=no
//## end module%639CCBA8017C.additionalIncludes

//## begin module%639CCBA8017C.includes preserve=yes
//## end module%639CCBA8017C.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class EmailSegment;
} // namespace usersegment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Email;

} // namespace command

//## begin module%639CCBA8017C.declarations preserve=no
//## end module%639CCBA8017C.declarations

//## begin module%639CCBA8017C.additionalDeclarations preserve=yes
//## end module%639CCBA8017C.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::ClearingFolder%639CCB4902A3.preface preserve=yes
//## end metaoperator::ClearingFolder%639CCB4902A3.preface

//## Class: ClearingFolder%639CCB4902A3
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%639CDD500357;reusable::Query { -> F}
//## Uses: <unnamed>%639CDD5400A0;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%639CDD570372;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%639CDD9E006F;usersegment::EmailSegment { -> F}
//## Uses: <unnamed>%639CDDF601C0;entitysegment::SwitchBusinessDay { -> F}

class DllExport ClearingFolder : public reusable::Observer  //## Inherits: <unnamed>%639CCB5A01EB
{
  //## begin metaoperator::ClearingFolder%639CCB4902A3.initialDeclarations preserve=yes
  //## end metaoperator::ClearingFolder%639CCB4902A3.initialDeclarations

  public:
    //## Constructors (generated)
      ClearingFolder();

    //## Destructor (generated)
      virtual ~ClearingFolder();


    //## Other Operations (specified)
      //## Operation: report%639CD8CA0250
      bool report (command::Email* pEmail);

      //## Operation: report%639CDB850048
      bool report ();

      //## Operation: update%639CCB67034E
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin metaoperator::ClearingFolder%639CCB4902A3.public preserve=yes
      //## end metaoperator::ClearingFolder%639CCB4902A3.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::ClearingFolder%639CCB4902A3.protected preserve=yes
      //## end metaoperator::ClearingFolder%639CCB4902A3.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::ClearingFolder%639CCB4902A3.private preserve=yes
      //## end metaoperator::ClearingFolder%639CCB4902A3.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: INST_ID%6398A66902A2
      //## begin metaoperator::ClearingFolder::INST_ID%6398A66902A2.attr preserve=no  private: reusable::string[2] {V} 
      reusable::string m_strINST_ID[2];
      //## end metaoperator::ClearingFolder::INST_ID%6398A66902A2.attr

      //## Attribute: NETWORK_ID%6398A630028F
      //## begin metaoperator::ClearingFolder::NETWORK_ID%6398A630028F.attr preserve=no  private: reusable::string[2] {V} 
      reusable::string m_strNETWORK_ID[2];
      //## end metaoperator::ClearingFolder::NETWORK_ID%6398A630028F.attr

      //## Attribute: PROC_ID%6398A669019B
      //## begin metaoperator::ClearingFolder::PROC_ID%6398A669019B.attr preserve=no  private: reusable::string[2] {V} 
      reusable::string m_strPROC_ID[2];
      //## end metaoperator::ClearingFolder::PROC_ID%6398A669019B.attr

      //## Attribute: REPORT_NAME%6398A66A0075
      //## begin metaoperator::ClearingFolder::REPORT_NAME%6398A66A0075.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strREPORT_NAME;
      //## end metaoperator::ClearingFolder::REPORT_NAME%6398A66A0075.attr

      //## Attribute: REPORT_SOURCE%6398A669038E
      //## begin metaoperator::ClearingFolder::REPORT_SOURCE%6398A669038E.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strREPORT_SOURCE;
      //## end metaoperator::ClearingFolder::REPORT_SOURCE%6398A669038E.attr

      //## Attribute: ROW_NUMBER%6398A66A016F
      //## begin metaoperator::ClearingFolder::ROW_NUMBER%6398A66A016F.attr preserve=no  private: int {V} 0
      int m_iROW_NUMBER;
      //## end metaoperator::ClearingFolder::ROW_NUMBER%6398A66A016F.attr

      //## Attribute: TRAN_COUNT%6398AB5801ED
      //## begin metaoperator::ClearingFolder::TRAN_COUNT%6398AB5801ED.attr preserve=no  private: int[7] {V} 
      int m_iTRAN_COUNT[7];
      //## end metaoperator::ClearingFolder::TRAN_COUNT%6398AB5801ED.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%639CD8A60369
      //## Role: ClearingFolder::<m_pEmail>%639CD8A7039D
      //## begin metaoperator::ClearingFolder::<m_pEmail>%639CD8A7039D.role preserve=no  public: command::Email { -> RFHgN}
      command::Email *m_pEmail;
      //## end metaoperator::ClearingFolder::<m_pEmail>%639CD8A7039D.role

    // Additional Implementation Declarations
      //## begin metaoperator::ClearingFolder%639CCB4902A3.implementation preserve=yes
      //## end metaoperator::ClearingFolder%639CCB4902A3.implementation

};

//## begin metaoperator::ClearingFolder%639CCB4902A3.postscript preserve=yes
//## end metaoperator::ClearingFolder%639CCB4902A3.postscript

} // namespace metaoperator

//## begin module%639CCBA8017C.epilog preserve=yes
//## end module%639CCBA8017C.epilog


#endif
