//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65B26A460004.cm preserve=no
//## end module%65B26A460004.cm

//## begin module%65B26A460004.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65B26A460004.cp

//## Module: CXOSMZ24%65B26A460004; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ24.hpp

#ifndef CXOSMZ24_h
#define CXOSMZ24_h 1

//## begin module%65B26A460004.additionalIncludes preserve=no
//## end module%65B26A460004.additionalIncludes

//## begin module%65B26A460004.includes preserve=yes
//## end module%65B26A460004.includes

#ifndef CXOSMZ03_h
#include "CXODMZ03.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;

} // namespace IF

//## begin module%65B26A460004.declarations preserve=no
//## end module%65B26A460004.declarations

//## begin module%65B26A460004.additionalDeclarations preserve=yes
//## end module%65B26A460004.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::PickFile%65B269A1033D.preface preserve=yes
//## end metaoperator::PickFile%65B269A1033D.preface

//## Class: PickFile%65B269A1033D
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%65B2C6400044;IF::FlatFile { -> F}

class DllExport PickFile : public Function  //## Inherits: <unnamed>%65B269B10260
{
  //## begin metaoperator::PickFile%65B269A1033D.initialDeclarations preserve=yes
  //## end metaoperator::PickFile%65B269A1033D.initialDeclarations

  public:
    //## Constructors (generated)
      PickFile();

    //## Destructor (generated)
      virtual ~PickFile();


    //## Other Operations (specified)
      //## Operation: execute%65B269D50189
      virtual int execute ();

    // Additional Public Declarations
      //## begin metaoperator::PickFile%65B269A1033D.public preserve=yes
      //## end metaoperator::PickFile%65B269A1033D.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::PickFile%65B269A1033D.protected preserve=yes
      //## end metaoperator::PickFile%65B269A1033D.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::PickFile%65B269A1033D.private preserve=yes
      //## end metaoperator::PickFile%65B269A1033D.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin metaoperator::PickFile%65B269A1033D.implementation preserve=yes
      //## end metaoperator::PickFile%65B269A1033D.implementation

};

//## begin metaoperator::PickFile%65B269A1033D.postscript preserve=yes
//## end metaoperator::PickFile%65B269A1033D.postscript

} // namespace metaoperator

//## begin module%65B26A460004.epilog preserve=yes
//## end module%65B26A460004.epilog


#endif
