//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6390A77A00DC.cm preserve=no
//## end module%6390A77A00DC.cm

//## begin module%6390A77A00DC.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6390A77A00DC.cp

//## Module: CXOSMZ08%6390A77A00DC; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ08.hpp

#ifndef CXOSMZ08_h
#define CXOSMZ08_h 1

//## begin module%6390A77A00DC.additionalIncludes preserve=no
//## end module%6390A77A00DC.additionalIncludes

//## begin module%6390A77A00DC.includes preserve=yes
//## end module%6390A77A00DC.includes

#ifndef CXOSMZ03_h
#include "CXODMZ03.hpp"
#endif

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class ExportFile;

} // namespace database

//## begin module%6390A77A00DC.declarations preserve=no
//## end module%6390A77A00DC.declarations

//## begin module%6390A77A00DC.additionalDeclarations preserve=yes
//## end module%6390A77A00DC.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::ExportFileTrigger%6390A72902A5.preface preserve=yes
//## end metaoperator::ExportFileTrigger%6390A72902A5.preface

//## Class: ExportFileTrigger%6390A72902A5
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6390A757006F;database::ExportFile { -> F}
//## Uses: <unnamed>%6390A8760168;timer::Clock { -> F}

class DllExport ExportFileTrigger : public Function  //## Inherits: <unnamed>%6390A742025D
{
  //## begin metaoperator::ExportFileTrigger%6390A72902A5.initialDeclarations preserve=yes
  //## end metaoperator::ExportFileTrigger%6390A72902A5.initialDeclarations

  public:
    //## Constructors (generated)
      ExportFileTrigger();

    //## Destructor (generated)
      virtual ~ExportFileTrigger();


    //## Other Operations (specified)
      //## Operation: execute%6390A74802A8
      virtual int execute ();

    // Additional Public Declarations
      //## begin metaoperator::ExportFileTrigger%6390A72902A5.public preserve=yes
      //## end metaoperator::ExportFileTrigger%6390A72902A5.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::ExportFileTrigger%6390A72902A5.protected preserve=yes
      //## end metaoperator::ExportFileTrigger%6390A72902A5.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::ExportFileTrigger%6390A72902A5.private preserve=yes
      //## end metaoperator::ExportFileTrigger%6390A72902A5.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin metaoperator::ExportFileTrigger%6390A72902A5.implementation preserve=yes
      //## end metaoperator::ExportFileTrigger%6390A72902A5.implementation

};

//## begin metaoperator::ExportFileTrigger%6390A72902A5.postscript preserve=yes
//## end metaoperator::ExportFileTrigger%6390A72902A5.postscript

} // namespace metaoperator

//## begin module%6390A77A00DC.epilog preserve=yes
//## end module%6390A77A00DC.epilog


#endif
