//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%639CCAA70044.cm preserve=no
//## end module%639CCAA70044.cm

//## begin module%639CCAA70044.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%639CCAA70044.cp

//## Module: CXOSMZ11%639CCAA70044; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ11.hpp

#ifndef CXOSMZ11_h
#define CXOSMZ11_h 1

//## begin module%639CCAA70044.additionalIncludes preserve=no
//## end module%639CCAA70044.additionalIncludes

//## begin module%639CCAA70044.includes preserve=yes
//## end module%639CCAA70044.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class Compactor;
} // namespace settlement

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
class Progress;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class GMTClock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Status;
class Channel;
class SwitchClock;
class FileFactory;
} // namespace database

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class EmailSegment;
} // namespace usersegment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Email;

} // namespace command

//## begin module%639CCAA70044.declarations preserve=no
//## end module%639CCAA70044.declarations

//## begin module%639CCAA70044.additionalDeclarations preserve=yes
//## end module%639CCAA70044.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::StatusFolder%639CA7B50391.preface preserve=yes
//## end metaoperator::StatusFolder%639CA7B50391.preface

//## Class: StatusFolder%639CA7B50391
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%639CCDDC02B6;entitysegment::Progress { -> F}
//## Uses: <unnamed>%639CCE1700EE;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%639CCE3D00CE;timer::GMTClock { -> F}
//## Uses: <unnamed>%639CCE5B0257;settlement::Compactor { -> F}
//## Uses: <unnamed>%639CCE7B003E;reusable::Query { -> F}
//## Uses: <unnamed>%639CCE7F00FF;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%639CCE830137;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%639CCEA70297;database::Channel { -> F}
//## Uses: <unnamed>%639CCF150027;database::Status { -> F}
//## Uses: <unnamed>%639CCF2C00FE;IF::Extract { -> F}
//## Uses: <unnamed>%639CD0260196;usersegment::EmailSegment { -> F}
//## Uses: <unnamed>%639CD12A0347;database::FileFactory { -> F}
//## Uses: <unnamed>%639CD1790367;database::SwitchClock { -> F}

class DllExport StatusFolder : public reusable::Observer  //## Inherits: <unnamed>%639CA7DB0013
{
  //## begin metaoperator::StatusFolder%639CA7B50391.initialDeclarations preserve=yes
  //## end metaoperator::StatusFolder%639CA7B50391.initialDeclarations

  public:
    //## Constructors (generated)
      StatusFolder();

    //## Destructor (generated)
      virtual ~StatusFolder();


    //## Other Operations (specified)
      //## Operation: report%639CCCB00022
      bool report (command::Email* pEmail);

      //## Operation: report%639CCD9102E1
      bool report (const char* pszName, const pair<string,int>& hItem);

      //## Operation: update%639CA7EB02FD
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin metaoperator::StatusFolder%639CA7B50391.public preserve=yes
      //## end metaoperator::StatusFolder%639CA7B50391.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::StatusFolder%639CA7B50391.protected preserve=yes
      //## end metaoperator::StatusFolder%639CA7B50391.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::StatusFolder%639CA7B50391.private preserve=yes
      //## end metaoperator::StatusFolder%639CA7B50391.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%639CCFC002E7
      //## Role: StatusFolder::<m_pEmail>%639CCFC102CA
      //## begin metaoperator::StatusFolder::<m_pEmail>%639CCFC102CA.role preserve=no  public: command::Email { -> RFHgN}
      command::Email *m_pEmail;
      //## end metaoperator::StatusFolder::<m_pEmail>%639CCFC102CA.role

    // Additional Implementation Declarations
      //## begin metaoperator::StatusFolder%639CA7B50391.implementation preserve=yes
      //## end metaoperator::StatusFolder%639CA7B50391.implementation

};

//## begin metaoperator::StatusFolder%639CA7B50391.postscript preserve=yes
//## end metaoperator::StatusFolder%639CA7B50391.postscript

} // namespace metaoperator

//## begin module%639CCAA70044.epilog preserve=yes
//## end module%639CCAA70044.epilog


#endif
