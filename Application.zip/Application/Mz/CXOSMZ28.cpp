//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%66295F1C02C6.cm preserve=no
//## end module%66295F1C02C6.cm

//## begin module%66295F1C02C6.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%66295F1C02C6.cp

//## Module: CXOSMZ28%66295F1C02C6; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ28.cpp

//## begin module%66295F1C02C6.additionalIncludes preserve=no
//## end module%66295F1C02C6.additionalIncludes

//## begin module%66295F1C02C6.includes preserve=yes
//## end module%66295F1C02C6.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSUS21_h
#include "CXODUS21.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSBC25_h
#include "CXODBC25.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSRU19_h
#include "CXODRU19.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSMZ28_h
#include "CXODMZ28.hpp"
#endif


//## begin module%66295F1C02C6.declarations preserve=no
//## end module%66295F1C02C6.declarations

//## begin module%66295F1C02C6.additionalDeclarations preserve=yes
//## end module%66295F1C02C6.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::ExportFileFolder 

//## begin metaoperator::ExportFileFolder::Instance%6629628601B2.attr preserve=no  private: static metaoperator::ExportFileFolder* {V} 0
metaoperator::ExportFileFolder* ExportFileFolder::m_pInstance = 0;
//## end metaoperator::ExportFileFolder::Instance%6629628601B2.attr

ExportFileFolder::ExportFileFolder()
  //## begin ExportFileFolder::ExportFileFolder%66295E2503B9_const.hasinit preserve=no
      : m_iDX_FILE_ID(0),
        m_iIndex(0),
        m_pEmail(0)
  //## end ExportFileFolder::ExportFileFolder%66295E2503B9_const.hasinit
  //## begin ExportFileFolder::ExportFileFolder%66295E2503B9_const.initialization preserve=yes
  //## end ExportFileFolder::ExportFileFolder%66295E2503B9_const.initialization
{
  //## begin metaoperator::ExportFileFolder::ExportFileFolder%66295E2503B9_const.body preserve=yes
   memcpy(m_sID,"MZ28",4);
  //## end metaoperator::ExportFileFolder::ExportFileFolder%66295E2503B9_const.body
}


ExportFileFolder::~ExportFileFolder()
{
  //## begin metaoperator::ExportFileFolder::~ExportFileFolder%66295E2503B9_dest.body preserve=yes
  //## end metaoperator::ExportFileFolder::~ExportFileFolder%66295E2503B9_dest.body
}



//## Other Operations (implementation)
void ExportFileFolder::add (const string& strBuffer, vector<string>& hDX_FILE_TYPE)
{
  //## begin metaoperator::ExportFileFolder::add%6629741403E3.body preserve=yes
   vector<string> hTokens;
   if (Buffer::parse(strBuffer," ",hTokens) >= 3)
      for (int i = 0;i < hDX_FILE_TYPE.size();++i)
      {
         m_hDX_FILE_TYPE.insert(hDX_FILE_TYPE[i]);
         string strFirst(hTokens[1]);
         strFirst.append("~",1);
         strFirst += hTokens[2];
         strFirst.append("~",1);
         strFirst += hDX_FILE_TYPE[i];
         ExportFile hExportFile;
         m_hExportFile.insert(map<string,ExportFile,less<string> >::value_type(strFirst,hExportFile));
      }
  //## end metaoperator::ExportFileFolder::add%6629741403E3.body
}

ExportFileFolder* ExportFileFolder::instance ()
{
  //## begin metaoperator::ExportFileFolder::instance%6629625C0103.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ExportFileFolder;
   return m_pInstance;
  //## end metaoperator::ExportFileFolder::instance%6629625C0103.body
}

bool ExportFileFolder::report (command::Email* pEmail)
{
  //## begin metaoperator::ExportFileFolder::report%6629602300F5.body preserve=yes
   if (m_hDX_FILE_TYPE.empty())
      return true;
   m_pEmail = pEmail;
   string strEmpty;
   map<string,ExportFile,less<string> >::iterator p;
   for (p = m_hExportFile.begin();p != m_hExportFile.end();++p)
      for (int i = 0;i <= 2;++i)
         (*p).second.setRow(i,strEmpty);
   string strDX_FILE_TYPE("(");
   for (set<string,less<string> >::iterator p = m_hDX_FILE_TYPE.begin();p != m_hDX_FILE_TYPE.end();++p)
   {
      if (strDX_FILE_TYPE.length() > 1)
         strDX_FILE_TYPE.append(",",1);
      strDX_FILE_TYPE.append("'",1);
      strDX_FILE_TYPE += (*p);
      strDX_FILE_TYPE.append("'",1);
   }
   strDX_FILE_TYPE.append(")",1);
   int i = 0;
   string strDATE_RECON(entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(0));
   Date hDate(strDATE_RECON.c_str());
   hDate -= 1;
   strDATE_RECON = hDate.asString("%Y%m%d");
   usersegment::EmailSegment::instance()->setField("Yesterday",strDATE_RECON);
   usersegment::EmailSegment::instance()->setField("Today",entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(0));
   usersegment::EmailSegment::instance()->setField("Tomorrow",entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(1));
   m_pEmail->report('X');
   string strSubSelect;
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   for (m_iIndex = 0;m_iIndex <= 2;++m_iIndex)
   {
      Query hQuery;
      hQuery.attach(this);
      m_strSEQ_NO.erase();
      string strTable("DX_DATA_");
      strTable += strDATE_RECON;
      hQuery.setSubSelect(true);
      hQuery.bind(strTable.c_str(),"DX_FILE_ID",Column::LONG,&i);
      hQuery.bind(strTable.c_str(),"*",Column::LONG,&i,0,"COUNT");
      hQuery.setGroupByClause("DX_FILE_ID");
      auto_ptr<reusable::FormatSelectVisitor>pFormatSelectVisitor
      ((reusable::FormatSelectVisitor*)database::DatabaseFactory::instance()->create("FormatSelectVisitor"));
      hQuery.accept(*pFormatSelectVisitor);
      strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ") X";
      hQuery.reset();
      hQuery.setSubSelect(false);
      hQuery.join("DX_DATA_CONTROL","LEFT OUTER",strSubSelect.c_str(),"DX_FILE_ID");
      hQuery.bind("DX_DATA_CONTROL","DX_FILE_ID",Column::LONG,&m_iDX_FILE_ID);
      hQuery.bind("DX_DATA_CONTROL","ENTITY_TYPE",Column::STRING,&m_strENTITY_TYPE);
      hQuery.bind("DX_DATA_CONTROL","ENTITY_ID",Column::STRING,&m_strENTITY_ID);
      hQuery.bind("DX_DATA_CONTROL","DX_FILE_TYPE",Column::STRING,&m_strDX_FILE_TYPE);
      hQuery.bind(strSubSelect.c_str(),"ROW_COUNT",Column::STRING,&m_strSEQ_NO);
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_STATE","=","DC");
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DATE_RECON","=",strDATE_RECON.c_str());
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","IN",strDX_FILE_TYPE.c_str());
      pSelectStatement->execute(hQuery);
      hDate += 1;
      strDATE_RECON = hDate.asString("%Y%m%d");
   }
   string strENTITY_ID;
   vector<string> hToken;
   for (p = m_hExportFile.begin();p != m_hExportFile.end();++p)
   {
      hToken.clear();
      if (Buffer::parse((*p).first,"~",hToken) >= 3)
      {
         if (hToken[1] != strENTITY_ID)
         {
            usersegment::EmailSegment::instance()->setField("ENTITY_TYPE",hToken[0]);
            usersegment::EmailSegment::instance()->setField("ENTITY_ID",hToken[1]);
            strENTITY_ID = hToken[1];
         }
         else
         {
            usersegment::EmailSegment::instance()->setField("ENTITY_TYPE",strEmpty);
            usersegment::EmailSegment::instance()->setField("ENTITY_ID",strEmpty);
         }
         usersegment::EmailSegment::instance()->setField("DX_FILE_TYPE",hToken[2]);
         usersegment::EmailSegment::instance()->setField("Count0",(*p).second.getRow(0));
         usersegment::EmailSegment::instance()->setField("Count1",(*p).second.getRow(1));
         usersegment::EmailSegment::instance()->setField("Count2",(*p).second.getRow(2));
         usersegment::EmailSegment::instance()->setField("Status",(*p).second.getRow(1).empty() ? "ERROR" : "OK");
         m_pEmail->report('Y');
      }
   }
   return true;
  //## end metaoperator::ExportFileFolder::report%6629602300F5.body
}

void ExportFileFolder::update (Subject* pSubject)
{
  //## begin metaoperator::ExportFileFolder::update%66295FEA02A3.body preserve=yes
   string strFirst(m_strENTITY_TYPE);
   strFirst.append("~",1);
   strFirst += m_strENTITY_ID;
   strFirst.append("~",1);
   strFirst += m_strDX_FILE_TYPE;
   map<string,ExportFile,less<string> >::iterator p = m_hExportFile.find(strFirst);
   if (p != m_hExportFile.end())
      (*p).second.setRow(m_iIndex,m_strSEQ_NO);
  //## end metaoperator::ExportFileFolder::update%66295FEA02A3.body
}

// Additional Declarations
  //## begin metaoperator::ExportFileFolder%66295E2503B9.declarations preserve=yes
  //## end metaoperator::ExportFileFolder%66295E2503B9.declarations

} // namespace metaoperator

//## begin module%66295F1C02C6.epilog preserve=yes
//## end module%66295F1C02C6.epilog
