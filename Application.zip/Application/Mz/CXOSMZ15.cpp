//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B46533026C.cm preserve=no
//## end module%63B46533026C.cm

//## begin module%63B46533026C.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B46533026C.cp

//## Module: CXOSMZ15%63B46533026C; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ15.cpp

//## begin module%63B46533026C.additionalIncludes preserve=no
//## end module%63B46533026C.additionalIncludes

//## begin module%63B46533026C.includes preserve=yes
#include <sstream>
//## end module%63B46533026C.includes

#ifndef CXOSMZ15_h
#include "CXODMZ15.hpp"
#endif
//## begin module%63B46533026C.declarations preserve=no
//## end module%63B46533026C.declarations

//## begin module%63B46533026C.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Condition* createGlobalContext()
   {
      return new metaoperator::GlobalContext();
   }
   const bool registered1 = metaoperator::ConditionFactory::instance()->registerCondition("=",createGlobalContext);
   const bool registered2 = metaoperator::ConditionFactory::instance()->registerCondition("!=",createGlobalContext);
   const bool registered3 = metaoperator::ConditionFactory::instance()->registerCondition("<",createGlobalContext);
   const bool registered4 = metaoperator::ConditionFactory::instance()->registerCondition("<=",createGlobalContext);
   const bool registered5 = metaoperator::ConditionFactory::instance()->registerCondition(">",createGlobalContext);
   const bool registered6 = metaoperator::ConditionFactory::instance()->registerCondition(">=",createGlobalContext);
}
//## end module%63B46533026C.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::GlobalContext 

GlobalContext::GlobalContext()
  //## begin GlobalContext::GlobalContext%63B4640B0132_const.hasinit preserve=no
  //## end GlobalContext::GlobalContext%63B4640B0132_const.hasinit
  //## begin GlobalContext::GlobalContext%63B4640B0132_const.initialization preserve=yes
  //## end GlobalContext::GlobalContext%63B4640B0132_const.initialization
{
  //## begin metaoperator::GlobalContext::GlobalContext%63B4640B0132_const.body preserve=yes
   memcpy(m_sID,"MZ15",4);
  //## end metaoperator::GlobalContext::GlobalContext%63B4640B0132_const.body
}


GlobalContext::~GlobalContext()
{
  //## begin metaoperator::GlobalContext::~GlobalContext%63B4640B0132_dest.body preserve=yes
  //## end metaoperator::GlobalContext::~GlobalContext%63B4640B0132_dest.body
}



//## Other Operations (implementation)
bool GlobalContext::test ()
{
  //## begin metaoperator::GlobalContext::test%63B46449017E.body preserve=yes
   bool bSuccess = false;
   string strToken1;
   string strToken3;
   if (getValue(m_hToken[1],strToken1) == false
      || getValue(m_hToken[3],strToken3) == false)
      return false;
   if (m_hToken[2] == "=")
      bSuccess = (strToken1 == strToken3);
   else
   if (m_hToken[2] == ">")
      bSuccess = (strToken1 > strToken3);
   else
   if (m_hToken[2] == "<")
      bSuccess = (strToken1 < strToken3);
   else
   if (m_hToken[2] == ">=")
      bSuccess = (strToken1 >= strToken3);
   else
   if (m_hToken[2] == "<=")
      bSuccess = (strToken1 <= strToken3);
   else
      bSuccess = (strToken1 != strToken3);
   if (bSuccess)
      setValue("DATE_RECON",m_hToken[2] == ">" ? strToken1 : strToken3);
   if (IF::Trace::getEnable())
   {
      std::ostringstream oss;
      oss << "Condition : " << m_hToken[1] << m_hToken[2] << m_hToken[3] << " -> " << strToken1 << m_hToken[2] << strToken3 << " -> " << (bSuccess ? "True" : "False");
      Trace::put(oss.str().data());
   }
   return bSuccess;
  //## end metaoperator::GlobalContext::test%63B46449017E.body
}

// Additional Declarations
  //## begin metaoperator::GlobalContext%63B4640B0132.declarations preserve=yes
  //## end metaoperator::GlobalContext%63B4640B0132.declarations

} // namespace metaoperator

//## begin module%63B46533026C.epilog preserve=yes
//## end module%63B46533026C.epilog
