//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6234D70E0395.cm preserve=no
//## end module%6234D70E0395.cm

//## begin module%6234D70E0395.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6234D70E0395.cp

//## Module: CXOSMZ01%6234D70E0395; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ01.hpp

#ifndef CXOSMZ01_h
#define CXOSMZ01_h 1

//## begin module%6234D70E0395.additionalIncludes preserve=no
//## end module%6234D70E0395.additionalIncludes

//## begin module%6234D70E0395.includes preserve=yes
#include <vector>
//## end module%6234D70E0395.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSMZ03_h
#include "CXODMZ03.hpp"
#endif
#ifndef CXOSMZ02_h
#include "CXODMZ02.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
class Match;
class ConditionFactory;
class FunctionFactory;
} // namespace metaoperator

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MidnightAlarm;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%6234D70E0395.declarations preserve=no
//## end module%6234D70E0395.declarations

//## begin module%6234D70E0395.additionalDeclarations preserve=yes
//## end module%6234D70E0395.additionalDeclarations


namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::Rule%6234A6A90246.preface preserve=yes
//## end metaoperator::Rule%6234A6A90246.preface

//## Class: Rule%6234A6A90246
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6234E16C0158;IF::Trace { -> F}
//## Uses: <unnamed>%638FFDB00177;reusable::Buffer { -> F}
//## Uses: <unnamed>%638FFDD203AE;FunctionFactory { -> F}
//## Uses: <unnamed>%63929A040043;database::Database { -> F}
//## Uses: <unnamed>%63B481760273;ConditionFactory { -> F}
//## Uses: <unnamed>%6405F5D10046;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%6405F60C022A;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%65DF97D10106;Match { -> F}

class DllExport Rule : public reusable::Object  //## Inherits: <unnamed>%6234A6CC03A7
{
  //## begin metaoperator::Rule%6234A6A90246.initialDeclarations preserve=yes
  //## end metaoperator::Rule%6234A6A90246.initialDeclarations

  public:
    //## Constructors (generated)
      Rule();

    //## Constructors (specified)
      //## Operation: Rule%6234E07A01F8
      Rule (const char* pszBuffer);

    //## Destructor (generated)
      virtual ~Rule();


    //## Other Operations (specified)
      //## Operation: add%6234A7DB0194
      void add (const string& strBuffer);

      //## Operation: check%6234A79D0267
      bool check ();

      //## Operation: execute%6393772E0253
      bool execute ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Name%6234A8420342
      const string& getName () const
      {
        //## begin metaoperator::Rule::getName%6234A8420342.get preserve=no
        return m_strName;
        //## end metaoperator::Rule::getName%6234A8420342.get
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%6234AC490290
      //## Role: Rule::<m_hCondition>%6234AC4A01DB
      vector<Condition*>& getCondition ()
      {
        //## begin metaoperator::Rule::getCondition%6234AC4A01DB.get preserve=no
        return m_hCondition;
        //## end metaoperator::Rule::getCondition%6234AC4A01DB.get
      }


      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%6234AC510226
      //## Role: Rule::<m_hFunction>%6234AC520151
      vector<Function*>& getFunction ()
      {
        //## begin metaoperator::Rule::getFunction%6234AC520151.get preserve=no
        return m_hFunction;
        //## end metaoperator::Rule::getFunction%6234AC520151.get
      }


      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%649366EC0389
      //## Role: Rule::<m_pRule>%649366ED03D2
      static Rule * getRule ()
      {
        //## begin metaoperator::Rule::getRule%649366ED03D2.get preserve=no
        return m_pRule;
        //## end metaoperator::Rule::getRule%649366ED03D2.get
      }


    // Additional Public Declarations
      //## begin metaoperator::Rule%6234A6A90246.public preserve=yes
      //## end metaoperator::Rule%6234A6A90246.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::Rule%6234A6A90246.protected preserve=yes
      //## end metaoperator::Rule%6234A6A90246.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::Rule%6234A6A90246.private preserve=yes
      //## end metaoperator::Rule%6234A6A90246.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin metaoperator::Rule::Name%6234A8420342.attr preserve=no  public: string {V} 
      string m_strName;
      //## end metaoperator::Rule::Name%6234A8420342.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%6234AC490290
      //## begin metaoperator::Rule::<m_hCondition>%6234AC4A01DB.role preserve=no  public: metaoperator::Condition {1 -> 0..nRHgN}
      vector<Condition*> m_hCondition;
      //## end metaoperator::Rule::<m_hCondition>%6234AC4A01DB.role

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%6234AC510226
      //## begin metaoperator::Rule::<m_hFunction>%6234AC520151.role preserve=no  public: metaoperator::Function {1 -> 0..nRHgN}
      vector<Function*> m_hFunction;
      //## end metaoperator::Rule::<m_hFunction>%6234AC520151.role

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%649366EC0389
      //## begin metaoperator::Rule::<m_pRule>%649366ED03D2.role preserve=no  public: static metaoperator::Rule { -> RFHgN}
      static Rule *m_pRule;
      //## end metaoperator::Rule::<m_pRule>%649366ED03D2.role

    // Additional Implementation Declarations
      //## begin metaoperator::Rule%6234A6A90246.implementation preserve=yes
      //## end metaoperator::Rule%6234A6A90246.implementation

};

//## begin metaoperator::Rule%6234A6A90246.postscript preserve=yes
//## end metaoperator::Rule%6234A6A90246.postscript

} // namespace metaoperator

//## begin module%6234D70E0395.epilog preserve=yes
//## end module%6234D70E0395.epilog


#endif
