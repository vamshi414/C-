//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65B26A47039D.cm preserve=no
//## end module%65B26A47039D.cm

//## begin module%65B26A47039D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65B26A47039D.cp

//## Module: CXOSMZ24%65B26A47039D; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ24.cpp

//## begin module%65B26A47039D.additionalIncludes preserve=no
//## end module%65B26A47039D.additionalIncludes

//## begin module%65B26A47039D.includes preserve=yes
#include "CXODNS40.hpp"
//## end module%65B26A47039D.includes

#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSMZ24_h
#include "CXODMZ24.hpp"
#endif


//## begin module%65B26A47039D.declarations preserve=no
//## end module%65B26A47039D.declarations

//## begin module%65B26A47039D.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Function* createPickFile()
   {
      return new metaoperator::PickFile();
   }
   const bool registered = metaoperator::FunctionFactory::instance()->registerFunction("pick",createPickFile);
}
//## end module%65B26A47039D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::PickFile 

PickFile::PickFile()
  //## begin PickFile::PickFile%65B269A1033D_const.hasinit preserve=no
  //## end PickFile::PickFile%65B269A1033D_const.hasinit
  //## begin PickFile::PickFile%65B269A1033D_const.initialization preserve=yes
  //## end PickFile::PickFile%65B269A1033D_const.initialization
{
  //## begin metaoperator::PickFile::PickFile%65B269A1033D_const.body preserve=yes
   memcpy(m_sID,"MZ24",4);
  //## end metaoperator::PickFile::PickFile%65B269A1033D_const.body
}


PickFile::~PickFile()
{
  //## begin metaoperator::PickFile::~PickFile%65B269A1033D_dest.body preserve=yes
  //## end metaoperator::PickFile::~PickFile%65B269A1033D_dest.body
}



//## Other Operations (implementation)
int PickFile::execute ()
{
  //## begin metaoperator::PickFile::execute%65B269D50189.body preserve=yes
   if (m_hToken.size() < 4)
      return 0;
   string strDatasetName;
   Condition::getValue(m_hToken[3],strDatasetName);
   if (!strDatasetName.empty())
      return 0;
   string strPath = m_hToken[2];
   Condition::substitute(strPath);
   if (!FlatFile::pick(strPath.c_str(),strDatasetName))
      return 0;
   Condition::setValue("PATH",strDatasetName);
   Condition::setValue("DATE_RECON",entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(1));
   size_t pos = strDatasetName.find_last_of("\\/");
   if (pos != string::npos)
      Condition::setValue(m_hToken[3],strDatasetName.substr(pos + 1));
   FlatFile x;
   x.setDatasetName(strDatasetName.c_str());
   x.setPath(strDatasetName.c_str());
   x.open();
   char* psBuffer = new char[4096];
   size_t m = 0;
   string strBuffer;
   while (x.read(psBuffer,4096,&m))
   {
      strBuffer.assign(psBuffer,m);
      Condition::setMatch(m_hToken[3],strBuffer);
   }
   delete [] psBuffer;
   x.close();
   if (m_hToken.size() == 5)
   {
      int i = strDatasetName.length() - 2;
      if (i >= 0
         && strDatasetName[i] == '0'
         && strDatasetName[i + 1] > '0'
         && strDatasetName[i + 1] < '8')
         Condition::setValue(m_hToken[4],strDatasetName.substr(i,2));
   }
   return 1;
  //## end metaoperator::PickFile::execute%65B269D50189.body
}

// Additional Declarations
  //## begin metaoperator::PickFile%65B269A1033D.declarations preserve=yes
  //## end metaoperator::PickFile%65B269A1033D.declarations

} // namespace metaoperator

//## begin module%65B26A47039D.epilog preserve=yes
//## end module%65B26A47039D.epilog
