//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6390A371034B.cm preserve=no
//## end module%6390A371034B.cm

//## begin module%6390A371034B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6390A371034B.cp

//## Module: CXOSMZ06%6390A371034B; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ06.cpp

//## begin module%6390A371034B.additionalIncludes preserve=no
//## end module%6390A371034B.additionalIncludes

//## begin module%6390A371034B.includes preserve=yes
#include <sstream>
//## end module%6390A371034B.includes

#ifndef CXOSMZ06_h
#include "CXODMZ06.hpp"
#endif
//## begin module%6390A371034B.declarations preserve=no
//## end module%6390A371034B.declarations

//## begin module%6390A371034B.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Function* createCopyFile()
   {
      return new metaoperator::CopyFile();
   }
   const bool registered = metaoperator::FunctionFactory::instance()->registerFunction("cp",createCopyFile);
}
//## end module%6390A371034B.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::CopyFile 

CopyFile::CopyFile()
  //## begin CopyFile::CopyFile%6390A2D4002E_const.hasinit preserve=no
  //## end CopyFile::CopyFile%6390A2D4002E_const.hasinit
  //## begin CopyFile::CopyFile%6390A2D4002E_const.initialization preserve=yes
  //## end CopyFile::CopyFile%6390A2D4002E_const.initialization
{
  //## begin metaoperator::CopyFile::CopyFile%6390A2D4002E_const.body preserve=yes
   memcpy(m_sID,"MZ06",4);
  //## end metaoperator::CopyFile::CopyFile%6390A2D4002E_const.body
}


CopyFile::~CopyFile()
{
  //## begin metaoperator::CopyFile::~CopyFile%6390A2D4002E_dest.body preserve=yes
  //## end metaoperator::CopyFile::~CopyFile%6390A2D4002E_dest.body
}



//## Other Operations (implementation)
int CopyFile::execute ()
{
  //## begin metaoperator::CopyFile::execute%6390A34B02DC.body preserve=yes
   int iSuccess = 0;
   string strSource(m_hToken[2]);
   Condition::substitute(strSource);
   string strDestination(m_hToken[3]);
   Condition::substitute(strDestination);
   {
      std::ostringstream oss;
      oss << "mkdir " << strDestination;
      iSuccess = (::system(oss.str().c_str()) == 0) ? 1 : -1;
   }
   if (m_hToken.size() > 4)
   {
#ifdef _WIN32
      strDestination.append("\\",1);
#else
      strDestination.append("/",1);
#endif
      string strFile(m_hToken[4]);
      Condition::substitute(strFile);
      strDestination += strFile;
   }
   std::ostringstream oss;
#ifdef _WIN32
   oss << (m_hToken[1] == "mv" ? "move " : "copy ") << strSource << " " << strDestination;
   int i = ::system(oss.str().c_str());
   iSuccess = (i == 0) ? 1 : -1;
#elif _UNIX
   oss << m_hToken[1] << " " << strSource << " " << strDestination;
   int i = ::system(oss.str().c_str()); // this is returning -1 on RHEL VM
   iSuccess = 1;
#endif
   if (IF::Trace::getEnable())
   {
      oss << " returns " << i << " -> " << (iSuccess == 1 ? "True" : "False");
      string strValue("Function : ",11);
      strValue.append(oss.str().c_str());
      Trace::put(strValue.data(),strValue.length());
   }
   if (iSuccess == 1
      && m_hToken[1] == "mv"
      && m_hToken[2].substr(0,5) != "@TEMP")
   {

      size_t pos = m_hToken[2].find("@@");
      if (pos != string::npos)
         Condition::clear(m_hToken[2].substr(pos));
   }
   return iSuccess;
  //## end metaoperator::CopyFile::execute%6390A34B02DC.body
}

// Additional Declarations
  //## begin metaoperator::CopyFile%6390A2D4002E.declarations preserve=yes
  //## end metaoperator::CopyFile%6390A2D4002E.declarations

} // namespace metaoperator

//## begin module%6390A371034B.epilog preserve=yes
//## end module%6390A371034B.epilog
