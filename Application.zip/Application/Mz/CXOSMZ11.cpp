//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%639CCAA902F5.cm preserve=no
//## end module%639CCAA902F5.cm

//## begin module%639CCAA902F5.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%639CCAA902F5.cp

//## Module: CXOSMZ11%639CCAA902F5; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ11.cpp

//## begin module%639CCAA902F5.additionalIncludes preserve=no
//## end module%639CCAA902F5.additionalIncludes

//## begin module%639CCAA902F5.includes preserve=yes
//## end module%639CCAA902F5.includes

#ifndef CXOSNS39_h
#include "CXODNS39.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSTM11_h
#include "CXODTM11.hpp"
#endif
#ifndef CXOSST17_h
#include "CXODST17.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB28_h
#include "CXODDB28.hpp"
#endif
#ifndef CXOSDB29_h
#include "CXODDB29.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSUS21_h
#include "CXODUS21.hpp"
#endif
#ifndef CXOSDB26_h
#include "CXODDB26.hpp"
#endif
#ifndef CXOSDB08_h
#include "CXODDB08.hpp"
#endif
#ifndef CXOSBC25_h
#include "CXODBC25.hpp"
#endif
#ifndef CXOSMZ11_h
#include "CXODMZ11.hpp"
#endif


//## begin module%639CCAA902F5.declarations preserve=no
//## end module%639CCAA902F5.declarations

//## begin module%639CCAA902F5.additionalDeclarations preserve=yes
//## end module%639CCAA902F5.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::StatusFolder 

StatusFolder::StatusFolder()
  //## begin StatusFolder::StatusFolder%639CA7B50391_const.hasinit preserve=no
      : m_pEmail(0)
  //## end StatusFolder::StatusFolder%639CA7B50391_const.hasinit
  //## begin StatusFolder::StatusFolder%639CA7B50391_const.initialization preserve=yes
  //## end StatusFolder::StatusFolder%639CA7B50391_const.initialization
{
  //## begin metaoperator::StatusFolder::StatusFolder%639CA7B50391_const.body preserve=yes
   memcpy(m_sID,"MZ11",4);
  //## end metaoperator::StatusFolder::StatusFolder%639CA7B50391_const.body
}


StatusFolder::~StatusFolder()
{
  //## begin metaoperator::StatusFolder::~StatusFolder%639CA7B50391_dest.body preserve=yes
  //## end metaoperator::StatusFolder::~StatusFolder%639CA7B50391_dest.body
}



//## Other Operations (implementation)
bool StatusFolder::report (command::Email* pEmail)
{
  //## begin metaoperator::StatusFolder::report%639CCCB00022.body preserve=yes
   m_pEmail = pEmail;
   m_pEmail->report('S');
   report("GMT Clock",GMTClock::instance()->getStatus());
   report("Totals Progress",entitysegment::Progress::instance()->getStatus(0));
   if (Extract::instance()->getCustomCode() == "MPS")
      report("MAS Progress",entitysegment::Progress::instance()->getStatus(1));
   report("Local Clock",Clock::instance()->getStatus());
   report("Last Business Day Closed",entitysegment::SwitchBusinessDay::instance()->getStatus(0));
   if (Extract::instance()->getCustomCode() == "MPS")
      report("Last Business Day Rolled",Compactor::instance()->getStatus());
   string strStatus("0");
   Query hQuery;
   hQuery.bind("PROBLEM_TRAN","*",Column::STRING,&strStatus,0,"COUNT");
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   pSelectStatement->execute(hQuery);
   report("Problem Transactions",make_pair(strStatus,strStatus == "0" ? 0 : 1));
   report("Last File Exported",FileFactory::instance()->getStatus(0));
   report("Last Transaction Totaled",SwitchClock::instance()->getStatus());
   report("Next File To Export",FileFactory::instance()->getStatus(1));
   report("Next Business Day To Close",entitysegment::SwitchBusinessDay::instance()->getStatus(1));
   database::Status::instance()->attach(this);
   Channel hChannel;
   hChannel.getStatus();
   database::Status::instance()->detach(this);
   return true;
  //## end metaoperator::StatusFolder::report%639CCCB00022.body
}

bool StatusFolder::report (const char* pszName, const pair<string,int>& hItem)
{
  //## begin metaoperator::StatusFolder::report%639CCD9102E1.body preserve=yes
   char* pszStatus[3] = {"OK","WARNING","FAILING"};
   usersegment::EmailSegment::instance()->setField("Name",pszName);
   usersegment::EmailSegment::instance()->setField("Value",hItem.first);
   usersegment::EmailSegment::instance()->setField("Status",pszStatus[hItem.second]);
   return m_pEmail->report('E');
  //## end metaoperator::StatusFolder::report%639CCD9102E1.body
}

void StatusFolder::update (Subject* pSubject)
{
  //## begin metaoperator::StatusFolder::update%639CA7EB02FD.body preserve=yes
   string strName(database::Status::instance()->getTASKID() + " Channel");
   report(strName.c_str(),database::Status::instance()->getStatus());
  //## end metaoperator::StatusFolder::update%639CA7EB02FD.body
}

// Additional Declarations
  //## begin metaoperator::StatusFolder%639CA7B50391.declarations preserve=yes
  //## end metaoperator::StatusFolder%639CA7B50391.declarations

} // namespace metaoperator

//## begin module%639CCAA902F5.epilog preserve=yes
//## end module%639CCAA902F5.epilog
