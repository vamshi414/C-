//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6234D71003E2.cm preserve=no
//## end module%6234D71003E2.cm

//## begin module%6234D71003E2.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6234D71003E2.cp

//## Module: CXOSMZ01%6234D71003E2; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ01.cpp

//## begin module%6234D71003E2.additionalIncludes preserve=no
//## end module%6234D71003E2.additionalIncludes

//## begin module%6234D71003E2.includes preserve=yes
#include <sstream>
//## end module%6234D71003E2.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSMZ04_h
#include "CXODMZ04.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMZ14_h
#include "CXODMZ14.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSMZ25_h
#include "CXODMZ25.hpp"
#endif
#ifndef CXOSMZ01_h
#include "CXODMZ01.hpp"
#endif


//## begin module%6234D71003E2.declarations preserve=no
//## end module%6234D71003E2.declarations

//## begin module%6234D71003E2.additionalDeclarations preserve=yes
//## end module%6234D71003E2.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::Rule 


//## begin metaoperator::Rule::<m_pRule>%649366ED03D2.role preserve=no  public: static metaoperator::Rule { -> RFHgN}
Rule *Rule::m_pRule = 0;
//## end metaoperator::Rule::<m_pRule>%649366ED03D2.role

Rule::Rule()
  //## begin Rule::Rule%6234A6A90246_const.hasinit preserve=no
  //## end Rule::Rule%6234A6A90246_const.hasinit
  //## begin Rule::Rule%6234A6A90246_const.initialization preserve=yes
  //## end Rule::Rule%6234A6A90246_const.initialization
{
  //## begin metaoperator::Rule::Rule%6234A6A90246_const.body preserve=yes
   memcpy(m_sID,"MZ01",4);
  //## end metaoperator::Rule::Rule%6234A6A90246_const.body
}

Rule::Rule (const char* pszBuffer)
  //## begin metaoperator::Rule::Rule%6234E07A01F8.hasinit preserve=no
  //## end metaoperator::Rule::Rule%6234E07A01F8.hasinit
  //## begin metaoperator::Rule::Rule%6234E07A01F8.initialization preserve=yes
   :m_strName(pszBuffer)
  //## end metaoperator::Rule::Rule%6234E07A01F8.initialization
{
  //## begin metaoperator::Rule::Rule%6234E07A01F8.body preserve=yes
   memcpy(m_sID,"MZ01",4);
  //## end metaoperator::Rule::Rule%6234E07A01F8.body
}


Rule::~Rule()
{
  //## begin metaoperator::Rule::~Rule%6234A6A90246_dest.body preserve=yes
  //## end metaoperator::Rule::~Rule%6234A6A90246_dest.body
}



//## Other Operations (implementation)
void Rule::add (const string& strBuffer)
{
  //## begin metaoperator::Rule::add%6234A7DB0194.body preserve=yes
   if (strBuffer[0] == 'C')
   {
      vector<string> hToken;
      Buffer::parse(strBuffer," ",hToken);
      Condition* c = ConditionFactory::instance()->create(hToken[1]);
      if (!c)
      {
         c = ConditionFactory::instance()->create(hToken[2]);
         if (!c)
            return;
      }
      c->setToken(hToken);
      m_hCondition.push_back(c);
   }
   else
   if (strBuffer[0] == 'F')
   {
      vector<string> hToken;
      Buffer::parse(strBuffer," ",hToken);
      Function* f = FunctionFactory::instance()->create(hToken[1]);
      if (!f)
         f = new Function(); // for ++ and --
      if (hToken[1] == "cp"
         && hToken.size() > 3)
      {
         vector<string> hCopy;
         for (int i = 0;i < 4;++i)
            hCopy.push_back(hToken[i]);
         Function* f = FunctionFactory::instance()->create(hToken[1]);
         hCopy[3] = "@TEMP";
         f->setToken(hCopy);
         m_hFunction.push_back(f);
         hToken[1] = "mv";
         string strTemp("@TEMP");
#ifdef _WIN32
         strTemp.append("\\",1);
#else
         strTemp.append("/",1);
#endif
         vector<string> hPath;
         Buffer::parse(hToken[2],"\\/",hPath);
         strTemp += hPath[hPath.size() - 1];
         hToken[2] = strTemp;
      }
      f->setToken(hToken);
      m_hFunction.push_back(f);
   }
  //## end metaoperator::Rule::add%6234A7DB0194.body
}

bool Rule::check ()
{
  //## begin metaoperator::Rule::check%6234A79D0267.body preserve=yes
   m_pRule = this;
   Match::setResult(-1);
   Condition::setValue("DATE_RECON",entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(0));
   bool b = true;
   for (vector<Condition*>::iterator pCondition = m_hCondition.begin();pCondition != m_hCondition.end();++pCondition)
      b &= (*pCondition)->test();
   b &= Match::getResult() == 0 ? false : true;
   if (b == false
      && IF::Trace::getEnable())
   {
      std::ostringstream oss;
      oss << "Rule : " << m_strName << " -> Skipped";
      Trace::put(oss.str().data());
   }
   return b;
  //## end metaoperator::Rule::check%6234A79D0267.body
}

bool Rule::execute ()
{
  //## begin metaoperator::Rule::execute%6393772E0253.body preserve=yes
   m_pRule = this;
   string strRESOURCE_KEY;
   Condition::setValue("PATH",strRESOURCE_KEY);
   int iSuccess = 0;
   for (vector<Function*>::iterator pFunction = m_hFunction.begin(); pFunction != m_hFunction.end(); ++pFunction)
   {
      if ((iSuccess = (*pFunction)->execute()) == -1)
      {
         if (IF::Trace::getEnable())
         {
            std::ostringstream oss;
            oss << "Function : " << (*pFunction)->m_hToken[1] << " -> Not Executed";
            Trace::put(oss.str().data());
         }
         break;
      }
   }
   if (iSuccess == -1)
   {
      Database::instance()->rollback();
      return false;
   }
   if (iSuccess == 0)
      return true;
   Condition::getValue("DATE_RECON",strRESOURCE_KEY);
   strRESOURCE_KEY.append(" ",1);
   strRESOURCE_KEY += m_strName;
   string strPath;
   Condition::getValue("PATH",strPath);
   if (!strPath.empty())
   {
      strRESOURCE_KEY.append(" ",1);
      strRESOURCE_KEY += strPath;
   }
   segment::AuditEvent x;
   x.captureEvent("MZ",4,0,"RULE",strRESOURCE_KEY);
   x.commitEvent(true);
   Database::instance()->commit();
   if (IF::Trace::getEnable())
   {
      std::ostringstream oss;
      oss << "Rule : " << m_strName << " -> Executed";
      Trace::put(oss.str().data());
   }
   return true;
  //## end metaoperator::Rule::execute%6393772E0253.body
}

// Additional Declarations
  //## begin metaoperator::Rule%6234A6A90246.declarations preserve=yes
  //## end metaoperator::Rule%6234A6A90246.declarations

} // namespace metaoperator

//## begin module%6234D71003E2.epilog preserve=yes
//## end module%6234D71003E2.epilog
