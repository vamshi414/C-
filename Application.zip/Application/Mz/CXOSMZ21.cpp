//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B4A4BE0364.cm preserve=no
//## end module%63B4A4BE0364.cm

//## begin module%63B4A4BE0364.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B4A4BE0364.cp

//## Module: CXOSMZ21%63B4A4BE0364; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ21.cpp

//## begin module%63B4A4BE0364.additionalIncludes preserve=no
//## end module%63B4A4BE0364.additionalIncludes

//## begin module%63B4A4BE0364.includes preserve=yes
#include "CXODTM06.hpp"
//## end module%63B4A4BE0364.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU28_h
#include "CXODRU28.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSMZ02_h
#include "CXODMZ02.hpp"
#endif
#ifndef CXOSMZ21_h
#include "CXODMZ21.hpp"
#endif


//## begin module%63B4A4BE0364.declarations preserve=no
//## end module%63B4A4BE0364.declarations

//## begin module%63B4A4BE0364.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Function* createSetGlobalContext()
   {
      return new metaoperator::SetGlobalContext();
   }
   const bool registered = metaoperator::FunctionFactory::instance()->registerFunction("set",createSetGlobalContext);
}
//## end module%63B4A4BE0364.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::SetGlobalContext 

SetGlobalContext::SetGlobalContext()
  //## begin SetGlobalContext::SetGlobalContext%63B4A38900AC_const.hasinit preserve=no
  //## end SetGlobalContext::SetGlobalContext%63B4A38900AC_const.hasinit
  //## begin SetGlobalContext::SetGlobalContext%63B4A38900AC_const.initialization preserve=yes
  //## end SetGlobalContext::SetGlobalContext%63B4A38900AC_const.initialization
{
  //## begin metaoperator::SetGlobalContext::SetGlobalContext%63B4A38900AC_const.body preserve=yes
   memcpy(m_sID,"MZ21",4);
  //## end metaoperator::SetGlobalContext::SetGlobalContext%63B4A38900AC_const.body
}


SetGlobalContext::~SetGlobalContext()
{
  //## begin metaoperator::SetGlobalContext::~SetGlobalContext%63B4A38900AC_dest.body preserve=yes
  //## end metaoperator::SetGlobalContext::~SetGlobalContext%63B4A38900AC_dest.body
}



//## Other Operations (implementation)
int SetGlobalContext::execute ()
{
  //## begin metaoperator::SetGlobalContext::execute%63B4A3C903B2.body preserve=yes
   if (m_hToken.size() < 4)
      return -1;
   Table hTable("TASK_CONTEXT");
   hTable.setQualifier("CUSTQUAL");
   hTable.set("IMAGEID","*",false,true);
   hTable.set("TASKID","*",false,true);
   string strCONTEXT_TYPE(" ");
   hTable.set("CONTEXT_TYPE",strCONTEXT_TYPE,false,true);
   hTable.set("CONTEXT_KEY",m_hToken[2],false,true);
   string strCONTEXT_DATA;
   Condition::getValue(m_hToken[3],strCONTEXT_DATA);
   if (m_hToken.size() > 4
      && m_hToken[4] == "+"
      && m_hToken[5] == "1")
   {
      Date hDate(strCONTEXT_DATA.c_str());
      hDate += 1;
      strCONTEXT_DATA = hDate.asString("%Y%m%d");
   }
   hTable.set("CONTEXT_DATA",strCONTEXT_DATA,false,false);
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if (pUpdateStatement->execute(hTable) == false
      && pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND)
   {
      auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      if (pInsertStatement->execute(hTable) == false)
         return -1;
   }
   Condition::setValue(m_hToken[2],strCONTEXT_DATA);
   Database::instance()->commit();
   return 1;
  //## end metaoperator::SetGlobalContext::execute%63B4A3C903B2.body
}

// Additional Declarations
  //## begin metaoperator::SetGlobalContext%63B4A38900AC.declarations preserve=yes
  //## end metaoperator::SetGlobalContext%63B4A38900AC.declarations

} // namespace metaoperator

//## begin module%63B4A4BE0364.epilog preserve=yes
//## end module%63B4A4BE0364.epilog
