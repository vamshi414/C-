//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B4A47301AE.cm preserve=no
//## end module%63B4A47301AE.cm

//## begin module%63B4A47301AE.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B4A47301AE.cp

//## Module: CXOSMZ20%63B4A47301AE; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ20.cpp

//## begin module%63B4A47301AE.additionalIncludes preserve=no
//## end module%63B4A47301AE.additionalIncludes

//## begin module%63B4A47301AE.includes preserve=yes
//## end module%63B4A47301AE.includes

#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif
#ifndef CXOSMZ02_h
#include "CXODMZ02.hpp"
#endif
#ifndef CXOSMZ20_h
#include "CXODMZ20.hpp"
#endif


//## begin module%63B4A47301AE.declarations preserve=no
//## end module%63B4A47301AE.declarations

//## begin module%63B4A47301AE.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Function* createFTP()
   {
      return new metaoperator::FTP();
   }
   const bool registered = metaoperator::FunctionFactory::instance()->registerFunction("ftp",createFTP);
}
//## end module%63B4A47301AE.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::FTP 

FTP::FTP()
  //## begin FTP::FTP%63B4A357013D_const.hasinit preserve=no
  //## end FTP::FTP%63B4A357013D_const.hasinit
  //## begin FTP::FTP%63B4A357013D_const.initialization preserve=yes
  //## end FTP::FTP%63B4A357013D_const.initialization
{
  //## begin metaoperator::FTP::FTP%63B4A357013D_const.body preserve=yes
   memcpy(m_sID,"MZ20",4);
  //## end metaoperator::FTP::FTP%63B4A357013D_const.body
}


FTP::~FTP()
{
  //## begin metaoperator::FTP::~FTP%63B4A357013D_dest.body preserve=yes
  //## end metaoperator::FTP::~FTP%63B4A357013D_dest.body
}



//## Other Operations (implementation)
int FTP::execute ()
{
  //## begin metaoperator::FTP::execute%63B4A3700185.body preserve=yes
   if (m_hToken.size() < 4)
      return -1;
   string strDX_FILE_TYPE;
   Condition::getValue("DX_FILE_TYPE",strDX_FILE_TYPE);
   string strDATE_RECON;
   Condition::getValue("DATE_RECON",strDATE_RECON);
   strDATE_RECON.replace(0,2,"D",1);
   string strPath(m_hToken[2]);
   Condition::substitute(strPath);
   return Job::submit(m_hToken[3].c_str(),"&PATH   ",strPath.c_str(),"&DXTYPE ",strDX_FILE_TYPE.c_str(),"&DXDATE ",strDATE_RECON.c_str()) ? 1 : -1;
  //## end metaoperator::FTP::execute%63B4A3700185.body
}

// Additional Declarations
  //## begin metaoperator::FTP%63B4A357013D.declarations preserve=yes
  //## end metaoperator::FTP%63B4A357013D.declarations

} // namespace metaoperator

//## begin module%63B4A47301AE.epilog preserve=yes
//## end module%63B4A47301AE.epilog
