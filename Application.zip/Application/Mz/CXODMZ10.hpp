//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6397F7E90326.cm preserve=no
//## end module%6397F7E90326.cm

//## begin module%6397F7E90326.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6397F7E90326.cp

//## Module: CXOSMZ10%6397F7E90326; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ10.hpp

#ifndef CXOSMZ10_h
#define CXOSMZ10_h 1

//## begin module%6397F7E90326.additionalIncludes preserve=no
//## end module%6397F7E90326.additionalIncludes

//## begin module%6397F7E90326.includes preserve=yes
//## end module%6397F7E90326.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
class SettlementFolder;
class AuditFolder;
class ReconciliationFileFolder;
class ClearingFolder;
class StatusFolder;
} // namespace metaoperator

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class HourAlarm;
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ContactSegment;
} // namespace segment

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class EmailSegment;
} // namespace usersegment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Email;
} // namespace command

namespace metaoperator {
class ExportFileFolder;

} // namespace metaoperator

//## begin module%6397F7E90326.declarations preserve=no
//## end module%6397F7E90326.declarations

//## begin module%6397F7E90326.additionalDeclarations preserve=yes
//## end module%6397F7E90326.additionalDeclarations


namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::StatusEmail%6397F6920027.preface preserve=yes
//## end metaoperator::StatusEmail%6397F6920027.preface

//## Class: StatusEmail%6397F6920027
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6397F8C103E7;timer::HourAlarm { -> F}
//## Uses: <unnamed>%6397FA7B0280;usersegment::EmailSegment { -> F}
//## Uses: <unnamed>%6397FAEA0247;IF::Extract { -> F}
//## Uses: <unnamed>%6397FB140199;segment::ContactSegment { -> F}
//## Uses: <unnamed>%6397FC710089;timer::Clock { -> F}
//## Uses: <unnamed>%63987EFF0264;reusable::Query { -> F}
//## Uses: <unnamed>%63987F02035A;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%63987F0600D1;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%639CD22102B0;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%639CD28E0006;database::Database { -> F}
//## Uses: <unnamed>%639CD7E90395;StatusFolder { -> F}
//## Uses: <unnamed>%639CDBF6001B;ClearingFolder { -> F}
//## Uses: <unnamed>%63AC52E90320;ReconciliationFileFolder { -> F}
//## Uses: <unnamed>%63FE49E000B8;AuditFolder { -> F}
//## Uses: <unnamed>%66200BB80067;SettlementFolder { -> F}
//## Uses: <unnamed>%662960E90144;ExportFileFolder { -> F}

class DllExport StatusEmail : public reusable::Observer  //## Inherits: <unnamed>%6397F7760147
{
  //## begin metaoperator::StatusEmail%6397F6920027.initialDeclarations preserve=yes
  //## end metaoperator::StatusEmail%6397F6920027.initialDeclarations

  public:
    //## Constructors (generated)
      StatusEmail();

    //## Destructor (generated)
      virtual ~StatusEmail();


    //## Other Operations (specified)
      //## Operation: initialize%63987DDE0111
      bool initialize ();

      //## Operation: send%6397F91002D7
      bool send ();

      //## Operation: update%6397F7A80112
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin metaoperator::StatusEmail%6397F6920027.public preserve=yes
      //## end metaoperator::StatusEmail%6397F6920027.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::StatusEmail%6397F6920027.protected preserve=yes
      //## end metaoperator::StatusEmail%6397F6920027.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::StatusEmail%6397F6920027.private preserve=yes
      //## end metaoperator::StatusEmail%6397F6920027.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%63989CD70220
      //## Role: StatusEmail::<m_pEmail>%63989CD802AD
      //## begin metaoperator::StatusEmail::<m_pEmail>%63989CD802AD.role preserve=no  public: command::Email { -> RFHgN}
      command::Email *m_pEmail;
      //## end metaoperator::StatusEmail::<m_pEmail>%63989CD802AD.role

    // Additional Implementation Declarations
      //## begin metaoperator::StatusEmail%6397F6920027.implementation preserve=yes
      //## end metaoperator::StatusEmail%6397F6920027.implementation

};

//## begin metaoperator::StatusEmail%6397F6920027.postscript preserve=yes
//## end metaoperator::StatusEmail%6397F6920027.postscript

} // namespace metaoperator

//## begin module%6397F7E90326.epilog preserve=yes
//## end module%6397F7E90326.epilog


#endif
