//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6438617B003B.cm preserve=no
//## end module%6438617B003B.cm

//## begin module%6438617B003B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6438617B003B.cp

//## Module: CXOSMZ23%6438617B003B; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ23.cpp

//## begin module%6438617B003B.additionalIncludes preserve=no
//## end module%6438617B003B.additionalIncludes

//## begin module%6438617B003B.includes preserve=yes
//## end module%6438617B003B.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSUS21_h
#include "CXODUS21.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSBC25_h
#include "CXODBC25.hpp"
#endif
#ifndef CXOSMZ23_h
#include "CXODMZ23.hpp"
#endif


//## begin module%6438617B003B.declarations preserve=no
//## end module%6438617B003B.declarations

//## begin module%6438617B003B.additionalDeclarations preserve=yes
//## end module%6438617B003B.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::FileFolder 

FileFolder::FileFolder()
  //## begin FileFolder::FileFolder%643860CF02F2_const.hasinit preserve=no
      : m_iITEM_COUNT(0),
        m_pEmail(0)
  //## end FileFolder::FileFolder%643860CF02F2_const.hasinit
  //## begin FileFolder::FileFolder%643860CF02F2_const.initialization preserve=yes
  //## end FileFolder::FileFolder%643860CF02F2_const.initialization
{
  //## begin metaoperator::FileFolder::FileFolder%643860CF02F2_const.body preserve=yes
   memcpy(m_sID,"MZ23",4);
  //## end metaoperator::FileFolder::FileFolder%643860CF02F2_const.body
}


FileFolder::~FileFolder()
{
  //## begin metaoperator::FileFolder::~FileFolder%643860CF02F2_dest.body preserve=yes
  //## end metaoperator::FileFolder::~FileFolder%643860CF02F2_dest.body
}



//## Other Operations (implementation)
bool FileFolder::report (command::Email* pEmail)
{
  //## begin metaoperator::FileFolder::report%6438613E0029.body preserve=yes
   m_pEmail = pEmail;
   m_pEmail->report('I');
   Query hQuery;
   hQuery.attach(this);
   hQuery.setQualifier("QUALIFY","SYS_HEALTH_MON");
   hQuery.bind("SYS_HEALTH_MON","MEMBER_NAME",Column::STRING,&m_strMEMBER_NAME);
   hQuery.bind("SYS_HEALTH_MON","BUCKET",Column::STRING,&m_strBUCKET);
   hQuery.bind("SYS_HEALTH_MON","ITEM_COUNT",Column::LONG,&m_iITEM_COUNT,0,"SUM");
   hQuery.setBasicPredicate("SYS_HEALTH_MON","DOMAIN_NAME","=","OCSFILE");
   hQuery.setBasicPredicate("SYS_HEALTH_MON","TIME_PERIOD",">=",timer::MidnightAlarm::instance()->getYesterday().c_str());
   hQuery.setGroupByClause("MEMBER_NAME,BUCKET");
   hQuery.setOrderByClause("MEMBER_NAME,BUCKET");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(hQuery) == false
      || pSelectStatement->getRows() == 0)
      return false;
   return true;
  //## end metaoperator::FileFolder::report%6438613E0029.body
}

void FileFolder::update (Subject* pSubject)
{
  //## begin metaoperator::FileFolder::update%643861210140.body preserve=yes
   usersegment::EmailSegment::instance()->setField("MEMBER_NAME",m_strMEMBER_NAME);
   usersegment::EmailSegment::instance()->setField("BUCKET",m_strBUCKET);
   char szTemp[PERCENTD];
   snprintf(szTemp,PERCENTD,"%d",m_iITEM_COUNT);
   usersegment::EmailSegment::instance()->setField("ITEM_COUNT",szTemp);
   m_pEmail->report('J');
  //## end metaoperator::FileFolder::update%643861210140.body
}

// Additional Declarations
  //## begin metaoperator::FileFolder%643860CF02F2.declarations preserve=yes
  //## end metaoperator::FileFolder%643860CF02F2.declarations

} // namespace metaoperator

//## begin module%6438617B003B.epilog preserve=yes
//## end module%6438617B003B.epilog
