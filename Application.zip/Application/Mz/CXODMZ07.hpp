//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6390A63F00C4.cm preserve=no
//## end module%6390A63F00C4.cm

//## begin module%6390A63F00C4.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6390A63F00C4.cp

//## Module: CXOSMZ07%6390A63F00C4; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ07.hpp

#ifndef CXOSMZ07_h
#define CXOSMZ07_h 1

//## begin module%6390A63F00C4.additionalIncludes preserve=no
//## end module%6390A63F00C4.additionalIncludes

//## begin module%6390A63F00C4.includes preserve=yes
//## end module%6390A63F00C4.includes

#ifndef CXOSMZ03_h
#include "CXODMZ03.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class ExportFile;

} // namespace database

//## begin module%6390A63F00C4.declarations preserve=no
//## end module%6390A63F00C4.declarations

//## begin module%6390A63F00C4.additionalDeclarations preserve=yes
//## end module%6390A63F00C4.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::ExportFileClose%6390A5B400C5.preface preserve=yes
//## end metaoperator::ExportFileClose%6390A5B400C5.preface

//## Class: ExportFileClose%6390A5B400C5
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6390A62002ED;database::ExportFile { -> F}

class DllExport ExportFileClose : public Function  //## Inherits: <unnamed>%6390A5CE02F2
{
  //## begin metaoperator::ExportFileClose%6390A5B400C5.initialDeclarations preserve=yes
  //## end metaoperator::ExportFileClose%6390A5B400C5.initialDeclarations

  public:
    //## Constructors (generated)
      ExportFileClose();

    //## Destructor (generated)
      virtual ~ExportFileClose();


    //## Other Operations (specified)
      //## Operation: execute%6390A5D40371
      virtual int execute ();

    // Additional Public Declarations
      //## begin metaoperator::ExportFileClose%6390A5B400C5.public preserve=yes
      //## end metaoperator::ExportFileClose%6390A5B400C5.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::ExportFileClose%6390A5B400C5.protected preserve=yes
      //## end metaoperator::ExportFileClose%6390A5B400C5.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::ExportFileClose%6390A5B400C5.private preserve=yes
      //## end metaoperator::ExportFileClose%6390A5B400C5.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin metaoperator::ExportFileClose%6390A5B400C5.implementation preserve=yes
      //## end metaoperator::ExportFileClose%6390A5B400C5.implementation

};

//## begin metaoperator::ExportFileClose%6390A5B400C5.postscript preserve=yes
//## end metaoperator::ExportFileClose%6390A5B400C5.postscript

} // namespace metaoperator

//## begin module%6390A63F00C4.epilog preserve=yes
//## end module%6390A63F00C4.epilog


#endif
