//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65B2AAFA0037.cm preserve=no
//## end module%65B2AAFA0037.cm

//## begin module%65B2AAFA0037.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65B2AAFA0037.cp

//## Module: CXOSMZ25%65B2AAFA0037; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ25.hpp

#ifndef CXOSMZ25_h
#define CXOSMZ25_h 1

//## begin module%65B2AAFA0037.additionalIncludes preserve=no
//## end module%65B2AAFA0037.additionalIncludes

//## begin module%65B2AAFA0037.includes preserve=yes
//## end module%65B2AAFA0037.includes

#ifndef CXOSMZ02_h
#include "CXODMZ02.hpp"
#endif
//## begin module%65B2AAFA0037.declarations preserve=no
//## end module%65B2AAFA0037.declarations

//## begin module%65B2AAFA0037.additionalDeclarations preserve=yes
//## end module%65B2AAFA0037.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::Match%65B2AA9F02E5.preface preserve=yes
//## end metaoperator::Match%65B2AA9F02E5.preface

//## Class: Match%65B2AA9F02E5
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport Match : public Condition  //## Inherits: <unnamed>%65B2AABC0227
{
  //## begin metaoperator::Match%65B2AA9F02E5.initialDeclarations preserve=yes
  //## end metaoperator::Match%65B2AA9F02E5.initialDeclarations

  public:
    //## Constructors (generated)
      Match();

    //## Destructor (generated)
      virtual ~Match();


    //## Other Operations (specified)
      //## Operation: setToken%65B2AE680170
      virtual void setToken (const vector<string>& hToken);

      //## Operation: test%65B2AAC403E6
      virtual bool test ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Result%65DF96C801FD
      static const short getResult ()
      {
        //## begin metaoperator::Match::getResult%65DF96C801FD.get preserve=no
        return m_siResult;
        //## end metaoperator::Match::getResult%65DF96C801FD.get
      }

      static void setResult (short value)
      {
        //## begin metaoperator::Match::setResult%65DF96C801FD.set preserve=no
        m_siResult = value;
        //## end metaoperator::Match::setResult%65DF96C801FD.set
      }


    // Additional Public Declarations
      //## begin metaoperator::Match%65B2AA9F02E5.public preserve=yes
      //## end metaoperator::Match%65B2AA9F02E5.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::Match%65B2AA9F02E5.protected preserve=yes
      //## end metaoperator::Match%65B2AA9F02E5.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::Match%65B2AA9F02E5.private preserve=yes
      //## end metaoperator::Match%65B2AA9F02E5.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin metaoperator::Match::Result%65DF96C801FD.attr preserve=no  public: static short {V} -1
      static short m_siResult;
      //## end metaoperator::Match::Result%65DF96C801FD.attr

    // Additional Implementation Declarations
      //## begin metaoperator::Match%65B2AA9F02E5.implementation preserve=yes
      //## end metaoperator::Match%65B2AA9F02E5.implementation

};

//## begin metaoperator::Match%65B2AA9F02E5.postscript preserve=yes
//## end metaoperator::Match%65B2AA9F02E5.postscript

} // namespace metaoperator

//## begin module%65B2AAFA0037.epilog preserve=yes
//## end module%65B2AAFA0037.epilog


#endif
