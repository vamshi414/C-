//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6234D6AE03D4.cm preserve=no
//## end module%6234D6AE03D4.cm

//## begin module%6234D6AE03D4.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6234D6AE03D4.cp

//## Module: CXOPMZ00%6234D6AE03D4; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ00.hpp

#ifndef CXOPMZ00_h
#define CXOPMZ00_h 1

//## begin module%6234D6AE03D4.additionalIncludes preserve=no
//## end module%6234D6AE03D4.additionalIncludes

//## begin module%6234D6AE03D4.includes preserve=yes
#include <vector>
//## end module%6234D6AE03D4.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSMZ10_h
#include "CXODMZ10.hpp"
#endif
#ifndef CXOSMZ01_h
#include "CXODMZ01.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Processor;
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
class Condition;
} // namespace metaoperator

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

namespace metaoperator {
class ExportFileFolder;
} // namespace metaoperator

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MidnightAlarm;
class MinuteTimer;
class Date;
} // namespace timer

namespace IF {
class Extract;
class Sleep;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class Database;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class AuditEvent;

} // namespace segment

//## begin module%6234D6AE03D4.declarations preserve=no
//## end module%6234D6AE03D4.declarations

//## begin module%6234D6AE03D4.additionalDeclarations preserve=yes
//## end module%6234D6AE03D4.additionalDeclarations


namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::MetaOperator%6234A650019D.preface preserve=yes
//## end metaoperator::MetaOperator%6234A650019D.preface

//## Class: MetaOperator%6234A650019D
//	<body>
//	<title>CG
//	<h1>MZ
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The Meta Operator ...
//	</p>
//	</body>
//	<body>
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6234AB91003F;IF::FlatFile { -> F}
//## Uses: <unnamed>%6234ABB30237;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%6234ABD10198;database::Database { -> F}
//## Uses: <unnamed>%6234CC8B0257;Condition { -> F}
//## Uses: <unnamed>%6234E1860169;IF::Trace { -> F}
//## Uses: <unnamed>%6234EF85002A;reusable::Buffer { -> F}
//## Uses: <unnamed>%6234F9C30012;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%6373DC1202AA;monitor::UseCase { -> F}
//## Uses: <unnamed>%6373DC160099;timer::Date { -> F}
//## Uses: <unnamed>%6373ED9E02C7;database::GlobalContext { -> F}
//## Uses: <unnamed>%65B3D87E0008;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%65B3D8980308;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%65B3D8BC0140;IF::Extract { -> F}
//## Uses: <unnamed>%65B3D9430392;IF::Sleep { -> F}
//## Uses: <unnamed>%65B3D96502C0;segment::AuditEvent { -> F}
//## Uses: <unnamed>%662973CF0303;ExportFileFolder { -> F}
//## Uses: <unnamed>%66AB869C0295;entitysegment::Processor { -> F}

class DllExport MetaOperator : public process::Application  //## Inherits: <unnamed>%6234A66901EF
{
  //## begin metaoperator::MetaOperator%6234A650019D.initialDeclarations preserve=yes
  //## end metaoperator::MetaOperator%6234A650019D.initialDeclarations

  public:
    //## Constructors (generated)
      MetaOperator();

    //## Destructor (generated)
      virtual ~MetaOperator();


    //## Other Operations (specified)
      //## Operation: generate%66AAFB6303AA
      void generate (const vector<string>& hMacro, const vector<string>& hVariables, vector<string>& hDX_FILE_TYPE);

      //## Operation: initialize%6234A6830366
      virtual int initialize ();

      //## Operation: parse%66AA54FE0085
      void parse (const string& strBuffer, vector<string>& hDX_FILE_TYPE);

      //## Operation: put%6373DBB7016F
      static bool put (const string& strCONTEXT_KEY, const char* pszCONTEXT_DATA);

      //## Operation: update%6234A68B01AE
      //	Interprets the inbound Message and calls:
      //
      //	   Application::onConfirm
      //	   Application::onMessage
      //	   Application::onNotify
      //	   Application::onQuiesce
      //	   Application::onRefresh
      //	   Application::onReset
      //	   Application::shutdown
      //	   Timer::elapsed
      virtual void update (Subject* pSubject);

    //## Get and Set Operations for Associations (generated)

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%6234CC2603BC
      //## Role: MetaOperator::<m_hRule>%6234CC270310
      vector<Rule>& getRule ()
      {
        //## begin metaoperator::MetaOperator::getRule%6234CC270310.get preserve=no
        return m_hRule;
        //## end metaoperator::MetaOperator::getRule%6234CC270310.get
      }


    // Additional Public Declarations
      //## begin metaoperator::MetaOperator%6234A650019D.public preserve=yes
      //## end metaoperator::MetaOperator%6234A650019D.public

  protected:

    //## Other Operations (specified)
      //## Operation: onReset%6373DAAE023A
      virtual int onReset (Message& hMessage);

    // Additional Protected Declarations
      //## begin metaoperator::MetaOperator%6234A650019D.protected preserve=yes
      //## end metaoperator::MetaOperator%6234A650019D.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::MetaOperator%6234A650019D.private preserve=yes
      //## end metaoperator::MetaOperator%6234A650019D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CONTEXT_DATA%6373DE3400A1
      //## begin metaoperator::MetaOperator::CONTEXT_DATA%6373DE3400A1.attr preserve=no  private: string {U} 
      string m_strCONTEXT_DATA;
      //## end metaoperator::MetaOperator::CONTEXT_DATA%6373DE3400A1.attr

      //## Attribute: GlobalContext%6373EDA50075
      //## begin metaoperator::MetaOperator::GlobalContext%6373EDA50075.attr preserve=no  private: static map<reusable::string, database::GlobalContext *, less<reusable::string> >* {V} 0
      static map<reusable::string, database::GlobalContext *, less<reusable::string> >* m_pGlobalContext;
      //## end metaoperator::MetaOperator::GlobalContext%6373EDA50075.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%6234CC2603BC
      //## begin metaoperator::MetaOperator::<m_hRule>%6234CC270310.role preserve=no  public: metaoperator::Rule {1 -> 0..nVHgN}
      vector<Rule> m_hRule;
      //## end metaoperator::MetaOperator::<m_hRule>%6234CC270310.role

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%6397F88502AC
      //## Role: MetaOperator::<m_hStatusEmail>%6397F88603A0
      //## begin metaoperator::MetaOperator::<m_hStatusEmail>%6397F88603A0.role preserve=no  public: metaoperator::StatusEmail { -> VHgN}
      StatusEmail m_hStatusEmail;
      //## end metaoperator::MetaOperator::<m_hStatusEmail>%6397F88603A0.role

    // Additional Implementation Declarations
      //## begin metaoperator::MetaOperator%6234A650019D.implementation preserve=yes
      //## end metaoperator::MetaOperator%6234A650019D.implementation

};

//## begin metaoperator::MetaOperator%6234A650019D.postscript preserve=yes
//## end metaoperator::MetaOperator%6234A650019D.postscript

} // namespace metaoperator

//## begin module%6234D6AE03D4.epilog preserve=yes
//## end module%6234D6AE03D4.epilog


#endif
