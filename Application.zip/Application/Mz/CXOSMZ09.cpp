//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6392A0330347.cm preserve=no
//## end module%6392A0330347.cm

//## begin module%6392A0330347.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6392A0330347.cp

//## Module: CXOSMZ09%6392A0330347; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ09.cpp

//## begin module%6392A0330347.additionalIncludes preserve=no
//## end module%6392A0330347.additionalIncludes

//## begin module%6392A0330347.includes preserve=yes
#include <sstream>
//## end module%6392A0330347.includes

#ifndef CXOSIF42_h
#include "CXODIF42.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSMZ09_h
#include "CXODMZ09.hpp"
#endif


//## begin module%6392A0330347.declarations preserve=no
//## end module%6392A0330347.declarations

//## begin module%6392A0330347.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Function* createBusinessDayClose()
   {
      return new metaoperator::BusinessDayClose();
   }
   const bool registered = metaoperator::FunctionFactory::instance()->registerFunction("CLOSE.BUSINESS.DAY",createBusinessDayClose);
}
//## end module%6392A0330347.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::BusinessDayClose 

BusinessDayClose::BusinessDayClose()
  //## begin BusinessDayClose::BusinessDayClose%63929FAA000D_const.hasinit preserve=no
  //## end BusinessDayClose::BusinessDayClose%63929FAA000D_const.hasinit
  //## begin BusinessDayClose::BusinessDayClose%63929FAA000D_const.initialization preserve=yes
  //## end BusinessDayClose::BusinessDayClose%63929FAA000D_const.initialization
{
  //## begin metaoperator::BusinessDayClose::BusinessDayClose%63929FAA000D_const.body preserve=yes
   memcpy(m_sID,"MZ09",4);
  //## end metaoperator::BusinessDayClose::BusinessDayClose%63929FAA000D_const.body
}


BusinessDayClose::~BusinessDayClose()
{
  //## begin metaoperator::BusinessDayClose::~BusinessDayClose%63929FAA000D_dest.body preserve=yes
  //## end metaoperator::BusinessDayClose::~BusinessDayClose%63929FAA000D_dest.body
}



//## Other Operations (implementation)
int BusinessDayClose::execute ()
{
  //## begin metaoperator::BusinessDayClose::execute%63929FCE0113.body preserve=yes
   bool iSuccess = 0;
   string strValue;
   string strData2("EOD     ");
   if ((iSuccess = Condition::getValue("@CLOSED+1",strValue)) ? 1 : -1)
   {
      strData2 += strValue;
      CommandMessage hCommandMessage(reusable::string("RESET"),strData2);
      string strQueue(Application::instance()->name().data(),2);
      strQueue += "TE";
      iSuccess = hCommandMessage.execute(strQueue.c_str()) ? 1 : -1;
   }
   if (IF::Trace::getEnable())
   {
      std::ostringstream oss;
      oss << "Function : " << m_hToken[1] << " -> " << strValue << " -> " << (iSuccess == 1 ? "True" : "False");
      Trace::put(oss.str().data());
   }
   return iSuccess;
  //## end metaoperator::BusinessDayClose::execute%63929FCE0113.body
}

// Additional Declarations
  //## begin metaoperator::BusinessDayClose%63929FAA000D.declarations preserve=yes
  //## end metaoperator::BusinessDayClose%63929FAA000D.declarations

} // namespace metaoperator

//## begin module%6392A0330347.epilog preserve=yes
//## end module%6392A0330347.epilog
