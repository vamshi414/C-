//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63AC518F0025.cm preserve=no
//## end module%63AC518F0025.cm

//## begin module%63AC518F0025.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63AC518F0025.cp

//## Module: CXOSMZ13%63AC518F0025; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ13.cpp

//## begin module%63AC518F0025.additionalIncludes preserve=no
//## end module%63AC518F0025.additionalIncludes

//## begin module%63AC518F0025.includes preserve=yes
//## end module%63AC518F0025.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSUS21_h
#include "CXODUS21.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSBC25_h
#include "CXODBC25.hpp"
#endif
#ifndef CXOSMZ13_h
#include "CXODMZ13.hpp"
#endif


//## begin module%63AC518F0025.declarations preserve=no
//## end module%63AC518F0025.declarations

//## begin module%63AC518F0025.additionalDeclarations preserve=yes
//## end module%63AC518F0025.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::ReconciliationFileFolder 

ReconciliationFileFolder::ReconciliationFileFolder()
  //## begin ReconciliationFileFolder::ReconciliationFileFolder%63AC507002C5_const.hasinit preserve=no
      : m_pEmail(0)
  //## end ReconciliationFileFolder::ReconciliationFileFolder%63AC507002C5_const.hasinit
  //## begin ReconciliationFileFolder::ReconciliationFileFolder%63AC507002C5_const.initialization preserve=yes
  //## end ReconciliationFileFolder::ReconciliationFileFolder%63AC507002C5_const.initialization
{
  //## begin metaoperator::ReconciliationFileFolder::ReconciliationFileFolder%63AC507002C5_const.body preserve=yes
   memcpy(m_sID,"MZ13",4);
  //## end metaoperator::ReconciliationFileFolder::ReconciliationFileFolder%63AC507002C5_const.body
}


ReconciliationFileFolder::~ReconciliationFileFolder()
{
  //## begin metaoperator::ReconciliationFileFolder::~ReconciliationFileFolder%63AC507002C5_dest.body preserve=yes
  //## end metaoperator::ReconciliationFileFolder::~ReconciliationFileFolder%63AC507002C5_dest.body
}



//## Other Operations (implementation)
bool ReconciliationFileFolder::report (command::Email* pEmail)
{
  //## begin metaoperator::ReconciliationFileFolder::report%63AC513B02B8.body preserve=yes
   m_pEmail = pEmail;
   m_pEmail->report('R');
   Query hQuery;
   hQuery.attach(this);
   hQuery.bind("AU_FILE_CONTROL","AU_FILE_NAME",Column::STRING,&m_strAU_FILE_NAME);
   hQuery.bind("AU_FILE_CONTROL","AU_STATE",Column::STRING,&m_strAU_STATE);
   hQuery.bind("AU_FILE_CONTROL","BIN",Column::STRING,&m_strBIN);
   hQuery.bind("AU_FILE_CONTROL","BIN_COUNT",Column::STRING,&m_strBIN_COUNT);
   hQuery.bind("AU_FILE_CONTROL","DATE_RECON",Column::STRING,&m_strDATE_RECON);
   hQuery.bind("AU_FILE_CONTROL","TASK_RECONCILED",Column::STRING,&m_strTASK_RECONCILED);
   hQuery.bind("AU_FILE_CONTROL","TSTAMP_TRANS_FROM",Column::STRING,&m_strTSTAMP_TRANS_FROM);
   hQuery.bind("AU_FILE_CONTROL","TSTAMP_TRANS_TO",Column::STRING,&m_strTSTAMP_TRANS_TO);
   hQuery.setBasicPredicate("AU_FILE_CONTROL","DATE_RECON","=",entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(0).c_str());
   hQuery.setOrderByClause("AU_FILE_NAME");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   return (pSelectStatement->execute(hQuery) == false
      || pSelectStatement->getRows() == 0);
  //## end metaoperator::ReconciliationFileFolder::report%63AC513B02B8.body
}

void ReconciliationFileFolder::update (Subject* pSubject)
{
  //## begin metaoperator::ReconciliationFileFolder::update%63AC50CB00CE.body preserve=yes
   usersegment::EmailSegment::instance()->setField("AU_FILE_NAME",m_strAU_FILE_NAME);
   usersegment::EmailSegment::instance()->setField("AU_STATE",m_strAU_STATE);
   usersegment::EmailSegment::instance()->setField("BIN",m_strBIN);
   usersegment::EmailSegment::instance()->setField("BIN_COUNT",m_strBIN_COUNT);
   usersegment::EmailSegment::instance()->setField("DATE_RECON",m_strDATE_RECON);
   usersegment::EmailSegment::instance()->setField("TASK_RECONCILED",m_strTASK_RECONCILED);
   usersegment::EmailSegment::instance()->setField("TSTAMP_TRANS_FROM",m_strTSTAMP_TRANS_FROM);
   usersegment::EmailSegment::instance()->setField("TSTAMP_TRANS_TO",m_strTSTAMP_TRANS_TO);
   m_pEmail->report('F');
  //## end metaoperator::ReconciliationFileFolder::update%63AC50CB00CE.body
}

// Additional Declarations
  //## begin metaoperator::ReconciliationFileFolder%63AC507002C5.declarations preserve=yes
  //## end metaoperator::ReconciliationFileFolder%63AC507002C5.declarations

} // namespace metaoperator

//## begin module%63AC518F0025.epilog preserve=yes
//## end module%63AC518F0025.epilog
