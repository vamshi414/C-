//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B4674702A3.cm preserve=no
//## end module%63B4674702A3.cm

//## begin module%63B4674702A3.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B4674702A3.cp

//## Module: CXOSMZ17%63B4674702A3; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ17.hpp

#ifndef CXOSMZ17_h
#define CXOSMZ17_h 1

//## begin module%63B4674702A3.additionalIncludes preserve=no
//## end module%63B4674702A3.additionalIncludes

//## begin module%63B4674702A3.includes preserve=yes
//## end module%63B4674702A3.includes

#ifndef CXOSMZ02_h
#include "CXODMZ02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%63B4674702A3.declarations preserve=no
//## end module%63B4674702A3.declarations

//## begin module%63B4674702A3.additionalDeclarations preserve=yes
//## end module%63B4674702A3.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::Report%63B464B00009.preface preserve=yes
//## end metaoperator::Report%63B464B00009.preface

//## Class: Report%63B464B00009
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%63B51DCD031C;reusable::Query { -> F}
//## Uses: <unnamed>%63B51DD00020;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%63B51DED023B;reusable::SelectStatement { -> F}

class DllExport Report : public Condition  //## Inherits: <unnamed>%63B464BD0156
{
  //## begin metaoperator::Report%63B464B00009.initialDeclarations preserve=yes
  //## end metaoperator::Report%63B464B00009.initialDeclarations

  public:
    //## Constructors (generated)
      Report();

    //## Destructor (generated)
      virtual ~Report();


    //## Other Operations (specified)
      //## Operation: test%63B464C501EC
      virtual bool test ();

    // Additional Public Declarations
      //## begin metaoperator::Report%63B464B00009.public preserve=yes
      //## end metaoperator::Report%63B464B00009.public
  protected:
    // Additional Protected Declarations
      //## begin metaoperator::Report%63B464B00009.protected preserve=yes
      //## end metaoperator::Report%63B464B00009.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::Report%63B464B00009.private preserve=yes
      //## end metaoperator::Report%63B464B00009.private
  private: //## implementation
    // Additional Implementation Declarations
      //## begin metaoperator::Report%63B464B00009.implementation preserve=yes
      //## end metaoperator::Report%63B464B00009.implementation

};

//## begin metaoperator::Report%63B464B00009.postscript preserve=yes
//## end metaoperator::Report%63B464B00009.postscript

} // namespace metaoperator

//## begin module%63B4674702A3.epilog preserve=yes
//## end module%63B4674702A3.epilog


#endif
