//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B45FBB00E5.cm preserve=no
//## end module%63B45FBB00E5.cm

//## begin module%63B45FBB00E5.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B45FBB00E5.cp

//## Module: CXOSMZ14%63B45FBB00E5; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ14.hpp

#ifndef CXOSMZ14_h
#define CXOSMZ14_h 1

//## begin module%63B45FBB00E5.additionalIncludes preserve=no
//## end module%63B45FBB00E5.additionalIncludes

//## begin module%63B45FBB00E5.includes preserve=yes
//## end module%63B45FBB00E5.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
class Condition;

} // namespace metaoperator

//## begin module%63B45FBB00E5.declarations preserve=no
//## end module%63B45FBB00E5.declarations

//## begin module%63B45FBB00E5.additionalDeclarations preserve=yes
//## end module%63B45FBB00E5.additionalDeclarations


namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::ConditionFactory%63B45ECB02A4.preface preserve=yes
//## end metaoperator::ConditionFactory%63B45ECB02A4.preface

//## Class: ConditionFactory%63B45ECB02A4
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%63B45EF502E4;Condition { -> F}

class DllExport ConditionFactory : public reusable::Object  //## Inherits: <unnamed>%63B45EE40123
{
  //## begin metaoperator::ConditionFactory%63B45ECB02A4.initialDeclarations preserve=yes
      typedef Condition* (*cloneFunction)();
  //## end metaoperator::ConditionFactory%63B45ECB02A4.initialDeclarations

  public:
    //## Constructors (generated)
      ConditionFactory();

    //## Destructor (generated)
      virtual ~ConditionFactory();


    //## Other Operations (specified)
      //## Operation: create%63B45F1A026D
      metaoperator::Condition* create (const reusable::string& strName);

      //## Operation: instance%63B45F1A0290
      static ConditionFactory* instance ();

      //## Operation: registerCondition%63B45F1A02A1
      bool registerCondition (const reusable::string& strName, cloneFunction hCloneFunction);

    // Additional Public Declarations
      //## begin metaoperator::ConditionFactory%63B45ECB02A4.public preserve=yes
      //## end metaoperator::ConditionFactory%63B45ECB02A4.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::ConditionFactory%63B45ECB02A4.protected preserve=yes
      //## end metaoperator::ConditionFactory%63B45ECB02A4.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::ConditionFactory%63B45ECB02A4.private preserve=yes
      //## end metaoperator::ConditionFactory%63B45ECB02A4.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Condition%63B45F0902E4
      //## begin metaoperator::ConditionFactory::Condition%63B45F0902E4.attr preserve=no  private: map<string,cloneFunction,less<string> > {U} 
      map<string,cloneFunction,less<string> > m_hCondition;
      //## end metaoperator::ConditionFactory::Condition%63B45F0902E4.attr

      //## Attribute: Instance%63B45F090302
      //## begin metaoperator::ConditionFactory::Instance%63B45F090302.attr preserve=no  private: static ConditionFactory* {V} 0
      static ConditionFactory* m_pInstance;
      //## end metaoperator::ConditionFactory::Instance%63B45F090302.attr

    // Additional Implementation Declarations
      //## begin metaoperator::ConditionFactory%63B45ECB02A4.implementation preserve=yes
      //## end metaoperator::ConditionFactory%63B45ECB02A4.implementation

};

//## begin metaoperator::ConditionFactory%63B45ECB02A4.postscript preserve=yes
//## end metaoperator::ConditionFactory%63B45ECB02A4.postscript

} // namespace metaoperator

//## begin module%63B45FBB00E5.epilog preserve=yes
//## end module%63B45FBB00E5.epilog


#endif
