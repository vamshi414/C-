//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B4679E0321.cm preserve=no
//## end module%63B4679E0321.cm

//## begin module%63B4679E0321.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B4679E0321.cp

//## Module: CXOSMZ18%63B4679E0321; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ18.hpp

#ifndef CXOSMZ18_h
#define CXOSMZ18_h 1

//## begin module%63B4679E0321.additionalIncludes preserve=no
//## end module%63B4679E0321.additionalIncludes

//## begin module%63B4679E0321.includes preserve=yes
//## end module%63B4679E0321.includes

#ifndef CXOSMZ02_h
#include "CXODMZ02.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
class Function;
class Rule;
} // namespace metaoperator

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class MidnightAlarm;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%63B4679E0321.declarations preserve=no
//## end module%63B4679E0321.declarations

//## begin module%63B4679E0321.additionalDeclarations preserve=yes
//## end module%63B4679E0321.additionalDeclarations


namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::Scrape%63B464EC02C9.preface preserve=yes
//## end metaoperator::Scrape%63B464EC02C9.preface

//## Class: Scrape%63B464EC02C9
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%63B47BAF02AE;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%63B47BB4011E;reusable::Query { -> F}
//## Uses: <unnamed>%63B47BB80355;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%63B4802B010E;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%63B4804F02DF;timer::Date { -> F}
//## Uses: <unnamed>%63B4809C0158;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%649367EC00E3;Rule { -> F}
//## Uses: <unnamed>%649367FA01B3;Function { -> F}

class DllExport Scrape : public Condition  //## Inherits: <unnamed>%63B464F80071
{
  //## begin metaoperator::Scrape%63B464EC02C9.initialDeclarations preserve=yes
  //## end metaoperator::Scrape%63B464EC02C9.initialDeclarations

  public:
    //## Constructors (generated)
      Scrape();

    //## Destructor (generated)
      virtual ~Scrape();


    //## Other Operations (specified)
      //## Operation: test%63B464FD0328
      virtual bool test ();

    // Additional Public Declarations
      //## begin metaoperator::Scrape%63B464EC02C9.public preserve=yes
      //## end metaoperator::Scrape%63B464EC02C9.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::Scrape%63B464EC02C9.protected preserve=yes
      //## end metaoperator::Scrape%63B464EC02C9.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::Scrape%63B464EC02C9.private preserve=yes
      //## end metaoperator::Scrape%63B464EC02C9.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin metaoperator::Scrape%63B464EC02C9.implementation preserve=yes
      //## end metaoperator::Scrape%63B464EC02C9.implementation

};

//## begin metaoperator::Scrape%63B464EC02C9.postscript preserve=yes
//## end metaoperator::Scrape%63B464EC02C9.postscript

} // namespace metaoperator

//## begin module%63B4679E0321.epilog preserve=yes
//## end module%63B4679E0321.epilog


#endif
