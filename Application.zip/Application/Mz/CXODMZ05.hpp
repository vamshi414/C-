//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%638FFC83023E.cm preserve=no
//## end module%638FFC83023E.cm

//## begin module%638FFC83023E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%638FFC83023E.cp

//## Module: CXOSMZ05%638FFC83023E; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ05.hpp

#ifndef CXOSMZ05_h
#define CXOSMZ05_h 1

//## begin module%638FFC83023E.additionalIncludes preserve=no
//## end module%638FFC83023E.additionalIncludes

//## begin module%638FFC83023E.includes preserve=yes
//## end module%638FFC83023E.includes

#ifndef CXOSMZ06_h
#include "CXODMZ06.hpp"
#endif
//## begin module%638FFC83023E.declarations preserve=no
//## end module%638FFC83023E.declarations

//## begin module%638FFC83023E.additionalDeclarations preserve=yes
//## end module%638FFC83023E.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::MoveFile%638FFC0C023F.preface preserve=yes
//## end metaoperator::MoveFile%638FFC0C023F.preface

//## Class: MoveFile%638FFC0C023F
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport MoveFile : public CopyFile  //## Inherits: <unnamed>%6390A33A03D3
{
  //## begin metaoperator::MoveFile%638FFC0C023F.initialDeclarations preserve=yes
  //## end metaoperator::MoveFile%638FFC0C023F.initialDeclarations

  public:
    //## Constructors (generated)
      MoveFile();

    //## Destructor (generated)
      virtual ~MoveFile();

    // Additional Public Declarations
      //## begin metaoperator::MoveFile%638FFC0C023F.public preserve=yes
      //## end metaoperator::MoveFile%638FFC0C023F.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::MoveFile%638FFC0C023F.protected preserve=yes
      //## end metaoperator::MoveFile%638FFC0C023F.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::MoveFile%638FFC0C023F.private preserve=yes
      //## end metaoperator::MoveFile%638FFC0C023F.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin metaoperator::MoveFile%638FFC0C023F.implementation preserve=yes
      //## end metaoperator::MoveFile%638FFC0C023F.implementation

};

//## begin metaoperator::MoveFile%638FFC0C023F.postscript preserve=yes
//## end metaoperator::MoveFile%638FFC0C023F.postscript

} // namespace metaoperator

//## begin module%638FFC83023E.epilog preserve=yes
//## end module%638FFC83023E.epilog


#endif
