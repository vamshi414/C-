//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6390A77C0305.cm preserve=no
//## end module%6390A77C0305.cm

//## begin module%6390A77C0305.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6390A77C0305.cp

//## Module: CXOSMZ08%6390A77C0305; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ08.cpp

//## begin module%6390A77C0305.additionalIncludes preserve=no
//## end module%6390A77C0305.additionalIncludes

//## begin module%6390A77C0305.includes preserve=yes
//## end module%6390A77C0305.includes

#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSMZ08_h
#include "CXODMZ08.hpp"
#endif


//## begin module%6390A77C0305.declarations preserve=no
//## end module%6390A77C0305.declarations

//## begin module%6390A77C0305.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Function* createExportFileTrigger()
   {
      return new metaoperator::ExportFileTrigger();
   }
   const bool registered = metaoperator::FunctionFactory::instance()->registerFunction("TRIGGER",createExportFileTrigger);
}
//## end module%6390A77C0305.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::ExportFileTrigger 

ExportFileTrigger::ExportFileTrigger()
  //## begin ExportFileTrigger::ExportFileTrigger%6390A72902A5_const.hasinit preserve=no
  //## end ExportFileTrigger::ExportFileTrigger%6390A72902A5_const.hasinit
  //## begin ExportFileTrigger::ExportFileTrigger%6390A72902A5_const.initialization preserve=yes
  //## end ExportFileTrigger::ExportFileTrigger%6390A72902A5_const.initialization
{
  //## begin metaoperator::ExportFileTrigger::ExportFileTrigger%6390A72902A5_const.body preserve=yes
   memcpy(m_sID,"MZ08",4);
  //## end metaoperator::ExportFileTrigger::ExportFileTrigger%6390A72902A5_const.body
}


ExportFileTrigger::~ExportFileTrigger()
{
  //## begin metaoperator::ExportFileTrigger::~ExportFileTrigger%6390A72902A5_dest.body preserve=yes
  //## end metaoperator::ExportFileTrigger::~ExportFileTrigger%6390A72902A5_dest.body
}



//## Other Operations (implementation)
int ExportFileTrigger::execute ()
{
  //## begin metaoperator::ExportFileTrigger::execute%6390A74802A8.body preserve=yes
   string strENTITY_ID;
   if (m_hToken.size() == 4)
      strENTITY_ID = m_hToken[3];
   else
      Condition::getValue("ENTITY_ID",strENTITY_ID);
   string strDATE_RECON;
   Condition::getValue("DATE_RECON",strDATE_RECON);
   if (m_strDATE_RECON == strDATE_RECON)
      return 0;
   ExportFile hExportFile(m_hToken[2],"AP",strENTITY_ID,strDATE_RECON,"240000");
   hExportFile.setDX_STATE("FW");
   hExportFile.setTSTAMP_INITIATED(Clock::instance()->getYYYYMMDDHHMMSSHN());
   if (!hExportFile.trigger())
      return -1;
   m_strDATE_RECON = strDATE_RECON;
   Database::instance()->commit();
   return 1;
  //## end metaoperator::ExportFileTrigger::execute%6390A74802A8.body
}

// Additional Declarations
  //## begin metaoperator::ExportFileTrigger%6390A72902A5.declarations preserve=yes
  //## end metaoperator::ExportFileTrigger%6390A72902A5.declarations

} // namespace metaoperator

//## begin module%6390A77C0305.epilog preserve=yes
//## end module%6390A77C0305.epilog
