//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63AC518C01CB.cm preserve=no
//## end module%63AC518C01CB.cm

//## begin module%63AC518C01CB.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63AC518C01CB.cp

//## Module: CXOSMZ13%63AC518C01CB; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ13.hpp

#ifndef CXOSMZ13_h
#define CXOSMZ13_h 1

//## begin module%63AC518C01CB.additionalIncludes preserve=no
//## end module%63AC518C01CB.additionalIncludes

//## begin module%63AC518C01CB.includes preserve=yes
//## end module%63AC518C01CB.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class EmailSegment;
} // namespace usersegment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Email;

} // namespace command

//## begin module%63AC518C01CB.declarations preserve=no
//## end module%63AC518C01CB.declarations

//## begin module%63AC518C01CB.additionalDeclarations preserve=yes
//## end module%63AC518C01CB.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::ReconciliationFileFolder%63AC507002C5.preface preserve=yes
//## end metaoperator::ReconciliationFileFolder%63AC507002C5.preface

//## Class: ReconciliationFileFolder%63AC507002C5
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%63AC50B0039E;reusable::Query { -> F}
//## Uses: <unnamed>%63AC50B201DE;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%63AC50B302FF;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%63AC50B5008E;usersegment::EmailSegment { -> F}
//## Uses: <unnamed>%63AC50B70211;entitysegment::SwitchBusinessDay { -> F}

class DllExport ReconciliationFileFolder : public reusable::Observer  //## Inherits: <unnamed>%63AC509D0078
{
  //## begin metaoperator::ReconciliationFileFolder%63AC507002C5.initialDeclarations preserve=yes
  //## end metaoperator::ReconciliationFileFolder%63AC507002C5.initialDeclarations

  public:
    //## Constructors (generated)
      ReconciliationFileFolder();

    //## Destructor (generated)
      virtual ~ReconciliationFileFolder();


    //## Other Operations (specified)
      //## Operation: report%63AC513B02B8
      bool report (command::Email* pEmail);

      //## Operation: update%63AC50CB00CE
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin metaoperator::ReconciliationFileFolder%63AC507002C5.public preserve=yes
      //## end metaoperator::ReconciliationFileFolder%63AC507002C5.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::ReconciliationFileFolder%63AC507002C5.protected preserve=yes
      //## end metaoperator::ReconciliationFileFolder%63AC507002C5.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::ReconciliationFileFolder%63AC507002C5.private preserve=yes
      //## end metaoperator::ReconciliationFileFolder%63AC507002C5.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: AU_FILE_NAME%63AC52310168
      //## begin metaoperator::ReconciliationFileFolder::AU_FILE_NAME%63AC52310168.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strAU_FILE_NAME;
      //## end metaoperator::ReconciliationFileFolder::AU_FILE_NAME%63AC52310168.attr

      //## Attribute: AU_STATE%63AC523101A5
      //## begin metaoperator::ReconciliationFileFolder::AU_STATE%63AC523101A5.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strAU_STATE;
      //## end metaoperator::ReconciliationFileFolder::AU_STATE%63AC523101A5.attr

      //## Attribute: BIN%63AC523101DB
      //## begin metaoperator::ReconciliationFileFolder::BIN%63AC523101DB.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strBIN;
      //## end metaoperator::ReconciliationFileFolder::BIN%63AC523101DB.attr

      //## Attribute: BIN_COUNT%63AC52310213
      //## begin metaoperator::ReconciliationFileFolder::BIN_COUNT%63AC52310213.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strBIN_COUNT;
      //## end metaoperator::ReconciliationFileFolder::BIN_COUNT%63AC52310213.attr

      //## Attribute: DATE_RECON%63AC52310253
      //## begin metaoperator::ReconciliationFileFolder::DATE_RECON%63AC52310253.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strDATE_RECON;
      //## end metaoperator::ReconciliationFileFolder::DATE_RECON%63AC52310253.attr

      //## Attribute: TASK_RECONCILED%63AC52310292
      //## begin metaoperator::ReconciliationFileFolder::TASK_RECONCILED%63AC52310292.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strTASK_RECONCILED;
      //## end metaoperator::ReconciliationFileFolder::TASK_RECONCILED%63AC52310292.attr

      //## Attribute: TSTAMP_TRANS_FROM%63AC523102D6
      //## begin metaoperator::ReconciliationFileFolder::TSTAMP_TRANS_FROM%63AC523102D6.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strTSTAMP_TRANS_FROM;
      //## end metaoperator::ReconciliationFileFolder::TSTAMP_TRANS_FROM%63AC523102D6.attr

      //## Attribute: TSTAMP_TRANS_TO%63AC5231031D
      //## begin metaoperator::ReconciliationFileFolder::TSTAMP_TRANS_TO%63AC5231031D.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strTSTAMP_TRANS_TO;
      //## end metaoperator::ReconciliationFileFolder::TSTAMP_TRANS_TO%63AC5231031D.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::MetaOperator_CAT::<unnamed>%63AC510503DE
      //## Role: ReconciliationFileFolder::<m_pEmail>%63AC51060300
      //## begin metaoperator::ReconciliationFileFolder::<m_pEmail>%63AC51060300.role preserve=no  public: command::Email { -> RFHgN}
      command::Email *m_pEmail;
      //## end metaoperator::ReconciliationFileFolder::<m_pEmail>%63AC51060300.role

    // Additional Implementation Declarations
      //## begin metaoperator::ReconciliationFileFolder%63AC507002C5.implementation preserve=yes
      //## end metaoperator::ReconciliationFileFolder%63AC507002C5.implementation

};

//## begin metaoperator::ReconciliationFileFolder%63AC507002C5.postscript preserve=yes
//## end metaoperator::ReconciliationFileFolder%63AC507002C5.postscript

} // namespace metaoperator

//## begin module%63AC518C01CB.epilog preserve=yes
//## end module%63AC518C01CB.epilog


#endif
