//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%662A453D0232.cm preserve=no
//## end module%662A453D0232.cm

//## begin module%662A453D0232.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%662A453D0232.cp

//## Module: CXOSMZ29%662A453D0232; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ29.hpp

#ifndef CXOSMZ29_h
#define CXOSMZ29_h 1

//## begin module%662A453D0232.additionalIncludes preserve=no
//## end module%662A453D0232.additionalIncludes

//## begin module%662A453D0232.includes preserve=yes
//## end module%662A453D0232.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
//## begin module%662A453D0232.declarations preserve=no
//## end module%662A453D0232.declarations

//## begin module%662A453D0232.additionalDeclarations preserve=yes
//## end module%662A453D0232.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::ExportFile%662A44A400A8.preface preserve=yes
//## end metaoperator::ExportFile%662A44A400A8.preface

//## Class: ExportFile%662A44A400A8
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport ExportFile : public reusable::Object  //## Inherits: <unnamed>%662A44C102CE
{
  //## begin metaoperator::ExportFile%662A44A400A8.initialDeclarations preserve=yes
  //## end metaoperator::ExportFile%662A44A400A8.initialDeclarations

  public:
    //## Constructors (generated)
      ExportFile();

    //## Destructor (generated)
      virtual ~ExportFile();


    //## Other Operations (specified)
      //## Operation: getRow%662A96830062
      const reusable::string& getRow (int iIndex) const
      {
        //## begin metaoperator::ExportFile::getRow%662A96830062.body preserve=yes
         return m_strRow[iIndex];
        //## end metaoperator::ExportFile::getRow%662A96830062.body
      }

      //## Operation: setRow%662A6FA40005
      void setRow (int iIndex, const string& strRow)
      {
        //## begin metaoperator::ExportFile::setRow%662A6FA40005.body preserve=yes
         m_strRow[iIndex] = strRow;
        //## end metaoperator::ExportFile::setRow%662A6FA40005.body
      }

    // Additional Public Declarations
      //## begin metaoperator::ExportFile%662A44A400A8.public preserve=yes
      //## end metaoperator::ExportFile%662A44A400A8.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::ExportFile%662A44A400A8.protected preserve=yes
      //## end metaoperator::ExportFile%662A44A400A8.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::ExportFile%662A44A400A8.private preserve=yes
      //## end metaoperator::ExportFile%662A44A400A8.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Row%662A44EB026F
      //## begin metaoperator::ExportFile::Row%662A44EB026F.attr preserve=no  private: string[3] {V} 
      string m_strRow[3];
      //## end metaoperator::ExportFile::Row%662A44EB026F.attr

    // Additional Implementation Declarations
      //## begin metaoperator::ExportFile%662A44A400A8.implementation preserve=yes
      //## end metaoperator::ExportFile%662A44A400A8.implementation

};

//## begin metaoperator::ExportFile%662A44A400A8.postscript preserve=yes
//## end metaoperator::ExportFile%662A44A400A8.postscript

} // namespace metaoperator

//## begin module%662A453D0232.epilog preserve=yes
//## end module%662A453D0232.epilog


#endif
