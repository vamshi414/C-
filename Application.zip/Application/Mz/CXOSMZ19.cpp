//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B4A41F00B7.cm preserve=no
//## end module%63B4A41F00B7.cm

//## begin module%63B4A41F00B7.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B4A41F00B7.cp

//## Module: CXOSMZ19%63B4A41F00B7; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ19.cpp

//## begin module%63B4A41F00B7.additionalIncludes preserve=no
//## end module%63B4A41F00B7.additionalIncludes

//## begin module%63B4A41F00B7.includes preserve=yes
//## end module%63B4A41F00B7.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSMZ17_h
#include "CXODMZ17.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSMZ19_h
#include "CXODMZ19.hpp"
#endif


//## begin module%63B4A41F00B7.declarations preserve=no
//## end module%63B4A41F00B7.declarations

//## begin module%63B4A41F00B7.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Function* createConcatenateFiles()
   {
      return new metaoperator::ConcatenateFiles();
   }
   const bool registered = metaoperator::FunctionFactory::instance()->registerFunction("cat",createConcatenateFiles);
}
#include "CXODTM06.hpp"
//## end module%63B4A41F00B7.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::ConcatenateFiles 

ConcatenateFiles::ConcatenateFiles()
  //## begin ConcatenateFiles::ConcatenateFiles%63B4A31E0171_const.hasinit preserve=no
  //## end ConcatenateFiles::ConcatenateFiles%63B4A31E0171_const.hasinit
  //## begin ConcatenateFiles::ConcatenateFiles%63B4A31E0171_const.initialization preserve=yes
  //## end ConcatenateFiles::ConcatenateFiles%63B4A31E0171_const.initialization
{
  //## begin metaoperator::ConcatenateFiles::ConcatenateFiles%63B4A31E0171_const.body preserve=yes
   memcpy(m_sID,"MZ19",4);
  //## end metaoperator::ConcatenateFiles::ConcatenateFiles%63B4A31E0171_const.body
}


ConcatenateFiles::~ConcatenateFiles()
{
  //## begin metaoperator::ConcatenateFiles::~ConcatenateFiles%63B4A31E0171_dest.body preserve=yes
  //## end metaoperator::ConcatenateFiles::~ConcatenateFiles%63B4A31E0171_dest.body
}



//## Other Operations (implementation)
int ConcatenateFiles::execute ()
{
  //## begin metaoperator::ConcatenateFiles::execute%63B4A3400207.body preserve=yes
   if (m_hToken.size() < 3)
      return -1;
   string strDX_FILE_TYPE;
   Condition::getValue("DX_FILE_TYPE",strDX_FILE_TYPE);
   string strDATE_RECON;
   Condition::getValue("DATE_RECON",strDATE_RECON);
#ifdef _WIN32
   m_strCommand.assign("type " + Extract::instance()->getNode001() + "\\");
#elif _UNIX
   m_strCommand.assign("cat " + Extract::instance()->getNode001() + "/");
#endif
   m_strPath = m_hToken[2];
   Condition::substitute(m_strPath);
   m_strOperator.assign(" >",2);
   Query hQuery;
   hQuery.attach(this);
   hQuery.join("DX_DATA_CONTROL D","INNER","DX_DATA_PATH P","DX_FILE_ID");
   hQuery.bind("DX_DATA_PATH P","DX_PATH",Column::STRING,&m_strDX_PATH);
   hQuery.setBasicPredicate("DX_DATA_PATH P","DX_FILE_TYPE","=",strDX_FILE_TYPE.c_str());
   hQuery.setBasicPredicate("DX_DATA_CONTROL D","DX_STATE","=","DC");
   hQuery.setBasicPredicate("DX_DATA_CONTROL D","DATE_RECON","=",strDATE_RECON.c_str());
   hQuery.setOrderByClause("ENTITY_ID");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   return (pSelectStatement->execute(hQuery) == false || hQuery.getAbort()) ? -1 : 1;
  //## end metaoperator::ConcatenateFiles::execute%63B4A3400207.body
}

void ConcatenateFiles::update (Subject* pSubject)
{
  //## begin metaoperator::ConcatenateFiles::update%63B528090071.body preserve=yes
   string strCommand(m_strCommand);
   strCommand.append(m_strDX_PATH);
   strCommand.append(m_strOperator);
   strCommand.append(m_strPath);
   Trace::put(strCommand.data(),strCommand.length(),true);
   int i = system(strCommand.c_str());
   if (i != 0 && i != 2)
   {
      char szTemp[50];
      Trace::put(szTemp, snprintf(szTemp, sizeof(szTemp), "system command failure code: %d", i), true);
      ((Query*)pSubject)->setAbort(true);
   }
   m_strOperator.assign(" >>",3);
  //## end metaoperator::ConcatenateFiles::update%63B528090071.body
}

// Additional Declarations
  //## begin metaoperator::ConcatenateFiles%63B4A31E0171.declarations preserve=yes
  //## end metaoperator::ConcatenateFiles%63B4A31E0171.declarations

} // namespace metaoperator

//## begin module%63B4A41F00B7.epilog preserve=yes
//## end module%63B4A41F00B7.epilog
