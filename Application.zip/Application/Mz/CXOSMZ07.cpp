//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6390A64101E1.cm preserve=no
//## end module%6390A64101E1.cm

//## begin module%6390A64101E1.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6390A64101E1.cp

//## Module: CXOSMZ07%6390A64101E1; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ07.cpp

//## begin module%6390A64101E1.additionalIncludes preserve=no
//## end module%6390A64101E1.additionalIncludes

//## begin module%6390A64101E1.includes preserve=yes
//## end module%6390A64101E1.includes

#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSMZ07_h
#include "CXODMZ07.hpp"
#endif


//## begin module%6390A64101E1.declarations preserve=no
//## end module%6390A64101E1.declarations

//## begin module%6390A64101E1.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Function* createExportFileClose()
   {
      return new metaoperator::ExportFileClose();
   }
   const bool registered = metaoperator::FunctionFactory::instance()->registerFunction("CLOSE",createExportFileClose);
}
//## end module%6390A64101E1.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::ExportFileClose 

ExportFileClose::ExportFileClose()
  //## begin ExportFileClose::ExportFileClose%6390A5B400C5_const.hasinit preserve=no
  //## end ExportFileClose::ExportFileClose%6390A5B400C5_const.hasinit
  //## begin ExportFileClose::ExportFileClose%6390A5B400C5_const.initialization preserve=yes
  //## end ExportFileClose::ExportFileClose%6390A5B400C5_const.initialization
{
  //## begin metaoperator::ExportFileClose::ExportFileClose%6390A5B400C5_const.body preserve=yes
   memcpy(m_sID,"MZ07",4);
  //## end metaoperator::ExportFileClose::ExportFileClose%6390A5B400C5_const.body
}


ExportFileClose::~ExportFileClose()
{
  //## begin metaoperator::ExportFileClose::~ExportFileClose%6390A5B400C5_dest.body preserve=yes
  //## end metaoperator::ExportFileClose::~ExportFileClose%6390A5B400C5_dest.body
}



//## Other Operations (implementation)
int ExportFileClose::execute ()
{
  //## begin metaoperator::ExportFileClose::execute%6390A5D40371.body preserve=yes
   string strDATE_RECON;
   Condition::getValue("DATE_RECON",strDATE_RECON);
   if (m_strDATE_RECON == strDATE_RECON)
      return 0;
   ExportFile* pExportFile = 0;
   if (m_hToken.size() == 5)
      pExportFile = new ExportFile(m_hToken[4],m_hToken[2],m_hToken[3],strDATE_RECON,"240000");
   else
      pExportFile = new ExportFile(m_hToken[3],"AI",m_hToken[2],strDATE_RECON,"240000");
   string strBuffer("FH      yyyymmdd",16);
   strBuffer.replace(8,8,strDATE_RECON);
   if (!pExportFile->write(strBuffer.data(),16))
   {
      delete pExportFile;
      return -1;
   }
   if (!pExportFile->write("FT",2))
   {
      delete pExportFile;
      return -1;
   }
   if (!pExportFile->close())
   {
      delete pExportFile;
      return -1;
   }
   m_strDATE_RECON = strDATE_RECON;
   Database::instance()->commit();
   delete pExportFile;
   return 1;
  //## end metaoperator::ExportFileClose::execute%6390A5D40371.body
}

// Additional Declarations
  //## begin metaoperator::ExportFileClose%6390A5B400C5.declarations preserve=yes
  //## end metaoperator::ExportFileClose%6390A5B400C5.declarations

} // namespace metaoperator

//## begin module%6390A64101E1.epilog preserve=yes
//## end module%6390A64101E1.epilog
