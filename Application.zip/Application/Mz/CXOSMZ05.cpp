//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%638FFC8600BF.cm preserve=no
//## end module%638FFC8600BF.cm

//## begin module%638FFC8600BF.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%638FFC8600BF.cp

//## Module: CXOSMZ05%638FFC8600BF; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ05.cpp

//## begin module%638FFC8600BF.additionalIncludes preserve=no
//## end module%638FFC8600BF.additionalIncludes

//## begin module%638FFC8600BF.includes preserve=yes
//## end module%638FFC8600BF.includes

#ifndef CXOSMZ05_h
#include "CXODMZ05.hpp"
#endif
//## begin module%638FFC8600BF.declarations preserve=no
//## end module%638FFC8600BF.declarations

//## begin module%638FFC8600BF.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Function* createMoveFile()
   {
      return new metaoperator::MoveFile();
   }
   const bool registered = metaoperator::FunctionFactory::instance()->registerFunction("mv",createMoveFile);
}
//## end module%638FFC8600BF.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::MoveFile 

MoveFile::MoveFile()
  //## begin MoveFile::MoveFile%638FFC0C023F_const.hasinit preserve=no
  //## end MoveFile::MoveFile%638FFC0C023F_const.hasinit
  //## begin MoveFile::MoveFile%638FFC0C023F_const.initialization preserve=yes
  //## end MoveFile::MoveFile%638FFC0C023F_const.initialization
{
  //## begin metaoperator::MoveFile::MoveFile%638FFC0C023F_const.body preserve=yes
   memcpy(m_sID,"MZ05",4);
  //## end metaoperator::MoveFile::MoveFile%638FFC0C023F_const.body
}


MoveFile::~MoveFile()
{
  //## begin metaoperator::MoveFile::~MoveFile%638FFC0C023F_dest.body preserve=yes
  //## end metaoperator::MoveFile::~MoveFile%638FFC0C023F_dest.body
}


// Additional Declarations
  //## begin metaoperator::MoveFile%638FFC0C023F.declarations preserve=yes
  //## end metaoperator::MoveFile%638FFC0C023F.declarations

} // namespace metaoperator

//## begin module%638FFC8600BF.epilog preserve=yes
//## end module%638FFC8600BF.epilog
