//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B4658C0067.cm preserve=no
//## end module%63B4658C0067.cm

//## begin module%63B4658C0067.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B4658C0067.cp

//## Module: CXOSMZ16%63B4658C0067; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ16.cpp

//## begin module%63B4658C0067.additionalIncludes preserve=no
//## end module%63B4658C0067.additionalIncludes

//## begin module%63B4658C0067.includes preserve=yes
#include <sstream>
//## end module%63B4658C0067.includes

#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSMZ16_h
#include "CXODMZ16.hpp"
#endif


//## begin module%63B4658C0067.declarations preserve=no
//## end module%63B4658C0067.declarations

//## begin module%63B4658C0067.additionalDeclarations preserve=yes
namespace
{
   metaoperator::Condition* createFile()
   {
      return new metaoperator::File();
   }
   const bool registered1 = metaoperator::ConditionFactory::instance()->registerCondition("Exists",createFile);
   const bool registered2 = metaoperator::ConditionFactory::instance()->registerCondition("WIP",createFile);
   const bool registered3 = metaoperator::ConditionFactory::instance()->registerCondition("^WIP",createFile);
}
//## end module%63B4658C0067.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::File 

File::File()
  //## begin File::File%63B464730142_const.hasinit preserve=no
  //## end File::File%63B464730142_const.hasinit
  //## begin File::File%63B464730142_const.initialization preserve=yes
  //## end File::File%63B464730142_const.initialization
{
  //## begin metaoperator::File::File%63B464730142_const.body preserve=yes
   memcpy(m_sID,"MZ16",4);
  //## end metaoperator::File::File%63B464730142_const.body
}


File::~File()
{
  //## begin metaoperator::File::~File%63B464730142_dest.body preserve=yes
  //## end metaoperator::File::~File%63B464730142_dest.body
}



//## Other Operations (implementation)
bool File::test ()
{
  //## begin metaoperator::File::test%63B46492020C.body preserve=yes
   string strFolder(m_hToken[2]);
   substitute(strFolder);
   bool bSuccess = ((m_hToken[1][0] == '^') ? FlatFile::isFolderEmpty(strFolder.c_str()) : !FlatFile::isFolderEmpty(strFolder.c_str()));
   if (IF::Trace::getEnable())
   {
      std::ostringstream oss;
      oss << m_hToken[1] << " -> " << strFolder << " -> " << (bSuccess ? "True" : "False");
      Trace::put(oss.str().data());
   }
   return bSuccess;
  //## end metaoperator::File::test%63B46492020C.body
}

// Additional Declarations
  //## begin metaoperator::File%63B464730142.declarations preserve=yes
  //## end metaoperator::File%63B464730142.declarations

} // namespace metaoperator

//## begin module%63B4658C0067.epilog preserve=yes
//## end module%63B4658C0067.epilog
