//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6234D76602B1.cm preserve=no
//## end module%6234D76602B1.cm

//## begin module%6234D76602B1.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6234D76602B1.cp

//## Module: CXOSMZ02%6234D76602B1; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ02.hpp

#ifndef CXOSMZ02_h
#define CXOSMZ02_h 1

//## begin module%6234D76602B1.additionalIncludes preserve=no
//## end module%6234D76602B1.additionalIncludes

//## begin module%6234D76602B1.includes preserve=yes
//## end module%6234D76602B1.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSMZ14_h
#include "CXODMZ14.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;

} // namespace timer

//## begin module%6234D76602B1.declarations preserve=no
//## end module%6234D76602B1.declarations

//## begin module%6234D76602B1.additionalDeclarations preserve=yes
//## end module%6234D76602B1.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::Condition%6234A6FA033D.preface preserve=yes
//## end metaoperator::Condition%6234A6FA033D.preface

//## Class: Condition%6234A6FA033D
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6234E17700D1;IF::Trace { -> }
//## Uses: <unnamed>%6234F3FA03BA;reusable::Buffer { -> F}
//## Uses: <unnamed>%63B4753603CD;ConditionFactory { -> }
//## Uses: <unnamed>%63B4856E0373;timer::Date { -> F}

class DllExport Condition : public reusable::Object  //## Inherits: <unnamed>%6234A7090180
{
  //## begin metaoperator::Condition%6234A6FA033D.initialDeclarations preserve=yes
  //## end metaoperator::Condition%6234A6FA033D.initialDeclarations

  public:
    //## Constructors (generated)
      Condition();

    //## Destructor (generated)
      virtual ~Condition();


    //## Other Operations (specified)
      //## Operation: addMatch%65B2ABC4028B
      static void addMatch (const reusable::string& strFirst, const reusable::string& strSecond);

      //## Operation: clear%65B2DFBC0288
      static void clear (const reusable::string& strFirst);

      //## Operation: getValue%634874DB0361
      static bool getValue (const reusable::string& strKey, reusable::string& strValue);

      //## Operation: match%65B2D5AD0034
      static bool match (const reusable::string& strFirst, const reusable::string& strSecond);

      //## Operation: setMatch%65B2C8C90055
      static void setMatch (const reusable::string& strFirst, const reusable::string& strBuffer);

      //## Operation: setToken%63B481D70114
      virtual void setToken (const vector<string>& hToken);

      //## Operation: setValue%6234CB800155
      static void setValue (const reusable::string& strFirst, const reusable::string& strSecond);

      //## Operation: substitute%6348750803E6
      static void substitute (reusable::string& strValue);

      //## Operation: test%6234A78500E5
      virtual bool test ();

    // Additional Public Declarations
      //## begin metaoperator::Condition%6234A6FA033D.public preserve=yes
      //## end metaoperator::Condition%6234A6FA033D.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Token%6234A86703B1
      //## begin metaoperator::Condition::Token%6234A86703B1.attr preserve=no  protected: vector<string> {VA} 
      vector<string> m_hToken;
      //## end metaoperator::Condition::Token%6234A86703B1.attr

    // Additional Protected Declarations
      //## begin metaoperator::Condition%6234A6FA033D.protected preserve=yes
      //## end metaoperator::Condition%6234A6FA033D.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::Condition%6234A6FA033D.private preserve=yes
      //## end metaoperator::Condition%6234A6FA033D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Match%65B2AB6A02C7
      //## begin metaoperator::Condition::Match%65B2AB6A02C7.attr preserve=no  private: static multimap<string,pair<string,bool>,less<string> >* {V} 0
      static multimap<string,pair<string,bool>,less<string> >* m_pMatch;
      //## end metaoperator::Condition::Match%65B2AB6A02C7.attr

      //## Attribute: Value%6234CB500115
      //## begin metaoperator::Condition::Value%6234CB500115.attr preserve=no  private: static map<string,string,less<string> >* {V} 0
      static map<string,string,less<string> >* m_pValue;
      //## end metaoperator::Condition::Value%6234CB500115.attr

    // Additional Implementation Declarations
      //## begin metaoperator::Condition%6234A6FA033D.implementation preserve=yes
      //## end metaoperator::Condition%6234A6FA033D.implementation

};

//## begin metaoperator::Condition%6234A6FA033D.postscript preserve=yes
//## end metaoperator::Condition%6234A6FA033D.postscript

} // namespace metaoperator

//## begin module%6234D76602B1.epilog preserve=yes
//## end module%6234D76602B1.epilog


#endif
