//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63FE49490148.cm preserve=no
//## end module%63FE49490148.cm

//## begin module%63FE49490148.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63FE49490148.cp

//## Module: CXOSMZ22%63FE49490148; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ22.hpp

#ifndef CXOSMZ22_h
#define CXOSMZ22_h 1

//## begin module%63FE49490148.additionalIncludes preserve=no
//## end module%63FE49490148.additionalIncludes

//## begin module%63FE49490148.includes preserve=yes
//## end module%63FE49490148.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
class MetaOperator;
} // namespace metaoperator

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Email;
} // namespace command

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class EmailSegment;

} // namespace usersegment

//## begin module%63FE49490148.declarations preserve=no
//## end module%63FE49490148.declarations

//## begin module%63FE49490148.additionalDeclarations preserve=yes
//## end module%63FE49490148.additionalDeclarations


namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::AuditFolder%63FE474403B7.preface preserve=yes
//## end metaoperator::AuditFolder%63FE474403B7.preface

//## Class: AuditFolder%63FE474403B7
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%63FE478902FE;reusable::Query { -> F}
//## Uses: <unnamed>%63FE478B01CE;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%63FE478C036E;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%63FE478E0339;usersegment::EmailSegment { -> F}
//## Uses: <unnamed>%63FE4791003F;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%63FFBB870208;MetaOperator { -> F}
//## Uses: <unnamed>%6400C29202A3;timer::Date { -> F}
//## Uses: <unnamed>%640606C4023E;command::Email { -> F}

class DllExport AuditFolder : public reusable::Observer  //## Inherits: <unnamed>%63FE47D10378
{
  //## begin metaoperator::AuditFolder%63FE474403B7.initialDeclarations preserve=yes
  //## end metaoperator::AuditFolder%63FE474403B7.initialDeclarations

  public:
    //## Constructors (generated)
      AuditFolder();

    //## Destructor (generated)
      virtual ~AuditFolder();


    //## Other Operations (specified)
      //## Operation: report%63FE47FE007B
      bool report (command::Email* pEmail);

      //## Operation: update%63FE48090329
      //	Callback function that is invoked by a Subject when its
      //	state changes.
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin metaoperator::AuditFolder%63FE474403B7.public preserve=yes
      //## end metaoperator::AuditFolder%63FE474403B7.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::AuditFolder%63FE474403B7.protected preserve=yes
      //## end metaoperator::AuditFolder%63FE474403B7.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::AuditFolder%63FE474403B7.private preserve=yes
      //## end metaoperator::AuditFolder%63FE474403B7.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: RESOURCE_KEY%63FECA1F0376
      //## begin metaoperator::AuditFolder::RESOURCE_KEY%63FECA1F0376.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strRESOURCE_KEY;
      //## end metaoperator::AuditFolder::RESOURCE_KEY%63FECA1F0376.attr

      //## Attribute: Timestamp%63FFBC8D022E
      //## begin metaoperator::AuditFolder::Timestamp%63FFBC8D022E.attr preserve=no  private: vector<string>[2] {V} 
      vector<string> m_hTimestamp[2];
      //## end metaoperator::AuditFolder::Timestamp%63FFBC8D022E.attr

      //## Attribute: TSTAMP_CREATED%63FECA140346
      //## begin metaoperator::AuditFolder::TSTAMP_CREATED%63FECA140346.attr preserve=no  private: reusable::string {V} 
      reusable::string m_strTSTAMP_CREATED;
      //## end metaoperator::AuditFolder::TSTAMP_CREATED%63FECA140346.attr

    // Additional Implementation Declarations
      //## begin metaoperator::AuditFolder%63FE474403B7.implementation preserve=yes
      //## end metaoperator::AuditFolder%63FE474403B7.implementation

};

//## begin metaoperator::AuditFolder%63FE474403B7.postscript preserve=yes
//## end metaoperator::AuditFolder%63FE474403B7.postscript

} // namespace metaoperator

//## begin module%63FE49490148.epilog preserve=yes
//## end module%63FE49490148.epilog


#endif
