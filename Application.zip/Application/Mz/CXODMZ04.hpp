//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%638FF394014A.cm preserve=no
//## end module%638FF394014A.cm

//## begin module%638FF394014A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%638FF394014A.cp

//## Module: CXOSMZ04%638FF394014A; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ04.hpp

#ifndef CXOSMZ04_h
#define CXOSMZ04_h 1

//## begin module%638FF394014A.additionalIncludes preserve=no
//## end module%638FF394014A.additionalIncludes

//## begin module%638FF394014A.includes preserve=yes
//## end module%638FF394014A.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
class Function;

} // namespace metaoperator

//## begin module%638FF394014A.declarations preserve=no
//## end module%638FF394014A.declarations

//## begin module%638FF394014A.additionalDeclarations preserve=yes
//## end module%638FF394014A.additionalDeclarations


namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::FunctionFactory%638FF2900111.preface preserve=yes
//## end metaoperator::FunctionFactory%638FF2900111.preface

//## Class: FunctionFactory%638FF2900111
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%638FF33D033D;Function { -> F}

class DllExport FunctionFactory : public reusable::Object  //## Inherits: <unnamed>%638FF2BE01A6
{
  //## begin metaoperator::FunctionFactory%638FF2900111.initialDeclarations preserve=yes
      typedef Function* (*cloneFunction)();
  //## end metaoperator::FunctionFactory%638FF2900111.initialDeclarations

  public:
    //## Constructors (generated)
      FunctionFactory();

    //## Destructor (generated)
      virtual ~FunctionFactory();


    //## Other Operations (specified)
      //## Operation: create%638FF2E00256
      Function* create (const reusable::string& strName);

      //## Operation: instance%638FF2E00280
      static FunctionFactory* instance ();

      //## Operation: registerFunction%638FF2E002A7
      bool registerFunction (const reusable::string& strName, cloneFunction hCloneFunction);

    // Additional Public Declarations
      //## begin metaoperator::FunctionFactory%638FF2900111.public preserve=yes
      //## end metaoperator::FunctionFactory%638FF2900111.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::FunctionFactory%638FF2900111.protected preserve=yes
      //## end metaoperator::FunctionFactory%638FF2900111.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::FunctionFactory%638FF2900111.private preserve=yes
      //## end metaoperator::FunctionFactory%638FF2900111.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Function%638FF5AF00B3
      //## begin metaoperator::FunctionFactory::Function%638FF5AF00B3.attr preserve=no  private: map<string,cloneFunction,less<string> > {U} 
      map<string,cloneFunction,less<string> > m_hFunction;
      //## end metaoperator::FunctionFactory::Function%638FF5AF00B3.attr

      //## Attribute: Instance%638FF2D3019D
      //## begin metaoperator::FunctionFactory::Instance%638FF2D3019D.attr preserve=no  private: static FunctionFactory* {V} 0
      static FunctionFactory* m_pInstance;
      //## end metaoperator::FunctionFactory::Instance%638FF2D3019D.attr

    // Additional Implementation Declarations
      //## begin metaoperator::FunctionFactory%638FF2900111.implementation preserve=yes
      //## end metaoperator::FunctionFactory%638FF2900111.implementation

};

//## begin metaoperator::FunctionFactory%638FF2900111.postscript preserve=yes
//## end metaoperator::FunctionFactory%638FF2900111.postscript

} // namespace metaoperator

//## begin module%638FF394014A.epilog preserve=yes
//## end module%638FF394014A.epilog


#endif
