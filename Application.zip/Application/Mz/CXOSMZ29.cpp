//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%662A454000B6.cm preserve=no
//## end module%662A454000B6.cm

//## begin module%662A454000B6.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%662A454000B6.cp

//## Module: CXOSMZ29%662A454000B6; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ29.cpp

//## begin module%662A454000B6.additionalIncludes preserve=no
//## end module%662A454000B6.additionalIncludes

//## begin module%662A454000B6.includes preserve=yes
//## end module%662A454000B6.includes

#ifndef CXOSMZ29_h
#include "CXODMZ29.hpp"
#endif
//## begin module%662A454000B6.declarations preserve=no
//## end module%662A454000B6.declarations

//## begin module%662A454000B6.additionalDeclarations preserve=yes
//## end module%662A454000B6.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::ExportFile 

ExportFile::ExportFile()
  //## begin ExportFile::ExportFile%662A44A400A8_const.hasinit preserve=no
  //## end ExportFile::ExportFile%662A44A400A8_const.hasinit
  //## begin ExportFile::ExportFile%662A44A400A8_const.initialization preserve=yes
  //## end ExportFile::ExportFile%662A44A400A8_const.initialization
{
  //## begin metaoperator::ExportFile::ExportFile%662A44A400A8_const.body preserve=yes
   memcpy(m_sID,"MZ29",4);
  //## end metaoperator::ExportFile::ExportFile%662A44A400A8_const.body
}


ExportFile::~ExportFile()
{
  //## begin metaoperator::ExportFile::~ExportFile%662A44A400A8_dest.body preserve=yes
  //## end metaoperator::ExportFile::~ExportFile%662A44A400A8_dest.body
}


// Additional Declarations
  //## begin metaoperator::ExportFile%662A44A400A8.declarations preserve=yes
  //## end metaoperator::ExportFile%662A44A400A8.declarations

} // namespace metaoperator

//## begin module%662A454000B6.epilog preserve=yes
//## end module%662A454000B6.epilog

