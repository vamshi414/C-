//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B465890370.cm preserve=no
//## end module%63B465890370.cm

//## begin module%63B465890370.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B465890370.cp

//## Module: CXOSMZ16%63B465890370; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ16.hpp

#ifndef CXOSMZ16_h
#define CXOSMZ16_h 1

//## begin module%63B465890370.additionalIncludes preserve=no
//## end module%63B465890370.additionalIncludes

//## begin module%63B465890370.includes preserve=yes
//## end module%63B465890370.includes

#ifndef CXOSMZ02_h
#include "CXODMZ02.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class FlatFile;

} // namespace IF

//## begin module%63B465890370.declarations preserve=no
//## end module%63B465890370.declarations

//## begin module%63B465890370.additionalDeclarations preserve=yes
//## end module%63B465890370.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::File%63B464730142.preface preserve=yes
//## end metaoperator::File%63B464730142.preface

//## Class: File%63B464730142
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%63B47CF003D9;IF::FlatFile { -> F}

class DllExport File : public Condition  //## Inherits: <unnamed>%63B4647F027E
{
  //## begin metaoperator::File%63B464730142.initialDeclarations preserve=yes
  //## end metaoperator::File%63B464730142.initialDeclarations

  public:
    //## Constructors (generated)
      File();

    //## Destructor (generated)
      virtual ~File();


    //## Other Operations (specified)
      //## Operation: test%63B46492020C
      virtual bool test ();

    // Additional Public Declarations
      //## begin metaoperator::File%63B464730142.public preserve=yes
      //## end metaoperator::File%63B464730142.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::File%63B464730142.protected preserve=yes
      //## end metaoperator::File%63B464730142.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::File%63B464730142.private preserve=yes
      //## end metaoperator::File%63B464730142.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin metaoperator::File%63B464730142.implementation preserve=yes
      //## end metaoperator::File%63B464730142.implementation

};

//## begin metaoperator::File%63B464730142.postscript preserve=yes
//## end metaoperator::File%63B464730142.postscript

} // namespace metaoperator

//## begin module%63B465890370.epilog preserve=yes
//## end module%63B465890370.epilog


#endif
