//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B4A4BC021E.cm preserve=no
//## end module%63B4A4BC021E.cm

//## begin module%63B4A4BC021E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B4A4BC021E.cp

//## Module: CXOSMZ21%63B4A4BC021E; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ21.hpp

#ifndef CXOSMZ21_h
#define CXOSMZ21_h 1

//## begin module%63B4A4BC021E.additionalIncludes preserve=no
//## end module%63B4A4BC021E.additionalIncludes

//## begin module%63B4A4BC021E.includes preserve=yes
//## end module%63B4A4BC021E.includes

#ifndef CXOSMZ03_h
#include "CXODMZ03.hpp"
#endif

//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
class Condition;
} // namespace metaoperator

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SearchCondition;
class Table;
class Statement;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%63B4A4BC021E.declarations preserve=no
//## end module%63B4A4BC021E.declarations

//## begin module%63B4A4BC021E.additionalDeclarations preserve=yes
//## end module%63B4A4BC021E.additionalDeclarations


namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::SetGlobalContext%63B4A38900AC.preface preserve=yes
//## end metaoperator::SetGlobalContext%63B4A38900AC.preface

//## Class: SetGlobalContext%63B4A38900AC
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%63B689A00373;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%63B689C401E2;database::Database { -> F}
//## Uses: <unnamed>%63B68A130054;reusable::Table { -> F}
//## Uses: <unnamed>%63B68AE700ED;reusable::SearchCondition { -> F}
//## Uses: <unnamed>%63B68B2A0360;reusable::Statement { -> F}
//## Uses: <unnamed>%63B68BAB03E7;Condition { -> F}

class DllExport SetGlobalContext : public Function  //## Inherits: <unnamed>%63B4A3BD0267
{
  //## begin metaoperator::SetGlobalContext%63B4A38900AC.initialDeclarations preserve=yes
  //## end metaoperator::SetGlobalContext%63B4A38900AC.initialDeclarations

  public:
    //## Constructors (generated)
      SetGlobalContext();

    //## Destructor (generated)
      virtual ~SetGlobalContext();


    //## Other Operations (specified)
      //## Operation: execute%63B4A3C903B2
      virtual int execute ();

    // Additional Public Declarations
      //## begin metaoperator::SetGlobalContext%63B4A38900AC.public preserve=yes
      //## end metaoperator::SetGlobalContext%63B4A38900AC.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::SetGlobalContext%63B4A38900AC.protected preserve=yes
      //## end metaoperator::SetGlobalContext%63B4A38900AC.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::SetGlobalContext%63B4A38900AC.private preserve=yes
      //## end metaoperator::SetGlobalContext%63B4A38900AC.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin metaoperator::SetGlobalContext%63B4A38900AC.implementation preserve=yes
      //## end metaoperator::SetGlobalContext%63B4A38900AC.implementation

};

//## begin metaoperator::SetGlobalContext%63B4A38900AC.postscript preserve=yes
#define STS_RECORD_NOT_FOUND 14
//## end metaoperator::SetGlobalContext%63B4A38900AC.postscript

} // namespace metaoperator

//## begin module%63B4A4BC021E.epilog preserve=yes
//## end module%63B4A4BC021E.epilog


#endif
