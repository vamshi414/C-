//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63FE494B035D.cm preserve=no
//## end module%63FE494B035D.cm

//## begin module%63FE494B035D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63FE494B035D.cp

//## Module: CXOSMZ22%63FE494B035D; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ22.cpp

//## begin module%63FE494B035D.additionalIncludes preserve=no
//## end module%63FE494B035D.additionalIncludes

//## begin module%63FE494B035D.includes preserve=yes
//## end module%63FE494B035D.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSUS21_h
#include "CXODUS21.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOPMZ00_h
#include "CXODMZ00.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSBC25_h
#include "CXODBC25.hpp"
#endif
#ifndef CXOSMZ22_h
#include "CXODMZ22.hpp"
#endif


//## begin module%63FE494B035D.declarations preserve=no
//## end module%63FE494B035D.declarations

//## begin module%63FE494B035D.additionalDeclarations preserve=yes
//## end module%63FE494B035D.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::AuditFolder 

AuditFolder::AuditFolder()
  //## begin AuditFolder::AuditFolder%63FE474403B7_const.hasinit preserve=no
  //## end AuditFolder::AuditFolder%63FE474403B7_const.hasinit
  //## begin AuditFolder::AuditFolder%63FE474403B7_const.initialization preserve=yes
  //## end AuditFolder::AuditFolder%63FE474403B7_const.initialization
{
  //## begin metaoperator::AuditFolder::AuditFolder%63FE474403B7_const.body preserve=yes
   memcpy(m_sID,"MZ22",4);
  //## end metaoperator::AuditFolder::AuditFolder%63FE474403B7_const.body
}


AuditFolder::~AuditFolder()
{
  //## begin metaoperator::AuditFolder::~AuditFolder%63FE474403B7_dest.body preserve=yes
  //## end metaoperator::AuditFolder::~AuditFolder%63FE474403B7_dest.body
}



//## Other Operations (implementation)
bool AuditFolder::report (command::Email* pEmail)
{
  //## begin metaoperator::AuditFolder::report%63FE47FE007B.body preserve=yes
   MetaOperator* p = dynamic_cast<metaoperator::MetaOperator*>(Application::instance());
   vector<Rule>& r = p->getRule();
   string strTemp;
   for (int i = 0;i < r.size();++i)
   {
      m_hTimestamp[0].push_back(strTemp);
      m_hTimestamp[1].push_back(strTemp);
   }
   pEmail->report('A');
   Query hQuery;
   hQuery.attach(this);
   hQuery.setQualifier("QUALIFY","AUDIT_EVENT");
   hQuery.bind("AUDIT_EVENT","TSTAMP_CREATED",Column::STRING,&m_strTSTAMP_CREATED);
   hQuery.bind("AUDIT_EVENT","RESOURCE_KEY",Column::STRING,&m_strRESOURCE_KEY);
   Date hDate(entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(0).c_str());
   hDate -= 1;
   hQuery.setBasicPredicate("AUDIT_EVENT","USER_ID","=","MZ");
   hQuery.setBasicPredicate("AUDIT_EVENT","RESOURCE_NAME","=","RULE");
   hQuery.setBasicPredicate("AUDIT_EVENT","RESOURCE_KEY",">",hDate.asString("%Y%m%d").c_str());
   hQuery.setOrderByClause("RESOURCE_KEY");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (pSelectStatement->execute(hQuery) == false
      || pSelectStatement->getRows() == 0)
      return false;
   for (int j = 0;j < r.size();++j)
   {
      usersegment::EmailSegment::instance()->setField("Name",r[j].getName());
      usersegment::EmailSegment::instance()->setField("Yesterday",m_hTimestamp[0][j]);
      usersegment::EmailSegment::instance()->setField("Today",m_hTimestamp[1][j]);
      usersegment::EmailSegment::instance()->setField("Status",m_hTimestamp[1][j].empty() ? "WARNING" : "OK");
      pEmail->report('B');
   }
   return true;
  //## end metaoperator::AuditFolder::report%63FE47FE007B.body
}

void AuditFolder::update (Subject* pSubject)
{
  //## begin metaoperator::AuditFolder::update%63FE48090329.body preserve=yes
   string strDate(m_strRESOURCE_KEY.data(),8);
   string strName(m_strRESOURCE_KEY.c_str() + 9);
   m_strTSTAMP_CREATED.insert(14,":",1);
   m_strTSTAMP_CREATED.insert(12,":",1);
   m_strTSTAMP_CREATED.insert(10,":",1);
   m_strTSTAMP_CREATED.insert(8," ",1);
   m_strTSTAMP_CREATED.insert(6,"-",1);
   m_strTSTAMP_CREATED.insert(4,"-",1);
   MetaOperator* p = dynamic_cast<metaoperator::MetaOperator*>(Application::instance());
   vector<Rule>& r = p->getRule();
   for (int j = 0;j < r.size();++j)
      if (r[j].getName() == strName)
      {
         int i = strDate == entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(0) ? 1 : 0;
         m_hTimestamp[i][j] = m_strTSTAMP_CREATED;
         break;
      }
  //## end metaoperator::AuditFolder::update%63FE48090329.body
}

// Additional Declarations
  //## begin metaoperator::AuditFolder%63FE474403B7.declarations preserve=yes
  //## end metaoperator::AuditFolder%63FE474403B7.declarations

} // namespace metaoperator

//## begin module%63FE494B035D.epilog preserve=yes
//## end module%63FE494B035D.epilog
