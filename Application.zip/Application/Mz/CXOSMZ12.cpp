//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%639CCBAB0093.cm preserve=no
//## end module%639CCBAB0093.cm

//## begin module%639CCBAB0093.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%639CCBAB0093.cp

//## Module: CXOSMZ12%639CCBAB0093; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ12.cpp

//## begin module%639CCBAB0093.additionalIncludes preserve=no
//## end module%639CCBAB0093.additionalIncludes

//## begin module%639CCBAB0093.includes preserve=yes
//## end module%639CCBAB0093.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSUS21_h
#include "CXODUS21.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSBC25_h
#include "CXODBC25.hpp"
#endif
#ifndef CXOSMZ12_h
#include "CXODMZ12.hpp"
#endif


//## begin module%639CCBAB0093.declarations preserve=no
//## end module%639CCBAB0093.declarations

//## begin module%639CCBAB0093.additionalDeclarations preserve=yes
//## end module%639CCBAB0093.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::ClearingFolder 

ClearingFolder::ClearingFolder()
  //## begin ClearingFolder::ClearingFolder%639CCB4902A3_const.hasinit preserve=no
      : m_iROW_NUMBER(0),
        m_pEmail(0)
  //## end ClearingFolder::ClearingFolder%639CCB4902A3_const.hasinit
  //## begin ClearingFolder::ClearingFolder%639CCB4902A3_const.initialization preserve=yes
  //## end ClearingFolder::ClearingFolder%639CCB4902A3_const.initialization
{
  //## begin metaoperator::ClearingFolder::ClearingFolder%639CCB4902A3_const.body preserve=yes
   memcpy(m_sID,"MZ12",4);
   for (int i = 0;i < 6;++i)
      m_iTRAN_COUNT[i] = 0;
  //## end metaoperator::ClearingFolder::ClearingFolder%639CCB4902A3_const.body
}


ClearingFolder::~ClearingFolder()
{
  //## begin metaoperator::ClearingFolder::~ClearingFolder%639CCB4902A3_dest.body preserve=yes
  //## end metaoperator::ClearingFolder::~ClearingFolder%639CCB4902A3_dest.body
}



//## Other Operations (implementation)
bool ClearingFolder::report (command::Email* pEmail)
{
  //## begin metaoperator::ClearingFolder::report%639CD8CA0250.body preserve=yes
   m_pEmail = pEmail;
   m_strNETWORK_ID[0].erase();
   m_strPROC_ID[0].erase();
   m_strINST_ID[0].erase();
   Query hQuery;
   hQuery.attach(this);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   for (int i = 0;i < 2;++i)
   {
      usersegment::EmailSegment::instance()->setField("DATE",entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(i));
      m_pEmail->report('H');
      hQuery.reset();
      hQuery.join("PROCESSOR","INNER","INSTITUTION","PROC_ID");
      hQuery.join("INSTITUTION","LEFT OUTER","T_RECON_TOTAL","INST_ID");
      hQuery.join(0,"LEFT OUTER","T_RECON_TOTAL",entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(i).c_str(),"DATE_RECON_ISS");
      hQuery.join(0,"LEFT OUTER","T_RECON_TOTAL","~200","ROW_NUMBER","<");
      hQuery.setQualifier("QUALIFY","PROCESSOR");
      hQuery.setQualifier("QUALIFY","INSTITUTION");
      hQuery.bind("INSTITUTION","NAME",Column::STRING,&m_strNETWORK_ID[1]);
      hQuery.bind("INSTITUTION","PROC_ID",Column::STRING,&m_strPROC_ID[1]);
      hQuery.bind("INSTITUTION","INST_ID",Column::STRING,&m_strINST_ID[1]);
      hQuery.bind("T_RECON_TOTAL","ROW_NUMBER",Column::LONG,&m_iROW_NUMBER);
      hQuery.bind("T_RECON_TOTAL","REPORT_SOURCE",Column::STRING,&m_strREPORT_SOURCE);
      hQuery.bind("T_RECON_TOTAL","REPORT_NAME",Column::STRING,&m_strREPORT_NAME);
      hQuery.bind("T_RECON_TOTAL","TRAN_COUNT",Column::LONG,&m_iTRAN_COUNT[6]);
      hQuery.setBasicPredicate("PROCESSOR","PROC_GRP_ID","=","ACQUIRER");
      hQuery.setBasicPredicate("PROCESSOR","CC_CHANGE_GRP_ID","IS NULL");
      hQuery.setBasicPredicate("PROCESSOR","CC_STATE","=","A");
      hQuery.setBasicPredicate("INSTITUTION","CC_CHANGE_GRP_ID","IS NULL");
      hQuery.setBasicPredicate("INSTITUTION","CC_STATE","=","A");
      hQuery.setGroupByClause("NAME,PROC_ID,INST_ID,ROW_NUMBER,REPORT_SOURCE,REPORT_NAME HAVING SUM(TRAN_COUNT) > 0");
      hQuery.setOrderByClause("NAME,PROC_ID,INST_ID,ROW_NUMBER,REPORT_SOURCE,REPORT_NAME");
      if (!pSelectStatement->execute(hQuery))
         return false;
      if (pSelectStatement->getRows() > 0)
         report();
   }
   return true;
  //## end metaoperator::ClearingFolder::report%639CD8CA0250.body
}

bool ClearingFolder::report ()
{
  //## begin metaoperator::ClearingFolder::report%639CDB850048.body preserve=yes
   char pszTemp[7] = {"012345"};
   char pszName[12] = {"TRAN_COUNT0"};
   char szTemp[PERCENTD];
   for (int i = 0;i < 6;++i)
   {
      snprintf(szTemp,PERCENTD,"%d",m_iTRAN_COUNT[i]);
      pszName[10] = pszTemp[i];
      usersegment::EmailSegment::instance()->setField(pszName,szTemp);
   }
   usersegment::EmailSegment::instance()->setField("Status",m_iTRAN_COUNT[0] + m_iTRAN_COUNT[1] == m_iTRAN_COUNT[2] + m_iTRAN_COUNT[3] + m_iTRAN_COUNT[4] && m_iTRAN_COUNT[4] == m_iTRAN_COUNT[5] ? "OK" : "WARNING");
   return m_pEmail->report('D');
  //## end metaoperator::ClearingFolder::report%639CDB850048.body
}

void ClearingFolder::update (Subject* pSubject)
{
  //## begin metaoperator::ClearingFolder::update%639CCB67034E.body preserve=yes
   if (m_strNETWORK_ID[0] != m_strNETWORK_ID[1]
      || m_strPROC_ID[0] != m_strPROC_ID[1]
      || m_strINST_ID[0] != m_strINST_ID[1])
   {
      if (!m_strNETWORK_ID[0].empty())
         report();
      for (int i = 0;i < 6;++i)
         m_iTRAN_COUNT[i] = 0;
      m_strNETWORK_ID[0] = m_strNETWORK_ID[1];
      m_strPROC_ID[0] = m_strPROC_ID[1];
      m_strINST_ID[0] = m_strINST_ID[1];
      usersegment::EmailSegment::instance()->setField("NETWORK_ID",m_strNETWORK_ID[1]);
      usersegment::EmailSegment::instance()->setField("PROC_ID",m_strPROC_ID[1]);
      usersegment::EmailSegment::instance()->setField("INST_ID",m_strINST_ID[1]);
   }
   int i = 5;
   if (m_iROW_NUMBER == 198)
      i = 1;
   else
   if (m_strREPORT_SOURCE == "D")
      i = 0;
   else
   if (m_iROW_NUMBER == 197)
      i = 2;
   else
   if (m_iROW_NUMBER == 199)
      i = 3;
   else
   if (m_strREPORT_NAME == "BASEII"
      || m_strREPORT_NAME == "IP755120"
      || m_strREPORT_NAME == "TX-100-01")
      i = 4;
   m_iTRAN_COUNT[i] += m_iTRAN_COUNT[6];
  //## end metaoperator::ClearingFolder::update%639CCB67034E.body
}

// Additional Declarations
  //## begin metaoperator::ClearingFolder%639CCB4902A3.declarations preserve=yes
  //## end metaoperator::ClearingFolder%639CCB4902A3.declarations

} // namespace metaoperator

//## begin module%639CCBAB0093.epilog preserve=yes
//## end module%639CCBAB0093.epilog
