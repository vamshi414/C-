//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B45FBD01D5.cm preserve=no
//## end module%63B45FBD01D5.cm

//## begin module%63B45FBD01D5.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B45FBD01D5.cp

//## Module: CXOSMZ14%63B45FBD01D5; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ14.cpp

//## begin module%63B45FBD01D5.additionalIncludes preserve=no
//## end module%63B45FBD01D5.additionalIncludes

//## begin module%63B45FBD01D5.includes preserve=yes
//## end module%63B45FBD01D5.includes

#ifndef CXOSMZ02_h
#include "CXODMZ02.hpp"
#endif
#ifndef CXOSMZ14_h
#include "CXODMZ14.hpp"
#endif


//## begin module%63B45FBD01D5.declarations preserve=no
//## end module%63B45FBD01D5.declarations

//## begin module%63B45FBD01D5.additionalDeclarations preserve=yes
//## end module%63B45FBD01D5.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::ConditionFactory 

//## begin metaoperator::ConditionFactory::Instance%63B45F090302.attr preserve=no  private: static metaoperator::ConditionFactory* {V} 0
metaoperator::ConditionFactory* ConditionFactory::m_pInstance = 0;
//## end metaoperator::ConditionFactory::Instance%63B45F090302.attr

ConditionFactory::ConditionFactory()
  //## begin ConditionFactory::ConditionFactory%63B45ECB02A4_const.hasinit preserve=no
  //## end ConditionFactory::ConditionFactory%63B45ECB02A4_const.hasinit
  //## begin ConditionFactory::ConditionFactory%63B45ECB02A4_const.initialization preserve=yes
  //## end ConditionFactory::ConditionFactory%63B45ECB02A4_const.initialization
{
  //## begin metaoperator::ConditionFactory::ConditionFactory%63B45ECB02A4_const.body preserve=yes
   memcpy(m_sID,"MZ14",4);
  //## end metaoperator::ConditionFactory::ConditionFactory%63B45ECB02A4_const.body
}


ConditionFactory::~ConditionFactory()
{
  //## begin metaoperator::ConditionFactory::~ConditionFactory%63B45ECB02A4_dest.body preserve=yes
  //## end metaoperator::ConditionFactory::~ConditionFactory%63B45ECB02A4_dest.body
}



//## Other Operations (implementation)
metaoperator::Condition* ConditionFactory::create (const reusable::string& strName)
{
  //## begin metaoperator::ConditionFactory::create%63B45F1A026D.body preserve=yes
   map<string,cloneFunction,less<string> >::iterator p = m_hCondition.find(strName);
   if (p == m_hCondition.end())
      return 0;
   return (*p).second();
  //## end metaoperator::ConditionFactory::create%63B45F1A026D.body
}

metaoperator::ConditionFactory* ConditionFactory::instance ()
{
  //## begin metaoperator::ConditionFactory::instance%63B45F1A0290.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new ConditionFactory();
   return m_pInstance;
  //## end metaoperator::ConditionFactory::instance%63B45F1A0290.body
}

bool ConditionFactory::registerCondition (const reusable::string& strName, cloneFunction hCloneFunction)
{
  //## begin metaoperator::ConditionFactory::registerCondition%63B45F1A02A1.body preserve=yes
   m_hCondition[strName] = hCloneFunction;
   return true;
  //## end metaoperator::ConditionFactory::registerCondition%63B45F1A02A1.body
}

// Additional Declarations
  //## begin metaoperator::ConditionFactory%63B45ECB02A4.declarations preserve=yes
  //## end metaoperator::ConditionFactory%63B45ECB02A4.declarations

} // namespace metaoperator

//## begin module%63B45FBD01D5.epilog preserve=yes
//## end module%63B45FBD01D5.epilog
