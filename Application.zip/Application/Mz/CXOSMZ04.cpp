//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%638FF3970022.cm preserve=no
//## end module%638FF3970022.cm

//## begin module%638FF3970022.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%638FF3970022.cp

//## Module: CXOSMZ04%638FF3970022; Package body
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXOSMZ04.cpp

//## begin module%638FF3970022.additionalIncludes preserve=no
//## end module%638FF3970022.additionalIncludes

//## begin module%638FF3970022.includes preserve=yes
//## end module%638FF3970022.includes

#ifndef CXOSMZ03_h
#include "CXODMZ03.hpp"
#endif
#ifndef CXOSMZ04_h
#include "CXODMZ04.hpp"
#endif


//## begin module%638FF3970022.declarations preserve=no
//## end module%638FF3970022.declarations

//## begin module%638FF3970022.additionalDeclarations preserve=yes
//## end module%638FF3970022.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

// Class metaoperator::FunctionFactory 

//## begin metaoperator::FunctionFactory::Instance%638FF2D3019D.attr preserve=no  private: static metaoperator::FunctionFactory* {V} 0
metaoperator::FunctionFactory* FunctionFactory::m_pInstance = 0;
//## end metaoperator::FunctionFactory::Instance%638FF2D3019D.attr

FunctionFactory::FunctionFactory()
  //## begin FunctionFactory::FunctionFactory%638FF2900111_const.hasinit preserve=no
  //## end FunctionFactory::FunctionFactory%638FF2900111_const.hasinit
  //## begin FunctionFactory::FunctionFactory%638FF2900111_const.initialization preserve=yes
  //## end FunctionFactory::FunctionFactory%638FF2900111_const.initialization
{
  //## begin metaoperator::FunctionFactory::FunctionFactory%638FF2900111_const.body preserve=yes
   memcpy(m_sID,"MZ04",4);
  //## end metaoperator::FunctionFactory::FunctionFactory%638FF2900111_const.body
}


FunctionFactory::~FunctionFactory()
{
  //## begin metaoperator::FunctionFactory::~FunctionFactory%638FF2900111_dest.body preserve=yes
  //## end metaoperator::FunctionFactory::~FunctionFactory%638FF2900111_dest.body
}



//## Other Operations (implementation)
Function* FunctionFactory::create (const reusable::string& strName)
{
  //## begin metaoperator::FunctionFactory::create%638FF2E00256.body preserve=yes
   map<string,cloneFunction,less<string> >::iterator p = m_hFunction.find(strName);
   if (p == m_hFunction.end())
      return 0;
   return (*p).second();
  //## end metaoperator::FunctionFactory::create%638FF2E00256.body
}

FunctionFactory* FunctionFactory::instance ()
{
  //## begin metaoperator::FunctionFactory::instance%638FF2E00280.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new FunctionFactory();
   return m_pInstance;
  //## end metaoperator::FunctionFactory::instance%638FF2E00280.body
}

bool FunctionFactory::registerFunction (const reusable::string& strName, cloneFunction hCloneFunction)
{
  //## begin metaoperator::FunctionFactory::registerFunction%638FF2E002A7.body preserve=yes
   m_hFunction[strName] = hCloneFunction;
   return true;
  //## end metaoperator::FunctionFactory::registerFunction%638FF2E002A7.body
}

// Additional Declarations
  //## begin metaoperator::FunctionFactory%638FF2900111.declarations preserve=yes
  //## end metaoperator::FunctionFactory%638FF2900111.declarations

} // namespace metaoperator

//## begin module%638FF3970022.epilog preserve=yes
//## end module%638FF3970022.epilog
