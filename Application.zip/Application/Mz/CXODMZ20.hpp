//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63B4A47100CE.cm preserve=no
//## end module%63B4A47100CE.cm

//## begin module%63B4A47100CE.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63B4A47100CE.cp

//## Module: CXOSMZ20%63B4A47100CE; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ20.hpp

#ifndef CXOSMZ20_h
#define CXOSMZ20_h 1

//## begin module%63B4A47100CE.additionalIncludes preserve=no
//## end module%63B4A47100CE.additionalIncludes

//## begin module%63B4A47100CE.includes preserve=yes
//## end module%63B4A47100CE.includes

#ifndef CXOSMZ03_h
#include "CXODMZ03.hpp"
#endif

//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
class Condition;
} // namespace metaoperator

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Job;

} // namespace IF

//## begin module%63B4A47100CE.declarations preserve=no
//## end module%63B4A47100CE.declarations

//## begin module%63B4A47100CE.additionalDeclarations preserve=yes
//## end module%63B4A47100CE.additionalDeclarations


namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::FTP%63B4A357013D.preface preserve=yes
//## end metaoperator::FTP%63B4A357013D.preface

//## Class: FTP%63B4A357013D
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%63B6D077027C;IF::Job { -> F}
//## Uses: <unnamed>%63B6D1D2000C;Condition { -> F}

class DllExport FTP : public Function  //## Inherits: <unnamed>%63B4A36202B8
{
  //## begin metaoperator::FTP%63B4A357013D.initialDeclarations preserve=yes
  //## end metaoperator::FTP%63B4A357013D.initialDeclarations

  public:
    //## Constructors (generated)
      FTP();

    //## Destructor (generated)
      virtual ~FTP();


    //## Other Operations (specified)
      //## Operation: execute%63B4A3700185
      virtual int execute ();

    // Additional Public Declarations
      //## begin metaoperator::FTP%63B4A357013D.public preserve=yes
      //## end metaoperator::FTP%63B4A357013D.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::FTP%63B4A357013D.protected preserve=yes
      //## end metaoperator::FTP%63B4A357013D.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::FTP%63B4A357013D.private preserve=yes
      //## end metaoperator::FTP%63B4A357013D.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin metaoperator::FTP%63B4A357013D.implementation preserve=yes
      //## end metaoperator::FTP%63B4A357013D.implementation

};

//## begin metaoperator::FTP%63B4A357013D.postscript preserve=yes
//## end metaoperator::FTP%63B4A357013D.postscript

} // namespace metaoperator

//## begin module%63B4A47100CE.epilog preserve=yes
//## end module%63B4A47100CE.epilog


#endif
