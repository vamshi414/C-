//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%65F2FE700305.cm preserve=no
//## end module%65F2FE700305.cm

//## begin module%65F2FE700305.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%65F2FE700305.cp

//## Module: CXOSMZ26%65F2FE700305; Package specification
//## Subsystem: MZ%6234D64601FA
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Mz\CXODMZ26.hpp

#ifndef CXOSMZ26_h
#define CXOSMZ26_h 1

//## begin module%65F2FE700305.additionalIncludes preserve=no
//## end module%65F2FE700305.additionalIncludes

//## begin module%65F2FE700305.includes preserve=yes
//## end module%65F2FE700305.includes

#ifndef CXOSMZ02_h
#include "CXODMZ02.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%65F2FE700305.declarations preserve=no
//## end module%65F2FE700305.declarations

//## begin module%65F2FE700305.additionalDeclarations preserve=yes
//## end module%65F2FE700305.additionalDeclarations


//## Modelname: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
namespace metaoperator {
//## begin metaoperator%6234A549012B.initialDeclarations preserve=yes
//## end metaoperator%6234A549012B.initialDeclarations

//## begin metaoperator::Total%65F2F9BD035F.preface preserve=yes
//## end metaoperator::Total%65F2F9BD035F.preface

//## Class: Total%65F2F9BD035F
//## Category: DataNavigator Foundation::Application::MetaOperator_CAT%6234A549012B
//## Subsystem: MZ%6234D64601FA
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%65F2FCBD02DD;reusable::Query { -> F}
//## Uses: <unnamed>%65F2FCC200D2;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%65F2FCC703DB;reusable::SelectStatement { -> F}

class DllExport Total : public Condition  //## Inherits: <unnamed>%65F2FC6A0283
{
  //## begin metaoperator::Total%65F2F9BD035F.initialDeclarations preserve=yes
  //## end metaoperator::Total%65F2F9BD035F.initialDeclarations

  public:
    //## Constructors (generated)
      Total();

    //## Destructor (generated)
      virtual ~Total();


    //## Other Operations (specified)
      //## Operation: test%65F2FC7402C3
      virtual bool test ();

    // Additional Public Declarations
      //## begin metaoperator::Total%65F2F9BD035F.public preserve=yes
      //## end metaoperator::Total%65F2F9BD035F.public

  protected:
    // Additional Protected Declarations
      //## begin metaoperator::Total%65F2F9BD035F.protected preserve=yes
      //## end metaoperator::Total%65F2F9BD035F.protected

  private:
    // Additional Private Declarations
      //## begin metaoperator::Total%65F2F9BD035F.private preserve=yes
      //## end metaoperator::Total%65F2F9BD035F.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin metaoperator::Total%65F2F9BD035F.implementation preserve=yes
      //## end metaoperator::Total%65F2F9BD035F.implementation

};

//## begin metaoperator::Total%65F2F9BD035F.postscript preserve=yes
//## end metaoperator::Total%65F2F9BD035F.postscript

} // namespace metaoperator

//## begin module%65F2FE700305.epilog preserve=yes
//## end module%65F2FE700305.epilog


#endif
