//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A3A6FE00109.cm preserve=no
//## end module%3A3A6FE00109.cm

//## begin module%3A3A6FE00109.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3A3A6FE00109.cp

//## Module: CXOPDI00%3A3A6FE00109; Package body
//## Subsystem: DI%3A3A6F9801CE
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Di\CXOPDI00.cpp

//## begin module%3A3A6FE00109.additionalIncludes preserve=no
//## end module%3A3A6FE00109.additionalIncludes

//## begin module%3A3A6FE00109.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),ENVAR('TASK=DI'))
#endif
#ifndef MVS
#ifndef _AIX
#include "CXODKQ01.hpp"
#include "CXODMC21.hpp"
#include "CXODMC32.hpp"
#endif
#endif
//## end module%3A3A6FE00109.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSAR03_h
#include "CXODAR03.hpp"
#endif
#ifndef CXOSNS39_h
#include "CXODNS39.hpp"
#endif
#ifndef CXOSNC12_h
#include "CXODNC12.hpp"
#endif
#ifndef CXOSRC09_h
#include "CXODRC09.hpp"
#endif
#ifndef CXOSRC10_h
#include "CXODRC10.hpp"
#endif
#ifndef CXOSRC11_h
#include "CXODRC11.hpp"
#endif
#ifndef CXOSRC07_h
#include "CXODRC07.hpp"
#endif
#ifndef CXOSSX05_h
#include "CXODSX05.hpp"
#endif
#ifndef CXOSSX29_h
#include "CXODSX29.hpp"
#endif
#ifndef CXOSSX37_h
#include "CXODSX37.hpp"
#endif
#ifndef CXOSDB22_h
#include "CXODDB22.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOPDI00_h
#include "CXODDI00.hpp"
#endif


//## begin module%3A3A6FE00109.declarations preserve=no
//## end module%3A3A6FE00109.declarations

//## begin module%3A3A6FE00109.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new DeviceInquiry();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%3A3A6FE00109.additionalDeclarations


// Class DeviceInquiry 

DeviceInquiry::DeviceInquiry()
  //## begin DeviceInquiry::DeviceInquiry%3A3A6EB403B1_const.hasinit preserve=no
      : m_pVendorModelListCommand(0),
        m_pDeviceStatusListCommand(0),
        m_pStatusListCommand(0),
        m_pDeviceCommentAllCommand(0),
        m_pDeviceCommentCreateCommand(0),
        m_pATMReceiptListCommand(0),
        m_pATMReplenishmentListCommand(0),
        m_pATMStream(0),
        m_pAuditStream(0)
  //## end DeviceInquiry::DeviceInquiry%3A3A6EB403B1_const.hasinit
  //## begin DeviceInquiry::DeviceInquiry%3A3A6EB403B1_const.initialization preserve=yes
  //## end DeviceInquiry::DeviceInquiry%3A3A6EB403B1_const.initialization
{
  //## begin DeviceInquiry::DeviceInquiry%3A3A6EB403B1_const.body preserve=yes
   memcpy(m_sID,"DI00",4);
  //## end DeviceInquiry::DeviceInquiry%3A3A6EB403B1_const.body
}

DeviceInquiry::~DeviceInquiry()
{
  //## begin DeviceInquiry::~DeviceInquiry%3A3A6EB403B1_dest.body preserve=yes
   delete m_pVendorModelListCommand;
   delete m_pDeviceStatusListCommand;
   delete m_pDeviceCommentCreateCommand;
   delete m_pDeviceCommentAllCommand;
   delete m_pStatusListCommand;
   delete m_pATMReplenishmentListCommand;
   delete m_pATMStream;
   delete m_pAuditStream;
  //## end DeviceInquiry::~DeviceInquiry%3A3A6EB403B1_dest.body
}

//## Other Operations (implementation)
int DeviceInquiry::initialize ()
{
  //## begin DeviceInquiry::initialize%3A3A6F650365.body preserve=yes
   new dnplatform::DNPlatform();
   int i = ServiceApplication::initialize();
   UseCase hUseCase("CLIENT","## CL74 START DI");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   m_pVendorModelListCommand = new VendorModelListCommand(0);
   m_pDeviceStatusListCommand = new DeviceStatusListCommand(m_pVendorModelListCommand);
   m_pDeviceCommentCreateCommand = new DeviceCommentCreateCommand(m_pDeviceStatusListCommand);
   m_pDeviceCommentAllCommand = new DeviceCommentAllCommand(m_pDeviceCommentCreateCommand);
   m_pStatusListCommand = new StatusListCommand(m_pDeviceCommentAllCommand);
   m_pATMReceiptListCommand = new soapcommand::ATMReceiptListCommand(m_pStatusListCommand);
   m_pSXStatusListCommand = new soapcommand::StatusListCommand(m_pATMReceiptListCommand);
   m_pATMReplenishmentListCommand = new soapcommand::ATMReplenishmentListCommand(m_pSXStatusListCommand);
   entitysegment::Progress::instance();
#ifndef MVS
#ifndef _AIX
   string strValue;
   if (Extract::instance()->getSpec("MC21","QUEUE",strValue))
   {
      new kafka::KafkaQueueFactory();
      m_pATMStream = new managementcommand::ATMStream();
      m_pATMStream->setExternalQueue((ExternalQueue*)kafka::KafkaQueueFactory::instance()->create("Queue",strValue.c_str()));
   }
   if (Extract::instance()->getSpec("MC32","QUEUE",strValue))
   {
      new kafka::KafkaQueueFactory();
      m_pAuditStream = new managementcommand::AuditStream();
      m_pAuditStream->setExternalQueue((ExternalQueue*)kafka::KafkaQueueFactory::instance()->create("Queue",strValue.c_str()));
   }
#endif
#endif
   Database::instance()->attach(this);
   Database::instance()->connect();
   return 0;
  //## end DeviceInquiry::initialize%3A3A6F650365.body
}

int DeviceInquiry::onMessage (Message& hMessage)
{
  //## begin DeviceInquiry::onMessage%3A3A6F69016C.body preserve=yes
   Transaction::instance()->begin();
   string strTimeStamp(Clock::instance()->getYYYYMMDDHHMMSS(true));
   Transaction::instance()->setTimeStamp(strTimeStamp += "00");
   m_pATMReplenishmentListCommand->update(Message::instance(Message::INBOUND));
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      Database::instance()->rollback();
   else
      Database::instance()->commit();
   Transaction::instance()->commit();
   idle();
   return 0;
  //## end DeviceInquiry::onMessage%3A3A6F69016C.body
}

int DeviceInquiry::onReset (Message& hMessage)
{
  //## begin DeviceInquiry::onReset%3D81E1AD003E.body preserve=yes
   if (hMessage.context().indexOf("DELETE") > 0)
   {
      UseCase hUseCase("DR","## DR54 DELETE DEVICE COMMENTS");
      GenericDelete hGenericDelete("DEVICE_COMMENT","TSTAMP_CREATED");
      hGenericDelete.deleteRecords("TSTAMP_CREATED",hMessage.context().subString(9).data());
   }
   if (Database::instance()->transactionState() == Database::COMMITREQUIRED)
      Database::instance()->commit();
   else
      Database::instance()->rollback();
   return 0;
  //## end DeviceInquiry::onReset%3D81E1AD003E.body
}

int DeviceInquiry::onResume (Message& hMessage)
{
  //## begin DeviceInquiry::onResume%6112628E02B9.body preserve=yes
#ifndef MVS
#ifndef _AIX
   if (m_pATMStream)
      m_pATMStream->onResume();
   if (m_pAuditStream)
      m_pAuditStream->onResume();
#endif
#endif
   return 0;
  //## end DeviceInquiry::onResume%6112628E02B9.body
}

void DeviceInquiry::update (Subject* pSubject)
{
  //## begin DeviceInquiry::update%3A3A7347001B.body preserve=yes
   if (pSubject == Database::instance())
   {
      if (Database::instance()->state() == Database::CONNECTED)
      {
         Queue::attach("@##SERVER",Queue::CX_DISTRIBUTION_QUEUE);
         Database::instance()->commit();
      }
   }
   ServiceApplication::update(pSubject);
  //## end DeviceInquiry::update%3A3A7347001B.body
}

// Additional Declarations
  //## begin DeviceInquiry%3A3A6EB403B1.declarations preserve=yes
  //## end DeviceInquiry%3A3A6EB403B1.declarations

//## begin module%3A3A6FE00109.epilog preserve=yes
//## end module%3A3A6FE00109.epilog
