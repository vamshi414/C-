//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3A3A6FDE02E7.cm preserve=no
//## end module%3A3A6FDE02E7.cm

//## begin module%3A3A6FDE02E7.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3A3A6FDE02E7.cp

//## Module: CXOPDI00%3A3A6FDE02E7; Package specification
//## Subsystem: DI%3A3A6F9801CE
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Di\CXODDI00.hpp

#ifndef CXOPDI00_h
#define CXOPDI00_h 1

//## begin module%3A3A6FDE02E7.additionalIncludes preserve=no
//## end module%3A3A6FDE02E7.additionalIncludes

//## begin module%3A3A6FDE02E7.includes preserve=yes
//## end module%3A3A6FDE02E7.includes

#ifndef CXOSPS03_h
#include "CXODPS03.hpp"
#endif

//## Modelname: Device Management::ManagementCommand_CAT%3A06C995022A
namespace managementcommand {
class AuditStream;
class ATMStream;
} // namespace managementcommand

//## Modelname: Continuous Feed::Kafka_CAT%6111C9880032
namespace kafka {
class KafkaQueueFactory;
} // namespace kafka

//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
class ArchiveRetriever;
} // namespace archive

//## Modelname: DataNavigator Foundation::EntityCommand_CAT%394E2706012A
namespace entitycommand {
class VendorModelListCommand;
} // namespace entitycommand

//## Modelname: DataNavigator Foundation::RepositoryCommand_CAT%394E267C0078
namespace repositorycommand {
class DeviceCommentAllCommand;
class StatusListCommand;
class DeviceCommentCreateCommand;
class DeviceStatusListCommand;
} // namespace repositorycommand

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: DataNavigator Foundation::SOAPCommand_CAT%4DC0633D0140
namespace soapcommand {
class ATMReceiptListCommand;
class ATMReplenishmentListCommand;
class StatusListCommand;
} // namespace soapcommand

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class Database;

} // namespace database

//## begin module%3A3A6FDE02E7.declarations preserve=no
//## end module%3A3A6FDE02E7.declarations

//## begin module%3A3A6FDE02E7.additionalDeclarations preserve=yes
//## end module%3A3A6FDE02E7.additionalDeclarations


//## begin DeviceInquiry%3A3A6EB403B1.preface preserve=yes
//## end DeviceInquiry%3A3A6EB403B1.preface

//## Class: DeviceInquiry%3A3A6EB403B1
//	<body>
//	<title>CG
//	<h1>DI
//	<h2>AB
//	<p>
//	Device Inquiry allows you to monitor your ATM network
//	7*24 from the DataNavigator client application.
//	It provides inquiry access to the status of your
//	terminals and identifies when and why your devices are
//	troubled or down.
//	<p>
//	You can:
//	<p>
//	<ul>
//	<li>View only your troubled devices that have open
//	tickets with our ATM monitoring tool and display current
//	status information.
//	<li>View all your devices and display status history
//	messages on any device.
//	<li>Find a specific device based on a set of search
//	criteria.
//	<li>Add on-line comments about troubled devices so that
//	your internal staff knows what action has taken place
//	for specific ATMs.
//	</ul>
//	<p>
//	Device Inquiry increases efficiency and improves
//	productivity and profitability of your ATM network.
//	It provides you with a quick and easy means to identify
//	specific ATM problems early and be proactive in
//	returning your devices to working order.
//	<h3>System Flow
//	<p>
//	The DataNavigator server maintains the current status of
//	each network terminal.
//	<p>
//	The Device Inquiry service (<i>ca</i>DI) retrieves
//	device status information for end users.
//	Requests come through the Client Interface service
//	(<i>ca</i>CI01).
//	</p>
//	<img src=CXOCDI00.gif>
//	<p>
//	Refer to the <i>DataNavigator Client Device Services
//	User's Guide</i> for more information.
//	</p>
//	</body>
//	<body>
//	<title>OG
//	<h1>DI
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server maintains the current status of
//	each network terminal.
//	<p>
//	The Device Inquiry service (<i>ca</i>DI) retrieves
//	device status information for end users.
//	</p>
//	<img src=CXOODI00.gif>
//	<p>
//	<h2>TS
//	<h3>DataNavigator Client
//	<p>
//	<b>Issue:</b>  End user reporting problems with services
//	provided by Device Inquiry.
//	<p>
//	<b>Resolution:</b>  Refer to the Troubleshooting tips
//	for the Client Interface in the <i>DataNavigator Server
//	Operations Guide: Foundation</i> manual.
//	</p>
//	</body>
//## Category: Device Management::DeviceInquiry_CAT%3A3A6E89026F
//## Subsystem: DI%3A3A6F9801CE
//## Persistence: Transient
//## Cardinality/Multiplicity: 0..n



//## Uses: <unnamed>%3A3A6F3A0382;database::Database { -> F}
//## Uses: <unnamed>%3A3A6F450098;IF::Message { -> F}
//## Uses: <unnamed>%3A3A70FF02C5;monitor::UseCase { -> F}
//## Uses: <unnamed>%3A3A77BF0175;database::GlobalContext { -> F}
//## Uses: <unnamed>%3A3A77CF022C;reusable::Transaction { -> F}
//## Uses: <unnamed>%3A6ED5B902DC;timer::Clock { -> F}
//## Uses: <unnamed>%3BCED186036B;IF::Queue { -> F}
//## Uses: <unnamed>%3D81E17E00CB;database::GenericDelete { -> F}
//## Uses: <unnamed>%3D860762038A;IF::Extract { -> F}
//## Uses: <unnamed>%40AB87D80128;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%47D16DB40112;archive::ArchiveRetriever { -> F}
//## Uses: <unnamed>%611262EB023A;kafka::KafkaQueueFactory { -> F}
//## Uses: <unnamed>%611263040380;managementcommand::ATMStream { -> F}
//## Uses: <unnamed>%627917FA0100;managementcommand::AuditStream { -> F}

class DeviceInquiry : public process::ServiceApplication  //## Inherits: <unnamed>%3BCED11900FA
{
  //## begin DeviceInquiry%3A3A6EB403B1.initialDeclarations preserve=yes
  //## end DeviceInquiry%3A3A6EB403B1.initialDeclarations

  public:
    //## Constructors (generated)
      DeviceInquiry();

    //## Destructor (generated)
      virtual ~DeviceInquiry();


    //## Other Operations (specified)
      //## Operation: initialize%3A3A6F650365
      virtual int initialize ();

      //## Operation: update%3A3A7347001B
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin DeviceInquiry%3A3A6EB403B1.public preserve=yes
      //## end DeviceInquiry%3A3A6EB403B1.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%3A3A6F69016C
      virtual int onMessage (Message& hMessage);

      //## Operation: onReset%3D81E1AD003E
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>DI
      //	<h2>CD
      //	<h3>Delete Device Comments
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>DI DELETE 6MONTHS
      //	<h4>Description
      //	<p>
      //	The Device Inquiry service deletes all comments prior to
      //	the last six months of data.
      //	</p>
      //	<h4>Schedule
      //	<p>
      //	The DataNavigator Server installation automatically sets
      //	up an event to perform this command at 03:00 AM.
      //	Use the CR Client to change the time or the number of
      //	months of data to retain.
      //	<p>
      //	The Events are in the Event Management folder in the CR
      //	Client for the DataNavigator Server.
      //	</p>
      //	</body>
      virtual int onReset (Message& hMessage);

      //## Operation: onResume%6112628E02B9
      virtual int onResume (Message& hMessage);

    // Additional Protected Declarations
      //## begin DeviceInquiry%3A3A6EB403B1.protected preserve=yes
      //## end DeviceInquiry%3A3A6EB403B1.protected

  private:
    // Additional Private Declarations
      //## begin DeviceInquiry%3A3A6EB403B1.private preserve=yes
      //## end DeviceInquiry%3A3A6EB403B1.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Device Management::DeviceInquiry_CAT::<unnamed>%3A3A967A01A9
      //## Role: DeviceInquiry::<m_pVendorModelListCommand>%3A3A967B01B5
      //## begin DeviceInquiry::<m_pVendorModelListCommand>%3A3A967B01B5.role preserve=no  public: entitycommand::VendorModelListCommand { -> RFHgN}
      entitycommand::VendorModelListCommand *m_pVendorModelListCommand;
      //## end DeviceInquiry::<m_pVendorModelListCommand>%3A3A967B01B5.role

      //## Association: Device Management::DeviceInquiry_CAT::<unnamed>%3D863409009C
      //## Role: DeviceInquiry::<m_pDeviceStatusListCommand>%3D86340A006D
      //## begin DeviceInquiry::<m_pDeviceStatusListCommand>%3D86340A006D.role preserve=no  public: repositorycommand::DeviceStatusListCommand { -> RFHgN}
      repositorycommand::DeviceStatusListCommand *m_pDeviceStatusListCommand;
      //## end DeviceInquiry::<m_pDeviceStatusListCommand>%3D86340A006D.role

      //## Association: Device Management::DeviceInquiry_CAT::<unnamed>%3D86343600EA
      //## Role: DeviceInquiry::<m_pStatusListCommand>%3D8634370119
      //## begin DeviceInquiry::<m_pStatusListCommand>%3D8634370119.role preserve=no  public: repositorycommand::StatusListCommand { -> RFHgN}
      repositorycommand::StatusListCommand *m_pStatusListCommand;
      //## end DeviceInquiry::<m_pStatusListCommand>%3D8634370119.role

      //## Association: Device Management::DeviceInquiry_CAT::<unnamed>%3D863513001F
      //## Role: DeviceInquiry::<m_pDeviceCommentAllCommand>%3D86351302CF
      //## begin DeviceInquiry::<m_pDeviceCommentAllCommand>%3D86351302CF.role preserve=no  public: repositorycommand::DeviceCommentAllCommand { -> RFHgN}
      repositorycommand::DeviceCommentAllCommand *m_pDeviceCommentAllCommand;
      //## end DeviceInquiry::<m_pDeviceCommentAllCommand>%3D86351302CF.role

      //## Association: Device Management::DeviceInquiry_CAT::<unnamed>%3D86413B0128
      //## Role: DeviceInquiry::<m_pDeviceCommentCreateCommand>%3D86413C0149
      //## begin DeviceInquiry::<m_pDeviceCommentCreateCommand>%3D86413C0149.role preserve=no  public: repositorycommand::DeviceCommentCreateCommand { -> RFHgN}
      repositorycommand::DeviceCommentCreateCommand *m_pDeviceCommentCreateCommand;
      //## end DeviceInquiry::<m_pDeviceCommentCreateCommand>%3D86413C0149.role

      //## Association: Device Management::DeviceInquiry_CAT::<unnamed>%521E075A0353
      //## Role: DeviceInquiry::<m_pATMReceiptListCommand>%521E075B02E4
      //## begin DeviceInquiry::<m_pATMReceiptListCommand>%521E075B02E4.role preserve=no  public: soapcommand::ATMReceiptListCommand { -> RFHgN}
      soapcommand::ATMReceiptListCommand *m_pATMReceiptListCommand;
      //## end DeviceInquiry::<m_pATMReceiptListCommand>%521E075B02E4.role

      //## Association: Device Management::DeviceInquiry_CAT::<unnamed>%5AB174530125
      //## Role: DeviceInquiry::<m_pSXStatusListCommand>%5AB17454017D
      //## begin DeviceInquiry::<m_pSXStatusListCommand>%5AB17454017D.role preserve=no  public: soapcommand::StatusListCommand { -> RFHgN}
      soapcommand::StatusListCommand *m_pSXStatusListCommand;
      //## end DeviceInquiry::<m_pSXStatusListCommand>%5AB17454017D.role

      //## Association: Device Management::DeviceInquiry_CAT::<unnamed>%5CD28C15002F
      //## Role: DeviceInquiry::<m_pATMReplenishmentListCommand>%5CD28C16015E
      //## begin DeviceInquiry::<m_pATMReplenishmentListCommand>%5CD28C16015E.role preserve=no  public: soapcommand::ATMReplenishmentListCommand { -> RFHgN}
      soapcommand::ATMReplenishmentListCommand *m_pATMReplenishmentListCommand;
      //## end DeviceInquiry::<m_pATMReplenishmentListCommand>%5CD28C16015E.role

      //## Association: Device Management::DeviceInquiry_CAT::<unnamed>%6279190E0146
      //## Role: DeviceInquiry::<m_pATMStream>%6279190F03A9
      //## begin DeviceInquiry::<m_pATMStream>%6279190F03A9.role preserve=no  public: managementcommand::ATMStream { -> RFHgN}
      managementcommand::ATMStream *m_pATMStream;
      //## end DeviceInquiry::<m_pATMStream>%6279190F03A9.role

      //## Association: Device Management::DeviceInquiry_CAT::<unnamed>%6279197A0117
      //## Role: DeviceInquiry::<m_pAuditStream>%6279197E0341
      //## begin DeviceInquiry::<m_pAuditStream>%6279197E0341.role preserve=no  public: managementcommand::AuditStream { -> RFHgN}
      managementcommand::AuditStream *m_pAuditStream;
      //## end DeviceInquiry::<m_pAuditStream>%6279197E0341.role

    // Additional Implementation Declarations
      //## begin DeviceInquiry%3A3A6EB403B1.implementation preserve=yes
      //## end DeviceInquiry%3A3A6EB403B1.implementation

};

//## begin DeviceInquiry%3A3A6EB403B1.postscript preserve=yes
//## end DeviceInquiry%3A3A6EB403B1.postscript

//## begin module%3A3A6FDE02E7.epilog preserve=yes
//## end module%3A3A6FDE02E7.epilog


#endif
