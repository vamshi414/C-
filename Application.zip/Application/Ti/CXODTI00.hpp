//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3884FB65034E.cm preserve=no
//	$Date:   Dec 13 2011 09:33:58  $ $Author:   e1009839  $
//	$Revision:   1.15  $
//## end module%3884FB65034E.cm

//## begin module%3884FB65034E.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%3884FB65034E.cp

//## Module: CXOPTI00%3884FB65034E; Package specification
//## Subsystem: TI%3884FB470319
//## Source file: C:\Devel\Dn\Server\Application\TI\CXODTI00.hpp

#ifndef CXOPTI00_h
#define CXOPTI00_h 1

//## begin module%3884FB65034E.additionalIncludes preserve=no
//## end module%3884FB65034E.additionalIncludes

//## begin module%3884FB65034E.includes preserve=yes
// $Date:   Dec 13 2011 09:33:58  $ $Author:   e1009839  $ $Revision:   1.15  $
//## end module%3884FB65034E.includes

#ifndef CXOSPS03_h
#include "CXODPS03.hpp"
#endif

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class Database;
} // namespace database

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;

} // namespace platform

//## begin module%3884FB65034E.declarations preserve=no
//## end module%3884FB65034E.declarations

//## begin module%3884FB65034E.additionalDeclarations preserve=yes
//## end module%3884FB65034E.additionalDeclarations


//## begin TotalsInquiry%3884FB1C015F.preface preserve=yes
//## end TotalsInquiry%3884FB1C015F.preface

//## Class: TotalsInquiry%3884FB1C015F
//	<body>
//	<title>CG
//	<h1>TI
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server provides real time and historic
//	views of the financial totals.
//	<p>
//	The following views are available:
//	<ul>
//	<li>Activity By Interchange
//	<li>Financial Detail
//	<li>Financial Settlement
//	<li>Financial Summary
//	</ul>
//	<img src=CXOCTI00.gif>
//	</body>
//	<body>
//	<title>OG
//	<h1>TI
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server provides real time and historic
//	views of the financial totals.
//	<p>
//	<img src=CXOOTI00.gif>
//	</p>
//	<h2>TS
//	<h3>DataNavigator Client
//	<p>
//	<b>Issue:</b>  End user reporting problems with services
//	provided by Totals Inquiry.
//	<p>
//	<b>Resolution:</b>  Refer to the Troubleshooting tips
//	for the Client Interface in the <i>DataNavigator Server
//	Operations Guide: Foundation</i> manual.
//	</p>
//	</body>
//## Category: Totals Management::TotalsInquiry_CAT%3884FAE701D1
//## Subsystem: TI%3884FB470319
//## Persistence: Transient
//## Cardinality/Multiplicity: 0..n



//## Uses: <unnamed>%388504AC0046;database::Database { -> F}
//## Uses: <unnamed>%38874FF00389;IF::Message { -> F}
//## Uses: <unnamed>%38EB81DA001F;reusable::Transaction { -> F}
//## Uses: <unnamed>%39B7D2A2039F;database::GlobalContext { -> F}
//## Uses: <unnamed>%3A3A70F10347;monitor::UseCase { -> F}
//## Uses: <unnamed>%3AD193D5029A;IF::Queue { -> F}
//## Uses: <unnamed>%40AA876E0027;platform::Platform { -> F}
//## Uses: <unnamed>%40AA87A601FE;dnplatform::DNPlatform { -> F}

class TotalsInquiry : public process::ServiceApplication  //## Inherits: <unnamed>%3BCEDB3003A9
{
  //## begin TotalsInquiry%3884FB1C015F.initialDeclarations preserve=yes
  //## end TotalsInquiry%3884FB1C015F.initialDeclarations

  public:
    //## Constructors (generated)
      TotalsInquiry();

    //## Destructor (generated)
      virtual ~TotalsInquiry();


    //## Other Operations (specified)
      //## Operation: initialize%3884FBE500A0
      virtual int initialize ();

      //## Operation: update%3A75F2F50336
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin TotalsInquiry%3884FB1C015F.public preserve=yes
      //## end TotalsInquiry%3884FB1C015F.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%388745D90212
      virtual int onMessage (IF::Message& hMessage);

    // Additional Protected Declarations
      //## begin TotalsInquiry%3884FB1C015F.protected preserve=yes
      //## end TotalsInquiry%3884FB1C015F.protected

  private:
    // Additional Private Declarations
      //## begin TotalsInquiry%3884FB1C015F.private preserve=yes
      //## end TotalsInquiry%3884FB1C015F.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin TotalsInquiry%3884FB1C015F.implementation preserve=yes
      //## end TotalsInquiry%3884FB1C015F.implementation

};

//## begin TotalsInquiry%3884FB1C015F.postscript preserve=yes
//## end TotalsInquiry%3884FB1C015F.postscript

//## begin module%3884FB65034E.epilog preserve=yes
//## end module%3884FB65034E.epilog


#endif
