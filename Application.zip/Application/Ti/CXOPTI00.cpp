//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3884FB67035B.cm preserve=no
//	$Date:   Jan 08 2015 15:15:56  $ $Author:   e1009839  $
//	$Revision:   1.24  $
//## end module%3884FB67035B.cm

//## begin module%3884FB67035B.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%3884FB67035B.cp

//## Module: CXOPTI00%3884FB67035B; Package body
//## Subsystem: TI%3884FB470319
//## Source file: C:\Devel\Dn\Server\Application\TI\CXOPTI00.cpp

//## begin module%3884FB67035B.additionalIncludes preserve=no
//## end module%3884FB67035B.additionalIncludes

//## begin module%3884FB67035B.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#include "CXODDB16.hpp"
//## end module%3884FB67035B.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOPTI00_h
#include "CXODTI00.hpp"
#endif


//## begin module%3884FB67035B.declarations preserve=no
//## end module%3884FB67035B.declarations

//## begin module%3884FB67035B.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new TotalsInquiry();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%3884FB67035B.additionalDeclarations


// Class TotalsInquiry

TotalsInquiry::TotalsInquiry()
  //## begin TotalsInquiry::TotalsInquiry%3884FB1C015F_const.hasinit preserve=no
  //## end TotalsInquiry::TotalsInquiry%3884FB1C015F_const.hasinit
  //## begin TotalsInquiry::TotalsInquiry%3884FB1C015F_const.initialization preserve=yes
  //## end TotalsInquiry::TotalsInquiry%3884FB1C015F_const.initialization
{
  //## begin TotalsInquiry::TotalsInquiry%3884FB1C015F_const.body preserve=yes
   memcpy(m_sID,"TI00",4);
  //## end TotalsInquiry::TotalsInquiry%3884FB1C015F_const.body
}


TotalsInquiry::~TotalsInquiry()
{
  //## begin TotalsInquiry::~TotalsInquiry%3884FB1C015F_dest.body preserve=yes
  //## end TotalsInquiry::~TotalsInquiry%3884FB1C015F_dest.body
}



//## Other Operations (implementation)
int TotalsInquiry::initialize ()
{
  //## begin TotalsInquiry::initialize%3884FBE500A0.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = ServiceApplication::initialize();
   UseCase hUseCase("CLIENT","## CL51 START TI");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   database::CRTransactionTypeIndicator::instance();
   Database::instance()->attach(this);
   Database::instance()->connect();
   return 0;
  //## end TotalsInquiry::initialize%3884FBE500A0.body
}

int TotalsInquiry::onMessage (IF::Message& hMessage)
{
  //## begin TotalsInquiry::onMessage%388745D90212.body preserve=yes
   Transaction::instance()->begin();
   Database::instance()->commit();
   Transaction::instance()->commit();
   idle();
   return 0;
  //## end TotalsInquiry::onMessage%388745D90212.body
}

void TotalsInquiry::update (Subject* pSubject)
{
  //## begin TotalsInquiry::update%3A75F2F50336.body preserve=yes
   ServiceApplication::update(pSubject);
  //## end TotalsInquiry::update%3A75F2F50336.body
}

// Additional Declarations
  //## begin TotalsInquiry%3884FB1C015F.declarations preserve=yes
  //## end TotalsInquiry%3884FB1C015F.declarations

//## begin module%3884FB67035B.epilog preserve=yes
//## end module%3884FB67035B.epilog
