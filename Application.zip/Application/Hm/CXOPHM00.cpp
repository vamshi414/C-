//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3E6CF8BB037A.cm preserve=no
//## end module%3E6CF8BB037A.cm

//## begin module%3E6CF8BB037A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3E6CF8BB037A.cp

//## Module: CXOPHM00%3E6CF8BB037A; Package body
//## Subsystem: HM%3E6CAD66037A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Application\Hm\CXOPHM00.cpp

//## begin module%3E6CF8BB037A.additionalIncludes preserve=no
//## end module%3E6CF8BB037A.additionalIncludes

//## begin module%3E6CF8BB037A.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
//## end module%3E6CF8BB037A.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBS22_h
#include "CXODBS22.hpp"
#endif
#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
#ifndef CXOSBC17_h
#include "CXODBC17.hpp"
#endif
#ifndef CXOPHM00_h
#include "CXODHM00.hpp"
#endif


//## begin module%3E6CF8BB037A.declarations preserve=no
//## end module%3E6CF8BB037A.declarations

//## begin module%3E6CF8BB037A.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new HealthMonitor();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%3E6CF8BB037A.additionalDeclarations


// Class HealthMonitor 

HealthMonitor::HealthMonitor()
  //## begin HealthMonitor::HealthMonitor%3E6CF6FF0196_const.hasinit preserve=no
      : m_lMessages(0)
  //## end HealthMonitor::HealthMonitor%3E6CF6FF0196_const.hasinit
  //## begin HealthMonitor::HealthMonitor%3E6CF6FF0196_const.initialization preserve=yes
  //## end HealthMonitor::HealthMonitor%3E6CF6FF0196_const.initialization
{
  //## begin HealthMonitor::HealthMonitor%3E6CF6FF0196_const.body preserve=yes
   memcpy(m_sID,"HM00",4);
  //## end HealthMonitor::HealthMonitor%3E6CF6FF0196_const.body
}


HealthMonitor::~HealthMonitor()
{
  //## begin HealthMonitor::~HealthMonitor%3E6CF6FF0196_dest.body preserve=yes
   Database::instance()->commit();
  //## end HealthMonitor::~HealthMonitor%3E6CF6FF0196_dest.body
}



//## Other Operations (implementation)
int HealthMonitor::initialize ()
{
  //## begin HealthMonitor::initialize%3E6D0711035B.body preserve=yes
   new platform::Platform();
   if (Application::initialize() != 0)
      return -1;
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->attach(this);
   Database::instance()->connect();
   MinuteTimer::instance()->attach(this);
   MidnightAlarm::instance()->attach(this);
#ifdef MVS
   Queue::attach("@AHM",Queue::CX_DISTRIBUTION_QUEUE);
#endif
   return 0;
  //## end HealthMonitor::initialize%3E6D0711035B.body
}

int HealthMonitor::onMessage (Message& hMessage)
{
  //## begin HealthMonitor::onMessage%3E7207030109.body preserve=yes
   if (hMessage.messageID() == "H5050D")
   {
      HealthMonitorSegment* h = HealthMonitorSegment::instance();
#ifdef MVS
      string strText(hMessage.data(),hMessage.dataLength());
      vector<string> hTokens;
      Buffer::parse(strText,"().",hTokens);
      if (hTokens.size() != 8)
      {
         if (getQueueDepth() == 0)
         {
           Database::instance()->commit();
           m_lMessages = 0;
           Sleep::goTo("00001500");
         }
         return 0;
      }
      h->setDOMAIN_NAME(hTokens[1]);
      h->setMEMBER_NAME(hTokens[3]);
      h->setBUCKET(hTokens[5]);
      h->setOperator(string(&hTokens[6][0],1));
      h->setITEM_COUNT(atoi(hTokens[7].c_str()));
#else
      char* p = hMessage.data();
      h->import(&p);
#endif
      command::Count::apply(*h);
      if (getQueueDepth() == 0)
      {
        Database::instance()->commit();
        m_lMessages = 0;
        Sleep::goTo("00001500");
      }
      else
      if (++m_lMessages >= 100)
      {
        Database::instance()->commit();
        m_lMessages = 0;
      }
   }
   return 0;
  //## end HealthMonitor::onMessage%3E7207030109.body
}

void HealthMonitor::trace ()
{
  //## begin HealthMonitor::trace%477CFAFE0119.body preserve=yes
#ifndef MVS
   m_hQuery.reset();
   m_hQuery.setQualifier("QUALIFY","CONSOLE_MSG");
   m_hQuery.setQualifier("QUALIFY","CONSOLE_MSG_TEXT");
   m_hQuery.bind("CONSOLE_MSG","DATE_TIME",Column::STRING,&m_strDATE_TIME);
   m_hQuery.bind("CONSOLE_MSG","TASKID",Column::STRING,&m_strTASKID);
   m_hQuery.bind("CONSOLE_MSG","MSG_ID",Column::STRING,&m_strMSG_ID);
   m_hQuery.bind("CONSOLE_MSG","MSG_PARMS",Column::STRING,&m_strMSG_PARMS);
   m_hQuery.bind("CONSOLE_MSG","TSTAMP_UPDATED",Column::STRING,&m_strTSTAMP_UPDATED);
   m_hQuery.bind("CONSOLE_MSG","USER_ID",Column::STRING,&m_strUSER_ID);
   m_hQuery.bind("CONSOLE_MSG_TEXT","TEXT",Column::STRING,&m_strTEXT);
   m_hQuery.bind("CONSOLE_MSG_TEXT","DESCRIPTION",Column::STRING,&m_strDESCRIPTION);
   m_hQuery.bind("CONSOLE_MSG_TEXT","ACTION",Column::STRING,&m_strACTION);
   m_hQuery.bind("CONSOLE_MSG_TEXT","SEVERITY",Column::STRING,&m_strSEVERITY);
   m_hQuery.join("CONSOLE_MSG","LEFT OUTER","CONSOLE_MSG_TEXT","MSG_ID");
   Date hDate(MidnightAlarm::instance()->getYesterday().c_str());
   string strDATE_TIME("'");
   strDATE_TIME.append(hDate.asString("%Y%m%d00000000"));
   strDATE_TIME.append("' AND '");
   hDate += 1;
   strDATE_TIME.append(hDate.asString("%Y%m%d00000000"));
   strDATE_TIME.append("'");
   m_hQuery.setBasicPredicate("CONSOLE_MSG","DATE_TIME","BETWEEN",strDATE_TIME.c_str());
   m_hQuery.setOrderByClause("CONSOLE_MSG.DATE_TIME");
   m_hQuery.attach(this);
   auto_ptr<reusable::SelectStatement> pSelectStatement((reusable::SelectStatement*)database::DatabaseFactory::instance()->create("SelectStatement"));
   pSelectStatement->execute(m_hQuery);
#endif
  //## end HealthMonitor::trace%477CFAFE0119.body
}

void HealthMonitor::update (Subject* pSubject)
{
  //## begin HealthMonitor::update%3E6D072900EA.body preserve=yes
   if (pSubject == &m_hQuery)
   {
      size_t n = m_strTEXT.find_first_of('@');
      if (m_strMSG_PARMS.empty() == false
         && n != string::npos)
      {
         size_t p = m_strTEXT.find_last_of('@');
         string strTemp(m_strTEXT.substr(0,n));
         strTemp += m_strMSG_PARMS.substr(0,((p + 1) - n));
         strTemp += m_strTEXT.substr(p + 1,(60 - p));
         m_strTEXT = strTemp;
      }
      if ((m_strSEVERITY == "6"
         || m_strSEVERITY == "7")
         && m_strTSTAMP_UPDATED.empty())
         m_strSEVERITY = "H";
      else
         m_strSEVERITY = " ";
      string strBuffer(m_strDATE_TIME);
      strBuffer += ",";
      strBuffer += m_strTASKID;
      strBuffer += ",";
      strBuffer += m_strMSG_ID;
      strBuffer += ",";
      strBuffer += m_strTEXT;
      strBuffer += ",";
      strBuffer += m_strSEVERITY;
      strBuffer += ",";
      strBuffer += m_strTSTAMP_UPDATED;
      strBuffer += ",";
      strBuffer += m_strUSER_ID;
      strBuffer += ",";
      strBuffer += m_strDESCRIPTION;
      strBuffer += ",";
      strBuffer += m_strACTION;
      Trace::put(strBuffer.c_str(),strBuffer.length(),true);
      return;
   }
   if (pSubject == MidnightAlarm::instance()
      && Database::instance()->state() == Database::CONNECTED)
   {
      Date hDate(Date::today());
      hDate -= 7;
      string strDate = hDate.asString("%Y%m%d");
      strDate += "00";
      auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
      Query hQuery;
      hQuery.setQualifier("QUALIFY","SYS_HEALTH_MON");
      hQuery.setBasicPredicate("SYS_HEALTH_MON","IMAGE_ID","=",Application::instance()->image().c_str());
      hQuery.setBasicPredicate("SYS_HEALTH_MON","TIME_PERIOD","<",strDate.c_str());
      pDeleteStatement->execute(hQuery);
      Database::instance()->commit();
      trace();
      Database::instance()->commit();
   }
   else
   if (pSubject == MinuteTimer::instance())
      Database::instance()->commit();
   Application::update(pSubject);
  //## end HealthMonitor::update%3E6D072900EA.body
}

// Additional Declarations
  //## begin HealthMonitor%3E6CF6FF0196.declarations preserve=yes
  //## end HealthMonitor%3E6CF6FF0196.declarations

//## begin module%3E6CF8BB037A.epilog preserve=yes
//## end module%3E6CF8BB037A.epilog
