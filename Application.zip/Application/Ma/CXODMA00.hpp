//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5F7FF0130047.cm preserve=no
//	$Date:   Jan 05 2021 11:14:50  $ $Author:   e3023547  $
//	$Revision:   1.0  $
//## end module%5F7FF0130047.cm

//## begin module%5F7FF0130047.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5F7FF0130047.cp

//## Module: CXOSMA00%5F7FF0130047; Package specification
//## Subsystem: MA%5F7FEBE302AE
//## Source file: D:\V03.1A.R010\Dn\Server\Application\Ma\CXODMA00.hpp

#ifndef CXOSMA00_h
#define CXOSMA00_h 1

//## begin module%5F7FF0130047.additionalIncludes preserve=no
//## end module%5F7FF0130047.additionalIncludes

//## begin module%5F7FF0130047.includes preserve=yes
//## end module%5F7FF0130047.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class TransactionMediator;
class MonthlyTotal;
class MonthlyMediator;
} // namespace settlement

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Progress;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Sleep;
class Timestamp;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class InsertSequenceNumber;

} // namespace database

//## begin module%5F7FF0130047.declarations preserve=no
//## end module%5F7FF0130047.declarations

//## begin module%5F7FF0130047.additionalDeclarations preserve=yes
//## end module%5F7FF0130047.additionalDeclarations


//## begin MonthlyAccumulator%5F7FF44E03AE.preface preserve=yes
//## end MonthlyAccumulator%5F7FF44E03AE.preface

//## Class: MonthlyAccumulator%5F7FF44E03AE
//## Category: Totals Management::MonthlyAccumulator_CAT%5F7FF26A0000
//## Subsystem: MA%5F7FEBE302AE
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5F7FF4B002C7;settlement::MonthlyTotal { -> F}
//## Uses: <unnamed>%5F7FFC420040;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%5F7FFC5E039D;monitor::UseCase { -> F}
//## Uses: <unnamed>%5F801BC00235;entitysegment::Progress { -> F}
//## Uses: <unnamed>%5F801BD20020;IF::Timestamp { -> F}
//## Uses: <unnamed>%5F801C020262;database::InsertSequenceNumber { -> F}
//## Uses: <unnamed>%5F80305003BB;settlement::MonthlyMediator { -> F}
//## Uses: <unnamed>%5F80307F0303;settlement::TransactionMediator { -> F}
//## Uses: <unnamed>%5F803129002D;database::Database { -> F}
//## Uses: <unnamed>%5F92C61900EE;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%5F92C803036B;IF::Sleep { -> F}

class DllExport MonthlyAccumulator : public process::Application  //## Inherits: <unnamed>%5F7FF53600DE
{
  //## begin MonthlyAccumulator%5F7FF44E03AE.initialDeclarations preserve=yes
  //## end MonthlyAccumulator%5F7FF44E03AE.initialDeclarations

  public:
    //## Constructors (generated)
      MonthlyAccumulator();

    //## Destructor (generated)
      virtual ~MonthlyAccumulator();


    //## Other Operations (specified)
      //## Operation: initialize%5F7FF50A0041
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>TE
      //	<h2>MS
      //	<!-- TotalsEngine::initialize : Preconditions -->
      //	<h5>Settlement Totals
      //	<h6>Switch Clock vs. Wall Clock
      //	<p>
      //	Many DataNavigator functions such as settlement and the
      //	export of files are triggered by the timestamps of the
      //	transactions entering the system.
      //	For example, settlement scheduled for 18:00 will occur
      //	only when a transaction that occurred on or after 18:00
      //	has been totalled.
      //	This time is referred to as switch clock in Data
      //	Navigator and normally only moves forward when
      //	transactions are processed by the Totals Engine service.
      //	<p>
      //	DataNavigator can also operate on absolute time (i.e.
      //	wall clock).
      //	Settlement scheduled for 18:00 will occur at 18:00
      //	regardless of the transaction feed and totalling.
      //	To operate in this way, add the value WALL to the Totals
      //	Engine task user data.
      //	</body>
      int initialize ();

      //## Operation: update%5F7FF50A0073
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin MonthlyAccumulator%5F7FF44E03AE.public preserve=yes
      //## end MonthlyAccumulator%5F7FF44E03AE.public

  protected:

    //## Other Operations (specified)
      //## Operation: onReset%5F7FF50A0050
      //	Syntax:  RESET task EOD CURRENT
      //
      //	Syntax:  RESET task yyyymmdd
      //
      //	This command resets totals back to a point in time.
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>TE
      //	<h2>CD
      //	<h3>Recover Totals
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>TE <i>yyyymmdd</i>
      //	<h4>Description
      //	<p>
      //	The Totals Engine service recalculates all totals from
      //	midnight on the day specified up to the current time.
      //	Files generated by the Totals
      //	Engine service are also re-created based on the newly
      //	calculated totals.
      //	This command should only be used in case of an emergency
      //	(e.g. following a software fix to totals or to recover
      //	from a database issue).
      //	</p>
      //	<h3>Close Business Day
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>TE EOD CURRENT
      //	<h4>Description
      //	<p>
      //	The Totals Engine service forces the customer business
      //	day to close (regardless of where the service is in
      //	regards
      //	to processing financial transactions for business day).
      //	</p>
      //	</body>
      //	<body>
      //	<title>OG
      //	<h1>TE
      //	<h2>CD
      //	<h3>Recover Totals
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>TE <i>yyyymmdd</i>
      //	<h4>Description
      //	<p>
      //	The Totals Engine service recalculates all totals from
      //	midnight on the day specified up to the current time.
      //	This command should only be used in case of an emergency
      //	(e.g. following a software fix to totals or to recover
      //	from a database issue).
      //	<p>
      //	In the Operator Console Business Days folder, choose
      //	Recover for the desired calendar day:
      //	</p>
      //	<img src=CXOOTE01.gif>
      //	<h3>Close Business Day
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>TE EOD CURRENT
      //	<h4>Description
      //	<p>
      //	The Totals Engine service forces the customer business
      //	day to close (regardless of where the service is in
      //	regards
      //	to processing financial transactions for business day).
      //	<p>
      //	In the Operator Console Business Days folder, choose
      //	Close for the desired calendar day:
      //	</p>
      //	<img src=CXOOTE02.gif>
      //	</body>
      int onReset (Message& hMessage);

      //## Operation: onResume%5F7FF50A0061
      int onResume (Message& hMessage);

    // Additional Protected Declarations
      //## begin MonthlyAccumulator%5F7FF44E03AE.protected preserve=yes
      //## end MonthlyAccumulator%5F7FF44E03AE.protected

  private:
    // Additional Private Declarations
      //## begin MonthlyAccumulator%5F7FF44E03AE.private preserve=yes
      //## end MonthlyAccumulator%5F7FF44E03AE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Delay%5F92C5BC0341
      //## begin MonthlyAccumulator::Delay%5F92C5BC0341.attr preserve=no  private: string {U} 
      string m_strDelay;
      //## end MonthlyAccumulator::Delay%5F92C5BC0341.attr

    // Additional Implementation Declarations
      //## begin MonthlyAccumulator%5F7FF44E03AE.implementation preserve=yes
      string m_strSleep;
      //## end MonthlyAccumulator%5F7FF44E03AE.implementation
};

//## begin MonthlyAccumulator%5F7FF44E03AE.postscript preserve=yes
//## end MonthlyAccumulator%5F7FF44E03AE.postscript

//## begin module%5F7FF0130047.epilog preserve=yes
//## end module%5F7FF0130047.epilog


#endif
