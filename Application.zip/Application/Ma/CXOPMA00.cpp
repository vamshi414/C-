//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5F7FF014014A.cm preserve=no
//	$Date:   Mar 22 2021 02:39:08  $ $Author:   e3028298  $
//	$Revision:   1.3  $
//## end module%5F7FF014014A.cm

//## begin module%5F7FF014014A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5F7FF014014A.cp

//## Module: CXOSMA00%5F7FF014014A; Package body
//## Subsystem: MA%5F7FEBE302AE
//## Source file: D:\V03.1A.R010\Dn\Server\Application\Ma\CXOPMA00.cpp

//## begin module%5F7FF014014A.additionalIncludes preserve=no
//## end module%5F7FF014014A.additionalIncludes

//## begin module%5F7FF014014A.includes preserve=yes
#ifndef CXOSDB50_h
#include "CXODDB50.hpp"
#endif
#ifndef CXOSST81_h
#include "CXODST81.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSAT10_h
#include "CXODAT10.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#include "CXODDB16.hpp"
//## end module%5F7FF014014A.includes

#ifndef CXOSST80_h
#include "CXODST80.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSNS39_h
#include "CXODNS39.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSDB30_h
#include "CXODDB30.hpp"
#endif
#ifndef CXOSST82_h
#include "CXODST82.hpp"
#endif
#ifndef CXOSST33_h
#include "CXODST33.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
#ifndef CXOSMA00_h
#include "CXODMA00.hpp"
#endif


//## begin module%5F7FF014014A.declarations preserve=no
//## end module%5F7FF014014A.declarations

//## begin module%5F7FF014014A.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
pApplication = new MonthlyAccumulator();
pApplication->parseCommandLine(argc, argv);
if (pApplication->initialize() == 0)
   pApplication->run();
#include "CXODPS07.hpp"
//## end module%5F7FF014014A.additionalDeclarations


// Class MonthlyAccumulator 

MonthlyAccumulator::MonthlyAccumulator()
  //## begin MonthlyAccumulator::MonthlyAccumulator%5F7FF44E03AE_const.hasinit preserve=no
  //## end MonthlyAccumulator::MonthlyAccumulator%5F7FF44E03AE_const.hasinit
  //## begin MonthlyAccumulator::MonthlyAccumulator%5F7FF44E03AE_const.initialization preserve=yes
  //## end MonthlyAccumulator::MonthlyAccumulator%5F7FF44E03AE_const.initialization
{
  //## begin MonthlyAccumulator::MonthlyAccumulator%5F7FF44E03AE_const.body preserve=yes
   memcpy(m_sID, "MA00", 4);
  //## end MonthlyAccumulator::MonthlyAccumulator%5F7FF44E03AE_const.body
}


MonthlyAccumulator::~MonthlyAccumulator()
{
  //## begin MonthlyAccumulator::~MonthlyAccumulator%5F7FF44E03AE_dest.body preserve=yes
   delete ConfigurationRepository::instance();
  //## end MonthlyAccumulator::~MonthlyAccumulator%5F7FF44E03AE_dest.body
}



//## Other Operations (implementation)
int MonthlyAccumulator::initialize ()
{
  //## begin MonthlyAccumulator::initialize%5F7FF50A0041.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   entitysegment::Progress::instance();
   atm::Hierarchy::instance();
   database::DataModel::instance();
   database::CRTransactionTypeIndicator::instance();
   ConfigurationRepository::instance();
   MinuteTimer::instance()->attach(this);
   string strValue;
   if (!Extract::instance()->getRecord("DSPEC   MA00    DELAY~", strValue)
      && strValue.length() < 30)
      m_strDelay.assign("00000100");
   else
      m_strDelay.assign(strValue.data()+22,8);
   Database::instance()->connect();
   return 0;
  //## end MonthlyAccumulator::initialize%5F7FF50A0041.body
}

int MonthlyAccumulator::onReset (Message& hMessage)
{
  //## begin MonthlyAccumulator::onReset%5F7FF50A0050.body preserve=yes
   if (memcmp((char*)hMessage.context(), "DELAY", 5) == 0)
      m_strDelay.assign(hMessage.context()+8, 8);
   else 
   {
      ConfigurationRepository::instance()->reset();
      string strContext((char*)hMessage.context());
      size_t n = strContext.find_first_of(' ');
      if (n != string::npos)
         strContext.erase(n);
      if (strContext.length() == 8)
         strContext += "00";
      if (strContext.length() != 10)
         return 0;
      MonthlyMediator::instance()->reset(strContext.c_str());
   }
   return 0;
  //## end MonthlyAccumulator::onReset%5F7FF50A0050.body
}

int MonthlyAccumulator::onResume (Message& hMessage)
{
  //## begin MonthlyAccumulator::onResume%5F7FF50A0061.body preserve=yes
   string strProgress(entitysegment::Progress::instance()->getMonthlyProgress());
   if (strProgress.length() == 8)
   {
      strProgress.append("00");
      MonthlyMediator::instance()->reset(strProgress.c_str());
      strProgress.assign(entitysegment::Progress::instance()->getMonthlyProgress());
      if (strProgress.length() < 15
         && entitysegment::Progress::instance()->setMonthlyProgress(InsertSequenceNumber::getYYYYMMDDJJJHHMM()))
         Database::instance()->commit();
      else
      {
         entitysegment::Progress::instance()->load();
         setQueueWaitOption(true);
         return 0;
      }
   }
   string strCurrentYYYYMMDDJJJHHMM = InsertSequenceNumber::getYYYYMMDDJJJHHMM();
   // advance to next minute
   string strDate(strProgress.substr(0, 11));
   string strTime(strProgress.substr(11, 4));
   strTime += "00";
   Timestamp::adjustGMT(strDate, strTime, 5);
   strProgress = strDate;
   strProgress += strTime.substr(0, 4);
   // stop if caught up to transaction loading
   if (strProgress >= strCurrentYYYYMMDDJJJHHMM)
   {
      setQueueWaitOption(true);
      return true;
   }
   Sleep::goTo(m_strDelay.c_str());
   setQueueWaitOption(MonthlyMediator::instance()->total());
  //## end MonthlyAccumulator::onResume%5F7FF50A0061.body
}

void MonthlyAccumulator::update (Subject* pSubject)
{
  //## begin MonthlyAccumulator::update%5F7FF50A0073.body preserve=yes
   if (pSubject ==MinuteTimer::instance())
   {
      setQueueWaitOption(false);
      return;
   }
   Application::update(pSubject);
  //## end MonthlyAccumulator::update%5F7FF50A0073.body
}

// Additional Declarations
  //## begin MonthlyAccumulator%5F7FF44E03AE.declarations preserve=yes
  //## end MonthlyAccumulator%5F7FF44E03AE.declarations

//## begin module%5F7FF014014A.epilog preserve=yes
//## end module%5F7FF014014A.epilog
