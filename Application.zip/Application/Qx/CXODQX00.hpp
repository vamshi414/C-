//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4A60B54803C8.cm preserve=no
//	$Date:   Jun 09 2011 13:16:10  $ $Author:   E1042833  $
//	$Revision:   1.2  $
//## end module%4A60B54803C8.cm

//## begin module%4A60B54803C8.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%4A60B54803C8.cp

//## Module: CXOPQX00%4A60B54803C8; Package specification
//## Subsystem: QX%4A60B5350242
//## Source file: C:\Devel\Dn\Server\Application\Qx\CXODQX00.hpp

#ifndef CXOPQX00_h
#define CXOPQX00_h 1

//## begin module%4A60B54803C8.additionalIncludes preserve=no
//## end module%4A60B54803C8.additionalIncludes

//## begin module%4A60B54803C8.includes preserve=yes
//## end module%4A60B54803C8.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Continuous Feed::MQSeries_CAT%36C82B100167
namespace mqseries {
class MqQueueFactory;
} // namespace mqseries

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
class ContactSegment;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class FlatFile;
class ExternalQueue;
class ExternalQueueFactory;
class QueueManager;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
class MidnightAlarm;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ImportReportAuditSegment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class Email;
} // namespace command

//## Modelname: Connex Library::UserSegment_CAT%394E272B01EC
namespace usersegment {
class EmailSegment;

} // namespace usersegment

//## begin module%4A60B54803C8.declarations preserve=no
//## end module%4A60B54803C8.declarations

//## begin module%4A60B54803C8.additionalDeclarations preserve=yes
//## end module%4A60B54803C8.additionalDeclarations


//## begin QueueTransfer%4A60B4AB034B.preface preserve=yes
//## end QueueTransfer%4A60B4AB034B.preface

//## Class: QueueTransfer%4A60B4AB034B
//	<body>
//	<title>CG
//	<h1>QX
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The Queue Transfer service sends files from a Windows
//	server to an IBM WebSphere MQ queue.
//	This program can be used to transfer text files (e.g.
//	OCR scanned FAX documents) from a Windows based image
//	server to a queue on an IBM z/OS LPAR.
//	<p>
//	<p>
//	The image server must be configured as follows:
//	<ul>
//	<li>Create a file system (C:\FIS) on the image server as
//	shown in the below diagram
//	<li>Copy the Microsoft Windows version of the FIS Data
//	Navigator server to the Alpha\Bin folder
//	<li>Create a QX.txt extract file (see example below)
//	<li>Configure the WebSphere MQ queue on z/OS
//	<li>Configure the WebSphere MQ queue on Windows
//	</ul>
//	<img src=CXOCQX00.gif>
//	<p>
//	<h2>MS
//	<p>
//	Start the IBM MQM z/OS Operations & Control dialog on
//	the IBM z/OS system.
//	Define a local queue:
//	<img src=CXOCQX01.gif>
//	<p>
//	On page 2 of the local queue definition:
//	<ul>
//	<li>Set the Maximum queue depth to a value equal to
//	one-half of the average daily fax volume
//	<li>Set the Maximum message length equal to 32768
//	</ul>
//	<img src=CXOCQX02.gif>
//	<p>
//	In this example, the Exception Interface in Data
//	Navigator will get from this queue name
//	(LPL016319.GOLD.RIGHTFAX).
//	<p>
//	Start the IBM WebSphere MQ Explorer application on the
//	Microsoft Windows server. Define a local queue:
//	<ul>
//	<li>Set the Usage to Transmission
//	<li>Set the Maximum Queue Depth to a value equal to
//	one-half of the average daily daily fax volume
//	<li>Set the Maximum Message Length equal to 32768
//	</ul>
//	<img src=CXOCQX04.gif>
//	<p>
//	On the Microsoft Windows server, define a remote queue
//	definition:
//	<ul>
//	<li>Set the Remote Queue Name to match the local queue
//	on the z/OS LPAR
//	<li>Set the Remote Queue Manager Name to the WebSphere
//	MQ subsystem on the z/OS LPAR
//	<li>Set the Transmission Queue Name to the match the
//	local queue defined in the prior step
//	</ul>
//	<img src=CXOCQX05.gif>
//	<p>
//	On the Microsoft Windows server, define a sender channel:
//	<ul>
//	<li>Set the Transmission Protocol to TCP/IP
//	<li>Set the Connection Name and Local Communication
//	Address to the TCP/IP address and port for the z/OS LPAR
//	WebSphere MQ subsystem
//	<li>Set the Transmission Queue to the match the local
//	queue on the Microsoft Windows server
//	<li>Set the Maximum Message Length equal to 32768
//	</ul>
//	<img src=CXOCQX06.gif>
//	<p>
//	The Queue Transfer application must be run from the
//	command line initially.
//	Open a Command Prompt window on the image server and
//	enter the following commands:
//	<ul>
//	<li>cd FIS\Server\Alpha\Bin
//	<li>CXOPQX00 -debug -n QX -p <i>node001</i> -q
//	<i>qualify</i>
//	</ul>
//	The program will register itself as a new Windows
//	service named 'DataNavigator QX'.
//	The Microsoft Services dialog can now be used to stop
//	and start the application.
//	<p>
//	Copy text files to be transferred to the Pending folder.
//	The Pending folder is checked each minute.
//	The Queue Transfer service forms a message containing
//	the following text:
//	<ul>
//	<li>Current date (YYYYMMDD format)
//	<li>Tilde (~) delimiter
//	<li>Path name of the text file
//	<li>Tilde (~) delimiter
//	<li>Contents of the text file
//	</ul>
//	<p>
//	When a file is successfully sent to the IBM WebSphere MQ
//	queue, it is moved from the Pending folder to the
//	Complete folder.
//	<p>
//	</body>
//## Category: DataNavigator Foundation::Application::QueueTransfer%4A60B4670167
//## Subsystem: QX%4A60B5350242
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4A60BA4E0222;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%4A60BD9601D4;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%4A60D0060251;mqseries::MqQueueFactory { -> F}
//## Uses: <unnamed>%4A60D0D30232;IF::Message { -> F}
//## Uses: <unnamed>%4A61F3CD005D;IF::Extract { -> F}
//## Uses: <unnamed>%4A61F78702DE;IF::QueueManager { -> F}
//## Uses: <unnamed>%4A61FBFE03C8;IF::FlatFile { -> F}
//## Uses: <unnamed>%4A65D5F501E4;timer::Date { -> F}
//## Uses: <unnamed>%4DC8451D0225;command::Email { -> F}
//## Uses: <unnamed>%4DC8453701FE;entitysegment::Customer { -> F}
//## Uses: <unnamed>%4DC845650340;timer::Date { -> F}
//## Uses: <unnamed>%4DC845D2021D;timer::Clock { -> F}
//## Uses: <unnamed>%4DCACAE30152;entitysegment::ContactSegment { -> F}
//## Uses: <unnamed>%4DCACAEF01F1;usersegment::EmailSegment { -> F}
//## Uses: <unnamed>%4DCACAF30371;segment::ImportReportAuditSegment { -> F}
//## Uses: <unnamed>%4DDC16820104;timer::MidnightAlarm { -> F}

class DllExport QueueTransfer : public process::Application  //## Inherits: <unnamed>%4A60B4C80138
{
  //## begin QueueTransfer%4A60B4AB034B.initialDeclarations preserve=yes
  //## end QueueTransfer%4A60B4AB034B.initialDeclarations

  public:
    //## Constructors (generated)
      QueueTransfer();

    //## Destructor (generated)
      virtual ~QueueTransfer();


    //## Other Operations (specified)
      //## Operation: initialize%4A60B4D50280
      virtual int initialize ();

      //## Operation: parseCommandLine%4A65E53B0119
      //	Interprets the command line parameters:
      //	-debug:  Optional - specified as the first parameter to
      //	start the Application in Visual Studio .NET
      //	-n <name>:  Specifies the name of the Application (e.g.
      //	caQE01)
      //	-d:  Optional - causes the Application to read from a
      //	DiskQueue (only used with -debug)
      virtual void parseCommandLine (int iArgc, char** ppArgv);

      //## Operation: update%4A60BD7C005D
      //	Interprets the inbound Message and calls:
      //
      //	   Application::onConfirm
      //	   Application::onMessage
      //	   Application::onNotify
      //	   Application::onQuiesce
      //	   Application::onRefresh
      //	   Application::onReset
      //	   Application::shutdown
      //	   Timer::elapsed
      //## Postconditions:
      //	<body>
      //	<title>CG
      //	<h1>FM
      //	<h2>FO
      //	<h3>Messages
      //	<p>
      //	Messages displayed by the DataNavigator services are
      //	saved in:
      //	<ul>
      //	<li><i>qualify</i>.CONSOLE_MSG
      //	</ul>
      //	</body>
      virtual void update (Subject* pSubject);

      //## Operation: email%4DC843EE02DC
      bool email ();

    // Additional Public Declarations
      //## begin QueueTransfer%4A60B4AB034B.public preserve=yes
      //## end QueueTransfer%4A60B4AB034B.public

  protected:
    // Additional Protected Declarations
      //## begin QueueTransfer%4A60B4AB034B.protected preserve=yes
      //## end QueueTransfer%4A60B4AB034B.protected

  private:
    // Additional Private Declarations
      //## begin QueueTransfer%4A60B4AB034B.private preserve=yes
      //## end QueueTransfer%4A60B4AB034B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Setup%4A65E54D031C
      //## begin QueueTransfer::Setup%4A65E54D031C.attr preserve=no  private: bool {V} false
      bool m_bSetup;
      //## end QueueTransfer::Setup%4A65E54D031C.attr

      //## Attribute: Email%4DC845F70211
      //## begin QueueTransfer::Email%4DC845F70211.attr preserve=no  private: command::Email* {U} 
      command::Email* m_pEmail;
      //## end QueueTransfer::Email%4DC845F70211.attr

      //## Attribute: ContactEmailAddress%4DC84AE30196
      //## begin QueueTransfer::ContactEmailAddress%4DC84AE30196.attr preserve=no  private: string {U} 
      string m_strContactEmailAddress;
      //## end QueueTransfer::ContactEmailAddress%4DC84AE30196.attr

      //## Attribute: SuccessfulMessages%4DCAF7DD027F
      //## begin QueueTransfer::SuccessfulMessages%4DCAF7DD027F.attr preserve=no  private: int {U} 0
      int m_iSuccessfulMessages;
      //## end QueueTransfer::SuccessfulMessages%4DCAF7DD027F.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::QueueTransfer::<unnamed>%4A60CFB50261
      //## Role: QueueTransfer::<m_pExternalQueue>%4A60CFB6007D
      //## begin QueueTransfer::<m_pExternalQueue>%4A60CFB6007D.role preserve=no  public: IF::ExternalQueue { -> RFHgN}
      IF::ExternalQueue *m_pExternalQueue;
      //## end QueueTransfer::<m_pExternalQueue>%4A60CFB6007D.role

      //## Association: DataNavigator Foundation::Application::QueueTransfer::<unnamed>%4A60D017007D
      //## Role: QueueTransfer::<m_pExternalQueueFactory>%4A60D01702BF
      //## begin QueueTransfer::<m_pExternalQueueFactory>%4A60D01702BF.role preserve=no  public: IF::ExternalQueueFactory { -> RFHgN}
      IF::ExternalQueueFactory *m_pExternalQueueFactory;
      //## end QueueTransfer::<m_pExternalQueueFactory>%4A60D01702BF.role

    // Additional Implementation Declarations
      //## begin QueueTransfer%4A60B4AB034B.implementation preserve=yes
      //## end QueueTransfer%4A60B4AB034B.implementation

};

//## begin QueueTransfer%4A60B4AB034B.postscript preserve=yes
//## end QueueTransfer%4A60B4AB034B.postscript

//## begin module%4A60B54803C8.epilog preserve=yes
//## end module%4A60B54803C8.epilog


#endif
