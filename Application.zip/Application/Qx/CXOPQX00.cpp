//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4A60B54A01C5.cm preserve=no
//	$Date:   May 13 2020 15:13:20  $ $Author:   e1009510  $
//	$Revision:   1.8  $
//## end module%4A60B54A01C5.cm

//## begin module%4A60B54A01C5.cp preserve=no
//	Copyright (c) 1997 - 2011
//	FIS
//## end module%4A60B54A01C5.cp

//## Module: CXOPQX00%4A60B54A01C5; Package body
//## Subsystem: QX%4A60B5350242
//## Source file: C:\Devel\Dn\Server\Application\Qx\CXOPQX00.cpp

//## begin module%4A60B54A01C5.additionalIncludes preserve=no
//## end module%4A60B54A01C5.additionalIncludes

//## begin module%4A60B54A01C5.includes preserve=yes
#ifdef _WIN32
#include "CXODPS04.hpp"
#endif
#include <sstream>
//## end module%4A60B54A01C5.includes

#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSMQ04_h
#include "CXODMQ04.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF46_h
#include "CXODIF46.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSBC25_h
#include "CXODBC25.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSNS10_h
#include "CXODNS10.hpp"
#endif
#ifndef CXOSUS21_h
#include "CXODUS21.hpp"
#endif
#ifndef CXOSBS24_h
#include "CXODBS24.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSIF55_h
#include "CXODIF55.hpp"
#endif
#ifndef CXOSIF47_h
#include "CXODIF47.hpp"
#endif
#ifndef CXOPQX00_h
#include "CXODQX00.hpp"
#endif


//## begin module%4A60B54A01C5.declarations preserve=no
//## end module%4A60B54A01C5.declarations

//## begin module%4A60B54A01C5.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new QueueTransfer();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%4A60B54A01C5.additionalDeclarations


// Class QueueTransfer 

QueueTransfer::QueueTransfer()
  //## begin QueueTransfer::QueueTransfer%4A60B4AB034B_const.hasinit preserve=no
      : m_bSetup(false),
        m_iSuccessfulMessages(0),
        m_pExternalQueue(0),
        m_pExternalQueueFactory(0)
  //## end QueueTransfer::QueueTransfer%4A60B4AB034B_const.hasinit
  //## begin QueueTransfer::QueueTransfer%4A60B4AB034B_const.initialization preserve=yes
  //## end QueueTransfer::QueueTransfer%4A60B4AB034B_const.initialization
{
  //## begin QueueTransfer::QueueTransfer%4A60B4AB034B_const.body preserve=yes
   memcpy(m_sID,"QX00",4);
  //## end QueueTransfer::QueueTransfer%4A60B4AB034B_const.body
}


QueueTransfer::~QueueTransfer()
{
  //## begin QueueTransfer::~QueueTransfer%4A60B4AB034B_dest.body preserve=yes
  //## end QueueTransfer::~QueueTransfer%4A60B4AB034B_dest.body
}



//## Other Operations (implementation)
int QueueTransfer::initialize ()
{
  //## begin QueueTransfer::initialize%4A60B4D50280.body preserve=yes
   if (m_bSetup)
   {
      Extract::instance()->setup(); // will execute up to the point of getSpec CUSTOMER
#ifdef _WIN32
      string strName("DataNavigator");
      strName += " QX";
      string strPath;
      char sBuffer[_MAX_PATH];
      _getcwd(sBuffer,_MAX_PATH);
      strPath = sBuffer;
      strPath += "\\CXOPQX00.exe";
      process::Service hTask(strName.c_str(),strPath.c_str(),false);
      hTask.start();
#endif
      return -1;
   }
   new dnplatform::DNPlatform();
   if (Application::initialize() != 0)
      return -1;
   Trace::setEnable(true);
   string strValue;
   if (!Extract::instance()->getSpec("FAXQUEUE",strValue))
      return 0;
   m_pExternalQueueFactory = new MqQueueFactory();
   m_pExternalQueue = (ExternalQueue*)ExternalQueueFactory::instance()->create("Queue",strValue.c_str());
   MinuteTimer::instance()->attach(this);
   return 0;
  //## end QueueTransfer::initialize%4A60B4D50280.body
}

void QueueTransfer::parseCommandLine (int iArgc, char** ppArgv)
{
  //## begin QueueTransfer::parseCommandLine%4A65E53B0119.body preserve=yes
   setName("GDQX");
   int j = 0;
   char* q = 0;
   for (int i = 1;i < iArgc;++i)
   {
      switch (j)
      {
         case 0:
            if (!strcmp(ppArgv[i],"-p"))
               j = 1;
            else
            if (!strcmp(ppArgv[i],"-q"))
               j = 2;
            else
            if (!strcmp(ppArgv[i],"-t"))
               Trace::setEnable(true);
            break;
         case 1:
            m_bSetup = true;
            q = strchr(ppArgv[i],'"');
            if (q)
               *q = '\0';
            Extract::instance()->setNode001(ppArgv[i]);
            j = 0;
            break;
         case 2:
            string strRecord("DSPEC   QUALIFY ");
            strRecord += ppArgv[i];
            Extract::instance()->addRecord(strRecord);
            j = 0;
            break;
      }
   }
  //## end QueueTransfer::parseCommandLine%4A65E53B0119.body
}

void QueueTransfer::update (Subject* pSubject)
{
  //## begin QueueTransfer::update%4A60BD7C005D.body preserve=yes
   if (pSubject == MinuteTimer::instance())
   {
      FlatFile hFlatFile("FAX");
      while (hFlatFile.open(FlatFile::CX_OPEN_INPUT))
      {
#define MESSAGE_SIZE 32768
         Message hMessage(MESSAGE_SIZE);
         char* p = hMessage.buffer();
         Date hDate(Date::today());
         memcpy(p,hDate.asString("%Y%m%d").data(),8);
         p += 8;
         *p = '~';
         memcpy(p,hFlatFile.getDatasetName().data(),hFlatFile.getDatasetName().length());
         p += hFlatFile.getDatasetName().length();
         *p = '~';
         ++p;
         size_t i = MESSAGE_SIZE - (hFlatFile.getDatasetName().length() + 10);
         size_t j = 0;
         Trace::setEnable(false);
         while (i > 1 && hFlatFile.read(p,i,&j))
         {
            p += j;
            i -= j;
         }
         Trace::setEnable(true);
         hMessage.setMessageLength(32768 - i);
         if (m_pExternalQueue->send(&hMessage,Queue::DATAGRAM))
         {
            hFlatFile.move("..\\Complete");
            ++m_iSuccessfulMessages;
            hFlatFile.close();
         }
         else
         {
            hFlatFile.close();
            break;
         }
         QueueManager::instance(m_pExternalQueue->getQueueManager())->commit();
      }  
   }
   if(pSubject == MidnightAlarm::instance())
   {
      email();
      m_iSuccessfulMessages = 0;
   }
   Application::update(pSubject);
  //## end QueueTransfer::update%4A60BD7C005D.body
}

bool QueueTransfer::email ()
{
  //## begin QueueTransfer::email%4DC843EE02DC.body preserve=yes
   string strDate = Date::today().asString("%Y%m%d");
   m_pEmail = new Email("QXDLAU","CU",Customer::instance()->getCUST_ID(),strDate,"235959");
   string strValue;
   Extract::instance()->getSpec("PROC",strValue);
   usersegment::EmailSegment::instance()->setServer(strValue);
   string strTime(Clock::instance()->getYYYYMMDDHHMMSS(),8,4);
   strTime.insert(2,":");
   usersegment::EmailSegment::instance()->setSCHED_TIME(strTime);
   strDate = Date::today().asString("%Y-%m-%d");
   usersegment::EmailSegment::instance()->setDATE_RECON(strDate);

   m_pEmail->add('Z',usersegment::EmailSegment::instance());

   string strTemp = ("CRCPT TO:<Paul.Depratt@fisglobal.com>");
   string strTemp2 = ("CTO:<Paul.Depratt@fisglobal.com>");

   char szTemp[10];
   snprintf(szTemp,sizeof(szTemp),"C%d",m_iSuccessfulMessages);

   const char* pszEmail[] =
   {
      "CHELO ~Z.PROC.",
      "CMAIL FROM:<DataNavigator>",
      strTemp.c_str(),
      "CDATA",
      strTemp2.c_str(),
      "CSUBJECT:DataNavigator Successful Faxes Sent Today",
      "C",
      "CRun Time: ~Z.DATE_RECON. ~Z.SCHED_TIME.",
      "C",
      "CSuccessful messages: ",
      &szTemp[0],
      0
   };  
   m_pEmail->setTemplate(&pszEmail[0]);
   m_pEmail->report('C');
   m_pEmail->getFlatFile().close();
   return true;
  //## end QueueTransfer::email%4DC843EE02DC.body
}

// Additional Declarations
  //## begin QueueTransfer%4A60B4AB034B.declarations preserve=yes
  //## end QueueTransfer%4A60B4AB034B.declarations

//## begin module%4A60B54A01C5.epilog preserve=yes
//## end module%4A60B54A01C5.epilog
