//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%50D40AA303D5.cm preserve=no
//	$Date:   Mar 17 2013 20:49:26  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%50D40AA303D5.cm

//## begin module%50D40AA303D5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%50D40AA303D5.cp

//## Module: CXOPER00%50D40AA303D5; Package specification
//## Subsystem: ER%50D3FCA4012D
//## Source file: C:\bV02.3B.R001\Windows\Build\Dn\Server\Application\Er\CXODER00.hpp

#ifndef CXOPER00_h
#define CXOPER00_h 1

//## begin module%50D40AA303D5.additionalIncludes preserve=no
//## end module%50D40AA303D5.additionalIncludes

//## begin module%50D40AA303D5.includes preserve=yes
//## end module%50D40AA303D5.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSRulesEngine;
} // namespace ems

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%50D40AA303D5.declarations preserve=no
//## end module%50D40AA303D5.declarations

//## begin module%50D40AA303D5.additionalDeclarations preserve=yes
//## end module%50D40AA303D5.additionalDeclarations


//## begin ExceptionRules%50D32B4603DB.preface preserve=yes
//## end ExceptionRules%50D32B4603DB.preface

//## Class: ExceptionRules%50D32B4603DB
//## Category: Transaction Research and Adjustments::ExceptionRules_CAT ( ER )%50D32AA200A4
//## Subsystem: ER%50D3FCA4012D
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%50D43478021F;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%50D4347F02A0;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%50EC4F8401BB;monitor::UseCase { -> F}
//## Uses: <unnamed>%50EC50E70388;database::Database { -> F}

class DllExport ExceptionRules : public process::Application  //## Inherits: <unnamed>%50EC5D9B01F0
{
  //## begin ExceptionRules%50D32B4603DB.initialDeclarations preserve=yes
  //## end ExceptionRules%50D32B4603DB.initialDeclarations

  public:
    //## Constructors (generated)
      ExceptionRules();

    //## Destructor (generated)
      virtual ~ExceptionRules();


    //## Other Operations (specified)
      //## Operation: initialize%50D4386300F9
      virtual int initialize ();

    // Additional Public Declarations
      //## begin ExceptionRules%50D32B4603DB.public preserve=yes
      //## end ExceptionRules%50D32B4603DB.public

  protected:
    // Additional Protected Declarations
      //## begin ExceptionRules%50D32B4603DB.protected preserve=yes
      //## end ExceptionRules%50D32B4603DB.protected

  private:
    // Additional Private Declarations
      //## begin ExceptionRules%50D32B4603DB.private preserve=yes
      //## end ExceptionRules%50D32B4603DB.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin ExceptionRules%50D32B4603DB.implementation preserve=yes
      //## end ExceptionRules%50D32B4603DB.implementation

};

//## begin ExceptionRules%50D32B4603DB.postscript preserve=yes
//## end ExceptionRules%50D32B4603DB.postscript

//## begin module%50D40AA303D5.epilog preserve=yes
//## end module%50D40AA303D5.epilog


#endif
