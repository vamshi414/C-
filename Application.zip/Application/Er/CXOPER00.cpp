//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%50D40E6700A2.cm preserve=no
//	$Date:   May 05 2015 14:19:00  $ $Author:   e1009610  $
//	$Revision:   1.2  $
//## end module%50D40E6700A2.cm

//## begin module%50D40E6700A2.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%50D40E6700A2.cp

//## Module: CXOPER00%50D40E6700A2; Package body
//## Subsystem: ER%50D3FCA4012D
//## Source file: C:\bV02.3B.R001\Windows\Build\Dn\Server\Application\Er\CXOPER00.cpp

//## begin module%50D40E6700A2.additionalIncludes preserve=no
//## end module%50D40E6700A2.additionalIncludes

//## begin module%50D40E6700A2.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),ENVAR('TASK=ER'))
#endif
//## end module%50D40E6700A2.includes

#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOPER00_h
#include "CXODER00.hpp"
#endif


//## begin module%50D40E6700A2.declarations preserve=no
//## end module%50D40E6700A2.declarations

//## begin module%50D40E6700A2.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new ExceptionRules();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%50D40E6700A2.additionalDeclarations


// Class ExceptionRules 

ExceptionRules::ExceptionRules()
  //## begin ExceptionRules::ExceptionRules%50D32B4603DB_const.hasinit preserve=no
  //## end ExceptionRules::ExceptionRules%50D32B4603DB_const.hasinit
  //## begin ExceptionRules::ExceptionRules%50D32B4603DB_const.initialization preserve=yes
  //## end ExceptionRules::ExceptionRules%50D32B4603DB_const.initialization
{
  //## begin ExceptionRules::ExceptionRules%50D32B4603DB_const.body preserve=yes
   memcpy(m_sID,"ER00",4);
  //## end ExceptionRules::ExceptionRules%50D32B4603DB_const.body
}


ExceptionRules::~ExceptionRules()
{
  //## begin ExceptionRules::~ExceptionRules%50D32B4603DB_dest.body preserve=yes
   delete EMSRulesEngine::instance();
  //## end ExceptionRules::~ExceptionRules%50D32B4603DB_dest.body
}



//## Other Operations (implementation)
int ExceptionRules::initialize ()
{
  //## begin ExceptionRules::initialize%50D4386300F9.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("CLIENT","## CL14 START ER");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   EMSRulesEngine::instance();
   Database::instance()->connect();
   return 0;
  //## end ExceptionRules::initialize%50D4386300F9.body
}

// Additional Declarations
  //## begin ExceptionRules%50D32B4603DB.declarations preserve=yes
  //## end ExceptionRules%50D32B4603DB.declarations

//## begin module%50D40E6700A2.epilog preserve=yes
//## end module%50D40E6700A2.epilog
