//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%375C1ADC02B8.cm preserve=no
//## end module%375C1ADC02B8.cm

//## begin module%375C1ADC02B8.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%375C1ADC02B8.cp

//## Module: CXOPEI00%375C1ADC02B8; Package specification
//## Subsystem: EI%375C1A9C0130
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Ei\CXODEI00.hpp

#ifndef CXOPEI00_h
#define CXOPEI00_h 1

//## begin module%375C1ADC02B8.additionalIncludes preserve=no
//## end module%375C1ADC02B8.additionalIncludes

//## begin module%375C1ADC02B8.includes preserve=yes
#ifndef CXOSEC26_h
#include "CXODEC26.hpp"
#endif
#include "CXODME44.hpp"
//## end module%375C1ADC02B8.includes

#ifndef CXOSIF36_h
#include "CXODIF36.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOXSEX82_h
#include "CXODEX82.hpp"
#endif
#ifndef CXOSEX50_h
#include "CXODEX50.hpp"
#endif
#ifndef CXOSEX05_h
#include "CXODEX05.hpp"
#endif
#ifndef CXOSSE13_h
#include "CXODSE13.hpp"
#endif
#ifndef CXOSSE04_h
#include "CXODSE04.hpp"
#endif
#ifndef CXOSSE01_h
#include "CXODSE01.hpp"
#endif
#ifndef CXOSME66_h
#include "CXODME66.hpp"
#endif
#ifndef CXOSME58_h
#include "CXODME58.hpp"
#endif
#ifndef CXOSPE02_h
#include "CXODPE02.hpp"
#endif
#ifndef CXOSCE01_h
#include "CXODCE01.hpp"
#endif
#ifndef CXOSNE03_h
#include "CXODNE03.hpp"
#endif
#ifndef CXOSNE01_h
#include "CXODNE01.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
class CaseUpdateCommand;
} // namespace emscommand

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class MasterCardException;
class CaseCommentsExport;
class SettlementWebAdjustmentTransaction;
class GetOriginalFinancialCommand;
class C2CImport;
class EMSDocDeleteList;
class AccountFile;
class APIAging;
} // namespace ems

namespace emscommand {
class CaseCreateCommand;
class DocSecure;
class CaseFinLocatorUpdate;
} // namespace emscommand

//## Modelname: Transaction Research and Adjustments::VisaException_CAT%4097A16101D4
namespace visaexception {
class VisaAdminIsoImportTransaction;
class VCRExportCases;
class VisaAdminIsoImportFile;
} // namespace visaexception

//## Modelname: Transaction Research and Adjustments::OasisException_CAT%4242FC2D02CE
namespace oasisexception {
class OCSExceptionImport;
class OCSExceptionImportFile;
} // namespace oasisexception

//## Modelname: Transaction Research and Adjustments::MasterCardException_CAT%4242FC56001F
namespace mastercardexception {
class SAFEImportFile;
class SAFETransaction;
class MasterComExpirationFile;
class MasterComBulkErrorFile;
class MasterComErrorTransaction;
class MasterComErrorImportFile;
class MasterComProImport;
class IPMTransaction;
class IPMImportFile;
} // namespace mastercardexception

//## Modelname: Transaction Research and Adjustments::StarException_CAT%4242FC630251
namespace starexception {
class StarAcknowledgementImport;
class StarRejectImport;
class StarInterfaceTransaction;
} // namespace starexception

//## Modelname: Transaction Research and Adjustments::PulseException_CAT%481B74D302AF
namespace pulseexception {
class PulseImport;
} // namespace pulseexception

//## Modelname: Transaction Research and Adjustments::GenericException_CAT%4ADF1B4C003E
namespace genericexception {
class HistorylessBulkImport;
} // namespace genericexception

//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
class ArchiveRetriever;
} // namespace archive

//## Modelname: DataNavigator Foundation::Partition_CAT%346B9162029B
namespace partition {
class PartitionControl;
} // namespace partition

//## Modelname: DataNavigator Foundation::RepositoryCommand_CAT%394E267C0078
namespace repositorycommand {
class BillDataLoader;
} // namespace repositorycommand

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class NetworkFactory;
class ExceptionFactory;
class ActionFactory;
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Signal;
} // namespace reusable

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class ImportFile;
} // namespace command

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Console;
class ExternalQueue;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Rules_CAT (RLDLL)%3EB810F40157
namespace rules {
class FunctionFactory;
} // namespace rules

//## Modelname: Platform \: Regions::RegionsAPI%49C79DB0002E
namespace regionsapi {
class RightFax;
class ProvisionalCredit;

} // namespace regionsapi

//## begin module%375C1ADC02B8.declarations preserve=no
//## end module%375C1ADC02B8.declarations

//## begin module%375C1ADC02B8.additionalDeclarations preserve=yes
namespace bamsprocessing
{
   class BAMSExceptionImport;
}
namespace visaexception
{
   class BulkMailImport;
   class BulkQuestionnaireImport;
}
//## end module%375C1ADC02B8.additionalDeclarations


//## begin ExceptionInterface%375C1A2C0247.preface preserve=yes
//## end ExceptionInterface%375C1A2C0247.preface

//## Class: ExceptionInterface%375C1A2C0247
//	<body>
//	<title>CG
//	<h1>EI
//	<h2>AB
//	<h3>System Flow
//	<p>
//	For dispute resolution, the DataNavigator server
//	provides batch interfaces to card assocations, networks
//	and financial institutions, including:
//	<ul>
//	<li>Other instances of DataNavigator
//	<li>VISA
//	<li>Mastercard
//	<li>Star
//	<li>Bank of America
//	</ul>
//	<p>
//	The Exception Interface service (<i>ca</i>EI) imports
//	and exports files to external applications and systems.
//	</p>
//	<img src=CXOCEI00.gif>
//	<p>
//	Refer to the various <i>DataNavigator Client Exception
//	Management User's Guides</i> for more information.
//	</p>
//	</body>
//	<body>
//	<title>OG
//	<h1>EI
//	<h2>AB
//	<h3>System Flow
//	<p>
//	For exception item processing, the DataNavigator server
//	provides batch interfaces to other systems (e.g. VISA or
//	MasterCard).
//	<p>
//	<img src=CXOOEI00.gif>
//	</p>
//	</body>
//## Category: Transaction Research and Adjustments::ExceptionInterface_CAT%375C19F10116
//## Subsystem: EI%375C1A9C0130
//## Persistence: Transient
//## Cardinality/Multiplicity: 0..1



//## Uses: <unnamed>%375C2223004A;database::Database { -> F}
//## Uses: <unnamed>%375D6BEB02A6;IF::Message { -> F}
//## Uses: <unnamed>%3A008A28037B;monitor::UseCase { -> F}
//## Uses: <unnamed>%3B4B347C005F;timer::Clock { -> F}
//## Uses: <unnamed>%3B4B3480008D;reusable::Transaction { -> F}
//## Uses: <unnamed>%3C1BC2E60397;IF::Extract { -> }
//## Uses: <unnamed>%3C4739FB03C4;IF::EMailMessage { -> }
//## Uses: <unnamed>%3CB48C67024E;ems::SettledAdjustment { -> F}
//## Uses: <unnamed>%3CBC78F0038E;ems::StarCaseExport { -> F}
//## Uses: <unnamed>%3D889ADD034B;database::GenericDelete { -> F}
//## Uses: <unnamed>%3EC5AD7F002E;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%3EC8DE2B0196;ems::NationalException { -> F}
//## Uses: <unnamed>%40AB8893037A;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%40ACCD6F0148;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%40D280DA036B;ems::CaseCommentsExport { -> F}
//## Uses: <unnamed>%40F7CD0C02CE;ems::AccountFile { -> F}
//## Uses: <unnamed>%4242FF2E0000;command::ImportFile { -> F}
//## Uses: <unnamed>%4243006501B5;IF::Console { -> F}
//## Uses: <unnamed>%431EFDE1001F;IF::Trace { -> F}
//## Uses: <unnamed>%451B89A101A2;ems::EMSDocDeleteList { -> F}
//## Uses: <unnamed>%458260F702DF;ems::C2CImport { -> F}
//## Uses: <unnamed>%45E4786F0352;visaexception::VisaAdminIsoImportFile { -> F}
//## Uses: <unnamed>%45F620C70367;visaexception::VisaAdminIsoImportTransaction { -> F}
//## Uses: <unnamed>%45F6266702B2;emscommand::CaseFinLocatorUpdate { -> F}
//## Uses: <unnamed>%460CCB6E0208;mastercardexception::SAFETransaction { -> F}
//## Uses: <unnamed>%46109B360167;mastercardexception::SAFEImportFile { -> F}
//## Uses: <unnamed>%4652CFA500F2;ems::MasterCardException { -> F}
//## Uses: <unnamed>%466E9A7E0151;oasisexception::OCSExceptionImport { -> F}
//## Uses: <unnamed>%468B6FEF02B4;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%47D5315402E8;archive::ArchiveRetriever { -> F}
//## Uses: <unnamed>%49E485FC033C;regionsapi::ProvisionalCredit { -> F}
//## Uses: <unnamed>%49E4AEA0038A;IF::ExternalQueue { -> F}
//## Uses: <unnamed>%4A82DFE8016B;dnplatform::ActionFactory { -> F}
//## Uses: <unnamed>%4A82E001031E;rules::FunctionFactory { -> F}
//## Uses: <unnamed>%4AD36296020B;pulseexception::PulseImport { -> F}
//## Uses: <unnamed>%4AE05B48002E;dnplatform::ExceptionFactory { -> F}
//## Uses: <unnamed>%4AEF130F01E4;dnplatform::NetworkFactory { -> F}
//## Uses: <unnamed>%4FEB17C4012E;mastercardexception::IPMImportFile { -> F}
//## Uses: <unnamed>%5237376300D1;oasisexception::OCSExceptionImportFile { -> F}
//## Uses: <unnamed>%555597250233;ems::GetOriginalFinancialCommand { -> F}
//## Uses: <unnamed>%55BA2A3F00E2;emscommand::DocSecure { -> F}
//## Uses: <unnamed>%593812210203;repositorycommand::BillDataLoader { -> F}
//## Uses: <unnamed>%5938299103A4;ems::SettlementWebAdjustmentTransaction { -> F}
//## Uses: <unnamed>%5ED9287C0332;mastercardexception::MasterCardT5G2Import { -> }
//## Uses: <unnamed>%64FDFDAF01C8;genericexception::HistorylessBulkImport { -> F}

class ExceptionInterface : public process::Application  //## Inherits: <unnamed>%375C1A4800E9
{
  //## begin ExceptionInterface%375C1A2C0247.initialDeclarations preserve=yes
  //## end ExceptionInterface%375C1A2C0247.initialDeclarations

  public:
    //## Constructors (generated)
      ExceptionInterface();

    //## Destructor (generated)
      virtual ~ExceptionInterface();


    //## Other Operations (specified)
      //## Operation: initialize%375C1A6D0038
      virtual int initialize ();

    // Additional Public Declarations
      //## begin ExceptionInterface%375C1A2C0247.public preserve=yes
      virtual void update(Subject* pSubject);
      //## end ExceptionInterface%375C1A2C0247.public
  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%375C1A760077
      virtual int onMessage (Message& hMessage);

      //## Operation: onReset%375C1A7D00C7
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>E3
      //	<h2>CD
      //	<h3>Import MasterCard
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI IMPORT MCI
      //	<h4>Description
      //	Process a MasterCard exception import file.
      //	<h3>Import MasterCard
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI IMPORT MCOFLN
      //	<h4>Description
      //	Process a MasterCard exception import file from Offline.
      //	<h3>Import MasterCard Fraud
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI IMPORT FRD
      //	<h4>Description
      //	Process a MasterCard Fraud reject file.
      //	<h3>Import Star
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI IMSTAR
      //	<h4>Description
      //	Process a Star exception import file.
      //	<h3>Import VISA
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI IMPORT VNT
      //	<h4>Description
      //	<p>
      //	Process a VISA exception import file.
      //	<h3>Import VISA VROL BQI
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI BQIDOWN
      //	<h4>Description
      //	<p>
      //	Process a VISA VROL BQI download file.
      //	<h3>Import VISA VROL Bulk Mail
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI BMDOWN
      //	<h4>Description
      //	<p>
      //	Process a VISA VROL Bulk Mail download file.
      //	<h3>Export MasterCard
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI EXPORT MCI
      //	<h4>Description
      //	<p>
      //	Create the MasterCard exception export file.
      //	<h4>Schedule
      //	<p>
      //	Execute every day (Monday through Friday) at switch end
      //	of day.
      //	<h3>Export MasterCard Fraud
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI EXPORT FRD
      //	<h4>Description
      //	<p>
      //	Create the MasterCard Fraud export file.
      //	<h4>Schedule
      //	<p>
      //	Execute every day (Monday through Friday) at switch end
      //	of day.
      //	<h3>Export Star
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI EOD STAR
      //	<h4>Description
      //	<p>
      //	Create the Star exception export file.
      //	<h3>Export VISA
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI EXPORT VNT
      //	<h4>Description
      //	<p>
      //	Create the VISA exception export file.
      //	<h3>Export Accounting
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI EXPORT ACCTFL
      //	<h4>Description
      //	<p>
      //	Create the EMS case accounting export file.
      //	<h3>Export Comments
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI EXPORT COMMENTS
      //	<h4>Description
      //	<p>
      //	Create the EMS case comments export file.
      //	<h3>Export Settled Adjustments
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI EOD 0410
      //	<h4>Description
      //	<p>
      //	Creates the regional 410 file.
      //	<h4>Schedule
      //	<p>
      //	The DataNavigator Server installation automatically sets
      //	up an event to perform this command at 11:45 PM (15
      //	minutes prior to the default business end of day).
      //	Use the CR Client to change the time or the retention
      //	period.
      //	<p>
      //	The Events are in the Event Management folder in the CR
      //	Client for the DataNavigator Server.
      //	<h3>Settle MasterCard
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI SETTLE MCI
      //	<h4>Description
      //	<p>
      //	Create a 410 batch settlement file for MasterCard cases.
      //	</p>
      //	<h3>Settle All
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI SETTLE
      //	<h4>Description
      //	<p>
      //	Create a 410 batch settlement file for all cases.
      //	<h3>Delete Cases
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI DELETE 180DAYS
      //	<h4>Description
      //	<p>
      //	Purge all cases that have been unchanged for 180 days.
      //	<h4>Schedule
      //	<p>
      //	The DataNavigator Server installation automatically sets
      //	up an event to perform this command at 02:00 AM.
      //	Use the CR Client to change the time or the retention
      //	period.
      //	<p>
      //	The Events are in the Event Management folder in the CR
      //	Client for the DataNavigator Server.
      //	<h3>Delete Import Audit Report
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI DELETEIA180DAYS
      //	<h4>Description
      //	<p>
      //	Purge all import audit information older than 180 days.
      //	<h4>Schedule
      //	<p>
      //	The DataNavigator Server installation automatically sets
      //	up an event to perform this command at 02:00 AM.
      //	Use the CR Client to change the time or the retention
      //	period.
      //	<p>
      //	The Events are in the Event Management folder in the CR
      //	Client for the DataNavigator Server.
      //	<h3>Rules Initialize
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI RULES INIT
      //	<h4>Description
      //	<p>
      //	Resets the EMS Rules Engine by removing all existing
      //	rules from memory.
      //	<h3>Rules Load MasterCard
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI RULES LOAD MCI
      //	<h4>Description
      //	<p>
      //	Load MasterCard rules into the EMS Rules Engine.
      //	<h3>Rules Load VISA
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI RULES LOAD VNT
      //	<h4>Description
      //	<p>
      //	Load VISA rules into the EMS Rules Engine.
      //	<h3>Rules Write MasterCard
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI RULES WRITE MCI
      //	<h4>Description
      //	<p>
      //	Write the MasterCard rules to the <i>ca</i>EI trace file.
      //	<h3>Rules Write VISA
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI RULES WRITE VNT
      //	<h4>Description
      //	<p>
      //	Write the VISA rules to the <i>ca</i>EI trace file.
      //	<h3>Rules Debug on
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI RULES DEBUG ON
      //	<h4>Description
      //	<p>
      //	Enable writing Rules Engine debugging information to the
      //	<i>ca</i>EI trace file.
      //	<h3>Rules Debug off
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI RULES DEBUG OFF
      //	<h4>Description
      //	<p>
      //	Disable writing Rules Engine debugging information to
      //	the <i>ca</i>EI trace file.
      //	<h3>Send MasterCard
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI SEND MCI
      //	<h4>Description
      //	<p>
      //	Auto transition all MasterCard EMS cases.
      //	<h3>Send VISA
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI SEND VNT
      //	<h4>Description
      //	<p>
      //	Auto transition all VISA EMS cases.
      //	<h3>Send All
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>EI SEND *
      //	<h4>Description
      //	<p>
      //	Auto transition all EMS cases.
      //	<h4>Schedule
      //	<p>
      //	The DataNavigator Server installation automatically sets
      //	up an event to perform this command at 11:30 PM (30
      //	minutes prior to the default business end of day).
      //	Use the CR Client to change the time or the retention
      //	period.
      //	<p>
      //	The Events are in the Event Management folder in the CR
      //	Client for the DataNavigator Server.
      //	</p>
      //	</body>
      virtual int onReset (Message& hMessage);

      //## Operation: onResume%3ED1F6ED0186
      virtual int onResume (Message& hMessage);

    // Additional Protected Declarations
      //## begin ExceptionInterface%375C1A2C0247.protected preserve=yes
      //## end ExceptionInterface%375C1A2C0247.protected

  private:
    // Additional Private Declarations
      //## begin ExceptionInterface%375C1A2C0247.private preserve=yes
      //## end ExceptionInterface%375C1A2C0247.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BillDataLoader%593811C40066
      //## begin ExceptionInterface::BillDataLoader%593811C40066.attr preserve=no  private: repositorycommand::BillDataLoader* {U} 0
      repositorycommand::BillDataLoader* m_pBillDataLoader;
      //## end ExceptionInterface::BillDataLoader%593811C40066.attr

      //## Attribute: CaseFinLocatorUpdate%45F626740292
      //## begin ExceptionInterface::CaseFinLocatorUpdate%45F626740292.attr preserve=no  private: emscommand::CaseFinLocatorUpdate* {U} 0
      emscommand::CaseFinLocatorUpdate* m_pCaseFinLocatorUpdate;
      //## end ExceptionInterface::CaseFinLocatorUpdate%45F626740292.attr

      //## Attribute: C2CImport%468B70770343
      //## begin ExceptionInterface::C2CImport%468B70770343.attr preserve=no  private: ems::C2CImport* {U} 0
      ems::C2CImport* m_pC2CImport;
      //## end ExceptionInterface::C2CImport%468B70770343.attr

      //## Attribute: MasterCardT5G2ImportFile%5ED8AC8B00BF
      //## begin ExceptionInterface::MasterCardT5G2ImportFile%5ED8AC8B00BF.attr preserve=no  private: mastercardexception::MasterCardT5G2Import* {U} 
      mastercardexception::MasterCardT5G2Import* m_pMasterCardT5G2ImportFile;
      //## end ExceptionInterface::MasterCardT5G2ImportFile%5ED8AC8B00BF.attr

      //## Attribute: VisaAdminIsoImportFile%468B71870148
      //## begin ExceptionInterface::VisaAdminIsoImportFile%468B71870148.attr preserve=no  private: visaexception::VisaAdminIsoImportFile* {U} 0
      visaexception::VisaAdminIsoImportFile* m_pVisaAdminIsoImportFile;
      //## end ExceptionInterface::VisaAdminIsoImportFile%468B71870148.attr

      //## Attribute: VisaAdminIsoImportTransaction%46E9880400CB
      //## begin ExceptionInterface::VisaAdminIsoImportTransaction%46E9880400CB.attr preserve=no  private: visaexception::VisaAdminIsoImportTransaction* {U} 0
      visaexception::VisaAdminIsoImportTransaction* m_pVisaAdminIsoImportTransaction;
      //## end ExceptionInterface::VisaAdminIsoImportTransaction%46E9880400CB.attr

      //## Attribute: OCSExceptionImportFile%468E176000FC
      //## begin ExceptionInterface::OCSExceptionImportFile%468E176000FC.attr preserve=no  private: oasisexception::OCSExceptionImportFile* {U} 0
      oasisexception::OCSExceptionImportFile* m_pOCSExceptionImportFile;
      //## end ExceptionInterface::OCSExceptionImportFile%468E176000FC.attr

      //## Attribute: OCSExceptionImport%468E1A4D032B
      //## begin ExceptionInterface::OCSExceptionImport%468E1A4D032B.attr preserve=no  private: oasisexception::OCSExceptionImport* {U} 0
      oasisexception::OCSExceptionImport* m_pOCSExceptionImport;
      //## end ExceptionInterface::OCSExceptionImport%468E1A4D032B.attr

      //## Attribute: PulseImport%4AD362A4034E
      //## begin ExceptionInterface::PulseImport%4AD362A4034E.attr preserve=no  private: pulseexception::PulseImport* {U} 0
      pulseexception::PulseImport* m_pPulseImport;
      //## end ExceptionInterface::PulseImport%4AD362A4034E.attr

      //## Attribute: SAFEImportFile%468B71700384
      //## begin ExceptionInterface::SAFEImportFile%468B71700384.attr preserve=no  private: mastercardexception::SAFEImportFile* {U} 0
      mastercardexception::SAFEImportFile* m_pSAFEImportFile;
      //## end ExceptionInterface::SAFEImportFile%468B71700384.attr

      //## Attribute: SAFETransaction%46D2A85A00BB
      //## begin ExceptionInterface::SAFETransaction%46D2A85A00BB.attr preserve=no  private: mastercardexception::SAFETransaction* {U} 0
      mastercardexception::SAFETransaction* m_pSAFETransaction;
      //## end ExceptionInterface::SAFETransaction%46D2A85A00BB.attr

      //## Attribute: SettlementWebAdjustmentTransaction%593829AB0037
      //## begin ExceptionInterface::SettlementWebAdjustmentTransaction%593829AB0037.attr preserve=no  private: ems::SettlementWebAdjustmentTransaction {U} 
      ems::SettlementWebAdjustmentTransaction m_hSettlementWebAdjustmentTransaction;
      //## end ExceptionInterface::SettlementWebAdjustmentTransaction%593829AB0037.attr

    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%375D6B9601DC
      //## Role: ExceptionInterface::<m_pCaseExport>%375D6B9700D9
      //## begin ExceptionInterface::<m_pCaseExport>%375D6B9700D9.role preserve=no  public: ems::CaseExport { -> RHgN}
      ems::CaseExport *m_pCaseExport;
      //## end ExceptionInterface::<m_pCaseExport>%375D6B9700D9.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%3CB5B98502BC
      //## Role: ExceptionInterface::<m_pPartitionControl>%3CB5B986014B
      //## begin ExceptionInterface::<m_pPartitionControl>%3CB5B986014B.role preserve=no  public: partition::PartitionControl { -> RFHgN}
      partition::PartitionControl *m_pPartitionControl;
      //## end ExceptionInterface::<m_pPartitionControl>%3CB5B986014B.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%3EC59FFF0251
      //## Role: ExceptionInterface::<m_pCaseCreateCommand>%3EC5A0000196
      //## begin ExceptionInterface::<m_pCaseCreateCommand>%3EC5A0000196.role preserve=no  public: emscommand::CaseCreateCommand { -> RFHgN}
      emscommand::CaseCreateCommand *m_pCaseCreateCommand;
      //## end ExceptionInterface::<m_pCaseCreateCommand>%3EC5A0000196.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%3EC5A00103B9
      //## Role: ExceptionInterface::<m_pCaseUpdateCommand>%3EC5A003009C
      //## begin ExceptionInterface::<m_pCaseUpdateCommand>%3EC5A003009C.role preserve=no  public: emscommand::CaseUpdateCommand { -> RFHgN}
      emscommand::CaseUpdateCommand *m_pCaseUpdateCommand;
      //## end ExceptionInterface::<m_pCaseUpdateCommand>%3EC5A003009C.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%42691B19034B
      //## Role: ExceptionInterface::<m_hStarTransaction>%42691B1A02BF
      //## begin ExceptionInterface::<m_hStarTransaction>%42691B1A02BF.role preserve=no  public: starexception::StarTransaction { -> VHgN}
      starexception::StarTransaction m_hStarTransaction;
      //## end ExceptionInterface::<m_hStarTransaction>%42691B1A02BF.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%43CE9FDF01D4
      //## Role: ExceptionInterface::<m_hCaseReplicationImport>%43CE9FE3005D
      //## begin ExceptionInterface::<m_hCaseReplicationImport>%43CE9FE3005D.role preserve=no  public: ems::CaseReplicationImport { -> VHgN}
      ems::CaseReplicationImport m_hCaseReplicationImport;
      //## end ExceptionInterface::<m_hCaseReplicationImport>%43CE9FE3005D.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%49E4A2A900DA
      //## Role: ExceptionInterface::<m_pSignal>%49E4A2A9037A
      //## begin ExceptionInterface::<m_pSignal>%49E4A2A9037A.role preserve=no  public: reusable::Signal { -> 2RFHgN}
      reusable::Signal *m_pSignal[2];
      //## end ExceptionInterface::<m_pSignal>%49E4A2A9037A.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%4A11487D0119
      //## Role: ExceptionInterface::<m_hPulseTransaction>%4A11487E009C
      //## begin ExceptionInterface::<m_hPulseTransaction>%4A11487E009C.role preserve=no  public: pulseexception::PulseTransaction { -> VHgN}
      pulseexception::PulseTransaction m_hPulseTransaction;
      //## end ExceptionInterface::<m_hPulseTransaction>%4A11487E009C.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%4A5E0189002E
      //## Role: ExceptionInterface::<m_pRightFax>%4A5E0189037A
      //## begin ExceptionInterface::<m_pRightFax>%4A5E0189037A.role preserve=no  public: regionsapi::RightFax { -> RFHgN}
      regionsapi::RightFax *m_pRightFax;
      //## end ExceptionInterface::<m_pRightFax>%4A5E0189037A.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%4FEB13290129
      //## Role: ExceptionInterface::<m_pIPMTransaction>%4FEB132A0274
      //## begin ExceptionInterface::<m_pIPMTransaction>%4FEB132A0274.role preserve=no  public: mastercardexception::IPMTransaction { -> RFHgN}
      mastercardexception::IPMTransaction *m_pIPMTransaction;
      //## end ExceptionInterface::<m_pIPMTransaction>%4FEB132A0274.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%4FEB148B0105
      //## Role: ExceptionInterface::<m_hCupTransaction>%4FEB148D0046
      //## begin ExceptionInterface::<m_hCupTransaction>%4FEB148D0046.role preserve=no  public: cupexception::CupTransaction { -> VHgN}
      cupexception::CupTransaction m_hCupTransaction;
      //## end ExceptionInterface::<m_hCupTransaction>%4FEB148D0046.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%4FEB17D303B8
      //## Role: ExceptionInterface::<m_pIPMImportFile>%4FEB17D5018C
      //## begin ExceptionInterface::<m_pIPMImportFile>%4FEB17D5018C.role preserve=no  public: mastercardexception::IPMImportFile { -> RFHgN}
      mastercardexception::IPMImportFile *m_pIPMImportFile;
      //## end ExceptionInterface::<m_pIPMImportFile>%4FEB17D5018C.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%5050A8030020
      //## Role: ExceptionInterface::<m_hStarPOSTransaction>%5050A804015D
      //## begin ExceptionInterface::<m_hStarPOSTransaction>%5050A804015D.role preserve=no  public: starexception::StarPOSTransaction { -> VHgN}
      starexception::StarPOSTransaction m_hStarPOSTransaction;
      //## end ExceptionInterface::<m_hStarPOSTransaction>%5050A804015D.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%529F5EF4024E
      //## Role: ExceptionInterface::<m_pMasterComProImport>%529F5EF501BB
      //## begin ExceptionInterface::<m_pMasterComProImport>%529F5EF501BB.role preserve=no  public: mastercardexception::MasterComProImport { -> RFHgN}
      mastercardexception::MasterComProImport *m_pMasterComProImport;
      //## end ExceptionInterface::<m_pMasterComProImport>%529F5EF501BB.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%530776F90104
      //## Role: ExceptionInterface::<m_pMasterComErrorImportFile>%530776FB03E6
      //## begin ExceptionInterface::<m_pMasterComErrorImportFile>%530776FB03E6.role preserve=no  public: mastercardexception::MasterComErrorImportFile { -> RFHgN}
      mastercardexception::MasterComErrorImportFile *m_pMasterComErrorImportFile;
      //## end ExceptionInterface::<m_pMasterComErrorImportFile>%530776FB03E6.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%530777520174
      //## Role: ExceptionInterface::<m_pMasterComErrorTransaction>%53077754013F
      //## begin ExceptionInterface::<m_pMasterComErrorTransaction>%53077754013F.role preserve=no  public: mastercardexception::MasterComErrorTransaction { -> RFHgN}
      mastercardexception::MasterComErrorTransaction *m_pMasterComErrorTransaction;
      //## end ExceptionInterface::<m_pMasterComErrorTransaction>%53077754013F.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%5432F1C4016E
      //## Role: ExceptionInterface::<m_pMasterComBulkErrorFile>%5432F1C50241
      //## begin ExceptionInterface::<m_pMasterComBulkErrorFile>%5432F1C50241.role preserve=no  public: mastercardexception::MasterComBulkErrorFile { -> RFHgN}
      mastercardexception::MasterComBulkErrorFile *m_pMasterComBulkErrorFile;
      //## end ExceptionInterface::<m_pMasterComBulkErrorFile>%5432F1C50241.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%54412DE602C6
      //## Role: ExceptionInterface::<m_pMasterComExpirationFile>%54412DE702A2
      //## begin ExceptionInterface::<m_pMasterComExpirationFile>%54412DE702A2.role preserve=no  public: mastercardexception::MasterComExpirationFile { -> RFHgN}
      mastercardexception::MasterComExpirationFile *m_pMasterComExpirationFile;
      //## end ExceptionInterface::<m_pMasterComExpirationFile>%54412DE702A2.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%55BA2A75032F
      //## Role: ExceptionInterface::<m_pDocSecure>%55BA2A760303
      //## begin ExceptionInterface::<m_pDocSecure>%55BA2A760303.role preserve=no  public: emscommand::DocSecure { -> 2RFHgN}
      emscommand::DocSecure *m_pDocSecure[2];
      //## end ExceptionInterface::<m_pDocSecure>%55BA2A760303.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%55D49D1503BA
      //## Role: ExceptionInterface::<m_hNYCETransaction>%55D49D1701BA
      //## begin ExceptionInterface::<m_hNYCETransaction>%55D49D1701BA.role preserve=no  public: nyceexception::NYCETransaction { -> VHgN}
      nyceexception::NYCETransaction m_hNYCETransaction;
      //## end ExceptionInterface::<m_hNYCETransaction>%55D49D1701BA.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%55D49DC30369
      //## Role: ExceptionInterface::<m_hNYCEReject>%55D49DC40323
      //## begin ExceptionInterface::<m_hNYCEReject>%55D49DC40323.role preserve=no  public: nyceexception::NYCEReject { -> VHgN}
      nyceexception::NYCEReject m_hNYCEReject;
      //## end ExceptionInterface::<m_hNYCEReject>%55D49DC40323.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%5788D15201E7
      //## Role: ExceptionInterface::<m_pStarInterfaceTransaction>%5788D15301DD
      //## begin ExceptionInterface::<m_pStarInterfaceTransaction>%5788D15301DD.role preserve=no  public: starexception::StarInterfaceTransaction { -> RFHgN}
      starexception::StarInterfaceTransaction *m_pStarInterfaceTransaction;
      //## end ExceptionInterface::<m_pStarInterfaceTransaction>%5788D15301DD.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%5A3128C40315
      //## Role: ExceptionInterface::<m_pVCRExportCases>%5A3128C60062
      //## begin ExceptionInterface::<m_pVCRExportCases>%5A3128C60062.role preserve=no  public: visaexception::VCRExportCases { -> RFHgN}
      visaexception::VCRExportCases *m_pVCRExportCases;
      //## end ExceptionInterface::<m_pVCRExportCases>%5A3128C60062.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%5CE645E8022E
      //## Role: ExceptionInterface::<m_hMasterCardTQR4ImportFile>%5CE645E90266
      //## begin ExceptionInterface::<m_hMasterCardTQR4ImportFile>%5CE645E90266.role preserve=no  public: mastercardexception::MasterCardTQR4ImportFile { -> VHgN}
      mastercardexception::MasterCardTQR4ImportFile m_hMasterCardTQR4ImportFile;
      //## end ExceptionInterface::<m_hMasterCardTQR4ImportFile>%5CE645E90266.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%5CFE2DE203D8
      //## Role: ExceptionInterface::<m_hAIMSFile>%5CFE2DEC01EB
      //## begin ExceptionInterface::<m_hAIMSFile>%5CFE2DEC01EB.role preserve=no  public: ems::AIMSFile { -> 6VHgN}
      ems::AIMSFile m_hAIMSFile[6];
      //## end ExceptionInterface::<m_hAIMSFile>%5CFE2DEC01EB.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%61376BF300C8
      //## Role: ExceptionInterface::<m_pAPIAging>%61376BFE03B2
      //## begin ExceptionInterface::<m_pAPIAging>%61376BFE03B2.role preserve=no  public: ems::APIAging { -> RFHgN}
      ems::APIAging *m_pAPIAging;
      //## end ExceptionInterface::<m_pAPIAging>%61376BFE03B2.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%62AC35E70055
      //## Role: ExceptionInterface::<m_pStarRejectImport>%62AC35FB0228
      //## begin ExceptionInterface::<m_pStarRejectImport>%62AC35FB0228.role preserve=no  public: starexception::StarRejectImport { -> RFHgN}
      starexception::StarRejectImport *m_pStarRejectImport;
      //## end ExceptionInterface::<m_pStarRejectImport>%62AC35FB0228.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%62CDB09300AC
      //## Role: ExceptionInterface::<m_pStarAcknowledgementImport>%62CDB09D032B
      //## begin ExceptionInterface::<m_pStarAcknowledgementImport>%62CDB09D032B.role preserve=no  public: starexception::StarAcknowledgementImport { -> RFHgN}
      starexception::StarAcknowledgementImport *m_pStarAcknowledgementImport;
      //## end ExceptionInterface::<m_pStarAcknowledgementImport>%62CDB09D032B.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%64FDFDE20093
      //## Role: ExceptionInterface::<m_pHistorylessBulkImport>%64FDFDE30091
      //## begin ExceptionInterface::<m_pHistorylessBulkImport>%64FDFDE30091.role preserve=no  public: genericexception::HistorylessBulkImport { -> RFHgN}
      genericexception::HistorylessBulkImport *m_pHistorylessBulkImport;
      //## end ExceptionInterface::<m_pHistorylessBulkImport>%64FDFDE30091.role

      //## Association: Transaction Research and Adjustments::ExceptionInterface_CAT::<unnamed>%64FDFEBB00D3
      //## Role: ExceptionInterface::<m_pStarImageImport>%64FDFEBB03B6
      //## begin ExceptionInterface::<m_pStarImageImport>%64FDFEBB03B6.role preserve=no  public: starexception::StarImageImport { -> RHgN}
      starexception::StarImageImport *m_pStarImageImport;
      //## end ExceptionInterface::<m_pStarImageImport>%64FDFEBB03B6.role

    // Additional Implementation Declarations
      //## begin ExceptionInterface%375C1A2C0247.implementation preserve=yes
      oasisexception::OCSExceptionImport m_hOCSExceptionImport;
      bamsprocessing::BAMSExceptionImport *m_pBAMSExceptionImport;
      visaexception::BulkMailImport *m_pBulkMailImport;
      visaexception::BulkQuestionnaireImport *m_pBulkQuestionnaireImport;
      ExceptionRepair* m_pExceptionRepair;
      EMSSpreadsheetImport* m_pEMSSpreadsheetImport;
      mastercardexception::MasterComAPIQueue *m_pMasterComAPIQueue;
      visaexception::VisaQueue *m_pVisaQueue;
      //## end ExceptionInterface%375C1A2C0247.implementation
};

//## begin ExceptionInterface%375C1A2C0247.postscript preserve=yes
//## end ExceptionInterface%375C1A2C0247.postscript

//## begin module%375C1ADC02B8.epilog preserve=yes
//## end module%375C1ADC02B8.epilog


#endif
