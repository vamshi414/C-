//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%375C1ADD0346.cm preserve=no
//## end module%375C1ADD0346.cm

//## begin module%375C1ADD0346.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%375C1ADD0346.cp

//## Module: CXOPEI00%375C1ADD0346; Package body
//## Subsystem: EI%375C1A9C0130
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Ei\CXOPEI00.cpp

//## begin module%375C1ADD0346.additionalIncludes preserve=no
//## end module%375C1ADD0346.additionalIncludes

//## begin module%375C1ADD0346.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),ENVAR('TASK=EI'))
#endif
#include "CXODRU29.hpp"
#include "CXODSE02.hpp"
#include "CXODVE01.hpp"
#include "CXODVE06.hpp"
#include "CXODBA01.hpp"
#include "CXODDB27.hpp"
#include "CXODPF01.hpp"
#include "CXODDB50.hpp"
#include "CXODDB16.hpp"
#include "CXODCF01.hpp"
#include "CXODME78.hpp"
#include "CXODME79.hpp"
#include "CXODME85.hpp"
#ifndef CXOSGE71_h
#include "CXODGE71.hpp"
#endif
#ifndef CXOSEC11_h
#include "CXODEC11.hpp"
#endif
#include "CXODDZ06.hpp"
#include "CXODDZ08.hpp"
#include "CXODVE19.hpp"
#ifndef CXOSMN03_h
#include "CXODMN03.hpp"
#endif
#include "CXODME58.hpp"
#include "CXODME65.hpp"
#ifndef CXOSME69_h
#include "CXODME69.hpp"
#endif
#ifndef CXOSVE44_h
#include "CXODVE44.hpp"
#endif
#include "CXODVE53.hpp"
#include "CXODDB46.hpp"
#include "CXODEX91.hpp"
//## end module%375C1ADD0346.includes

#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSEX41_h
#include "CXODEX41.hpp"
#endif
#ifndef CXOSEX10_h
#include "CXODEX10.hpp"
#endif
#ifndef CXOSBC18_h
#include "CXODBC18.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSEX54_h
#include "CXODEX54.hpp"
#endif
#ifndef CXOSEX55_h
#include "CXODEX55.hpp"
#endif
#ifndef CXOSVE11_h
#include "CXODVE11.hpp"
#endif
#ifndef CXOSVE09_h
#include "CXODVE09.hpp"
#endif
#ifndef CXOSEC21_h
#include "CXODEC21.hpp"
#endif
#ifndef CXOSME01_h
#include "CXODME01.hpp"
#endif
#ifndef CXOSME02_h
#include "CXODME02.hpp"
#endif
#ifndef CXOSEX18_h
#include "CXODEX18.hpp"
#endif
#ifndef CXOSOE02_h
#include "CXODOE02.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSAR03_h
#include "CXODAR03.hpp"
#endif
#ifndef CXOSRA02_h
#include "CXODRA02.hpp"
#endif
#ifndef CXOSIF55_h
#include "CXODIF55.hpp"
#endif
#ifndef CXOSDZ02_h
#include "CXODDZ02.hpp"
#endif
#ifndef CXOSRL17_h
#include "CXODRL17.hpp"
#endif
#ifndef CXOSPE04_h
#include "CXODPE04.hpp"
#endif
#ifndef CXOSDZ03_h
#include "CXODDZ03.hpp"
#endif
#ifndef CXOSDZ04_h
#include "CXODDZ04.hpp"
#endif
#ifndef CXOSME08_h
#include "CXODME08.hpp"
#endif
#ifndef CXOSOE03_h
#include "CXODOE03.hpp"
#endif
#ifndef CXOSEX68_h
#include "CXODEX68.hpp"
#endif
#ifndef CXOSEC31_h
#include "CXODEC31.hpp"
#endif
#ifndef CXOSRC23_h
#include "CXODRC23.hpp"
#endif
#ifndef CXOSEX71_h
#include "CXODEX71.hpp"
#endif
#ifndef CXOSGE97_h
#include "CXODGE97.hpp"
#endif
#ifndef CXOSPC01_h
#include "CXODPC01.hpp"
#endif
#ifndef CXOSEC01_h
#include "CXODEC01.hpp"
#endif
#ifndef CXOSEC02_h
#include "CXODEC02.hpp"
#endif
#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
#ifndef CXOSRA07_h
#include "CXODRA07.hpp"
#endif
#ifndef CXOSME09_h
#include "CXODME09.hpp"
#endif
#ifndef CXOSME18_h
#include "CXODME18.hpp"
#endif
#ifndef CXOSME27_h
#include "CXODME27.hpp"
#endif
#ifndef CXOSME28_h
#include "CXODME28.hpp"
#endif
#ifndef CXOSME29_h
#include "CXODME29.hpp"
#endif
#ifndef CXOSME30_h
#include "CXODME30.hpp"
#endif
#ifndef CXOSSE07_h
#include "CXODSE07.hpp"
#endif
#ifndef CXOSVE31_h
#include "CXODVE31.hpp"
#endif
#ifndef CXOSEX85_h
#include "CXODEX85.hpp"
#endif
#ifndef CXOSSE12_h
#include "CXODSE12.hpp"
#endif
#ifndef CXOSSE11_h
#include "CXODSE11.hpp"
#endif
#ifndef CXOSSE13_h
#include "CXODSE13.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSEX04_h
#include "CXODEX04.hpp"
#endif
#ifndef CXOSEX09_h
#include "CXODEX09.hpp"
#endif
#ifndef CXOSDB22_h
#include "CXODDB22.hpp"
#endif
#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOSEX28_h
#include "CXODEX28.hpp"
#endif
#ifndef CXOPEI00_h
#include "CXODEI00.hpp"
#endif


//## begin module%375C1ADD0346.declarations preserve=no
//## end module%375C1ADD0346.declarations

//## begin module%375C1ADD0346.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new ExceptionInterface();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%375C1ADD0346.additionalDeclarations


// Class ExceptionInterface 

ExceptionInterface::ExceptionInterface()
  //## begin ExceptionInterface::ExceptionInterface%375C1A2C0247_const.hasinit preserve=no
      : m_pBillDataLoader(0),
        m_pCaseFinLocatorUpdate(0),
        m_pC2CImport(0),
        m_pVisaAdminIsoImportFile(0),
        m_pVisaAdminIsoImportTransaction(0),
        m_pOCSExceptionImportFile(0),
        m_pOCSExceptionImport(0),
        m_pPulseImport(0),
        m_pSAFEImportFile(0),
        m_pSAFETransaction(0),
        m_pCaseExport(0),
        m_pPartitionControl(0),
        m_pCaseCreateCommand(0),
        m_pCaseUpdateCommand(0),
        m_pRightFax(0),
        m_pIPMTransaction(0),
        m_pIPMImportFile(0),
        m_pMasterComProImport(0),
        m_pMasterComErrorImportFile(0),
        m_pMasterComErrorTransaction(0),
        m_pMasterComBulkErrorFile(0),
        m_pMasterComExpirationFile(0),
        m_pStarInterfaceTransaction(0),
        m_pVCRExportCases(0),
        m_pAPIAging(0),
        m_pStarRejectImport(0),
        m_pStarAcknowledgementImport(0),
        m_pHistorylessBulkImport(0),
        m_pStarImageImport(0)
  //## end ExceptionInterface::ExceptionInterface%375C1A2C0247_const.hasinit
  //## begin ExceptionInterface::ExceptionInterface%375C1A2C0247_const.initialization preserve=yes
#ifndef _UNIX
   ,m_pBAMSExceptionImport(0)
#endif
   ,m_pBulkMailImport(0)
   ,m_pBulkQuestionnaireImport(0)
   ,m_pExceptionRepair(0)
   ,m_pEMSSpreadsheetImport(0)
   ,m_pMasterCardT5G2ImportFile(0)
   ,m_pMasterComAPIQueue(0)
   ,m_pVisaQueue(0)
  //## end ExceptionInterface::ExceptionInterface%375C1A2C0247_const.initialization
{
  //## begin ExceptionInterface::ExceptionInterface%375C1A2C0247_const.body preserve=yes
    memcpy(m_sID,"EI00",4);
  //## end ExceptionInterface::ExceptionInterface%375C1A2C0247_const.body
}


ExceptionInterface::~ExceptionInterface()
{
  //## begin ExceptionInterface::~ExceptionInterface%375C1A2C0247_dest.body preserve=yes
#ifndef _UNIX
   delete m_pBAMSExceptionImport;
#endif
   delete m_pBulkMailImport;
   delete m_pBulkQuestionnaireImport;
   delete m_pPartitionControl;
   delete m_pCaseExport;
   delete m_pCaseUpdateCommand;
   delete m_pCaseCreateCommand;
   delete GetOriginalFinancialCommand::instance();
   delete EMailMessage::instance();
   delete SettledAdjustment::instance();
   delete EMSRulesEngine::instance();
   delete CaseCommentsExport::instance();
   delete m_pVisaAdminIsoImportFile;
   delete m_pPulseImport;
   delete m_pSAFEImportFile;
   delete m_pC2CImport;
   delete m_pOCSExceptionImport;
   delete m_pOCSExceptionImportFile;
   delete m_pVisaAdminIsoImportTransaction;
   delete m_pSAFETransaction;
   if ((long)m_pSignal[0] != -1)
      delete m_pSignal[0];
   if ((long)m_pSignal[1] != -1)
      delete m_pSignal[1];
   delete regionsapi::ProvisionalCredit::instance();
   delete m_pRightFax;
   delete m_pExceptionRepair;
   delete FunctionFactory::instance();
   delete m_pIPMImportFile ;
   delete m_pIPMTransaction ;
   delete m_pMasterComProImport;
   delete m_pMasterComErrorImportFile;
   delete m_pMasterComErrorTransaction;
   delete m_pVCRExportCases;
   delete m_pDocSecure[0];
   delete m_pDocSecure[1];
   delete m_pBillDataLoader;
   delete m_pAPIAging;
   delete m_pStarRejectImport;
   delete m_pStarImageImport;
   delete m_pStarAcknowledgementImport;
   delete m_pStarInterfaceTransaction;
   delete m_pHistorylessBulkImport;
  //## end ExceptionInterface::~ExceptionInterface%375C1A2C0247_dest.body
}



//## Other Operations (implementation)
int ExceptionInterface::initialize ()
{
  //## begin ExceptionInterface::initialize%375C1A6D0038.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("DR","## DR20 START EI");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   database::DataModel::instance();
   database::CRTransactionTypeIndicator::instance();
   new PostingFileFactory();
   m_pSignal[0] = (Signal*)-1;
   m_pSignal[1] = (Signal*)-1;
   m_pDocSecure[0] = new DocSecure("ENCRYPT");
   m_pDocSecure[1] = new DocSecure("DECRYPT");
   m_pBillDataLoader = new repositorycommand::BillDataLoader();
   Database::instance()->attach(this);
   m_pCaseUpdateCommand = new CaseUpdateCommand();
   m_pBulkMailImport = new BulkMailImport();
   m_pVCRExportCases = new VCRExportCases();
   m_pAPIAging = new APIAging();
#ifndef _UNIX
   m_pBAMSExceptionImport = new BAMSExceptionImport();
#endif
   string strRecord;
   //check to make sure that the EI task is configured to receive IDM Messages
   if (IF::Extract::instance()->getRecord("DFILES  VRBDM5  ",strRecord) ||
		 IF::Extract::instance()->getRecord("DFILES  DNBDM5  ",strRecord))
      m_pBulkQuestionnaireImport = new BulkQuestionnaireImport();
   if (IF::Extract::instance()->getRecord("DFILES  AISOIN  ",strRecord))
   {
      m_pVisaAdminIsoImportFile = new VisaAdminIsoImportFile();
      m_pVisaAdminIsoImportTransaction = new VisaAdminIsoImportTransaction();
      ImportFile::instance()->add("AISOIN",m_pVisaAdminIsoImportTransaction,m_pVisaAdminIsoImportFile);
   }
   if (IF::Extract::instance()->getRecord("DFILES  CPPIN   ",strRecord))
   {
      ImportFile::instance()->add("CPPIN",&m_hStarPOSTransaction,ImportFile::instance());
   }
   if (IF::Extract::instance()->getRecord("DFILES  FRDIN   ",strRecord))
   {
      m_pSAFEImportFile = new SAFEImportFile();
      m_pSAFETransaction = new SAFETransaction();
      ImportFile::instance()->add("FRDIN",m_pSAFETransaction,m_pSAFEImportFile);
   }
   if (IF::Extract::instance()->getRecord("DFILES  ECIN    ",strRecord))
   {
      m_pC2CImport = new C2CImport();
      ImportFile::instance()->add("ECIN",&m_hCaseReplicationImport,m_pC2CImport);
   }
   if (IF::Extract::instance()->getRecord("DFILES  STRIN   ",strRecord))
   {
      ImportFile::instance()->add("STRIN",&m_hStarTransaction,ImportFile::instance());
   }
   if (IF::Extract::instance()->getRecord("DFILES  MCIN    ",strRecord))
   {
      IString strUserRecord;
      IF::Extract::instance()->get("DUSER   ",strUserRecord);
      if (strUserRecord.indexOf("OCS") > 0)
      {
         m_pOCSExceptionImport = new OCSExceptionImport();
         m_pOCSExceptionImportFile = new OCSExceptionImportFile();
         ImportFile::instance()->add("MCIN",m_pOCSExceptionImport,m_pOCSExceptionImportFile);
      }
   }
   if (IF::Extract::instance()->getRecord("DFILES  VNTIN   ",strRecord))
   {
      IString strUserRecord;
      IF::Extract::instance()->get("DUSER   ",strUserRecord);
      if (strUserRecord.indexOf("OCS") > 0)
      {
         m_pOCSExceptionImport = new OCSExceptionImport();
         m_pOCSExceptionImportFile = new OCSExceptionImportFile();
         ImportFile::instance()->add("VNTIN",m_pOCSExceptionImport,m_pOCSExceptionImportFile);
      }
   }
   if (IF::Extract::instance()->getRecord("DFILES  DNAIN   ",strRecord))
   {
      IString strUserRecord;
      IF::Extract::instance()->get("DUSER   ",strUserRecord);
      if (strUserRecord.indexOf("OCS") > 0)
      {
         m_pOCSExceptionImport = new OCSExceptionImport();
         m_pOCSExceptionImportFile = new OCSExceptionImportFile();
         ImportFile::instance()->add("DNAIN",m_pOCSExceptionImport,m_pOCSExceptionImportFile);
      }
   }
   if (IF::Extract::instance()->getRecord("DFILES  PULIN   ",strRecord))
   {
      m_pPulseImport = new PulseImport();
      ImportFile::instance()->add("PULIN",&m_hPulseTransaction,m_pPulseImport);
   }
   if (IF::Extract::instance()->getRecord("DFILES  CUPIN   ",strRecord))
   {
      ImportFile::instance()->add("CUPIN",&m_hCupTransaction,ImportFile::instance());
   }
   if (IF::Extract::instance()->getRecord("DFILES  IPMIN   ",strRecord))
   {
      m_pIPMTransaction = new IPMTransaction;
      m_pIPMImportFile = new IPMImportFile ;
      ImportFile::instance()->add("IPMIN",m_pIPMTransaction,m_pIPMImportFile);
   }
   if (IF::Extract::instance()->getRecord("DFILES  MCPIN   ",strRecord))
      m_pMasterComProImport = new MasterComProImport();
   if (IF::Extract::instance()->getRecord("DFILES  MCPERR  ",strRecord))
   {
      m_pMasterComErrorImportFile = new MasterComErrorImportFile;
      m_pMasterComErrorTransaction = new MasterComErrorTransaction;
      ImportFile::instance()->add("MCPERR",m_pMasterComErrorTransaction,m_pMasterComErrorImportFile);
   }
   if (IF::Extract::instance()->getRecord("DFILES  MBLKER  ",strRecord))
      m_pMasterComBulkErrorFile = new MasterComBulkErrorFile();
   if (IF::Extract::instance()->getRecord("DFILES  MEXPIR  ",strRecord))
      m_pMasterComExpirationFile = new MasterComExpirationFile();
   if (IF::Extract::instance()->getRecord("DFILES  NYCIN   ",strRecord))
      ImportFile::instance()->add("NYCIN",&m_hNYCETransaction,ImportFile::instance());
   if (IF::Extract::instance()->getRecord("DFILES  NYCREJ  ",strRecord))
      ImportFile::instance()->add("NYCREJ",&m_hNYCEReject,ImportFile::instance());
   if (IF::Extract::instance()->getRecord("DFILES  EMSSHT  ",strRecord))
      m_pEMSSpreadsheetImport = new EMSSpreadsheetImport();
   if (IF::Extract::instance()->getRecord("DFILES  ISIARC  ", strRecord))
   {
      m_pStarInterfaceTransaction = new StarInterfaceTransaction;
      ImportFile::instance()->add("ISIARC",m_pStarInterfaceTransaction,ImportFile::instance());
   }
   if (IF::Extract::instance()->getRecord("DFILES  WEBADJ  ", strRecord))
      ImportFile::instance()->add("WEBADJ", &m_hSettlementWebAdjustmentTransaction, ImportFile::instance());
   if (IF::Extract::instance()->getRecord("DFILES  MCTQR4  ", strRecord))
	   ImportFile::instance()->add("MCTQR4", &m_hMasterCardTQR4ImportFile, ImportFile::instance());
   if (IF::Extract::instance()->getRecord("DFILES  MCT5G2  ", strRecord))
	   m_pMasterCardT5G2ImportFile = new MasterCardT5G2Import();
   if (IF::Extract::instance()->getRecord("DFILES  CMAIMS  ",strRecord))
      ImportFile::instance()->add("CMAIMS",&m_hAIMSFile[0],ImportFile::instance());
   if (IF::Extract::instance()->getRecord("DFILES  HOTCRD  ",strRecord))
      ImportFile::instance()->add("HOTCRD",&m_hAIMSFile[1],ImportFile::instance());
   if (IF::Extract::instance()->getRecord("DFILES  ACTEXT  ", strRecord))
      ImportFile::instance()->add("ACTEXT",&m_hAIMSFile[2],ImportFile::instance());
   if (IF::Extract::instance()->getRecord("DFILES  PSTBAL  ", strRecord))
      ImportFile::instance()->add("PSTBAL", &m_hAIMSFile[3], ImportFile::instance());
   if (IF::Extract::instance()->getRecord("DFILES  TLSENF  ", strRecord))
      ImportFile::instance()->add("TLSENF",&m_hAIMSFile[4],ImportFile::instance());
   if (IF::Extract::instance()->getRecord("DFILES  VISION  ", strRecord))
      ImportFile::instance()->add("VISION", &m_hAIMSFile[5], ImportFile::instance());
   if (IF::Extract::instance()->getRecord("DFILES  STRREJ  ",strRecord))
      m_pStarRejectImport = new StarRejectImport();
   if (IF::Extract::instance()->getRecord("DFILES  ISIIMG  ", strRecord)
      || IF::Extract::instance()->getRecord("DFILES  STRIRJ  ",strRecord)
      || IF::Extract::instance()->getRecord("DFILES  STRIAK  ",strRecord))
      m_pStarImageImport = new StarImageImport();
   if (IF::Extract::instance()->getRecord("DFILES  STRACK  ",strRecord))
      m_pStarAcknowledgementImport = new StarAcknowledgementImport();
   if (IF::Extract::instance()->getRecord("DFILES  HSTIMP  ", strRecord))
      m_pHistorylessBulkImport = new HistorylessBulkImport();
   Database::instance()->connect();
   m_pPartitionControl = new PartitionControl((
      PartitionAllocator*)DatabaseFactory::instance()->create("PartitionAllocator"));
   string strCustomer;
   IF::Extract::instance()->getSpec("CUSTOMER",strCustomer);
   reusable::Transaction::instance()->setCustomer(strCustomer);
   m_pCaseExport = new CaseExport();
   m_pCaseCreateCommand = new CaseCreateCommand();
   NationalException::instance()->setCaseCreateCommand(m_pCaseCreateCommand);
   MasterCardException::instance()->setCaseCreateCommand(m_pCaseCreateCommand);
   MasterCardException::instance()->setCaseUpdateCommand(m_pCaseUpdateCommand);
   m_hPulseTransaction.setCaseCreateCommand(m_pCaseCreateCommand);
   m_hStarTransaction.setCaseCreateCommand(m_pCaseCreateCommand);
   m_hStarPOSTransaction.setCaseCreateCommand(m_pCaseCreateCommand);
   m_hStarTransaction.setCaseUpdateCommand(m_pCaseUpdateCommand);
   m_hStarPOSTransaction.setCaseUpdateCommand(m_pCaseUpdateCommand);
   m_hCaseReplicationImport.setCaseCreateCommand(m_pCaseCreateCommand);
   m_hCaseReplicationImport.setCaseUpdateCommand(m_pCaseUpdateCommand);
   m_pCaseExport->setCaseUpdateCommand(m_pCaseUpdateCommand);
   EMSRulesEngine::instance();
   DataControl::instance();
   EMSBusinessDate::instance();
   new ActionFactory();
   new ExceptionFactory();
   new dnplatform::NetworkFactory();
   new dnplatform::APIExportFactory();
   new dnplatform::APIQueueExportFactory();
   ConfigurationRepository::instance()->loadTable("X_GENERIC");
   MinuteTimer::instance()->attach(this);
   return 0;
  //## end ExceptionInterface::initialize%375C1A6D0038.body
}

int ExceptionInterface::onMessage (Message& hMessage)
{
  //## begin ExceptionInterface::onMessage%375C1A760077.body preserve=yes
   return 0;
  //## end ExceptionInterface::onMessage%375C1A760077.body
}

int ExceptionInterface::onReset (Message& hMessage)
{
  //## begin ExceptionInterface::onReset%375C1A7D00C7.body preserve=yes
   string strContext((char*)hMessage.context());
   string strAction[2] = {"ENCRYPT","DECRYPT"};
   for(int i = 0; i < 2; i++)
   {
      if(strContext.find(strAction[i]) != string::npos)
      {
         if(!m_pDocSecure[i])
            m_pDocSecure[i] = new DocSecure(strAction[i].c_str());
         int iRC = -1;
         if(strContext.find("START") != string::npos)
            iRC = m_pDocSecure[i]->start();
         if(strContext.find("STOP") != string::npos)
            iRC = m_pDocSecure[i]->stop();
         if(iRC > 0)
         {  //command successful
            Console::display("ST604",strAction[i].c_str()); 
            Database::instance()->commit();
         }
         else
         {  //command failed
            Console::display("ST605",strAction[i].c_str()); 
            Database::instance()->rollback();
         }
         return 0;
      }
   }
   reusable::Transaction::instance()->begin();
   reusable::Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSS(true) += "00");
   string strCustomer;
   IF::Extract::instance()->getSpec("CUSTOMER",strCustomer);
   reusable::Transaction::instance()->setCustomer(strCustomer);
   EMSRulesEngine::instance()->reset();
   if (!memcmp((char*)hMessage.context(),"EXPORT",6))
   {
      string strTemp(hMessage.context().subString(9,100,'\0').data());
      Trace::put("Context");
      Trace::put(strTemp.data());
      string strCustID;
      string strNetID;
      string strDate;
      const char *p = strstr(strTemp.c_str(),"CUST=");
      if (p)
         strCustID.assign(p+5,4);
      p = strstr(strTemp.c_str(),"DATE=");
      if (p)
         strDate.assign(p+5,8);
      Trace::put("Date:");
      Trace::put(strDate.data());
      NationalException::instance()->setBusDateOverride(strDate);
      strNetID = strTemp.substr(0,6);
      if (strNetID.length() != 0)
      {
         size_t pos = strNetID.find_first_of(" ");
         if (pos != string::npos)
            strNetID.erase(pos);
         strTemp.erase();
         if (strNetID == "STR")
         {
            if (!(IF::Extract::instance()->getRecord("DSPEC   EI00    ISIARC~",strTemp) && strTemp.length() >= 31
               && memcmp(Clock::instance()->getYYYYMMDDHHMMSS().c_str(),strTemp.c_str() + 23,8) >= 0))
            {
               string strYYYYMMDD("20050925");
               IF::Extract::instance()->getSpec("STAR2005",strYYYYMMDD);
               if (Clock::instance()->getYYYYMMDDHHMMSS().substr(0,8) < strYYYYMMDD)
                  StarCaseExport::instance()->deport();
               else
               {
                  StarExport* pStarExport = new StarExport();
                  pStarExport->create();
                  delete pStarExport;
               }
            }
         }
         else if (strNetID == "VCR")
         {
            m_pVCRExportCases->execute();
         }
         else
            NationalException::instance()->deport(strNetID,strCustID);
      }
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"CPP",3) == 0)
   {
      ImportFile::instance()->read("CPPIN");
      setQueueWaitOption(false);
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"STR",3) == 0)
   {
      if (memcmp((char*)hMessage.context() + 11,"REJ",3) == 0)
      {
         if (m_pStarRejectImport)
            m_pStarRejectImport->execute();
      }
      else
      if (memcmp((char*)hMessage.context() + 11,"ACK",3) == 0)
      {
         if (m_pStarAcknowledgementImport)
            m_pStarAcknowledgementImport->execute();
      }
      else
      {
         ImportFile::instance()->read("STRIN");
         setQueueWaitOption(false);
      }
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"PUL",3) == 0)
   {
      if (m_pPulseImport)
      {
         m_pPulseImport->read("PULIN");
         setQueueWaitOption(false);
      }
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"DNA",3) == 0)
   {
      ImportFile::instance()->read("DNAIN");
      setQueueWaitOption(false);
   }
   else
   if (memcmp((char*)hMessage.context(), "IMPORT", 6) == 0
	   && memcmp((char*)hMessage.context() + 8, "SMWEB", 3) == 0)
   {
		   ImportFile::instance()->read("WEBADJ");
		   setQueueWaitOption(false);
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"C2C",3) == 0)
   {
      if (m_pC2CImport)
      {
         m_pC2CImport->read("ECIN",false);
         setQueueWaitOption(false);
      }
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"FRDIN",5) == 0)
   {
      if (m_pSAFEImportFile)
      {
         m_pSAFEImportFile->read("FRDIN",false);
         setQueueWaitOption(false);
      }
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"AISOIN",6) == 0)
   {
      if (m_pVisaAdminIsoImportFile)
      {
         m_pVisaAdminIsoImportFile->read("AISOIN",false);
         setQueueWaitOption(false);
      }
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"CUP",3) == 0)
   {
      ImportFile::instance()->read("CUPIN");
      setQueueWaitOption(false);
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"IPM",3) == 0)
   {
      m_pIPMImportFile->read("IPMIN");
      setQueueWaitOption(false);
   }
   //else
   //if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
   //   && memcmp((char*)hMessage.context() + 8,"MCI",3) == 0)
   //{
   //   ImportFile::instance()->read("MCIN");
   //   setQueueWaitOption(false);
   //}
   //else
   //if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
   //   && memcmp((char*)hMessage.context() + 8,"VNT",3) == 0)
   //{
   //   ImportFile::instance()->read("VNTIN");
   //   setQueueWaitOption(false);
   //}
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"MCOFLN",6) == 0)
   {
      bool bReturn = MasterCardException::instance()->import();
      if (!bReturn)
      {
         Console::display("ST545","MCOFLN"); // ST545 - PROCESSING NOT COMPLETE FOR @@@ IMPORT FILE.
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
      }
      else
         Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"NYCIN",5) == 0)
   {
      ImportFile::instance()->read("NYCIN");
      setQueueWaitOption(false);
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"NYCREJ",6) == 0)
   {
      ImportFile::instance()->read("NYCREJ");
      setQueueWaitOption(false);
   }
#ifndef _UNIX
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"BAMS",4) == 0)
   {
      m_pBAMSExceptionImport->execute();
   }
#endif
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"MCPERR",6) == 0)
   {
      ImportFile::instance()->read("MCPERR");
      setQueueWaitOption(false);
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"MCPBLK",6) == 0)
   {
      if (m_pMasterComBulkErrorFile)
         m_pMasterComBulkErrorFile->execute();
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"MEXPIR",6) == 0)
   {
      if (m_pMasterComExpirationFile)
         m_pMasterComExpirationFile->execute();
   } 
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"EMSSHT",6) == 0)
   {
      if (m_pEMSSpreadsheetImport)
         m_pEMSSpreadsheetImport->execute();
   }
   else
   if (memcmp((char*)hMessage.context(), "IMPORT", 6) == 0
      && memcmp((char*)hMessage.context() + 8, "ISIARC", 6) == 0)
   {
      ImportFile::instance()->read("ISIARC");
      setQueueWaitOption(false);
   }
   else
   if (memcmp((char*)hMessage.context(), "IMPORT", 6) == 0
	   && memcmp((char*)hMessage.context() + 8, "MCTQR4", 6) == 0)
   {
	   ImportFile::instance()->read("MCTQR4");
	   setQueueWaitOption(false);
   }
   else
   if (memcmp((char*)hMessage.context(), "IMPORT", 6) == 0
	   && memcmp((char*)hMessage.context() + 8, "MCT5G2", 6) == 0)
   {
	   if (m_pMasterCardT5G2ImportFile)
	   {
		  if (!m_pMasterCardT5G2ImportFile->execute())
	      {
		     Console::display("ST545", "MCT5G2"); // ST545 - PROCESSING NOT COMPLETE FOR @@@ IMPORT FILE.
		     Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
	      }
	      else
		     Database::instance()->setTransactionState(Database::COMMITREQUIRED);
       }
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"CMAIMS",6) == 0)
   {
      ImportFile::instance()->read("CMAIMS", false);
      setQueueWaitOption(false);
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"PSTBAL",6) == 0)
   {
      ImportFile::instance()->read("PSTBAL", false);
      setQueueWaitOption(false);
   }
   else
   if (memcmp((char*)hMessage.context(),"IMPORT",6) == 0
      && memcmp((char*)hMessage.context() + 8,"HOTCRD",6) == 0)
   {
      ImportFile::instance()->read("HOTCRD");
      setQueueWaitOption(false);
   }
   else
   if (memcmp((char*)hMessage.context(), "IMPORT", 6) == 0
      && memcmp((char*)hMessage.context() + 8, "ACTEXT", 6) == 0)
   {
      ImportFile::instance()->read("ACTEXT",false);
      setQueueWaitOption(false);
   }
   else
   if (memcmp((char*)hMessage.context(), "IMPORT", 6) == 0
      && memcmp((char*)hMessage.context() + 8, "TLSENF", 6) == 0)
   {
      ImportFile::instance()->read("TLSENF", false);
      setQueueWaitOption(false);
   }
   else
      if (memcmp((char*)hMessage.context(), "IMPORT", 6) == 0
      && memcmp((char*)hMessage.context() + 8, "VISION", 6) == 0)
   {
      ImportFile::instance()->read("VISION", false);
      setQueueWaitOption(false);
   }
   else
   if (!memcmp((char*)hMessage.context(),"IMPORT",6))
   {
      string strTemp(hMessage.context().subString(9,100,'\0').data());
      string strNetID = "";
      string strDate = "";
      const char *p = strstr(strTemp.c_str(),"DATE=");
      if (p)
         strDate.assign(p+5,8);
      NationalException::instance()->setBusDateOverride(strDate);
      strNetID = strTemp.substr(0,3);
      if(!NationalException::instance()->import(strNetID))
         Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
      else
         Database::instance()->setTransactionState(Database::COMMITREQUIRED);
   }
   else
   if (!memcmp((char*)hMessage.context(),"EOD",3))
   {
      SettledAdjustment::instance()->deport();
      GetOriginalFinancialCommand::instance()->execute();
   }
   else
   if (!memcmp((char*)hMessage.context(),"SEND",4))
   {
      string strTemp(hMessage.context().subString(9, 3, '\0').data());
      size_t n = strTemp.find_last_not_of(' ');
      if (n != string::npos)
      {
         string strCriticalSection(IF::Extract::instance()->getName().c_str(), 2);
         strCriticalSection.append("AUTOTRAN", 8);
         CriticalSection hCriticalSection(strCriticalSection.c_str());
         strTemp.erase(n + 1);
         m_pCaseExport->execute(strTemp);
      }
   }
   else
   if (!memcmp((char*)hMessage.context(),"SETTLE",6))
   {
      string strTemp(hMessage.context().subString(9,20,'\0').data());
      size_t n = strTemp.find_last_not_of(' ');
      if (n != string::npos)
         strTemp.erase(n + 1);
      SettledAdjustment::instance()->deport(strTemp.data());
   }
   else
   if (!memcmp((char*)hMessage.context(),"DELETEIA",8))
   {
      UseCase hUseCase("DR","## DR78 DELETE IMPORT AUDIT");
      GenericDelete hGenericDelete("IMPORT_AUDIT","TSTAMP_CREATED",false,30,"QUALIFY");
      hGenericDelete.deleteRecords("TSTAMP_CREATED",(char*)hMessage.context().subString(9));
   }
   else
   if (!memcmp((char*)hMessage.context(),"DELETECL",8))
   {
      UseCase hUseCase("DR","## DR12 DELETE CLOSED CASES");
      string strTemp;
      IF::Extract::instance()->getSpec("DELDAYS",strTemp);
      GenericDelete hGenericDelete("EMS_CASE","CASE_ID",true,atoi(strTemp.c_str()));
      hGenericDelete.deleteClosedRecords(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   }
   else
   if (!memcmp((char*)hMessage.context(), "DELETEAP", 8))
      m_pAPIAging->execute();
   else
   if (!memcmp((char*)hMessage.context(),"DELETE",6))
   {
      UseCase hUseCase("DR","## DR53 DELETE EMS CASES");
      EMSDocDeleteList hDocDeleteList;
      hDocDeleteList.setDeleteInfo((char*)hMessage.context().subString(9));
      hDocDeleteList.execute();
      GenericDelete hGenericDelete("EMS_CASE","CASE_ID",true,180);
      hGenericDelete.deleteRecords("TSTAMP_UPDATED",(char*)hMessage.context().subString(9));
      GenericDelete hGenericDelete2("EMS_UNMATCHED_MSG","TSTAMP_CREATED",false,730,"QUALIFY");
      hGenericDelete2.deleteRecords("TSTAMP_CREATED","24MONTHS");
      GenericDelete hGenericDelete3("SM_WEB_ADJ","TSTAMP_TRANS", false, 180);
      hGenericDelete3.deleteRecords("TSTAMP_TRANS",(char*)hMessage.context().subString(9));
      CaseCardholderInfoCommand hCaseCardholderInfoCommand;
      hCaseCardholderInfoCommand.deleteObsolete();
   }
   else
   if (!memcmp((char*)hMessage.context(),"BQIDOWN",7))
   {
      string strContext((char*)hMessage.context());
      m_pBulkQuestionnaireImport->setBilling(true);
      if(strContext.find("NOBILL") != string::npos)
         m_pBulkQuestionnaireImport->setBilling(false);
      if (m_pBulkQuestionnaireImport)
         m_pBulkQuestionnaireImport->update(0);
   }
   else
   if (!memcmp((char*)hMessage.context(),"BPRDOWN",7))
   {
      if (m_pBulkQuestionnaireImport)
         m_pBulkQuestionnaireImport->update(0);
   }
   else
   if (!memcmp((char*)hMessage.context(),"BMDOWN",6))
   {
      m_pBulkMailImport->execute();
   }
   else
   if (!memcmp((char*)hMessage.context(),"MCPDOWN",7))
   {
      if (m_pMasterComProImport)
         m_pMasterComProImport->execute();
   }
   else
   if (!memcmp((char*)hMessage.context(), "VCR", 3))
   {
      Action hAction;
      hAction.setAction("EXP_VCR");
      std::auto_ptr<rules::Function> pFunction((rules::Function*)rules::FunctionFactory::instance()->create("EXP_VCR"));
      if (pFunction.get())
      {
         string strTemp(hMessage.context().subString(9, 10, '\0').data());
         size_t n = strTemp.find_last_not_of(' ');
         if (n != string::npos)
         {
            strTemp.erase(n + 1);
            ActionDetail hActionDetail;
            hActionDetail.setInstruction(strTemp.c_str());
            pFunction->execute(hAction, hActionDetail);
         }
      }
   }
   else
   if (!memcmp((char*)hMessage.context(),"COMMENTS",8))
   {
      CaseCommentsExport::instance()->deport();
   }
   else
   if (!memcmp((char*)hMessage.context(), "DOCSTAT", 7))
   {
      SendDocStatusAPI hSendDocStatusAPI;
      hSendDocStatusAPI.execute();
   }
   else
   if (!memcmp((char*)hMessage.context(), "CFSTAT", 6))
      {
         SendCaseFilingStatusAPI hSendCaseFilingStatusAPI;
         hSendCaseFilingStatusAPI.execute();
      }
   else
   if (!memcmp((char*)hMessage.context(), "NETSTAT", 7))
   {
      NetworkStatus hNetworkStatus;
      hNetworkStatus.execute();
   }
   else
   if (!memcmp((char*)hMessage.context(),"CFACQRSP",8))
   {
      CaseFilingAcquirerResponse hCaseFilingAcquirerResponse;
      hCaseFilingAcquirerResponse.execute();
   }
   else
   if (!memcmp((char*)hMessage.context(), "CFNETRSP", 8))
   {
      CaseFilingNetworkResponse hCaseFilingNetworkResponse;
      hCaseFilingNetworkResponse.execute();
   }
   else
   if (!memcmp((char*)hMessage.context(),"RTCLMDTL",8))
   {
      RetrieveClaimsDetail hRetrieveClaimsDetail;
      hRetrieveClaimsDetail.execute();
   }
   else
   if (!memcmp((char*)hMessage.context(),"QUEUES",6))
   {
	   string strQueueName(hMessage.context().subString(8, 100, '\0').data());  
      Trace::put("EI00 Reset command");
      Trace::put(strQueueName.c_str());
      if (strQueueName[9] != ' ')  // coming from EM
         strQueueName.erase(70);
      Trace::put(strQueueName.c_str());
      size_t n = strQueueName.find_first_of(' ');
	   while (n != string::npos)
	   {
		   strQueueName.erase(n, 1);
		   n = strQueueName.find_first_of(' ');
	   }
      Trace::put("after space removing");
      Trace::put(strQueueName.c_str());
      if (strQueueName.substr(0,3) == "ALL")
      {
         if (strQueueName.substr(3) == "MCI")
         {
            if (m_pMasterComAPIQueue == 0)
                m_pMasterComAPIQueue = new MasterComAPIQueue();
            m_pMasterComAPIQueue->deport(strQueueName.c_str());
         }
         else if (strQueueName.substr(3) == "VCR")
         {
            if (m_pVisaQueue == 0)
                m_pVisaQueue = new VisaQueue();
            m_pVisaQueue->deport(strQueueName.c_str());
         }
      }
      else if (strQueueName.substr(0,3) == "MCI") 
	   {
         if (m_pMasterComAPIQueue == 0)
            m_pMasterComAPIQueue = new MasterComAPIQueue();
         m_pMasterComAPIQueue->deport(strQueueName.c_str());
      }
      else if (strQueueName.substr(0,3) == "VCR")
      {
         if (m_pVisaQueue == 0)
            m_pVisaQueue = new VisaQueue();
         m_pVisaQueue->deport(strQueueName.c_str());
	   }
   }
   else
   if (memcmp((char*)hMessage.context(),"TRANS",5) == 0
      && memcmp((char*)hMessage.context() + 8,"CMPL",4) == 0)
   {
      CBACompliance hCBACompliance;
      hCBACompliance.execute();
   }
   else
      Console::display("ST547",(const char*)hMessage.context());
   if (Database::instance()->transactionState() == Database::COMMITREQUIRED)
      Database::instance()->commit();
   else
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      Database::instance()->rollback();
   reusable::Transaction::instance()->commit();
   IF::Extract::instance()->getSpec("CUSTOMER",strCustomer);
   NationalException::instance()->setQualifierFromNetwork(strCustomer);
   return 0;
  //## end ExceptionInterface::onReset%375C1A7D00C7.body
}

int ExceptionInterface::onResume (Message& hMessage)
{
  //## begin ExceptionInterface::onResume%3ED1F6ED0186.body preserve=yes
   if (m_pExceptionRepair)
   {
      if (m_pExceptionRepair->onResume())
      {  //all done
         delete m_pExceptionRepair;
         m_pExceptionRepair = 0;
         setQueueWaitOption(true);
      }
      return 0;
   }
   if ((long)m_pSignal[0] == -1)
   {
      string strValue;
      if (IF::Extract::instance()->getSpec("IDMQUEUE",strValue))
      {
         m_pSignal[0] = new Signal("ProvCredit");
         IF::ExternalQueue* pReplyExternalQueue = (IF::ExternalQueue*)regionsapi::ProvisionalCredit::instance()->getReplyExternalQueue();
         if (pReplyExternalQueue)
         {
            pReplyExternalQueue->setSignal(m_pSignal[0]);
            m_pSignal[0]->attach((Observer*)pReplyExternalQueue);
            Application::instance()->enable(m_pSignal[0]);
            Message::instance(Message::INBOUND)->attach(regionsapi::ProvisionalCredit::instance());
            pReplyExternalQueue->open();
         }
      }
      else
         m_pSignal[0] = 0;
      if (IF::Extract::instance()->getSpec("FAXQUEUE",strValue))
      {
         m_pSignal[1] = new Signal("RightFax");
         m_pRightFax = new regionsapi::RightFax(strValue);
         IF::ExternalQueue* pExternalQueue = (IF::ExternalQueue*)m_pRightFax->getExternalQueue();
         pExternalQueue->setSignal(m_pSignal[1]);
         m_pSignal[1]->attach((Observer*)pExternalQueue);
         Application::instance()->enable(m_pSignal[1]);
         pExternalQueue->open();
      }
      else
         m_pSignal[1] = 0;
   }
   for(int i = 0; i < 2; i++)
   {
      if(m_pDocSecure[i])
      {
         int iRC = m_pDocSecure[i]->onResume();
         if(iRC < 0)
            Database::instance()->rollback();
         else if(iRC == 0)
         {
            Database::instance()->commit();
            delete m_pDocSecure[i];
            m_pDocSecure[i] = 0;
         }
         else if(iRC > 0)
            Database::instance()->commit();
      }
   }
   reusable::Transaction::instance()->begin();
   reusable::Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   string strCustomer;
   IF::Extract::instance()->getSpec("CUSTOMER",strCustomer);
   reusable::Transaction::instance()->setCustomer(strCustomer);
   EMSRulesEngine::instance()->reset();
   ImportFile::instance()->onResume();
   if (Database::instance()->transactionState() == Database::COMMITREQUIRED)
      Database::instance()->commit();
   else
      Database::instance()->rollback();
   reusable::Transaction::instance()->commit();
   if (Application::instance()->getQueueWaitOption())
      m_pBillDataLoader->onResume();
   return 0;
  //## end ExceptionInterface::onResume%3ED1F6ED0186.body
}

// Additional Declarations
  //## begin ExceptionInterface%375C1A2C0247.declarations preserve=yes
void ExceptionInterface::update (Subject* pSubject)
{
   if (pSubject == MinuteTimer::instance())
      setQueueWaitOption(false);
   if (pSubject == Database::instance() &&
       Database::instance()->state() == Database::CONNECTED)
   {
      m_pExceptionRepair = new ExceptionRepair();
      setQueueWaitOption(false);
   }
   Application::update(pSubject);
}
  //## end ExceptionInterface%375C1A2C0247.declarations
//## begin module%375C1ADD0346.epilog preserve=yes
//## end module%375C1ADD0346.epilog
