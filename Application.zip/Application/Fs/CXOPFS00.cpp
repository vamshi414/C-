//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%51DBF9A7020E.cm preserve=no
//## end module%51DBF9A7020E.cm

//## begin module%51DBF9A7020E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%51DBF9A7020E.cp

//## Module: CXOPFS00%51DBF9A7020E; Package body
//## Subsystem: FS%51DBF988009A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\ConnexPlatform\Server\Application\Fs\CXOPFS00.cpp

//## begin module%51DBF9A7020E.additionalIncludes preserve=no
//## end module%51DBF9A7020E.additionalIncludes

//## begin module%51DBF9A7020E.includes preserve=yes
//## end module%51DBF9A7020E.includes

#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSBS28_h
#include "CXODBS28.hpp"
#endif
#ifndef CXOSDB44_h
#include "CXODDB44.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSSW01_h
#include "CXODSW01.hpp"
#endif
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
#ifndef CXOPFS00_h
#include "CXODFS00.hpp"
#endif


//## begin module%51DBF9A7020E.declarations preserve=no
//## end module%51DBF9A7020E.declarations

//## begin module%51DBF9A7020E.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new FileScan();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
#define ALPHA_BIN    0
#define ALPHA_SOURCE 1
#define PPROD        2
//## end module%51DBF9A7020E.additionalDeclarations


// Class FileScan 

FileScan::FileScan()
  //## begin FileScan::FileScan%51DBF9660065_const.hasinit preserve=no
      : m_pBuffer(0),
        m_iSEQ_NO(1)
  //## end FileScan::FileScan%51DBF9660065_const.hasinit
  //## begin FileScan::FileScan%51DBF9660065_const.initialization preserve=yes
  //## end FileScan::FileScan%51DBF9660065_const.initialization
{
  //## begin FileScan::FileScan%51DBF9660065_const.body preserve=yes
      memcpy(m_sID, "FS00", 4);
      m_pBuffer = new char[256];
      m_strFileName[ALPHA_BIN].assign("alpha_bin.txt");
      m_strFileName[ALPHA_SOURCE].assign("alpha_source.txt");
      m_strFileName[PPROD].assign("pprod.txt");
      m_strCONTEXT_KEY[ALPHA_BIN] = "ALPHA_BIN";
      m_strCONTEXT_KEY[ALPHA_SOURCE] = "ALPHA_SOURCE";
      m_strCONTEXT_KEY[PPROD] = "PPROD";
      m_strResource[ALPHA_BIN] = "Alpha/Bin";
      m_strResource[ALPHA_SOURCE] = "Alpha/Source";
      m_strResource[PPROD] = "Pprod";
      m_strDFILES[ALPHA_BIN] = "SCAN0";
      m_strDFILES[ALPHA_SOURCE] = "SCAN1";
      m_strDFILES[PPROD] = "SCAN2";
  //## end FileScan::FileScan%51DBF9660065_const.body
}


FileScan::~FileScan()
{
  //## begin FileScan::~FileScan%51DBF9660065_dest.body preserve=yes
   delete[] m_pBuffer;
  //## end FileScan::~FileScan%51DBF9660065_dest.body
}



//## Other Operations (implementation)
const string FileScan::generateDigest (const string& strDFILE)
{
  //## begin FileScan::generateDigest%6259C49702EB.body preserve=yes
   size_t m = 0;
   EVP_MD* md = (EVP_MD*)EVP_sha256();
   EVP_MD_CTX* mdctx = EVP_MD_CTX_new();
   unsigned char md_value[EVP_MAX_MD_SIZE];
   unsigned int md_len;
   EVP_MD_CTX_reset(mdctx);
   EVP_DigestInit_ex(mdctx, md, NULL);
   FlatFile hFlatFile(strDFILE.c_str());
   if (!hFlatFile.open())
      return "";
   while (hFlatFile.read(m_pBuffer, 256, &m))
   {
      EVP_DigestUpdate(mdctx, m_pBuffer, m);
   }
   hFlatFile.close();
   EVP_DigestFinal_ex(mdctx, md_value, &md_len);
   EVP_MD_CTX_free(mdctx);
   char szTemp[3];
   string strHash;
   for (int i = 0; i < md_len; i++)
      strHash.append(szTemp, snprintf(szTemp, sizeof(szTemp), "%02x", (unsigned char)md_value[i]));
   return strHash;
  //## end FileScan::generateDigest%6259C49702EB.body
}

int FileScan::initialize ()
{
  //## begin FileScan::initialize%51DBFA3503A2.body preserve=yes
   new platform::Platform();
   new segment::AuditEvent;
   int iRC = Application::initialize();
   UseCase hUseCase("FD","## FD04 START FS");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   string strDFILES;
   for (int i = 0; i < 3; i++)
   {
      strDFILES.assign(m_pBuffer, snprintf(m_pBuffer, 256, "DFILES  SCAN%d   %s\\%s\\%s", i, Extract::instance()->getNode001().c_str(), "Alpha\\Bin", m_strFileName[i].c_str()));
#ifdef _UNIX
      size_t pos;
      while ((pos = strDFILES.find('\\')) != string::npos)
         strDFILES.replace(pos, 1, "/");
#endif
      if (!Extract::instance()->getRecord(strDFILES.substr(0, 16).c_str(), strDFILES))
         Extract::instance()->addRecord(strDFILES);
   }
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->connect();
   MinuteTimer::instance()->attach(this);
   return 0;
  //## end FileScan::initialize%51DBFA3503A2.body
}

bool FileScan::readAuditFile ()
{
  //## begin FileScan::readAuditFile%51DC821D0327.body preserve=yes
   FlatFile hFlatFile("AUDIT");
   if (!hFlatFile.open())
      return false;
   char sBuffer[257];
   Table hTable;
   AuditEventSegment hAuditEventSegment;
   string strCUST_ID;
   Extract::instance()->getSpec("CUSTOMER",strCUST_ID);
   string strHOST = Extract::instance()->getHost();
   auto_ptr<reusable::Statement> pInsertStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("InsertStatement"));
   size_t lLen = 0;
   while (hFlatFile.read(sBuffer,256,&lLen))
   {
      if(lLen > 25)
      {
         string strTSTAMP_CREATED(sBuffer,16);
         hAuditEventSegment.setTSTAMP_CREATED(strTSTAMP_CREATED);
         if(strTSTAMP_CREATED == m_strLastTstamp)
            m_iSEQ_NO++;
         else
            m_iSEQ_NO = 1;
         m_strLastTstamp = strTSTAMP_CREATED;
         hAuditEventSegment.setSEQ_NO(m_iSEQ_NO);
         if(memcmp(sBuffer+17,"UPDATE",6) == 0)
            hAuditEventSegment.setEVENT_TYPE(database::AuditEvent::SYSTEM_LEVEL_OBJECT + database::AuditEvent::UPDATE);
         else
         if(memcmp(sBuffer+17,"INSERT",6) == 0)
            hAuditEventSegment.setEVENT_TYPE(database::AuditEvent::SYSTEM_LEVEL_OBJECT + database::AuditEvent::INSERT);
         else
         if(memcmp(sBuffer+17,"DELETE",6) == 0)
            hAuditEventSegment.setEVENT_TYPE(database::AuditEvent::SYSTEM_LEVEL_OBJECT + database::AuditEvent::DEL);
         hAuditEventSegment.setCUST_ID(strCUST_ID);
         hAuditEventSegment.setUSER_ID("UNKNOWN");
         hAuditEventSegment.setTASKID(Application::instance()->name());
         hAuditEventSegment.setORIGINATION(strHOST);
         string strBuffer(sBuffer+24,lLen-24);
         size_t pos = strBuffer.find_first_of(' ');
         if(pos != string::npos)
         {
            hAuditEventSegment.setRESOURCE_NAME(strBuffer.substr(0,pos));
            hAuditEventSegment.setRESOURCE_KEY(strBuffer.substr(pos+1));
         }
         hAuditEventSegment.setRETURN_CODE(0);
         hAuditEventSegment.setColumns(hTable);
         if (pInsertStatement->execute(hTable) == false)
         {
            Database::instance()->rollback();
            return false;
         }
      }
   }
   Database::instance()->commit();
   hFlatFile.move("..\\Complete");
   return true;
  //## end FileScan::readAuditFile%51DC821D0327.body
}

void FileScan::update (Subject* pSubject)
{
  //## begin FileScan::update%51DBFA3A01BB.body preserve=yes
   if(pSubject == MinuteTimer::instance())
   {
      if (Clock::instance()->getMinute() % 10 == 0)
      {
         verifyDigest();
         Job::submit("CXOXSCAN");
      }
      else
         while(readAuditFile())
            Database::instance()->commit();
   }
   Application::update(pSubject);
  //## end FileScan::update%51DBFA3A01BB.body
}

void FileScan::verifyDigest ()
{
  //## begin FileScan::verifyDigest%6255CD03015C.body preserve=yes
   for (int i = 0; i < 3; i++)
      m_strComputedDigest[i] = generateDigest(m_strDFILES[i]);
   Context hContext("*", "*");
   if (hContext.get("ALPHA_BIN", m_strCONTEXT_DATA))
      m_strSavedDigest[ALPHA_BIN] = m_strCONTEXT_DATA;
   if (hContext.get("ALPHA_SOURCE", m_strCONTEXT_DATA))
      m_strSavedDigest[ALPHA_SOURCE] = m_strCONTEXT_DATA;
   if (hContext.get("PPROD", m_strCONTEXT_DATA))
      m_strSavedDigest[PPROD] = m_strCONTEXT_DATA;
   for (int i = 0; i < 3; i++)
   {
      if (m_strComputedDigest[i] != m_strSavedDigest[i])
      {
         if (!m_strSavedDigest[i].empty())
         {
            database::AuditEvent::capture("", 700, 0, "modification", m_strResource[i]);
            database::AuditEvent::commit(false);
         }
         hContext.put(m_strCONTEXT_KEY[i].c_str(), m_strComputedDigest[i].c_str());
      }
   }
   Database::instance()->commit();
  //## end FileScan::verifyDigest%6255CD03015C.body
}

// Additional Declarations
  //## begin FileScan%51DBF9660065.declarations preserve=yes
  //## end FileScan%51DBF9660065.declarations

//## begin module%51DBF9A7020E.epilog preserve=yes
//## end module%51DBF9A7020E.epilog
