//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39A530940325.cm preserve=no
//	$Date:   Jun 22 2018 00:50:44  $ $Author:   e3018367  $
//	$Revision:   1.28  $
//## end module%39A530940325.cm

//## begin module%39A530940325.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39A530940325.cp

//## Module: CXOSLM01%39A530940325; Package specification
//## Subsystem: LM%3597EB1A028A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Lm\CXODLM01.hpp

#ifndef CXOSLM01_h
#define CXOSLM01_h 1

//## begin module%39A530940325.additionalIncludes preserve=no
//## end module%39A530940325.additionalIncludes

//## begin module%39A530940325.includes preserve=yes
// $Date:   Jun 22 2018 00:50:44  $ $Author:   e3018367  $ $Revision:   1.28  $
//## end module%39A530940325.includes

#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif

struct EMSFraudAndFeeBillingRecord;
struct EMSExceptionBillingRecord;
//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class FormatSelectVisitor;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Job;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class Context;
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%39A530940325.declarations preserve=no
//## end module%39A530940325.declarations

//## begin module%39A530940325.additionalDeclarations preserve=yes
//## end module%39A530940325.additionalDeclarations


//## begin EMSBilling%39A52EAA0078.preface preserve=yes
//## end EMSBilling%39A52EAA0078.preface

//## Class: EMSBilling%39A52EAA0078
//## Category: DataNavigator Foundation::Application::LocatorManager_CAT%354B349200A7
//## Subsystem: LM%3597EB1A028A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39A5301F01F1;timer::Clock { -> F}
//## Uses: <unnamed>%39A5303B02EB;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%39A5303D038E;reusable::FormatSelectVisitor { -> F}
//## Uses: <unnamed>%39A5317000E7;IF::Extract { -> F}
//## Uses: <unnamed>%39A53D3601E5;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%39AE618C016F;database::Database { -> F}
//## Uses: <unnamed>%39AE62DF0018;IF::Job { -> F}
//## Uses: <unnamed>%39AE63F5005E;process::Application { -> F}
//## Uses: <unnamed>%39BFCE5F01CA;database::Context { -> F}
//## Uses: <unnamed>%3A3938BC03E2;monitor::UseCase { -> F}
//## Uses: <unnamed>%3ED5445B00DA;EMSExceptionBillingRecord { -> F}
//## Uses: <unnamed>%3ED5493D0271;EMSFraudAndFeeBillingRecord { -> F}
//## Uses: <unnamed>%4CD7880200A3;IF::FlatFile { -> F}

class EMSBilling : public reusable::Observer  //## Inherits: <unnamed>%39A53D0E01FC
{
  //## begin EMSBilling%39A52EAA0078.initialDeclarations preserve=yes
  //## end EMSBilling%39A52EAA0078.initialDeclarations

  public:
    //## Constructors (generated)
      EMSBilling();

    //## Destructor (generated)
      virtual ~EMSBilling();


    //## Other Operations (specified)
      //## Operation: getHomeProc%40ACAC7A00EA
      string getHomeProc (const string& strHomeSwitch);

      //## Operation: getHomeSwitch%3F3BD1FD03C8
      const string& getHomeSwitch ();

      //## Operation: reset%39BE49BB031C
      void reset (bool bForce, const string& strDate, bool bDaily = false);

      //## Operation: update%39A530F900AA
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin EMSBilling%39A52EAA0078.public preserve=yes
      //## end EMSBilling%39A52EAA0078.public

  protected:
    // Additional Protected Declarations
      //## begin EMSBilling%39A52EAA0078.protected preserve=yes
      //## end EMSBilling%39A52EAA0078.protected

  private:

    //## Other Operations (specified)
      //## Operation: createBillingFiles%3ED7CFF7008C
      bool createBillingFiles ();

      //## Operation: createExceptionBillingFile%39A533E900DD
      bool createExceptionBillingFile ();

      //## Operation: createFraudAndFeeBillingFile%3ED53EA403B9
      bool createFraudAndFeeBillingFile ();

      //## Operation: shouldBill%39BE4A14039C
      bool shouldBill ();

      //## Operation: writeException%3F0EA2DE034B
      bool writeException ();

      //## Operation: writeFraudFee%3F0E9DD5030D
      bool writeFraudFee ();

      //## Operation: getVisaFeeCounts%5AD085240141
      bool getVisaFeeCounts ();

    // Data Members for Class Attributes

      //## Attribute: INTERNAL%3ED78CD10157
      //## begin EMSBilling::INTERNAL%3ED78CD10157.attr preserve=no  private: string {U} 
      string m_strINTERNAL;
      //## end EMSBilling::INTERNAL%3ED78CD10157.attr

    // Additional Private Declarations
      //## begin EMSBilling%39A52EAA0078.private preserve=yes
      //## end EMSBilling%39A52EAA0078.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BillingDate%418AA18D0157
      //## begin EMSBilling::BillingDate%418AA18D0157.attr preserve=no  private: string {U} 
      string m_strBillingDate;
      //## end EMSBilling::BillingDate%418AA18D0157.attr

      //## Attribute: BillingMonth%39BE5873000D
      //## begin EMSBilling::BillingMonth%39BE5873000D.attr preserve=no  private: string {U} 
      string m_strBillingMonth;
      //## end EMSBilling::BillingMonth%39BE5873000D.attr

      //## Attribute: BillOrbit%445863B801C5
      //## begin EMSBilling::BillOrbit%445863B801C5.attr preserve=no  private: bool {U} false
      bool m_bBillOrbit;
      //## end EMSBilling::BillOrbit%445863B801C5.attr

      //## Attribute: CASE_EXTENSION%5887AA75036E
      //## begin EMSBilling::CASE_EXTENSION%5887AA75036E.attr preserve=no  private: string {U} 
      string m_strCASE_EXTENSION;
      //## end EMSBilling::CASE_EXTENSION%5887AA75036E.attr

      //## Attribute: CASE_ID%39A53D9903C8
      //## begin EMSBilling::CASE_ID%39A53D9903C8.attr preserve=no  private: string {U} 
      string m_strCASE_ID;
      //## end EMSBilling::CASE_ID%39A53D9903C8.attr

      //## Attribute: CASE_NO%463F370803C3
      //## begin EMSBilling::CASE_NO%463F370803C3.attr preserve=no  private: string {V} 
      string m_strCASE_NO;
      //## end EMSBilling::CASE_NO%463F370803C3.attr

      //## Attribute: CaseCount%4639DE8B0003
      //## begin EMSBilling::CaseCount%4639DE8B0003.attr preserve=no  private: int {U} 1
      int m_iCaseCount;
      //## end EMSBilling::CaseCount%4639DE8B0003.attr

      //## Attribute: ContextMonth%3F1D133E0203
      //## begin EMSBilling::ContextMonth%3F1D133E0203.attr preserve=no  private: string {U} 
      string m_strContextMonth;
      //## end EMSBilling::ContextMonth%3F1D133E0203.attr

      //## Attribute: Count%39A53D9E018A
      //## begin EMSBilling::Count%39A53D9E018A.attr preserve=no  private: int {U} 0
      int m_lCount;
      //## end EMSBilling::Count%39A53D9E018A.attr

      //## Attribute: CountTotals%4075682A02DE
      //## begin EMSBilling::CountTotals%4075682A02DE.attr preserve=no  private: int[7] {U} 
      int m_lCountTotals[7];
      //## end EMSBilling::CountTotals%4075682A02DE.attr

      //## Attribute: CurrentCASE_NO%4919DFFC033C
      //## begin EMSBilling::CurrentCASE_NO%4919DFFC033C.attr preserve=no  private: string {U} 
      string m_strCurrentCASE_NO;
      //## end EMSBilling::CurrentCASE_NO%4919DFFC033C.attr

      //## Attribute: CUST_ID%3ECC242B00DA
      //## begin EMSBilling::CUST_ID%3ECC242B00DA.attr preserve=no  private: string {U} 
      string m_strCUST_ID;
      //## end EMSBilling::CUST_ID%3ECC242B00DA.attr

      //## Attribute: CustQualID%3F0C0D8A03C8
      //## begin EMSBilling::CustQualID%3F0C0D8A03C8.attr preserve=no  private: string {U} 
      string m_strCustQualID;
      //## end EMSBilling::CustQualID%3F0C0D8A03C8.attr

      //## Attribute: DailyBilling%4173FE880128
      //## begin EMSBilling::DailyBilling%4173FE880128.attr preserve=no  private: bool {U} false
      bool m_bDailyBilling;
      //## end EMSBilling::DailyBilling%4173FE880128.attr

      //## Attribute: EMSExceptionBillingRecord%39AE61C4002F
      //## begin EMSBilling::EMSExceptionBillingRecord%39AE61C4002F.attr preserve=no  private: EMSExceptionBillingRecord {R} 0
      EMSExceptionBillingRecord *m_pEMSExceptionBillingRecord;
      //## end EMSBilling::EMSExceptionBillingRecord%39AE61C4002F.attr

      //## Attribute: EMSFraudAndFeeBillingRecord%3ED5324A0222
      //## begin EMSBilling::EMSFraudAndFeeBillingRecord%3ED5324A0222.attr preserve=no  private: EMSFraudAndFeeBillingRecord {R} 0
      EMSFraudAndFeeBillingRecord *m_pEMSFraudAndFeeBillingRecord;
      //## end EMSBilling::EMSFraudAndFeeBillingRecord%3ED5324A0222.attr

      //## Attribute: ExceptionCount%3F0EA396033C
      //## begin EMSBilling::ExceptionCount%3F0EA396033C.attr preserve=no  private: int[7][7] {V} 
      int m_lExceptionCount[15][7];
      //## end EMSBilling::ExceptionCount%3F0EA396033C.attr

      //## Attribute: First%4639DC330164
      //## begin EMSBilling::First%4639DC330164.attr preserve=no  private: bool {U} false
      bool m_bFirst;
      //## end EMSBilling::First%4639DC330164.attr

      //## Attribute: FraudFeeCount%3F0E9D31000F
      //## begin EMSBilling::FraudFeeCount%3F0E9D31000F.attr preserve=no  private: int[8] {V} 
      int m_lFraudFeeCount[8];
      //## end EMSBilling::FraudFeeCount%3F0E9D31000F.attr

      //## Attribute: INST_ID%39A53D9400C8
      //## begin EMSBilling::INST_ID%39A53D9400C8.attr preserve=no  private: string {U} 
      string m_strINST_ID;
      //## end EMSBilling::INST_ID%39A53D9400C8.attr

      //## Attribute: InstCustID%3F38FE44036B
      //## begin EMSBilling::InstCustID%3F38FE44036B.attr preserve=no  private: string {U} 
      string m_strInstCustID;
      //## end EMSBilling::InstCustID%3F38FE44036B.attr

      //## Attribute: NET_ID_EMS%3F0EA0CB006D
      //## begin EMSBilling::NET_ID_EMS%3F0EA0CB006D.attr preserve=no  private: string {V} 
      string m_strNET_ID_EMS;
      //## end EMSBilling::NET_ID_EMS%3F0EA0CB006D.attr

      //## Attribute: NextINST_ID%4639DDA003CE
      //## begin EMSBilling::NextINST_ID%4639DDA003CE.attr preserve=no  private: string {U} 
      string m_strNextINST_ID;
      //## end EMSBilling::NextINST_ID%4639DDA003CE.attr

      //## Attribute: NextNET_ID_EMS%4639DDA30083
      //## begin EMSBilling::NextNET_ID_EMS%4639DDA30083.attr preserve=no  private: string {U} 
      string m_strNextNET_ID_EMS;
      //## end EMSBilling::NextNET_ID_EMS%4639DDA30083.attr

      //## Attribute: NextPROC_ID%4639DD9E0296
      //## begin EMSBilling::NextPROC_ID%4639DD9E0296.attr preserve=no  private: string {U} 
      string m_strNextPROC_ID;
      //## end EMSBilling::NextPROC_ID%4639DD9E0296.attr

      //## Attribute: NextREQUEST_TYPE%4639DDA20083
      //## begin EMSBilling::NextREQUEST_TYPE%4639DDA20083.attr preserve=no  private: string {U} 
      string m_strNextREQUEST_TYPE;
      //## end EMSBilling::NextREQUEST_TYPE%4639DDA20083.attr

      //## Attribute: PROC_ID%39A53D8E0372
      //## begin EMSBilling::PROC_ID%39A53D8E0372.attr preserve=no  private: string {U} 
      string m_strPROC_ID;
      //## end EMSBilling::PROC_ID%39A53D8E0372.attr

      //## Attribute: Qualify%3F0C0DAB0261
      //## begin EMSBilling::Qualify%3F0C0DAB0261.attr preserve=no  private: string {U} 
      string m_strQualify;
      //## end EMSBilling::Qualify%3F0C0DAB0261.attr

      //## Attribute: Regional%3FBE1E620213
      //## begin EMSBilling::Regional%3FBE1E620213.attr preserve=no  private: bool {U} false
      bool m_bRegional;
      //## end EMSBilling::Regional%3FBE1E620213.attr

      //## Attribute: REQUEST_TYPE%3ECC1B1E036B
      //## begin EMSBilling::REQUEST_TYPE%3ECC1B1E036B.attr preserve=no  private: string {U} 
      string m_strREQUEST_TYPE;
      //## end EMSBilling::REQUEST_TYPE%3ECC1B1E036B.attr

      //## Attribute: TSTAMP_CREATED%3ECC1B7E0157
      //## begin EMSBilling::TSTAMP_CREATED%3ECC1B7E0157.attr preserve=no  private: string {U} 
      string m_strTSTAMP_CREATED;
      //## end EMSBilling::TSTAMP_CREATED%3ECC1B7E0157.attr

      //## Attribute: Count1%5AD0845D0374
      //## begin EMSBilling::Count1%5AD0845D0374.attr preserve=no  private: int {V} 0
      int m_lCount1;
      //## end EMSBilling::Count1%5AD0845D0374.attr

      //## Attribute: FEE_BILLING_CODE%5AD085540240
      //## begin EMSBilling::FEE_BILLING_CODE%5AD085540240.attr preserve=no  private: string {V} 
      string m_strFEE_BILLING_CODE;
      //## end EMSBilling::FEE_BILLING_CODE%5AD085540240.attr

      //## Attribute: STATUS%5AD084DF030B
      //## begin EMSBilling::STATUS%5AD084DF030B.attr preserve=no  private: string {V} 
      string m_strSTATUS;
      //## end EMSBilling::STATUS%5AD084DF030B.attr

      //## Attribute: VCR_IND%5AD084CE0263
      //## begin EMSBilling::VCR_IND%5AD084CE0263.attr preserve=no  private: string {V} 
      string m_strVCR_IND;
      //## end EMSBilling::VCR_IND%5AD084CE0263.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%39A533700223
      //## Role: EMSBilling::<m_hTimer>%39A533710012
      //## begin EMSBilling::<m_hTimer>%39A533710012.role preserve=no  public: timer::Timer { -> VHgN}
      timer::Timer m_hTimer;
      //## end EMSBilling::<m_hTimer>%39A533710012.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%39B5407000BD
      //## Role: EMSBilling::<m_pMemory>%39B5407100A1
      //## begin EMSBilling::<m_pMemory>%39B5407100A1.role preserve=no  public: IF::Memory { -> 2RHgN}
      IF::Memory *m_pMemory[2];
      //## end EMSBilling::<m_pMemory>%39B5407100A1.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%4919E2D2005D
      //## Role: EMSBilling::<m_hQuery>%4919E2D30186
      //## begin EMSBilling::<m_hQuery>%4919E2D30186.role preserve=no  public: reusable::Query { -> 6VHgN}
      reusable::Query m_hQuery[6];
      //## end EMSBilling::<m_hQuery>%4919E2D30186.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%4CD78A23003F
      //## Role: EMSBilling::<m_pFlatFile>%4CD78A240281
      //## begin EMSBilling::<m_pFlatFile>%4CD78A240281.role preserve=no  public: IF::FlatFile { -> 4RHgN}
      IF::FlatFile *m_pFlatFile[4];
      //## end EMSBilling::<m_pFlatFile>%4CD78A240281.role

    // Additional Implementation Declarations
      //## begin EMSBilling%39A52EAA0078.implementation preserve=yes
      map <string, string, less<string> > m_hInstitution;
      map <string, string, less<string> > m_hNetInstCode;
		map <string, string, less<string> > m_hInstProc;
      //## end EMSBilling%39A52EAA0078.implementation
};

//## begin EMSBilling%39A52EAA0078.postscript preserve=yes
//## end EMSBilling%39A52EAA0078.postscript

//## Class: EMSExceptionBillingRecord%3ED53F280203
//## Category: DataNavigator Foundation::Application::LocatorManager_CAT%354B349200A7
//## Subsystem: LM%3597EB1A028A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



struct EMSExceptionBillingRecord 
{
    // Data Members for Class Attributes

      //## Attribute: sCustomerID%3ED53F7002FD
      //## begin EMSExceptionBillingRecord::sCustomerID%3ED53F7002FD.attr preserve=no  public: char[4] {V} 
      char sCustomerID[4];
      //## end EMSExceptionBillingRecord::sCustomerID%3ED53F7002FD.attr

      //## Attribute: sProcessorID%3ED542500242
      //## begin EMSExceptionBillingRecord::sProcessorID%3ED542500242.attr preserve=no  public: char[8] {V} 
      char sProcessorID[8];
      //## end EMSExceptionBillingRecord::sProcessorID%3ED542500242.attr

      //## Attribute: sInstitutionID%3ED5427E01C5
      //## begin EMSExceptionBillingRecord::sInstitutionID%3ED5427E01C5.attr preserve=no  public: char[11] {V} 
      char sInstitutionID[11];
      //## end EMSExceptionBillingRecord::sInstitutionID%3ED5427E01C5.attr

      //## Attribute: cCaseType%3ED543740128
      //## begin EMSExceptionBillingRecord::cCaseType%3ED543740128.attr preserve=no  public: char {V} 
      char cCaseType;
      //## end EMSExceptionBillingRecord::cCaseType%3ED543740128.attr

      //## Attribute: sKeyEnteredCount%3ED543990128
      //## begin EMSExceptionBillingRecord::sKeyEnteredCount%3ED543990128.attr preserve=no  public: char[9] {V} 
      char sKeyEnteredCount[9];
      //## end EMSExceptionBillingRecord::sKeyEnteredCount%3ED543990128.attr

      //## Attribute: sRetrievalRequestCount%3ED543DC02CE
      //## begin EMSExceptionBillingRecord::sRetrievalRequestCount%3ED543DC02CE.attr preserve=no  public: char[9] {V} 
      char sRetrievalRequestCount[9];
      //## end EMSExceptionBillingRecord::sRetrievalRequestCount%3ED543DC02CE.attr

      //## Attribute: sFirstChargeBackCount%3ED543EB03D8
      //## begin EMSExceptionBillingRecord::sFirstChargeBackCount%3ED543EB03D8.attr preserve=no  public: char[9] {V} 
      char sFirstChargeBackCount[9];
      //## end EMSExceptionBillingRecord::sFirstChargeBackCount%3ED543EB03D8.attr

      //## Attribute: sRepresentmentCount%3ED544080186
      //## begin EMSExceptionBillingRecord::sRepresentmentCount%3ED544080186.attr preserve=no  public: char[9] {V} 
      char sRepresentmentCount[9];
      //## end EMSExceptionBillingRecord::sRepresentmentCount%3ED544080186.attr

      //## Attribute: sSecondChargeBackCount%3ED544160177
      //## begin EMSExceptionBillingRecord::sSecondChargeBackCount%3ED544160177.attr preserve=no  public: char[9] {V} 
      char sSecondChargeBackCount[9];
      //## end EMSExceptionBillingRecord::sSecondChargeBackCount%3ED544160177.attr

      //## Attribute: sArbitrationCount%3ED5442D00BB
      //## begin EMSExceptionBillingRecord::sArbitrationCount%3ED5442D00BB.attr preserve=no  public: char[9] {V} 
      char sArbitrationCount[9];
      //## end EMSExceptionBillingRecord::sArbitrationCount%3ED5442D00BB.attr

      //## Attribute: sCollectionCount%3ED5443A01F4
      //## begin EMSExceptionBillingRecord::sCollectionCount%3ED5443A01F4.attr preserve=no  public: char[9] {V} 
      char sCollectionCount[9];
      //## end EMSExceptionBillingRecord::sCollectionCount%3ED5443A01F4.attr

      //## Attribute: sTotalCount%441F9CDF0167
      //## begin EMSExceptionBillingRecord::sTotalCount%441F9CDF0167.attr preserve=no  public: char[9] {V} 
      char sTotalCount[9];
      //## end EMSExceptionBillingRecord::sTotalCount%441F9CDF0167.attr

  public:
  protected:
  private:
  private: //## implementation
};

//## Class: EMSFraudAndFeeBillingRecord%3ED5475C01C5
//## Category: DataNavigator Foundation::Application::LocatorManager_CAT%354B349200A7
//## Subsystem: LM%3597EB1A028A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



struct EMSFraudAndFeeBillingRecord 
{
    // Data Members for Class Attributes

      //## Attribute: sCustomerID%3ED5490303C8
      //## begin EMSFraudAndFeeBillingRecord::sCustomerID%3ED5490303C8.attr preserve=no  public: char[4] {V} 
      char sCustomerID[4];
      //## end EMSFraudAndFeeBillingRecord::sCustomerID%3ED5490303C8.attr

      //## Attribute: sProcessorID%3ED5490803A9
      //## begin EMSFraudAndFeeBillingRecord::sProcessorID%3ED5490803A9.attr preserve=no  public: char[8] {V} 
      char sProcessorID[8];
      //## end EMSFraudAndFeeBillingRecord::sProcessorID%3ED5490803A9.attr

      //## Attribute: sInstitutionID%3ED5490D0399
      //## begin EMSFraudAndFeeBillingRecord::sInstitutionID%3ED5490D0399.attr preserve=no  public: char[11] {V} 
      char sInstitutionID[11];
      //## end EMSFraudAndFeeBillingRecord::sInstitutionID%3ED5490D0399.attr

      //## Attribute: cCaseType%3ED5491100AB
      //## begin EMSFraudAndFeeBillingRecord::cCaseType%3ED5491100AB.attr preserve=no  public: char {V} 
      char cCaseType;
      //## end EMSFraudAndFeeBillingRecord::cCaseType%3ED5491100AB.attr

      //## Attribute: sCount%3ED549180109
      //## begin EMSFraudAndFeeBillingRecord::sCount%3ED549180109.attr preserve=no  public: char[9] {V} 
      char sCount[9];
      //## end EMSFraudAndFeeBillingRecord::sCount%3ED549180109.attr

  public:
  protected:
  private:
  private: //## implementation
};

//## begin module%39A530940325.epilog preserve=yes
//## end module%39A530940325.epilog


#endif
