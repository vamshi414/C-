//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4F7AC473015E.cm preserve=no
//   $Date:   May 20 2020 16:46:44  $ $Author:   e1009510  $
//   $Revision:   1.8  $
//## end module%4F7AC473015E.cm

//## begin module%4F7AC473015E.cp preserve=no
//   Copyright (c) 1997 - 2012
//   FIS
//## end module%4F7AC473015E.cp

//## Module: CXOSLM03%4F7AC473015E; Package body
//## Subsystem: LM%3597EB1A028A
//   .
//## Source file: C:\Devel\Dn\Server\Application\Lm\CXOSLM03.cpp

//## begin module%4F7AC473015E.additionalIncludes preserve=no
//## end module%4F7AC473015E.additionalIncludes

//## begin module%4F7AC473015E.includes preserve=yes
//## end module%4F7AC473015E.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSLM03_h
#include "CXODLM03.hpp"
#endif


//## begin module%4F7AC473015E.declarations preserve=no
//## end module%4F7AC473015E.declarations

//## begin module%4F7AC473015E.additionalDeclarations preserve=yes
//## end module%4F7AC473015E.additionalDeclarations


// Class TransactionHistory 

TransactionHistory::TransactionHistory()
  //## begin TransactionHistory::TransactionHistory%4F7ABCA101C3_const.hasinit preserve=no
  //## end TransactionHistory::TransactionHistory%4F7ABCA101C3_const.hasinit
  //## begin TransactionHistory::TransactionHistory%4F7ABCA101C3_const.initialization preserve=yes
  //## end TransactionHistory::TransactionHistory%4F7ABCA101C3_const.initialization
{
  //## begin TransactionHistory::TransactionHistory%4F7ABCA101C3_const.body preserve=yes
   memcpy(m_sID,"LM03",4);
   m_hQuery.attach(this);
   MidnightAlarm::instance()->attach(this);
  //## end TransactionHistory::TransactionHistory%4F7ABCA101C3_const.body
}


TransactionHistory::~TransactionHistory()
{
  //## begin TransactionHistory::~TransactionHistory%4F7ABCA101C3_dest.body preserve=yes
  //## end TransactionHistory::~TransactionHistory%4F7ABCA101C3_dest.body
}



//## Other Operations (implementation)
void TransactionHistory::getTransactions (const string& strCONTEXT_KEY, const string& strCONTEXT_DATA)
{
  //## begin TransactionHistory::getTransactions%4F7ABEA200CF.body preserve=yes
   if(strCONTEXT_DATA.substr(0,16) == strCONTEXT_DATA.substr(17,16))
      return;
   m_strBeginDate.assign(strCONTEXT_DATA,0,16);
   m_strEndDate.assign(strCONTEXT_DATA,17,16);
   Date hDate(m_strBeginDate.c_str());
   string strLocator, strInstID; 
   strInstID.assign(strCONTEXT_KEY,8,strCONTEXT_KEY.npos);

   GlobalContext hGlobalContext("##BEGIN");
   if (!hGlobalContext.get(strLocator,'F'))
      return;
   if(strLocator.length()>=6)
      if(m_strBeginDate.substr(0,6) < strLocator.substr(0,6))
         m_strBeginDate = strLocator + "0100000000";

   Date hBeginDate(m_strBeginDate.substr(0,8).c_str());

   if((hBeginDate+1).getDay() == 1)
      hBeginDate+=1;

   strLocator.assign(hBeginDate.asString("%Y%m%d"),0,6);

   Date hEndDate(m_strEndDate.substr(0,8).c_str());   
   hDate = hBeginDate;
   string strTempBegDate = hDate.asString("%Y%m%d")+"23595999";
   if (hDate.getDay() == 1)
      strTempBegDate = hDate.asString("%Y%m%d")+ "00000000";

   if((hDate+10) <= hEndDate)
      hEndDate = hDate + 10;
   if(hEndDate.getMonth() != hDate.getMonth())
   {
      Date tempDate(hEndDate.getYear(),hEndDate.getMonth(),1);
      hEndDate = tempDate - 1;
   }
      
   Job::submit("##UDHIST","&INSTID ",strInstID.c_str(),"&YYYYMM ",strLocator.c_str(),"&BDATE  ",strTempBegDate.c_str(),"&EDATE  ",(hEndDate.asString("%Y%m%d")).c_str());
   
  //## end TransactionHistory::getTransactions%4F7ABEA200CF.body
}

void TransactionHistory::inspectTaskContext ()
{
  //## begin TransactionHistory::inspectTaskContext%4F9508A0010C.body preserve=yes
   m_hQuery.reset();
   m_hQuery.bind("TASK_CONTEXT","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA);
   m_hQuery.bind("TASK_CONTEXT","CONTEXT_KEY",Column::STRING,&m_strCONTEXT_KEY);
   m_hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_KEY","LIKE","TRANHIST%");
   m_hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","=",(Application::instance()->name()).c_str());
   m_hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","F");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   pSelectStatement->execute(m_hQuery);
  //## end TransactionHistory::inspectTaskContext%4F9508A0010C.body
}

void TransactionHistory::processTransactions ()
{
  //## begin TransactionHistory::processTransactions%4F86EEC50331.body preserve=yes
   m_hQuery.setIndex(1);
   inspectTaskContext();
  //## end TransactionHistory::processTransactions%4F86EEC50331.body
}

void TransactionHistory::reset (const string& strInstId, const string& strEndDate, bool bResponse)
{
  //## begin TransactionHistory::reset%4F7ABE8400C0.body preserve=yes
   m_strCONTEXT_KEY = "TRANHIST";
   m_strCONTEXT_KEY.append(strInstId);
   string strTempContextData;
   Context hContext(Application::instance()->image(),Application::instance()->name());
   
   if(bResponse == true)
   {
      if (!hContext.get(m_strCONTEXT_KEY.c_str(),m_strCONTEXT_DATA,'F'))
         return;
      strTempContextData.assign(strEndDate,0,8);
      strTempContextData.append("23595999:");
      strTempContextData.append(m_strCONTEXT_DATA.data() + 17,16);
      saveContext(m_strCONTEXT_KEY.c_str(),strTempContextData.c_str());
      getTransactions(m_strCONTEXT_KEY,strTempContextData);
   }
   else
   {
      Date hDate;
      int iDD = hDate.daysInMonth(atoi(strEndDate.substr(0,4).c_str()),atoi(strEndDate.substr(4,2).c_str()));
      char szBuffer[3];
      snprintf(szBuffer,sizeof(szBuffer),"%02d",iDD);
      string strEndDateTemp = strEndDate+szBuffer;   
      hDate = Date::today();
      if (strEndDateTemp > hDate.asString("%Y%m%d"))
         strEndDateTemp = hDate.asString("%Y%m%d");
      hContext.get(m_strCONTEXT_KEY.c_str(),m_strCONTEXT_DATA,'F');
      if (m_strCONTEXT_DATA.length() >= 32)
      {
         m_strBeginDate.assign(m_strCONTEXT_DATA,0,8);
         m_strEndDate.assign(m_strCONTEXT_DATA,17,8);
         if(strEndDateTemp > m_strBeginDate)               
         {
            strTempContextData.assign(m_strCONTEXT_DATA,0,16);
            strTempContextData += ":" + strEndDateTemp + "23595999";
            getTransactions(m_strCONTEXT_KEY,strTempContextData);
         }
         else
            return;
      }
      else
      {
         string strLocator;
         GlobalContext hGlobalContext("##BEGIN");
         if (!hGlobalContext.get(strLocator,'F'))
            return;
         if (strLocator > strEndDate.substr(0,6))
            return;
         m_strBeginDate = strLocator + "0100000000";
         m_strCONTEXT_KEY = "TRANHIST"+strInstId;
         hDate = Date::today();
         strTempContextData.assign(m_strBeginDate);
         if(strEndDateTemp > hDate.asString("%Y%m%d"))
            strTempContextData += ":" + hDate.asString("%Y%m%d") + "23595999";
         else 
            strTempContextData += ":" + strEndDateTemp + "23595999";
         getTransactions(m_strCONTEXT_KEY,strTempContextData);       
      }
      saveContext(m_strCONTEXT_KEY.c_str(),strTempContextData.c_str());
   }
  //## end TransactionHistory::reset%4F7ABE8400C0.body
}

void TransactionHistory::saveContext (const char* pszKey, const char* pszData)
{
  //## begin TransactionHistory::saveContext%4F7ABF4200FA.body preserve=yes
   Context hContext(Application::instance()->image(),Application::instance()->name());
   if(hContext.put(pszKey,pszData,'F'))
      Database::instance()->commit();

  //## end TransactionHistory::saveContext%4F7ABF4200FA.body
}

void TransactionHistory::update (Subject* pSubject)
{
  //## begin TransactionHistory::update%4F7D959900D2.body preserve=yes
   if (pSubject == MidnightAlarm::instance())
   {
      m_hQuery.setIndex(2);
      inspectTaskContext();
      Database::instance()->commit();
      return;
   }
   if (pSubject == &m_hQuery)
   {
      if(m_strCONTEXT_DATA.length()>=32)
         if(m_strCONTEXT_DATA.substr(0,16)!= m_strCONTEXT_DATA.substr(17,16))
            if(m_hQuery.getIndex() == 1)
               getTransactions(m_strCONTEXT_KEY,m_strCONTEXT_DATA);
            else
               Console::display("ST610",(m_strCONTEXT_KEY.substr(8,m_strCONTEXT_KEY.npos)).c_str());
      return;
   }
  //## end TransactionHistory::update%4F7D959900D2.body
}

// Additional Declarations
  //## begin TransactionHistory%4F7ABCA101C3.declarations preserve=yes
  //## end TransactionHistory%4F7ABCA101C3.declarations

//## begin module%4F7AC473015E.epilog preserve=yes
//## end module%4F7AC473015E.epilog
