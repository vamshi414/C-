//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%601A3601013B.cm preserve=no
//## end module%601A3601013B.cm

//## begin module%601A3601013B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%601A3601013B.cp

//## Module: CXOSLM06%601A3601013B; Package specification
//## Subsystem: LM%3597EB1A028A
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Lm\CXODLM06.hpp

#ifndef CXOSLM06_h
#define CXOSLM06_h 1

//## begin module%601A3601013B.additionalIncludes preserve=no
//## end module%601A3601013B.additionalIncludes

//## begin module%601A3601013B.includes preserve=yes
//## end module%601A3601013B.includes

#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif

//## Modelname: Totals Management::ManagementInformation_CAT%440DDD48031C
namespace managementinformation {
class QMRReport;
} // namespace managementinformation

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
class QMRIssuers;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%601A3601013B.declarations preserve=no
//## end module%601A3601013B.declarations

//## begin module%601A3601013B.additionalDeclarations preserve=yes
//## end module%601A3601013B.additionalDeclarations


//## begin QMRAcquirerBin%601A378603CD.preface preserve=yes
//## end QMRAcquirerBin%601A378603CD.preface

//## Class: QMRAcquirerBin%601A378603CD
//## Category: DataNavigator Foundation::Application::LocatorManager_CAT%354B349200A7
//## Subsystem: LM%3597EB1A028A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%601A38F30207;process::Application { -> F}
//## Uses: <unnamed>%601A39C4025D;reusable::Statement { -> F}
//## Uses: <unnamed>%601A39EC00B4;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%601A4D40016E;database::Database { -> F}
//## Uses: <unnamed>%601A4D6701A4;timer::Clock { -> F}
//## Uses: <unnamed>%601A5AE301FA;entitysegment::Customer { -> F}
//## Uses: <unnamed>%601AB682020F;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%602262D8008D;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%602263B0024C;reusable::Query { -> F}
//## Uses: <unnamed>%60379CFA0298;monitor::UseCase { -> F}
//## Uses: <unnamed>%60EECD4003A1;IF::Trace { -> F}
//## Uses: <unnamed>%60EED90003D6;timer::Date { -> F}
//## Uses: <unnamed>%60EEDA040184;reusable::Buffer { -> F}
//## Uses: <unnamed>%6118EC1600F3;configuration::QMRIssuers { -> F}
//## Uses: <unnamed>%61A4D69603B4;database::GlobalContext { -> F}
//## Uses: <unnamed>%652D22D402F8;managementinformation::QMRReport { -> F}

class DllExport QMRAcquirerBin : public database::GenerationDataGroup  //## Inherits: <unnamed>%601A3829025E
{
  //## begin QMRAcquirerBin%601A378603CD.initialDeclarations preserve=yes
  //## end QMRAcquirerBin%601A378603CD.initialDeclarations

  public:
    //## Constructors (generated)
      QMRAcquirerBin();

    //## Destructor (generated)
      virtual ~QMRAcquirerBin();


    //## Other Operations (specified)
      //## Operation: deleteBins%659BD63201CA
      bool deleteBins ();

      //## Operation: getCheckDigit%612EE9C50332
      char getCheckDigit (const string& strINST_ID);

      //## Operation: import%601A37E0015A
      bool import ();

      //## Operation: updateLogo%62315BA601EF
      bool updateLogo ();

    // Additional Public Declarations
      //## begin QMRAcquirerBin%601A378603CD.public preserve=yes
      //## end QMRAcquirerBin%601A378603CD.public

  protected:
    // Additional Protected Declarations
      //## begin QMRAcquirerBin%601A378603CD.protected preserve=yes
      //## end QMRAcquirerBin%601A378603CD.protected

  private:
    // Additional Private Declarations
      //## begin QMRAcquirerBin%601A378603CD.private preserve=yes
      //## end QMRAcquirerBin%601A378603CD.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: File%62315DAA028C
      //## begin QMRAcquirerBin::File%62315DAA028C.attr preserve=no  public: string {U} 
      string m_strFile;
      //## end QMRAcquirerBin::File%62315DAA028C.attr

      //## Attribute: LogoIDs%6118EB93025B
      //## begin QMRAcquirerBin::LogoIDs%6118EB93025B.attr preserve=no  public: map<string,pair<string,string>,less<string> > {U} 
      map<string,pair<string,string>,less<string> > m_hLogoIDs;
      //## end QMRAcquirerBin::LogoIDs%6118EB93025B.attr

      //## Attribute: YYYYMMDD%60EECB88035C
      //## begin QMRAcquirerBin::YYYYMMDD%60EECB88035C.attr preserve=no  public: string {U} 
      string m_strYYYYMMDD;
      //## end QMRAcquirerBin::YYYYMMDD%60EECB88035C.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%601A453700EE
      //## Role: QMRAcquirerBin::<m_hTable>%601A45380135
      //## begin QMRAcquirerBin::<m_hTable>%601A45380135.role preserve=no  public: reusable::Table { -> VHgN}
      reusable::Table m_hTable;
      //## end QMRAcquirerBin::<m_hTable>%601A45380135.role

    // Additional Implementation Declarations
      //## begin QMRAcquirerBin%601A378603CD.implementation preserve=yes
      string m_strCONTEXT_DATA;
      //## end QMRAcquirerBin%601A378603CD.implementation
};

//## begin QMRAcquirerBin%601A378603CD.postscript preserve=yes
//## end QMRAcquirerBin%601A378603CD.postscript

//## begin module%601A3601013B.epilog preserve=yes
//## end module%601A3601013B.epilog


#endif
