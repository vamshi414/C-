//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%60229B1C03BE.cm preserve=no
//## end module%60229B1C03BE.cm

//## begin module%60229B1C03BE.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%60229B1C03BE.cp

//## Module: CXOSLM07%60229B1C03BE; Package body
//## Subsystem: LM%3597EB1A028A
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Lm\CXOSLM07.cpp

//## begin module%60229B1C03BE.additionalIncludes preserve=no
//## end module%60229B1C03BE.additionalIncludes

//## begin module%60229B1C03BE.includes preserve=yes
#define STS_DUPLICATE_RECORD 35
#include "CXODIF16.hpp"
#include <algorithm>
//## end module%60229B1C03BE.includes

#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSLM07_h
#include "CXODLM07.hpp"
#endif


//## begin module%60229B1C03BE.declarations preserve=no
//## end module%60229B1C03BE.declarations

//## begin module%60229B1C03BE.additionalDeclarations preserve=yes
//## end module%60229B1C03BE.additionalDeclarations


// Class QMRDeviceFile 

QMRDeviceFile::QMRDeviceFile()
  //## begin QMRDeviceFile::QMRDeviceFile%6529159F027A_const.hasinit preserve=no
  //## end QMRDeviceFile::QMRDeviceFile%6529159F027A_const.hasinit
  //## begin QMRDeviceFile::QMRDeviceFile%6529159F027A_const.initialization preserve=yes
   : GenerationDataGroup(Application::instance()->image(), Application::instance()->name(), "QMRDEV")
  //## end QMRDeviceFile::QMRDeviceFile%6529159F027A_const.initialization
{
  //## begin QMRDeviceFile::QMRDeviceFile%6529159F027A_const.body preserve=yes
   memcpy(m_sID,"LM07",4);
   m_hNetworks.insert(multimap<string, string, less<string> >::value_type("CIRR", "CIRRUS"));
   m_hNetworks.insert(multimap<string, string, less<string> >::value_type("CIRR", "CIRRINT"));
   m_hNetworks.insert(multimap<string, string, less<string> >::value_type("CIRR", "CR1E"));
   m_hNetworks.insert(multimap<string, string, less<string> >::value_type("CIRR", "CRA1"));
   m_hNetworks.insert(multimap<string, string, less<string> >::value_type("MCI", "MCATM"));
   m_hNetworks.insert(multimap<string, string, less<string> >::value_type("MCI", "MCINT"));
   m_hNetworks.insert(multimap<string, string, less<string> >::value_type("MAP", "MUSA"));
   m_hNetworks.insert(multimap<string, string, less<string> >::value_type("MAP", "MUSA1"));
   m_hNetworks.insert(multimap<string, string, less<string> >::value_type("PLS", "PLUS"));
  //## end QMRDeviceFile::QMRDeviceFile%6529159F027A_const.body
}


QMRDeviceFile::~QMRDeviceFile()
{
  //## begin QMRDeviceFile::~QMRDeviceFile%6529159F027A_dest.body preserve=yes
  //## end QMRDeviceFile::~QMRDeviceFile%6529159F027A_dest.body
}



//## Other Operations (implementation)
bool QMRDeviceFile::getLogo (const string& strNetwork, const string& strBuffer)
{
  //## begin QMRDeviceFile::getLogo%6529178E020A.body preserve=yes
   pair<multimap<string, string, less<string> >::iterator, multimap<string, string, less<string> >::iterator > hRange;
   multimap<string, string, less<string> >::iterator pRange;
   hRange = m_hNetworks.equal_range(strNetwork);
   for (pRange = hRange.first; pRange != hRange.second; ++pRange)
   {
      if (strBuffer.find((*pRange).second) != string::npos)
         return true;
   }
   return false;
  //## end QMRDeviceFile::getLogo%6529178E020A.body
}

bool QMRDeviceFile::import ()
{
  //## begin QMRDeviceFile::import%652917EB019C.body preserve=yes
   if (!open())
      return false;
   UseCase hUseCase("DR", "## DR106 LOAD ATM LOGO TABLE");
   size_t n = 0;
#ifdef MVS
   Date hDate(Date::today());
   m_strYYYYMMDD.assign(hDate.asString("%Y%m%d"));
#else
   if (!(((n = datasetName().find(".D",0,2)) != string::npos
      || (n = datasetName().find(".M",0,2)) != string::npos)
      && datasetName().length() > n + 8))
   {
      Trace::put("Missing Date(.DYYMMDD/.MYYMMDD) in FileName : ",datasetName());
      close();
      return false;
   }
   m_strYYYYMMDD.assign(Clock::instance()->getDate().c_str(),2);
   m_strYYYYMMDD.append(datasetName().c_str() + n + 2,6);
#endif
   char sBuffer[1024];
   string strBuffer,strTemp;
   auto_ptr<SelectStatement> pDeleteStatment((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   Query hQuery;
   hQuery.setQualifier("QUALIFY", "QMR_DEVICE_LOGO");
   hQuery.setBasicPredicate("QMR_DEVICE_LOGO", "CUST_ID", "=", Customer::instance()->getCUST_ID().c_str());
   if (pDeleteStatment->execute(hQuery) == false)
   {
      close();
      return UseCase::setSuccess(false);
   }
   auto_ptr<Statement> pInsertStatment((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   auto_ptr<Statement> pUpdateStatment((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   while (read(sBuffer, 1024, &n))
   {
      strBuffer.assign(sBuffer, n);
      if (!ConfigurationRepository::instance()->translate("DEVICE",strBuffer.substr(0,8),strTemp,"","",-1,false))
         continue;
      m_hTable.reset();
      m_hTable.setQualifier("QUALIFY");
      m_hTable.setName("QMR_DEVICE_LOGO");
      m_hTable.set("DEVICE_ID",strBuffer.substr(0,8),false,true);
      m_hTable.set("DEVICE_STAT", " ",false,true);
      m_hTable.set("CIRRUS_LOGO", getLogo("CIRR",strBuffer) ? "Y" : "N");
      m_hTable.set("MASTERCARD_LOGO", getLogo("MCI",strBuffer) ? "Y":"N");
      m_hTable.set("MAESTRO_LOGO", getLogo("MAP",strBuffer) ? "Y": "N");
      m_hTable.set("PLUS_LOGO", getLogo("PLS",strBuffer) ? "Y" : "N");
      m_hTable.set("CUST_ID", Customer::instance()->getCUST_ID(), false, true);
      m_hTable.set("CUST_STAT", " ", false, true);
      m_hTable.set("CC_STATE", "A");
      m_hTable.set("CC_USER_ID", "SYSTEM");
      m_hTable.set("CC_LAST_OPERATION", "INS");
      m_hTable.set("CC_TSTAMP_CHANGE", Clock::instance()->getYYYYMMDDHHMMSS());
      if (pInsertStatment->execute(m_hTable) == false)
      {
         if (!(pInsertStatment->getInfoIDNumber() == STS_DUPLICATE_RECORD
            && pUpdateStatment->execute(m_hTable)))
         {
            close();
            Database::instance()->rollback();
            return UseCase::setSuccess(false);
         }
      }
      UseCase::addItem();
   }
   commit();
   Database::instance()->commit();
   return true;
  //## end QMRDeviceFile::import%652917EB019C.body
}

// Additional Declarations
  //## begin QMRDeviceFile%6529159F027A.declarations preserve=yes
  //## end QMRDeviceFile%6529159F027A.declarations

//## begin module%60229B1C03BE.epilog preserve=yes
//## end module%60229B1C03BE.epilog
