//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%601A3603033B.cm preserve=no
//## end module%601A3603033B.cm

//## begin module%601A3603033B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%601A3603033B.cp

//## Module: CXOSLM06%601A3603033B; Package body
//## Subsystem: LM%3597EB1A028A
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Lm\CXOSLM06.cpp

//## begin module%601A3603033B.additionalIncludes preserve=no
//## end module%601A3603033B.additionalIncludes

//## begin module%601A3603033B.includes preserve=yes
#define STS_DUPLICATE_RECORD 35
#define STS_RECORD_NOT_FOUND 14
#define VISABIN_REC_LEN 133
#include "CXODIF16.hpp"
#include "CXODRU28.hpp"
#include "CXODRU19.hpp"
#include <algorithm>
//## end module%601A3603033B.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSCFC0_h
#include "CXODCFC0.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSMG39_h
#include "CXODMG39.hpp"
#endif
#ifndef CXOSLM06_h
#include "CXODLM06.hpp"
#endif


//## begin module%601A3603033B.declarations preserve=no
//## end module%601A3603033B.declarations

//## begin module%601A3603033B.additionalDeclarations preserve=yes
static const int iDigit[8] = { 3,7,1,3,7,1,3,7 };
//## end module%601A3603033B.additionalDeclarations


// Class QMRAcquirerBin 

QMRAcquirerBin::QMRAcquirerBin()
  //## begin QMRAcquirerBin::QMRAcquirerBin%601A378603CD_const.hasinit preserve=no
  //## end QMRAcquirerBin::QMRAcquirerBin%601A378603CD_const.hasinit
  //## begin QMRAcquirerBin::QMRAcquirerBin%601A378603CD_const.initialization preserve=yes
  : GenerationDataGroup(Application::instance()->image(), Application::instance()->name(), "QMRACQ")
  //## end QMRAcquirerBin::QMRAcquirerBin%601A378603CD_const.initialization
{
  //## begin QMRAcquirerBin::QMRAcquirerBin%601A378603CD_const.body preserve=yes
   memcpy(m_sID,"LM06",4);
   m_strCONTEXT_DATA.assign("QMRACQVISA:N~QMRACQMC:N");
   m_hLogoIDs.insert(map<string,pair<string,string>,less<string> >::value_type("V",make_pair("VISA_LOGO","YNN")));
   m_hLogoIDs.insert(map<string,pair<string,string>,less<string> >::value_type("I",make_pair("INTERLINK_LOGO","NYN")));
   m_hLogoIDs.insert(map<string,pair<string,string>,less<string> >::value_type("P",make_pair("PLUS_LOGO","NNY")));
   m_hLogoIDs.insert(map<string,pair<string,string>,less<string> >::value_type("B",make_pair("VISA_LOGO,INTERLINK_LOGO","YYN")));
   m_hLogoIDs.insert(map<string,pair<string,string>,less<string> >::value_type("D",make_pair("VISA_LOGO,PLUS_LOGO","YNY")));
   m_hLogoIDs.insert(map<string,pair<string,string>,less<string> >::value_type("E",make_pair("VISA_LOGO,INTERLINK_LOGO,PLUS_LOGO","YYY")));
   m_hLogoIDs.insert(map<string,pair<string,string>,less<string> >::value_type("L",make_pair("INTERLINK_LOGO,PLUS_LOGO","NYY")));
   ConfigurationRepository::instance()->setEvidence(false);
  //## end QMRAcquirerBin::QMRAcquirerBin%601A378603CD_const.body
}


QMRAcquirerBin::~QMRAcquirerBin()
{
  //## begin QMRAcquirerBin::~QMRAcquirerBin%601A378603CD_dest.body preserve=yes
  //## end QMRAcquirerBin::~QMRAcquirerBin%601A378603CD_dest.body
}



//## Other Operations (implementation)
bool QMRAcquirerBin::deleteBins ()
{
  //## begin QMRAcquirerBin::deleteBins%659BD63201CA.body preserve=yes
   if (m_strFile != "QMRACQVISA" && m_strFile != "QMRACQMC")
      return true;
   string strPredicate;
   Query hSubQuery;
   hSubQuery.setSubSelect(true);
   hSubQuery.setQualifier("QUALIFY","QMR_ACQUIRER_BIN A");
   hSubQuery.setQualifier("QUALIFY","QMR_ACQUIRER_BIN B");
   hSubQuery.setQualifier("QUALIFY","QMR_BIN Q");
   hSubQuery.join("QMR_ACQUIRER_BIN A","INNER","QMR_ACQUIRER_BIN B","SUBSTR(BIN,1,6)","SUBSTR(BIN,1,6)");
   hSubQuery.join("QMR_ACQUIRER_BIN A","INNER","QMR_BIN Q","SUBSTR(BIN,1,6)","SUBSTR(BIN,1,6)");
   hSubQuery.bind("QMR_ACQUIRER_BIN A","BIN", Column::STRING,0);
   hSubQuery.setBasicPredicate("QMR_ACQUIRER_BIN A","CUST_ID", "=",Customer::instance()->getCUST_ID().c_str());
   hSubQuery.setBasicPredicate("QMR_BIN Q","CUST_ID","=",Customer::instance()->getCUST_ID().c_str());
   hSubQuery.setBasicPredicate("QMR_BIN Q","NETWORK_ID","=","MCI");
   hSubQuery.setBasicPredicate("QMR_ACQUIRER_BIN A","NETWORK_ID","!=","VNT");
   auto_ptr<FormatSelectVisitor>pFormatSelectVisitor((FormatSelectVisitor*)DatabaseFactory::instance()->create("FormatSelectVisitor"));
   hSubQuery.accept(*pFormatSelectVisitor);
   strPredicate = "(" + pFormatSelectVisitor->SQLText() + ")";
   Query hQuery;
   hQuery.setQualifier("QUALIFY","QMR_ACQUIRER_BIN");
   hQuery.setBasicPredicate("QMR_ACQUIRER_BIN","CUST_ID","=",Customer::instance()->getCUST_ID().c_str());
   hQuery.setBasicPredicate("QMR_ACQUIRER_BIN","NETWORK_ID","=","VNT");
   hQuery.setBasicPredicate("QMR_ACQUIRER_BIN","BIN","IN",strPredicate.c_str());
   auto_ptr<SelectStatement> pDeleteStatment((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   if (pDeleteStatment->execute(hQuery) == false)
   {
     close();
     return UseCase::setSuccess(false);
   }
   return true;
  //## end QMRAcquirerBin::deleteBins%659BD63201CA.body
}

char QMRAcquirerBin::getCheckDigit (const string& strINST_ID)
{
  //## begin QMRAcquirerBin::getCheckDigit%612EE9C50332.body preserve=yes
   int iCheckDigit = 0;
   for (int i = 0;i < strINST_ID.length();i++)
      iCheckDigit += (strINST_ID[i] - '0') * iDigit[i];
   iCheckDigit %= 10;
   return '0' + ((iCheckDigit == 0) ? iCheckDigit : (10 - iCheckDigit));
  //## end QMRAcquirerBin::getCheckDigit%612EE9C50332.body
}

bool QMRAcquirerBin::import ()
{
  //## begin QMRAcquirerBin::import%601A37E0015A.body preserve=yes
   bool bDuplicate = false;
   if (open(FlatFile::CX_OPEN_INPUT,&bDuplicate) == false
      && bDuplicate == false)
      return false;
   UseCase hUseCase("DR", "## DR105 LOAD QMR ACQUIRER TABLE");
   m_strFile.erase();
   size_t n = 0;
#ifdef MVS
   Date hDate(Date::today());
   m_strYYYYMMDD.assign(hDate.asString("%y%m%d"));
#else
   if (!(((n = datasetName().find(".D",0,2)) != string::npos
      || (n = datasetName().find(".M",0,2)) != string::npos)
      && datasetName().length() > n + 8))
   {
      Trace::put("Missing Date(.DYYMMDD/.MYYMMDD) in FileName : ",datasetName());
      close();
      return false;
   }
   size_t pos = 0;
   if ((pos = datasetName().find("QMRACQMC")) != string::npos
      || (pos = datasetName().find("QMRACQVISA")) != string::npos
      || (pos = datasetName().find("QMRACQVRID")) != string::npos)
      m_strFile.assign(datasetName().c_str() + pos,n - pos);
   m_strYYYYMMDD.assign(Clock::instance()->getDate().c_str(),2);
   m_strYYYYMMDD.append(datasetName().c_str() + n + 2,6);
   if (m_strFile == "QMRACQVRID")
      m_strCONTEXT_DATA.assign("VC690:N~COMBINED:N~LOGO:N~CIMS:N~QMRACQVRID:N");
#endif
   if (bDuplicate)
   {
      if (managementinformation::QMRReport::progressUpdate(m_strFile,m_strYYYYMMDD,m_strCONTEXT_DATA) == false)
         return false;
      Database::instance()->commit();
      return true;
   }
   char sBuffer[256];
   string strBuffer;
   string strTemp;
   string strBIN,strBIN_TYPE,strNETWORK_ID;
   int iBinLength = 0;
   auto_ptr<Statement> pInsertStatment((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   auto_ptr<Statement> pUpdateStatment((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   string strFirst("QMR_BIN_TYPE   ");
   string strKey;
   bool bUpdate(false);
   char szLogo[4] = {"   "};
   map<string,pair<string,string>,less<string> >::iterator pConfig;
   while (read(sBuffer,256,&n))
   {
      strBuffer.assign(sBuffer, n);
      if (memcmp(sBuffer,"FIT",3) == 0)
      {
         if (m_strFile.empty())
            m_strFile.assign("QMRACQMC",8);
         if (strBuffer.length() >= 4)
         {
            if (memcmp(strBuffer.data(), "FITD", 4) == 0 &&
               n >= 42)
               memcpy_s(szLogo,sizeof(szLogo),strBuffer.data() + 39,3);
            else if (memcmp(strBuffer.data(), "FIT1", 4) == 0
               && n >= 20)
            {
               strTemp.assign(strBuffer.data() + 4,2);
               strBIN.assign(strBuffer.substr(6,atoi(strTemp.c_str())));
               trim(strBIN);
               strNETWORK_ID = (szLogo[1] == 'Y') ? "MCI" : "CRS";
               if (strNETWORK_ID == "CRS" &&
                  szLogo[2] == 'Y')
                  strNETWORK_ID = "MAP";
               strFirst.resize(15);
               strFirst.append(strBuffer.data() + 17, 3);
               if (ConfigurationRepository::instance()->translate("X_GENERIC",strFirst,strBIN_TYPE," "," ",-1,false) == false)
                  strBIN_TYPE.assign("D",1);
               strBIN_TYPE.resize(1);
               strKey.assign("   ",3);
               strKey.append(1,szLogo[2]);
               strKey.append(1,szLogo[1]);
               strKey.append(1,szLogo[0]);
               strKey.append("NNN",3);
               strKey.append(strBIN_TYPE);
               bUpdate = false;
               if (ConfigurationRepository::instance()->translate("QMR_ACQUIRER_BIN",strBIN,strTemp," "," ",0,false))
               {
                  bUpdate = (strNETWORK_ID == strTemp);
                  if (bUpdate && ConfigurationRepository::instance()->getThird() == strKey)
                     continue;
               }
               m_hTable.reset();
               m_hTable.setQualifier("QUALIFY");
               m_hTable.setName("QMR_ACQUIRER_BIN");
               m_hTable.set("BIN",strBIN,false,true);
               m_hTable.set("CUST_ID", Customer::instance()->getCUST_ID(), false, true);
               m_hTable.set("CUST_STAT", " ", false, true);
               m_hTable.set("NETWORK_ID", strNETWORK_ID, false, true);
               strTemp.assign(szLogo, 1);
               m_hTable.set("CIRRUS_LOGO", strTemp);
               strTemp.assign(szLogo + 1, 1);
               m_hTable.set("MASTERCARD_LOGO", strTemp);
               strTemp.assign(szLogo + 2, 1);
               m_hTable.set("MAESTRO_LOGO", strTemp);
               m_hTable.set("VISA_LOGO","N");
               m_hTable.set("INTERLINK_LOGO","N");
               m_hTable.set("PLUS_LOGO","N");
               m_hTable.set("CARD_BRAND", " ");
               m_hTable.set("BIN_TYPE",strBIN_TYPE);
               m_hTable.set("CC_STATE", "A");
               m_hTable.set("CC_USER_ID", "SYSTEM");
               m_hTable.set("CC_TSTAMP_CHANGE", Clock::instance()->getYYYYMMDDHHMMSS());
               if (bUpdate)
               {
                  m_hTable.set("CC_LAST_OPERATION","UPD");
                  bUpdate = pUpdateStatment->execute(m_hTable);
               }
               else
               {
                  m_hTable.set("CC_LAST_OPERATION","INS");
                  bUpdate = pInsertStatment->execute(m_hTable) || (pInsertStatment->getInfoIDNumber() == STS_DUPLICATE_RECORD
                     && pUpdateStatment->execute(m_hTable));
               }
               if (!bUpdate)
               {
                  close();
                  Database::instance()->rollback();
                  return UseCase::setSuccess(false);
               }
               UseCase::addItem();
            }
         }
      }
      else
      if (n == VISABIN_REC_LEN)
      {
         if (m_strFile.empty())
            m_strFile.assign("QMRACQVISA",10);
         if (strBuffer.find("HEADER") != string::npos || strBuffer.find("TRAILER") != string::npos)
            continue;
         for (int i = 0;i < 3;i++)
         {
            iBinLength = atoi(strBuffer.substr((2 + (i*40)),2).c_str());
            iBinLength = (iBinLength > 11) ? 11 : iBinLength;
            if (iBinLength == 0)
               continue;
            strBIN.assign(strBuffer.c_str() + (4 + (i*40)),iBinLength);
            strFirst.assign("QMR_BIN_TYPE   ",15);
            strFirst.append(strBuffer.c_str() + 19 + (i*40),1);
            if (ConfigurationRepository::instance()->translate("X_GENERIC",strFirst,strBIN_TYPE," ", " ",-1,false) == false)
               strBIN_TYPE.assign(1,'D');
            strKey.assign(strBIN);
            //Update QMR_BIN Bin Type for Visa Bins
            while (strKey.length() >= 6 && QMRIssuers::verifyBin(strKey,iBinLength))
            {
               strKey.assign(strKey.c_str(),iBinLength);
               m_hTable.reset();
               m_hTable.setName("QMR_BIN");
               m_hTable.setQualifier("QUALIFY");
               m_hTable.set("BIN",strKey,false,true);
               m_hTable.set("BIN_TYPE",strBIN_TYPE);
               m_hTable.set("CC_LAST_OPERATION","UPD");
               m_hTable.set("CC_TSTAMP_CHANGE",Clock::instance()->getYYYYMMDDHHMMSS());
               if (pUpdateStatment->execute(m_hTable) == false
                   && pUpdateStatment->getInfoIDNumber() != STS_RECORD_NOT_FOUND)
               {
                  close();
                  Database::instance()->rollback();
                  return UseCase::setSuccess(false);
               }
               strKey.resize(strKey.length() - 1);
            }
            strKey.assign("   ",3);
            strKey.append("NNN",3);
            strTemp.assign(strBuffer.c_str() + 22 + (i * 40),1);
            pConfig = m_hLogoIDs.find(strTemp);
            if (pConfig == m_hLogoIDs.end())
               continue;
            strKey.append((*pConfig).second.second);
            strKey.append(strBIN_TYPE);
            bUpdate = false;
            if (ConfigurationRepository::instance()->translate("QMR_ACQUIRER_BIN",strBIN,strTemp," "," ", 0,false))
            {
               bUpdate = (strTemp == "VNT");
               if (bUpdate && ConfigurationRepository::instance()->getThird() == strKey)
                  continue;
            }
            m_hTable.reset();
            m_hTable.setQualifier("QUALIFY");
            m_hTable.setName("QMR_ACQUIRER_BIN");
            m_hTable.set("BIN",strBIN,false,true);
            m_hTable.set("NETWORK_ID","VNT",false,true);
            m_hTable.set("CUST_ID",Customer::instance()->getCUST_ID(),false,true);
            m_hTable.set("CUST_STAT"," ",false,true);
            m_hTable.set("CARD_BRAND"," ");
            m_hTable.set("CIRRUS_LOGO","N");
            m_hTable.set("MASTERCARD_LOGO","N");
            m_hTable.set("MAESTRO_LOGO","N");
            m_hTable.set("VISA_LOGO","N");
            m_hTable.set("INTERLINK_LOGO","N");
            m_hTable.set("PLUS_LOGO","N");
            m_hTable.set("BIN_TYPE",strBIN_TYPE);
            vector<string> hLogos;
            Buffer::parse((*pConfig).second.first,",",hLogos);
            for (int i=0;i < hLogos.size();i++)
               m_hTable.set(hLogos[i].c_str(),"Y");
            m_hTable.set("CC_STATE","A");
            m_hTable.set("CC_USER_ID","SYSTEM");
            m_hTable.set("CC_TSTAMP_CHANGE",Clock::instance()->getYYYYMMDDHHMMSS());
            if (bUpdate)
            {
               m_hTable.set("CC_LAST_OPERATION","UPD");
               bUpdate = pUpdateStatment->execute(m_hTable);
            }
            else
            {
               m_hTable.set("CC_LAST_OPERATION","INS");
               bUpdate = pInsertStatment->execute(m_hTable) || (pInsertStatment->getInfoIDNumber() == STS_DUPLICATE_RECORD
                  && pUpdateStatment->execute(m_hTable));
            }
            if (!bUpdate)
            {
               close();
               Database::instance()->rollback();
               return UseCase::setSuccess(false);
            }
            UseCase::addItem();
         }
      }
      else
      if(memcmp(sBuffer,"SAFL",4) == 0)
      {
         if (m_strFile.empty())
            m_strFile.assign("QMRACQVRID",10);
         vector<string> hTokens;
         if (Buffer::parse(strBuffer," ",hTokens) < 5 
            || hTokens[4] != Customer::instance()->getCUST_ID())
            continue;
         hTokens[2].append(1,getCheckDigit(hTokens[2]));
         if (ConfigurationRepository::instance()->translate("INSTITUTION",hTokens[2],strTemp,"","",-1,false) == false)
            continue;
         for (int i = 0; i < 2; i++)
         {
            if (i == 0)
            {
               strFirst.assign("A", 1);
               strFirst.append(hTokens[3]);
               if (ConfigurationRepository::instance()->translate("QMR_VISA_BID", strFirst, strTemp, " ", " ", -1, false) == false)
                  continue;
            }
            strFirst.assign("VNT", 3);
            strFirst = (i == 0) ? strFirst.append(hTokens[3]) : strFirst.append(hTokens[1]);
            strFirst.resize(14, ' ');
            strFirst = (i == 0) ? strFirst.append("00000000", 8) : strFirst.append(hTokens[3]);
            if (ConfigurationRepository::instance()->translate("X_NET_INST_ID", strFirst, strTemp, " ", " ", 0, false)
               && strTemp == hTokens[2])
               continue;
            m_hTable.reset();
            m_hTable.setQualifier("QUALIFY");
            m_hTable.setName("X_NET_INST_ID");
            if (i == 0)
            {
               m_hTable.set("NET_INST_ID_CODE", hTokens[3], false, true);
               m_hTable.set("PAN_PREFIX", "00000000", false, true);
               m_hTable.set("CUST_ID", Customer::instance()->getCUST_ID(), false, true);
            }
            else
            {
               m_hTable.set("NET_INST_ID_CODE", hTokens[1], false, true);
               m_hTable.set("PAN_PREFIX", hTokens[3], false, true);
               m_hTable.set("CUST_ID", hTokens[4], false, true);
            }
            m_hTable.set("INST_ID", hTokens[2], false, true);
            m_hTable.set("INST_STAT", " ", false, true);
            m_hTable.set("CUST_STAT", " ", false, true);
            m_hTable.set("NET_ID", "VNT", false, true);
            m_hTable.set("X_STAT", " ", false, true);
            m_hTable.set("CC_STATE", "A");
            m_hTable.set("CC_LAST_OPERATION", "INS");
            m_hTable.set("CC_USER_ID", "SYSTEM");
            m_hTable.set("CC_TSTAMP_CHANGE", Clock::instance()->getYYYYMMDDHHMMSS());
            if (pInsertStatment->execute(m_hTable) == false)
            {
               if (!(pInsertStatment->getInfoIDNumber() == STS_DUPLICATE_RECORD
                  && pUpdateStatment->execute(m_hTable)))
               {
                  close();
                  Database::instance()->rollback();
                  return UseCase::setSuccess(false);
               }
            }
            UseCase::addItem();
         }
      }
   }
   if (((m_strFile == "QMRACQMC" || m_strFile == "QMRACQVISA")
      && updateLogo() == false)
      || managementinformation::QMRReport::progressUpdate(m_strFile,m_strYYYYMMDD,m_strCONTEXT_DATA) == false
      || deleteBins() == false)
   {
      close();
      Database::instance()->rollback();
      return UseCase::setSuccess(false);
   }
   commit();
   Database::instance()->commit();
   return true;
  //## end QMRAcquirerBin::import%601A37E0015A.body
}

bool QMRAcquirerBin::updateLogo ()
{
  //## begin QMRAcquirerBin::updateLogo%62315BA601EF.body preserve=yes
   const char* sLogoColumns[6] = { "MASTERCARD_LOGO", "MAESTRO_LOGO", "CIRRUS_LOGO", "VISA_LOGO", "PLUS_LOGO", "INTERLINK_LOGO" };
   int iIndex = (m_strFile == "QMRACQVISA") ? 0 : 3;
   string strDBVendor;
   int i =  -1;
   Table hTable("QMR_ACQUIRER_BIN");
   hTable.setQualifier("QUALIFY");
   while (++i < 3)
   {
      hTable.set(sLogoColumns[iIndex],"Y");
      Query hQuery;
      SearchCondition hSearchCondition;
      hQuery.setQualifier("QUALIFY","QMR_ACQUIRER_BIN Y");
      hQuery.setSubSelect(true);
      hQuery.bind("QMR_ACQUIRER_BIN Y","BIN",Column::STRING,0,0,"SUBSTR,1,6");
      hQuery.setBasicPredicate("QMR_ACQUIRER_BIN Y","BIN","=","SUBSTR(QMR_ACQUIRER_BIN.BIN,1,6)",true,false,"SUBSTR","1,6");
      hQuery.setBasicPredicate("QMR_ACQUIRER_BIN Y",sLogoColumns[iIndex],"=","Y");
      hQuery.setBasicPredicate("QMR_ACQUIRER_BIN Y","CUST_ID","=","QMR_ACQUIRER_BIN.CUST_ID",1);
      hQuery.setBasicPredicate("QMR_ACQUIRER_BIN Y","NETWORK_ID",iIndex < 3 ? "!=" : "=","VNT");
      hQuery.setBasicPredicate("QMR_ACQUIRER_BIN","NETWORK_ID",iIndex < 3 ? "=" : "!=", "VNT");
      Extract::instance()->getSpec("DBVENDOR",strDBVendor);
      if (strDBVendor == "SQLSERVER")
         hSearchCondition.setBasicPredicate("QMR_ACQUIRER_BIN","LEN(RTRIM(QMR_ACQUIRER_BIN.BIN))",">","LEN(RTRIM(Y.BIN))",1,1);
      else
         hSearchCondition.setBasicPredicate("QMR_ACQUIRER_BIN","LENGTH(RTRIM(QMR_ACQUIRER_BIN.BIN))",">","LENGTH(RTRIM(Y.BIN))",1,1);
      auto_ptr<FormatSelectVisitor> pFormatSelectVisitor((FormatSelectVisitor*)DatabaseFactory::instance()->create("FormatSelectVisitor"));
      hQuery.accept(*pFormatSelectVisitor);
      string strSubQuery(1,'(');
      strSubQuery.append(pFormatSelectVisitor->SQLText());
      strSubQuery.append(hSearchCondition.getText());
      strSubQuery.append(1,')');
      hSearchCondition.getText().erase();
      hSearchCondition.setBasicPredicate("QMR_ACQUIRER_BIN",sLogoColumns[iIndex],"=","N");
      hSearchCondition.setBasicPredicate("QMR_ACQUIRER_BIN",strDBVendor == "SQLSERVER" ? "SUBSTRING(QMR_ACQUIRER_BIN.BIN,1,6)" : "SUBSTR(QMR_ACQUIRER_BIN.BIN,1,6)","IN",strSubQuery.c_str());
      hQuery.reset();
      hQuery.setSubSelect(true);
      hQuery.setQualifier("QUALIFY","QMR_ACQUIRER_BIN A");
      hQuery.setQualifier("QUALIFY","QMR_ACQUIRER_BIN B");
      hQuery.bind("QMR_ACQUIRER_BIN A","BIN",Column::STRING,0);
      hQuery.join("QMR_ACQUIRER_BIN A","INNER","QMR_ACQUIRER_BIN B","BIN");
      hQuery.join("QMR_ACQUIRER_BIN A","INNER","QMR_ACQUIRER_BIN B","CUST_ID");
      hQuery.setBasicPredicate("QMR_ACQUIRER_BIN A","NETWORK_ID","!=","VNT");
      hQuery.setBasicPredicate("QMR_ACQUIRER_BIN B","NETWORK_ID","=","VNT");
      hQuery.accept(*pFormatSelectVisitor);
      strSubQuery = "(" + pFormatSelectVisitor->SQLText() + ")";
      hSearchCondition.setBasicPredicate("QMR_ACQUIRER_BIN","BIN","NOT IN",strSubQuery.c_str());
      auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
      if (pUpdateStatement->execute(hTable,hSearchCondition.getText()) == false
         && pUpdateStatement->getInfoIDNumber() != STS_RECORD_NOT_FOUND)
         return false;
      hTable.reset();
      ++iIndex;
   }
   return true;
  //## end QMRAcquirerBin::updateLogo%62315BA601EF.body
}

// Additional Declarations
  //## begin QMRAcquirerBin%601A378603CD.declarations preserve=yes
  //## end QMRAcquirerBin%601A378603CD.declarations

//## begin module%601A3603033B.epilog preserve=yes
//## end module%601A3603033B.epilog
