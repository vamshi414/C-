//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6019020303B8.cm preserve=no
//## end module%6019020303B8.cm

//## begin module%6019020303B8.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6019020303B8.cp

//## Module: CXOSLM05%6019020303B8; Package specification
//## Subsystem: LM%3597EB1A028A
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Lm\CXODLM05.hpp

#ifndef CXOSLM05_h
#define CXOSLM05_h 1

//## begin module%6019020303B8.additionalIncludes preserve=no
//## end module%6019020303B8.additionalIncludes

//## begin module%6019020303B8.includes preserve=yes
//## end module%6019020303B8.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
class Statement;
class SelectStatement;
} // namespace reusable

//## Modelname: Totals Management::ManagementInformation_CAT%440DDD48031C
namespace managementinformation {
class QMRReport;
} // namespace managementinformation

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%6019020303B8.declarations preserve=no
//## end module%6019020303B8.declarations

//## begin module%6019020303B8.additionalDeclarations preserve=yes
//## end module%6019020303B8.additionalDeclarations


//## begin QMRIssuerBin%601902980214.preface preserve=yes
//## end QMRIssuerBin%601902980214.preface

//## Class: QMRIssuerBin%601902980214
//## Category: DataNavigator Foundation::Application::LocatorManager_CAT%354B349200A7
//## Subsystem: LM%3597EB1A028A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6019094802FE;process::Application { -> F}
//## Uses: <unnamed>%60190BC902C5;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%6019116003B3;timer::Clock { -> F}
//## Uses: <unnamed>%6019189F007B;database::Database { -> F}
//## Uses: <unnamed>%601A5B0503DE;entitysegment::Customer { -> F}
//## Uses: <unnamed>%602262B70057;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%60379CC7003C;monitor::UseCase { -> F}
//## Uses: <unnamed>%6049C3E9018E;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%60EC00920123;IF::Trace { -> F}
//## Uses: <unnamed>%60EC00D402CA;reusable::Buffer { -> F}
//## Uses: <unnamed>%60EC01CC0320;timer::Date { -> F}
//## Uses: <unnamed>%61A4D5AE009D;database::GlobalContext { -> F}
//## Uses: <unnamed>%652D220A0181;managementinformation::QMRReport { -> F}

class DllExport QMRIssuerBin : public database::GenerationDataGroup  //## Inherits: <unnamed>%6019030B02E3
{
  //## begin QMRIssuerBin%601902980214.initialDeclarations preserve=yes
  //## end QMRIssuerBin%601902980214.initialDeclarations

  public:
    //## Constructors (generated)
      QMRIssuerBin();

    //## Destructor (generated)
      virtual ~QMRIssuerBin();


    //## Other Operations (specified)
      //## Operation: applyDelete%637CBD0001D6
      bool applyDelete ();

      //## Operation: deleteBins%637CC1A50200
      bool deleteBins ();

      //## Operation: import%601903260358
      bool import ();

      //## Operation: insert%6049C4380252
      bool insert ();

      //## Operation: readNext%637CBBBC03B7
      virtual void readNext ();

      //## Operation: update%637CBBBA01DA
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin QMRIssuerBin%601902980214.public preserve=yes
      //## end QMRIssuerBin%601902980214.public

  protected:
    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%6388830A0144
      //## Role: QMRIssuerBin::<m_hQuery>%6388830B0133
      //## begin QMRIssuerBin::<m_hQuery>%6388830B0133.role preserve=no  public: reusable::Query {1 -> 1VHgN}
      reusable::Query m_hQuery;
      //## end QMRIssuerBin::<m_hQuery>%6388830B0133.role

    // Additional Protected Declarations
      //## begin QMRIssuerBin%601902980214.protected preserve=yes
      //## end QMRIssuerBin%601902980214.protected

  private:
    // Additional Private Declarations
      //## begin QMRIssuerBin%601902980214.private preserve=yes
      //## end QMRIssuerBin%601902980214.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BIN%637CBDC302DC
      //## begin QMRIssuerBin::BIN%637CBDC302DC.attr preserve=no  private: string {U} 
      string m_strBIN;
      //## end QMRIssuerBin::BIN%637CBDC302DC.attr

      //## Attribute: Buffer%63889ADE02AD
      //## begin QMRIssuerBin::Buffer%63889ADE02AD.attr preserve=no  private: string {U} 
      string m_strBuffer;
      //## end QMRIssuerBin::Buffer%63889ADE02AD.attr

      //## Attribute: Config%601912B100FD
      //## begin QMRIssuerBin::Config%601912B100FD.attr preserve=no  private: map<int , string , less<int> > {U} 
      map<int , string , less<int> > m_hConfig;
      //## end QMRIssuerBin::Config%601912B100FD.attr

      //## Attribute: DBKey%637CBDF102E6
      //## begin QMRIssuerBin::DBKey%637CBDF102E6.attr preserve=no  private: string {U} 
      string m_strDBKey;
      //## end QMRIssuerBin::DBKey%637CBDF102E6.attr

      //## Attribute: File%637CCAD903E6
      //## begin QMRIssuerBin::File%637CCAD903E6.attr preserve=no  private: string {U} 
      string m_strFile;
      //## end QMRIssuerBin::File%637CCAD903E6.attr

      //## Attribute: FileBIN%6049C446017A
      //## begin QMRIssuerBin::FileBIN%6049C446017A.attr preserve=no  private: string {U} 
      string m_strFileBIN;
      //## end QMRIssuerBin::FileBIN%6049C446017A.attr

      //## Attribute: FileINST_ID%6049C46700DB
      //## begin QMRIssuerBin::FileINST_ID%6049C46700DB.attr preserve=no  private: string {U} 
      string m_strFileINST_ID;
      //## end QMRIssuerBin::FileINST_ID%6049C46700DB.attr

      //## Attribute: FileNETWORK_ID%6049C46E0132
      //## begin QMRIssuerBin::FileNETWORK_ID%6049C46E0132.attr preserve=no  private: string {U} 
      string m_strFileNETWORK_ID;
      //## end QMRIssuerBin::FileNETWORK_ID%6049C46E0132.attr

      //## Attribute: FileKey%637CBE30038C
      //## begin QMRIssuerBin::FileKey%637CBE30038C.attr preserve=no  private: string {U} 
      string m_strFileKey;
      //## end QMRIssuerBin::FileKey%637CBE30038C.attr

      //## Attribute: INST_ID%637CBD8702A6
      //## begin QMRIssuerBin::INST_ID%637CBD8702A6.attr preserve=no  private: string {U} 
      string m_strINST_ID;
      //## end QMRIssuerBin::INST_ID%637CBD8702A6.attr

      //## Attribute: LogoColumn%60E88CCE0340
      //## begin QMRIssuerBin::LogoColumn%60E88CCE0340.attr preserve=no  private: string {U} 
      string m_strLogoColumn;
      //## end QMRIssuerBin::LogoColumn%60E88CCE0340.attr

      //## Attribute: NETWORK_ID%637CBE0F01A8
      //## begin QMRIssuerBin::NETWORK_ID%637CBE0F01A8.attr preserve=no  private: string {U} 
      string m_strNETWORK_ID;
      //## end QMRIssuerBin::NETWORK_ID%637CBE0F01A8.attr

      //## Attribute: RecordLength%63889C1602A2
      //## begin QMRIssuerBin::RecordLength%63889C1602A2.attr preserve=no  private: size_t {U} 0
      size_t m_lRecordLength;
      //## end QMRIssuerBin::RecordLength%63889C1602A2.attr

      //## Attribute: YYYYMMDD%60EBE75B0089
      //## begin QMRIssuerBin::YYYYMMDD%60EBE75B0089.attr preserve=no  private: string {U} 
      string m_strYYYYMMDD;
      //## end QMRIssuerBin::YYYYMMDD%60EBE75B0089.attr

      //## Attribute: zBuffer%637CBF7B02CA
      //## begin QMRIssuerBin::zBuffer%637CBF7B02CA.attr preserve=no  private: char[256] {U} 
      char m_szBuffer[256];
      //## end QMRIssuerBin::zBuffer%637CBF7B02CA.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%60190C700295
      //## Role: QMRIssuerBin::<m_hTable>%60190C7102FB
      //## begin QMRIssuerBin::<m_hTable>%60190C7102FB.role preserve=no  public: reusable::Table { -> VHgN}
      reusable::Table m_hTable;
      //## end QMRIssuerBin::<m_hTable>%60190C7102FB.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%60EEE75800BB
      //## Role: QMRIssuerBin::<m_pInsertStatement>%60EEE75802B9
      //## begin QMRIssuerBin::<m_pInsertStatement>%60EEE75802B9.role preserve=no  public: reusable::Statement { -> RFHgN}
      reusable::Statement *m_pInsertStatement;
      //## end QMRIssuerBin::<m_pInsertStatement>%60EEE75802B9.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%60EEE7D70274
      //## Role: QMRIssuerBin::<m_pUpdateStatement>%60EEE7D800FD
      //## begin QMRIssuerBin::<m_pUpdateStatement>%60EEE7D800FD.role preserve=no  public: reusable::Statement { -> RFHgN}
      reusable::Statement *m_pUpdateStatement;
      //## end QMRIssuerBin::<m_pUpdateStatement>%60EEE7D800FD.role

    // Additional Implementation Declarations
      //## begin QMRIssuerBin%601902980214.implementation preserve=yes
      string m_strCONTEXT_DATA;
      map<int, string, less<int> > m_hLogoIDs;
      //## end QMRIssuerBin%601902980214.implementation
};

//## begin QMRIssuerBin%601902980214.postscript preserve=yes
//## end QMRIssuerBin%601902980214.postscript

//## begin module%6019020303B8.epilog preserve=yes
//## end module%6019020303B8.epilog


#endif
