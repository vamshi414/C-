//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%366FDCC80233.cm preserve=no
//	$Date:   Feb 12 2021 22:29:52  $ $Author:   e3027760  $
//	$Revision:   1.51  $
//## end module%366FDCC80233.cm

//## begin module%366FDCC80233.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%366FDCC80233.cp

//## Module: CXOPLM00%366FDCC80233; Package specification
//## Subsystem: LM%3597EB1A028A
//	.
//## Source file: D:\WorkSpace-Server\V03.2A.R001\Dn\Server\Application\Lm\CXODLM00.hpp

#ifndef CXOPLM00_h
#define CXOPLM00_h 1

//## begin module%366FDCC80233.additionalIncludes preserve=no
//## end module%366FDCC80233.additionalIncludes

//## begin module%366FDCC80233.includes preserve=yes
// $Date:   Feb 12 2021 22:29:52  $ $Author:   e3027760  $ $Revision:   1.51  $
#ifndef CXOSRC15_h
#include "CXODRC15.hpp"
#endif
#ifndef CXOSRC16_h
#include "CXODRC16.hpp"
#endif
#include "CXODLM03.hpp"
#include "CXODLM04.hpp"
//## end module%366FDCC80233.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif

//## Modelname: Totals Management::ManagementInformation_CAT%440DDD48031C
namespace managementinformation {
class AuditEventFile;
} // namespace managementinformation

//## Modelname: Archive::Archive_CAT%3451F7650251
namespace archive {
class ExportData;
class Locator;
} // namespace archive

//## Modelname: DataNavigator Foundation::EntityCommand_CAT%394E2706012A
namespace entitycommand {
class UserActivityCommand;
} // namespace entitycommand

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Partition_CAT%346B9162029B
namespace partition {
class PartitionDeallocator;
} // namespace partition

//## Modelname: DataNavigator Foundation::RepositoryCommand_CAT%394E267C0078
namespace repositorycommand {
class TokenRepair;
class TransactionRepair;
class PopulatePanSuffix;
class PanRepair;
} // namespace repositorycommand

class TransactionBilling;
class EMSBilling;
class QMRDeviceFile;
class QMRAcquirerBin;
class QMRIssuerBin;
//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

namespace reusable {
class KeyRing;
class KeyManager;
class Buffer;
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class ImportFile;
} // namespace command

namespace IF {
class Extract;
class Job;
class Timestamp;
class Console;
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
class MidnightAlarm;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DuplicateIndex;
class GlobalContext;
class DatabaseFactory;
class MaintenanceProcedure;
class AESKeyRing;
} // namespace database

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class AuditEvent;
} // namespace segment

//## Modelname: Reconciliation::ReconciliationFile_CAT%439754C1037A
namespace reconciliationfile {
class ReconciliationTransaction;

} // namespace reconciliationfile

//## begin module%366FDCC80233.declarations preserve=no
//## end module%366FDCC80233.declarations

//## begin module%366FDCC80233.additionalDeclarations preserve=yes
#include <deque>
//## end module%366FDCC80233.additionalDeclarations


//## begin LocatorManager%3505A95B026A.preface preserve=yes
//## end LocatorManager%3505A95B026A.preface

//## Class: LocatorManager%3505A95B026A
//	<body>
//	<title>CG
//	<h1>LM
//	<h2>AB
//	<!-- LocatorManager General -->
//	<h3>System Flow
//	<p>
//	The DataNavigator server stores transactions in monthly
//	tables.
//	The number of months can vary from 3 to a maximum of 99.
//	New tables are created by the Locator Manager service
//	(<i>ca</i>LM) prior to the start of each month.
//	Old tables are dropped as needed to retain the
//	configured number of months of transactions.
//	<p>
//	Distributed file result sets are saved in daily tables.
//	The number of daily tables can vary from 15 to a maximum
//	of 180.
//	A daily table is created by the Locator Manager service
//	(<i>ca</i>LM) seven days in advance.
//	Old tables are dropped as needed to retain the
//	configured number of days of backup.
//	<p>
//	Table maintenance is accomplished by submitting the
//	necessary scripts.
//	</p>
//	<img src=CXOCLM00.gif>
//	</body>
//	<body>
//	<title>OG
//	<h1>LM
//	<h2>AB
//	<!-- LocatorManager General -->
//	<h3>System Flow
//	<p>
//	The DataNavigator server stores transactions in monthly
//	tables.
//	The number of months can vary from 3 to a maximum of 99.
//	New tables are created by the Locator Manager service
//	(<i>ca</i>LM) prior to the start of each month.
//	Old tables are dropped as needed to retain the
//	configured number of months of transactions.
//	<p>
//	Distributed files are saved in daily tables.
//	The number of daily tables can vary from 15 to a maximum
//	of 180.
//	A daily table is created by the Locator Manager service
//	(<i>ca</i>LM) seven days before needed.
//	Old tables are dropped as needed to retain the
//	configured number of days of backup.
//	<p>
//	Table maintenance is accomplished by submitting the
//	necessary scripts.
//	</p>
//	<img src=CXOOLM00.gif>
//	<h3>PADSS (Payment Application Data Security Standard)
//	<p>
//	The Payment Card Industry (PCI) Data Security Standard
//	and the Payment Application Data Security
//	Standard (PADSS) require that Personal Account Number
//	(PAN)
//	information be protected while at rest in a file on disk
//	or tape or when stored as a field in a
//	database.  Data Navigator protects PAN information in
//	its database
//	repository by replacing the PAN with a randomized
//	token.  The relationship between tokens and PANs
//	is stored in the Data Navigator repository in an
//	encrypted form using the Advanced Encryption
//	Standard (AES).  The LM task provides an interface for
//	controlling the tokenization of PANs.
//	<p>
//	<h3>BEGIN command
//	This command is used to begin the tokenizing of PAN
//	columns in the database going forward as new
//	transactions are loaded or new data containing PAN
//	information is added to the database.
//	Existing PANs in the database are not impacted by this
//	command.  Tokenizing must begin on a monthly
//	boundary.  The BEGIN command looks for an empty FIN_
//	LOCATOR monthly table, starting with
//	the current month and going forward. For example, if the
//	command is entered on 6-1-20xx and
//	the FIN_L20xx06 table already has transactions, then the
//	starting date will be 7-1-20xx.   If there
//	are no transactions in FIN_L20xx06 then the starting
//	date will be 6-1-20xx, and tokenizing will
//	start with June transactions.  Once a start date is
//	established, any transactions loaded after the
//	start date will be stored with tokenized PANs.  The
//	tokenization environment
//	consists of data encryption keys which are stored in the
//	TASK_CONTEXT table and the random tokens
//	which are stored in the DN_SYMBOLS table. Backups of the
//	encryption keys and the encrypted tokens
//	are stored in the DX_DATA tables with a DX_FILE_TYPE of
//	"BACKUP".
//	Command format is "RESET caLM PADSS BEGIN".  On open
//	systems, right clicking on the LM task
//	provides access to PADSS menu.
//	Select "Manage PANs in new data (going forward)",
//	"Protection On (Tokenize PANs)".
//	The BEGIN command should be executed at least two days
//	prior to the end of the month so that all
//	tasks can detect that tokenization has been turned on.
//	Tasks check for changes to tokenization
//	during startup and once a day at midnight.  Restarting
//	the system after issuing the command is required
//	if the command is issued on the last day of the month.
//	<p>
//	<h3>END command
//	The END command provides a way to stop the tokenization
//	of PANs.  As with the BEGIN command the END
//	command must terminate tokenization on a monthly
//	boundary. Typically, this means that tokenization
//	will cease as of the end of the month in which the
//	command was entered. The exception to that rule
//	is if no transactions have been loaded in the current
//	month.  In that case, the END date is set to
//	the end of the previous month.
//	Command format is "RESET caLM PADSS END".  On open
//	systems, right clicking on the LM task
//	provides access to PADSS menu.
//	Select "Manage PANs in new data (going forward)",
//	"Protection Off (Detokenize PANs)".
//	<p>
//	<h3>TOKENIZE command
//	This command is used to convert existing PAN data into
//	tokens. This command cannot be entered until
//	tokenization has been activated with the "BEGIN"
//	command. The tokenization of existing financial data
//	starts with the current month � 1. For example if this
//	command is issued on 6-1-20xx,
//	then tokenization of existing data will start with the
//	FIN_L20xx05 table and will work its way
//	backwards until all FIN_LYYYYMM tables have been
//	processed.
//	The commands to START, STOP, and CANCEL the tokenization
//	of the financial tables are as follows:
//	<p>
//	RESET caLM TOKENIZE FIN START
//	RESET caLM TOKENIZE FIN STOP
//	RESET caLM TOKENIZE FIN CANCEL
//	<p>
//	The START command begins the process of tokenizing
//	existing data.
//	The process can be suspended using STOP command.  The
//	process can be resumed by re-entering the START
//	command.  A CANCEL command is also provided which stops
//	the process and removes the checkpoint data
//	such that a subsequent START command starts over from
//	the beginning instead of resuming from where it
//	left off.
//	<p>
//	To process the other tables containing PAN information
//	use the TOKENIZE EMS commands:
//	<p>
//	RESET caLM TOKENIZE EMS START
//	RESET caLM TOKENIZE EMS STOP
//	RESET caLM TOKENIZE EMS CANCEL
//	<p>
//	Tables impacted by these commands include EMS_CASE,
//	DEPOSIT_TRAN, EMS_UNMATCHED_MSG, CARDHOLDER,
//	and CAPTURED_CARD tables.  On open systems, right
//	clicking on the LM task provides access to PADSS menu.
//	Select "Manage PANs in existing data", "Protect PANs
//	(Tokenize)".
//	<p>
//	<h3>DETOKENIZE command
//	This command is used to convert tokenized PANs into PANs
//	in the clear.
//	The de-tokenization of existing data starts with the
//	current month � 1.
//	For example if this command is issued on 6-1-20xx, then
//	de-tokenization of existing data will start
//	with the FIN_L20xx05 table and will work its way
//	backwards until all FIN_LYYYYMM tables have been
//	processed. This command would typically be used after
//	the "END" command has been issued and tokenization
//	has stopped.
//	The format and behavior of the DETOKINZE commands are
//	similar to the TOKENIZE commands:
//	<p>
//	RESET caLM DETOKEN  FIN START
//	RESET caLM DETOKEN  FIN STOP
//	RESET caLM DETOKEN  FIN CANCEL
//	<p>
//	RESET caLM DETOKEN  EMS START
//	RESET caLM DETOKEN  EMS STOP
//	RESET caLM DETOKEN  EMS CANCEL
//	<p>
//	On open systems, right clicking on the LM task provides
//	access to PADSS menu.
//	Select "Manage PANs in existing data", "Re-instate PANs
//	in clear (Detokenize)".
//	<p>
//	<h3>MASTERKEY command
//	This command generates a new master key and re-encrypts
//	the data keys stored in the TASK_CONTEXT table with
//	the new master key.  This command can be run any number
//	of times per day.
//	Command format is "RESET caLM PADSS MASTERKEY".  On open
//	systems, right clicking on the LM task
//	provides access to PADSS menu.  Select "Manage
//	Encryption Keys", "Change Master Key".
//	<p>
//
//	<h3>DATAKEY command
//	This command generates a new data key and re-encrypts
//	the DN_SYMBOLS table with the new key.
//	This command can be run up to 9 times per day.
//	Command format is "RESET caLM PADSS DATAKEY".  On open
//	systems, right clicking on the LM task
//	provides access to PADSS menu.  Select "Manage
//	Encryption Keys", "Change Data Key".
//	<p>
//	<h3>RECOVER command
//	This command repairs any missing or corrupted data
//	encryption keys in the TASK_CONTEXT table or any missing
//	or corrupted rows in the DN_SYMBOLS table.  It uses
//	backups stored in the DX_DATA tables under the
//	DX_FILE_TYPE of "BACKUP" to facilitate the recovery.
//	These backups are taken daily by the LM task.
//	This command is also issued automatically by Data
//	Navigator if it determines that the encryption
//	keys or tokens have been damaged.
//	Command format is "RESET caLM PADSS RECOVER".  On open
//	systems, right clicking on the LM task
//	provides access to PADSS menu.  Select "Manage
//	Encryption Keys", "Recover Keys".
//	<p>
//	<h3>Managing File Encryption Keys
//	Data Navigator has the ability to process triple DES
//	encrypted input from other systems and endpoints as well
//	as
//	the ability to encrypt output destined for external
//	systems and endpoints using triple DES encryption.
//	To successfully pass triple DES encrypted data from one
//	system to another, both systems must have access to the
//	same data key(s) that are used to encrypt the data at
//	the sending endpoint and decrypt the data at the
//	receiving endpoint.
//	Data keys are securely shared between systems by first
//	encrypting the data keys with a transport key.
//	Once encrypted with a transport key, the data keys can
//	be safely sent from one system to another via any data
//	transfer
//	means desired.  This scheme requires that the transport
//	key also be available at both ends.
//	Transport keys are securely shared between systems by
//	exporting and importing the transport key in 3 parts.
//	Once imported,
//	the 3 parts are combined programatically into a single
//	transport key.  The transport can then be used to
//	decrypt the data keys.
//
//	Data Navigator provides the following key management
//	functions:
//	<ul>
//	<li>Generate a new transport key
//	<li>Generate a new data key
//	<li>Import an existing transport key from another system
//	<li>Import an existing data key from another system
//	<li>Export a transport key
//	<li>Export a data key
//	</ul>
//	On open systems, right clicking on the LM task provides
//	access to PADSS menu.
//	Select "Manage Encryption Keys", to reveal the following
//	options:
//	<p>
//	<ul>
//	<li>Import Transport Key
//	<li>Import Data Key
//	<li>Import Key File
//	<li>Export Transport Key
//	<li>Export Data Key
//	<li>Configure Keys
//	</ul>
//	<p>
//	The "Import Key File" option provides a mechanism for
//	importing one or more keys from a data file as opposed
//	to manually entering them.  The "Configure Keys" option
//	provides the ability to generate new transport keys,
//	generate new data keys, specify a transport key to be
//	used for exporting data keys, specify a data key to be
//	used for encrypting output data, and the ability to
//	delete keys.
//	<p>
//	On the IBM Mainframe environment, similar encryption key
//	management functions are accessed via the Data Navigator
//	Console.
//	From the Data Navigator Dialog screen select the "K -
//	Keys" option.
//	<p>
//	<img src=KEYS_01.gif>
//	<p>
//	This brings up the "File Encyption Keys" screen.  This
//	screen lists all existing keys and identifies them as
//	Transport keys or Data keys.
//	<p>
//	<img src=KEYS_02.gif>
//	<p>
//	From the "File Encryption Keys" screen the row command
//	"S" can be used to set the default transport key and the
//	default data key.  The default data key is used by Data
//	Navigator to encrypt output files.  The default
//	transport key is used to export the default data key.
//	Only one default transport key and one default data key
//	can be specified at a time.  The "D" row command is used
//	to delete keys.  The following commands can be entered
//	at the command line:
//	<p>
//	<ul>
//	<li>GTK - Generates a new transport key
//	<li>GDK - Generates a new data key
//	<li>ITK - Import an existing transport key from another
//	system
//	<li>IDK - Import an existing data key from another system
//	</ul>
//	<p>
//	On the IBM Mainframe environment, exporting transport
//	keys is done by issuing a "RESET caLM PADSS ETK"
//	command. This exports
//	the current default transport key as 3 parts to 3
//	separate files.
//	Exporting data keys is done by issuing a "RESET caLM
//	PADSS EDK" command.  This uses the current default
//	transport key to
//	encrypt the current default data key and write it to a
//	file.  Importing keys from a file is accomplished
//	with the "RESET caLM PADSS KEYFILE" command.
//	<p>
//	</body>
//## Category: DataNavigator Foundation::Application::LocatorManager_CAT%354B349200A7
//## Subsystem: LM%3597EB1A028A
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..1



//## Uses: <unnamed>%36DED14A03E0;database::Database { -> F}
//## Uses: <unnamed>%39BE551A00A1;IF::Message { -> F}
//## Uses: <unnamed>%39F1ABDB01B9;monitor::UseCase { -> F}
//## Uses: <unnamed>%40851F86036B;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%408521BA034B;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4475526B00B6;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%44756B7B0382;IF::Console { -> F}
//## Uses: <unnamed>%449646C60262;partition::PartitionDeallocator { -> F}
//## Uses: <unnamed>%47187CD400A4;IF::Timestamp { -> F}
//## Uses: <unnamed>%47187FBA0352;timer::Clock { -> F}
//## Uses: <unnamed>%472EDF3403DF;reusable::Buffer { -> F}
//## Uses: <unnamed>%472EE4B00168;timer::Date { -> F}
//## Uses: <unnamed>%47DE6F4601D9;command::ImportFile { -> F}
//## Uses: <unnamed>%4A31213B0232;IF::Extract { -> F}
//## Uses: <unnamed>%4A3121550000;IF::Job { -> F}
//## Uses: <unnamed>%4A31219302CE;database::MaintenanceProcedure { -> F}
//## Uses: <unnamed>%4AA7DB9D037B;repositorycommand::TransactionRepair { -> F}
//## Uses: <unnamed>%4AA7DBA9021B;repositorycommand::TokenRepair { -> F}
//## Uses: <unnamed>%4AB14AD501AA;database::GlobalContext { -> F}
//## Uses: <unnamed>%4AC3BAF103B9;repositorycommand::PanRepair { -> F}
//## Uses: <unnamed>%4C6399070211;repositorycommand::PopulatePanSuffix { -> F}
//## Uses: <unnamed>%4C81707103B6;reusable::KeyManager { -> F}
//## Uses: <unnamed>%4C9BC0080172;IF::Trace { -> F}
//## Uses: <unnamed>%4EE8476A002A;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%4EE849CE0348;reconciliationfile::ReconciliationTransaction { -> F}
//## Uses: <unnamed>%501806490254;reusable::KeyRing { -> F}
//## Uses: <unnamed>%5018064B0345;database::AESKeyRing { -> F}
//## Uses: <unnamed>%53B67DD500F7;segment::AuditEvent { -> F}
//## Uses: <unnamed>%53B67E570159;entitycommand::UserActivityCommand { -> F}
//## Uses: <unnamed>%53C42D260371;reusable::Transaction { -> F}
//## Uses: <unnamed>%601A59BD0109;entitysegment::Customer { -> F}

class LocatorManager : public process::Application  //## Inherits: <unnamed>%3505A9B801BA
{
  //## begin LocatorManager%3505A95B026A.initialDeclarations preserve=yes
  //## end LocatorManager%3505A95B026A.initialDeclarations

  public:
    //## Constructors (generated)
      LocatorManager();

    //## Destructor (generated)
      virtual ~LocatorManager();


    //## Other Operations (specified)
      //## Operation: checkAvailablePartitions%44754A80033E
      void checkAvailablePartitions (const string& strRecordType);

      //## Operation: checkPartitions%4475A05403DE
      void checkPartitions ();

      //## Operation: initialize%366FDB4703AC
      virtual int initialize ();

      //## Operation: update%3EE9F0FB03D8
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin LocatorManager%3505A95B026A.public preserve=yes
      //## end LocatorManager%3505A95B026A.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%4C2A12EB0127
      virtual int onMessage (Message& hMessage);

      //## Operation: onReset%384581CE0151
      //	Syntax:  RESET task EMS
      //
      //	This command triggers the generation of billing
      //	information for EMS.
      //
      //	Syntax:  RESET task TRAN
      //
      //	This command triggers the generation of billing
      //	information for transaction storage.
      virtual int onReset (Message& hMessage);

      //## Operation: onResume%4A3120C40242
      virtual int onResume (Message& hMessage);

    // Additional Protected Declarations
      //## begin LocatorManager%3505A95B026A.protected preserve=yes
      //## end LocatorManager%3505A95B026A.protected

  private:
    // Additional Private Declarations
      //## begin LocatorManager%3505A95B026A.private preserve=yes
      //## end LocatorManager%3505A95B026A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: MEMBER_NAME%4728537C017F
      //## begin LocatorManager::MEMBER_NAME%4728537C017F.attr preserve=no  private: string {U} 
      string m_strMEMBER_NAME;
      //## end LocatorManager::MEMBER_NAME%4728537C017F.attr

      //## Attribute: PopulatePanSuffix%4DEE50210134
      //## begin LocatorManager::PopulatePanSuffix%4DEE50210134.attr preserve=no  private: repositorycommand::PopulatePanSuffix* {U} 0
      repositorycommand::PopulatePanSuffix* m_pPopulatePanSuffix;
      //## end LocatorManager::PopulatePanSuffix%4DEE50210134.attr

      //## Attribute: TIME_PERIOD%472854020196
      //## begin LocatorManager::TIME_PERIOD%472854020196.attr preserve=no  private: string {U} 
      string m_strTIME_PERIOD;
      //## end LocatorManager::TIME_PERIOD%472854020196.attr

      //## Attribute: TransactionHistory%4F7C6ADD019F
      //## begin LocatorManager::TransactionHistory%4F7C6ADD019F.attr preserve=no  private: TransactionHistory {R} 0
      TransactionHistory *m_pTransactionHistory;
      //## end LocatorManager::TransactionHistory%4F7C6ADD019F.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%366FDBA60131
      //## Role: LocatorManager::<m_pLocator>%366FDBA70133
      //## begin LocatorManager::<m_pLocator>%366FDBA70133.role preserve=no  public: archive::Locator {1 -> 5RFHgN}
      archive::Locator *m_pLocator[5];
      //## end LocatorManager::<m_pLocator>%366FDBA70133.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%367FA0ED02DD
      //## Role: LocatorManager::<m_pDuplicateIndex>%367FA0EE0324
      //## begin LocatorManager::<m_pDuplicateIndex>%367FA0EE0324.role preserve=no  public: database::DuplicateIndex { -> RFHgN}
      database::DuplicateIndex *m_pDuplicateIndex;
      //## end LocatorManager::<m_pDuplicateIndex>%367FA0EE0324.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%39BE498A0023
      //## Role: LocatorManager::<m_pEMSBilling>%39BE498A0217
      //## begin LocatorManager::<m_pEMSBilling>%39BE498A0217.role preserve=no  public: EMSBilling { -> RFHgN}
      EMSBilling *m_pEMSBilling;
      //## end LocatorManager::<m_pEMSBilling>%39BE498A0217.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%39BE498C00DA
      //## Role: LocatorManager::<m_pTransactionBilling>%39BE498C0256
      //## begin LocatorManager::<m_pTransactionBilling>%39BE498C0256.role preserve=no  public: TransactionBilling { -> RFHgN}
      TransactionBilling *m_pTransactionBilling;
      //## end LocatorManager::<m_pTransactionBilling>%39BE498C0256.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%3EE9ED2002DE
      //## Role: LocatorManager::<m_hTimer>%3EE9ED210128
      //## begin LocatorManager::<m_hTimer>%3EE9ED210128.role preserve=no  public: timer::Timer { -> 3VHgN}
      timer::Timer m_hTimer[3];
      //## end LocatorManager::<m_hTimer>%3EE9ED210128.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%42263B9D0399
      //## Role: LocatorManager::<m_pExportData>%42263B9E02BF
      //## begin LocatorManager::<m_pExportData>%42263B9E02BF.role preserve=no  public: archive::ExportData { -> RFHgN}
      archive::ExportData *m_pExportData;
      //## end LocatorManager::<m_pExportData>%42263B9E02BF.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%4721BF590068
      //## Role: LocatorManager::<m_hQuery>%4721BF5A0039
      //## begin LocatorManager::<m_hQuery>%4721BF5A0039.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end LocatorManager::<m_hQuery>%4721BF5A0039.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%5578376101E7
      //## Role: LocatorManager::<m_pAuditEventFile>%557837620113
      //## begin LocatorManager::<m_pAuditEventFile>%557837620113.role preserve=no  public: managementinformation::AuditEventFile { -> RFHgN}
      managementinformation::AuditEventFile *m_pAuditEventFile;
      //## end LocatorManager::<m_pAuditEventFile>%557837620113.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%601A33BD000F
      //## Role: LocatorManager::<m_pQMRIssuerBin>%601A33BE0281
      //## begin LocatorManager::<m_pQMRIssuerBin>%601A33BE0281.role preserve=no  public: QMRIssuerBin { -> RFHgN}
      QMRIssuerBin *m_pQMRIssuerBin;
      //## end LocatorManager::<m_pQMRIssuerBin>%601A33BE0281.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%601AC7F1012F
      //## Role: LocatorManager::<m_pQMRAcquirerBin>%601AC7F201B3
      //## begin LocatorManager::<m_pQMRAcquirerBin>%601AC7F201B3.role preserve=no  public: QMRAcquirerBin { -> RFHgN}
      QMRAcquirerBin *m_pQMRAcquirerBin;
      //## end LocatorManager::<m_pQMRAcquirerBin>%601AC7F201B3.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%60236641001D
      //## Role: LocatorManager::<m_pQMRDeviceFile>%60236642024B
      //## begin LocatorManager::<m_pQMRDeviceFile>%60236642024B.role preserve=no  public: QMRDeviceFile { -> RFHgN}
      QMRDeviceFile *m_pQMRDeviceFile;
      //## end LocatorManager::<m_pQMRDeviceFile>%60236642024B.role

    // Additional Implementation Declarations
      //## begin LocatorManager%3505A95B026A.implementation preserve=yes
      TokenRepair* m_pTokenRepair[2];
      PanRepair* m_pPanRepair[2];
      deque<repositorycommand::TransactionRepair*> m_hTransactionRepair;
      QMRBinFile* m_pQMRBinFile;
      //## end LocatorManager%3505A95B026A.implementation
};

//## begin LocatorManager%3505A95B026A.postscript preserve=yes
//## end LocatorManager%3505A95B026A.postscript

//## begin module%366FDCC80233.epilog preserve=yes
//## end module%366FDCC80233.epilog


#endif
