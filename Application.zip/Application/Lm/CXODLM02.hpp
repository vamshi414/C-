//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39B4F4BB0126.cm preserve=no
//	$Date:   Mar 31 2016 16:03:34  $ $Author:   e1009839  $
//	$Revision:   1.9  $
//## end module%39B4F4BB0126.cm

//## begin module%39B4F4BB0126.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39B4F4BB0126.cp

//## Module: CXOSLM02%39B4F4BB0126; Package specification
//## Subsystem: LM%3597EB1A028A
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Application\Lm\CXODLM02.hpp

#ifndef CXOSLM02_h
#define CXOSLM02_h 1

//## begin module%39B4F4BB0126.additionalIncludes preserve=no
//## end module%39B4F4BB0126.additionalIncludes

//## begin module%39B4F4BB0126.includes preserve=yes
// $Date:   Mar 31 2016 16:03:34  $ $Author:   e1009839  $ $Revision:   1.9  $
//## end module%39B4F4BB0126.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif
#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class FormatSelectVisitor;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Job;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class Context;
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%39B4F4BB0126.declarations preserve=no
//## end module%39B4F4BB0126.declarations

//## begin module%39B4F4BB0126.additionalDeclarations preserve=yes
struct TransactionBillingRecord
{
   char sRecordID[5];
   char sVersionID[2];
   char sCreateDate[8];
   char sCreateTime[8];
   char sInstitutionID[11];
   char sProcessorID[8];
   char sCustomerID[4];
   char sTranCount[9];
};

struct TransactionCount
{
	char sInstitutionID[11];
    char sProcessorID[8];
	long lAcqCount;
	long lIssCount;
	long lOnUsCount;
};
//## end module%39B4F4BB0126.additionalDeclarations


//## begin TransactionBilling%39B4F4FB025E.preface preserve=yes
//## end TransactionBilling%39B4F4FB025E.preface

//## Class: TransactionBilling%39B4F4FB025E
//## Category: DataNavigator Foundation::Application::LocatorManager_CAT%354B349200A7
//## Subsystem: LM%3597EB1A028A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39B4F564018D;timer::Clock { -> F}
//## Uses: <unnamed>%39B4F56602DA;process::Application { -> F}
//## Uses: <unnamed>%39B4F56A0218;IF::Job { -> F}
//## Uses: <unnamed>%39B4F5700108;database::Database { -> F}
//## Uses: <unnamed>%39B4F57401B8;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%39B4F57602C9;IF::Extract { -> F}
//## Uses: <unnamed>%39B4F57803C7;reusable::FormatSelectVisitor { -> F}
//## Uses: <unnamed>%39B4F57B019A;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%39BFCE6D036F;database::Context { -> F}
//## Uses: <unnamed>%3A3938D3018C;monitor::UseCase { -> F}

class TransactionBilling : public reusable::Observer  //## Inherits: <unnamed>%39B4F5800346
{
  //## begin TransactionBilling%39B4F4FB025E.initialDeclarations preserve=yes
  //## end TransactionBilling%39B4F4FB025E.initialDeclarations

  public:
    //## Constructors (generated)
      TransactionBilling();

    //## Destructor (generated)
      virtual ~TransactionBilling();


    //## Other Operations (specified)
      //## Operation: reset%39BE4A290126
      void reset (bool bForce, const string& strDate);

      //## Operation: update%39B4F5E002E1
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin TransactionBilling%39B4F4FB025E.public preserve=yes
      //## end TransactionBilling%39B4F4FB025E.public

  protected:
    // Additional Protected Declarations
      //## begin TransactionBilling%39B4F4FB025E.protected preserve=yes
      //## end TransactionBilling%39B4F4FB025E.protected

  private:

    //## Other Operations (specified)
      //## Operation: createBillingFile%39B4F5E002E0
      bool createBillingFile ();

      //## Operation: shouldBill%39BE4A290128
      bool shouldBill ();

    // Additional Private Declarations
      //## begin TransactionBilling%39B4F4FB025E.private preserve=yes
      //## end TransactionBilling%39B4F4FB025E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: BillingMonth%39BE5882009B
      //## begin TransactionBilling::BillingMonth%39BE5882009B.attr preserve=no  private: string {U} 
      string m_strBillingMonth;
      //## end TransactionBilling::BillingMonth%39BE5882009B.attr

      //## Attribute: Count%39B4F5EE0222
      //## begin TransactionBilling::Count%39B4F5EE0222.attr preserve=no  private: int {U} 0
      int m_lCount;
      //## end TransactionBilling::Count%39B4F5EE0222.attr

      //## Attribute: INST_ID%39B4F5EE022C
      //## begin TransactionBilling::INST_ID%39B4F5EE022C.attr preserve=no  private: string {U} 
      string m_strINST_ID;
      //## end TransactionBilling::INST_ID%39B4F5EE022C.attr

      //## Attribute: PROC_ID%39B4F5EE0241
      //## begin TransactionBilling::PROC_ID%39B4F5EE0241.attr preserve=no  private: string {U} 
      string m_strPROC_ID;
      //## end TransactionBilling::PROC_ID%39B4F5EE0241.attr

      //## Attribute: RecordType%39B4F5EE0236
      //## begin TransactionBilling::RecordType%39B4F5EE0236.attr preserve=no  private: string {U} 
      string m_strRecordType;
      //## end TransactionBilling::RecordType%39B4F5EE0236.attr

      //## Attribute: TransactionBillingRecord%39B4F5EE024A
      //## begin TransactionBilling::TransactionBillingRecord%39B4F5EE024A.attr preserve=no  private: struct TransactionBillingRecord* {U} 
      struct TransactionBillingRecord* m_pTransactionBillingRecord;
      //## end TransactionBilling::TransactionBillingRecord%39B4F5EE024A.attr

      //## Attribute: TransactionBilling%44A29B920261
      //## begin TransactionBilling::TransactionBilling%44A29B920261.attr preserve=no  private: map<string,TransactionCount ,less<string> > {U} 
      map<string,TransactionCount ,less<string> > m_pTransactionBilling;
      //## end TransactionBilling::TransactionBilling%44A29B920261.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%39B4F58F022F
      //## Role: TransactionBilling::<m_hFlatFile>%39B4F5900046
      //## begin TransactionBilling::<m_hFlatFile>%39B4F5900046.role preserve=no  public: IF::FlatFile { -> VHgN}
      IF::FlatFile m_hFlatFile;
      //## end TransactionBilling::<m_hFlatFile>%39B4F5900046.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%39B4F5A001F7
      //## Role: TransactionBilling::<m_hQuery>%39B4F5A0039C
      //## begin TransactionBilling::<m_hQuery>%39B4F5A0039C.role preserve=no  public: reusable::Query { -> 2VHgN}
      reusable::Query m_hQuery[2];
      //## end TransactionBilling::<m_hQuery>%39B4F5A0039C.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%39B4F5A8000E
      //## Role: TransactionBilling::<m_hTimer>%39B4F5A80235
      //## begin TransactionBilling::<m_hTimer>%39B4F5A80235.role preserve=no  public: timer::Timer { -> VHgN}
      timer::Timer m_hTimer;
      //## end TransactionBilling::<m_hTimer>%39B4F5A80235.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%39B5409300FA
      //## Role: TransactionBilling::<m_pMemory>%39B5409302C6
      //## begin TransactionBilling::<m_pMemory>%39B5409302C6.role preserve=no  public: IF::Memory { -> RHgN}
      IF::Memory *m_pMemory;
      //## end TransactionBilling::<m_pMemory>%39B5409302C6.role

    // Additional Implementation Declarations
      //## begin TransactionBilling%39B4F4FB025E.implementation preserve=yes
      //## end TransactionBilling%39B4F4FB025E.implementation

};

//## begin TransactionBilling%39B4F4FB025E.postscript preserve=yes
//## end TransactionBilling%39B4F4FB025E.postscript

//## begin module%39B4F4BB0126.epilog preserve=yes
//## end module%39B4F4BB0126.epilog


#endif
