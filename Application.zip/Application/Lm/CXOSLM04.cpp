//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5FA3F1CE0022.cm preserve=no
//## end module%5FA3F1CE0022.cm

//## begin module%5FA3F1CE0022.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5FA3F1CE0022.cp

//## Module: CXOSLM04%5FA3F1CE0022; Package body
//## Subsystem: LM%3597EB1A028A
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Lm\CXOSLM04.cpp

//## begin module%5FA3F1CE0022.additionalIncludes preserve=no
//## end module%5FA3F1CE0022.additionalIncludes

//## begin module%5FA3F1CE0022.includes preserve=yes
#include "CXODIF16.hpp"
#include <algorithm>
//## end module%5FA3F1CE0022.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSMG39_h
#include "CXODMG39.hpp"
#endif
#ifndef CXOSLM04_h
#include "CXODLM04.hpp"
#endif


//## begin module%5FA3F1CE0022.declarations preserve=no
//## end module%5FA3F1CE0022.declarations

//## begin module%5FA3F1CE0022.additionalDeclarations preserve=yes
//## end module%5FA3F1CE0022.additionalDeclarations


// Class QMRBinFile 

QMRBinFile::QMRBinFile()
  //## begin QMRBinFile::QMRBinFile%5FA3F23F0037_const.hasinit preserve=no
      : m_iCount(0)
  //## end QMRBinFile::QMRBinFile%5FA3F23F0037_const.hasinit
  //## begin QMRBinFile::QMRBinFile%5FA3F23F0037_const.initialization preserve=yes
  ,GenerationDataGroup(Application::instance()->image(),Application::instance()->name(),"QMRBIN")
  //## end QMRBinFile::QMRBinFile%5FA3F23F0037_const.initialization
{
  //## begin QMRBinFile::QMRBinFile%5FA3F23F0037_const.body preserve=yes
   memcpy(m_sID,"LM04",4);
   m_strCONTEXT_DATA.assign("VC690:N~COMBINED:N~LOGO:N~CIMS:N~QMRACQVRID:N");
  //## end QMRBinFile::QMRBinFile%5FA3F23F0037_const.body
}


QMRBinFile::~QMRBinFile()
{
  //## begin QMRBinFile::~QMRBinFile%5FA3F23F0037_dest.body preserve=yes
  //## end QMRBinFile::~QMRBinFile%5FA3F23F0037_dest.body
}



//## Other Operations (implementation)
bool QMRBinFile::import ()
{
  //## begin QMRBinFile::import%5FA40C67032A.body preserve=yes
   if (!open())
      return false;
   UseCase hUseCase("DR", "## DR103 LOAD QMR BIN TABLE");
   m_iCount = 0;
   m_strYYYYMMDD.erase();
   size_t n = 0;
   char sBuffer[512];
   auto_ptr<Statement> pInsertStatment((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
   while (read(sBuffer,512,&n))
   {
      if (sBuffer[0] == 'H' && n > 8)
      {
         m_strYYYYMMDD.assign(sBuffer + 1,8);
         Date hDate(m_strYYYYMMDD.c_str());
         int iDays = hDate.daysInMonth(hDate.getYear(), hDate.getMonth()) - hDate.getDay();
         if (iDays != 0)
         {
            hDate += iDays;
            hDate.incrementMonth(-1);
            m_strYYYYMMDD.assign(hDate.asString("%Y%m%d"));
         }
      }
      if (sBuffer[0] != 'D')
         continue;
      if (n == sizeof(struct QMRBin))
      {
         ++m_iCount;
         if (memcmp(sBuffer + 1,Customer::instance()->getCUST_ID().c_str(),4) != 0)
            continue;
         struct QMRBin* pQMRBin = (struct QMRBin*)sBuffer;
         m_hTable.setName("T_QMR_BIN");
         m_hTable.set("YEAR_MONTH",6,m_strYYYYMMDD.c_str());
         m_hTable.set("PROC_ID",sizeof(pQMRBin->sProcId),pQMRBin->sProcId);
         m_hTable.set("INST_ID",sizeof(pQMRBin->sInstId) - 1,pQMRBin->sInstId + 1);
         m_hTable.set("BIN",sizeof(pQMRBin->sBin),pQMRBin->sBin);
         m_hTable.set("BUSINESS_FLG",sizeof(pQMRBin->cBusinessFlg),&pQMRBin->cBusinessFlg);
         m_hTable.set("LOYALTY_FLG",sizeof(pQMRBin->cLoyaltyFlg),&pQMRBin->cLoyaltyFlg);
         m_hTable.set("FRAUD_FLG",sizeof(pQMRBin->cFraudFlg),&pQMRBin->cFraudFlg);
         m_hTable.set("CARD_ORDER_FLG",sizeof(pQMRBin->cCardOrderFlg),&pQMRBin->cCardOrderFlg);
         m_hTable.set("NOT_AP_FLG",sizeof(pQMRBin->cNonAPBinFlg),&pQMRBin->cNonAPBinFlg);
         m_hTable.set("CARD_COUNT",atoi(string(pQMRBin->sCardCount,sizeof(pQMRBin->sCardCount)).c_str()));
         m_hTable.set("ENROLL_COUNT",atoi(string(pQMRBin->sEnrolledCardCount,sizeof(pQMRBin->sEnrolledCardCount)).c_str()));
         m_hTable.set("MEDIA_MS_COUNT",atoi(string(pQMRBin->sMediaMSCount,sizeof(pQMRBin->sMediaMSCount)).c_str()));
         m_hTable.set("MEDIA_IC_COUNT",atoi(string(pQMRBin->sMediaICCount,sizeof(pQMRBin->sMediaICCount)).c_str()));
         m_hTable.set("MEDIA_IP_COUNT",atoi(string(pQMRBin->sMediaIPCount,sizeof(pQMRBin->sMediaIPCount)).c_str()));
         m_hTable.set("MEDIA_IS_COUNT",atoi(string(pQMRBin->sMediaISCount,sizeof(pQMRBin->sMediaISCount)).c_str()));
         m_hTable.set("MINI_COUNT",atoi(string(pQMRBin->sMiniCount,sizeof(pQMRBin->sMiniCount)).c_str()));
         m_hTable.set("MICRO_COUNT",atoi(string(pQMRBin->sMicroCount,sizeof(pQMRBin->sMicroCount)).c_str()));
         m_hTable.set("MOBILE_COUNT",atoi(string(pQMRBin->sMobileCount,sizeof(pQMRBin->sMobileCount)).c_str()));
         m_hTable.set("OTHER_COUNT",atoi(string(pQMRBin->sUNKMediaType,sizeof(pQMRBin->sUNKMediaType)).c_str()));
         m_hTable.set("NETWORK_TYPE",sizeof(pQMRBin->sNetworkType),pQMRBin->sNetworkType);
         m_hTable.set("CARD_TYPE",sizeof(pQMRBin->cDebitCreditInd),&pQMRBin->cDebitCreditInd);
         m_hTable.set("NETWORK_PROD_CODE",sizeof(pQMRBin->sNetworkProductType),pQMRBin->sNetworkProductType);
         m_hTable.set("CARD_NEW_COUNT",atoi(string(pQMRBin->sAddedCardCount,sizeof(pQMRBin->sAddedCardCount)).c_str()));
         m_hTable.set("ACCT_COUNT",atoi(string(pQMRBin->sAcctCount,sizeof(pQMRBin->sAcctCount)).c_str()));
         m_hTable.set("ACCT_NEW_COUNT",atoi(string(pQMRBin->sAddedAcctCount,sizeof(pQMRBin->sAddedAcctCount)).c_str()));
         m_hTable.set("SAV_ACCT_COUNT",atoi(string(pQMRBin->sSAVAcctCount,sizeof(pQMRBin->sSAVAcctCount)).c_str()));
         m_hTable.set("CHK_ACCT_COUNT",atoi(string(pQMRBin->sDDAAcctCount,sizeof(pQMRBin->sDDAAcctCount)).c_str()));
         m_hTable.set("ICA",sizeof(pQMRBin->sICA),pQMRBin->sICA);
         m_hTable.set("ACTIVE_CARD_COUNT",atoi(string(pQMRBin->sActiveCardCount,sizeof(pQMRBin->sActiveCardCount)).c_str()));
         if (!pInsertStatment->execute(m_hTable))
         {
            close();
            Database::instance()->rollback();
            return UseCase::setSuccess(false);
         }
         UseCase::addItem();
      }
   }
   if (m_iCount > 0 && managementinformation::QMRReport::progressUpdate("CIMS", m_strYYYYMMDD, m_strCONTEXT_DATA) == false)
   {
      close();
      Database::instance()->rollback();
      return UseCase::setSuccess(false);
   }
   commit();
   Database::instance()->commit();
   return true;
  //## end QMRBinFile::import%5FA40C67032A.body
}

// Additional Declarations
  //## begin QMRBinFile%5FA3F23F0037.declarations preserve=yes
  //## end QMRBinFile%5FA3F23F0037.declarations

//## begin module%5FA3F1CE0022.epilog preserve=yes
//## end module%5FA3F1CE0022.epilog
