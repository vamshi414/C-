//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39A530C201FF.cm preserve=no
//   $Date:   May 20 2020 16:46:42  $ $Author:   e1009510  $
//   $Revision:   1.62  $
//## end module%39A530C201FF.cm

//## begin module%39A530C201FF.cp preserve=no
//   Copyright (c) 1997 - 2012
//   FIS
//## end module%39A530C201FF.cp

//## Module: CXOSLM01%39A530C201FF; Package body
//## Subsystem: LM%3597EB1A028A
//   .
//## Source file: C:\Devel.Feb\Dn\Server\Application\Lm\CXOSLM01.cpp

//## begin module%39A530C201FF.additionalIncludes preserve=no
//## end module%39A530C201FF.additionalIncludes

//## begin module%39A530C201FF.includes preserve=yes
#include "CXODIF11.hpp"
#include "CXODIF15.hpp"
#include "CXODTM02.hpp"
#include "CXODTM06.hpp"
#include "CXODIF03.hpp"
#include "CXODIF44.hpp"
//## end module%39A530C201FF.includes

#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU19_h
#include "CXODRU19.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSLM01_h
#include "CXODLM01.hpp"
#endif
#ifndef CXOSIF10_h
#include "CXODIF10.hpp"
#endif


//## begin module%39A530C201FF.declarations preserve=no
//## end module%39A530C201FF.declarations

//## begin module%39A530C201FF.additionalDeclarations preserve=yes
//## end module%39A530C201FF.additionalDeclarations


// Class EMSBilling 

EMSBilling::EMSBilling()
  //## begin EMSBilling::EMSBilling%39A52EAA0078_const.hasinit preserve=no
      : m_bBillOrbit(false),
        m_iCaseCount(1),
        m_lCount(0),
        m_bDailyBilling(false),
        m_pEMSExceptionBillingRecord(0),
        m_pEMSFraudAndFeeBillingRecord(0),
        m_bFirst(false),
        m_bRegional(false),
        m_lCount1(0)
  //## end EMSBilling::EMSBilling%39A52EAA0078_const.hasinit
  //## begin EMSBilling::EMSBilling%39A52EAA0078_const.initialization preserve=yes
  //## end EMSBilling::EMSBilling%39A52EAA0078_const.initialization
{
  //## begin EMSBilling::EMSBilling%39A52EAA0078_const.body preserve=yes
   memcpy(m_sID,"LM01",4);
   m_pFlatFile[0] = 0;
   m_pFlatFile[1] = 0;
   m_pFlatFile[2] = 0;
   m_pFlatFile[3] = 0;
   m_pMemory[0] = new Memory(sizeof(EMSExceptionBillingRecord));
   m_pMemory[1] = new Memory(sizeof(EMSFraudAndFeeBillingRecord));
   m_pEMSExceptionBillingRecord = (EMSExceptionBillingRecord*)(char*)*m_pMemory[0];
   m_pEMSFraudAndFeeBillingRecord = (EMSFraudAndFeeBillingRecord*)(char*)*m_pMemory[1];
   memset(m_pEMSExceptionBillingRecord,' ',sizeof(EMSExceptionBillingRecord));
   memset(m_pEMSFraudAndFeeBillingRecord,' ',sizeof(EMSFraudAndFeeBillingRecord));
   m_hQuery[0].attach(this);
   m_hQuery[1].attach(this);
   m_hQuery[2].attach(this);
   Extract::instance()->getSpec("CUSTQUAL",m_strCustQualID);
   Extract::instance()->getSpec("CUSTOMER",m_strCUST_ID);
   Extract::instance()->getSpec("QUALIFY",m_strQualify);
   IString strBill;
   if (Extract::instance()->get("DUSER   ",strBill))
      m_bBillOrbit = (strBill.indexOf("ORBIT") > 0);
   if (!Extract::instance()->getString("DUSER   ","INTERNAL=",m_strINTERNAL,4))
      m_strINTERNAL = "GTWY";
   int i = 0;
   for (i = 0;i <= 7;++i)
      m_lFraudFeeCount[i] = 0;
   for (i = 0;i <= 14;++i)
      for (int j = 0;j <= 6;++j)
         m_lExceptionCount[i][j] = 0;
  //## end EMSBilling::EMSBilling%39A52EAA0078_const.body
}


EMSBilling::~EMSBilling()
{
  //## begin EMSBilling::~EMSBilling%39A52EAA0078_dest.body preserve=yes
   delete m_pMemory[1];
   delete m_pMemory[0];
   m_hInstitution.erase(m_hInstitution.begin(),m_hInstitution.end());
   m_hNetInstCode.erase(m_hNetInstCode.begin(),m_hNetInstCode.end());
   m_hInstProc.erase(m_hInstProc.begin(),m_hInstProc.end());
  //## end EMSBilling::~EMSBilling%39A52EAA0078_dest.body
}



//## Other Operations (implementation)
bool EMSBilling::createBillingFiles ()
{
  //## begin EMSBilling::createBillingFiles%3ED7CFF7008C.body preserve=yes
   UseCase hUseCase("DR","## DR41 BILL FOR EMS");
   if (m_strCUST_ID == m_strINTERNAL && m_hInstitution.size() == 0)
   {
      m_hQuery[3].attach(this);
      m_hQuery[3].setQualifier("QUALIFY","INSTITUTION");
      m_hQuery[3].bind("INSTITUTION","INST_ID",Column::STRING,&m_strINST_ID);
      m_hQuery[3].bind("INSTITUTION","CUST_ID",Column::STRING,&m_strInstCustID);
      m_hQuery[3].setBasicPredicate("INSTITUTION","CUST_ID","<>",m_strCUST_ID.c_str());
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      pSelectStatement->execute(m_hQuery[3]);
      m_hQuery[4].attach(this);
      m_hQuery[4].setQualifier("QUALIFY","X_NET_INST_ID");
      m_hQuery[4].bind("X_NET_INST_ID","INST_ID",Column::STRING,&m_strINST_ID);
      m_hQuery[4].bind("X_NET_INST_ID","CUST_ID",Column::STRING,&m_strInstCustID);
      m_hQuery[4].setBasicPredicate("X_NET_INST_ID","CUST_ID","<>",m_strCUST_ID.c_str());
      pSelectStatement->execute(m_hQuery[4]);
      m_hQuery[5].attach(this);
      m_hQuery[5].setQualifier("QUALIFY","INSTITUTION");
      m_hQuery[5].bind("INSTITUTION","INST_ID",Column::STRING,&m_strINST_ID);
      m_hQuery[5].bind("INSTITUTION","PROC_ID",Column::STRING,&m_strPROC_ID);
      m_hQuery[5].bind("INSTITUTION","CUST_ID",Column::STRING,&m_strInstCustID);
      m_hQuery[5].setBasicPredicate("INSTITUTION","CUST_ID","<>",m_strCUST_ID.c_str());
      pSelectStatement->execute(m_hQuery[5]);
   }
   auto_ptr<Context> pContext(new Context(Application::instance()->image(),Application::instance()->name()));
   bool bReturn = createExceptionBillingFile();
   if (bReturn)
      bReturn = createFraudAndFeeBillingFile();
   if (bReturn && !m_bDailyBilling)
      bReturn = pContext->put("EMSBILLING", m_strContextMonth.c_str());
   return bReturn;
  //## end EMSBilling::createBillingFiles%3ED7CFF7008C.body
}

bool EMSBilling::createExceptionBillingFile ()
{
  //## begin EMSBilling::createExceptionBillingFile%39A533E900DD.body preserve=yes
   m_bRegional = false;
   m_bFirst = true;
   int i = 0;
   for (i = 0;i <= 7;++i)
      m_lFraudFeeCount[i] = 0;
   for (i = 0;i <= 14;++i)
      for (int j = 0;j <= 6;++j)
         m_lExceptionCount[i][j] = 0;
   if (m_bDailyBilling)
   {
      m_pFlatFile[0] = new FlatFile("ECOUNTDY");
      m_pFlatFile[0]->setName("ECOUNTDY");
   }
   else
   {
      m_pFlatFile[0] = new FlatFile("ECOUNT  ");
      m_pFlatFile[0]->setName("ECOUNT  ");
   }
   if (!m_pFlatFile[0]->open(FlatFile::CX_OPEN_OUTPUT))
      return UseCase::setSuccess(false);
   Memory hMemory(100);
   char *szHeader = (char*)hMemory;
   if (m_bDailyBilling)
   {
      memset(szHeader,' ',100);
      memcpy(szHeader,"                              DAILY DN EMS COUNTS",49);
      m_pFlatFile[0]->write(hMemory,100);
      memset(szHeader,' ',100);
      m_pFlatFile[0]->write(hMemory,100);
      memcpy(szHeader, "DATE          INIT      DOCR      CHB1"
         "      REP1      CHB2      DOC7/ARB   UNKNOWN",78);
      m_pFlatFile[0]->write(hMemory,100);
   }
   else
   if (m_bBillOrbit)
   {
      szHeader[0] = 'H';
      memcpy(szHeader+1, Clock::instance()->getYYYYMMDDHHMMSS().data(),Clock::instance()->getYYYYMMDDHHMMSS().length());
      m_pFlatFile[0]->write(hMemory,15);
      m_pFlatFile[2] = new FlatFile("SCOUNT  ");
      m_pFlatFile[2]->setName("SCOUNT  ");
      if (!m_pFlatFile[2]->open(FlatFile::CX_OPEN_OUTPUT))
         return UseCase::setSuccess(false);
   }
   for (int k = 0; k < 7; k++)
      m_lCountTotals[k] = 0;
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery;
   hQuery.setSubSelect(true);
   hQuery.bind("EMS_TRANSITION","CASE_ID",Column::STRING,(void*)0);
   hQuery.bind("EMS_TRANSITION","STATUS_NEXT",Column::STRING,(void*)0);
   hQuery.bind("EMS_TRANSITION","TSTAMP_CREATED",Column::STRING,(void*)0);
   auto_ptr<FormatSelectVisitor> pFormatSelectVisitor((FormatSelectVisitor*)DatabaseFactory::instance()->create("FormatSelectVisitor"));
   hQuery.accept(*pFormatSelectVisitor);
   string strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ") TISS";
   m_hQuery[0].reset();
   m_hQuery[0].setSubSelect(true);
   m_hQuery[0].join("EMS_CASE","INNER","EMS_PHASE P","CASE_ID");
   m_hQuery[0].join("EMS_PHASE P","INNER",strSubSelect.c_str(),"CASE_ID");
   m_hQuery[0].join("EMS_PHASE P","INNER",strSubSelect.c_str(),"TSTAMP_CREATED");
   m_hQuery[0].join("EMS_PHASE P", "LEFT OUTER", "EMS_CASE_VNT V", "CASE_ID");
   m_hQuery[0].bind("EMS_CASE","CASE_ID",Column::STRING,&m_strCASE_ID);
   m_hQuery[0].bind("EMS_CASE","CASE_NO",Column::STRING,&m_strCASE_NO);
   m_hQuery[0].bind("EMS_CASE","PROC_ID_ISS",Column::STRING,&m_strNextPROC_ID);
   m_hQuery[0].bind("EMS_CASE","INST_ID_RECON_ISS",Column::STRING,&m_strNextINST_ID);
   m_hQuery[0].bind("EMS_PHASE P","REQUEST_TYPE",Column::STRING,&m_strNextREQUEST_TYPE);
   m_hQuery[0].bind("EMS_CASE_VNT V", "VCR_IND", Column::STRING, &m_strVCR_IND);
   m_hQuery[0].bind("EMS_CASE", "STATUS", Column::STRING, &m_strSTATUS);
   m_hQuery[0].bind("EMS_CASE","NET_ID_EMS",Column::STRING,&m_strNextNET_ID_EMS);
   m_hQuery[0].bind("EMS_CASE","*",Column::LONG,&m_lCount,0,"COUNT");
   string strBetweenClause;
   if (m_bDailyBilling)
      strBetweenClause ="'" + m_strBillingDate + "00000000' AND '"
                            + m_strBillingDate + "99999999'";
   else
      strBetweenClause ="'" + m_strBillingMonth
         + "0000000000' AND '" + m_strBillingMonth + "9999999999'";

   m_hQuery[0].setBasicPredicate("EMS_PHASE P","TSTAMP_CREATED","BETWEEN",strBetweenClause.c_str());
   if (m_strCUST_ID == m_strINTERNAL)
      m_hQuery[0].setBasicPredicate("EMS_PHASE P","REQUEST_TYPE","IN",
         "('UNW1','UNW2','UNW3','DOC7','ARB','DOC8','COMP')");
   else
   {
      m_hQuery[0].setBasicPredicate("EMS_CASE","NET_ID_EMS","IN",
         "('MCI','VNT')");
      m_hQuery[0].setBasicPredicate("EMS_PHASE P","REQUEST_TYPE","IN",
         "('INIT','DOCR','CHB1','REP1','CHB2','CHBQ','ARB','COMP')");
      m_hQuery[0].setBasicPredicate(strSubSelect.c_str(),"STATUS_NEXT","NOT IN",
         "('REJU','RERU')");
      m_hQuery[0].setBasicPredicate(strSubSelect.c_str(),"STATUS_NEXT","NOT LIKE",
         "CL%");
   }
   m_hQuery[0].setGroupByClause
      ("PROC_ID_ISS,INST_ID_RECON_ISS,P.REQUEST_TYPE,V.VCR_IND,"
      "NET_ID_EMS,EMS_CASE.CASE_ID,EMS_CASE.CASE_NO,EMS_CASE.STATUS");
   m_hQuery[0].setOrderByClause("EMS_CASE.PROC_ID_ISS,"
      "EMS_CASE.INST_ID_RECON_ISS,EMS_CASE.CASE_NO,"
      "P.REQUEST_TYPE,EMS_CASE.NET_ID_EMS");
   if (!pSelectStatement->execute(m_hQuery[0]))
      return UseCase::setSuccess(false);
   m_strNextPROC_ID.erase();
   m_strCurrentCASE_NO.erase();
   update(&m_hQuery[0]);
   writeException();
   if (m_strCUST_ID != m_strINTERNAL)
   {
      m_bRegional = true;
      m_bFirst = true;
      hQuery.reset();
      hQuery.setSubSelect(true);
      hQuery.bind("EMS_PHASE","CASE_ID",Column::STRING,(void*)0);
      hQuery.bind("EMS_PHASE","TSTAMP_CREATED",Column::STRING,(void*)0,0,"MIN");
      auto_ptr<FormatSelectVisitor> pFormatSelectVisitor((FormatSelectVisitor*)DatabaseFactory::instance()->create("FormatSelectVisitor"));
      hQuery.accept(*pFormatSelectVisitor);
      strSubSelect = "(" + pFormatSelectVisitor->SQLText() + ") TISS";
      m_strNextPROC_ID = "";
      m_strNextINST_ID = "";
      m_strNextREQUEST_TYPE = "";
      m_strNextNET_ID_EMS = "";
      m_hQuery[0].reset();
      m_hQuery[0].join("EMS_CASE C","INNER","EMS_PHASE P","CASE_ID");
      m_hQuery[0].join("EMS_CASE C","INNER",strSubSelect.c_str(),"CASE_ID");
      m_hQuery[0].join("EMS_PHASE P","INNER",strSubSelect.c_str(),"TSTAMP_CREATED");
	  m_hQuery[0].join("EMS_PHASE P", "LEFT OUTER", "EMS_CASE_VNT V", "CASE_ID");
      m_hQuery[0].bind("EMS_CASE C","CASE_ID",Column::STRING,&m_strCASE_ID);
      m_hQuery[0].bind("EMS_CASE C","CASE_NO",Column::STRING,&m_strCASE_NO);
      m_hQuery[0].bind("EMS_CASE C","PROC_ID_ISS",Column::STRING,&m_strNextPROC_ID);
      m_hQuery[0].bind("EMS_CASE C","INST_ID_RECON_ISS",Column::STRING,&m_strNextINST_ID);
      m_hQuery[0].bind("EMS_PHASE P","REQUEST_TYPE",Column::STRING,&m_strNextREQUEST_TYPE);
      m_hQuery[0].bind("EMS_CASE C","NET_ID_EMS",Column::STRING,&m_strNextNET_ID_EMS);
	  m_hQuery[0].bind("EMS_CASE C", "STATUS", Column::STRING, &m_strSTATUS);
	  m_hQuery[0].bind("EMS_CASE_VNT V", "VCR_IND", Column::STRING, &m_strVCR_IND);
      m_hQuery[0].bind("EMS_CASE C","*",Column::LONG,&m_lCount,0,"COUNT");
      string strBetweenClause;
      if (m_bDailyBilling)
         strBetweenClause ="'" + m_strBillingDate + "00000000' AND '"
                               + m_strBillingDate + "99999999'";
      else
         strBetweenClause ="'" + m_strBillingMonth
            + "0000000000' AND '" + m_strBillingMonth + "9999999999'";

      m_hQuery[0].setBasicPredicate("EMS_PHASE P","TSTAMP_CREATED","BETWEEN",strBetweenClause.c_str());
      m_hQuery[0].setBasicPredicate("EMS_PHASE P","USER_ROLE","=","I");
      m_hQuery[0].setBasicPredicate("EMS_CASE C","NET_ID_EMS","NOT IN",
         "('MCI','VNT')");
      m_hQuery[0].setGroupByClause
      ("C.PROC_ID_ISS,C.INST_ID_RECON_ISS,P.REQUEST_TYPE,C.STATUS,"
       "C.NET_ID_EMS,C.CASE_NO,C.CASE_ID,V.VCR_IND");
      m_hQuery[2].reset();
      m_hQuery[2].setAssociation("UNION ALL");
      m_hQuery[2].setSubSelect(true);
      m_hQuery[2].join("EMS_CASE C","INNER","EMS_PHASE P","CASE_ID");
      m_hQuery[2].join("EMS_CASE C","INNER",strSubSelect.c_str(),"CASE_ID");
      m_hQuery[2].join("EMS_PHASE P","INNER",strSubSelect.c_str(),"TSTAMP_CREATED");
	  m_hQuery[2].join("EMS_PHASE P", "LEFT OUTER", "EMS_CASE_VNT V", "CASE_ID");
      m_hQuery[2].bind("EMS_CASE C","CASE_ID",Column::STRING,&m_strCASE_ID);
      m_hQuery[2].bind("EMS_CASE C","CASE_NO",Column::STRING,&m_strCASE_NO);
      m_hQuery[2].bind("EMS_CASE C","PROC_ID_ACQ",Column::STRING,&m_strNextPROC_ID);
      m_hQuery[2].bind("EMS_CASE C","INST_ID_RECON_ACQ",Column::STRING,&m_strNextINST_ID);
      m_hQuery[2].bind("EMS_PHASE P","REQUEST_TYPE",Column::STRING,&m_strNextREQUEST_TYPE);
      m_hQuery[2].bind("EMS_CASE C","NET_ID_EMS",Column::STRING,&m_strNextNET_ID_EMS);
	  m_hQuery[2].bind("EMS_CASE C", "STATUS", Column::STRING, &m_strSTATUS);
	  m_hQuery[2].bind("EMS_CASE_VNT V", "VCR_IND", Column::STRING, &m_strVCR_IND);
      m_hQuery[2].bind("EMS_CASE C","*",Column::LONG,&m_lCount,0,"COUNT");
      m_hQuery[2].setBasicPredicate("EMS_PHASE P","TSTAMP_CREATED","BETWEEN",strBetweenClause.c_str());
      m_hQuery[2].setBasicPredicate("EMS_PHASE P","USER_ROLE","=","A");
      m_hQuery[2].setBasicPredicate("EMS_CASE C","NET_ID_EMS","NOT IN",
         "('MCI','VNT')");
      m_hQuery[2].setGroupByClause
      ("C.PROC_ID_ACQ,C.INST_ID_RECON_ACQ,P.REQUEST_TYPE,C.STATUS,"
       "C.NET_ID_EMS,C.CASE_NO,C.CASE_ID,V.VCR_IND");
      //take care of the order by column position numbers below if you
      //select more columns which may alter the order used below
      //C.PROC_ID_ISS,C.INST_ID_RECON_ISS,P.REQUEST_TYPE,C.NET_ID_EMS
      m_hQuery[2].setOrderByClause("6, 4, 7, 5");
      m_hQuery[0].setQuery(&m_hQuery[2]);
      if (!pSelectStatement->execute(m_hQuery[0]))
         return UseCase::setSuccess(false);
      m_strNextPROC_ID = "";
      update(&m_hQuery[0]);
   }
   writeException();
   getVisaFeeCounts();
   if (m_strCUST_ID == m_strINTERNAL)
   {
      int lExcludeCaseType3 = 1;
      Extract::instance()->getLong("DUSER   ","EXCLCT3=",&lExcludeCaseType3);
      if (lExcludeCaseType3)
      {
         memset(m_pEMSExceptionBillingRecord,' ',sizeof(EMSExceptionBillingRecord));
         memcpy(m_pEMSExceptionBillingRecord->sCustomerID,m_strCUST_ID.data(),m_strCUST_ID.length());
         m_pEMSExceptionBillingRecord->cCaseType = '3';
         memset(m_pEMSExceptionBillingRecord->sKeyEnteredCount,'0',72);
         m_hQuery[2].reset();
         m_hQuery[2].bind("INSTITUTION","PROC_ID",Column::STRING,&m_strPROC_ID);
         m_hQuery[2].bind("INSTITUTION","INST_ID",Column::STRING,&m_strINST_ID);
         m_hQuery[2].setQualifier("QUALIFY","INSTITUTION");
         m_hQuery[2].setBasicPredicate("INSTITUTION","CUST_ID","=",m_strCUST_ID.c_str());
         m_hQuery[2].setBasicPredicate("INSTITUTION","CC_STATE","IN","('A','I')");
         m_hQuery[2].setOrderByClause("PROC_ID,INST_ID");
         if (!pSelectStatement->execute(m_hQuery[2]))
            return UseCase::setSuccess(false);
      }
   }
   memset(hMemory,' ',100);
   char *szTrailer = (char*)hMemory;
   if (m_bDailyBilling)
   {
      memset(szTrailer,' ',100);
      memcpy(szTrailer,m_strBillingDate.data(),8);
      szTrailer += 9;
      char szTemp[10];
      for (int k = 0; k < 7; k++)
      {
         snprintf(szTemp,sizeof(szTemp),"%9d",m_lCountTotals[k]);
         memcpy(szTrailer,szTemp,9);
         szTrailer += 10;
      }
     m_pFlatFile[0]->write(hMemory,100);
   }
   else
   if (m_bBillOrbit)
   {
      szTrailer[0] = 'T';
      szTrailer += 1;
      char szTemp[10];
      for (int k = 0; k < 7; k++)
      {
         snprintf(szTemp,sizeof(szTemp),"%09d",m_lCountTotals[k]);
         memcpy(szTrailer,szTemp,9);
         szTrailer += 9;
      }
      m_pFlatFile[0]->write(hMemory,100);
   }
   if (m_bDailyBilling)
      Console::display("ST544","DLY EMS"); // ST544 - @@@@@@@@@ FILE PROCESSING COMPLETE
   else
      Console::display("ST544","EMS CNTS"); // ST544 - @@@@@@@@@ FILE PROCESSING COMPLETE
   return true;
  //## end EMSBilling::createExceptionBillingFile%39A533E900DD.body
}

bool EMSBilling::createFraudAndFeeBillingFile ()
{
  //## begin EMSBilling::createFraudAndFeeBillingFile%3ED53EA403B9.body preserve=yes
   if (!m_bDailyBilling)
   {
      m_pFlatFile[1] = new FlatFile("FCOUNT  ");
      m_pFlatFile[1]->setName("FCOUNT  ");
      if (!m_pFlatFile[1]->open(FlatFile::CX_OPEN_OUTPUT))
         return UseCase::setSuccess(false);
   }
   Memory hMemory(100);
   char *szHeader = (char*)hMemory;
   if (m_bDailyBilling)
   {
     memset(szHeader, ' ', 100);
     m_pFlatFile[0]->write(hMemory,100);
     memcpy(szHeader, "                              DAILY DN FRAUD/FEE COUNTS", 55);
     m_pFlatFile[0]->write(hMemory,100);
     memset(szHeader, ' ', 100);
     m_pFlatFile[0]->write(hMemory,100);
     Trace::put(" WRITE FEE");
     memcpy(szHeader, "DATE          FEE       FDRA", 28);
     m_pFlatFile[0]->write(hMemory,100);
   }
   else
   if (m_bBillOrbit)
   {
      m_pFlatFile[3] = new FlatFile("SFCOUNT  ");
      m_pFlatFile[3]->setName("SFCOUNT  ");
      if (!m_pFlatFile[3]->open(FlatFile::CX_OPEN_OUTPUT))
         return UseCase::setSuccess(false);
      szHeader[0] = 'H';
      memcpy(szHeader+1, Clock::instance()->getYYYYMMDDHHMMSS().data(),Clock::instance()->getYYYYMMDDHHMMSS().length());
      m_pFlatFile[1]->write(hMemory,15);
   }
   for (int k = 0; k < 7; k++)
      m_lCountTotals[k] = 0;
   m_hQuery[1].reset();
   m_hQuery[1].setSubSelect(true);
   m_hQuery[1].join("EMS_CASE","INNER","EMS_PHASE P","CASE_ID");
   m_hQuery[1].bind("EMS_CASE","PROC_ID_ISS",Column::STRING,&m_strPROC_ID);
   m_hQuery[1].bind("EMS_CASE","INST_ID_RECON_ISS",Column::STRING,&m_strINST_ID);
   m_hQuery[1].bind("EMS_PHASE P","REQUEST_TYPE",Column::STRING,&m_strREQUEST_TYPE);
   m_hQuery[1].bind("EMS_CASE","CASE_EXTENSION",Column::STRING,&m_strCASE_EXTENSION);
   m_hQuery[1].bind("EMS_CASE","*",Column::LONG,&m_lCount,0,"COUNT");
   string strBetweenClause;
   if (m_bDailyBilling)
      strBetweenClause ="'" + m_strBillingDate + "00000000' AND '"
                            + m_strBillingDate + "99999999'";
   else
      strBetweenClause ="'" + m_strBillingMonth + "0000000000' AND '"
                            + m_strBillingMonth + "9999999999'";

   m_hQuery[1].setBasicPredicate("EMS_PHASE P","USER_ROLE","=","I");
   m_hQuery[1].setBasicPredicate("EMS_PHASE P","TSTAMP_CREATED","BETWEEN",strBetweenClause.c_str());
   m_hQuery[1].setBasicPredicate("EMS_PHASE P","REQUEST_TYPE","IN",
      "('FEEA','FEAC','FEAD','FEIC','FEID','FDRA','NRIA')");
   m_hQuery[1].setGroupByClause
      ("PROC_ID_ISS,INST_ID_RECON_ISS,P.REQUEST_TYPE,CASE_EXTENSION");
   m_hQuery[1].setOrderByClause("INST_ID_RECON_ISS,CASE_EXTENSION");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(m_hQuery[1]))
      return UseCase::setSuccess(false);
   writeFraudFee();
   memset(hMemory, ' ', 100);
   char *szTrailer = (char*)hMemory;
   if (m_bDailyBilling)
   {
      memset(szTrailer, ' ', 100);
      memcpy(szTrailer,m_strBillingDate.data(),8);
      szTrailer += 9;
      char szTemp[10];
      for (int k = 0; k < 2; k++)
      {
         snprintf(szTemp,sizeof(szTemp),"%9d",m_lCountTotals[k]);
         memcpy(szTrailer,szTemp,9);
         szTrailer += 10;
      }
      m_pFlatFile[0]->write(hMemory,100);
   }
   else
   if (m_bBillOrbit)
   {
      szTrailer[0] = 'T';
      szTrailer += 1;
      char szTemp[10];
      for (int k = 0; k < 2; k++)
      {
         snprintf(szTemp,sizeof(szTemp),"%09d",m_lCountTotals[k]);
         memcpy(szTrailer,szTemp,9);
         szTrailer += 9;
      }
      m_pFlatFile[1]->write(hMemory,100);
   }
   if (m_bDailyBilling)
      Console::display("ST544","DLY FRD"); // ST544 - @@@@@@@@@ FILE PROCESSING COMPLETE
   else
      Console::display("ST544","FRDFEE"); // ST544 - @@@@@@@@@ FILE PROCESSING COMPLETE
   return true;
  //## end EMSBilling::createFraudAndFeeBillingFile%3ED53EA403B9.body
}

string EMSBilling::getHomeProc (const string& strHomeSwitch)
{
  //## begin EMSBilling::getHomeProc%40ACAC7A00EA.body preserve=yes
   string strProc;
   string strInstSwitchKey = m_strINST_ID + strHomeSwitch;
   map<string,string,less<string> >::iterator pInstProc = m_hInstProc.find(strInstSwitchKey);
   if (pInstProc != m_hInstProc.end())
      strProc = (*pInstProc).second;
   return strProc;
  //## end EMSBilling::getHomeProc%40ACAC7A00EA.body
}

const string& EMSBilling::getHomeSwitch ()
{
  //## begin EMSBilling::getHomeSwitch%3F3BD1FD03C8.body preserve=yes
   map<string,string,less<string> >::iterator pNetInstCode = m_hNetInstCode.find(m_strINST_ID);
   if (pNetInstCode != m_hNetInstCode.end())
      return (*pNetInstCode).second;
   map<string,string,less<string> >::iterator pInstitution = m_hInstitution.find(m_strINST_ID);
   if (pInstitution != m_hInstitution.end())
      return(*pInstitution).second;
   return m_strCUST_ID;
  //## end EMSBilling::getHomeSwitch%3F3BD1FD03C8.body
}

void EMSBilling::reset (bool bForce, const string& strDate, bool bDaily)
{
  //## begin EMSBilling::reset%39BE49BB031C.body preserve=yes
   m_bDailyBilling = bDaily;
   if (m_bDailyBilling)
   {
      if (strDate.length() == 0)
      {
         Date hDate(Date::today());
         hDate -= 1;
         m_strBillingDate = hDate.asString("%Y%m%d");
      }
      else
         m_strBillingDate = strDate;
      bForce = true;
   }
   int lYear = Clock::instance()->getYear();
   int lMonth = Clock::instance()->getMonth();
   if (lMonth == 1)
   {
      lYear--;
      lMonth = 12;
   }
   else
      lMonth--;
   char szYearMonth[7];
   snprintf(szYearMonth,sizeof(szYearMonth), "%04d%02d", lYear, lMonth);
   m_strContextMonth = szYearMonth;
   if (strDate.length() == 0)
      m_strBillingMonth = szYearMonth;
   else
   {
      m_strBillingMonth = strDate;
      bForce = true;
   }
   if (bForce || shouldBill())
   {
      Trace::put("forced");
      m_hTimer.attach(this);
      m_hTimer.notify();
   }
   else
      Trace::put(m_strBillingMonth.c_str());
  //## end EMSBilling::reset%39BE49BB031C.body
}

bool EMSBilling::shouldBill ()
{
  //## begin EMSBilling::shouldBill%39BE4A14039C.body preserve=yes
   string strContextData;
   auto_ptr<Context> pContext(new Context(Application::instance()->image(),Application::instance()->name()));
   pContext->get("EMSBILLING", strContextData);
   Database::instance()->commit();
   return (strContextData != m_strBillingMonth);
  //## end EMSBilling::shouldBill%39BE4A14039C.body
}

void EMSBilling::update (Subject* pSubject)
{
  //## begin EMSBilling::update%39A530F900AA.body preserve=yes
   if (pSubject == &m_hTimer)
   {
      if (createBillingFiles())
      {
         m_hTimer.detach(this);
         Database::instance()->commit();
      }
      else
      {
         Database::instance()->rollback();
         m_hTimer.set(1800);
      }
      for (int i = 0;i <= 3;++i)
         if (m_pFlatFile[i])
         {
            string strPath("PATH");
            string strValue(m_pFlatFile[i]->datasetName());
            SiteSpecification::instance()->add(strPath,strValue);
            string strDate = "D" + Clock::instance()->getYYYYMMDDHHMMSS(true).substr(2,6) + ".T" + Clock::instance()->getYYYYMMDDHHMMSS().substr(8,6);
            string strMember;
#ifndef MVS
            strMember += "##";
#endif
            strMember += m_pFlatFile[i]->getType();
            rtrim(strMember);
            m_pFlatFile[i]->close();
            Job::submit(strMember.c_str(),"&DATE   ",strDate.c_str());
            delete m_pFlatFile[i];
            m_pFlatFile[i] = 0;
         }
      return;
   }
   if (pSubject == &m_hQuery[0])
   {
      if (m_strNextREQUEST_TYPE == "UNW1"
         || m_strNextREQUEST_TYPE == "UNW2"
         || m_strNextREQUEST_TYPE == "UNW3")
      {
         if (m_bDailyBilling)
         {
            if (m_strCASE_NO.substr(0,6) != m_strBillingDate.substr(0,6)
               || (m_strCASE_NO == m_strCurrentCASE_NO && !m_bFirst))
            {
               m_strNextREQUEST_TYPE = "";
               return;
            }
         }
         else
         {
            if (m_strCASE_NO.substr(0,6) != m_strBillingMonth
               || (m_strCASE_NO == m_strCurrentCASE_NO && !m_bFirst))
            {
               m_strNextREQUEST_TYPE = "";
               return;
            }
         }
         m_strCurrentCASE_NO = m_strCASE_NO;
      }
      if (m_bFirst)
      {
         m_strPROC_ID = m_strNextPROC_ID;
         m_strINST_ID = m_strNextINST_ID;
         m_strREQUEST_TYPE = m_strNextREQUEST_TYPE;
         m_strNET_ID_EMS = m_strNextNET_ID_EMS;
         m_bFirst = false;
         return;
      }
      if ((m_strPROC_ID == m_strNextPROC_ID) && (m_strREQUEST_TYPE == m_strNextREQUEST_TYPE)
         && (m_strINST_ID == m_strNextINST_ID) && (m_strNET_ID_EMS == m_strNextNET_ID_EMS))
      {
         m_iCaseCount++;
         return;
      }
      m_lCount = m_iCaseCount;
      if (m_strINST_ID.length() == 0)
         m_strINST_ID = "           ";
      if (memcmp(m_pEMSExceptionBillingRecord->sInstitutionID,m_strINST_ID.data(),m_strINST_ID.length()))
         writeException();
      int i = 1; // CDC (internal) exception cases
      if (m_strCUST_ID == m_strINTERNAL)
         i = (m_strREQUEST_TYPE == "DOC7" || m_strREQUEST_TYPE == "DOC8"
            || m_strREQUEST_TYPE == "ARB" || m_strREQUEST_TYPE == "COMP") ? 2 : 1;
     else
     {
        if (m_bRegional)
           i = 5; //external regional cases
        else
           i = m_strNET_ID_EMS == "MCI" || m_strNET_ID_EMS == "VNT" ? 4 : 5;
     }
      int j = 0;
      if (m_strCUST_ID == m_strINTERNAL)
      {
         char szREQUEST_TYPE[29] = {"UNW1DOCRCHB1REP1CHB2DOC7DOC8"};
         char* p = strstr(szREQUEST_TYPE,m_strREQUEST_TYPE.c_str());
         if (p)
            j = (p - szREQUEST_TYPE) / 4;
         else if (m_strREQUEST_TYPE == "UNW2" || m_strREQUEST_TYPE == "UNW3")
            j = 0;
		 else if (m_strREQUEST_TYPE == "ARB" || m_strREQUEST_TYPE == "COMP")
		 {
			 j = 5;
			 m_lExceptionCount[12][0] += m_lCount;
		 }
         m_lExceptionCount[i][j] += m_lCount;
      }
      else
      {
         char szREQUEST_TYPE[21] = {"INITDOCRCHB1REP1CHB2"};
         char* p = strstr(szREQUEST_TYPE,m_strREQUEST_TYPE.c_str());
         if (p)
            j = (p - szREQUEST_TYPE) / 4;
		 if (m_strREQUEST_TYPE == "ARB" || m_strREQUEST_TYPE == "COMP")
		 {
			 j = 5;
		 }
         m_lExceptionCount[i][j] += m_lCount;
      }
     if (m_strREQUEST_TYPE == "CHBQ" && m_strSTATUS == "SDRC" && m_strVCR_IND == "Y")
        m_lExceptionCount[13][0] += m_lCount;
      m_lCountTotals[j] += m_lCount;
      m_strPROC_ID = m_strNextPROC_ID;
      m_strINST_ID = m_strNextINST_ID;
      m_strREQUEST_TYPE = m_strNextREQUEST_TYPE;
      m_strNET_ID_EMS = m_strNextNET_ID_EMS;
      m_iCaseCount = 1;
      return;
   }
   if (pSubject == &m_hQuery[1])
   {
      int i = 0;
      if (memcmp(m_pEMSFraudAndFeeBillingRecord->sInstitutionID, m_strINST_ID.data(), m_strINST_ID.length()))
         writeFraudFee();
      if (m_strCASE_EXTENSION == "VNT" || m_strCASE_EXTENSION == "MCI")
      {
         if (m_strREQUEST_TYPE == "FEEA" || m_strREQUEST_TYPE == "FEAC" ||
            m_strREQUEST_TYPE == "FEAD" || m_strREQUEST_TYPE == "FEIC" || m_strREQUEST_TYPE == "FEID")
         {
            i = m_strNET_ID_EMS == "VNT" ? 5 : 6;
            m_lCountTotals[0] += m_lCount;
         }
         else
         {
            i = m_strCASE_EXTENSION == "VNT" ? 1 : 3;
            if (m_strCUST_ID == m_strINTERNAL)
               ++i;
            m_lCountTotals[1] += m_lCount;
         }
         m_lFraudFeeCount[i] += m_lCount;
      }
      else
      {
         i = 7;
         m_lCountTotals[1] += m_lCount;
         m_lFraudFeeCount[i] += m_lCount;
      }
      return;
   }
   if (pSubject == &m_hQuery[2])
   {
      if (!m_bDailyBilling)
      {
         string strHomeSwitch = getHomeSwitch();
         memcpy(m_pEMSExceptionBillingRecord->sCustomerID,strHomeSwitch.data(),strHomeSwitch.length());
         memcpy(m_pEMSExceptionBillingRecord->sProcessorID,m_strPROC_ID.data(),m_strPROC_ID.length());
         memcpy(m_pEMSExceptionBillingRecord->sInstitutionID,"           ",11);
         memcpy(m_pEMSExceptionBillingRecord->sInstitutionID,m_strINST_ID.data(),m_strINST_ID.length());
         if (m_pFlatFile[2])
         {
            m_pFlatFile[2]->write((char*)m_pEMSExceptionBillingRecord,sizeof(EMSExceptionBillingRecord));
            Memory hMemory(87);
            char *sBillingRecord = (char*)hMemory;
            memcpy(sBillingRecord,m_pEMSExceptionBillingRecord,87);
            m_pFlatFile[0]->write(hMemory,87);
         }
         else
            m_pFlatFile[0]->write((char*)m_pEMSExceptionBillingRecord,sizeof(EMSExceptionBillingRecord));
      }
   }
   if (pSubject == &m_hQuery[3])
   {
      m_hInstitution.insert(map<string,string,less<string> >::value_type(m_strINST_ID,m_strInstCustID));
      return;
   }
   if (pSubject == &m_hQuery[4])
   {
      m_hNetInstCode.insert(map<string,string,less<string> >::value_type(m_strINST_ID,m_strInstCustID));
      return;
   }
   if (pSubject == &m_hQuery[5])
   {
      string strInstSwitchKey = m_strINST_ID + m_strInstCustID;
      m_hInstProc.insert(map<string,string,less<string> >::value_type(strInstSwitchKey,m_strPROC_ID));
      return;
   }

   if (((Query*)pSubject)->getIndex() == 1)
   {
	   m_lExceptionCount[6][0] += m_lCount;
	   memcpy(m_pEMSExceptionBillingRecord->sCustomerID, m_strCUST_ID.data(), m_strCUST_ID.length());
	   memcpy(m_pEMSExceptionBillingRecord->sProcessorID, m_strPROC_ID.data(), m_strPROC_ID.length());
	   memcpy(m_pEMSExceptionBillingRecord->sInstitutionID, m_strINST_ID.data(), m_strINST_ID.length());
	   writeException();
	   return;
   }
   if (((Query*)pSubject)->getIndex() == 2)
   {
	   int i, j = 0;
	   if (m_strFEE_BILLING_CODE == "AcptT2")
		   i = 7;

	   if (m_strFEE_BILLING_CODE == "AcptT3")
		   i = 8;

	   if (m_strFEE_BILLING_CODE == "RespT1")
		   i = 9;

	   if (m_strFEE_BILLING_CODE == "RespT2")
		   i = 10;

	   if (m_strFEE_BILLING_CODE == "RespT3")
		   i = 11;
	   m_lExceptionCount[i][j] += m_lCount;
	   memcpy(m_pEMSExceptionBillingRecord->sCustomerID, m_strCUST_ID.data(), m_strCUST_ID.length());
	   memcpy(m_pEMSExceptionBillingRecord->sProcessorID, m_strPROC_ID.data(), m_strPROC_ID.length());
	   memcpy(m_pEMSExceptionBillingRecord->sInstitutionID, m_strINST_ID.data(), m_strINST_ID.length());
	   writeException();
	   return;
   }
   if (pSubject == MinuteTimer::instance())
   {
      Clock::instance()->getYYYYMMDDHHMMSS(true);
      reset(true,"");
      MinuteTimer::instance()->detach(this);
      return;
   }
  //## end EMSBilling::update%39A530F900AA.body
}

bool EMSBilling::writeException ()
{
  //## begin EMSBilling::writeException%3F0EA2DE034B.body preserve=yes
   if (m_bDailyBilling)
      return true;
   if (m_pEMSExceptionBillingRecord->sCustomerID[0] != ' ')
   {
      for (int i = 1;i <= 14;++i)
      {
         int j = 0;
         int k = 0;
         for (j = 0;j <= 6;++j)
            k += m_lExceptionCount[i][j];
         if (k > 0)
         {
            char szCaseType[15] = {"0123456789ABCD"};
            m_pEMSExceptionBillingRecord->cCaseType = szCaseType[i];
            char szTemp[10];
            char* p = m_pEMSExceptionBillingRecord->sKeyEnteredCount;
            for (j = 0;j <= 6;++j)
            {
               snprintf(szTemp,sizeof(szTemp),"%09d",m_lExceptionCount[i][j]);
               memcpy(p,szTemp,9);
               p += 9;
               m_lExceptionCount[i][j] = 0;
            }
            snprintf(szTemp,sizeof(szTemp),"%09d",k);
            memcpy(p,szTemp,9);
            if (m_pFlatFile[2])
            {
               m_pFlatFile[2]->write((char*)m_pEMSExceptionBillingRecord,96);
               Memory hMemory(87);
               char *sBillingRecord = (char*)hMemory;
               memcpy(sBillingRecord,m_pEMSExceptionBillingRecord,87);
               m_pFlatFile[0]->write(hMemory,87);
            }
            else
               m_pFlatFile[0]->write((char*)m_pEMSExceptionBillingRecord,96);
            UseCase::addItem();
         }
      }
   }
   memset(m_pEMSExceptionBillingRecord,' ',sizeof(EMSExceptionBillingRecord));
   // get the home switch of the inst
   string strHomeSwitch = getHomeSwitch();
   string strHomeProc = getHomeProc(strHomeSwitch);
   if (strHomeProc.length() == 0)
      strHomeProc = m_strPROC_ID;
   memcpy(m_pEMSExceptionBillingRecord->sCustomerID,strHomeSwitch.data(),strHomeSwitch.length());
   memcpy(m_pEMSExceptionBillingRecord->sProcessorID,strHomeProc.data(),strHomeProc.length());
   memcpy(m_pEMSExceptionBillingRecord->sInstitutionID,m_strINST_ID.data(),m_strINST_ID.length());
   return true;
  //## end EMSBilling::writeException%3F0EA2DE034B.body
}

bool EMSBilling::writeFraudFee ()
{
  //## begin EMSBilling::writeFraudFee%3F0E9DD5030D.body preserve=yes
   if (m_bDailyBilling)
      return true;
   if (m_pEMSFraudAndFeeBillingRecord->sCustomerID[0] != ' ')
   {
      for (int i = 1;i <= 7;++i)
      {
         if (m_lFraudFeeCount[i] > 0)
         {
            char szCaseType[9] = {"01234567"};
            m_pEMSFraudAndFeeBillingRecord->cCaseType = szCaseType[i];
            char szTemp[10];
            snprintf(szTemp,sizeof(szTemp),"%09d",m_lFraudFeeCount[i]);
            memcpy(m_pEMSFraudAndFeeBillingRecord->sCount,szTemp,9);
            m_pFlatFile[1]->write((char*)m_pEMSFraudAndFeeBillingRecord,33);
            if (m_pFlatFile[3])
               m_pFlatFile[3]->write((char*)m_pEMSFraudAndFeeBillingRecord,33);
            UseCase::addItem();
            m_lFraudFeeCount[i] = 0;
         }
      }
   }
   memset(m_pEMSFraudAndFeeBillingRecord,' ',sizeof(EMSFraudAndFeeBillingRecord));
   memcpy(m_pEMSFraudAndFeeBillingRecord->sCustomerID,m_strCUST_ID.data(),m_strCUST_ID.length());
   memcpy(m_pEMSFraudAndFeeBillingRecord->sProcessorID,m_strPROC_ID.data(),m_strPROC_ID.length());
   memcpy(m_pEMSFraudAndFeeBillingRecord->sInstitutionID,m_strINST_ID.data(),m_strINST_ID.length());
   return true;
  //## end EMSBilling::writeFraudFee%3F0E9DD5030D.body
}

bool EMSBilling::getVisaFeeCounts ()
{
  //## begin EMSBilling::getVisaFeeCounts%5AA0EE1C00B0.body preserve=yes
	Query hQuery;
	string strBetweenClause = "'" + m_strBillingMonth + "0000000000' AND '" + m_strBillingMonth + "9999999999'";;
	if (!m_bDailyBilling)
	{
		hQuery.reset();
		hQuery.attach(this);
		hQuery.setIndex(1);
		hQuery.setQualifier("CUSTQUAL", "API_QUEUE_CONTROL Q");
		hQuery.bind("EMS_CASE C", "INST_ID_RECON_ISS", Column::STRING, &m_strINST_ID);
		hQuery.setQualifier("QUALIFY", "INSTITUTION I");
		hQuery.bind("INSTITUTION I", "PROC_ID", Column::STRING, &m_strPROC_ID);
		hQuery.bind("API_QUEUE_CONTROL Q", "*", Column::LONG, &m_lCount, 0, "COUNT");
		hQuery.join("API_QUEUE_CONTROL Q", "INNER", "EMS_CASE C", "CASE_ID");
		hQuery.join("EMS_CASE C", "INNER", "INSTITUTION I", "INST_ID_RECON_ISS", "INST_ID");
		hQuery.setBasicPredicate("INSTITUTION I", "CUST_ID", "=", m_strCUST_ID.c_str());
		hQuery.setBasicPredicate("API_QUEUE_CONTROL Q", "REQ_TYPE", "=", "TII");
		hQuery.setBasicPredicate("API_QUEUE_CONTROL Q", "API_STATE", "=", "AC");
		hQuery.setBasicPredicate("API_QUEUE_RESULT Q", "API_RESULT", "NOT LIKE", "Internal Error%");
		hQuery.setBasicPredicate("API_QUEUE_CONTROL Q", "TSTAMP_EVENT", "BETWEEN", strBetweenClause.c_str());
		hQuery.setGroupByClause("C.INST_ID_RECON_ISS,I.PROC_ID");
		auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
		if (!pSelectStatement->execute(hQuery))
		{
			Database::instance()->rollback();
			return false;
		}
		writeException();
		Trace::put("Calling 2nd time query");
		hQuery.reset();
		hQuery.attach(this);
		hQuery.setIndex(2);
		m_strINST_ID = "";
		m_strPROC_ID = "";
		hQuery.setDistinct(true);
		hQuery.bind("FEE_BILLING", "FEE_DATA", Column::STRING, &m_strFEE_BILLING_CODE);
		hQuery.bind("FEE_BILLING", "ITEM_COUNT", Column::LONG, &m_lCount);
		hQuery.bind("FEE_BILLING", "ENTITY_ID", Column::STRING, &m_strINST_ID);
		hQuery.setQualifier("QUALIFY", "INSTITUTION");
		hQuery.bind("INSTITUTION", "PROC_ID", Column::STRING, &m_strPROC_ID);
		hQuery.join("FEE_BILLING", "INNER", "INSTITUTION", "ENTITY_ID", "INST_ID");
		hQuery.setBasicPredicate("INSTITUTION", "CUST_ID", "=", m_strCUST_ID.c_str());
		hQuery.setBasicPredicate("FEE_BILLING", "FEE_TYPE", "=", "VCR");
		hQuery.setBasicPredicate("FEE_BILLING", "FEE_DATE", "=", m_strBillingMonth.c_str());
		hQuery.setBasicPredicate("FEE_BILLING", "FEE_DATA", "IN", "('AcptT2','AcptT3','RespT1','RespT2','RespT3')");
		hQuery.setOrderByClause("FEE_BILLING.FEE_DATA,FEE_BILLING.ENTITY_ID");
		if (!pSelectStatement->execute(hQuery))
		{
			Database::instance()->rollback();
			return false;
		}
		writeException();
	}

	return true;
  //## end EMSBilling::getVisaFeeCounts%5AA0EE1C00B0.body
}

// Additional Declarations
  //## begin EMSBilling%39A52EAA0078.declarations preserve=yes
  //## end EMSBilling%39A52EAA0078.declarations

// Class EMSExceptionBillingRecord 

// Class EMSFraudAndFeeBillingRecord 

//## begin module%39A530C201FF.epilog preserve=yes
//## end module%39A530C201FF.epilog
