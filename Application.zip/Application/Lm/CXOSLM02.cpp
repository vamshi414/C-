//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39B4F4C3014F.cm preserve=no
// $Date:   May 20 2020 16:46:44  $ $Author:   e1009510  $
// $Revision:   1.14  $
//## end module%39B4F4C3014F.cm

//## begin module%39B4F4C3014F.cp preserve=no
// Copyright (c) 1997 - 2012
// FIS
//## end module%39B4F4C3014F.cp

//## Module: CXOSLM02%39B4F4C3014F; Package body
//## Subsystem: LM%3597EB1A028A
// .
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Application\Lm\CXOSLM02.cpp

//## begin module%39B4F4C3014F.additionalIncludes preserve=no
//## end module%39B4F4C3014F.additionalIncludes

//## begin module%39B4F4C3014F.includes preserve=yes
#include "CXODIF11.hpp"
#include "CXODIF44.hpp"
//## end module%39B4F4C3014F.includes

#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU19_h
#include "CXODRU19.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSLM02_h
#include "CXODLM02.hpp"
#endif


//## begin module%39B4F4C3014F.declarations preserve=no
//## end module%39B4F4C3014F.declarations

//## begin module%39B4F4C3014F.additionalDeclarations preserve=yes
//## end module%39B4F4C3014F.additionalDeclarations


// Class TransactionBilling

TransactionBilling::TransactionBilling()
  //## begin TransactionBilling::TransactionBilling%39B4F4FB025E_const.hasinit preserve=no
      : m_lCount(0)
  //## end TransactionBilling::TransactionBilling%39B4F4FB025E_const.hasinit
  //## begin TransactionBilling::TransactionBilling%39B4F4FB025E_const.initialization preserve=yes
   ,m_hFlatFile("TRNCNT  ")
  //## end TransactionBilling::TransactionBilling%39B4F4FB025E_const.initialization
{
  //## begin TransactionBilling::TransactionBilling%39B4F4FB025E_const.body preserve=yes
   memcpy(m_sID, "LM02", 4);
   m_pMemory = new Memory(sizeof(*m_pTransactionBillingRecord));
   m_pTransactionBillingRecord = (struct TransactionBillingRecord*) (char*) *m_pMemory;
  //## end TransactionBilling::TransactionBilling%39B4F4FB025E_const.body
}


TransactionBilling::~TransactionBilling()
{
  //## begin TransactionBilling::~TransactionBilling%39B4F4FB025E_dest.body preserve=yes
   delete m_pMemory;
  //## end TransactionBilling::~TransactionBilling%39B4F4FB025E_dest.body
}



//## Other Operations (implementation)
bool TransactionBilling::createBillingFile ()
{
  //## begin TransactionBilling::createBillingFile%39B4F5E002E0.body preserve=yes
   UseCase hUseCase("DR","## DR42 BILL FOR TRANSACTIONS");
   m_hQuery[0].attach(this);
   m_hQuery[1].attach(this);
   if (!m_hFlatFile.open(FlatFile::CX_OPEN_OUTPUT))
   {
      UseCase::setSuccess(false);
      return false;
   }
   short iNull;
   string strCustomerID;
   string strPROC_GRP_ID;
   string strLocator("FIN_L" + m_strBillingMonth);
   Extract::instance()->getSpec("CUSTOMER", strCustomerID);
   memset(m_pTransactionBillingRecord, ' ', sizeof(*m_pTransactionBillingRecord));
   memcpy(m_pTransactionBillingRecord->sVersionID, "10", 2);
   memcpy(m_pTransactionBillingRecord->sCreateDate, Clock::instance()->getDate().data(), 8);
   memset(m_pTransactionBillingRecord->sCreateTime, '0', 8);
   memcpy(m_pTransactionBillingRecord->sCreateTime, Clock::instance()->getTime().data(), 6);
   memcpy(m_pTransactionBillingRecord->sCustomerID, strCustomerID.data(), 4);
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_hQuery[0].reset();
   m_hQuery[0].bind(strLocator.c_str(), "PROC_ID_ACQ", Column::STRING, &m_strPROC_ID);
   m_hQuery[0].bind(strLocator.c_str(), "INST_ID_RECON_ACQ", Column::STRING, &m_strINST_ID);
   m_hQuery[0].bind(strLocator.c_str(), "*", Column::LONG, &m_lCount, &iNull, "COUNT");
   m_hQuery[0].setQualifier("QUALIFY","PROCESSOR");
   m_hQuery[0].join(strLocator.c_str(),"INNER","PROCESSOR","PROC_ID_ACQ","PROC_ID");
   m_hQuery[0].setBasicPredicate("PROCESSOR", "CUST_ID", "=", strCustomerID.c_str());
   m_hQuery[0].setGroupByClause("PROC_ID_ACQ,INST_ID_RECON_ACQ");
   if (!pSelectStatement->execute(m_hQuery[0]))
   {
      UseCase::setSuccess(false);
      return false;
   }
   m_hQuery[1].reset();
   m_hQuery[1].bind(strLocator.c_str(), "PROC_ID_ISS", Column::STRING, &m_strPROC_ID);
   m_hQuery[1].bind(strLocator.c_str(), "INST_ID_RECON_ISS", Column::STRING, &m_strINST_ID);
   m_hQuery[1].bind(strLocator.c_str(), "*", Column::LONG, &m_lCount, &iNull, "COUNT");
   m_hQuery[1].setQualifier("QUALIFY","PROCESSOR");
   m_hQuery[1].join(strLocator.c_str(),"INNER","PROCESSOR","PROC_ID_ISS","PROC_ID");
   m_hQuery[1].setBasicPredicate("PROCESSOR", "CUST_ID", "=", strCustomerID.c_str());
   m_hQuery[1].setGroupByClause("PROC_ID_ISS,INST_ID_RECON_ISS");
   memcpy(m_pTransactionBillingRecord->sRecordID, "DN003", 5);
   if (!pSelectStatement->execute(m_hQuery[1]))
   {
      UseCase::setSuccess(false);
      return false;
   }
   string strCondition(" AND " + strLocator + ".INST_ID_RECON_ISS");
   strCondition += " = " + strLocator + ".INST_ID_RECON_ACQ";
   m_hQuery[1].getSearchCondition().append(strCondition);
   m_hQuery[1].setGroupByClause("PROC_ID_ISS,INST_ID_RECON_ISS");
   memcpy(m_pTransactionBillingRecord->sRecordID, "DN004", 5);
   if (!pSelectStatement->execute(m_hQuery[1]))
   {
      UseCase::setSuccess(false);
      return false;
   }

   char szCount[10];
   map<string,TransactionCount ,less<string> >::iterator ptran;
   for (ptran = m_pTransactionBilling.begin();ptran != m_pTransactionBilling.end();++ptran)
   {
     struct TransactionCount m_pTranCount = (*ptran).second;
      memcpy(m_pTransactionBillingRecord->sInstitutionID, m_pTranCount.sInstitutionID,11);
      memcpy(m_pTransactionBillingRecord->sProcessorID, m_pTranCount.sProcessorID,8);
     if((m_pTranCount.lAcqCount >0 )&& ( m_pTranCount.lIssCount==0 )&& ( m_pTranCount.lOnUsCount==0 ))
     {
        memcpy(m_pTransactionBillingRecord->sRecordID, "DN002", 5);
          snprintf(szCount,sizeof(szCount), "%09d", m_pTranCount.lAcqCount);
          memcpy(m_pTransactionBillingRecord->sTranCount,szCount, 9);
     }
     if((m_pTranCount.lAcqCount==0)&&(m_pTranCount.lIssCount>0)&&(m_pTranCount.lOnUsCount==0))
     {
        memcpy(m_pTransactionBillingRecord->sRecordID, "DN003", 5);
          snprintf(szCount,sizeof(szCount), "%09d", m_pTranCount.lIssCount);
          memcpy(m_pTransactionBillingRecord->sTranCount,szCount, 9);
     }
     if((m_pTranCount.lAcqCount==0)&&(m_pTranCount.lIssCount==0)&&(m_pTranCount.lOnUsCount>0))
     {
        memcpy(m_pTransactionBillingRecord->sRecordID, "DN004", 5);
          snprintf(szCount,sizeof(szCount), "%09d", m_pTranCount.lOnUsCount);
          memcpy(m_pTransactionBillingRecord->sTranCount,szCount, 9);
     }
     if((m_pTranCount.lAcqCount>0)&&(m_pTranCount.lIssCount>0)&&(m_pTranCount.lOnUsCount==0))
      {
        int ltemp = m_pTranCount.lAcqCount + m_pTranCount.lIssCount;
        snprintf(szCount,sizeof(szCount), "%09d", ltemp);
        memcpy(m_pTransactionBillingRecord->sRecordID, "DN005", 5);
        memcpy(m_pTransactionBillingRecord->sTranCount,szCount, 9);
     }
     if((m_pTranCount.lAcqCount>0)&&(m_pTranCount.lIssCount>0)&&(m_pTranCount.lOnUsCount >0))
     {
        int ltemp = m_pTranCount.lAcqCount+m_pTranCount.lIssCount;
        ltemp = ltemp - m_pTranCount.lOnUsCount;
          snprintf(szCount,sizeof(szCount), "%09d", ltemp);
        memcpy(m_pTransactionBillingRecord->sRecordID, "DN000", 5);
        memcpy(m_pTransactionBillingRecord->sTranCount,szCount, 9);
     }
      m_hFlatFile.write((char*) m_pTransactionBillingRecord, sizeof(*m_pTransactionBillingRecord));
   }
   auto_ptr<Context> pContext(new Context(Application::instance()->image(),Application::instance()->name()));
   return pContext->put("TRANBILLING", m_strBillingMonth.c_str());
  //## end TransactionBilling::createBillingFile%39B4F5E002E0.body
}

void TransactionBilling::reset (bool bForce, const string& strDate)
{
  //## begin TransactionBilling::reset%39BE4A290126.body preserve=yes
   int lYear = Clock::instance()->getYear();
   int lMonth = Clock::instance()->getMonth();
   if (lMonth == 1)
   {
      lYear--;
      lMonth = 12;
   }
   else
      lMonth--;

   char szYearMonth[7];
   snprintf(szYearMonth,sizeof(szYearMonth), "%04d%02d", lYear, lMonth);
   if (strDate.length() == 0)
      m_strBillingMonth = szYearMonth;
   else
   {
      m_strBillingMonth = strDate;
      bForce = true;
   }
   if (bForce || shouldBill())
   {
      m_hTimer.attach(this);
      m_hTimer.notify();
   }
  //## end TransactionBilling::reset%39BE4A290126.body
}

bool TransactionBilling::shouldBill ()
{
  //## begin TransactionBilling::shouldBill%39BE4A290128.body preserve=yes
   string strContextData;
   auto_ptr<Context> pContext(new Context(Application::instance()->image(),Application::instance()->name()));
   pContext->get("TRANBILLING", strContextData);
   Database::instance()->commit();
   return (strContextData != m_strBillingMonth);
  //## end TransactionBilling::shouldBill%39BE4A290128.body
}

void TransactionBilling::update (Subject* pSubject)
{
  //## begin TransactionBilling::update%39B4F5E002E1.body preserve=yes
   if (pSubject == &m_hTimer)
   {
      bool bSuccess = createBillingFile();
      string strPath("PATH");
      string strValue(m_hFlatFile.datasetName());
      SiteSpecification::instance()->add(strPath,strValue);
      string strDate = "D" + Clock::instance()->getYYYYMMDDHHMMSS(true).substr(2,6) + ".T" + Clock::instance()->getYYYYMMDDHHMMSS().substr(8,6);
      string strMember;
#ifndef MVS
      strMember += "##";
#endif
      strMember += m_hFlatFile.getType();
      rtrim(strMember);
      m_hFlatFile.close();
      Job::submit(strMember.c_str(),"&DATE   ",strDate.c_str());
      if (bSuccess)
      {
         m_hTimer.detach(this);
         Database::instance()->commit();
         Job::submit("DN##TBIL");
      }
      else
      {
         Database::instance()->rollback();
         m_hTimer.set(1800);
      }
      return;
   }

   if (pSubject == &m_hQuery[0])
   {
     struct TransactionCount m_pTranCount;
     memset(&m_pTranCount,' ',sizeof(m_pTranCount));
     memcpy(m_pTranCount.sInstitutionID, m_strINST_ID.data(), m_strINST_ID.length());
     memcpy(m_pTranCount.sProcessorID, m_strPROC_ID.data(), m_strPROC_ID.length());
     m_pTranCount.lAcqCount = m_lCount;
     m_pTranCount.lIssCount = 0;
     m_pTranCount.lOnUsCount = 0;
     m_pTransactionBilling.insert(map<string,TransactionCount ,less<string> >::value_type(m_strINST_ID,m_pTranCount));
   }
   if (pSubject == &m_hQuery[1] && !memcmp(m_pTransactionBillingRecord->sRecordID, "DN003", 5))
   {
     map<string,TransactionCount ,less<string> >::iterator ptran;
      ptran = m_pTransactionBilling.find(m_strINST_ID);
     if(ptran!=m_pTransactionBilling.end())
        (*ptran).second.lIssCount = m_lCount;
     else
      {
        struct TransactionCount m_pTranCount;
        memset(&m_pTranCount,' ',sizeof(m_pTranCount));
        memcpy(m_pTranCount.sInstitutionID, m_strINST_ID.data(), m_strINST_ID.length());
        memcpy(m_pTranCount.sProcessorID, m_strPROC_ID.data(), m_strPROC_ID.length());
        m_pTranCount.lAcqCount = 0;
        m_pTranCount.lIssCount = m_lCount;
        m_pTranCount.lOnUsCount = 0;
        m_pTransactionBilling.insert(map<string,TransactionCount ,less<string> >::value_type(m_strINST_ID,m_pTranCount));
      }
   }
   if(pSubject == &m_hQuery[1] && !memcmp(m_pTransactionBillingRecord->sRecordID, "DN004", 5))
   {
     map<string,TransactionCount ,less<string> >::iterator ptran;
     ptran = m_pTransactionBilling.find(m_strINST_ID);
     if(ptran!=m_pTransactionBilling.end())
      (*ptran).second.lOnUsCount = m_lCount;
     else
     {
        struct TransactionCount m_pTranCount;
        memset(&m_pTranCount,' ',sizeof(m_pTranCount));
        memcpy(m_pTranCount.sInstitutionID, m_strINST_ID.data(), m_strINST_ID.length());
        memcpy(m_pTranCount.sProcessorID, m_strPROC_ID.data(), m_strPROC_ID.length());
        m_pTranCount.lAcqCount = 0;
        m_pTranCount.lIssCount = 0;
        m_pTranCount.lOnUsCount = m_lCount;
        m_pTransactionBilling.insert(map<string,TransactionCount ,less<string> >::value_type(m_strINST_ID,m_pTranCount));
     }
   }
  //## end TransactionBilling::update%39B4F5E002E1.body
}

// Additional Declarations
  //## begin TransactionBilling%39B4F4FB025E.declarations preserve=yes
  //## end TransactionBilling%39B4F4FB025E.declarations

//## begin module%39B4F4C3014F.epilog preserve=yes
//## end module%39B4F4C3014F.epilog
