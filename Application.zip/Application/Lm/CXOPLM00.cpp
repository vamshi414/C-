//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%366FDCCA011D.cm preserve=no
//	$Date:   Feb 12 2021 22:39:32  $ $Author:   e3027760  $
//	$Revision:   1.105.2.13  $
//## end module%366FDCCA011D.cm

//## begin module%366FDCCA011D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%366FDCCA011D.cp

//## Module: CXOPLM00%366FDCCA011D; Package body
//## Subsystem: LM%3597EB1A028A
//	.
//## Source file: D:\WorkSpace-Server\V03.2A.R001\Dn\Server\Application\Lm\CXOPLM00.cpp

//## begin module%366FDCCA011D.additionalIncludes preserve=no
//## end module%366FDCCA011D.additionalIncludes

//## begin module%366FDCCA011D.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#ifdef _WIN32
#include <winsock2.h>
#endif
#define TOKENIZE 0
#define DETOKENIZE 1
//## end module%366FDCCA011D.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSPC05_h
#include "CXODPC05.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSBC18_h
#include "CXODBC18.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF01_h
#include "CXODIF01.hpp"
#endif
#ifndef CXOSDB03_h
#include "CXODDB03.hpp"
#endif
#ifndef CXOSRC14_h
#include "CXODRC14.hpp"
#endif
#ifndef CXOSRC15_h
#include "CXODRC15.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSRC16_h
#include "CXODRC16.hpp"
#endif
#ifndef CXOSRC17_h
#include "CXODRC17.hpp"
#endif
#ifndef CXOSRU39_h
#include "CXODRU39.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSRF21_h
#include "CXODRF21.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSDB33_h
#include "CXODDB33.hpp"
#endif
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
#ifndef CXOSNC27_h
#include "CXODNC27.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSAR05_h
#include "CXODAR05.hpp"
#endif
#ifndef CXOSDB15_h
#include "CXODDB15.hpp"
#endif
#ifndef CXOSLM01_h
#include "CXODLM01.hpp"
#endif
#ifndef CXOSLM02_h
#include "CXODLM02.hpp"
#endif
#ifndef CXOSAR06_h
#include "CXODAR06.hpp"
#endif
#ifndef CXOSMG28_h
#include "CXODMG28.hpp"
#endif
#ifndef CXOSLM05_h
#include "CXODLM05.hpp"
#endif
#ifndef CXOSLM06_h
#include "CXODLM06.hpp"
#endif
#ifndef CXOSLM07_h
#include "CXODLM07.hpp"
#endif
#ifndef CXOPLM00_h
#include "CXODLM00.hpp"
#endif


//## begin module%366FDCCA011D.declarations preserve=no
//## end module%366FDCCA011D.declarations

//## begin module%366FDCCA011D.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new LocatorManager();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
#include "CXODIF25.hpp"
#include "CXODTM02.hpp"
#include "CXODDB04.hpp"
//## end module%366FDCCA011D.additionalDeclarations


// Class LocatorManager

LocatorManager::LocatorManager()
  //## begin LocatorManager::LocatorManager%3505A95B026A_const.hasinit preserve=no
      : m_pPopulatePanSuffix(0),
        m_pTransactionHistory(0),
        m_pDuplicateIndex(0),
        m_pEMSBilling(0),
        m_pTransactionBilling(0),
        m_pExportData(0),
        m_pAuditEventFile(0),
        m_pQMRIssuerBin(0),
        m_pQMRAcquirerBin(0),
        m_pQMRDeviceFile(0)
  //## end LocatorManager::LocatorManager%3505A95B026A_const.hasinit
  //## begin LocatorManager::LocatorManager%3505A95B026A_const.initialization preserve=yes
  //## end LocatorManager::LocatorManager%3505A95B026A_const.initialization
{
  //## begin LocatorManager::LocatorManager%3505A95B026A_const.body preserve=yes
   memcpy(m_sID,"LM00",4);
   m_pLocator[0] = 0;
   m_pLocator[1] = 0;
   m_pLocator[2] = 0;
   m_pLocator[3] = 0;
   m_pLocator[4] = 0;
   m_pTokenRepair[0] = 0;
   m_pTokenRepair[1] = 0;
   m_pPanRepair[0] = 0;
   m_pPanRepair[1] = 0;
   m_pQMRBinFile = 0;
#ifndef MVS
   m_hTimer[0].attach(this);
   m_hTimer[0].set("01000000"); //01000000
#endif
   m_hTimer[1].setAlarm("080000");
   m_hTimer[1].attach(this);
   m_hTimer[2].set(1800);
   m_hTimer[2].attach(this);
  //## end LocatorManager::LocatorManager%3505A95B026A_const.body
}


LocatorManager::~LocatorManager()
{
  //## begin LocatorManager::~LocatorManager%3505A95B026A_dest.body preserve=yes
//   delete m_pTransactionRepair;
   delete m_pExportData;
   delete m_pTransactionHistory;
   delete m_pLocator[4];
   delete m_pLocator[3];
   delete m_pLocator[2];
   delete m_pLocator[1];
   delete m_pLocator[0];
   delete m_pDuplicateIndex;
   delete m_pEMSBilling;
   delete m_pTransactionBilling;
   delete m_pPopulatePanSuffix;
   for(int i = 0; i < 2; i++)
   {
      delete m_pTokenRepair[i];
      delete m_pPanRepair[i];
   }
   delete m_pQMRBinFile;
   delete m_pQMRIssuerBin;
   delete m_pQMRAcquirerBin;
   delete m_pQMRDeviceFile;
  //## end LocatorManager::~LocatorManager%3505A95B026A_dest.body
}



//## Other Operations (implementation)
void LocatorManager::checkAvailablePartitions (const string& strRecordType)
{
  //## begin LocatorManager::checkAvailablePartitions%44754A80033E.body preserve=yes
   UseCase hUseCase("DR","## DR16 EXAMINE PARTITION");
   PartitionDeallocator*  pPartitionDeallocator = (PartitionDeallocator*)DatabaseFactory::instance()->create("PartitionDeallocator");
   pPartitionDeallocator->setTableName(strRecordType.c_str());
   int iPartitionCount = 0;
   if (pPartitionDeallocator->available(&iPartitionCount))
      if (iPartitionCount < 2)
         Console::display("ST135",strRecordType.c_str());
   Database::instance()->commit();
   delete pPartitionDeallocator;
  //## end LocatorManager::checkAvailablePartitions%44754A80033E.body
}

void LocatorManager::checkPartitions ()
{
  //## begin LocatorManager::checkPartitions%4475A05403DE.body preserve=yes
   checkAvailablePartitions("DEV_ADMIN");
#ifdef MVS
   string strValue;
   Extract::instance()->getSpec("MODEL",strValue);
   if (strValue != "OPEN")
      checkAvailablePartitions("FIN_RECORD");
#endif
  //## end LocatorManager::checkPartitions%4475A05403DE.body
}

int LocatorManager::initialize ()
{
  //## begin LocatorManager::initialize%366FDB4703AC.body preserve=yes
   new dnplatform::DNPlatform();
   new segment::AuditEvent;
   int iRC = Application::initialize();
   UseCase hUseCase("DR","## DR01 START LM");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   DatabaseFactory::instance()->create("DataModel");
#ifdef MVS
   m_pDuplicateIndex = new DuplicateIndex();
#endif
   Customer::instance();
   Database::instance()->connect();
   MidnightAlarm::instance()->attach(this);
   MinuteTimer::instance()->attach(this);
   Application::instance()->setQueueWaitOption(false);
   return 0;
  //## end LocatorManager::initialize%366FDB4703AC.body
}

int LocatorManager::onMessage (Message& hMessage)
{
  //## begin LocatorManager::onMessage%4C2A12EB0127.body preserve=yes
   if (hMessage.messageID() == "H5050D")
   {
      Trace::put("H5050D received from console");
      if (hMessage.dataLength() >= 5 && !strncmp(hMessage.data(),"KEYS.",5))
      {
         string strCommand(hMessage.data(),hMessage.dataLength());
         string strConsoleMsg;
         if(!KeyManager::instance()->handleKeyCommands(strCommand,strConsoleMsg))
            Console::display("ST605",strConsoleMsg.c_str()); //failed
         else
            Console::display("ST604",strConsoleMsg.c_str()); //completed
      }
   }
   return 0;
  //## end LocatorManager::onMessage%4C2A12EB0127.body
}

int LocatorManager::onReset (Message& hMessage)
{
  //## begin LocatorManager::onReset%384581CE0151.body preserve=yes
   string strContext((char*)hMessage.context());
   Date hDate;
   if (strContext.length() < 16)
      strContext.resize(16);
   if (strContext.substr(0,8) == "SUBMIT  ")
   {
#ifdef MVS
      Date hDate(Date::today());
      string strToday(hDate.asString("%y%m%d"));
      hDate -= 1;
      string strYesterday(hDate.asString("%y%m%d"));
      Job::submit(strContext.substr(8).c_str(),"&YYMMDD ",strToday.c_str(),"&PYYMMDD",strYesterday.c_str());
#else
      auto_ptr<MaintenanceProcedure> p((MaintenanceProcedure*)DatabaseFactory::instance()->create("MaintenanceProcedure"));
      p->execute(strContext.substr(8).c_str());
#endif
      return 0;
   }
   string strDate = "";
   size_t posDate = strContext.find("DATE=");
   if (posDate != string::npos)
      strDate = strContext.substr(posDate+5,6);
   size_t posForce = strContext.find("FORCE");
   if (strContext.length() > 3 && strContext.substr(0,4) == "EMSD")
   {
      if (posDate != string::npos)
         strDate = strContext.substr(posDate+5,8);
      m_pEMSBilling->reset((posForce != string::npos),strDate,true);
   }
   else
   if (strContext.substr(0,3) == "EMS")
      m_pEMSBilling->reset((posForce != string::npos),strDate);
   else
   if (strContext.substr(0,9) == "TRANSPORT")
      m_pExportData->processPADSS(strContext);
   else
   if (strContext.substr(0,3) == "SSL")
   {
      if(strContext.find("IMPCERT") != string::npos)
      { //IMPCERT-passphrase
         string strPassPhrase = strContext.substr(strContext.find("IMPCERT") + 8);
         if(!KeyManager::instance()->importSSLCertificate(strPassPhrase))
            Console::display("ST605","IMPCERT ");
         else
            Console::display("ST604","IMPCERT ");
      }
      else
      if(strContext.find("EXPORTCERT") != string::npos)
      {
         if(!KeyManager::instance()->exportSSLCertificate())
            Console::display("ST605","EXPORTCERT ");
         else
            Console::display("ST604","EXPORTCERT ");
      }
      if(strContext.find("INITSSL") != string::npos)
      {
         if(!KeyManager::instance()->initSSLEnvironment())
            Console::display("ST605","INITSSL ");
         else
            Console::display("ST604","INITSSL ");
      }
   }
   else
   if (strContext.substr(0,5) == "PADSS")
   {
      if (strContext.find("ETK") != string::npos)
      {
         string strErrorMsg;
         if(!KeyManager::instance()->exportTransportKey(strErrorMsg))
         {
            Console::display("ST605","EXPORT-TK ");
            Trace::put(strErrorMsg.c_str());
         }
         else
         {
            Console::display("ST604","EXPORT-TK ");
            Trace::put("Export of transport key successful");
         }
      }
      else
      if (strContext.find("EDK") != string::npos)
      {
         string strErrorMsg;
         if(!KeyManager::instance()->exportDataKey(strErrorMsg))
         {
            Console::display("ST605","EXPORT-DK ");
            Trace::put(strErrorMsg.c_str());
         }
         else
         {
            Console::display("ST604","EXPORT-DK ");
            Trace::put("Export of transport key successful");
         }
      }
      else
         m_pExportData->processPADSS(strContext);
      Database::instance()->commit();
      return 0;

   }
   else
   if (strContext.substr(0,6) == "SUFFIX")
   {
      string strMsg;
      string strMsgId("ST602"); //ACCEPTED
      if(strContext.substr(7,5) == "START")
      {
         strMsg.assign("SUFFIX-START");
         if(m_pPopulatePanSuffix->start())
            Application::instance()->setQueueWaitOption(false);
         else
            strMsgId.assign("ST603"); //REJECTED
      }
      else
      if(strContext.substr(7,4) == "STOP")
      {
         strMsg.assign("SUFFIX-STOP");
         if(!m_pPopulatePanSuffix->stop())
            strMsgId.assign("ST603"); //REJECTED
      }
      else
      if(strContext.substr(7,6) == "CANCEL")
      {
         strMsg.assign("SUFFIX-CANCEL");
         if(!m_pPopulatePanSuffix->cancel())
            strMsgId.assign("ST603"); //REJECTED
      }
      Database::instance()->commit();
      Console::display(strMsgId.c_str(),strMsg.c_str());
      return 0;
   }
   if (strContext.substr(0,8) == "TOKENIZE" ||
       strContext.substr(0,7) == "DETOKEN")
   {
      string strMsg(strContext);
      string strMsgId("ST602"); //ACCEPTED
      int iIndex = TOKENIZE;
      if(strContext.find("DETOKEN") != string::npos)
         iIndex = DETOKENIZE;
      if(strContext.find("FIN") != string::npos)
      {
         if(strContext.find("START") != string::npos)
         {
            if(m_pTokenRepair[iIndex]->start())
               Application::instance()->setQueueWaitOption(false);
            else
               strMsgId.assign("ST603"); //REJECTED
         }
         else
         if(strContext.find("STOP") != string::npos)
         {
            if(!m_pTokenRepair[iIndex]->stop())
               strMsgId.assign("ST603"); //REJECTED
         }
         else
         if(strContext.find("CANCEL") != string::npos)
         {
            if(!m_pTokenRepair[iIndex]->cancel())
               strMsgId.assign("ST603"); //REJECTED
         }
      }
      else
      if(strContext.find("EMS") != string::npos)
      {
         if(strContext.find("START") != string::npos)
         {
            if(m_pPanRepair[iIndex]->start())
               Application::instance()->setQueueWaitOption(false);
            else
               strMsgId.assign("ST603"); //REJECTED
         }
         else
         if(strContext.find("STOP") != string::npos)
         {
            if(!m_pPanRepair[iIndex]->stop())
               strMsgId.assign("ST603"); //REJECTED
         }
         else
         if(strContext.find("CANCEL") != string::npos)
         {
            if(!m_pPanRepair[iIndex]->cancel())
               strMsgId.assign("ST603"); //REJECTED
         }
      }
      Database::instance()->commit();
      Console::display(strMsgId.c_str(),strMsg.c_str());
      return 0;
   }
   else
   if(strContext.substr(0,8) == "TRANHIST")
   {
      size_t pos = strContext.find(' ');
      if (pos != string::npos)
         strContext.erase(pos);
      vector<string> hTokens;
      if(Buffer::parse(strContext,"-",hTokens) < 3)
      {
         Console::display("ST609");
         return -1;
      }
      string strInstID(hTokens[1]) ;
      string strEndDate(hTokens[2]);
      int iMM = 0;
      int iYYYY = 0;
      if(strEndDate.length()>=6)
      {
         iMM = atoi(strEndDate.substr(4,2).c_str());
         iYYYY = atoi(strEndDate.substr(0,4).c_str());
      }
      if((strEndDate.length()<6)||(iYYYY == 0)||((iMM<1)&&(iMM>12)))
      {
         Console::display("ST609");
         return -1;
      }
      m_pTransactionHistory->reset(strInstID,strEndDate,false);
   }
   else
   if(strContext.substr(0,6) == "UDHIST")
   {
      string strInstID ;
      size_t n = strContext.find_first_of('-');
      string strContextTemp;
      strContextTemp.assign(strContext,n+1,strContext.npos);
      n = strContextTemp.find_first_of('-');
      strInstID.assign(strContextTemp,0,n);
      string strEndDate ;
      strEndDate.assign(strContextTemp,n+1,8);
      m_pTransactionHistory->reset(strInstID,strEndDate,true);
   }
   else
   if (strContext.substr(0,4) == "TRAN")
      m_pTransactionBilling->reset((posForce != string::npos),strDate);
   else
   if (strContext.substr(0,5) == "AUDIT")
      m_pAuditEventFile->createFile();
   else
   if (strContext.substr(0,7) == "ASAGING")
   {
      Transaction::instance()->begin();
      Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
      UseCase hUseCase1("CR","## CR99 CHECK FOR ACTIVE USERS");
      UseCase::setSuccess(entitycommand::UserActivityCommand::instance()->checkActiveUsers());
      Transaction::instance()->commit();
   }
   else
   {
#ifndef MVS
      string strTemp;
      Extract::instance()->getSpec("DBVENDOR",strTemp);
      if (strTemp != "SQLSERVER" && strTemp != "ORACLE" && strTemp != "POSTGRES")
      {
         auto_ptr<MaintenanceProcedure> p((MaintenanceProcedure*)DatabaseFactory::instance()->create("MaintenanceProcedure"));
         p->execute("CXOXDB00");
      }
#endif
      m_pLocator[0]->synchronize();
      if (Extract::instance()->getCustomCode() != "MPS")
      {
         m_pLocator[1]->synchronize();
         m_pLocator[2]->synchronize();
         m_pLocator[3]->synchronize();
         m_pLocator[4]->synchronize();
      }
      Database::instance()->commit();
   }
   return 0;
  //## end LocatorManager::onReset%384581CE0151.body
}

int LocatorManager::onResume (Message& hMessage)
{
  //## begin LocatorManager::onResume%4A3120C40242.body preserve=yes
   if (!m_pEMSBilling)
   {
      m_pEMSBilling = new EMSBilling();
      m_pTransactionBilling = new TransactionBilling();
      m_pLocator[0] = (Locator*)DatabaseFactory::instance()->create("Locator");
      m_pLocator[0]->setTableName("FIN_L");
      m_pLocator[0]->setType('F');
      if (Extract::instance()->getCustomCode() != "MPS")
      {
         m_pLocator[1] = (Locator*)DatabaseFactory::instance()->create("Locator");
         m_pLocator[1]->setTableName("AUDIT_MAINT");
         m_pLocator[1]->setType('M');
         m_pLocator[2] = (Locator*)DatabaseFactory::instance()->create("Locator");
         m_pLocator[2]->setTableName("STAT_REC_L");
         m_pLocator[2]->setType('S');
         m_pLocator[3] = (Locator*)DatabaseFactory::instance()->create("Locator");
         m_pLocator[3]->setTableName("DEV_ADMIN_L");
         m_pLocator[3]->setType('A');
         m_pLocator[4] = (Locator*)DatabaseFactory::instance()->create("Locator");
         m_pLocator[4]->setTableName("ATM_EJ_REC");
         m_pLocator[4]->setType('E');
      }
      m_pExportData = new ExportData();
      m_pTransactionHistory = new TransactionHistory();
      m_pAuditEventFile = new managementinformation::AuditEventFile();
      m_pExportData->update(0);
      m_pLocator[0]->update(0);
      if (Extract::instance()->getCustomCode() != "MPS")
      {
         m_pLocator[1]->update(0);
         m_pLocator[2]->update(0);
         m_pLocator[3]->update(0);
         m_pLocator[4]->update(0);
      }
      m_pTransactionHistory->processTransactions();
      checkPartitions();
      m_pTokenRepair[0] = new TokenRepair();
      m_pTokenRepair[0]->initStatus("TOKENIZE");
      m_pTokenRepair[1] = new TokenRepair();
      m_pTokenRepair[1]->initStatus("DETOKENIZE");
      m_pPanRepair[0] = new PanRepair();
      m_pPanRepair[0]->initStatus("TOKENIZE");
      m_pPanRepair[1] = new PanRepair();
      m_pPanRepair[1]->initStatus("DETOKENIZE");
      m_pPopulatePanSuffix = new PopulatePanSuffix();
      m_pPopulatePanSuffix->initStatus();
#ifndef MVS
      string strTemp;
      Extract::instance()->getSpec("DBVENDOR", strTemp);
      if (strTemp != "SQLSERVER" && strTemp != "ORACLE" && strTemp != "POSTGRES")
      {
         auto_ptr<MaintenanceProcedure> p((MaintenanceProcedure*)DatabaseFactory::instance()->create("MaintenanceProcedure"));
         p->execute("CXOXDB00");
      }
#endif
      ImportFile::age();
      Database::instance()->commit();
   }
   if(m_pPopulatePanSuffix->onResume())
      return 0;
   for(int i = 0; i < 2; i++)
   {
      if(m_pTokenRepair[i]->onResume())
         return 0;
   }
   for(int i = 0; i < 2; i++)
   {
      if(m_pPanRepair[i]->onResume())
         return 0;
   }
   if(m_hTransactionRepair.size() == 0)
      Application::instance()->setQueueWaitOption(true);
   else if (!m_hTransactionRepair.front()->onResume())
   {
      delete m_hTransactionRepair.front();
      m_hTransactionRepair.pop_front();
      if(m_hTransactionRepair.size() == 0)
         Application::instance()->setQueueWaitOption(true);
   }
   return 0;
  //## end LocatorManager::onResume%4A3120C40242.body
}

void LocatorManager::update (Subject* pSubject)
{
  //## begin LocatorManager::update%3EE9F0FB03D8.body preserve=yes
   if (pSubject == MidnightAlarm::instance())
   {
      reconciliationfile::ReconciliationTransaction::instance()->ageOffOldExceptions();
      m_pAuditEventFile->createFile();
      m_hTimer[2].set(1800);
      m_hTimer[2].attach(this);
   }
#ifndef MVS
   if (pSubject == &m_hTimer[0])
   {
      string strTemp;
      Extract::instance()->getSpec("DBVENDOR",strTemp);
      if (strTemp != "SQLSERVER" && strTemp != "ORACLE" && strTemp != "POSTGRES")
      {
         auto_ptr<MaintenanceProcedure> p((MaintenanceProcedure*)DatabaseFactory::instance()->create("MaintenanceProcedure"));
         p->execute("CXOXDB00");
      }
      m_pLocator[0]->synchronize();
      if (Extract::instance()->getCustomCode() != "MPS")
      {
         m_pLocator[1]->synchronize();
         m_pLocator[2]->synchronize();
         m_pLocator[3]->synchronize();
         m_pLocator[4]->synchronize();
      }
      Database::instance()->commit();
      m_hTimer[0].set("01000000");
      return;
   }
#endif
   if (pSubject == &m_hTimer[1])
   {
      checkPartitions();
      ImportFile::age();
      m_hTimer[1].setAlarm("080000");
   }
   else
   if (pSubject == &m_hTimer[2])
   {
      if(KeyRing::instance()->getActive() && KeyRing::instance()->isPrimary())
      {  //verify database
         AESKeyRing hAESKeyRing;
         hAESKeyRing.setActive(true);
         if(!hAESKeyRing.reset())
         {
            m_hTimer[2].set(1800); //re-try every 30 mins till fixed
            Console::display("ST605","RECOVER"); //FAILED
            Database::instance()->rollback();
            KeyRing::instance()->setInitializedFromBackups(true);
            return;
         }
         if(hAESKeyRing.getInitializedFromBackups())
         {  //repair needed
            if(!hAESKeyRing.repairKeys() || !hAESKeyRing.repairTokens())
            {
               m_hTimer[2].set(1800); //re-try every 30 mins till fixed
               Console::display("ST605","RECOVER"); //FAILED
               Database::instance()->rollback();
               KeyRing::instance()->setInitializedFromBackups(true);
               return;
            }
            Console::display("ST604","RECOVER"); //COMPLETED
            Database::instance()->commit();
            KeyRing::instance()->setInitializedFromBackups(false);
         }
      }
      //Take daily backup
      if(!KeyManager::instance()->backup())
         Database::instance()->rollback();
      else
         Database::instance()->commit();
      m_hTimer[2].cancel();
      m_hTimer[2].detach(this);
      return;
   }
   if (pSubject == MinuteTimer::instance())
   {
      string strAPDEMO;
      if (IF::Extract::instance()->getRecord("DFILES  APDEMO  ", strAPDEMO))
      {
         int lRecordCount = 0;
         size_t lByteCount = 0;
         size_t lMaxRecordLength = 0;
         GenerationDataGroup hGenerationDataGroup(Application::instance()->image(), Application::instance()->name(), "APDEMO");
         if (hGenerationDataGroup.getSize(&lRecordCount, &lByteCount, &lMaxRecordLength, true) && lMaxRecordLength > 0)
         {
            Date hDate(Date::today());
            ExportFile hExportFile("AUGEO", "*P", "PRC999", hDate.asString("%Y%m%d"), "240000");
            hExportFile.setTSTAMP_INITIATED(Clock::instance()->getYYYYMMDDHHMMSSHN());
            hExportFile.setDX_STATE("DW");
            if (!hExportFile.trigger())
               Database::instance()->rollback();
            if (hGenerationDataGroup.open(FlatFile::CX_OPEN_INPUT))
               hGenerationDataGroup.commit();
            Database::instance()->commit();
         }
      }
      //TransFund-NCR File Report
      string strTFNCR;
      if (IF::Extract::instance()->getRecord("DFILES  CMTFNCR ", strTFNCR))
      {
         int lRecordCount = 0;
         size_t lByteCount = 0;
         size_t lMaxRecordLength = 0;
         GenerationDataGroup hGenerationDataGroup(Application::instance()->image(), Application::instance()->name(), "CMTFNCR");
         if (hGenerationDataGroup.getSize(&lRecordCount, &lByteCount, &lMaxRecordLength, true) && lMaxRecordLength > 0)
         {
            Date hDate(Date::today());
            ExportFile hExportFile("TFNCR", "*P", "PRC999", hDate.asString("%Y%m%d"), "240000");
            hExportFile.setTSTAMP_INITIATED(Clock::instance()->getYYYYMMDDHHMMSSHN());
            hExportFile.setDX_STATE("DW");
            if (!hExportFile.trigger())
               Database::instance()->rollback();
            if (hGenerationDataGroup.open(FlatFile::CX_OPEN_INPUT))
               hGenerationDataGroup.commit();
            Database::instance()->commit();
         }
      }
      ///////////////////////////////////////////
      string strTemp;
      if (IF::Extract::instance()->getRecord("DFILES  DRCFCR  ",strTemp))
      {
         int lRecordCount = 0;
         size_t lByteCount = 0;
         size_t lMaxRecordLength = 0;
         GenerationDataGroup hGenerationDataGroup(Application::instance()->image(),Application::instance()->name(),"DRCFCR");
         if (hGenerationDataGroup.getSize(&lRecordCount,&lByteCount,&lMaxRecordLength,true) && lMaxRecordLength > 0)
         {
            Date hDate(Date::today());
            ExportFile hExportFile("PROFCR","*P","PRC999",hDate.asString("%Y%m%d"),"240000");
            hExportFile.setTSTAMP_INITIATED(Clock::instance()->getYYYYMMDDHHMMSSHN());
            hExportFile.setDX_STATE("DW");
            if (!hExportFile.trigger())
               Database::instance()->rollback();
            if (hGenerationDataGroup.open(FlatFile::CX_OPEN_INPUT))
               hGenerationDataGroup.commit();
            Database::instance()->commit();
         }
      }
      if (IF::Extract::instance()->getRecord("DFILES  QMRBIN  ", strTemp))
      {
         if (!m_pQMRBinFile)
            m_pQMRBinFile = new QMRBinFile;
         m_pQMRBinFile->import();
      }
      if (IF::Extract::instance()->getRecord("DFILES  QMRISS  ", strTemp))
      {
         if (!m_pQMRIssuerBin)
            m_pQMRIssuerBin = new QMRIssuerBin;
         m_pQMRIssuerBin->import();
      }
      if (IF::Extract::instance()->getRecord("DFILES  QMRACQ  ", strTemp))
      {
         if (!m_pQMRAcquirerBin)
            m_pQMRAcquirerBin = new QMRAcquirerBin;
         m_pQMRAcquirerBin->import();
      }
      if (IF::Extract::instance()->getRecord("DFILES  QMRDEV  ", strTemp))
      {
         if (!m_pQMRDeviceFile)
            m_pQMRDeviceFile = new QMRDeviceFile;
         m_pQMRDeviceFile->import();
      }
   }
   Application::update(pSubject);
  //## end LocatorManager::update%3EE9F0FB03D8.body
}

// Additional Declarations
  //## begin LocatorManager%3505A95B026A.declarations preserve=yes
  //## end LocatorManager%3505A95B026A.declarations

//## begin module%366FDCCA011D.epilog preserve=yes
//## end module%366FDCCA011D.epilog
