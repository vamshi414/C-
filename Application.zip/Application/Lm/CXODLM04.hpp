//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5FA3F1A6029F.cm preserve=no
//## end module%5FA3F1A6029F.cm

//## begin module%5FA3F1A6029F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5FA3F1A6029F.cp

//## Module: CXOSLM04%5FA3F1A6029F; Package specification
//## Subsystem: LM%3597EB1A028A
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Lm\CXODLM04.hpp

#ifndef CXOSLM04_h
#define CXOSLM04_h 1

//## begin module%5FA3F1A6029F.additionalIncludes preserve=no
//## end module%5FA3F1A6029F.additionalIncludes

//## begin module%5FA3F1A6029F.includes preserve=yes
//## end module%5FA3F1A6029F.includes

#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Totals Management::ManagementInformation_CAT%440DDD48031C
namespace managementinformation {
class QMRReport;
} // namespace managementinformation

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%5FA3F1A6029F.declarations preserve=no
//## end module%5FA3F1A6029F.declarations

//## begin module%5FA3F1A6029F.additionalDeclarations preserve=yes
struct QMRBin
{                               //offsets
   char cRecordType;            //0000
   char sCustId[6];             //0001
   char sInstId[10];            //0007
   char sBin[10];               //0017
   char sDate[8];               //0027
   char cBusinessFlg;           //0035
   char cLoyaltyFlg;            //0036
   char cFraudFlg;              //0037
   char cCardOrderFlg;          //0038
   char cNonAPBinFlg;           //0039
   char sNetworkType[2];        //0040
   char cDebitCreditInd;        //0042
   char sNetworkProductType[3]; //0043
   char sProcId[6];             //0046
   char sCardCount[10];         //0052
   char sActiveCardCount[10];   //0062
   char sInactiveCardCount[10]; //0072
   char sStatusedCardCount[10]; //0082
   char sAddedCardCount[10];    //0092
   char sMediaMSCount[10];      //0102
   char sMediaICCount[10];      //0112
   char sMediaIPCount[10];      //0122
   char sMediaISCount[10];      //0132
   char sUNKMediaType[10];      //0142
   char sMiniCount[10];         //0152
   char sMicroCount[10];        //0162
   char sMobileCount[10];       //0172
   char sEnrolledCardCount[10]; //0182
   char sAcctCount[10];         //0192
   char sAddedAcctCount[10];    //0202
   char sDDAAcctCount[10];      //0212
   char sSAVAcctCount[10];      //0222
   char sCRDAcctCount[10];      //0232
   char sOTHAcctCount[10];      //0242
   char sUNKAcctCount[10];      //0252
   char sICA[11];               //0262
   char sFiller[227];           //0273
};                              //0500
//## end module%5FA3F1A6029F.additionalDeclarations


//## begin QMRBinFile%5FA3F23F0037.preface preserve=yes
//## end QMRBinFile%5FA3F23F0037.preface

//## Class: QMRBinFile%5FA3F23F0037
//## Category: DataNavigator Foundation::Application::LocatorManager_CAT%354B349200A7
//## Subsystem: LM%3597EB1A028A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%60EA911A00F7;database::Database { -> F}
//## Uses: <unnamed>%60EA911E0232;process::Application { -> F}
//## Uses: <unnamed>%60EA912B037E;reusable::Query { -> F}
//## Uses: <unnamed>%60EA914A0344;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%60EA914F03D8;monitor::UseCase { -> F}
//## Uses: <unnamed>%60EA91550168;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%60EA915902A0;entitysegment::Customer { -> F}
//## Uses: <unnamed>%60EA915D009E;reusable::Statement { -> F}
//## Uses: <unnamed>%60EBE5B902D0;timer::Date { -> F}
//## Uses: <unnamed>%60ED989D015C;reusable::Buffer { -> F}
//## Uses: <unnamed>%61A4D6430385;database::GlobalContext { -> F}
//## Uses: <unnamed>%652D16B500C3;managementinformation::QMRReport { -> F}

class DllExport QMRBinFile : public database::GenerationDataGroup  //## Inherits: <unnamed>%5FA3F3610199
{
  //## begin QMRBinFile%5FA3F23F0037.initialDeclarations preserve=yes
  //## end QMRBinFile%5FA3F23F0037.initialDeclarations

  public:
    //## Constructors (generated)
      QMRBinFile();

    //## Destructor (generated)
      virtual ~QMRBinFile();


    //## Other Operations (specified)
      //## Operation: import%5FA40C67032A
      bool import ();

    // Additional Public Declarations
      //## begin QMRBinFile%5FA3F23F0037.public preserve=yes
      //## end QMRBinFile%5FA3F23F0037.public

  protected:
    // Additional Protected Declarations
      //## begin QMRBinFile%5FA3F23F0037.protected preserve=yes
      //## end QMRBinFile%5FA3F23F0037.protected

  private:
    // Additional Private Declarations
      //## begin QMRBinFile%5FA3F23F0037.private preserve=yes
      //## end QMRBinFile%5FA3F23F0037.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Count%60EAB1F10361
      //## begin QMRBinFile::Count%60EAB1F10361.attr preserve=no  private: int {U} 0
      int m_iCount;
      //## end QMRBinFile::Count%60EAB1F10361.attr

      //## Attribute: YYYYMMDD%60EA8AD70378
      //## begin QMRBinFile::YYYYMMDD%60EA8AD70378.attr preserve=no  private: string {U} 
      string m_strYYYYMMDD;
      //## end QMRBinFile::YYYYMMDD%60EA8AD70378.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%5FA40B2801AE
      //## Role: QMRBinFile::<m_hTable>%5FA40B29035F
      //## begin QMRBinFile::<m_hTable>%5FA40B29035F.role preserve=no  public: reusable::Table { -> VHgN}
      reusable::Table m_hTable;
      //## end QMRBinFile::<m_hTable>%5FA40B29035F.role

    // Additional Implementation Declarations
      //## begin QMRBinFile%5FA3F23F0037.implementation preserve=yes
      string m_strCONTEXT_DATA;
      //## end QMRBinFile%5FA3F23F0037.implementation

};

//## begin QMRBinFile%5FA3F23F0037.postscript preserve=yes
//## end QMRBinFile%5FA3F23F0037.postscript

//## begin module%5FA3F1A6029F.epilog preserve=yes
//## end module%5FA3F1A6029F.epilog


#endif
