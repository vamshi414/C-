//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%60229B190150.cm preserve=no
//## end module%60229B190150.cm

//## begin module%60229B190150.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%60229B190150.cp

//## Module: CXOSLM07%60229B190150; Package specification
//## Subsystem: LM%3597EB1A028A
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Lm\CXODLM07.hpp

#ifndef CXOSLM07_h
#define CXOSLM07_h 1

//## begin module%60229B190150.additionalIncludes preserve=no
//## end module%60229B190150.additionalIncludes

//## begin module%60229B190150.includes preserve=yes
//## end module%60229B190150.includes

#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%60229B190150.declarations preserve=no
//## end module%60229B190150.declarations

//## begin module%60229B190150.additionalDeclarations preserve=yes
//## end module%60229B190150.additionalDeclarations


//## begin QMRDeviceFile%6529159F027A.preface preserve=yes
//## end QMRDeviceFile%6529159F027A.preface

//## Class: QMRDeviceFile%6529159F027A
//## Category: DataNavigator Foundation::Application::LocatorManager_CAT%354B349200A7
//## Subsystem: LM%3597EB1A028A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%652916B70376;entitysegment::Customer { -> F}
//## Uses: <unnamed>%652916BC02E2;database::Database { -> F}
//## Uses: <unnamed>%652916BF03C9;timer::Clock { -> F}
//## Uses: <unnamed>%652916C30045;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%652916CD0345;reusable::Statement { -> F}
//## Uses: <unnamed>%652916D102C0;process::Application { -> F}
//## Uses: <unnamed>%652916D403E5;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%6529171901F1;reusable::Query { -> F}
//## Uses: <unnamed>%6529171D009D;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%6529172A02B4;monitor::UseCase { -> F}
//## Uses: <unnamed>%6529172E0208;IF::Trace { -> F}
//## Uses: <unnamed>%65291732001D;timer::Date { -> F}
//## Uses: <unnamed>%652917350380;reusable::Buffer { -> F}
//## Uses: <unnamed>%6529173A00BA;database::GlobalContext { -> F}

class DllExport QMRDeviceFile : public database::GenerationDataGroup  //## Inherits: <unnamed>%652916A500E4
{
  //## begin QMRDeviceFile%6529159F027A.initialDeclarations preserve=yes
  //## end QMRDeviceFile%6529159F027A.initialDeclarations

  public:
    //## Constructors (generated)
      QMRDeviceFile();

    //## Destructor (generated)
      virtual ~QMRDeviceFile();


    //## Other Operations (specified)
      //## Operation: getLogo%6529178E020A
      bool getLogo (const string& strNetwork, const string& strBuffer);

      //## Operation: import%652917EB019C
      bool import ();

    // Additional Public Declarations
      //## begin QMRDeviceFile%6529159F027A.public preserve=yes
      //## end QMRDeviceFile%6529159F027A.public

  protected:
    // Additional Protected Declarations
      //## begin QMRDeviceFile%6529159F027A.protected preserve=yes
      //## end QMRDeviceFile%6529159F027A.protected

  private:
    // Data Members for Class Attributes

      //## Attribute: Networks%6529182201C0
      //## begin QMRDeviceFile::Networks%6529182201C0.attr preserve=no  private: multimap<string,string,less<string> > {U} 
      multimap<string,string,less<string> > m_hNetworks;
      //## end QMRDeviceFile::Networks%6529182201C0.attr

      //## Attribute: YYYYMMDD%652917FF017B
      //## begin QMRDeviceFile::YYYYMMDD%652917FF017B.attr preserve=no  private: string {U} 
      string m_strYYYYMMDD;
      //## end QMRDeviceFile::YYYYMMDD%652917FF017B.attr

    // Additional Private Declarations
      //## begin QMRDeviceFile%6529159F027A.private preserve=yes
      //## end QMRDeviceFile%6529159F027A.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%652916DA00A2
      //## Role: QMRDeviceFile::<m_hTable>%652916DB009C
      //## begin QMRDeviceFile::<m_hTable>%652916DB009C.role preserve=no  public: reusable::Table { -> VHgN}
      reusable::Table m_hTable;
      //## end QMRDeviceFile::<m_hTable>%652916DB009C.role

    // Additional Implementation Declarations
      //## begin QMRDeviceFile%6529159F027A.implementation preserve=yes
      string m_strCONTEXT_DATA;
      //## end QMRDeviceFile%6529159F027A.implementation
};

//## begin QMRDeviceFile%6529159F027A.postscript preserve=yes
//## end QMRDeviceFile%6529159F027A.postscript

//## begin module%60229B190150.epilog preserve=yes
//## end module%60229B190150.epilog


#endif
