//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%601902060290.cm preserve=no
//## end module%601902060290.cm

//## begin module%601902060290.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%601902060290.cp

//## Module: CXOSLM05%601902060290; Package body
//## Subsystem: LM%3597EB1A028A
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Lm\CXOSLM05.cpp

//## begin module%601902060290.additionalIncludes preserve=no
//## end module%601902060290.additionalIncludes

//## begin module%601902060290.includes preserve=yes
#define STS_DUPLICATE_RECORD 35
#define STS_RECORD_NOT_FOUND 14
#define VISABIN_REC_LEN 133
#include "CXODCFC0.hpp"
#include "CXODIF16.hpp"
#include "CXODRU19.hpp"
#include <algorithm>
//## end module%601902060290.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSMG39_h
#include "CXODMG39.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSLM05_h
#include "CXODLM05.hpp"
#endif


//## begin module%601902060290.declarations preserve=no
//## end module%601902060290.declarations

//## begin module%601902060290.additionalDeclarations preserve=yes
struct QMRIssuer
{
   char cFiller;
   char sINST_ID[10];
   char cSpace1;
   char sBIN_NO[12];
   char cSpace2;
   char cNETWORK_IND;
};
struct QMRBinLogo
{
   char sINST_ID[11];
   char sFiller1[2];
   char sBIN[12];
   char sFiller2[2];
   char sLOGO_ID[8];
};
//## end module%601902060290.additionalDeclarations


// Class QMRIssuerBin 

QMRIssuerBin::QMRIssuerBin()
  //## begin QMRIssuerBin::QMRIssuerBin%601902980214_const.hasinit preserve=no
      : m_lRecordLength(0),
        m_pInsertStatement(0),
        m_pUpdateStatement(0)
  //## end QMRIssuerBin::QMRIssuerBin%601902980214_const.hasinit
  //## begin QMRIssuerBin::QMRIssuerBin%601902980214_const.initialization preserve=yes
   ,GenerationDataGroup(Application::instance()->image(), Application::instance()->name(), "QMRISS")
  //## end QMRIssuerBin::QMRIssuerBin%601902980214_const.initialization
{
  //## begin QMRIssuerBin::QMRIssuerBin%601902980214_const.body preserve=yes
   memcpy(m_sID,"LM05",4);
   m_strCONTEXT_DATA.assign("VC690:N~COMBINED:N~LOGO:N~CIMS:N~QMRACQVRID:N");
   m_hConfig.insert(map<int, string, less<int> >::value_type(1, "MCI"));
   m_hConfig.insert(map<int, string, less<int> >::value_type(2, "MAP"));
   m_hConfig.insert(map<int, string, less<int> >::value_type(3, "MCI"));
   m_hConfig.insert(map<int, string, less<int> >::value_type(4, "CRS"));
   m_hConfig.insert(map<int, string, less<int> >::value_type(5, "MCI"));
   m_hConfig.insert(map<int, string, less<int> >::value_type(6, "MAP"));
   m_hConfig.insert(map<int, string, less<int> >::value_type(7, "MCI"));
   m_hLogoIDs.insert(map<int, string, less<int> >::value_type(1, "MASTERCARD_LOGO"));
   m_hLogoIDs.insert(map<int, string, less<int> >::value_type(2, "VISA_LOGO"));
   m_hLogoIDs.insert(map<int, string, less<int> >::value_type(3, "PLUS_LOGO"));
   m_hLogoIDs.insert(map<int, string, less<int> >::value_type(4, "INTERLINK_LOGO"));
   m_hLogoIDs.insert(map<int, string, less<int> >::value_type(5, "CIRRUS_LOGO"));
   m_hLogoIDs.insert(map<int, string, less<int> >::value_type(6, "MAESTRO_LOGO"));
  //## end QMRIssuerBin::QMRIssuerBin%601902980214_const.body
}


QMRIssuerBin::~QMRIssuerBin()
{
  //## begin QMRIssuerBin::~QMRIssuerBin%601902980214_dest.body preserve=yes
   delete m_pUpdateStatement;
   delete m_pInsertStatement;
  //## end QMRIssuerBin::~QMRIssuerBin%601902980214_dest.body
}



//## Other Operations (implementation)
bool QMRIssuerBin::applyDelete ()
{
  //## begin QMRIssuerBin::applyDelete%637CBD0001D6.body preserve=yes
    Query hQuery;
    hQuery.setQualifier("QUALIFY","QMR_BIN");
    hQuery.setBasicPredicate("QMR_BIN","CUST_ID","=",Customer::instance()->getCUST_ID().c_str());
    hQuery.setBasicPredicate("QMR_BIN","NETWORK_ID","=",m_strNETWORK_ID.c_str());
    hQuery.setBasicPredicate("QMR_BIN","BIN","=",m_strBIN.c_str());
    hQuery.setBasicPredicate("QMR_BIN","INST_ID","=",m_strINST_ID.c_str());
    hQuery.setBasicPredicate("QMR_BIN","CC_STATE","=","A");
    hQuery.setBasicPredicate("QMR_BIN","CC_CHANGE_GRP_ID","IS NULL");
    auto_ptr<SelectStatement> pDeleteStatment((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
    bool b = pDeleteStatment->execute(hQuery);
    if (!b)
       close();
    return UseCase::setSuccess(b);
  //## end QMRIssuerBin::applyDelete%637CBD0001D6.body
}

bool QMRIssuerBin::deleteBins ()
{
  //## begin QMRIssuerBin::deleteBins%637CC1A50200.body preserve=yes
    if (m_strFile != "VC690"
        && m_strFile != "COMBINED")
        return true;
    string strPredicate;
    Query hSubQuery;
    hSubQuery.setSubSelect(true);
    hSubQuery.setQualifier("QUALIFY","QMR_BIN");
    hSubQuery.bind("QMR_BIN","BIN",Column::STRING,0);
    hSubQuery.setBasicPredicate("QMR_BIN","NETWORK_ID","!=","***");
    hSubQuery.setBasicPredicate("QMR_BIN","CUST_ID","=",Customer::instance()->getCUST_ID().c_str());
    auto_ptr<FormatSelectVisitor>pFormatSelectVisitor((FormatSelectVisitor*)DatabaseFactory::instance()->create("FormatSelectVisitor"));
    hSubQuery.accept(*pFormatSelectVisitor);
    strPredicate = "(" + pFormatSelectVisitor->SQLText() + ")";
    Query hQuery;
    hQuery.setQualifier("QUALIFY","QMR_BIN");
    hQuery.setBasicPredicate("QMR_BIN","CUST_ID","=",Customer::instance()->getCUST_ID().c_str());
    hQuery.setBasicPredicate("QMR_BIN","NETWORK_ID","=","***");
    hQuery.setBasicPredicate("QMR_BIN","BIN","IN",strPredicate.c_str());
    auto_ptr<SelectStatement> pDeleteStatment((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
    if (pDeleteStatment->execute(hQuery) == false)
    {
        close();
        return UseCase::setSuccess(false);
    }
    return true;
  //## end QMRIssuerBin::deleteBins%637CC1A50200.body
}

bool QMRIssuerBin::import ()
{
  //## begin QMRIssuerBin::import%601903260358.body preserve=yes
   bool bDuplicate = false;
   if (open(FlatFile::CX_OPEN_INPUT,&bDuplicate) == false 
      && bDuplicate == false)
      return false;
   UseCase hUseCase("DR", "## DR104 LOAD QMR ISSUER TABLE");
   m_strFile.erase();
   size_t pos = 0;
   size_t n = 0;
#ifdef MVS
   Date hDate(Date::today());
   m_strYYYYMMDD.assign(hDate.asString("%Y%m%d"));
#else
   if (!(((pos = datasetName().find(".D",0,2)) != string::npos
      || (pos = datasetName().find(".M",0,2)) != string::npos)
      && datasetName().length() > pos + 8))
   {
      Trace::put("Missing Date(.DYYMMDD/.MYYMMDD) in FileName : ",datasetName());
      close();
      return false;
   }
   m_strYYYYMMDD.assign(Clock::instance()->getDate().c_str(),2);
   m_strYYYYMMDD.append(datasetName().c_str() + pos + 2,6);
   if ((n = datasetName().find("COMBINED")) != string::npos
      || (n = datasetName().find("VC690")) != string::npos
      || (n = datasetName().find("LOGO")) != string::npos)
      m_strFile.assign(datasetName().c_str() + n,pos - n);
#endif
   if (bDuplicate)
   {
      if ((managementinformation::QMRReport::progressUpdate(m_strFile,m_strYYYYMMDD,m_strCONTEXT_DATA)) == false)
         return false;
      Database::instance()->commit();
      return true;
   }
   string strFirst,strTemp;
   map<int,string,less<int> >::iterator pConfig;
   m_hTable.setName("QMR_BIN");
   m_hTable.setQualifier("QUALIFY");
   if (m_strFile == "VC690" || m_strFile == "COMBINED")
   {
      if (m_strFile == "VC690")
      {
         m_strFileNETWORK_ID.assign("VNT",3);
         strTemp.assign("VNT",3);
      }
      else
      {
         m_strFileNETWORK_ID.assign(1,' ');
         strTemp.assign("('MCI','CRS','MAP')",19);
      }
      readNext();
      m_hQuery.reset();
      m_hQuery.setQualifier("QUALIFY","QMR_BIN");
      m_hQuery.attach(this);
      m_hQuery.bind("QMR_BIN","BIN",Column::STRING,&m_strBIN);
      m_hQuery.bind("QMR_BIN","INST_ID",Column::STRING,&m_strINST_ID);
      m_hQuery.bind("QMR_BIN","NETWORK_ID",Column::STRING,&m_strNETWORK_ID);
      m_hQuery.setBasicPredicate("QMR_BIN","NETWORK_ID","IN",strTemp.c_str());
      strTemp = "('" + Customer::instance()->getCUST_ID() + "','****')";
      m_hQuery.setBasicPredicate("QMR_BIN","CUST_ID","IN",strTemp.c_str());
      m_hQuery.setBasicPredicate("QMR_BIN","CC_STATE","=","A");
      m_hQuery.setBasicPredicate("QMR_BIN","CC_CHANGE_GRP_ID","IS NULL");
      m_hQuery.setOrderByClause("QMR_BIN.INST_ID ASC,QMR_BIN.BIN ASC");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (pSelectStatement->execute(m_hQuery) == false || m_hQuery.getAbort())
      {
         Database::instance()->rollback();
         return UseCase::setSuccess(false);
      }
      while (m_strFileKey != "9999999999999999999")
      {
         if (insert() == false)
         {
            close();
            return UseCase::setSuccess(false);
         }
         readNext();
      }
   }
   else if (m_strFile == "LOGO")
   {
      while (read(m_szBuffer, 256, &n))
      {
         m_strBuffer.assign(m_szBuffer, n);
         if (m_strBuffer.length() == sizeof(struct QMRBinLogo))
         {
            if (m_strFile.empty())
               m_strFile.assign("LOGO",4);
            struct QMRBinLogo* pQMRBinLogo = (struct QMRBinLogo*)m_szBuffer;
            m_strFileINST_ID.assign(pQMRBinLogo->sINST_ID + 2, sizeof(pQMRBinLogo->sINST_ID) - 2);
            m_strFileBIN.assign(pQMRBinLogo->sBIN, sizeof(pQMRBinLogo->sBIN));
            while ((pos = m_strFileBIN.find("~")) != string::npos)
               m_strFileBIN.erase(pos, 1);
            strFirst.assign("ISSUER_BIN_NET ",15);
            strFirst.append(pQMRBinLogo->sLOGO_ID, 8);
            if (ConfigurationRepository::instance()->translate("X_GENERIC", strFirst, strTemp, " ", " ", -1, false) == false)
               continue;
            vector<string> hLogos;
            Buffer::parse(strTemp, ",", hLogos);
            for (vector<string>::iterator p = hLogos.begin(); p != hLogos.end(); p++)
            {
               pConfig = m_hLogoIDs.find(atoi((*p).c_str()));
               if (pConfig == m_hLogoIDs.end())
                  continue;
               m_strFileNETWORK_ID.assign("***",3);
               m_strLogoColumn.assign((*pConfig).second);
               m_hTable.reset();
               m_hTable.setName("QMR_BIN");
               m_hTable.setQualifier("QUALIFY");
               m_hTable.set("INST_ID",m_strFileINST_ID,false,true);
               m_hTable.set("BIN",m_strFileBIN,false,true);
               m_hTable.set("CUST_ID",Customer::instance()->getCUST_ID(),false,true);
               m_hTable.set(m_strLogoColumn.c_str(),"Y");
               m_hTable.set("CC_LAST_OPERATION","UPD");
               m_hTable.set("CC_TSTAMP_CHANGE",Clock::instance()->getYYYYMMDDHHMMSS());
               if (!m_pUpdateStatement)
                  m_pUpdateStatement = (Statement*)DatabaseFactory::instance()->create("UpdateStatement");
               if (m_pUpdateStatement->execute(m_hTable) == false
                  && !(m_pUpdateStatement->getInfoIDNumber() == STS_RECORD_NOT_FOUND && insert()))
               {
                  close();
                  Database::instance()->rollback();
                  return UseCase::setSuccess(false);
               }
               UseCase::addItem();
            }
         }
      }
   }
   if (deleteBins() == false
      || managementinformation::QMRReport::progressUpdate(m_strFile,m_strYYYYMMDD,m_strCONTEXT_DATA) == false)
   {
      close();
      Database::instance()->rollback();
      return UseCase::setSuccess(false);
   }
   commit();
   Database::instance()->commit();
   return true;
  //## end QMRIssuerBin::import%601903260358.body
}

bool QMRIssuerBin::insert ()
{
  //## begin QMRIssuerBin::insert%6049C4380252.body preserve=yes
   string strTemp(m_strFileINST_ID);
   strTemp.resize(11,' ');
   strTemp.append(m_strFileNETWORK_ID);
   strTemp.resize(14,' ');
   strTemp.append(m_strFileBIN);
   if (ConfigurationRepository::instance()->verify("QMR_BIN",strTemp))
      return true;
   if (ConfigurationRepository::instance()->translate("INSTITUTION",m_strFileINST_ID,strTemp,"","",-1,false) == false)
      return true;
   if (!m_pUpdateStatement)
      m_pUpdateStatement = (Statement*)DatabaseFactory::instance()->create("UpdateStatement");
   if (!m_pInsertStatement)
      m_pInsertStatement = (Statement*)DatabaseFactory::instance()->create("InsertStatement");
   m_hTable.reset();
   m_hTable.set("INST_ID", m_strFileINST_ID, false, true);
   m_hTable.set("INST_STAT", " ", false, true);
   m_hTable.set("CUST_ID", Customer::instance()->getCUST_ID(), false, true);
   m_hTable.set("CUST_STAT", " ", false, true);
   m_hTable.set("BIN", m_strFileBIN, false, true);
   m_hTable.set("NETWORK_ID", m_strFileNETWORK_ID, false, true);
   m_hTable.set("CIRRUS_LOGO", "N");
   m_hTable.set("MASTERCARD_LOGO", "N");
   m_hTable.set("MAESTRO_LOGO", "N");
   m_hTable.set("VISA_LOGO", "N");
   m_hTable.set("INTERLINK_LOGO", "N");
   m_hTable.set("PLUS_LOGO", "N");
   if (m_strFileNETWORK_ID == "***")
      m_hTable.set(m_strLogoColumn.c_str(),"Y");
   m_hTable.set("CC_STATE", "A");
   m_hTable.set("CC_USER_ID", "SYSTEM");
   m_hTable.set("CC_LAST_OPERATION", "INS");
   m_hTable.set("CC_TSTAMP_CHANGE", Clock::instance()->getYYYYMMDDHHMMSS());
   if (m_pInsertStatement->execute(m_hTable) == false)
   {
      m_hTable.set("CC_LAST_OPERATION","UPD");
      if (!(m_pInsertStatement->getInfoIDNumber() == STS_DUPLICATE_RECORD
         && m_pUpdateStatement->execute(m_hTable)))
      {
         Database::instance()->rollback();
         return UseCase::setSuccess(false);
      }
   }
   return true;
  //## end QMRIssuerBin::insert%6049C4380252.body
}

void QMRIssuerBin::readNext ()
{
  //## begin QMRIssuerBin::readNext%637CBBBC03B7.body preserve=yes
   if (!read(m_szBuffer,256,&m_lRecordLength))
   {
      m_strFileKey = "9999999999999999999";// to handle the end of the file
      return;
   }
   m_strBuffer.assign(m_szBuffer,m_lRecordLength);
   if (m_strFileNETWORK_ID == "VNT")
   {
      if (m_lRecordLength > 0 && memcmp(m_strBuffer.data(),"SELI",4) != 0)
      {
         readNext();
         return;
      }
      vector<string>hTokens;
      Buffer::parse(m_strBuffer," ",hTokens);
      if (hTokens.size() >= 5)
      {
         m_strFileINST_ID.erase();
         if (hTokens[1].length() >= 2)
            m_strFileINST_ID.assign(hTokens[1].data() + 1);
         m_strFileBIN.assign(hTokens[2]);
         m_strFileKey.assign(m_strFileINST_ID);
         m_strFileKey.append(m_strFileBIN);
      }
   }
   else
   {
      map<int,string,less<int> >::iterator pConfig;
      struct QMRIssuer* pQMRIssuer;
      string strTemp;
      size_t pos = 0;
      pQMRIssuer = (struct QMRIssuer*)m_szBuffer;
      strTemp.assign(&pQMRIssuer->cNETWORK_IND,sizeof(pQMRIssuer->cNETWORK_IND));
      if ((pConfig = m_hConfig.find(atoi(strTemp.c_str()))) == m_hConfig.end())
      {
         readNext();
         return;
      }
      m_strFileBIN.assign(pQMRIssuer->sBIN_NO,sizeof(pQMRIssuer->sBIN_NO));
      while ((pos = m_strFileBIN.find("~")) != string::npos)
         m_strFileBIN.erase(pos,1);
      m_strFileINST_ID.assign(pQMRIssuer->sINST_ID,sizeof(pQMRIssuer->sINST_ID));
      rtrim(m_strFileINST_ID);
      m_strFileNETWORK_ID.assign((*pConfig).second);
      m_strFileKey.assign(m_strFileINST_ID);
      m_strFileKey.append(m_strFileBIN);
   }
  //## end QMRIssuerBin::readNext%637CBBBC03B7.body
}

void QMRIssuerBin::update (Subject* pSubject)
{
  //## begin QMRIssuerBin::update%637CBBBA01DA.body preserve=yes
    if (pSubject == &m_hQuery)
    {
       m_strDBKey.assign(m_strINST_ID);
       m_strDBKey.append(m_strBIN);
       while (m_strFileKey < m_strDBKey) // to handle new entry in file
       {
          if (!insert())
          {
             m_hQuery.setAbort(true);
             return;
          }
          readNext();
       }
       if (m_strFileKey > m_strDBKey)  // to handle deleted entry from file
       {
          if (!applyDelete())
          {
             m_hQuery.setAbort(true);
             return;
          }
       }
       else
       {
          if ((m_strNETWORK_ID != m_strFileNETWORK_ID 
             && applyDelete() == false) || insert() == false)
          {
             m_hQuery.setAbort(true);
             return;
          }
          readNext();
       }
    }
  //## end QMRIssuerBin::update%637CBBBA01DA.body
}

// Additional Declarations
  //## begin QMRIssuerBin%601902980214.declarations preserve=yes
  //## end QMRIssuerBin%601902980214.declarations

//## begin module%601902060290.epilog preserve=yes
//## end module%601902060290.epilog
