//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4F7AC46F0239.cm preserve=no
//	$Date:   Apr 23 2012 07:27:18  $ $Author:   e1012231  $
//	$Revision:   1.3  $
//## end module%4F7AC46F0239.cm

//## begin module%4F7AC46F0239.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4F7AC46F0239.cp

//## Module: CXOSLM03%4F7AC46F0239; Package specification
//## Subsystem: LM%3597EB1A028A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Lm\CXODLM03.hpp

#ifndef CXOSLM03_h
#define CXOSLM03_h 1

//## begin module%4F7AC46F0239.additionalIncludes preserve=no
//## end module%4F7AC46F0239.additionalIncludes

//## begin module%4F7AC46F0239.includes preserve=yes
//## end module%4F7AC46F0239.includes

#ifndef CXOSRU20_h
#include "CXODRU20.hpp"
#endif
#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Console;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class GlobalContext;
class Context;
class DatabaseFactory;
class Database;
} // namespace database

namespace IF {
class Job;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
class MidnightAlarm;
} // namespace timer

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%4F7AC46F0239.declarations preserve=no
//## end module%4F7AC46F0239.declarations

//## begin module%4F7AC46F0239.additionalDeclarations preserve=yes
//## end module%4F7AC46F0239.additionalDeclarations


//## begin TransactionHistory%4F7ABCA101C3.preface preserve=yes
//## end TransactionHistory%4F7ABCA101C3.preface

//## Class: TransactionHistory%4F7ABCA101C3
//## Category: DataNavigator Foundation::Application::LocatorManager_CAT%354B349200A7
//## Subsystem: LM%3597EB1A028A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4F7AC2240050;database::Database { -> F}
//## Uses: <unnamed>%4F7AC22C0031;IF::Job { -> F}
//## Uses: <unnamed>%4F7AC24E00CC;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4F7AC25A008D;database::Context { -> F}
//## Uses: <unnamed>%4F7AC262030E;process::Application { -> F}
//## Uses: <unnamed>%4F7AC2680139;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4F7AC26C011A;timer::Clock { -> F}
//## Uses: <unnamed>%4F7EAA7901B9;timer::Date { -> F}
//## Uses: <unnamed>%4F913DB000A2;database::Context { -> F}
//## Uses: <unnamed>%4F913DD002F3;database::GlobalContext { -> F}
//## Uses: <unnamed>%4F94EB670156;reusable::Statement { -> F}
//## Uses: <unnamed>%4F950396017F;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%4F951C35016C;IF::Console { -> F}

class DllExport TransactionHistory : public reusable::Observer  //## Inherits: <unnamed>%4F7DD8A100E3
{
  //## begin TransactionHistory%4F7ABCA101C3.initialDeclarations preserve=yes
  //## end TransactionHistory%4F7ABCA101C3.initialDeclarations

  public:
    //## Constructors (generated)
      TransactionHistory();

    //## Destructor (generated)
      virtual ~TransactionHistory();


    //## Other Operations (specified)
      //## Operation: getTransactions%4F7ABEA200CF
      void getTransactions (const string& strCONTEXT_KEY, const string& strCONTEXT_DATA);

      //## Operation: inspectTaskContext%4F9508A0010C
      void inspectTaskContext ();

      //## Operation: processTransactions%4F86EEC50331
      void processTransactions ();

      //## Operation: reset%4F7ABE8400C0
      void reset (const string& strInstId, const string& strEndDate, bool bResponse);

      //## Operation: saveContext%4F7ABF4200FA
      void saveContext (const char* pszKey, const char* pszData);

      //## Operation: update%4F7D959900D2
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin TransactionHistory%4F7ABCA101C3.public preserve=yes
      //## end TransactionHistory%4F7ABCA101C3.public

  protected:
    // Additional Protected Declarations
      //## begin TransactionHistory%4F7ABCA101C3.protected preserve=yes
      //## end TransactionHistory%4F7ABCA101C3.protected

  private:
    // Additional Private Declarations
      //## begin TransactionHistory%4F7ABCA101C3.private preserve=yes
      //## end TransactionHistory%4F7ABCA101C3.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: CONTEXT_DATA%4F7B2828039A
      //## begin TransactionHistory::CONTEXT_DATA%4F7B2828039A.attr preserve=no  private: string {U} 
      string m_strCONTEXT_DATA;
      //## end TransactionHistory::CONTEXT_DATA%4F7B2828039A.attr

      //## Attribute: CONTEXT_KEY%4F7C61120078
      //## begin TransactionHistory::CONTEXT_KEY%4F7C61120078.attr preserve=no  private: string {U} 
      string m_strCONTEXT_KEY;
      //## end TransactionHistory::CONTEXT_KEY%4F7C61120078.attr

      //## Attribute: BeginDate%4F7C823903AE
      //## begin TransactionHistory::BeginDate%4F7C823903AE.attr preserve=no  private: string {U} 
      string m_strBeginDate;
      //## end TransactionHistory::BeginDate%4F7C823903AE.attr

      //## Attribute: EndDate%4F7C825D0227
      //## begin TransactionHistory::EndDate%4F7C825D0227.attr preserve=no  private: string {U} 
      string m_strEndDate;
      //## end TransactionHistory::EndDate%4F7C825D0227.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%4F7AC2CA031C
      //## Role: TransactionHistory::<m_pTimer>%4F7AC2CB036A
      //## begin TransactionHistory::<m_pTimer>%4F7AC2CB036A.role preserve=no  public: timer::Timer { -> VHgN}
      timer::Timer m_pTimer;
      //## end TransactionHistory::<m_pTimer>%4F7AC2CB036A.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%4F7D9C6F027A
      //## Role: TransactionHistory::<m_pRow>%4F7D9C7001BE
      //## begin TransactionHistory::<m_pRow>%4F7D9C7001BE.role preserve=no  public: reusable::Row { -> UHgN}
      reusable::Row m_pRow;
      //## end TransactionHistory::<m_pRow>%4F7D9C7001BE.role

      //## Association: DataNavigator Foundation::Application::LocatorManager_CAT::<unnamed>%4F843918038C
      //## Role: TransactionHistory::<m_hQuery>%4F843919036D
      //## begin TransactionHistory::<m_hQuery>%4F843919036D.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end TransactionHistory::<m_hQuery>%4F843919036D.role

    // Additional Implementation Declarations
      //## begin TransactionHistory%4F7ABCA101C3.implementation preserve=yes
      //## end TransactionHistory%4F7ABCA101C3.implementation

};

//## begin TransactionHistory%4F7ABCA101C3.postscript preserve=yes
//## end TransactionHistory%4F7ABCA101C3.postscript

//## begin module%4F7AC46F0239.epilog preserve=yes
//## end module%4F7AC46F0239.epilog


#endif
