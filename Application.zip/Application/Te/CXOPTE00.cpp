//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%38CE94C303B4.cm preserve=no
//## end module%38CE94C303B4.cm

//## begin module%38CE94C303B4.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%38CE94C303B4.cp

//## Module: CXOPTE00%38CE94C303B4; Package body
//## Subsystem: TE%38CE945500E5
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\Dn\Server\Application\Te\CXOPTE00.cpp

//## begin module%38CE94C303B4.additionalIncludes preserve=no
//## end module%38CE94C303B4.additionalIncludes

//## begin module%38CE94C303B4.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#include "CXODIF25.hpp"
#include "CXODDB30.hpp"
#include "CXODDB56.hpp"
#include "CXODAT10.hpp"
#include "CXODTC66.hpp"
#include "CXODDB28.hpp"
#ifndef CXOSST83_h
#include "CXODST83.hpp"
#endif
#ifndef CXOSST84_h
#include "CXODST84.hpp"
#endif
#include "CXODBS23.hpp"
#include "CXODRU12.hpp"
#include "CXODRU08.hpp"
#include "CXODTM06.hpp"
#include "CXODDB10.hpp"
#include "CXODIF01.hpp"
#include "CXODRU34.hpp"
#include "CXODRU28.hpp"
#include "CXODBS09.hpp"
#include "CXODIF15.hpp"
#include "CXODIF03.hpp"
#include "CXODRU10.hpp"
//## end module%38CE94C303B4.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSST16_h
#include "CXODST16.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSST28_h
#include "CXODST28.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSNS39_h
#include "CXODNS39.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSST33_h
#include "CXODST33.hpp"
#endif
#ifndef CXOSST02_h
#include "CXODST02.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSTM11_h
#include "CXODTM11.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSPF01_h
#include "CXODPF01.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSDB08_h
#include "CXODDB08.hpp"
#endif
#ifndef CXOSST44_h
#include "CXODST44.hpp"
#endif
#ifndef CXOSDB27_h
#include "CXODDB27.hpp"
#endif
#ifndef CXOSST10_h
#include "CXODST10.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSST41_h
#include "CXODST41.hpp"
#endif
#ifndef CXOSTC59_h
#include "CXODTC59.hpp"
#endif
#ifndef CXOSDB50_h
#include "CXODDB50.hpp"
#endif
#ifndef CXOSST46_h
#include "CXODST46.hpp"
#endif
#ifndef CXOSST04_h
#include "CXODST04.hpp"
#endif
#ifndef CXOSST63_h
#include "CXODST63.hpp"
#endif
#ifndef CXOSST56_h
#include "CXODST56.hpp"
#endif
#ifndef CXOSDB16_h
#include "CXODDB16.hpp"
#endif
#ifndef CXOSRU55_h
#include "CXODRU55.hpp"
#endif
#ifndef CXOSST07_h
#include "CXODST07.hpp"
#endif
#ifndef CXOSST71_h
#include "CXODST71.hpp"
#endif
#ifndef CXOSPF38_h
#include "CXODPF38.hpp"
#endif
#ifndef CXOSTC32_h
#include "CXODTC32.hpp"
#endif
#ifndef CXOSST78_h
#include "CXODST78.hpp"
#endif
#ifndef CXOSST79_h
#include "CXODST79.hpp"
#endif
#ifndef CXOSST45_h
#include "CXODST45.hpp"
#endif
#ifndef CXOSST64_h
#include "CXODST64.hpp"
#endif
#ifndef CXOSST66_h
#include "CXODST66.hpp"
#endif
#ifndef CXOSST69_h
#include "CXODST69.hpp"
#endif
#ifndef CXOSPS11_h
#include "CXODPS11.hpp"
#endif
#ifndef CXOPTE00_h
#include "CXODTE00.hpp"
#endif


//## begin module%38CE94C303B4.declarations preserve=no
//## end module%38CE94C303B4.declarations

//## begin module%38CE94C303B4.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new TotalsEngine();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%38CE94C303B4.additionalDeclarations


// Class TotalsEngine 

TotalsEngine::TotalsEngine()
  //## begin TotalsEngine::TotalsEngine%38CE947F0013_const.hasinit preserve=no
      : m_bWallClock(false),
        m_pSettlementFileFactory(0),
        m_pMISRepair(0),
        m_pDataExport(0),
        m_pTransactionRead(0),
        m_pTransactionTotal(0)
  //## end TotalsEngine::TotalsEngine%38CE947F0013_const.hasinit
  //## begin TotalsEngine::TotalsEngine%38CE947F0013_const.initialization preserve=yes
  ,m_pGenericSegment(0)
  //## end TotalsEngine::TotalsEngine%38CE947F0013_const.initialization
{
  //## begin TotalsEngine::TotalsEngine%38CE947F0013_const.body preserve=yes
   memcpy(m_sID,"TE00",4);
   m_hQuery[0].attach(this);
   m_hQuery[1].attach(this);
   m_iCycle = 1;
   m_iSYNC_INTERVAL_NO = 0;
   m_bInitialized = false;
  //## end TotalsEngine::TotalsEngine%38CE947F0013_const.body
}


TotalsEngine::~TotalsEngine()
{
  //## begin TotalsEngine::~TotalsEngine%38CE947F0013_dest.body preserve=yes
   if (TransactionMediator::instance()->getMultiThread())
   {
      process::Thread::setQuiesce(true);
      while (1)
      {
         if (m_pTransactionRead->getState() == process::Thread::THREAD_SHUTDOWN
            && m_pTransactionTotal->getState() == process::Thread::THREAD_SHUTDOWN
            && m_pDataExport->getState() == process::Thread::THREAD_SHUTDOWN)
            break;
         Sleep::goTo("00000100");
      }
   }
   MinuteTimer::instance()->detach(this);
   delete Replication::instance();
   if (m_pSettlementFileFactory)
   {
      delete FinancialSettlement::instance();
      delete m_pSettlementFileFactory;
   }
   if (!TransactionMediator::instance()->getMultiThread())
   {
      delete CutoffMediator::instance();
      delete AdminMediator::instance();
      delete AmountMediator::instance();
      delete TransactionMediator::instance();
   }
   delete FileFactory::instance();
   delete m_pMISRepair;
   delete m_pGenericSegment;
  //## end TotalsEngine::~TotalsEngine%38CE947F0013_dest.body
}



//## Other Operations (implementation)
bool TotalsEngine::convert ()
{
  //## begin TotalsEngine::convert%65BE7F1001E0.body preserve=yes
   Context hContext(Application::instance()->image(), Application::instance()->name());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_iSYNC_INTERVAL_NO = 0;
   if (!m_pGenericSegment)
      m_pGenericSegment = new segment::GenericSegment();
   else
      m_pGenericSegment->reset();
   if (m_strCoversionProgress == "INITIATED")
   {
      //Identify if T_FIN_ENTITY_ID for CU is as expected else fix it.
      //Step1 : Get CU's T_FIN_ENTITY_ID
      int iT_FIN_ENTITY_ID[2];
      Query hQuery;
      hQuery.bind("T_FIN_ENTITY", "T_FIN_ENTITY_ID", reusable::Column::LONG, &iT_FIN_ENTITY_ID[0]);
      hQuery.setBasicPredicate("T_FIN_ENTITY", "ENTITY_TYPE", "=", "CU");
      hQuery.setBasicPredicate("T_FIN_ENTITY", "ENTITY_ID", "=", Customer::instance()->getCUST_ID().c_str());
      if (pSelectStatement->execute(hQuery) == false)
      {
         Trace::put("Step1 : Get CU's T_FIN_ENTITY_ID failed", -1, true);
         return false;
      }
      if (iT_FIN_ENTITY_ID[0] != 1)
      {
         string strENTITY_TYPE;
         string strENTITY_ID;
         short siNull = -1;
         //Step2 : get ENTITY_TYPE and ENTITY_ID where T_FIN_ENTITY_ID is 1 
         hQuery.reset();
         hQuery.bind("T_FIN_ENTITY", "ENTITY_TYPE", reusable::Column::STRING, &strENTITY_TYPE);
         hQuery.bind("T_FIN_ENTITY", "ENTITY_ID", reusable::Column::STRING, &strENTITY_ID);
         hQuery.setBasicPredicate("T_FIN_ENTITY", "T_FIN_ENTITY_ID", "=", 1);
         if (pSelectStatement->execute(hQuery) == false)
         {
            Trace::put("Step2 : get ENTITY_TYPE and ENTITY_ID where T_FIN_ENTITY_ID is 1 failed", -1, true);
            return false;
         }

         //Step3 : get  MAX T_FIN_ENTITY_ID + 1 
         hQuery.reset();
         hQuery.bind("T_FIN_ENTITY", "T_FIN_ENTITY_ID", reusable::Column::LONG, &iT_FIN_ENTITY_ID[1], &siNull, "MAX");
         if (pSelectStatement->execute(hQuery) == false)
         {
            Trace::put("Step3 : get  MAX T_FIN_ENTITY_ID + 1  failed", -1, true);
            return false;
         }
         iT_FIN_ENTITY_ID[1]++;

         //Step4 : Insert Psuedo Entry in T_FIN_ENTITY 
         m_hTable.reset();
         m_hTable.setName("T_FIN_ENTITY");
         m_hTable.set("T_FIN_ENTITY_ID", iT_FIN_ENTITY_ID[1], true);
         m_hTable.set("ENTITY_TYPE", "XX");
         m_hTable.set("ENTITY_ID", strENTITY_ID);
         auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
         auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
         if (!pInsertStatement->execute(m_hTable))
         {
            Trace::put("Step4 : Insert Psuedo Entry in T_FIN_ENTITY failed", -1, true);
            return false;
         }
         //Step5 : Update All Child Tables where T_FIN_ENTITY_ID = 1 to  MAX + 1
         vector <string> hTables;
         hTables.push_back("T_FIN_PERIOD");
         hTables.push_back("T_MIS_TOTAL");
         hTables.push_back("T_FIN_COUNT");
         hTables.push_back("T_CANISTER");
         for (int i = 0; i < hTables.size(); i++)
         {
            char* szColumnName[] = { "T_FIN_ENTITY_ID","T_FIN_ENTITY_ID_2" };
            for (int j = 0; j < (hTables[i] == "T_MIS_TOTAL" ? 2 : 1); j++)
            {
               m_hTable.reset();
               m_hTable.setName(hTables[i]);
               m_hTable.set(szColumnName[j], iT_FIN_ENTITY_ID[1]);
               SearchCondition hSearchCondition;
               hSearchCondition.setBasicPredicate(hTables[i].c_str(), szColumnName[j], "=", (int)1);
               if (!pUpdateStatement->execute(m_hTable, hSearchCondition.getText()) && pUpdateStatement->getInfoIDNumber() != STS_RECORD_NOT_FOUND)
               {
                  Trace::put("Step5 Error updating T_FIN_ENTITY_ID for Table:", hTables[i], true);
                  return false;
               }
            }
         }
         // Step6 : Update the row with T_FIN_ENTITY_ID 1 with a Dummy ENTITY_TYPE  
         m_hTable.reset();
         m_hTable.setName("T_FIN_ENTITY");
         m_hTable.set("T_FIN_ENTITY_ID", (int)1, true);
         m_hTable.set("ENTITY_TYPE", "XX");
         m_hTable.set("ENTITY_ID", Customer::instance()->getCUST_ID());
         if (!pUpdateStatement->execute(m_hTable))
         {
            Trace::put("Step6 : Updating the row with T_FIN_ENTITY_ID 1 with a Dummy ENTITY_TYPE failed", -1, true);
            return false;
         }
         // Step7 : Update the MAX entry with the Original ENTITY_TYPE  
         m_hTable.reset();
         m_hTable.setName("T_FIN_ENTITY");
         m_hTable.set("T_FIN_ENTITY_ID", iT_FIN_ENTITY_ID[1], true);
         m_hTable.set("ENTITY_TYPE", strENTITY_TYPE);
         if (!pUpdateStatement->execute(m_hTable))
         {
            Trace::put("Step7 : Updating the MAX entry with the Original ENTITY_TYPE and ENTITY_ID failed", -1, true);
            return false;
         }
         //Step8 : Update All Child Tables that is a CU Entity with T_FIN_ENTITY_ID as 1  
         for (int i = 0; i < hTables.size(); i++)
         {
            m_hTable.reset();
            m_hTable.setName(hTables[i]);
            char* szColumnName[] = { "T_FIN_ENTITY_ID","T_FIN_ENTITY_ID_2" };
            for (int j = 0; j < (hTables[i] == "T_MIS_TOTAL" ? 2 : 1); j++)
            {
               SearchCondition hSearchCondition;
               m_hTable.set(szColumnName[j], (int)1);
               hSearchCondition.setBasicPredicate(hTables[i].c_str(), szColumnName[j], "=", iT_FIN_ENTITY_ID[0]);
               if (!pUpdateStatement->execute(m_hTable, hSearchCondition.getText()) && pUpdateStatement->getInfoIDNumber() != STS_RECORD_NOT_FOUND)
               {
                  Trace::put("Step8 Error updating T_FIN_ENTITY_ID as 1 for Table:", hTables[i], true);
                  return false;
               }
            }
         }
         // Step9 : Delete the Old CU entry;
         hQuery.reset();
         hQuery.setQualifier("CUSTQUAL", "T_FIN_ENTITY");
         hQuery.setBasicPredicate("T_FIN_ENTITY", "T_FIN_ENTITY_ID", "=", iT_FIN_ENTITY_ID[0]);
         if (!pDeleteStatement->execute(hQuery))
         {
            Trace::put("Step9 : Deleting the Old CU entry failed", -1, true);
            return false;
         }

         // Step10 : Update the CU entry with correct ENTITY_TYPE
         m_hTable.reset();
         m_hTable.setName("T_FIN_ENTITY");
         m_hTable.set("T_FIN_ENTITY_ID", (int)1, true);
         m_hTable.set("ENTITY_TYPE", "CU");
         if (!pUpdateStatement->execute(m_hTable))
         {
            Trace::put("Step10 : Update the CU entry with correct ENTITY_ID failed", -1, true);
            return false;
         }
         //Step11 : Commit
         if (Database::instance()->commit() != 0)
         {
            Trace::put("Step11 Error correcting CU T_FIN_ENTITY_ID as 1", -1, true);
            return false;
         }
      }
      if (!DatabaseCatalog::instance()->isExisting("T_FIN_PERIOD2") ||
         !DatabaseCatalog::instance()->isExisting("T_FIN_SUM2"))
      {
         Job::submit("CXOXCRV2");
         return true;
      }
   }
   if (m_hPeriod.empty())
   {
      m_hTable.reset();
      m_hTable.setName("T_FIN_PERIOD2");
      m_hQuery[0].reset();
      m_hQuery[0].setIndex(1);
      m_hPeriod.clear();
      m_pGenericSegment->bind("T_FIN_PERIOD", "PERIOD_ID", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_PERIOD", "T_FIN_ENTITY_ID", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_PERIOD", "TSTAMP_END", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_PERIOD", "TSTAMP_TRANS_FROM", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_PERIOD", "TSTAMP_TRANS_TO", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_PERIOD", "DATE_RECON", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_PERIOD", "TSTAMP_LAST_UPDATE", m_hQuery[0]);
      m_hQuery[0].setOrderByClause("DATE_RECON,T_FIN_ENTITY_ID,TSTAMP_END");
      if (pSelectStatement->execute(m_hQuery[0]) == false || Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      {
         Trace::put("Error inserting into T_FIN_PERIOD2", -1, true);
         return false;
      }
   }
   if (m_strCoversionProgress == "INITIATED")
   {
      m_strCoversionProgress = "PERIOD LOADED";
      hContext.put("CONVERSION PROGRESS", m_strCoversionProgress.c_str());
      if (Database::instance()->commit() != 0)
      {
         Trace::put("Error updating CoversionProgress to ", m_strCoversionProgress, true);
         return false;
      }
   }
   if (m_strCoversionProgress != "T_FIN_SUM LOADED" && m_strCoversionProgress != "VALIDATED")
   {
      m_pGenericSegment->reset();
      m_hTable.reset();
      m_hTable.setName("T_FIN_SUM2");
      m_hQuery[0].reset();
      m_hQuery[0].setIndex(2);
      m_hSum.clear();
      m_hQuery[0].join("T_FIN_ENTITY_GROUP", "INNER", "T_FIN_E_GROUP_ITEM", "ENTITY_GROUP_ID");
      m_hQuery[0].join("T_FIN_E_GROUP_ITEM", "INNER", "T_FIN_TOTAL", "ENTITY_GROUP_ID");
      m_pGenericSegment->bind("T_FIN_ENTITY_GROUP", "SYNC_INTERVAL_NO", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_E_GROUP_ITEM", "PERIOD_ID", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_E_GROUP_ITEM", "SEQUENCE_NO", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_TOTAL", "CATEGORY_ID", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_TOTAL", "TRAN_COUNT", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_TOTAL", "AMT_RECON_NET", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_TOTAL", "AMT_TRAN", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_TOTAL", "AMT_CARD_BILL", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_TOTAL", "AMT_RECON_ACQ", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_TOTAL", "AMT_RECON_ISS", m_hQuery[0]);
      m_pGenericSegment->bind("T_FIN_TOTAL", "TSTAMP_LAST_UPDATE", m_hQuery[0]);
      if (atoi(m_strCoversionProgress.c_str()) > 0)
         m_hQuery[0].setBasicPredicate("T_FIN_ENTITY_GROUP", "SYNC_INTERVAL_NO", ">", m_strCoversionProgress.c_str());
      m_hQuery[0].setOrderByClause("SYNC_INTERVAL_NO,T_FIN_ENTITY_GROUP.ENTITY_GROUP_ID,T_FIN_TOTAL.CATEGORY_ID,SEQUENCE_NO");
      if (pSelectStatement->execute(m_hQuery[0]) == false
         || Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      {
         Trace::put("Error updating T_FIN_SUM2", -1, true);
         return false;
      }
      if (pSelectStatement->getRows() == 0)
      {
         m_strCoversionProgress = "T_FIN_SUM LOADED";
         if (!hContext.put("CONVERSION PROGRESS", m_strCoversionProgress.c_str()))
         {
            Trace::put("Error updating CoversionProgress to ", m_strCoversionProgress, true);
            return false;
         }
      }
      else if (m_iSYNC_INTERVAL_NO > 0 && m_hQuery[0].getAbort() == false)
      {
         auto_ptr<Statement> pStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
         map<string, hSum>::iterator pSum;
         for (pSum = m_hSum.begin(); pSum != m_hSum.end(); pSum++)
         {
            m_hTable.set("SYNC_INTERVAL_NO", (*pSum).second.iSYNC_INTERVAL_NO, true);
            m_hTable.set("CU_PERIOD_ID", (*pSum).second.iCU_PERIOD_ID, true);
            m_hTable.set("AT_PERIOD_ID", (*pSum).second.iAT_PERIOD_ID, true);
            m_hTable.set("AM_PERIOD_ID", (*pSum).second.iAM_PERIOD_ID, true);
            m_hTable.set("AI_PERIOD_ID", (*pSum).second.iAI_PERIOD_ID, true);
            m_hTable.set("AP_PERIOD_ID", (*pSum).second.iAP_PERIOD_ID, true);
            m_hTable.set("II_PERIOD_ID", (*pSum).second.iII_PERIOD_ID, true);
            m_hTable.set("IP_PERIOD_ID", (*pSum).second.iIP_PERIOD_ID, true);
            m_hTable.set("CATEGORY_ID", (*pSum).second.iCATEGORY_ID, true);
            m_hTable.set("TRAN_COUNT", (*pSum).second.iTRAN_COUNT);
            m_hTable.set("AMT_RECON_NET", (*pSum).second.dAMT_RECON_NET);
            m_hTable.set("AMT_TRAN", (*pSum).second.dAMT_TRAN);
            m_hTable.set("AMT_CARD_BILL", (*pSum).second.dAMT_CARD_BILL);
            m_hTable.set("AMT_RECON_ISS", (*pSum).second.dAMT_RECON_ISS);
            m_hTable.set("AMT_RECON_ACQ", (*pSum).second.dAMT_RECON_ACQ);
            m_hTable.set("TSTAMP_LAST_UPDATE", (*pSum).second.strTSTAMP_LAST_UPDATE);
            if (!pStatement->execute(m_hTable))
            {
               Trace::put("Error Inserting into :", m_hTable.getName(), true);
               Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
               break;
            }
         }
         m_hSum.erase(m_hSum.begin(), m_hSum.end());
         if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
            return false;
         char szTemp[PERCENTD];
         snprintf(szTemp, PERCENTD, "%d", m_iSYNC_INTERVAL_NO);
         m_strCoversionProgress.assign(szTemp);
         hContext.put("CONVERSION PROGRESS", m_strCoversionProgress.c_str());
         if (Database::instance()->commit() != 0)
         {
            Trace::put("Error updating CoversionProgress to ", m_strCoversionProgress, true);
            return false;
         }
         Trace::put("Completed SYNC_INETRVAL_NO :", szTemp, true);
      }
   }
   if (m_strCoversionProgress == "T_FIN_SUM LOADED")
   {
      Job::submit("CXOXSTAT");
      if (validate() == false)
      {
         Trace::put("Validation failed", -1, true);
         return false;
      }
      else
      {
         Trace::put("Validated Successfully", -1, true);
         m_strCoversionProgress = "VALIDATED";
         if (!hContext.put("CONVERSION PROGRESS", m_strCoversionProgress.c_str()))
         {
            Trace::put("Error updating CoversionProgress to ", m_strCoversionProgress, true);
            return false;
         }
      }
   }
   if (m_strCoversionProgress == "VALIDATED")
   {
      if (!DatabaseCatalog::instance()->isExisting("T_FIN_SUM"))
      {
         Job::submit("CXOXDRV1");
      }
      else
      {
         m_strCoversionProgress = "COMPLETE";
         if (!hContext.put("CONVERSION PROGRESS", m_strCoversionProgress.c_str()))
         {
            Trace::put("Error updating CoversionProgress to ", m_strCoversionProgress, true);
            return false;
         }
         else
         {
            if(Database::instance()->commit() !=0)
               return false;
            TotalsMediator::instance()->abort();
            database::Cache::reload(Customer::instance());  
            initialize();
            m_pSettlementFileFactory->update(MidnightAlarm::instance());
            database::Cache::reload(settlement::FinancialSettlement::instance());
            m_hPeriod.erase(m_hPeriod.begin(), m_hPeriod.end());
            delete m_pGenericSegment;
            m_pGenericSegment = 0;
            m_hValidate[0].clear();
            m_hValidate[1].clear();
            Trace::put("Conversion Complete", -1, true);
            Console::display("ST604", "CONVERT");
         }
      }
   }
   return (Database::instance()->commit() == 0);
  //## end TotalsEngine::convert%65BE7F1001E0.body
}

int TotalsEngine::initialize ()
{
  //## begin TotalsEngine::initialize%38CE97B40046.body preserve=yes
   if (!m_bInitialized)
   {
      new dnplatform::DNPlatform();
      int iRC = Application::initialize();
      if (iRC == -1)
      {
         UseCase::setSuccess(false);
         return -1;
      }

      platform::Platform::instance()->createDatabaseFactory();
      string strRecord;
      if (Extract::instance()->getRecord("DUSER", strRecord))
         m_bWallClock = strRecord.find("WALL") != string::npos;
      string strDBVendor;
      Extract::instance()->getSpec("DBVENDOR", strDBVendor);
      database::DataModel::instance();
      database::CRTransactionTypeIndicator::instance();
      entitysegment::Customer::instance();
      postingfile::Reports::instance();
      entitysegment::Progress::instance();
      atm::Hierarchy::instance();
      entitysegment::SwitchBusinessDay::instance();
      settlement::FinancialSettlement::instance();
      settlement::Reconciliation::instance();
      totalscommand::Total::instance();
      settlement::FinancialRupay::instance();
      totalscommand::DirectRoute::instance();
      new PostingFileFactory();
      PostingFileFactory::instance()->setDailyFiles("('TXNACT','WHFILE','TXNSUS','TXNBRS','TXNMPU','TXNMUL','TXNRDF','TXNRDV','TXNRUD','TXNSTR','TXNCLM','TXNCLV','TXNDTL','RAWDAT')");
      PostingFileFactory::instance()->setMonthlyFiles("('DFRDEB','TXNDBA','TXMACT')");
      m_pMISRepair = new MISRepair();
      TotalsCategory::setSelections();
      MinuteTimer::instance()->attach(this);
      if (strRecord.find("MT") != string::npos)
      {
         m_pTransactionRead = new TransactionRead();
         m_pTransactionTotal = new TransactionTotal();
         m_pDataExport = new DataExport();
         Delegate::instance(m_pTransactionTotal->getNumber())->setCONTEXT_KEY("TRANSACTION PROGRESS");
         Delegate::instance(m_pDataExport->getNumber())->setCONTEXT_KEY("REPLICATION PROGRESS");
         Delegate::instance(m_pTransactionRead->getNumber());
         int i = 3;
         string strValue;
         if (Extract::instance()->getSpec("MTTOTAL", strValue))
            i = atoi(strValue.c_str());
         do
         {
            m_hDelegation.push_back(new Delegation(m_pTransactionTotal->getNumber()));
         } while (--i);
         i = 3;
         if (Extract::instance()->getSpec("MTEXPORT", strValue))
            i = atoi(strValue.c_str());
         do
         {
            m_hDelegation.push_back(new Delegation(m_pDataExport->getNumber()));
         } while (--i);
         i = 3;
         if (Extract::instance()->getSpec("MTREAD", strValue))
            i = atoi(strValue.c_str());
         do
         {
            m_hDelegation.push_back(new Delegation(m_pTransactionRead->getNumber()));
         } while (--i);
         TransactionMediator::instance()->setMultiThread(true);
         m_pTransactionRead->setState(process::Thread::THREAD_ACTIVE);
         m_pTransactionTotal->setState(process::Thread::THREAD_ACTIVE);
         m_pDataExport->setState(process::Thread::THREAD_ACTIVE);
      }
      UseCase hUseCase("TOTALS", "## TM01 START TE");
      Database::instance()->attach(TransactionMediator::instance());
      // Sleep::goTo("00010000");
      Database::instance()->connect();
   }

   if (entitysegment::Customer::instance()->getTotalsVersion() == 1)
   {
      new RulesMediator1();
      new RepairsMediator1();
      new AmountMediator1();
   }
   else
   {
      new RulesMediator2();
      new RepairsMediator2();
      new AmountMediator2();
      new totalscommand::FinancialSum;
   }
   database::Cache::reload(RulesMediator::instance());
   m_bInitialized = true;
   return 0;
  //## end TotalsEngine::initialize%38CE97B40046.body
}

int TotalsEngine::onReset (Message& hMessage)
{
  //## begin TotalsEngine::onReset%38CE97B8018C.body preserve=yes
   if (hMessage.context().indexOf("REPAIR"))
   {
      m_pMISRepair->execute();
      TotalsMediator::instance()->abort();
      return 0;
   }
   else
   if (memcmp((char*)hMessage.context(),"EOD",3) == 0)
   {
      string strYYYYMMDDHHMMSSHN;
      if (memcmp((char*)hMessage.context() + 8,"CURRENT",7) == 0)
      {
         string strYYYYMMDDHHMMSSHN = entitysegment::SwitchBusinessDay::instance()->getTSTAMP_END(1);
         SwitchClock::instance()->set(strYYYYMMDDHHMMSSHN);
      }
      else
      {
         strYYYYMMDDHHMMSSHN.assign((char*)hMessage.context(),8,8);
         if (hMessage.context().length() == 20)
         {
            strYYYYMMDDHHMMSSHN.append((char*)hMessage.context(),16,4);
            strYYYYMMDDHHMMSSHN.append("0000");
         }
         else
            strYYYYMMDDHHMMSSHN += Customer::instance()->getCUTOFF_TIME();
         if (strYYYYMMDDHHMMSSHN > SwitchClock::instance()->getYYYYMMDDHHMMSS())
            SwitchClock::instance()->set(strYYYYMMDDHHMMSSHN);
      }
      if (Extract::instance()->getCustomCode() == "MPS")
      {
         // prevent auto close of business day due to switch feed
         Channel hChannel(Application::instance()->image(),Application::instance()->name());
         if (!hChannel.setProgress(strYYYYMMDDHHMMSSHN,0))
            return 0;
      }
      Database::instance()->commit();
   }
   else
   if (memcmp((char*)hMessage.context(), "CONVERT", 7) == 0)
   {
      if (Customer::instance()->getTotalsVersion() == 1)
      {
         Context hContext(Application::instance()->image(), Application::instance()->name());
         if (hContext.put("CONVERSION PROGRESS", "INITIATED"))
         {
            Console::display("ST602", "CONVERT");
            Database::instance()->commit();
         }
         else
            Console::display("ST605", "CONVERT");
      }
      else
         Console::display("ST603", "CONVERT");
   }
   else
   {
      string strContext((char*)hMessage.context());
      size_t n = strContext.find_first_of(' ');
      if (n != string::npos)
         strContext.erase(n);
      if (strContext.length() == 8)
         strContext += "00";
      if (strContext.length() != 10)
         return 0;
      m_strReset = strContext;
   }
   return 0;
  //## end TotalsEngine::onReset%38CE97B8018C.body
}

int TotalsEngine::onResume (Message& hMessage)
{
  //## begin TotalsEngine::onResume%38CE97BB0244.body preserve=yes
   Transaction::instance()->begin();
   Context hContext(Application::instance()->image(), Application::instance()->name());
   if (hContext.get("CONVERSION PROGRESS", m_strCoversionProgress)
      && (!m_strCoversionProgress.empty() && m_strCoversionProgress != "COMPLETE"))
   {
      bool b = convert();
      if (b == false)
         Database::instance()->rollback();
      setQueueWaitOption(!b);
      return 1;
   }
   string strResourceName(Customer::instance()->getCUST_ID());
   strResourceName += "TE";
   CriticalSection hCriticalSection(strResourceName.c_str());
   if (m_strReset.empty() == false
      && entitysegment::Progress::instance()->getTransactionProgress().length() == 15)
   {
      if (TransactionMediator::instance()->reset(m_strReset.c_str()))
      {
         if (m_pSettlementFileFactory)
            m_pSettlementFileFactory->update(MidnightAlarm::instance());
         FileFactory::instance()->update(MidnightAlarm::instance());
         DataControl::instance()->update(MidnightAlarm::instance());
         FinancialSettlement::instance()->update(Database::instance());
         Database::instance()->commit();
      }
      m_strReset.erase();
   }
   if (entitysegment::Progress::instance()->getReplay() && m_bWallClock)
   {
      string strYYYYMMDDHHMMSSHN(entitysegment::Progress::instance()->getTransactionProgress());
      strYYYYMMDDHHMMSSHN.erase(8,3);
      strYYYYMMDDHHMMSSHN += "00";
      Timestamp::gmtToLocal(strYYYYMMDDHHMMSSHN);
      strYYYYMMDDHHMMSSHN += "00";
      SwitchClock::instance()->set(strYYYYMMDDHHMMSSHN);
      Database::instance()->commit();
   }
   // close business day
   if (SwitchClock::instance()->getYYYYMMDDHHMMSSHN() >= entitysegment::SwitchBusinessDay::instance()->getTSTAMP_END(1))
   {
      if (entitysegment::SwitchBusinessDay::instance()->close() == false
         || CutoffMediator::instance()->close() == false
         || RulesMediator::instance()->close() == false)
         setQueueWaitOption(true);
      return true;
   }
   // export FINSA0 file
   if (Customer::instance()->getFIN_TOTALS_FLG() == "Y"
      && SwitchClock::instance()->getYYYYMMDDHHMMSSHN() >= FinancialSettlement::instance()->getTSTAMP_INITIATED())
   {
      if (FinancialSettlement::instance()->process() == false)
      {
         Database::instance()->rollback();
         setQueueWaitOption(true);
         return true;
      }
      Database::instance()->commit();
      return true;
   }
   if (DataControl::instance()->getSuccess() == false)
   {
      setQueueWaitOption(true);
      return true;
   }
   // process transactions
   if (m_bWallClock)
      if (SwitchClock::instance()->getYYYYMMDDHHMMSSHN() < Clock::instance()->getYYYYMMDDHHMMSSHN())
         SwitchClock::instance()->set(Clock::instance()->getYYYYMMDDHHMMSSHN());
   Database::instance()->commit();
   string strCurrentYYYYMMDDJJJHHMM = InsertSequenceNumber::getYYYYMMDDJJJHHMM();
   string strProgress(entitysegment::Progress::instance()->getCutoffProgress());
   // advance to next minute
   string strDate(strProgress.substr(0,11));
   string strTime(strProgress.substr(11,4));
   strTime += "00";
   Timestamp::adjustGMT(strDate,strTime,5);
   strProgress = strDate;
   strProgress += strTime.substr(0,4);
   // stop if caught up to transaction loading
   if (strProgress >= strCurrentYYYYMMDDJJJHHMM)
   {
      setQueueWaitOption(true);
      return true;
   }
   if (Extract::instance()->getCustomCode() == "MPS"
      || Extract::instance()->getCustomCode() == "NPCI")
   {
      if (entitysegment::Progress::instance()->getTransactionProgress() < entitysegment::Progress::instance()->getCutoffProgress())
         setQueueWaitOption(TransactionMediator::instance()->total());
      else
         if (entitysegment::Progress::instance()->getCutoffProgress() < entitysegment::Progress::instance()->getFeeProgress())
         {
            Transaction::instance()->setArray(false);
            setQueueWaitOption(CutoffMediator::instance()->retrieve());
         }
      else
         setQueueWaitOption(AmountMediator::instance()->total());
   }
   else
   {
      if (entitysegment::Progress::instance()->getTransactionProgress() < entitysegment::Progress::instance()->getAdminProgress())
         setQueueWaitOption(TransactionMediator::instance()->total());
      else
      if (entitysegment::Progress::instance()->getAdminProgress() < entitysegment::Progress::instance()->getCutoffProgress())
         setQueueWaitOption(AdminMediator::instance()->retrieve());
      else
      {
         Transaction::instance()->setArray(false);
         setQueueWaitOption(CutoffMediator::instance()->retrieve());
      }
   }
   return 0;
  //## end TotalsEngine::onResume%38CE97BB0244.body
}

void TotalsEngine::update (Subject* pSubject)
{
  //## begin TotalsEngine::update%38CE97BF00C4.body preserve=yes
   if (pSubject == MinuteTimer::instance())
   {
      Replication::instance();
      if (Customer::instance()->getFIN_TOTALS_FLG() == "Y"
         && m_pSettlementFileFactory == 0)
      {
         m_pSettlementFileFactory = new SettlementFileFactory();
         m_pSettlementFileFactory->update(MidnightAlarm::instance());
         database::Cache::reload(settlement::FinancialSettlement::instance());
         // attach PostingFileFactory last to get notified and schedule new files before DataControl refreshes
         // Subject notifies Observers in reverse order
         MidnightAlarm::instance()->detach(PostingFileFactory::instance());
         MidnightAlarm::instance()->attach(PostingFileFactory::instance());
      }
      if (!TransactionMediator::instance()->getMultiThread())
         setQueueWaitOption(false);
      Database::instance()->commit();
   }
   else if (pSubject == &m_hQuery[0])
   {
      if (m_hQuery[0].getIndex() == 1)
      {
         short int siPARTITION_KEY = 0;
         if (m_pGenericSegment->get("DATE_RECON") == "99991231" || m_pGenericSegment->get("DATE_RECON").empty())
         {
            Date hDate(SwitchBusinessDay::instance()->getDATE_RECON(1).c_str());
            siPARTITION_KEY = hDate.getJulianDay();
         }
         else
         {
            Date hDate(m_pGenericSegment->get("DATE_RECON").c_str());
            siPARTITION_KEY = hDate.getJulianDay();
         }
         int iPERIOD_ID = 0;
         int iT_FIN_ENTITY_ID = atoi(m_pGenericSegment->get("T_FIN_ENTITY_ID").c_str());
         if (iT_FIN_ENTITY_ID != 1)
         {
            m_iCycle = 1;
            iPERIOD_ID = ((iT_FIN_ENTITY_ID + 99) * 366) + siPARTITION_KEY;
         }
         else
         {
            iPERIOD_ID = ((m_iCycle - 1) * 366) + siPARTITION_KEY;
            m_iCycle++;
         }
         m_hPeriod[atoi(m_pGenericSegment->get("PERIOD_ID").c_str())] = iPERIOD_ID;
         if(m_strCoversionProgress != "PERIOD LOADED" && atoi(m_strCoversionProgress.c_str()) == 0)
         {
            m_hTable.set("PERIOD_ID", iPERIOD_ID, true);
            m_hTable.set("PARTITION_KEY", siPARTITION_KEY);
            m_hTable.set("T_FIN_ENTITY_ID", atoi(m_pGenericSegment->get("T_FIN_ENTITY_ID").c_str()));
            m_hTable.set("TSTAMP_END", m_pGenericSegment->get("TSTAMP_END"));
            m_hTable.set("TSTAMP_TRANS_FROM", m_pGenericSegment->get("TSTAMP_TRANS_FROM"));
            m_hTable.set("TSTAMP_TRANS_TO", m_pGenericSegment->get("TSTAMP_TRANS_TO"));
            m_hTable.set("DATE_RECON", m_pGenericSegment->get("DATE_RECON"));
            m_hTable.set("TSTAMP_LAST_UPDATE", m_pGenericSegment->get("TSTAMP_LAST_UPDATE"));
            auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("MergeStatement"));
            if (!pInsertStatement->execute(m_hTable))
            {
               Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
               m_hQuery[0].setAbort(true);
               return;
            }
         }
      }
      else if (m_hQuery[0].getIndex() == 2)
      {
         if (atoi(m_pGenericSegment->get("SEQUENCE_NO").c_str()) == 7)
         {
            m_iPERIOD_ID[6] = atoi(m_pGenericSegment->get("PERIOD_ID").c_str());
            hSum hFinSum;
            hFinSum.iCU_PERIOD_ID = m_hPeriod[m_iPERIOD_ID[0]];
            hFinSum.iAT_PERIOD_ID = m_hPeriod[m_iPERIOD_ID[1]];
            hFinSum.iAM_PERIOD_ID = m_hPeriod[m_iPERIOD_ID[2]];
            hFinSum.iAI_PERIOD_ID = m_hPeriod[m_iPERIOD_ID[3]];
            hFinSum.iAP_PERIOD_ID = m_hPeriod[m_iPERIOD_ID[4]];
            hFinSum.iII_PERIOD_ID = m_hPeriod[m_iPERIOD_ID[5]];
            hFinSum.iIP_PERIOD_ID = m_hPeriod[m_iPERIOD_ID[6]];
            hFinSum.iCATEGORY_ID = atoi(m_pGenericSegment->get("CATEGORY_ID").c_str());
            char szKey[(8 * PERCENTD) + 7];
            snprintf(szKey, sizeof(szKey), "%d:%d:%d:%d:%d:%d:%d:%d",
               hFinSum.iCU_PERIOD_ID,
               hFinSum.iAT_PERIOD_ID,
               hFinSum.iAM_PERIOD_ID,
               hFinSum.iAI_PERIOD_ID,
               hFinSum.iAP_PERIOD_ID,
               hFinSum.iII_PERIOD_ID,
               hFinSum.iIP_PERIOD_ID,
               hFinSum.iCATEGORY_ID);
            hFinSum.iSYNC_INTERVAL_NO = atoi(m_pGenericSegment->get("SYNC_INTERVAL_NO").c_str());
            hFinSum.strTSTAMP_LAST_UPDATE = m_pGenericSegment->get("TSTAMP_LAST_UPDATE");
            hFinSum.iTRAN_COUNT = atoi(m_pGenericSegment->get("TRAN_COUNT").c_str());
            hFinSum.dAMT_RECON_NET = atof(m_pGenericSegment->get("AMT_RECON_NET").c_str());
            hFinSum.dAMT_TRAN = atof(m_pGenericSegment->get("AMT_TRAN").c_str());
            hFinSum.dAMT_CARD_BILL = atof(m_pGenericSegment->get("AMT_CARD_BILL").c_str());
            hFinSum.dAMT_RECON_ISS = atof(m_pGenericSegment->get("AMT_RECON_ISS").c_str());
            hFinSum.dAMT_RECON_ACQ = atof(m_pGenericSegment->get("AMT_RECON_ACQ").c_str());
            map<string, hSum>::iterator pSum = m_hSum.find(szKey);
            if (pSum == m_hSum.end())
               m_hSum.insert(map<string, hSum>::value_type(szKey, hFinSum));
            else
            {
               (*pSum).second.iTRAN_COUNT += hFinSum.iTRAN_COUNT;
               (*pSum).second.dAMT_RECON_NET += hFinSum.dAMT_RECON_NET;
               (*pSum).second.dAMT_TRAN += hFinSum.dAMT_TRAN;
               (*pSum).second.dAMT_CARD_BILL += hFinSum.dAMT_CARD_BILL;
               (*pSum).second.dAMT_RECON_ISS += hFinSum.dAMT_RECON_ISS;
               (*pSum).second.dAMT_RECON_ACQ += hFinSum.dAMT_RECON_ACQ;
               (*pSum).second.strTSTAMP_LAST_UPDATE = hFinSum.strTSTAMP_LAST_UPDATE;
            }
            //m_hTable.set("SYNC_INTERVAL_NO"  , atoi(m_pGenericSegment->get("SYNC_INTERVAL_NO").c_str()), true);
            //m_hTable.set("CU_PERIOD_ID"      , m_hPeriod[m_iPERIOD_ID[0]], true);
            //m_hTable.set("AT_PERIOD_ID"      , m_hPeriod[m_iPERIOD_ID[1]], true);
            //m_hTable.set("AM_PERIOD_ID"      , m_hPeriod[m_iPERIOD_ID[2]], true);
            //m_hTable.set("AI_PERIOD_ID"      , m_hPeriod[m_iPERIOD_ID[3]], true);
            //m_hTable.set("AP_PERIOD_ID"      , m_hPeriod[m_iPERIOD_ID[4]], true);
            //m_hTable.set("II_PERIOD_ID"      , m_hPeriod[m_iPERIOD_ID[5]], true);
            //m_hTable.set("IP_PERIOD_ID"      , m_hPeriod[m_iPERIOD_ID[6]], true);
            //m_hTable.set("CATEGORY_ID"       , atoi(m_pGenericSegment->get("CATEGORY_ID").c_str()), true);
            //m_hTable.set("TRAN_COUNT"        , atoi(m_pGenericSegment->get("TRAN_COUNT").c_str()),false,"+");
            //m_hTable.set("AMT_RECON_NET"     , atof(m_pGenericSegment->get("AMT_RECON_NET").c_str()), false, "+");
            //m_hTable.set("AMT_TRAN"          , atof(m_pGenericSegment->get("AMT_TRAN").c_str()), false, "+");
            //m_hTable.set("AMT_CARD_BILL"     , atof(m_pGenericSegment->get("AMT_CARD_BILL").c_str()), false, "+");
            //m_hTable.set("AMT_RECON_ISS"     , atof(m_pGenericSegment->get("AMT_RECON_ISS").c_str()), false, "+");
            //m_hTable.set("AMT_RECON_ACQ"     , atof(m_pGenericSegment->get("AMT_RECON_ACQ").c_str()), false, "+");
            //m_hTable.set("TSTAMP_LAST_UPDATE", m_pGenericSegment->get("TSTAMP_LAST_UPDATE"));
            //auto_ptr<Statement> pStatement((Statement*)DatabaseFactory::instance()->create("MergeStatement"));
            //if (!pStatement->execute(m_hTable))
            //{
            //   Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
            //   m_hQuery[0].setAbort(true);
            //   return;
            //}
            m_iSYNC_INTERVAL_NO = hFinSum.iSYNC_INTERVAL_NO;
         }
         else
         {
            m_iPERIOD_ID[atoi(m_pGenericSegment->get("SEQUENCE_NO").c_str()) - 1] = atoi(m_pGenericSegment->get("PERIOD_ID").c_str());
            if (m_iSYNC_INTERVAL_NO > 0 && m_iSYNC_INTERVAL_NO != atoi(m_pGenericSegment->get("SYNC_INTERVAL_NO").c_str()))
            {
               auto_ptr<Statement> pStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
               map<string, hSum>::iterator pSum;
               for (pSum = m_hSum.begin(); pSum != m_hSum.end(); pSum++)
               {
                  m_hTable.set("SYNC_INTERVAL_NO", (*pSum).second.iSYNC_INTERVAL_NO, true);
                  m_hTable.set("CU_PERIOD_ID", (*pSum).second.iCU_PERIOD_ID, true);
                  m_hTable.set("AT_PERIOD_ID", (*pSum).second.iAT_PERIOD_ID, true);
                  m_hTable.set("AM_PERIOD_ID", (*pSum).second.iAM_PERIOD_ID, true);
                  m_hTable.set("AI_PERIOD_ID", (*pSum).second.iAI_PERIOD_ID, true);
                  m_hTable.set("AP_PERIOD_ID", (*pSum).second.iAP_PERIOD_ID, true);
                  m_hTable.set("II_PERIOD_ID", (*pSum).second.iII_PERIOD_ID, true);
                  m_hTable.set("IP_PERIOD_ID", (*pSum).second.iIP_PERIOD_ID, true);
                  m_hTable.set("CATEGORY_ID", (*pSum).second.iCATEGORY_ID, true);
                  m_hTable.set("TRAN_COUNT", (*pSum).second.iTRAN_COUNT);
                  m_hTable.set("AMT_RECON_NET", (*pSum).second.dAMT_RECON_NET);
                  m_hTable.set("AMT_TRAN", (*pSum).second.dAMT_TRAN);
                  m_hTable.set("AMT_CARD_BILL", (*pSum).second.dAMT_CARD_BILL);
                  m_hTable.set("AMT_RECON_ISS", (*pSum).second.dAMT_RECON_ISS);
                  m_hTable.set("AMT_RECON_ACQ", (*pSum).second.dAMT_RECON_ACQ);
                  m_hTable.set("TSTAMP_LAST_UPDATE", (*pSum).second.strTSTAMP_LAST_UPDATE);
                  if (!pStatement->execute(m_hTable))
                  {
                     Trace::put("Error Inserting into :", m_hTable.getName(), true);
                     Database::instance()->setTransactionState(Database::ROLLBACKREQUIRED);
                     m_hQuery[0].setAbort(true);
                     break;
                  }
               }
               m_hSum.erase(m_hSum.begin(), m_hSum.end());
               if (m_hQuery[0].getAbort())
                  return;
               char szTemp[PERCENTD];
               snprintf(szTemp, PERCENTD, "%d", m_iSYNC_INTERVAL_NO);
               Context hContext(Application::instance()->image(), Application::instance()->name());
               m_strCoversionProgress.assign(szTemp);
               hContext.put("CONVERSION PROGRESS", m_strCoversionProgress.c_str());
               if (Database::instance()->commit() != 0)
               {
                  Trace::put("Error updating CoversionProgress to ", m_strCoversionProgress, true);
                  m_hQuery[0].setAbort(true);
                  return;
               }
               Trace::put("Completed SYNC_INETRVAL_NO :", szTemp, true);
               m_iSYNC_INTERVAL_NO = 0;
            }
         }
      }
   }
   else if (pSubject == &m_hQuery[1])
   {
      char szTemp[64];
      snprintf(szTemp, 50, "%d:%d:%018.0f:%d",m_iSYNC_INTERVAL_NO, m_iTFIN_ENTITY_ID, m_dAMT_RECON_NET, m_iTRAN_COUNT);
      m_hValidate[m_hQuery[1].getIndex()].push_back(szTemp);
   }
   Application::update(pSubject);
  //## end TotalsEngine::update%38CE97BF00C4.body
}

bool TotalsEngine::validate ()
{
  //## begin TotalsEngine::validate%65D0D26F0237.body preserve=yes
   m_hValidate[0].clear();
   m_hValidate[1].clear();
   m_hQuery[1].reset();
   m_hQuery[1].setIndex(0);
   m_hQuery[1].join("T_FIN_PERIOD2", "INNER", "T_FIN_SUM2", "PERIOD_ID", "CU_PERIOD_ID", "=", false);
   m_hQuery[1].join("T_FIN_PERIOD2", "INNER", "T_FIN_SUM2", "PERIOD_ID", "AT_PERIOD_ID", "=", false);
   m_hQuery[1].join("T_FIN_PERIOD2", "INNER", "T_FIN_SUM2", "PERIOD_ID", "AM_PERIOD_ID", "=", false);
   m_hQuery[1].join("T_FIN_PERIOD2", "INNER", "T_FIN_SUM2", "PERIOD_ID", "AI_PERIOD_ID", "=", false);
   m_hQuery[1].join("T_FIN_PERIOD2", "INNER", "T_FIN_SUM2", "PERIOD_ID", "AP_PERIOD_ID", "=", false);
   m_hQuery[1].join("T_FIN_PERIOD2", "INNER", "T_FIN_SUM2", "PERIOD_ID", "II_PERIOD_ID", "=", false);
   m_hQuery[1].join("T_FIN_PERIOD2", "INNER", "T_FIN_SUM2", "PERIOD_ID", "IP_PERIOD_ID", "=", false);
   m_hQuery[1].bind("T_FIN_SUM2", "SYNC_INTERVAL_NO", reusable::Column::LONG, &m_iSYNC_INTERVAL_NO);
   m_hQuery[1].bind("T_FIN_PERIOD2", "T_FIN_ENTITY_ID", reusable::Column::LONG, &m_iTFIN_ENTITY_ID);
   m_hQuery[1].bind("T_FIN_SUM2", "AMT_RECON_NET", reusable::Column::DOUBLE,&m_dAMT_RECON_NET,0,"SUM");
   m_hQuery[1].bind("T_FIN_SUM2", "TRAN_COUNT", reusable::Column::LONG, &m_iTRAN_COUNT, 0, "SUM");
   m_hQuery[1].setGroupByClause("SYNC_INTERVAL_NO,T_FIN_ENTITY_ID");
   m_hQuery[1].setOrderByClause("SYNC_INTERVAL_NO,T_FIN_ENTITY_ID");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(m_hQuery[1]))
      return false;
   m_hQuery[1].reset();
   m_hQuery[1].setIndex(1);
   m_hQuery[1].join("T_FIN_ENTITY_GROUP", "INNER", "T_FIN_E_GROUP_ITEM", "ENTITY_GROUP_ID");
   m_hQuery[1].join("T_FIN_E_GROUP_ITEM", "INNER", "T_FIN_TOTAL", "ENTITY_GROUP_ID");
   m_hQuery[1].join("T_FIN_E_GROUP_ITEM", "INNER","T_FIN_PERIOD", "PERIOD_ID");
   m_hQuery[1].join("T_FIN_E_GROUP_ITEM", "INNER", "T_FIN_TOTAL", "ENTITY_GROUP_ID");
   m_hQuery[1].bind("T_FIN_ENTITY_GROUP", "SYNC_INTERVAL_NO", reusable::Column::LONG, &m_iSYNC_INTERVAL_NO);
   m_hQuery[1].bind("T_FIN_PERIOD", "T_FIN_ENTITY_ID", reusable::Column::LONG, &m_iTFIN_ENTITY_ID);
   m_hQuery[1].bind("T_FIN_TOTAL", "AMT_RECON_NET", reusable::Column::DOUBLE, &m_dAMT_RECON_NET, 0, "SUM");
   m_hQuery[1].bind("T_FIN_TOTAL", "TRAN_COUNT", reusable::Column::LONG, &m_iTRAN_COUNT, 0, "SUM");
   m_hQuery[1].setGroupByClause("SYNC_INTERVAL_NO,T_FIN_ENTITY_ID");
   m_hQuery[1].setOrderByClause("SYNC_INTERVAL_NO,T_FIN_ENTITY_ID");
   if (!pSelectStatement->execute(m_hQuery[1]))
      return false;
   bool bReturn = true;
   if (!std::equal(m_hValidate[0].begin(), m_hValidate[0].end(), m_hValidate[1].begin()))
   {
      bReturn = false;
      for (int i = 0; i < m_hValidate[0].size(); i++)
         if (i <= (m_hValidate[1].size() - 1) && m_hValidate[0][i] != m_hValidate[1][i])
         {
            vector<string> hBuffer;
            Buffer::parse(m_hValidate[0][i], ":", hBuffer);
            Trace::put("Validation failed for SYNC_INETRVAL_NO:T_FIN_ENTITY_ID", hBuffer[0] + ":" + hBuffer[1], true);
            break;
         }
   }
   return bReturn;
  //## end TotalsEngine::validate%65D0D26F0237.body
}

// Additional Declarations
  //## begin TotalsEngine%38CE947F0013.declarations preserve=yes
  //## end TotalsEngine%38CE947F0013.declarations

//## begin module%38CE94C303B4.epilog preserve=yes
//## end module%38CE94C303B4.epilog
