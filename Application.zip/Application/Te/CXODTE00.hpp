//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%38CE94C20037.cm preserve=no
//## end module%38CE94C20037.cm

//## begin module%38CE94C20037.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%38CE94C20037.cp

//## Module: CXOPTE00%38CE94C20037; Package specification
//## Subsystem: TE%38CE945500E5
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\Dn\Server\Application\Te\CXODTE00.hpp

#ifndef CXOPTE00_h
#define CXOPTE00_h 1

//## begin module%38CE94C20037.additionalIncludes preserve=no
//## end module%38CE94C20037.additionalIncludes

//## begin module%38CE94C20037.includes preserve=yes
//## end module%38CE94C20037.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Totals Management::Settlement_CAT%35FFB37A031B
namespace settlement {
class FinancialTransaction;
class CutoffMediator;
class TotalsCategory;
class RulesMediator1;
class Total;
class MISRepair;
class SettlementFileFactory;
class FinancialSettlement;
class Replication;
class TransactionMediator;
class AdminMediator;
class RulesMediator2;
class TransactionTotal;
class TransactionRead;
class DataExport;
class FinancialRupay;
class Reconciliation;
class RepairsMediator2;
class RepairsMediator1;
} // namespace settlement

//## Modelname: Totals Management::TotalsCommand_CAT%3884FA670353
namespace totalscommand {
class DirectRoute;
class Total;
} // namespace totalscommand

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
class Progress;
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class CriticalSection;
class Thread;
} // namespace reusable

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Delegation;
} // namespace process

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class SwitchClock;
class DataControl;
class CRTransactionTypeIndicator;
} // namespace database

namespace IF {
class Extract;
class Timestamp;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class GMTClock;
class MinuteTimer;
} // namespace timer

namespace database {
class DatabaseFactory;
class Database;
class DataModel;
} // namespace database

//## Modelname: Data Distribution::PostingFile_CAT%41E951230177
namespace postingfile {
class PostingFileFactory;
class Reports;

} // namespace postingfile

//## begin module%38CE94C20037.declarations preserve=no
//## end module%38CE94C20037.declarations

//## begin module%38CE94C20037.additionalDeclarations preserve=yes
//## end module%38CE94C20037.additionalDeclarations


//## begin TotalsEngine%38CE947F0013.preface preserve=yes
//## end TotalsEngine%38CE947F0013.preface

//## Class: TotalsEngine%38CE947F0013
//	<body>
//	<title>CG
//	<h1>TE
//	<h2>AB
//	<!-- TotalsEngine : General -->
//	<h3>System Flow
//	<p>
//	The DataNavigator server calculates real-time
//	settlement, MIS and ATM  totals.
//	Totals are calculated after transactions are added to
//	the data repository by the Load Engine services.
//
//	Settlement totals are maintained for the following
//	entities:
//	<ul>
//	<li>Device
//	<li>Reporting Level (e.g. merchant)
//	<li>Acquiring Institution
//	<li>Acquiring Processor (e.g. network, card association,
//	etc)
//	<li>Issuing Institution
//	<li>Issuing Processor (e.g. network, card association,
//	etc)
//	<li>Switch
//	</ul>
//	<p>
//	Transactions are aggregated for MIS totals that are
//	available in system summary reporting.
//	<p>
//	Real-time ATM totals are calculated for devices for use
//	in ATM cash management functions in the DataNavigator
//	client.
//	<p>
//	The Totals Engine service (<i>ca</i>TE) processes
//	transactions on a five-minute delay following loading
//	(or correction by <i>ca</i>PTM).
//	The Totals Engine service (<i>ca</i>TE) produces the
//	following information:
//	<ul>
//	<li>MIS totals used as input to the File Format service
//	(<i>ca</i>DF01)
//	<li>Canister totals used by the Cash Manager service
//	(<i>ca</i>CM)
//	<li>Deposit transactions used for verification by the
//	ATM Manager service (<i>ca</i>AM)
//	<li><a href="Post Transaction.html">Post :
//	Transaction</a>
//	<li><a href="Post Transaction Custom.html">Post :
//	Transaction : Custom</a>
//	<li><a href="Post Suspect Transaction.html">Post :
//	Suspect Transaction</a>
//	<li><a href="Post Monthly Debit Transaction.html">Post :
//	Monthly Debit Transaction</a>
//	<li><a href="Settle Financial Settlement.html">Settle :
//	Financial Settlement</a>
//	</ul>
//	<p>
//	Entity information is supplied by the Entity Interface
//	service (<i>ca</i>CU).
//	Transactions are supplied by the Load Engine services
//	(<i>ca</i>LE<i>nn</i>).
//	Incomplete transactions are corrected by the Problem
//	Transaction Manager service (<i>ca</i>PTM) prior to
//	input to the totals process.
//	</p>
//	</body>
//## Category: Totals Management::TotalsEngine_CAT%38CE942701CF
//## Subsystem: TE%38CE945500E5
//## Persistence: Transient
//## Cardinality/Multiplicity: 0..1



//## Uses: <unnamed>%38CE9740019D;database::Database { -> F}
//## Uses: <unnamed>%38CE97420196;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%38CE9944013B;settlement::CutoffMediator { -> F}
//## Uses: <unnamed>%38CE99920314;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%38CE9D6E02E3;IF::Message { -> F}
//## Uses: <unnamed>%39AFB5A9027A;settlement::AdminMediator { -> F}
//## Uses: <unnamed>%39DF24420119;monitor::UseCase { -> F}
//## Uses: <unnamed>%3A22B05200B8;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%3A23C960038C;entitysegment::Progress { -> F}
//## Uses: <unnamed>%3A376E6C0161;IF::Timestamp { -> F}
//## Uses: <unnamed>%3F68C36001C5;settlement::TransactionMediator { -> F}
//## Uses: <unnamed>%4003F49A0177;settlement::FinancialTransaction { -> F}
//## Uses: <unnamed>%40AA8C2E026B;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%41E920FE0000;timer::GMTClock { -> F}
//## Uses: <unnamed>%41E9272F01E4;entitysegment::Customer { -> F}
//## Uses: <unnamed>%41EFC2AA029F;postingfile::PostingFileFactory { -> F}
//## Uses: <unnamed>%43DE13ED0280;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%4516891F0186;database::SwitchClock { -> F}
//## Uses: <unnamed>%453E60C403B9;settlement::FinancialSettlement { -> F}
//## Uses: <unnamed>%455B6136005D;database::DataControl { -> F}
//## Uses: <unnamed>%45D28DCE02FF;settlement::TotalsCategory { -> F}
//## Uses: <unnamed>%465C39FE00AB;IF::Extract { -> F}
//## Uses: <unnamed>%4E3865AD02A6;settlement::Replication { -> F}
//## Uses: <unnamed>%5437E5A00353;totalscommand::Total { -> F}
//## Uses: <unnamed>%546208460228;database::DataModel { -> F}
//## Uses: <unnamed>%58F781AC0231;settlement::MISRepair { -> F}
//## Uses: <unnamed>%5C113E7300EC;settlement::Total { -> F}
//## Uses: <unnamed>%5C113EA20183;settlement::FinancialRupay { -> F}
//## Uses: <unnamed>%5C113EB402DC;settlement::Reconciliation { -> F}
//## Uses: <unnamed>%5C1144600240;database::CRTransactionTypeIndicator { -> F}
//## Uses: <unnamed>%5C114491001F;reusable::Thread { -> F}
//## Uses: <unnamed>%5C8B03DD026C;settlement::RulesMediator1 { -> F}
//## Uses: <unnamed>%5C8BE96F0132;settlement::RulesMediator2 { -> F}
//## Uses: <unnamed>%5E383BB70352;postingfile::Reports { -> F}
//## Uses: <unnamed>%5ED92DDC0297;totalscommand::DirectRoute { -> F}
//## Uses: <unnamed>%5F4FBDE301B2;settlement::RepairsMediator1 { -> F}
//## Uses: <unnamed>%5F4FBDE60019;settlement::RepairsMediator2 { -> F}
//## Uses: <unnamed>%6081EEE5011E; { -> F}
//## Uses: <unnamed>%6081EEE901D6; { -> F}

class TotalsEngine : public process::Application  //## Inherits: <unnamed>%38CE96FE02C5
{
  //## begin TotalsEngine%38CE947F0013.initialDeclarations preserve=yes
  //## end TotalsEngine%38CE947F0013.initialDeclarations

  public:
    //## Constructors (generated)
      TotalsEngine();

    //## Destructor (generated)
      virtual ~TotalsEngine();


    //## Other Operations (specified)
      //## Operation: convert%65BE7F1001E0
      bool convert ();

      //## Operation: initialize%38CE97B40046
      int initialize ();

      //## Operation: update%38CE97BF00C4
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

      //## Operation: validate%65D0D26F0237
      bool validate ();

    // Additional Public Declarations
      //## begin TotalsEngine%38CE947F0013.public preserve=yes
      //## end TotalsEngine%38CE947F0013.public

  protected:

    //## Other Operations (specified)
      //## Operation: onReset%38CE97B8018C
      //	Syntax:  RESET task EOD CURRENT
      //
      //	Syntax:  RESET task yyyymmdd
      //
      //	This command resets totals back to a point in time.
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>TE
      //	<h2>CD
      //	<h3>Recover Totals
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>TE <i>yyyymmdd</i>
      //	<h4>Description
      //	<p>
      //	The Totals Engine service recalculates all totals from
      //	midnight on the day specified up to the current time.
      //	Files generated by the Totals
      //	Engine service are also re-created based on the newly
      //	calculated totals.
      //	This command should only be used in case of an emergency
      //	(e.g. following a software fix to totals or to recover
      //	from a database issue).
      //	</p>
      //	<h3>Close Business Day
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>TE EOD CURRENT
      //	<h4>Description
      //	<p>
      //	The Totals Engine service forces the customer business
      //	day to close (regardless of where the service is in
      //	regards
      //	to processing financial transactions for business day).
      //	</p>
      //	</body>
      int onReset (Message& hMessage);

      //## Operation: onResume%38CE97BB0244
      int onResume (Message& hMessage);

    // Additional Protected Declarations
      //## begin TotalsEngine%38CE947F0013.protected preserve=yes
      //## end TotalsEngine%38CE947F0013.protected

  private:
    // Additional Private Declarations
      //## begin TotalsEngine%38CE947F0013.private preserve=yes
      //## end TotalsEngine%38CE947F0013.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Reset%5321BA4E02EA
      //## begin TotalsEngine::Reset%5321BA4E02EA.attr preserve=no  private: string {V} 
      string m_strReset;
      //## end TotalsEngine::Reset%5321BA4E02EA.attr

      //## Attribute: WallClock%465C33AB009C
      //## begin TotalsEngine::WallClock%465C33AB009C.attr preserve=no  private: bool {V} false
      bool m_bWallClock;
      //## end TotalsEngine::WallClock%465C33AB009C.attr

    // Data Members for Associations

      //## Association: Totals Management::TotalsEngine_CAT::<unnamed>%455B601C01C5
      //## Role: TotalsEngine::<m_pSettlementFileFactory>%455B601D01A5
      //## begin TotalsEngine::<m_pSettlementFileFactory>%455B601D01A5.role preserve=no  public: settlement::SettlementFileFactory { -> RFHgN}
      settlement::SettlementFileFactory *m_pSettlementFileFactory;
      //## end TotalsEngine::<m_pSettlementFileFactory>%455B601D01A5.role

      //## Association: Totals Management::TotalsEngine_CAT::<unnamed>%58F785CA02C7
      //## Role: TotalsEngine::<m_pMISRepair>%58F785CB00AE
      //## begin TotalsEngine::<m_pMISRepair>%58F785CB00AE.role preserve=no  public: settlement::MISRepair { -> RFHgN}
      settlement::MISRepair *m_pMISRepair;
      //## end TotalsEngine::<m_pMISRepair>%58F785CB00AE.role

      //## Association: Totals Management::TotalsEngine_CAT::<unnamed>%5AD73AC30323
      //## Role: TotalsEngine::<m_pDataExport>%5AD73AC40231
      //## begin TotalsEngine::<m_pDataExport>%5AD73AC40231.role preserve=no  public: settlement::DataExport { -> RFHgN}
      settlement::DataExport *m_pDataExport;
      //## end TotalsEngine::<m_pDataExport>%5AD73AC40231.role

      //## Association: Totals Management::TotalsEngine_CAT::<unnamed>%5ADF53B800DB
      //## Role: TotalsEngine::<m_pTransactionRead>%5ADF53B9000B
      //## begin TotalsEngine::<m_pTransactionRead>%5ADF53B9000B.role preserve=no  public: settlement::TransactionRead { -> RFHgN}
      settlement::TransactionRead *m_pTransactionRead;
      //## end TotalsEngine::<m_pTransactionRead>%5ADF53B9000B.role

      //## Association: Totals Management::TotalsEngine_CAT::<unnamed>%5BFE3C4C031D
      //## Role: TotalsEngine::<m_pTransactionTotal>%5BFE3C4D0351
      //## begin TotalsEngine::<m_pTransactionTotal>%5BFE3C4D0351.role preserve=no  public: settlement::TransactionTotal { -> RFHgN}
      settlement::TransactionTotal *m_pTransactionTotal;
      //## end TotalsEngine::<m_pTransactionTotal>%5BFE3C4D0351.role

      //## Association: Totals Management::TotalsEngine_CAT::<unnamed>%5C0E76300194
      //## Role: TotalsEngine::<m_hDelegation>%5C0E7631016D
      //## begin TotalsEngine::<m_hDelegation>%5C0E7631016D.role preserve=no  public: process::Delegation { -> 0..nRFHgN}
      vector<process::Delegation*> m_hDelegation;
      //## end TotalsEngine::<m_hDelegation>%5C0E7631016D.role

    // Additional Implementation Declarations
      //## begin TotalsEngine%38CE947F0013.implementation preserve=yes
      struct hSum
      {
         int iSYNC_INTERVAL_NO;
         int iCU_PERIOD_ID;
         int iAT_PERIOD_ID;
         int iAM_PERIOD_ID;
         int iAI_PERIOD_ID;
         int iAP_PERIOD_ID;
         int iII_PERIOD_ID;
         int iIP_PERIOD_ID;
         int iCATEGORY_ID;
         int iTRAN_COUNT;
         double dAMT_RECON_NET;
         double dAMT_TRAN;
         double dAMT_CARD_BILL;
         double dAMT_RECON_ISS;
         double dAMT_RECON_ACQ;
         string strTSTAMP_LAST_UPDATE;
      };
      map<int, int, less<int> > m_hPeriod;
      map<string , hSum , less<string> > m_hSum;
      Query m_hQuery[2];
      vector<string> m_hValidate[2];
      int m_iTFIN_ENTITY_ID;
      double m_dAMT_RECON_NET;
      int m_iTRAN_COUNT;
      segment::GenericSegment* m_pGenericSegment;
      int m_iCycle;
      int m_iPERIOD_ID[7];
      Table m_hTable;
      string m_strCoversionProgress;
      int m_iSYNC_INTERVAL_NO;
      bool m_bInitialized;
      //## end TotalsEngine%38CE947F0013.implementation
};

//## begin TotalsEngine%38CE947F0013.postscript preserve=yes
//## end TotalsEngine%38CE947F0013.postscript

//## begin module%38CE94C20037.epilog preserve=yes
//## end module%38CE94C20037.epilog


#endif
