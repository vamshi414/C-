//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%36DF061802B1.cm preserve=no
//    %X% %Q% %Z% %W%
//## end module%36DF061802B1.cm

//## begin module%36DF061802B1.cp preserve=no
//  Copyright (c) 1998 - 2004
//  eFunds Corporation
//## end module%36DF061802B1.cp

//## Module: CXOPDE00%36DF061802B1; Package body
//## Subsystem: DE%3597E8C80019
//  .
//## Source file: C:\Devel\Dn\Server\Application\De\CXOPDE00.cpp

//## begin module%36DF061802B1.additionalIncludes preserve=no
//## end module%36DF061802B1.additionalIncludes

//## begin module%36DF061802B1.includes preserve=yes
// $Date:   Jan 13 2014 09:53:44  $ $Author:   e1014316  $ $Revision:   1.46  $
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif

#include "CXODIF03.hpp"
#include "CXODRU24.hpp"
#include <map>
//## end module%36DF061802B1.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSMN04_h
#include "CXODMN04.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSPC05_h
#include "CXODPC05.hpp"
#endif
#ifndef CXOSDB07_h
#include "CXODDB07.hpp"
#endif
#ifndef CXOPDE00_h
#include "CXODDE00.hpp"
#endif


//## begin module%36DF061802B1.declarations preserve=no
//## end module%36DF061802B1.declarations

//## begin module%36DF061802B1.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new DeleteEngine();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%36DF061802B1.additionalDeclarations


// Class DeleteEngine

DeleteEngine::DeleteEngine()
  //## begin DeleteEngine::DeleteEngine%34C0A3ED00B3_const.hasinit preserve=no
      : m_bInitialize(false),
        m_iPartitionNumber(0),
        m_cType('S'),
        m_pArchivedDate(0),
        m_pPartitionDeallocator(0),
        m_pTransactionRemover(0)
  //## end DeleteEngine::DeleteEngine%34C0A3ED00B3_const.hasinit
  //## begin DeleteEngine::DeleteEngine%34C0A3ED00B3_const.initialization preserve=yes
  //## end DeleteEngine::DeleteEngine%34C0A3ED00B3_const.initialization
{
  //## begin DeleteEngine::DeleteEngine%34C0A3ED00B3_const.body preserve=yes
   memcpy(m_sID,"DE00",4);
  //## end DeleteEngine::DeleteEngine%34C0A3ED00B3_const.body
}


DeleteEngine::~DeleteEngine()
{
  //## begin DeleteEngine::~DeleteEngine%34C0A3ED00B3_dest.body preserve=yes
   delete m_pTransactionRemover;
   delete m_pPartitionDeallocator;
   delete m_pArchivedDate;
  //## end DeleteEngine::~DeleteEngine%34C0A3ED00B3_dest.body
}



//## Other Operations (implementation)
int DeleteEngine::initialize ()
{
  //## begin DeleteEngine::initialize%36DF07B20076.body preserve=yes
   m_bInitialize = true;
   new dnplatform::DNPlatform();
   int i = Application::initialize();
   // DR15: Operator_Starts_DeleteEngine
   UseCase hUseCase("DR","## DR15 START DE");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->attach(this);
   m_pArchivedDate = new GlobalContext("##ARCHIVED");
   m_pPartitionDeallocator = (
      PartitionDeallocator*)DatabaseFactory::instance()->create("PartitionDeallocator");
   m_pPartitionDeallocator->attach(this);
   m_pTransactionRemover = (
      TransactionRemover*)DatabaseFactory::instance()->create("TransactionRemover");
   setTypes();
   newType();
   m_hTimer[0].attach(this);
   m_hTimer[1].attach(this);
   m_hTimer[1].set("02000000");
   Database::instance()->connect();
   return 0;
  //## end DeleteEngine::initialize%36DF07B20076.body
}

void DeleteEngine::newType ()
{
  //## begin DeleteEngine::newType%386EF43B01BD.body preserve=yes
   map<char,string,less<char> >::iterator pDT = m_hDataTypes.begin();
   IString strTableName((*pDT).second.data(),(*pDT).second.length());
   m_pPartitionDeallocator->setTableName(strTableName);
   m_pTransactionRemover->setTableName(strTableName);
   m_cType = (*pDT).first;
   m_pTransactionRemover->setType(m_cType);
   m_iPartitionNumber = 0;
  //## end DeleteEngine::newType%386EF43B01BD.body
}

int DeleteEngine::onResume (Message& hMessage)
{
  //## begin DeleteEngine::onResume%36DF07BB02E6.body preserve=yes
   // DR17: SW_Deletes_Transactions_From_DB
   char* pszMember;
   if (m_cType == 'F')
      pszMember = "## DR17 DELETE FINANCIAL";
   else
   if (m_cType == 'S')
      pszMember = "## DR48 DELETE STATUS";
   else
      pszMember = "## DR50 DELETE ADMIN";
   UseCase hUseCase("DR",pszMember);
   switch (m_pTransactionRemover->remove())
   {
      case 0: // in process
         break;
      case 1: // completed
         m_pPartitionDeallocator->deallocate(m_iPartitionNumber);
         m_iPartitionNumber = 0;
         setQueueWaitOption(true);
         Console::display("ST313");
         update(m_pPartitionDeallocator);
         Database::instance()->commit();
         break;
      case -1: // unexpected database failure
         Console::display("ST115",15);
         m_hTimer[0].set("00150000");
      case -2: // database disconnected
         m_iPartitionNumber = 0;
         setQueueWaitOption(true);
         UseCase::setSuccess(false);
         break;
   }
   return 0;
  //## end DeleteEngine::onResume%36DF07BB02E6.body
}

void DeleteEngine::setTypes ()
{
  //## begin DeleteEngine::setTypes%386EF4140383.body preserve=yes
#ifdef MVS
   string strValue;
   Extract::instance()->getSpec("MODEL",strValue);
   if (strValue != "OPEN")
      m_hDataTypes.insert(map<char,string,less<char> >::value_type('F',"FIN_RECORD"));
#endif     
   m_hDataTypes.insert(map<char,string,less<char> >::value_type('A',"DEV_ADMIN"));
  //## end DeleteEngine::setTypes%386EF4140383.body
}

void DeleteEngine::update (Subject* pSubject)
{
  //## begin DeleteEngine::update%36DF07B70005.body preserve=yes
   Trace::put(__FILE__,__LINE__,"update()",8);
   if (pSubject == &m_hTimer[1])
   {
      m_hDataTypes.erase(m_hDataTypes.begin(),m_hDataTypes.end());
      setTypes();
      newType();
      m_hTimer[1].set("02000000");
   }
   if (pSubject == Database::instance()
      || pSubject == m_pPartitionDeallocator
      || pSubject == &m_hTimer[0]
      || pSubject == &m_hTimer[1])
   {
      m_hTimer[0].cancel();
      m_hTimer[1].cancel();
      if (pSubject == Database::instance())
      {
         if (Database::instance()->state() == Database::DISCONNECTED)
         {
            m_iPartitionNumber = 0;
            setQueueWaitOption(true);
            return;
         }
      }
      if (m_iPartitionNumber != 0)
         return;
      // DR16: SW_Examines_Partitions_In_DB
      Trace::put(__FILE__,__LINE__,&m_cType,1);
      UseCase hUseCase("DR","## DR16 EXAMINE PARTITION");
      int iPartitionCount = 0;
      if (m_pPartitionDeallocator->available(&iPartitionCount))
      {
         if (iPartitionCount > 2)
         {
            m_hDataTypes.erase(m_cType);
            if ((m_bInitialize) && (m_hDataTypes.empty()))
            {
               m_bInitialize = false;
               Console::display("ST313");
            }
            if (m_hDataTypes.empty())
            {
               setTypes();
               newType();
               m_hTimer[1].set("02000000");
            }
            else
            {
               newType();
               m_hTimer[0].set("00000100");
               m_iPartitionNumber = 0;
               Database::instance()->commit();
               setQueueWaitOption(true);
            }
            return;
         }
         IString strTimestampStart;
         IString strTimestampEnd;
         string strTimestampArchived;
         m_pArchivedDate->get(strTimestampArchived,m_cType);
         if ((m_pPartitionDeallocator->oldest(strTimestampStart,strTimestampEnd,&m_iPartitionNumber))
            && ((strTimestampArchived.length() == 0) // true if no VDR
            || (string(strTimestampEnd) < strTimestampArchived)))
         {
            m_pTransactionRemover->setTimeRange(strTimestampStart,strTimestampEnd);
            Database::instance()->commit();
            setQueueWaitOption(false);
            return;
         }
         else
            m_hDataTypes.erase(m_cType);
         if ((m_bInitialize) && (m_hDataTypes.empty()))
         {
            m_bInitialize = false;
            Console::display("ST313");
         }
         if (m_hDataTypes.empty())
         {
            setTypes();
            newType();
         }
         else
         {
            newType();
            m_hTimer[0].set("00000100");
            m_iPartitionNumber = 0;
            Database::instance()->commit();
            setQueueWaitOption(true);
            return;
         }
      }
      m_hTimer[0].set("00300000");
      m_iPartitionNumber = 0;
      Database::instance()->commit();
      setQueueWaitOption(true);
      return;
   }
   Application::update(pSubject);
  //## end DeleteEngine::update%36DF07B70005.body
}

// Additional Declarations
  //## begin DeleteEngine%34C0A3ED00B3.declarations preserve=yes
  //## end DeleteEngine%34C0A3ED00B3.declarations

//## begin module%36DF061802B1.epilog preserve=yes
//## end module%36DF061802B1.epilog
