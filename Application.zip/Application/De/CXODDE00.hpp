//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%36DF061700BB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%36DF061700BB.cm

//## begin module%36DF061700BB.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%36DF061700BB.cp

//## Module: CXOPDE00%36DF061700BB; Package specification
//## Subsystem: DE%3597E8C80019
//	.
//## Source file: C:\Devel\Dn\Server\Application\De\CXODDE00.hpp

#ifndef CXOPDE00_h
#define CXOPDE00_h 1

//## begin module%36DF061700BB.additionalIncludes preserve=no
//## end module%36DF061700BB.additionalIncludes

//## begin module%36DF061700BB.includes preserve=yes
// $Date:   May 19 2004 13:53:44  $ $Author:   D92186  $ $Revision:   1.14  $
//## end module%36DF061700BB.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Console;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
class ConsecutiveCount;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class TransactionRemover;
class GlobalContext;
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: DataNavigator Foundation::Partition_CAT%346B9162029B
namespace partition {
class PartitionDeallocator;

} // namespace partition

//## begin module%36DF061700BB.declarations preserve=no
//## end module%36DF061700BB.declarations

//## begin module%36DF061700BB.additionalDeclarations preserve=yes
//## end module%36DF061700BB.additionalDeclarations


//## begin DeleteEngine%34C0A3ED00B3.preface preserve=yes
//## end DeleteEngine%34C0A3ED00B3.preface

//## Class: DeleteEngine%34C0A3ED00B3
//	<body>
//	<title>CG
//	<h1>DE
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server stores information from each
//	acquiring platform status, administrative and file
//	maintenance transaction into two tables:
//	<ul>
//	<li>Key information into monthly locator tables
//	<li>Detail information into a partitioned (by day) table
//	</ul>
//	<p>
//	Detail information for the status, administrative and
//	file maintenance transactions is kept in the database
//	for a configurable number of days.
//	The detail is deleted as needed to make partitions
//	available for the loading of current data.
//	The Delete Engine service will free a partition whenever
//	less than three are available for loading.
//	The status of partitions is checked automatically at
//	startup and each time the Load Engine service takes a
//	partition at the start of a new calendar day.
//	</p>
//	<img src=CXOCDE00.gif>
//	<h2>FO
//	<h3>Data Repository Tables
//	<p>
//	The Delete Engine service deletes the oldest
//	transactions from the following tables:
//	<ul>
//	<li><i>custqual</i>.DEV_ADMIN
//	<li><i>custqual</i>.FILE_MAINT
//	<li><i>custqual</i>.STAT_REC
//	</ul>
//	<p>
//	When a partition has been deleted, the corresponding
//	entry in the <i>custqual</i>.PARTITION_CONTROL table is
//	updated to indicate that it is available for use by the
//	Load Engine services
//	<h2>MS
//	<h3>Scheduling
//	<p>
//	One consideration with the Delete Engine service is
//	controlling when it is active.
//	The default installation of the Delete Engine has the
//	service started during the DataNavigator server cold
//	start and executing continuously (i.e. 7 * 24) until
//	server shutdown.
//	<p>
//	The amount of time that the Delete Engine actually needs
//	to be active can be monitored by observing the messages
//	on the Operator Console or the counts in the System
//	Health Monitor.
//	If desired, events can be set up in the Event Manager
//	service to limit the Delete Engine processing to a
//	specific (non prime time) window of time each day.
//	The amount of time needed depends on the volume of
//	transactions in the Data Repository.
//	<p>
//	To schedule the Delete Engine service, implement the
//	following changes using the CR Client for the Data
//	Navigator Server:
//	<ol>
//	<li>Change the Delete Engine service startup option to
//	Defer Startup
//	<li>Set up an event to start the Delete Engine using the
//	command START <i>ca</i>DE
//	<li>Set up an event (e.g. an hour after the start event)
//	to terminate the Delete Engine using the command
//	SHUTDOWN <i>ca</i>DE
//	</ol>
//	</body>
//	<body>
//	<title>OG
//	<h1>DE
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server stores information from each
//	acquiring platform status, administrative and file
//	maintenance transaction into two tables:
//	<ul>
//	<li>Key information into monthly locator tables
//	<li>Detail information into a partitioned (by day) table
//	</ul>
//	<p>
//	Detail information for the status, administrative and
//	file maintenance transactions is kept in the database
//	for a configurable number of days.
//	The detail is deleted as needed to make partitions
//	available for the loading of current data.
//	The Delete Engine service will free a partition whenever
//	less than three are available for loading.
//	The status of partitions is checked automatically at
//	startup and each time the Load Engine service takes a
//	partition at the start of a new calendar day.
//	</p>
//	<img src=CXOODE00.gif>
//	</body>
//## Category: DataNavigator Foundation::Application::DeleteEngine_CAT%354B346E0290
//## Subsystem: DE%3597E8C80019
//## Persistence: Transient
//## Cardinality/Multiplicity: 1..1



//## Uses: <unnamed>%36DF081002FC;database::Database { -> F}
//## Uses: <unnamed>%36DF0A6802F5;IF::Extract { -> F}
//## Uses: <unnamed>%36DF0A940294;IF::Console { -> F}
//## Uses: <unnamed>%3714FF7A011B;monitor::ConsecutiveCount { -> F}
//## Uses: <unnamed>%3A0089450003;monitor::UseCase { -> F}
//## Uses: <unnamed>%40AA3F9702AF;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%40AA4ADC0138;database::DatabaseFactory { -> F}

class DeleteEngine : public process::Application  //## Inherits: <unnamed>%34C0A43502BF
{
  //## begin DeleteEngine%34C0A3ED00B3.initialDeclarations preserve=yes
  //## end DeleteEngine%34C0A3ED00B3.initialDeclarations

  public:
    //## Constructors (generated)
      DeleteEngine();

    //## Destructor (generated)
      virtual ~DeleteEngine();


    //## Other Operations (specified)
      //## Operation: initialize%36DF07B20076
      virtual int initialize ();

      //## Operation: update%36DF07B70005
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin DeleteEngine%34C0A3ED00B3.public preserve=yes
      //## end DeleteEngine%34C0A3ED00B3.public

  protected:

    //## Other Operations (specified)
      //## Operation: onResume%36DF07BB02E6
      virtual int onResume (Message& hMessage);

    // Additional Protected Declarations
      //## begin DeleteEngine%34C0A3ED00B3.protected preserve=yes
      //## end DeleteEngine%34C0A3ED00B3.protected

  private:

    //## Other Operations (specified)
      //## Operation: newType%386EF43B01BD
      void newType ();

      //## Operation: setTypes%386EF4140383
      void setTypes ();

    // Additional Private Declarations
      //## begin DeleteEngine%34C0A3ED00B3.private preserve=yes
      //## end DeleteEngine%34C0A3ED00B3.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Initialize%36DF077A033C
      //## begin DeleteEngine::Initialize%36DF077A033C.attr preserve=no  private: bool {V} false
      bool m_bInitialize;
      //## end DeleteEngine::Initialize%36DF077A033C.attr

      //## Attribute: PartitionNumber%34C3B9CF03B0
      //## begin DeleteEngine::PartitionNumber%34C3B9CF03B0.attr preserve=no  private: int {V} 0
      int m_iPartitionNumber;
      //## end DeleteEngine::PartitionNumber%34C3B9CF03B0.attr

      //## Attribute: Type%36DF079402EA
      //## begin DeleteEngine::Type%36DF079402EA.attr preserve=no  private: char {V} 'S'
      char m_cType;
      //## end DeleteEngine::Type%36DF079402EA.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::DeleteEngine_CAT::<unnamed>%36DF07ED0306
      //## Role: DeleteEngine::<m_pArchivedDate>%36DF07EE01F9
      //## begin DeleteEngine::<m_pArchivedDate>%36DF07EE01F9.role preserve=no  public: database::GlobalContext { -> RFHgN}
      database::GlobalContext *m_pArchivedDate;
      //## end DeleteEngine::<m_pArchivedDate>%36DF07EE01F9.role

      //## Association: DataNavigator Foundation::Application::DeleteEngine_CAT::<unnamed>%36DF082B02E7
      //## Role: DeleteEngine::<m_pPartitionDeallocator>%36DF082C00B7
      //## begin DeleteEngine::<m_pPartitionDeallocator>%36DF082C00B7.role preserve=no  public: partition::PartitionDeallocator { -> RFHgN}
      partition::PartitionDeallocator *m_pPartitionDeallocator;
      //## end DeleteEngine::<m_pPartitionDeallocator>%36DF082C00B7.role

      //## Association: DataNavigator Foundation::Application::DeleteEngine_CAT::<unnamed>%36DF084D0029
      //## Role: DeleteEngine::<m_hTimer>%36DF084D01C3
      //## begin DeleteEngine::<m_hTimer>%36DF084D01C3.role preserve=no  public: timer::Timer {1 -> 2VHgN}
      timer::Timer m_hTimer[2];
      //## end DeleteEngine::<m_hTimer>%36DF084D01C3.role

      //## Association: DataNavigator Foundation::Application::DeleteEngine_CAT::<unnamed>%36DF08620033
      //## Role: DeleteEngine::<m_pTransactionRemover>%36DF086202C8
      //## begin DeleteEngine::<m_pTransactionRemover>%36DF086202C8.role preserve=no  public: database::TransactionRemover { -> RFHgN}
      database::TransactionRemover *m_pTransactionRemover;
      //## end DeleteEngine::<m_pTransactionRemover>%36DF086202C8.role

    // Additional Implementation Declarations
      //## begin DeleteEngine%34C0A3ED00B3.implementation preserve=yes
       map<char,string,less<char> > m_hDataTypes;
      //## end DeleteEngine%34C0A3ED00B3.implementation
};

//## begin DeleteEngine%34C0A3ED00B3.postscript preserve=yes
//## end DeleteEngine%34C0A3ED00B3.postscript

//## begin module%36DF061700BB.epilog preserve=yes
//## end module%36DF061700BB.epilog


#endif
