//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%49C296E20177.cm preserve=no
//	$Date:   May 13 2020 14:57:24  $ $Author:   e1009510  $
//	$Revision:   1.13  $
//## end module%49C296E20177.cm

//## begin module%49C296E20177.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%49C296E20177.cp

//## Module: CXOPRT00%49C296E20177; Package body
//## Subsystem: RT%49C296C1008C
//## Source file: C:\Devel\Dn\Server\Application\Rt\CXOPRT00.cpp

//## begin module%49C296E20177.additionalIncludes preserve=no
//## end module%49C296E20177.additionalIncludes

//## begin module%49C296E20177.includes preserve=yes
#include <memory>
#include "CXODRA01.hpp"
#include "CXODRA08.hpp"
#include "CXODRA09.hpp"
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif

#ifndef _UNIX
#include "CXODMQ04.hpp"
#endif
//## end module%49C296E20177.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
#ifndef CXOSIF46_h
#include "CXODIF46.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF47_h
#include "CXODIF47.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF55_h
#include "CXODIF55.hpp"
#endif
#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
#ifndef CXOPRT00_h
#include "CXODRT00.hpp"
#endif


//## begin module%49C296E20177.declarations preserve=no
//## end module%49C296E20177.declarations

//## begin module%49C296E20177.additionalDeclarations preserve=yes
 #include "CXODPS06.hpp"
   pApplication = new RegionsSimulator();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%49C296E20177.additionalDeclarations


// Class RegionsSimulator 

RegionsSimulator::RegionsSimulator()
  //## begin RegionsSimulator::RegionsSimulator%49C296930271_const.hasinit preserve=no
  //## end RegionsSimulator::RegionsSimulator%49C296930271_const.hasinit
  //## begin RegionsSimulator::RegionsSimulator%49C296930271_const.initialization preserve=yes
  //## end RegionsSimulator::RegionsSimulator%49C296930271_const.initialization
{
  //## begin RegionsSimulator::RegionsSimulator%49C296930271_const.body preserve=yes
   memcpy(m_sID,"RT00",4);
   m_pIDMQueue = 0;
   m_pCMIQueue = 0;
   m_pIDMSignal = 0;
   m_pCMISignal = 0;
   m_strResponseStatus = "SUCCESS";
  //## end RegionsSimulator::RegionsSimulator%49C296930271_const.body
}


RegionsSimulator::~RegionsSimulator()
{
  //## begin RegionsSimulator::~RegionsSimulator%49C296930271_dest.body preserve=yes
   Application::instance()->enable(m_pCMISignal,false);
   Application::instance()->enable(m_pIDMSignal,false);
   QueueManager::instance(m_pIDMQueue->getQueueManager())->detach(this);
   delete m_pCMIQueue;
   delete m_pCMISignal;
   delete m_pIDMQueue;
   delete m_pIDMSignal;
  //## end RegionsSimulator::~RegionsSimulator%49C296930271_dest.body
}



//## Other Operations (implementation)
void RegionsSimulator::formatCMIReply (IF::Message& hMessage, IF::Message& hReply)
{
  //## begin RegionsSimulator::formatCMIReply%49ECB8F10157.body preserve=yes
   hCMST* pCMST = (hCMST*)hMessage.data();

   if (m_strResponseStatus.find("NOREPLY") == string::npos)
   {
      //this is the first message that is being sent
      if(memcmp(pCMST->sProcessCode,"IQRC",4) == 0)
      {
         hIQRC* pIQRC = (hIQRC*)hReply.buffer();
         memset(pIQRC,' ',sizeof(struct hIQRC));
         memcpy(pIQRC->sProcessCode,pCMST->sProcessCode,4);
         memcpy(pIQRC->sOrigSearchName, pCMST->sOrigSearchName,40);
         memcpy(pIQRC->sMatchCode, "MM",2);
         memcpy(pIQRC->sAcctNumber, pCMST->sAccountNo,18);
         memcpy(pIQRC->sApplCode, pCMST->sApplCode,2);
         memcpy(pIQRC->sBankNumber, pCMST->sBankNo,3);
         pIQRC->cMoreCustomersAvail = 'N';

         if (m_strResponseStatus.find("SUCCESS") != string::npos)
         {
            pIQRC->cAccRejCode = 'A';
            int n = 5;
            char szTemp[3]="  ";
            snprintf(szTemp,sizeof(szTemp),"%02d",n);
            memcpy(pIQRC->sNumberSent,szTemp,2);
            for (int i = 0; i < n; i++)
            {
               string strTemp = "FirstName, LastName";
               memcpy(pIQRC->sCustomerName[i],strTemp.data(),strTemp.length());
               strTemp = "TIE";
               memcpy(pIQRC->sTieBreaker[i],strTemp.data(),strTemp.length());
               strTemp = "Some address here";
               memcpy(pIQRC->sAddressLine1[i],strTemp.data(),strTemp.length());
               strTemp = "CITY";
               memcpy(pIQRC->sCity[i],strTemp.data(),strTemp.length());
               strTemp = "WI";
               memcpy(pIQRC->sState[i],strTemp.data(),strTemp.length());
               strTemp = "55555-5555";
               memcpy(pIQRC->sZip[i],strTemp.data(),strTemp.length());
               strTemp = "123456789";
               memcpy(pIQRC->sTinNumber[i],strTemp.data(),strTemp.length());
               strTemp = "SEC";
               memcpy(pIQRC->sRelationship[i],strTemp.data(),strTemp.length());
               if (i%2 == 0)
                  pIQRC->cPerBusCode[i] = 'P';
               else
                  pIQRC->cPerBusCode[i] = 'B';
               strTemp = "20090420";
               memcpy(pIQRC->sDateOfBirth[i],strTemp.data(),strTemp.length());
            }
         }
         else
         {
            pIQRC->cAccRejCode = 'R';
            memcpy(pIQRC->sNumberSent,"00",2);
         }
         hReply.setMessageLength(sizeof(struct hIQRC));
      }
      //this is the second message that is being sent
      else if(memcmp(pCMST->sProcessCode,"IQCP",4) == 0)
      {
         hIQCP* pIQCP = (hIQCP*)hReply.buffer();
         memset(pIQCP,' ',sizeof(struct hIQCP));

         memcpy(pIQCP->sProcessCode,pCMST->sProcessCode,6);
         pIQCP->cPerBusInd = 'Z';
         memcpy(pIQCP->sCustomerName,pCMST->sCustomerName,40);
         memcpy(pIQCP->sTieBreaker,pCMST->sTieBreaker,3);


         if (m_strResponseStatus.find("SUCCESS") != string::npos)
         {
            pIQCP->cAccRejCode = 'A';
            string strTemp = "FirstName";
            memcpy(pIQCP->sFirstName,strTemp.data(),strTemp.length());
            strTemp = "LastName";
            memcpy(pIQCP->sLastName,strTemp.data(),strTemp.length());
            pIQCP->cSexCode = 'M';
            strTemp = "somebody@somehost.com";
            memcpy(pIQCP->sEmailAddress1,strTemp.data(),strTemp.length());
            strTemp = "Street Address";
            memcpy(pIQCP->sStreetLine1,strTemp.data(),strTemp.length());
            strTemp = "CityA";
            memcpy(pIQCP->sCity,strTemp.data(),strTemp.length());
            strTemp = "WI";
            memcpy(pIQCP->sState,strTemp.data(),strTemp.length());
            strTemp = "55555";
            memcpy(pIQCP->sZip,strTemp.data(),strTemp.length());
            strTemp = "IQCP reply sent by RT";
            memcpy(pIQCP->sComment1,strTemp.data(),strTemp.length());
            strTemp = "(555)555-5555";
            memcpy(pIQCP->sHomePrimPhone,strTemp.data(),strTemp.length());
         }
         hReply.setMessageLength(sizeof(struct hIQRC));
      }
   }
  //## end RegionsSimulator::formatCMIReply%49ECB8F10157.body
}

void RegionsSimulator::formatProvisionalCreditReply (IF::Message& hMessage, IF::Message& hReply)
{
  //## begin RegionsSimulator::formatProvisionalCreditReply%49ECAFB30399.body preserve=yes
   hBPI* pBPI = (hBPI*)hMessage.data();
   if (m_strResponseStatus.find("NOREPLY") == string::npos)
   {
      hBPO* pBPO = (hBPO*)hReply.buffer();
      memset(pBPO,' ',sizeof(struct hBPO));
      pBPO->cOutputCntlId = '>';
      memcpy(pBPO->sTranSeqNo,pBPI->sTranSeqNo,6);
      memcpy(pBPO->sMsgSeqNo,pBPI->sMsgSeqNo,3);
      memcpy(pBPO->sBankNo,pBPI->sBankNo,3);
      memcpy(pBPO->sAccountNo,pBPI->sAccountNo,10);
      memcpy(pBPO->sProcessCd,pBPI->sProcessCd,6);
      memcpy(pBPO->sFiller,pBPI->sFiller,10);
      memcpy(pBPO->sHoldADExpirDt,pBPI->sHoldExpDt,8);
      memset(pBPO->sHoldADAcctTitle,' ',40);
      memcpy(pBPO->sHoldADAvail,pBPI->sHoldAmt,14);

      if (m_strResponseStatus.find("SUCCESS") != string::npos)
      {
         pBPO->cTranStatus = 'A';
         pBPO->cAcceptReject = ' ';
      }
      else if (m_strResponseStatus.find("REJECT") != string::npos)
      {
         pBPO->cTranStatus = 'R';
         memcpy(pBPO->sRejectReason,"AMSBSCCA",8);
         pBPO->cAcceptReject = 'R';
      }
      hReply.setMessageLength(sizeof(struct hBPO));
   }
  //## end RegionsSimulator::formatProvisionalCreditReply%49ECAFB30399.body
}

int RegionsSimulator::initialize ()
{
  //## begin RegionsSimulator::initialize%49C3A84103C8.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("CLIENT","## CL46 START RT");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->attach(this);
   Database::instance()->connect();

   string strCMIQueue;
   string strIDMQueue;
   Extract::instance()->getSpec("CMIQUEUE",strCMIQueue);
   Extract::instance()->getSpec("IDMQUEUE",strIDMQueue);
   if ( (strCMIQueue.find("@") != string::npos) || (strIDMQueue.find("@") != string::npos) )
   {
#ifndef _UNIX
      new MqQueueFactory();
#endif
      if(strCMIQueue.length() > 0)
      {
         //set up for the CMI interface
         m_pCMISignal = new Signal("CMI");
         m_pCMIQueue = (ExternalQueue*)ExternalQueueFactory::instance()->create("Queue","CMIQUEUE");
         m_pCMIQueue->setSignal(m_pCMISignal);
         m_pCMISignal->attach(m_pCMIQueue);
         Application::instance()->enable(m_pCMISignal);
      }

      if(strIDMQueue.length() > 0)
      {
         //set up for the IDM Provisional Credit interface
         m_pIDMSignal = new Signal("IDM");
         m_pIDMQueue = (ExternalQueue*)ExternalQueueFactory::instance()->create("Queue","IDMQUEUE");
         m_pIDMQueue->setSignal(m_pIDMSignal);
         m_pIDMSignal->attach(m_pIDMQueue);
         Application::instance()->enable(m_pIDMSignal);
      }

      //!!NOTE: Currently there is an assumption being made that the IDM and CMI queues are on the same queue manager
      QueueManager::instance(m_pCMIQueue->getQueueManager())->attach(this);
   }
   setQueueWaitOption(false);
   return 0;
  //## end RegionsSimulator::initialize%49C3A84103C8.body
}

int RegionsSimulator::onMessage (IF::Message& hMessage)
{
  //## begin RegionsSimulator::onMessage%49C3A855034B.body preserve=yes
   hBPI* pBPI = (hBPI*)hMessage.data();
   Trace::put(pBPI->sTranId,4);
   Message hReply;
   if (memcmp(pBPI->sTranId,"BPRM",4) == 0)
   {
      formatProvisionalCreditReply(hMessage,hReply);
   }
   else if (memcmp(pBPI->sTranId,"BPMS",4) == 0)
   {
      formatCMIReply(hMessage,hReply);
   }
   //send a reply back
   if (m_strResponseStatus.find("NOREPLY") == string::npos)
   {
      hReply.setSource(hMessage.getSource());
      auto_ptr<ExternalQueue> pQueue((ExternalQueue*)ExternalQueueFactory::instance()->create("Queue",hMessage.getSource().c_str()));
      pQueue->open();
      if (!pQueue->send(&hReply,Queue::REPLY))
         return 1;
      if (!(QueueManager::instance(m_pIDMQueue->getQueueManager())->commit()))
         return 1;
   }
   return 0;
  //## end RegionsSimulator::onMessage%49C3A855034B.body
}

int RegionsSimulator::onReset (IF::Message& hMessage)
{
  //## begin RegionsSimulator::onReset%49C3A8720109.body preserve=yes
   m_strResponseStatus = hMessage.context();
   size_t n = m_strResponseStatus.find_last_not_of(' ');
   if (n!= string::npos)
      m_strResponseStatus.erase(n+1);

   Trace::put(m_strResponseStatus.c_str());
   return 0;
  //## end RegionsSimulator::onReset%49C3A8720109.body
}

int RegionsSimulator::onResume (IF::Message& hMessage)
{
  //## begin RegionsSimulator::onResume%49F99385031C.body preserve=yes
   if (m_pCMIQueue)
      m_pCMIQueue->open();
   if (m_pIDMQueue)
      m_pIDMQueue->open();
   setQueueWaitOption(true);
   return true;
  //## end RegionsSimulator::onResume%49F99385031C.body
}

// Additional Declarations
  //## begin RegionsSimulator%49C296930271.declarations preserve=yes
  //## end RegionsSimulator%49C296930271.declarations

//## begin module%49C296E20177.epilog preserve=yes
//## end module%49C296E20177.epilog
