//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%49C296E00261.cm preserve=no
//	$Date:   Sep 22 2009 11:56:22  $ $Author:   E1024360  $
//	$Revision:   1.6  $
//## end module%49C296E00261.cm

//## begin module%49C296E00261.cp preserve=no
//	Copyright (c) 1998 - 2009
//	Fidelity National Information Services
//## end module%49C296E00261.cp

//## Module: CXOPRT00%49C296E00261; Package specification
//## Subsystem: RT%49C296C1008C
//## Source file: C:\Devel\Dn\Server\Application\Rt\CXODRT00.hpp

#ifndef CXOPRT00_h
#define CXOPRT00_h 1

//## begin module%49C296E00261.additionalIncludes preserve=no
//## end module%49C296E00261.additionalIncludes

//## begin module%49C296E00261.includes preserve=yes
//## end module%49C296E00261.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Signal;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Trace;
class Memory;
class ExternalQueueFactory;
class QueueManager;
class Extract;
class ExternalQueue;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%49C296E00261.declarations preserve=no
//## end module%49C296E00261.declarations

//## begin module%49C296E00261.additionalDeclarations preserve=yes
//## end module%49C296E00261.additionalDeclarations


//## begin RegionsSimulator%49C296930271.preface preserve=yes
//## end RegionsSimulator%49C296930271.preface

//## Class: RegionsSimulator%49C296930271
//## Category: Platform \: Regions::RegionsSimulator_CAT%49C2963F003E
//## Subsystem: RT%49C296C1008C
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%49C3E37100DA;IF::Message { -> F}
//## Uses: <unnamed>%49C3E43A01F4;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%49C3E51701D4;IF::Memory { -> F}
//## Uses: <unnamed>%49C3E6FC0232;IF::QueueManager { -> F}
//## Uses: <unnamed>%49C3E7E2036B;IF::Extract { -> F}
//## Uses: <unnamed>%49C3E8A102BF;IF::ExternalQueueFactory { -> F}
//## Uses: <unnamed>%49CCEA1502BF;database::Database { -> F}
//## Uses: <unnamed>%49D754A6008C;monitor::UseCase { -> F}
//## Uses: <unnamed>%49F0901E01B5;IF::Trace { -> F}

class DllExport RegionsSimulator : public process::Application  //## Inherits: <unnamed>%49C297A60186
{
  //## begin RegionsSimulator%49C296930271.initialDeclarations preserve=yes
  //## end RegionsSimulator%49C296930271.initialDeclarations

  public:
    //## Constructors (generated)
      RegionsSimulator();

    //## Destructor (generated)
      virtual ~RegionsSimulator();


    //## Other Operations (specified)
      //## Operation: initialize%49C3A84103C8
      virtual int initialize ();

    // Additional Public Declarations
      //## begin RegionsSimulator%49C296930271.public preserve=yes
      //## end RegionsSimulator%49C296930271.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%49C3A855034B
      virtual int onMessage (IF::Message& hMessage);

      //## Operation: onReset%49C3A8720109
      virtual int onReset (IF::Message& hMessage);

      //## Operation: onResume%49F99385031C
      virtual int onResume (IF::Message& hMessage);

    // Additional Protected Declarations
      //## begin RegionsSimulator%49C296930271.protected preserve=yes
      //## end RegionsSimulator%49C296930271.protected

  private:

    //## Other Operations (specified)
      //## Operation: formatCMIReply%49ECB8F10157
      void formatCMIReply (IF::Message& hMessage, IF::Message& hReply);

      //## Operation: formatProvisionalCreditReply%49ECAFB30399
      void formatProvisionalCreditReply (IF::Message& hMessage, IF::Message& hReply);

    // Additional Private Declarations
      //## begin RegionsSimulator%49C296930271.private preserve=yes
      //## end RegionsSimulator%49C296930271.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ResponseStatus%49DA5F580203
      //## begin RegionsSimulator::ResponseStatus%49DA5F580203.attr preserve=no  private: string {U} 
      string m_strResponseStatus;
      //## end RegionsSimulator::ResponseStatus%49DA5F580203.attr

    // Data Members for Associations

      //## Association: Platform \: Regions::RegionsSimulator_CAT::<unnamed>%4A006B5E0251
      //## Role: RegionsSimulator::<m_pIDMQueue>%4A006B5F01B5
      //## begin RegionsSimulator::<m_pIDMQueue>%4A006B5F01B5.role preserve=no  public: IF::ExternalQueue { -> RFHgN}
      IF::ExternalQueue *m_pIDMQueue;
      //## end RegionsSimulator::<m_pIDMQueue>%4A006B5F01B5.role

      //## Association: Platform \: Regions::RegionsSimulator_CAT::<unnamed>%4A006C3A0222
      //## Role: RegionsSimulator::<m_pCMIQueue>%4A006C3B032C
      //## begin RegionsSimulator::<m_pCMIQueue>%4A006C3B032C.role preserve=no  public: IF::ExternalQueue { -> RFHgN}
      IF::ExternalQueue *m_pCMIQueue;
      //## end RegionsSimulator::<m_pCMIQueue>%4A006C3B032C.role

      //## Association: Platform \: Regions::RegionsSimulator_CAT::<unnamed>%4A006D2400DA
      //## Role: RegionsSimulator::<m_pIDMSignal>%4A006D2403B9
      //## begin RegionsSimulator::<m_pIDMSignal>%4A006D2403B9.role preserve=no  public: reusable::Signal { -> RFHgN}
      reusable::Signal *m_pIDMSignal;
      //## end RegionsSimulator::<m_pIDMSignal>%4A006D2403B9.role

      //## Association: Platform \: Regions::RegionsSimulator_CAT::<unnamed>%4A006D3A0196
      //## Role: RegionsSimulator::<m_pCMISignal>%4A006D3B00FA
      //## begin RegionsSimulator::<m_pCMISignal>%4A006D3B00FA.role preserve=no  public: reusable::Signal { -> RFHgN}
      reusable::Signal *m_pCMISignal;
      //## end RegionsSimulator::<m_pCMISignal>%4A006D3B00FA.role

    // Additional Implementation Declarations
      //## begin RegionsSimulator%49C296930271.implementation preserve=yes
      //## end RegionsSimulator%49C296930271.implementation

};

//## begin RegionsSimulator%49C296930271.postscript preserve=yes
//## end RegionsSimulator%49C296930271.postscript

//## begin module%49C296E00261.epilog preserve=yes
//## end module%49C296E00261.epilog


#endif
