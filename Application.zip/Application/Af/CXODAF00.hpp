//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39297A9A027A.cm preserve=no
//	$Date:   Apr 24 2019 09:18:36  $ $Author:   e1009839  $
//	$Revision:   1.19  $
//## end module%39297A9A027A.cm

//## begin module%39297A9A027A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39297A9A027A.cp

//## Module: CXOPAF00%39297A9A027A; Package specification
//## Subsystem: AF%39297A540052
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Af\CXODAF00.hpp

#ifndef CXOPAF00_h
#define CXOPAF00_h 1

//## begin module%39297A9A027A.additionalIncludes preserve=no
//## end module%39297A9A027A.additionalIncludes

//## begin module%39297A9A027A.includes preserve=yes
//## end module%39297A9A027A.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Totals Management::TotalsCommand_CAT%3884FA670353
namespace totalscommand {
class FinancialSettlementFile2;
class FinancialSettlementFile1;
} // namespace totalscommand

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;

} // namespace database

//## begin module%39297A9A027A.declarations preserve=no
//## end module%39297A9A027A.declarations

//## begin module%39297A9A027A.additionalDeclarations preserve=yes
//## end module%39297A9A027A.additionalDeclarations


//## begin AutomatedFundsMovement%39296B8E0230.preface preserve=yes
//## end AutomatedFundsMovement%39296B8E0230.preface

//## Class: AutomatedFundsMovement%39296B8E0230
//	<body>
//	<title>CG
//	<h1>AF
//	<h2>AB
//	<!-- AutomatedFundsMovement : General-->
//	<a href="DataNavigator Settlement.html">DataNavigator
//	Settlement</a> calculates and determines the net
//	financial position of each endpoint for all transactions
//	that are cleared.
//	The Automated Funds Movement service produces the files
//	(e.g. NACHA format) that can be forwarded to an
//	institution (e.g. a Federal Reserve Bank) for settlement.
//	<h3>System Flow
//	<p>
//	The Automated Funds Movement service produces the
//	following result sets:
//	<ul>
//	<li>Financial Settlement (Funds Movement Cover Letter)
//	<li>Financial Settlement (Funds Movement)
//	<li>Financial Settlement (Delta Funds Movement Cover
//	Letter)
//	<li>Financial Settlement (Delta Funds Movement)
//	</ul>
//	<p>
//	At the end of (and optionally during) the business day,
//	the <a href="Totals Engine.html">Totals Engine</a>
//	service (<i>ca</i>TE) generates the raw settlement
//	totals (result sets FINSA0 and FINSD0) in the data
//	export tables.
//	The FINSA0 result set contains accumulative totals since
//	the beginning of the business day.
//	When funds movement is done multiple times per day, the
//	FINSD0 result set contains the difference between FINSA0
//	result sets.
//	The Automated Funds Movement service (<i>ca</i>AF)
//	converts the raw settlement totals into a format (e.g.
//	NACHA) suitable for settlement.
//	These results sets (FINLA0, FINFA0, FINLD0 and FINFD0)
//	are customizable through the use of a template.
//	These result sets are then copied to the file system by
//	the <a href="File Distributor.html">File Distributor</a>
//	service (<i>ca</i>DT01).
//	</p>
//	<img src=CXOCAF00.gif>
//	</body>
//## Category: Totals Management::AutomatedFundsMovement_CAT%3929699700F2
//## Subsystem: AF%39297A540052
//## Persistence: Transient
//## Cardinality/Multiplicity: 0..1



//## Uses: <unnamed>%39296E8201C9;IF::QueueFactory { -> F}
//## Uses: <unnamed>%39296EFB0082;database::Database { -> F}
//## Uses: <unnamed>%392C2E9E03B7;ACHFundsMovement { -> F}
//## Uses: <unnamed>%392D30D60066;reusable::Query { -> F}
//## Uses: <unnamed>%3D9DDDC4005D;entitysegment::Customer { -> F}
//## Uses: <unnamed>%40A3E5E501B5;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%40A3E5E90196;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%45B093A50159;monitor::UseCase { -> F}
//## Uses: <unnamed>%45B093A90330;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%45C29FCC00A1;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%45C29FFB0305;timer::Clock { -> F}
//## Uses: <unnamed>%5C1A45180150;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%5C1A4539011E;IF::Message { -> F}
//## Uses: <unnamed>%5CC06E650222;totalscommand::FinancialSettlementFile1 { -> F}
//## Uses: <unnamed>%5CC06E690129;totalscommand::FinancialSettlementFile2 { -> F}

class AutomatedFundsMovement : public process::Application  //## Inherits: <unnamed>%39296BF201D0
{
  //## begin AutomatedFundsMovement%39296B8E0230.initialDeclarations preserve=yes
  //## end AutomatedFundsMovement%39296B8E0230.initialDeclarations

  public:
    //## Constructors (generated)
      AutomatedFundsMovement();

    //## Destructor (generated)
      virtual ~AutomatedFundsMovement();


    //## Other Operations (specified)
      //## Operation: getNextFile%45C6C08E0051
      bool getNextFile (database::ExportFile& pExportFile, reusable::string strFileType);

      //## Operation: initialize%39296C960316
      virtual int initialize ();

      //## Operation: update%392C1EB7007E
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin AutomatedFundsMovement%39296B8E0230.public preserve=yes
      //## end AutomatedFundsMovement%39296B8E0230.public

  protected:
    // Additional Protected Declarations
      //## begin AutomatedFundsMovement%39296B8E0230.protected preserve=yes
      //## end AutomatedFundsMovement%39296B8E0230.protected

  private:

    //## Other Operations (specified)
      //## Operation: process%45B0919001E7
      void process ();

    // Additional Private Declarations
      //## begin AutomatedFundsMovement%39296B8E0230.private preserve=yes
      //## end AutomatedFundsMovement%39296B8E0230.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin AutomatedFundsMovement%39296B8E0230.implementation preserve=yes
   //FinancialSettlementFile hFinancialSettlementFile;
      //## end AutomatedFundsMovement%39296B8E0230.implementation
};

//## begin AutomatedFundsMovement%39296B8E0230.postscript preserve=yes
//## end AutomatedFundsMovement%39296B8E0230.postscript

//## begin module%39297A9A027A.epilog preserve=yes
//## end module%39297A9A027A.epilog


#endif
