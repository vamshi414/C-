//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4452014B0111.cm preserve=no
//	$Date:   Sep 17 2019 15:51:08  $ $Author:   e1009610  $
//	$Revision:   1.7  $
//## end module%4452014B0111.cm

//## begin module%4452014B0111.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4452014B0111.cp

//## Module: CXOSAF05%4452014B0111; Package specification
//## Subsystem: AF%39297A540052
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Af\CXODAF05.hpp

#ifndef CXOSAF05_h
#define CXOSAF05_h 1

//## begin module%4452014B0111.additionalIncludes preserve=no
//## end module%4452014B0111.additionalIncludes

//## begin module%4452014B0111.includes preserve=yes
//## end module%4452014B0111.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
//## begin module%4452014B0111.declarations preserve=no
//## end module%4452014B0111.declarations

//## begin module%4452014B0111.additionalDeclarations preserve=yes
//## end module%4452014B0111.additionalDeclarations


//## begin ACHExportSegment%4451EA8E010F.preface preserve=yes
//## end ACHExportSegment%4451EA8E010F.preface

//## Class: ACHExportSegment%4451EA8E010F
//## Category: Totals Management::AutomatedFundsMovement_CAT%3929699700F2
//## Subsystem: AF%39297A540052
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport ACHExportSegment : public segment::Segment  //## Inherits: <unnamed>%4451EB0F03E0
{
  //## begin ACHExportSegment%4451EA8E010F.initialDeclarations preserve=yes
  //## end ACHExportSegment%4451EA8E010F.initialDeclarations

  public:
    //## Constructors (generated)
      ACHExportSegment();

    //## Destructor (generated)
      virtual ~ACHExportSegment();


    //## Other Operations (specified)
      //## Operation: fields%44521F41009F
      virtual struct  Fields* fields () const;

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ACH_DEST_ID%46A7A84E033C
      const string& getACH_DEST_ID () const
      {
        //## begin ACHExportSegment::getACH_DEST_ID%46A7A84E033C.get preserve=no
        return m_strACH_DEST_ID;
        //## end ACHExportSegment::getACH_DEST_ID%46A7A84E033C.get
      }

      void setACH_DEST_ID (const string& value)
      {
        //## begin ACHExportSegment::setACH_DEST_ID%46A7A84E033C.set preserve=no
        m_strACH_DEST_ID = value;
        //## end ACHExportSegment::setACH_DEST_ID%46A7A84E033C.set
      }


      //## Attribute: ACH_DEST_INST_ID%4451FF0A025E
      const string& getACH_DEST_INST_ID () const
      {
        //## begin ACHExportSegment::getACH_DEST_INST_ID%4451FF0A025E.get preserve=no
        return m_strACH_DEST_INST_ID;
        //## end ACHExportSegment::getACH_DEST_INST_ID%4451FF0A025E.get
      }

      void setACH_DEST_INST_ID (const string& value)
      {
        //## begin ACHExportSegment::setACH_DEST_INST_ID%4451FF0A025E.set preserve=no
        m_strACH_DEST_INST_ID = value;
        //## end ACHExportSegment::setACH_DEST_INST_ID%4451FF0A025E.set
      }


      //## Attribute: ACH_DEST_NAME%445202AB0202
      const string& getACH_DEST_NAME () const
      {
        //## begin ACHExportSegment::getACH_DEST_NAME%445202AB0202.get preserve=no
        return m_strACH_DEST_NAME;
        //## end ACHExportSegment::getACH_DEST_NAME%445202AB0202.get
      }

      void setACH_DEST_NAME (const string& value)
      {
        //## begin ACHExportSegment::setACH_DEST_NAME%445202AB0202.set preserve=no
        m_strACH_DEST_NAME = value;
        //## end ACHExportSegment::setACH_DEST_NAME%445202AB0202.set
      }


      //## Attribute: ACH_ORIG_ID%46A7A85E000F
      const string& getACH_ORIG_ID () const
      {
        //## begin ACHExportSegment::getACH_ORIG_ID%46A7A85E000F.get preserve=no
        return m_strACH_ORIG_ID;
        //## end ACHExportSegment::getACH_ORIG_ID%46A7A85E000F.get
      }

      void setACH_ORIG_ID (const string& value)
      {
        //## begin ACHExportSegment::setACH_ORIG_ID%46A7A85E000F.set preserve=no
        m_strACH_ORIG_ID = value;
        //## end ACHExportSegment::setACH_ORIG_ID%46A7A85E000F.set
      }


      //## Attribute: ACH_ORIG_INST_ID%4452024D0329
      const string& getACH_ORIG_INST_ID () const
      {
        //## begin ACHExportSegment::getACH_ORIG_INST_ID%4452024D0329.get preserve=no
        return m_strACH_ORIG_INST_ID;
        //## end ACHExportSegment::getACH_ORIG_INST_ID%4452024D0329.get
      }

      void setACH_ORIG_INST_ID (const string& value)
      {
        //## begin ACHExportSegment::setACH_ORIG_INST_ID%4452024D0329.set preserve=no
        m_strACH_ORIG_INST_ID = value;
        //## end ACHExportSegment::setACH_ORIG_INST_ID%4452024D0329.set
      }


      //## Attribute: ACH_ORIG_NAME%445205AE0228
      const string& getACH_ORIG_NAME () const
      {
        //## begin ACHExportSegment::getACH_ORIG_NAME%445205AE0228.get preserve=no
        return m_strACH_ORIG_NAME;
        //## end ACHExportSegment::getACH_ORIG_NAME%445205AE0228.get
      }

      void setACH_ORIG_NAME (const string& value)
      {
        //## begin ACHExportSegment::setACH_ORIG_NAME%445205AE0228.set preserve=no
        m_strACH_ORIG_NAME = value;
        //## end ACHExportSegment::setACH_ORIG_NAME%445205AE0228.set
      }


      //## Attribute: TransDate%4462E52C0231
      const string& getTransDate () const
      {
        //## begin ACHExportSegment::getTransDate%4462E52C0231.get preserve=no
        return m_strTransDate;
        //## end ACHExportSegment::getTransDate%4462E52C0231.get
      }

      void setTransDate (const string& value)
      {
        //## begin ACHExportSegment::setTransDate%4462E52C0231.set preserve=no
        m_strTransDate = value;
        //## end ACHExportSegment::setTransDate%4462E52C0231.set
      }


      //## Attribute: TransTime%4462E94D007B
      const string& getTransTime () const
      {
        //## begin ACHExportSegment::getTransTime%4462E94D007B.get preserve=no
        return m_strTransTime;
        //## end ACHExportSegment::getTransTime%4462E94D007B.get
      }

      void setTransTime (const string& value)
      {
        //## begin ACHExportSegment::setTransTime%4462E94D007B.set preserve=no
        m_strTransTime = value;
        //## end ACHExportSegment::setTransTime%4462E94D007B.set
      }


      //## Attribute: Name%4457285B0244
      const string& getName () const
      {
        //## begin ACHExportSegment::getName%4457285B0244.get preserve=no
        return m_strName;
        //## end ACHExportSegment::getName%4457285B0244.get
      }

      void setName (const string& value)
      {
        //## begin ACHExportSegment::setName%4457285B0244.set preserve=no
        m_strName = value;
        //## end ACHExportSegment::setName%4457285B0244.set
      }


      //## Attribute: EntityID%5C7D43E001C9
      const string& getEntityID () const
      {
        //## begin ACHExportSegment::getEntityID%5C7D43E001C9.get preserve=no
        return m_strEntityID;
        //## end ACHExportSegment::getEntityID%5C7D43E001C9.get
      }

      void setEntityID (const string& value)
      {
        //## begin ACHExportSegment::setEntityID%5C7D43E001C9.set preserve=no
        m_strEntityID = value;
        //## end ACHExportSegment::setEntityID%5C7D43E001C9.set
      }


      //## Attribute: ProcID%445728EF0302
      const string& getProcID () const
      {
        //## begin ACHExportSegment::getProcID%445728EF0302.get preserve=no
        return m_strProcID;
        //## end ACHExportSegment::getProcID%445728EF0302.get
      }

      void setProcID (const string& value)
      {
        //## begin ACHExportSegment::setProcID%445728EF0302.set preserve=no
        m_strProcID = value;
        //## end ACHExportSegment::setProcID%445728EF0302.set
      }


      //## Attribute: InstID%445729350287
      const string& getInstID () const
      {
        //## begin ACHExportSegment::getInstID%445729350287.get preserve=no
        return m_strInstID;
        //## end ACHExportSegment::getInstID%445729350287.get
      }

      void setInstID (const string& value)
      {
        //## begin ACHExportSegment::setInstID%445729350287.set preserve=no
        m_strInstID = value;
        //## end ACHExportSegment::setInstID%445729350287.set
      }


      //## Attribute: FM_INST_ID%445210890202
      const string& getFM_INST_ID () const
      {
        //## begin ACHExportSegment::getFM_INST_ID%445210890202.get preserve=no
        return m_strFM_INST_ID;
        //## end ACHExportSegment::getFM_INST_ID%445210890202.get
      }

      void setFM_INST_ID (const string& value)
      {
        //## begin ACHExportSegment::setFM_INST_ID%445210890202.set preserve=no
        m_strFM_INST_ID = value;
        //## end ACHExportSegment::setFM_INST_ID%445210890202.set
      }


      //## Attribute: Net%44572B6A012A
      const double& getNet () const
      {
        //## begin ACHExportSegment::getNet%44572B6A012A.get preserve=no
        return m_dNet;
        //## end ACHExportSegment::getNet%44572B6A012A.get
      }

      void setNet (const double& value)
      {
        //## begin ACHExportSegment::setNet%44572B6A012A.set preserve=no
        m_dNet = value;
        //## end ACHExportSegment::setNet%44572B6A012A.set
      }


      //## Attribute: AccountNumber%44572BE30052
      const string& getAccountNumber () const
      {
        //## begin ACHExportSegment::getAccountNumber%44572BE30052.get preserve=no
        return m_strAccountNumber;
        //## end ACHExportSegment::getAccountNumber%44572BE30052.get
      }

      void setAccountNumber (const string& value)
      {
        //## begin ACHExportSegment::setAccountNumber%44572BE30052.set preserve=no
        m_strAccountNumber = value;
        //## end ACHExportSegment::setAccountNumber%44572BE30052.set
      }


      //## Attribute: ACCT_TYPE%445210E60080
      const string& getACCT_TYPE () const
      {
        //## begin ACHExportSegment::getACCT_TYPE%445210E60080.get preserve=no
        return m_strACCT_TYPE;
        //## end ACHExportSegment::getACCT_TYPE%445210E60080.get
      }

      void setACCT_TYPE (const string& value)
      {
        //## begin ACHExportSegment::setACCT_TYPE%445210E60080.set preserve=no
        m_strACCT_TYPE = value;
        //## end ACHExportSegment::setACCT_TYPE%445210E60080.set
      }


      //## Attribute: YYMMDDHHMMSS%445206E90058
      const string& getYYMMDDHHMMSS () const
      {
        //## begin ACHExportSegment::getYYMMDDHHMMSS%445206E90058.get preserve=no
        return m_strYYMMDDHHMMSS;
        //## end ACHExportSegment::getYYMMDDHHMMSS%445206E90058.get
      }

      void setYYMMDDHHMMSS (const string& value)
      {
        //## begin ACHExportSegment::setYYMMDDHHMMSS%445206E90058.set preserve=no
        m_strYYMMDDHHMMSS = value;
        //## end ACHExportSegment::setYYMMDDHHMMSS%445206E90058.set
      }


      //## Attribute: BATCH_COUNT%44521745014B
      const int& getBATCH_COUNT () const
      {
        //## begin ACHExportSegment::getBATCH_COUNT%44521745014B.get preserve=no
        return m_lBATCH_COUNT;
        //## end ACHExportSegment::getBATCH_COUNT%44521745014B.get
      }

      void setBATCH_COUNT (const int& value)
      {
        //## begin ACHExportSegment::setBATCH_COUNT%44521745014B.set preserve=no
        m_lBATCH_COUNT = value;
        //## end ACHExportSegment::setBATCH_COUNT%44521745014B.set
      }


      //## Attribute: BATCH_DATE%445210C202FF
      const string& getBATCH_DATE () const
      {
        //## begin ACHExportSegment::getBATCH_DATE%445210C202FF.get preserve=no
        return m_strBATCH_DATE;
        //## end ACHExportSegment::getBATCH_DATE%445210C202FF.get
      }

      void setBATCH_DATE (const string& value)
      {
        //## begin ACHExportSegment::setBATCH_DATE%445210C202FF.set preserve=no
        m_strBATCH_DATE = value;
        //## end ACHExportSegment::setBATCH_DATE%445210C202FF.set
      }


      //## Attribute: BATCH_DATE_EFF%5D80EBC401E5
      const string& getBATCH_DATE_EFF () const
      {
        //## begin ACHExportSegment::getBATCH_DATE_EFF%5D80EBC401E5.get preserve=no
        return m_strBATCH_DATE_EFF;
        //## end ACHExportSegment::getBATCH_DATE_EFF%5D80EBC401E5.get
      }

      void setBATCH_DATE_EFF (const string& value)
      {
        //## begin ACHExportSegment::setBATCH_DATE_EFF%5D80EBC401E5.set preserve=no
        m_strBATCH_DATE_EFF = value;
        //## end ACHExportSegment::setBATCH_DATE_EFF%5D80EBC401E5.set
      }


      //## Attribute: TranCode%445759890025
      const string& getTranCode () const
      {
        //## begin ACHExportSegment::getTranCode%445759890025.get preserve=no
        return m_strTranCode;
        //## end ACHExportSegment::getTranCode%445759890025.get
      }

      void setTranCode (const string& value)
      {
        //## begin ACHExportSegment::setTranCode%445759890025.set preserve=no
        m_strTranCode = value;
        //## end ACHExportSegment::setTranCode%445759890025.set
      }


      //## Attribute: FILE_TRAN_COUNT%445710AE0182
      const int& getFILE_TRAN_COUNT () const
      {
        //## begin ACHExportSegment::getFILE_TRAN_COUNT%445710AE0182.get preserve=no
        return m_lFILE_TRAN_COUNT;
        //## end ACHExportSegment::getFILE_TRAN_COUNT%445710AE0182.get
      }

      void setFILE_TRAN_COUNT (const int& value)
      {
        //## begin ACHExportSegment::setFILE_TRAN_COUNT%445710AE0182.set preserve=no
        m_lFILE_TRAN_COUNT = value;
        //## end ACHExportSegment::setFILE_TRAN_COUNT%445710AE0182.set
      }


      //## Attribute: BATCH_TRAN_COUNT%445710D603E4
      const int& getBATCH_TRAN_COUNT () const
      {
        //## begin ACHExportSegment::getBATCH_TRAN_COUNT%445710D603E4.get preserve=no
        return m_lBATCH_TRAN_COUNT;
        //## end ACHExportSegment::getBATCH_TRAN_COUNT%445710D603E4.get
      }

      void setBATCH_TRAN_COUNT (const int& value)
      {
        //## begin ACHExportSegment::setBATCH_TRAN_COUNT%445710D603E4.set preserve=no
        m_lBATCH_TRAN_COUNT = value;
        //## end ACHExportSegment::setBATCH_TRAN_COUNT%445710D603E4.set
      }


      //## Attribute: BATCH_HASH%44571C0E017B
      const double& getBATCH_HASH () const
      {
        //## begin ACHExportSegment::getBATCH_HASH%44571C0E017B.get preserve=no
        return m_dBATCH_HASH;
        //## end ACHExportSegment::getBATCH_HASH%44571C0E017B.get
      }

      void setBATCH_HASH (const double& value)
      {
        //## begin ACHExportSegment::setBATCH_HASH%44571C0E017B.set preserve=no
        m_dBATCH_HASH = value;
        //## end ACHExportSegment::setBATCH_HASH%44571C0E017B.set
      }


      //## Attribute: BATCH_DEBITS_TOTAL%4457198D0353
      const double& getBATCH_DEBITS_TOTAL () const
      {
        //## begin ACHExportSegment::getBATCH_DEBITS_TOTAL%4457198D0353.get preserve=no
        return m_lBATCH_DEBITS_TOTAL;
        //## end ACHExportSegment::getBATCH_DEBITS_TOTAL%4457198D0353.get
      }

      void setBATCH_DEBITS_TOTAL (const double& value)
      {
        //## begin ACHExportSegment::setBATCH_DEBITS_TOTAL%4457198D0353.set preserve=no
        m_lBATCH_DEBITS_TOTAL = value;
        //## end ACHExportSegment::setBATCH_DEBITS_TOTAL%4457198D0353.set
      }


      //## Attribute: BATCH_CREDITS_TOTAL%4457191A0238
      const double& getBATCH_CREDITS_TOTAL () const
      {
        //## begin ACHExportSegment::getBATCH_CREDITS_TOTAL%4457191A0238.get preserve=no
        return m_lBATCH_CREDITS_TOTAL;
        //## end ACHExportSegment::getBATCH_CREDITS_TOTAL%4457191A0238.get
      }

      void setBATCH_CREDITS_TOTAL (const double& value)
      {
        //## begin ACHExportSegment::setBATCH_CREDITS_TOTAL%4457191A0238.set preserve=no
        m_lBATCH_CREDITS_TOTAL = value;
        //## end ACHExportSegment::setBATCH_CREDITS_TOTAL%4457191A0238.set
      }


      //## Attribute: FILE_DEBITS_TOTAL%445719690074
      const double& getFILE_DEBITS_TOTAL () const
      {
        //## begin ACHExportSegment::getFILE_DEBITS_TOTAL%445719690074.get preserve=no
        return m_lFILE_DEBITS_TOTAL;
        //## end ACHExportSegment::getFILE_DEBITS_TOTAL%445719690074.get
      }

      void setFILE_DEBITS_TOTAL (const double& value)
      {
        //## begin ACHExportSegment::setFILE_DEBITS_TOTAL%445719690074.set preserve=no
        m_lFILE_DEBITS_TOTAL = value;
        //## end ACHExportSegment::setFILE_DEBITS_TOTAL%445719690074.set
      }


      //## Attribute: FILE_CREDITS_TOTAL%445718EF038E
      const double& getFILE_CREDITS_TOTAL () const
      {
        //## begin ACHExportSegment::getFILE_CREDITS_TOTAL%445718EF038E.get preserve=no
        return m_lFILE_CREDITS_TOTAL;
        //## end ACHExportSegment::getFILE_CREDITS_TOTAL%445718EF038E.get
      }

      void setFILE_CREDITS_TOTAL (const double& value)
      {
        //## begin ACHExportSegment::setFILE_CREDITS_TOTAL%445718EF038E.set preserve=no
        m_lFILE_CREDITS_TOTAL = value;
        //## end ACHExportSegment::setFILE_CREDITS_TOTAL%445718EF038E.set
      }


      //## Attribute: BlockCount%4457462400DF
      const int& getBlockCount () const
      {
        //## begin ACHExportSegment::getBlockCount%4457462400DF.get preserve=no
        return m_lBlockCount;
        //## end ACHExportSegment::getBlockCount%4457462400DF.get
      }

      void setBlockCount (const int& value)
      {
        //## begin ACHExportSegment::setBlockCount%4457462400DF.set preserve=no
        m_lBlockCount = value;
        //## end ACHExportSegment::setBlockCount%4457462400DF.set
      }


      //## Attribute: FILE_HASH%44571BF1018A
      const double& getFILE_HASH () const
      {
        //## begin ACHExportSegment::getFILE_HASH%44571BF1018A.get preserve=no
        return m_dFILE_HASH;
        //## end ACHExportSegment::getFILE_HASH%44571BF1018A.get
      }

      void setFILE_HASH (const double& value)
      {
        //## begin ACHExportSegment::setFILE_HASH%44571BF1018A.set preserve=no
        m_dFILE_HASH = value;
        //## end ACHExportSegment::setFILE_HASH%44571BF1018A.set
      }


      //## Attribute: NetDRCR%44572BB60051
      const string& getNetDRCR () const
      {
        //## begin ACHExportSegment::getNetDRCR%44572BB60051.get preserve=no
        return m_strNetDRCR;
        //## end ACHExportSegment::getNetDRCR%44572BB60051.get
      }

      void setNetDRCR (const string& value)
      {
        //## begin ACHExportSegment::setNetDRCR%44572BB60051.set preserve=no
        m_strNetDRCR = value;
        //## end ACHExportSegment::setNetDRCR%44572BB60051.set
      }


      //## Attribute: RowID%46A7AB000203
      const string& getRowID () const
      {
        //## begin ACHExportSegment::getRowID%46A7AB000203.get preserve=no
        return m_strRowID;
        //## end ACHExportSegment::getRowID%46A7AB000203.get
      }

      void setRowID (const string& value)
      {
        //## begin ACHExportSegment::setRowID%46A7AB000203.set preserve=no
        m_strRowID = value;
        //## end ACHExportSegment::setRowID%46A7AB000203.set
      }


    // Additional Public Declarations
      //## begin ACHExportSegment%4451EA8E010F.public preserve=yes
      //## end ACHExportSegment%4451EA8E010F.public

  protected:
    // Additional Protected Declarations
      //## begin ACHExportSegment%4451EA8E010F.protected preserve=yes
      //## end ACHExportSegment%4451EA8E010F.protected

  private:
    // Additional Private Declarations
      //## begin ACHExportSegment%4451EA8E010F.private preserve=yes
      //## end ACHExportSegment%4451EA8E010F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin ACHExportSegment::ACH_DEST_ID%46A7A84E033C.attr preserve=no  public: string {V} 
      string m_strACH_DEST_ID;
      //## end ACHExportSegment::ACH_DEST_ID%46A7A84E033C.attr

      //## begin ACHExportSegment::ACH_DEST_INST_ID%4451FF0A025E.attr preserve=no  public: string {V} 
      string m_strACH_DEST_INST_ID;
      //## end ACHExportSegment::ACH_DEST_INST_ID%4451FF0A025E.attr

      //## begin ACHExportSegment::ACH_DEST_NAME%445202AB0202.attr preserve=no  public: string {V} 
      string m_strACH_DEST_NAME;
      //## end ACHExportSegment::ACH_DEST_NAME%445202AB0202.attr

      //## begin ACHExportSegment::ACH_ORIG_ID%46A7A85E000F.attr preserve=no  public: string {V} 
      string m_strACH_ORIG_ID;
      //## end ACHExportSegment::ACH_ORIG_ID%46A7A85E000F.attr

      //## begin ACHExportSegment::ACH_ORIG_INST_ID%4452024D0329.attr preserve=no  public: string {V} 
      string m_strACH_ORIG_INST_ID;
      //## end ACHExportSegment::ACH_ORIG_INST_ID%4452024D0329.attr

      //## begin ACHExportSegment::ACH_ORIG_NAME%445205AE0228.attr preserve=no  public: string {V} 
      string m_strACH_ORIG_NAME;
      //## end ACHExportSegment::ACH_ORIG_NAME%445205AE0228.attr

      //## begin ACHExportSegment::TransDate%4462E52C0231.attr preserve=no  public: string {V} 
      string m_strTransDate;
      //## end ACHExportSegment::TransDate%4462E52C0231.attr

      //## begin ACHExportSegment::TransTime%4462E94D007B.attr preserve=no  public: string {V} 
      string m_strTransTime;
      //## end ACHExportSegment::TransTime%4462E94D007B.attr

      //## begin ACHExportSegment::Name%4457285B0244.attr preserve=no  public: string {V} 
      string m_strName;
      //## end ACHExportSegment::Name%4457285B0244.attr

      //## begin ACHExportSegment::EntityID%5C7D43E001C9.attr preserve=no  public: string {V} 
      string m_strEntityID;
      //## end ACHExportSegment::EntityID%5C7D43E001C9.attr

      //## begin ACHExportSegment::ProcID%445728EF0302.attr preserve=no  public: string {V} 
      string m_strProcID;
      //## end ACHExportSegment::ProcID%445728EF0302.attr

      //## begin ACHExportSegment::InstID%445729350287.attr preserve=no  public: string {V} 
      string m_strInstID;
      //## end ACHExportSegment::InstID%445729350287.attr

      //## begin ACHExportSegment::FM_INST_ID%445210890202.attr preserve=no  public: string {V} 
      string m_strFM_INST_ID;
      //## end ACHExportSegment::FM_INST_ID%445210890202.attr

      //## begin ACHExportSegment::Net%44572B6A012A.attr preserve=no  public: double {V} 0
      double m_dNet;
      //## end ACHExportSegment::Net%44572B6A012A.attr

      //## begin ACHExportSegment::AccountNumber%44572BE30052.attr preserve=no  public: string {V} 
      string m_strAccountNumber;
      //## end ACHExportSegment::AccountNumber%44572BE30052.attr

      //## begin ACHExportSegment::ACCT_TYPE%445210E60080.attr preserve=no  public: string {V} 
      string m_strACCT_TYPE;
      //## end ACHExportSegment::ACCT_TYPE%445210E60080.attr

      //## begin ACHExportSegment::YYMMDDHHMMSS%445206E90058.attr preserve=no  public: string {U} 
      string m_strYYMMDDHHMMSS;
      //## end ACHExportSegment::YYMMDDHHMMSS%445206E90058.attr

      //## begin ACHExportSegment::BATCH_COUNT%44521745014B.attr preserve=no  public: int {V} 0
      int m_lBATCH_COUNT;
      //## end ACHExportSegment::BATCH_COUNT%44521745014B.attr

      //## begin ACHExportSegment::BATCH_DATE%445210C202FF.attr preserve=no  public: string {V} 
      string m_strBATCH_DATE;
      //## end ACHExportSegment::BATCH_DATE%445210C202FF.attr

      //## begin ACHExportSegment::BATCH_DATE_EFF%5D80EBC401E5.attr preserve=no  public: string {V} 
      string m_strBATCH_DATE_EFF;
      //## end ACHExportSegment::BATCH_DATE_EFF%5D80EBC401E5.attr

      //## begin ACHExportSegment::TranCode%445759890025.attr preserve=no  public: string {V} 
      string m_strTranCode;
      //## end ACHExportSegment::TranCode%445759890025.attr

      //## begin ACHExportSegment::FILE_TRAN_COUNT%445710AE0182.attr preserve=no  public: int {V} 0
      int m_lFILE_TRAN_COUNT;
      //## end ACHExportSegment::FILE_TRAN_COUNT%445710AE0182.attr

      //## begin ACHExportSegment::BATCH_TRAN_COUNT%445710D603E4.attr preserve=no  public: int {V} 0
      int m_lBATCH_TRAN_COUNT;
      //## end ACHExportSegment::BATCH_TRAN_COUNT%445710D603E4.attr

      //## begin ACHExportSegment::BATCH_HASH%44571C0E017B.attr preserve=no  public: double {V} 0
      double m_dBATCH_HASH;
      //## end ACHExportSegment::BATCH_HASH%44571C0E017B.attr

      //## begin ACHExportSegment::BATCH_DEBITS_TOTAL%4457198D0353.attr preserve=no  public: double {V} 0
      double m_lBATCH_DEBITS_TOTAL;
      //## end ACHExportSegment::BATCH_DEBITS_TOTAL%4457198D0353.attr

      //## begin ACHExportSegment::BATCH_CREDITS_TOTAL%4457191A0238.attr preserve=no  public: double {V} 0
      double m_lBATCH_CREDITS_TOTAL;
      //## end ACHExportSegment::BATCH_CREDITS_TOTAL%4457191A0238.attr

      //## begin ACHExportSegment::FILE_DEBITS_TOTAL%445719690074.attr preserve=no  public: double {V} 0
      double m_lFILE_DEBITS_TOTAL;
      //## end ACHExportSegment::FILE_DEBITS_TOTAL%445719690074.attr

      //## begin ACHExportSegment::FILE_CREDITS_TOTAL%445718EF038E.attr preserve=no  public: double {V} 0
      double m_lFILE_CREDITS_TOTAL;
      //## end ACHExportSegment::FILE_CREDITS_TOTAL%445718EF038E.attr

      //## begin ACHExportSegment::BlockCount%4457462400DF.attr preserve=no  public: int {V} 0
      int m_lBlockCount;
      //## end ACHExportSegment::BlockCount%4457462400DF.attr

      //## begin ACHExportSegment::FILE_HASH%44571BF1018A.attr preserve=no  public: double {V} 0
      double m_dFILE_HASH;
      //## end ACHExportSegment::FILE_HASH%44571BF1018A.attr

      //## begin ACHExportSegment::NetDRCR%44572BB60051.attr preserve=no  public: string {V} 
      string m_strNetDRCR;
      //## end ACHExportSegment::NetDRCR%44572BB60051.attr

      //## begin ACHExportSegment::RowID%46A7AB000203.attr preserve=no  public: string {V} 
      string m_strRowID;
      //## end ACHExportSegment::RowID%46A7AB000203.attr

    // Additional Implementation Declarations
      //## begin ACHExportSegment%4451EA8E010F.implementation preserve=yes
      //## end ACHExportSegment%4451EA8E010F.implementation

};

//## begin ACHExportSegment%4451EA8E010F.postscript preserve=yes
//## end ACHExportSegment%4451EA8E010F.postscript

//## begin module%4452014B0111.epilog preserve=yes
//## end module%4452014B0111.epilog


#endif
