//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EE22DF401CC.cm preserve=no
//	$Date:   Feb 24 2021 08:58:52  $ $Author:   e1014059  $
//	$Revision:   1.1  $
//## end module%5EE22DF401CC.cm

//## begin module%5EE22DF401CC.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5EE22DF401CC.cp

//## Module: CXOSAF07%5EE22DF401CC; Package specification
//## Subsystem: AF%39297A540052
//## Source file: C:\bV03.2A.R001\Dn\Server\Application\Af\CXODAF07.hpp

#ifndef CXOSAF07_h
#define CXOSAF07_h 1

//## begin module%5EE22DF401CC.additionalIncludes preserve=no
//## end module%5EE22DF401CC.additionalIncludes

//## begin module%5EE22DF401CC.includes preserve=yes
//## end module%5EE22DF401CC.includes

#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
//## begin module%5EE22DF401CC.declarations preserve=no
//## end module%5EE22DF401CC.declarations

//## begin module%5EE22DF401CC.additionalDeclarations preserve=yes
//## end module%5EE22DF401CC.additionalDeclarations


//## begin WireExportSegment%5EE2267B023D.preface preserve=yes
//## end WireExportSegment%5EE2267B023D.preface

//## Class: WireExportSegment%5EE2267B023D
//## Category: Totals Management::AutomatedFundsMovement_CAT%3929699700F2
//## Subsystem: AF%39297A540052
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport WireExportSegment : public segment::Segment  //## Inherits: <unnamed>%5EE2267B025F
{
  //## begin WireExportSegment%5EE2267B023D.initialDeclarations preserve=yes
  //## end WireExportSegment%5EE2267B023D.initialDeclarations

  public:
    //## Constructors (generated)
      WireExportSegment();

      WireExportSegment(const WireExportSegment &right);

    //## Destructor (generated)
      virtual ~WireExportSegment();


    //## Other Operations (specified)
      //## Operation: fields%5EE2267B025E
      virtual struct  Fields* fields () const;

      //## Operation: setFields%5EE9B22F0047
      void setFields ();

      //## Operation: setTranDate%6035F988023E
      void setTranDate (const string&  value)
      {
        //## begin WireExportSegment::setTranDate%6035F988023E.body preserve=yes
         m_strTranDate = value;
         if (value.length() >= 8)
         {
            m_strTranDateMMDDYYYY.assign(value.data() + 4, 2);
            m_strTranDateMMDDYYYY.append("/", 1);
            m_strTranDateMMDDYYYY.append(value.data() + 6, 2);
            m_strTranDateMMDDYYYY.append("/", 1);
            m_strTranDateMMDDYYYY.append(value.data() , 4);
         }
        //## end WireExportSegment::setTranDate%6035F988023E.body
      }

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: FIID%5EE479CB01F8
      void setFIID (const string& value)
      {
        //## begin WireExportSegment::setFIID%5EE479CB01F8.set preserve=no
        m_strFIID = value;
        //## end WireExportSegment::setFIID%5EE479CB01F8.set
      }


      //## Attribute: FileTotal%5EE2318D0051
      const double& getFileTotal () const
      {
        //## begin WireExportSegment::getFileTotal%5EE2318D0051.get preserve=no
        return m_dFileTotal;
        //## end WireExportSegment::getFileTotal%5EE2318D0051.get
      }

      void setFileTotal (const double& value)
      {
        //## begin WireExportSegment::setFileTotal%5EE2318D0051.set preserve=no
        m_dFileTotal = value;
        //## end WireExportSegment::setFileTotal%5EE2318D0051.set
      }


      //## Attribute: InstitutionAmount%5EE23169011A
      const double& getInstitutionAmount () const
      {
        //## begin WireExportSegment::getInstitutionAmount%5EE23169011A.get preserve=no
        return m_dInstitutionAmount;
        //## end WireExportSegment::getInstitutionAmount%5EE23169011A.get
      }

      void setInstitutionAmount (const double& value)
      {
        //## begin WireExportSegment::setInstitutionAmount%5EE23169011A.set preserve=no
        m_dInstitutionAmount = value;
        //## end WireExportSegment::setInstitutionAmount%5EE23169011A.set
      }


      //## Attribute: InstitutionId%5EE230A70163
      void setInstitutionId (const string& value)
      {
        //## begin WireExportSegment::setInstitutionId%5EE230A70163.set preserve=no
        m_strInstitutionId = value;
        //## end WireExportSegment::setInstitutionId%5EE230A70163.set
      }


      //## Attribute: InstitutionName%5EE230050228
      void setInstitutionName (const string& value)
      {
        //## begin WireExportSegment::setInstitutionName%5EE230050228.set preserve=no
        m_strInstitutionName = value;
        //## end WireExportSegment::setInstitutionName%5EE230050228.set
      }


      //## Attribute: InterchangeName%5EE2267B0246
      const string& getInterchangeName () const
      {
        //## begin WireExportSegment::getInterchangeName%5EE2267B0246.get preserve=no
        return m_strInterchangeName;
        //## end WireExportSegment::getInterchangeName%5EE2267B0246.get
      }

      void setInterchangeName (const string& value)
      {
        //## begin WireExportSegment::setInterchangeName%5EE2267B0246.set preserve=no
        m_strInterchangeName = value;
        //## end WireExportSegment::setInterchangeName%5EE2267B0246.set
      }


      //## Attribute: InterchangeProcId%5EE22FAB0044
      void setInterchangeProcId (const string& value)
      {
        //## begin WireExportSegment::setInterchangeProcId%5EE22FAB0044.set preserve=no
        m_strInterchangeProcId = value;
        //## end WireExportSegment::setInterchangeProcId%5EE22FAB0044.set
      }


      //## Attribute: InterchangeTotal%5EE2317701E6
      const double& getInterchangeTotal () const
      {
        //## begin WireExportSegment::getInterchangeTotal%5EE2317701E6.get preserve=no
        return m_dInterchangeTotal;
        //## end WireExportSegment::getInterchangeTotal%5EE2317701E6.get
      }

      void setInterchangeTotal (const double& value)
      {
        //## begin WireExportSegment::setInterchangeTotal%5EE2317701E6.set preserve=no
        m_dInterchangeTotal = value;
        //## end WireExportSegment::setInterchangeTotal%5EE2317701E6.set
      }


      //## Attribute: TemplateId%5EE8E6C0000D
      void setTemplateId (const string& value)
      {
        //## begin WireExportSegment::setTemplateId%5EE8E6C0000D.set preserve=no
        m_strTemplateId = value;
        //## end WireExportSegment::setTemplateId%5EE8E6C0000D.set
      }


    // Additional Public Declarations
      //## begin WireExportSegment%5EE2267B023D.public preserve=yes
      const string& getTemplateId() const
      {
         return m_strTemplateId;
      }
      //## end WireExportSegment%5EE2267B023D.public

  protected:
    // Additional Protected Declarations
      //## begin WireExportSegment%5EE2267B023D.protected preserve=yes
      //## end WireExportSegment%5EE2267B023D.protected

  private:
    // Additional Private Declarations
      //## begin WireExportSegment%5EE2267B023D.private preserve=yes
      //## end WireExportSegment%5EE2267B023D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin WireExportSegment::FIID%5EE479CB01F8.attr preserve=no  public: string {U} 
      string m_strFIID;
      //## end WireExportSegment::FIID%5EE479CB01F8.attr

      //## begin WireExportSegment::FileTotal%5EE2318D0051.attr preserve=no  public: double {U} 0
      double m_dFileTotal;
      //## end WireExportSegment::FileTotal%5EE2318D0051.attr

      //## begin WireExportSegment::InstitutionAmount%5EE23169011A.attr preserve=no  public: double {U} 0
      double m_dInstitutionAmount;
      //## end WireExportSegment::InstitutionAmount%5EE23169011A.attr

      //## begin WireExportSegment::InstitutionId%5EE230A70163.attr preserve=no  public: string {U} 
      string m_strInstitutionId;
      //## end WireExportSegment::InstitutionId%5EE230A70163.attr

      //## begin WireExportSegment::InstitutionName%5EE230050228.attr preserve=no  public: string {U} 
      string m_strInstitutionName;
      //## end WireExportSegment::InstitutionName%5EE230050228.attr

      //## begin WireExportSegment::InterchangeName%5EE2267B0246.attr preserve=no  public: string {V} 
      string m_strInterchangeName;
      //## end WireExportSegment::InterchangeName%5EE2267B0246.attr

      //## begin WireExportSegment::InterchangeProcId%5EE22FAB0044.attr preserve=no  public: string {U} 
      string m_strInterchangeProcId;
      //## end WireExportSegment::InterchangeProcId%5EE22FAB0044.attr

      //## begin WireExportSegment::InterchangeTotal%5EE2317701E6.attr preserve=no  public: double {U} 0
      double m_dInterchangeTotal;
      //## end WireExportSegment::InterchangeTotal%5EE2317701E6.attr

      //## begin WireExportSegment::TemplateId%5EE8E6C0000D.attr preserve=no  public: string {V} 
      string m_strTemplateId;
      //## end WireExportSegment::TemplateId%5EE8E6C0000D.attr

      //## Attribute: TranDate%5EE2267B0244
      //## begin WireExportSegment::TranDate%5EE2267B0244.attr preserve=no  public: string {V} 
      string m_strTranDate;
      //## end WireExportSegment::TranDate%5EE2267B0244.attr

      //## Attribute: TranDateMMDDYYYY%6035EFE20319
      //## begin WireExportSegment::TranDateMMDDYYYY%6035EFE20319.attr preserve=no  public: string {V} 
      string m_strTranDateMMDDYYYY;
      //## end WireExportSegment::TranDateMMDDYYYY%6035EFE20319.attr

    // Additional Implementation Declarations
      //## begin WireExportSegment%5EE2267B023D.implementation preserve=yes
      string m_strPrevInterchange;
      //## end WireExportSegment%5EE2267B023D.implementation
};

//## begin WireExportSegment%5EE2267B023D.postscript preserve=yes
//## end WireExportSegment%5EE2267B023D.postscript

//## begin module%5EE22DF401CC.epilog preserve=yes
//## end module%5EE22DF401CC.epilog


#endif
