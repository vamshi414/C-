//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4452014D0325.cm preserve=no
//	$Date:   Sep 17 2019 15:52:26  $ $Author:   e1009610  $
//	$Revision:   1.8  $
//## end module%4452014D0325.cm

//## begin module%4452014D0325.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4452014D0325.cp

//## Module: CXOSAF05%4452014D0325; Package body
//## Subsystem: AF%39297A540052
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Af\CXOSAF05.cpp

//## begin module%4452014D0325.additionalIncludes preserve=no
//## end module%4452014D0325.additionalIncludes

//## begin module%4452014D0325.includes preserve=yes
//## end module%4452014D0325.includes

#ifndef CXOSAF05_h
#include "CXODAF05.hpp"
#endif
//## begin module%4452014D0325.declarations preserve=no
//## end module%4452014D0325.declarations

//## begin module%4452014D0325.additionalDeclarations preserve=yes
#define FIELDS 30
Fields ACHExportSegment_Fields[FIELDS + 1] =
{
   "a         ","ACH_DEST_ID",0,0,
   "a         ","ACH_DEST_INST_ID",0,0,
   "a         ","ACH_DEST_NAME",0,0,
   "a         ","ACH_ORIG_ID",0,0,
   "a         ","ACH_ORIG_INST_ID",0,0,
   "a         ","ACH_ORIG_NAME",0,0,
   "a         ","BATCH_DATE",0,0,
   "a         ","TransDate",0,0,
   "a         ","TransTime",0,0,
   "a         ","Name",0,0,
   "a         ","ProcID",0,0,
   "a         ","InstID",0,0,
   "a         ","FM_INST_ID",0,0,
   "d%-12.0f  ","Net",0,0,
   "a         ","AccountNumber",0,0,
   "a         ","ACCT_TYPE",0,0,
   "a         ","YYMMDDHHMMSS",0,0,
   "l         ","BATCH_COUNT",0,0,
   "a         ","TranCode",0,0,
   "l         ","FILE_TRAN_COUNT",0,0,
   "l         ","BATCH_TRAN_COUNT",0,0,
   "d%010.0f  ","BATCH_HASH",0,0,
   "d%-12.0f  ","BATCH_DEBITS_TOTAL",0,0,
   "d%-12.0f  ","BATCH_CREDITS_TOTAL",0,0,
   "d%-12.0f  ","FILE_DEBITS_TOTAL",0,0,
   "d%-12.0f  ","FILE_CREDITS_TOTAL",0,0,
   "l         ","BlockCount",0,0,
   "d%010.0f  ","FILE_HASH",0,0,
   "a         ","EntityID",0,0,
   "a         ","BATCH_DATE_EFF",0,0,
   "~" ,"~", -1,0,
};
//## end module%4452014D0325.additionalDeclarations


// Class ACHExportSegment 

ACHExportSegment::ACHExportSegment()
  //## begin ACHExportSegment::ACHExportSegment%4451EA8E010F_const.hasinit preserve=no
      : m_dNet(0),
        m_lBATCH_COUNT(0),
        m_lFILE_TRAN_COUNT(0),
        m_lBATCH_TRAN_COUNT(0),
        m_dBATCH_HASH(0),
        m_lBATCH_DEBITS_TOTAL(0),
        m_lBATCH_CREDITS_TOTAL(0),
        m_lFILE_DEBITS_TOTAL(0),
        m_lFILE_CREDITS_TOTAL(0),
        m_lBlockCount(0),
        m_dFILE_HASH(0)
  //## end ACHExportSegment::ACHExportSegment%4451EA8E010F_const.hasinit
  //## begin ACHExportSegment::ACHExportSegment%4451EA8E010F_const.initialization preserve=yes
  //## end ACHExportSegment::ACHExportSegment%4451EA8E010F_const.initialization
{
  //## begin ACHExportSegment::ACHExportSegment%4451EA8E010F_const.body preserve=yes
   memcpy(m_sID,"AF05",4);
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_strACH_DEST_ID;
   m_pField[1] = &m_strACH_DEST_INST_ID;
   m_pField[2] = &m_strACH_DEST_NAME;
   m_pField[3] = &m_strACH_ORIG_ID;
   m_pField[4] = &m_strACH_ORIG_INST_ID;
   m_pField[5] = &m_strACH_ORIG_NAME;
   m_pField[6] = &m_strBATCH_DATE;
   m_pField[7] = &m_strTransDate;
   m_pField[8] = &m_strTransTime;
   m_pField[9] = &m_strName;
   m_pField[10] = &m_strProcID;
   m_pField[11] = &m_strInstID;
   m_pField[12] = &m_strFM_INST_ID;
   m_pField[13] = &m_dNet;
   m_pField[14] = &m_strAccountNumber;
   m_pField[15] = &m_strACCT_TYPE;
   m_pField[16] = &m_strYYMMDDHHMMSS;
   m_pField[17] = &m_lBATCH_COUNT;
   m_pField[18] = &m_strTranCode;
   m_pField[19] = &m_lFILE_TRAN_COUNT;
   m_pField[20] = &m_lBATCH_TRAN_COUNT;
   m_pField[21] = &m_dBATCH_HASH;
   m_pField[22] = &m_lBATCH_DEBITS_TOTAL;
   m_pField[23] = &m_lBATCH_CREDITS_TOTAL;
   m_pField[24] = &m_lFILE_DEBITS_TOTAL;
   m_pField[25] = &m_lFILE_CREDITS_TOTAL;
   m_pField[26] = &m_lBlockCount;
   m_pField[27] = &m_dFILE_HASH;
   m_pField[28] = &m_strEntityID;
   m_pField[29] = &m_strBATCH_DATE_EFF;
  //## end ACHExportSegment::ACHExportSegment%4451EA8E010F_const.body
}


ACHExportSegment::~ACHExportSegment()
{
  //## begin ACHExportSegment::~ACHExportSegment%4451EA8E010F_dest.body preserve=yes
   delete [] m_pField;
  //## end ACHExportSegment::~ACHExportSegment%4451EA8E010F_dest.body
}



//## Other Operations (implementation)
struct  Fields* ACHExportSegment::fields () const
{
  //## begin ACHExportSegment::fields%44521F41009F.body preserve=yes
   return &ACHExportSegment_Fields[0];
  //## end ACHExportSegment::fields%44521F41009F.body
}

// Additional Declarations
  //## begin ACHExportSegment%4451EA8E010F.declarations preserve=yes
  //## end ACHExportSegment%4451EA8E010F.declarations

//## begin module%4452014D0325.epilog preserve=yes
//## end module%4452014D0325.epilog
