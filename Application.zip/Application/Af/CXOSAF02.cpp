//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%392AEABD02E3.cm preserve=no
//## end module%392AEABD02E3.cm

//## begin module%392AEABD02E3.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%392AEABD02E3.cp

//## Module: CXOSAF02%392AEABD02E3; Package body
//## Subsystem: AF%39297A540052
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Af\CXOSAF02.cpp

//## begin module%392AEABD02E3.additionalIncludes preserve=no
//## end module%392AEABD02E3.additionalIncludes

//## begin module%392AEABD02E3.includes preserve=yes
//## end module%392AEABD02E3.includes

#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSDB31_h
#include "CXODDB31.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSAF02_h
#include "CXODAF02.hpp"
#endif


//## begin module%392AEABD02E3.declarations preserve=no
//## end module%392AEABD02E3.declarations

//## begin module%392AEABD02E3.additionalDeclarations preserve=yes
//## end module%392AEABD02E3.additionalDeclarations


// Class ACHFundsMovement 

ACHFundsMovement::ACHFundsMovement()
  //## begin ACHFundsMovement::ACHFundsMovement%392AEA370091_const.hasinit preserve=no
  //## end ACHFundsMovement::ACHFundsMovement%392AEA370091_const.hasinit
  //## begin ACHFundsMovement::ACHFundsMovement%392AEA370091_const.initialization preserve=yes
  //## end ACHFundsMovement::ACHFundsMovement%392AEA370091_const.initialization
{
  //## begin ACHFundsMovement::ACHFundsMovement%392AEA370091_const.body preserve=yes
   memcpy(m_sID,"AF02",4);
  //## end ACHFundsMovement::ACHFundsMovement%392AEA370091_const.body
}


ACHFundsMovement::~ACHFundsMovement()
{
  //## begin ACHFundsMovement::~ACHFundsMovement%392AEA370091_dest.body preserve=yes
  //## end ACHFundsMovement::~ACHFundsMovement%392AEA370091_dest.body
}



//## Other Operations (implementation)
bool ACHFundsMovement::begin ()
{
  //## begin ACHFundsMovement::begin%392AEAF80067.body preserve=yes
   m_pExportFile->erase();
   m_hACHExportSegment.setFILE_CREDITS_TOTAL(0);
   m_hACHExportSegment.setFILE_DEBITS_TOTAL(0);
   m_hACHExportSegment.setBATCH_CREDITS_TOTAL(0);
   m_hACHExportSegment.setBATCH_DEBITS_TOTAL(0);
   m_hACHExportSegment.setFILE_TRAN_COUNT(0);
   m_hACHExportSegment.setBATCH_TRAN_COUNT(0);
   m_hACHExportSegment.setFILE_HASH(0);
   m_hACHExportSegment.setBATCH_HASH(0);
   m_hResultSet.erase(m_hResultSet.begin(),m_hResultSet.end());
   m_strYYYYMMDDHHMMSS = m_pExportFile->getDATE_RECON();
   string strHHMMSS(m_pExportFile->getSCHED_TIME());
   if (strHHMMSS == "240000")
      strHHMMSS = "235959";
   m_strYYYYMMDDHHMMSS.append(strHHMMSS);
   m_hACHExportSegment.setYYMMDDHHMMSS(m_strYYYYMMDDHHMMSS.substr(2,m_strYYYYMMDDHHMMSS.length()));
   m_strSETL_INST_ID.erase();
   if (Customer::instance()->getACH_BATCHNO_FLG() == "Y")
   {
      string strBatchNum(m_strYYYYMMDDHHMMSS.data() + 2,2);
      strBatchNum.append(m_strYYYYMMDDHHMMSS.data() + 8,4);
      m_hACHExportSegment.setBATCH_COUNT(atoi(strBatchNum.c_str()));
   }
   else
      m_hACHExportSegment.setBATCH_COUNT(0);
#ifdef MVS
   m_hReport.readTemplate("DNDNACHF");
#else
   m_hReport.readTemplate("CXOXACHF");
#endif
   m_hReport.addSegment('Z', &m_hGenericSegment);
   m_hGenericSegment.set("CUST_ID", Customer::instance()->getCUST_ID());
   m_hReport.addSegment('A',&m_hACHExportSegment);
   m_hACHExportSegment.setACH_DEST_ID(Customer::instance()->getACH_DEST_ID());
   m_hACHExportSegment.setACH_DEST_INST_ID(Customer::instance()->getACH_DEST_INST_ID());
   m_hACHExportSegment.setACH_DEST_NAME(Customer::instance()->getACH_DEST_NAME());
   m_hACHExportSegment.setACH_ORIG_ID(Customer::instance()->getACH_ORIG_ID());
   m_hACHExportSegment.setACH_ORIG_INST_ID(Customer::instance()->getACH_ORIG_INST_ID());
   m_hACHExportSegment.setACH_ORIG_NAME(Customer::instance()->getACH_ORIG_NAME());
   if ((m_pExportFile->getDX_FILE_TYPE() == "FINFA0")
      || (m_pExportFile->getDX_FILE_TYPE() == "FINFD0"))
   {
      string strEvent;
      Extract::instance()->getSpec("CUSTABBR",strEvent);
      strEvent+= "SETTLE";
      Calendar* pCalendar = entitysegment::SwitchBusinessDay::instance()->getCalendar();
      if (pCalendar == 0)
         return false;
      pCalendar->setCalendar(strEvent);
      m_hReport.report("FH");
      m_hACHExportSegment.setFM_INST_ID(m_hResultSet["Bank ID"]);
      m_hACHExportSegment.setBATCH_DATE(m_strYYYYMMDDHHMMSS.substr(2,6));
      Date hDate(m_strYYYYMMDDHHMMSS.data());
      hDate += 1;
      string strDate = hDate.asString("%Y%m%d");
      m_hACHExportSegment.setBATCH_DATE_EFF(strDate.substr(2,6));
      m_hACHExportSegment.setBATCH_COUNT(m_hACHExportSegment.getBATCH_COUNT() + 1);
      m_hReport.report("BH");
   }
   return true;
  //## end ACHFundsMovement::begin%392AEAF80067.body
}

bool ACHFundsMovement::end ()
{
  //## begin ACHFundsMovement::end%392AEAFA00F6.body preserve=yes
   m_hReport.report("BT");
   int iRemainder = (m_hReport.getRecordCount() + 1) % 10;
   int iBlockCount = (m_hReport.getRecordCount() + 1) / 10;
   if (iRemainder)
      ++iBlockCount;
   m_hACHExportSegment.setBlockCount(iBlockCount);
   m_hReport.report("FT");
   if (iRemainder)
      while (iRemainder < 10)
      {
         m_hReport.report("FR"); // filler with 9's
         iRemainder++;
      }
   m_hReport.write(*m_pExportFile);
   return true;
  //## end ACHFundsMovement::end%392AEAFA00F6.body
}

bool ACHFundsMovement::letter ()
{
  //## begin ACHFundsMovement::letter%45DE0EB70222.body preserve=yes
   m_pExportFile->erase();
   string strYYYYMMDDHHMMSS(m_pExportFile->getDATE_RECON());
   char sDate[8];
   memcpy(sDate,strYYYYMMDDHHMMSS.data() + 4,2);
   sDate[2] = '/';
   memcpy(sDate + 3,strYYYYMMDDHHMMSS.data() + 6,2);
   sDate[5] = '/';
   memcpy(sDate + 6,strYYYYMMDDHHMMSS.data() + 2,2);
   m_hACHExportSegment.setTransDate(string(sDate,8));
   char sHHMM[5];
   memcpy(sHHMM,m_strYYYYMMDDHHMMSS.data() + 8,2);
   sHHMM[2] = ':';
   memcpy(sHHMM + 3,m_strYYYYMMDDHHMMSS.data() + 10,2);
   m_hACHExportSegment.setTransTime(string(sHHMM,5));
   m_hReport.report("TL");
   m_hReport.write(*m_pExportFile);
   return true;
  //## end ACHFundsMovement::letter%45DE0EB70222.body
}

bool ACHFundsMovement::process ()
{
  //## begin ACHFundsMovement::process%392AEAFB03AA.body preserve=yes
   if (Customer::instance()->getACH_ZERO_FLG() == "N" && atof(m_hResultSet["Net"].c_str()) == 0.00)
      return true;
   m_hACHExportSegment.setRowID(m_hResultSet["RowID"]);
   m_hACHExportSegment.setName(m_hResultSet["Proc/Inst Name"]);
   if (m_hResultSet["Type"] == "I")
      m_hACHExportSegment.setEntityID(m_hResultSet["Inst ID"]);
   else
      m_hACHExportSegment.setEntityID(m_hResultSet["Proc ID"]);
   m_hACHExportSegment.setProcID(m_hResultSet["Proc ID"]);
   m_hACHExportSegment.setInstID(m_hResultSet["Inst ID"]);
   m_hACHExportSegment.setFM_INST_ID(m_hResultSet["Bank ID"]);
   m_hACHExportSegment.setNetDRCR(m_hResultSet["NetDRCR"]);
   m_hACHExportSegment.setAccountNumber(m_hResultSet["Account Number"]);
   m_hACHExportSegment.setACCT_TYPE(m_hResultSet["Account Type"]);
   m_hACHExportSegment.setNet(atof(m_hResultSet["Net"].c_str()));
   m_hACHExportSegment.setProcID(m_hResultSet["Proc ID"].substr(0,6)) ;
   if (m_hACHExportSegment.getNetDRCR() == "DR")
   {
      if (m_hACHExportSegment.getACCT_TYPE() == "GL")
      {
         if (m_hACHExportSegment.getNet() != 0)
            m_hACHExportSegment.setTranCode("47");
         else
            m_hACHExportSegment.setTranCode("48");
      }
      else
      if (m_hACHExportSegment.getACCT_TYPE() == "SA")
      {
         if (m_hACHExportSegment.getNet() != 0)
            m_hACHExportSegment.setTranCode("37");
         else
            m_hACHExportSegment.setTranCode("38");
      }
      else
      {
         if (m_hACHExportSegment.getNet() != 0)
            m_hACHExportSegment.setTranCode("27");
         else
            m_hACHExportSegment.setTranCode("28");
      }
      m_hACHExportSegment.setFILE_DEBITS_TOTAL(m_hACHExportSegment.getFILE_DEBITS_TOTAL() +  m_hACHExportSegment.getNet());
      m_hACHExportSegment.setBATCH_DEBITS_TOTAL(m_hACHExportSegment.getBATCH_DEBITS_TOTAL() + m_hACHExportSegment.getNet());
   }
   else
   {
      if (m_hACHExportSegment.getACCT_TYPE() == "GL")
      {
         if (m_hACHExportSegment.getNet() != 0)
            m_hACHExportSegment.setTranCode("42");
         else
            m_hACHExportSegment.setTranCode("43");
      }
      else
      if (m_hACHExportSegment.getACCT_TYPE() == "SA")
      {
         if (m_hACHExportSegment.getNet() != 0)
            m_hACHExportSegment.setTranCode("32");
         else
            m_hACHExportSegment.setTranCode("33");
      }
      else
      {
         if (m_hACHExportSegment.getNet() != 0)
            m_hACHExportSegment.setTranCode("22");
         else
            m_hACHExportSegment.setTranCode("23");
      }
      m_hACHExportSegment.setFILE_CREDITS_TOTAL(m_hACHExportSegment.getFILE_CREDITS_TOTAL() + m_hACHExportSegment.getNet());
      m_hACHExportSegment.setBATCH_CREDITS_TOTAL(m_hACHExportSegment.getBATCH_CREDITS_TOTAL() + m_hACHExportSegment.getNet());
   }
   if (Customer::instance()->getACH_FINAL_FLG() == "I")
   {
      m_hACHExportSegment.setAccountNumber(m_hResultSet["Account Number"]);
      int i = 8;
      if (i > (int) m_hResultSet["Bank ID"].length())
         i = (int) m_hResultSet["Bank ID"].length();
      m_hACHExportSegment.setFILE_HASH(m_hACHExportSegment.getFILE_HASH() + atoi(m_hResultSet["Bank ID"].substr(0,i).c_str()));
      if (m_hACHExportSegment.getFILE_HASH() >= 10000000000)
         m_hACHExportSegment.setFILE_HASH(m_hACHExportSegment.getFILE_HASH() - 10000000000);
      m_hACHExportSegment.setBATCH_HASH(m_hACHExportSegment.getBATCH_HASH() + atoi(m_hResultSet["Bank ID"].substr(0,i).c_str()));
      if (m_hACHExportSegment.getBATCH_HASH() >= 10000000000)
         m_hACHExportSegment.setBATCH_HASH(m_hACHExportSegment.getBATCH_HASH() - 10000000000);
    }
   else
   {
      m_hACHExportSegment.setACH_DEST_INST_ID(Customer::instance()->getACH_DEST_INST_ID());
      int i = 8;
      if (i > (int) Customer::instance()->getACH_DEST_INST_ID().length())
         i = (int) Customer::instance()->getACH_DEST_INST_ID().length();
      m_hACHExportSegment.setFILE_HASH(m_hACHExportSegment.getFILE_HASH() + atoi(Customer::instance()->getACH_DEST_INST_ID().substr(0,i).c_str()));
      if (m_hACHExportSegment.getFILE_HASH() >= 10000000000)
         m_hACHExportSegment.setFILE_HASH(m_hACHExportSegment.getFILE_HASH() - 10000000000);
      m_hACHExportSegment.setBATCH_HASH(atoi(Customer::instance()->getACH_DEST_INST_ID().substr(0,i).c_str()));
      if (m_hACHExportSegment.getBATCH_HASH() >= 10000000000)
         m_hACHExportSegment.setBATCH_HASH(m_hACHExportSegment.getBATCH_HASH() - 10000000000);
   }
   // int i = (int) m_hResultSet["Account Number"].length();
   // if (i > 9)
   //    i = 9;
   // m_hACHExportSegment.setInstID(m_hResultSet["Account Number"].substr(0,i));
   m_hACHExportSegment.setName(m_hResultSet["Proc/Inst Name"]);
   m_hACHExportSegment.setFILE_TRAN_COUNT(m_hACHExportSegment.getFILE_TRAN_COUNT() + 1);
   m_hACHExportSegment.setBATCH_TRAN_COUNT(m_hACHExportSegment.getBATCH_TRAN_COUNT() + 1);
   double dAmount = m_hACHExportSegment.getNet();
   while (dAmount >= 10000000000.0l)
   {
      m_hACHExportSegment.setNet(9999999999.0l);
      m_hReport.report("EN");
      dAmount -= 9999999999.0l;
      m_hACHExportSegment.setFILE_TRAN_COUNT(m_hACHExportSegment.getFILE_TRAN_COUNT() + 1);
      m_hACHExportSegment.setBATCH_TRAN_COUNT(m_hACHExportSegment.getBATCH_TRAN_COUNT() + 1);
   }
   m_hACHExportSegment.setNet(dAmount);
   m_hReport.report("EN");
   return true;
  //## end ACHFundsMovement::process%392AEAFB03AA.body
}

// Additional Declarations
  //## begin ACHFundsMovement%392AEA370091.declarations preserve=yes
  //## end ACHFundsMovement%392AEA370091.declarations

//## begin module%392AEABD02E3.epilog preserve=yes
//## end module%392AEABD02E3.epilog
