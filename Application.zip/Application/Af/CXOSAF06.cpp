//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EE2089B0268.cm preserve=no
//	$Date:   Mar 29 2021 09:02:24  $ $Author:   e1014059  $
//	$Revision:   1.5  $
//## end module%5EE2089B0268.cm

//## begin module%5EE2089B0268.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5EE2089B0268.cp

//## Module: CXOSAF06%5EE2089B0268; Package body
//## Subsystem: AF%39297A540052
//## Source file: C:\bV03.2A.R001\Dn\Server\Application\Af\CXOSAF06.cpp

//## begin module%5EE2089B0268.additionalIncludes preserve=no
//## end module%5EE2089B0268.additionalIncludes

//## begin module%5EE2089B0268.includes preserve=yes
#ifndef CXOSUS21_h
#include "CXODUS21.hpp"
#endif
//## end module%5EE2089B0268.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSTC14_h
#include "CXODTC14.hpp"
#endif
#ifndef CXOSTC10_h
#include "CXODTC10.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSBC21_h
#include "CXODBC21.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSAF06_h
#include "CXODAF06.hpp"
#endif


//## begin module%5EE2089B0268.declarations preserve=no
//## end module%5EE2089B0268.declarations

//## begin module%5EE2089B0268.additionalDeclarations preserve=yes
//## end module%5EE2089B0268.additionalDeclarations


// Class WireTransfer 

WireTransfer::WireTransfer()
  //## begin WireTransfer::WireTransfer%5EE208280185_const.hasinit preserve=no
      : m_pExportFile(0)
  //## end WireTransfer::WireTransfer%5EE208280185_const.hasinit
  //## begin WireTransfer::WireTransfer%5EE208280185_const.initialization preserve=yes
  , m_hReport(83)
  //## end WireTransfer::WireTransfer%5EE208280185_const.initialization
{
  //## begin WireTransfer::WireTransfer%5EE208280185_const.body preserve=yes
   memcpy_s(m_sID, 4, "AF06", 4);
  //## end WireTransfer::WireTransfer%5EE208280185_const.body
}


WireTransfer::~WireTransfer()
{
  //## begin WireTransfer::~WireTransfer%5EE208280185_dest.body preserve=yes
  //## end WireTransfer::~WireTransfer%5EE208280185_dest.body
}



//## Other Operations (implementation)
bool WireTransfer::begin ()
{
  //## begin WireTransfer::begin%5EE208280188.body preserve=yes
   m_pExportFile->erase();
   m_hWireExportSegment.reset();
   m_hResultSet.erase(m_hResultSet.begin(), m_hResultSet.end());
   m_hWireExportSegment.setTranDate(m_pExportFile->getDATE_RECON());
#ifdef MVS
   m_hReport.readTemplate("DNDNWIRE");
#else
   m_hReport.readTemplate("CXOXWIRE");
#endif
   m_hReport.addSegment('A', &m_hWireExportSegment);
   m_hReport.report("CH");
   return true;
  //## end WireTransfer::begin%5EE208280188.body
}

void WireTransfer::email ()
{
  //## begin WireTransfer::email%605CABC4010C.body preserve=yes
   if (m_pExportFile->getDX_FILE_TYPE() == "FINWA0" && m_pExportFile->getSCHED_TIME() == "240000")
      return;
   map<string, WireExportSegment>::iterator pResult;
   string strInterchange;
   string strInstitutionId;
   string strTemplateId;
   double dSubTotal = 0;
   vector <string> hBatchHeader;
   vector <string> hLastLine;
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Email* pEmail = 0;
   for (pResult = m_hResultSet.begin(); pResult != m_hResultSet.end(); pResult++)
   {
      if (strTemplateId != (*pResult).second.getTemplateId())
      {
         if (pEmail != 0)
         {
            m_hGenericSegment.set("TOTAL", dSubTotal);
            if (m_pExportFile->getDX_FILE_TYPE() == "FINWD0")
               pEmail->report('Q');
            else
               pEmail->report('S');
            pEmail->report('T');
            pEmail->getFlatFile().close();
            delete pEmail;
         }
         pEmail = 0;
         dSubTotal = 0;
         if (m_pExportFile->getDX_FILE_TYPE() == "FINWD0" && (*pResult).second.getInstitutionAmount() == 0)
            continue;
         (*pResult).second._field("InstitutionId", strInstitutionId);
         Query hQuery;
         m_hContactSegment.reset();
         m_hContactSearchSegment.reset();
         m_hContactSearchSegment.setINST_ID(strInstitutionId);
         m_hContactSearchSegment.setup(hQuery);
         hQuery.setBasicPredicate("CONTACT_TYPE", "CONTACT_TYPE", "=", "WIRE");
         hQuery.setBasicPredicate("CONTACT_TYPE", "CONTACT_METHOD", "=", "E");
         m_hContactSegment.bind(hQuery);
         if (pSelectStatement->execute(hQuery) && pSelectStatement->getRows() > 0)
         {
            pEmail = new Email("CXOEAF06");
            pEmail->add('C', &m_hContactSegment);
            pEmail->add('Z', usersegment::EmailSegment::instance());
            pEmail->add('G', &m_hGenericSegment);
            usersegment::EmailSegment::instance()->setDATE_RECON(m_pExportFile->getDATE_RECON());
            if (m_pExportFile->getDX_FILE_TYPE() == "FINWD0")
               pEmail->report('D');
            else
               pEmail->report('C');
         }
      }
      m_hWireExportSegment = (*pResult).second;
      if (strInterchange.empty() || strInterchange != m_hWireExportSegment.getInterchangeName())
      {
         m_hReport.report("BH");
         m_hReport.getLast(2, hBatchHeader);
      }
      m_hReport.report("EN");
      m_hReport.getLast(1, hLastLine);
      if (pEmail)
      {
         if (strTemplateId != (*pResult).second.getTemplateId()) {
            for (int i = hBatchHeader.size() - 1; i >= 0; i--)
            {
               usersegment::EmailSegment::instance()->setField("TEXT", hBatchHeader[i]);
               pEmail->report('Y');
            }
         }
         if (hLastLine.size() > 0)
         {
            usersegment::EmailSegment::instance()->setField("TEXT", hLastLine[0]);
            pEmail->report('Y');
         }
      }
      dSubTotal += m_hWireExportSegment.getInstitutionAmount();
      strInterchange = m_hWireExportSegment.getInterchangeName();
      strTemplateId = m_hWireExportSegment.getTemplateId();
   }
   if (pEmail != 0)
   {
      m_hGenericSegment.set("TOTAL", dSubTotal);
      if (m_pExportFile->getDX_FILE_TYPE() == "FINWD0")
         pEmail->report('Q');
      else
         pEmail->report('S');
      pEmail->report('T');
      pEmail->getFlatFile().close();
      delete pEmail;
      pEmail = 0;
      dSubTotal = 0;
   }
  //## end WireTransfer::email%605CABC4010C.body
}

bool WireTransfer::end ()
{
  //## begin WireTransfer::end%5EE208280189.body preserve=yes
   return m_hReport.write(*m_pExportFile);
  //## end WireTransfer::end%5EE208280189.body
}

void WireTransfer::wireReport ()
{
  //## begin WireTransfer::wireReport%5EE216130382.body preserve=yes
   m_pExportFile->erase();
   m_hReport.report("FH");
   map<string, WireExportSegment>::iterator pResult;
   string strInterchange, strTemplateId;
   double dInterChangeTotal = 0;
   double dFileTotal = 0;
   double dSubTotal = 0;
   int iCount = 0;
   for (pResult = m_hResultSet.begin(); pResult != m_hResultSet.end(); pResult++)
   {
      if (!strTemplateId.empty() && strTemplateId != (*pResult).second.getTemplateId() && iCount > 0)
      {
         m_hWireExportSegment.setInterchangeTotal(dSubTotal);
         m_hReport.report("ST");
         dSubTotal = 0;
         iCount = 0;
      }
      if (!strInterchange.empty() && strInterchange != (*pResult).second.getInterchangeName())
      {
         m_hWireExportSegment.setInterchangeTotal(dInterChangeTotal);
         m_hReport.report("BT");
         dInterChangeTotal = 0;
      }
      if (strTemplateId == (*pResult).second.getTemplateId())
         iCount++;
      else
         dSubTotal = 0;
      m_hWireExportSegment = (*pResult).second;
      if (strInterchange.empty() || strInterchange != m_hWireExportSegment.getInterchangeName())
         m_hReport.report("BH");
      m_hReport.report("EN");
      dSubTotal += m_hWireExportSegment.getInstitutionAmount();
      strInterchange = m_hWireExportSegment.getInterchangeName();
      strTemplateId = m_hWireExportSegment.getTemplateId();
      dInterChangeTotal += m_hWireExportSegment.getInstitutionAmount();
      dFileTotal += m_hWireExportSegment.getInstitutionAmount();
   }
   m_hWireExportSegment.setInterchangeTotal(dInterChangeTotal);
   m_hWireExportSegment.setFileTotal(dFileTotal);
   m_hReport.report("BT");
   m_hReport.report("FT");
   m_hReport.write(*m_pExportFile);
   email();
  //## end WireTransfer::wireReport%5EE216130382.body
}

void WireTransfer::visitFundsMovementAmount (const string& strKey, totalscommand::FundsMovementAmount* pFundsMovementAmount)
{
  //## begin WireTransfer::visitFundsMovementAmount%5EE20828018B.body preserve=yes
   struct sKey *pKey = (struct sKey*)strKey.data();
   if (memcmp(pKey->sFM_ACCT_TYPE, "W", 1) != 0)
      return;
   //for now process only Institution entries.
   if (memcmp(&pKey->sOpt, "I", 1) != 0)
      return;
   string strResultKey = string(pKey->sFM_INST_ID, sizeof(pKey->sFM_INST_ID));
   strResultKey.append(pKey->sFM_ACCT_NO, sizeof(pKey->sFM_ACCT_NO));
   strResultKey.append(pKey->sINST_ID, sizeof(pKey->sINST_ID));
   double dNet = pFundsMovementAmount->getDebitAmount() - pFundsMovementAmount->getCreditAmount();
   string strInterchangeId(pKey->sFM_INST_ID, sizeof(pKey->sFM_INST_ID));
   trim(strInterchangeId);
   map<string, string, less <string> >::iterator pInterChange = m_hInterchange.find(strInterchangeId);

   if (pInterChange == m_hInterchange.end())
   {
      Query hQuery;
      string strPROC_NAME;
      hQuery.setQualifier("QUALIFY", "PROCESSOR");
      hQuery.bind("PROCESSOR", "PROC_NAME", Column::STRING, &strPROC_NAME);
      hQuery.setBasicPredicate("PROCESSOR", "PROC_ID", "=", strInterchangeId.c_str());
      hQuery.setBasicPredicate("PROCESSOR", "CUST_ID", "=", Customer::instance()->getCUST_ID().c_str());
      hQuery.setBasicPredicate("PROCESSOR", "CC_CHANGE_GRP_ID", "IS NULL");
      hQuery.setBasicPredicate("PROCESSOR", "CC_STATE", "=", "A");
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (!pSelectStatement->execute(hQuery))
         return ;
      m_hInterchange.insert(map<string, string, less <string> >::value_type( strInterchangeId, strPROC_NAME));
      pInterChange = m_hInterchange.find(strInterchangeId);
   }
   m_hWireExportSegment.setInstitutionName(pKey->sName);
   m_hWireExportSegment.setInterchangeName((*pInterChange).second);
   m_hWireExportSegment.setInstitutionAmount(dNet);
   m_hWireExportSegment.setInstitutionId(string(pKey->sINST_ID, sizeof(pKey->sINST_ID)));
   m_hWireExportSegment.setInterchangeProcId(strInterchangeId);
   string strBANK_ID;
   if (ConfigurationRepository::instance()->translate("INST_BANK_ID", string(pKey->sINST_ID, sizeof(pKey->sINST_ID)),strBANK_ID,"","",-1,false ))
      m_hWireExportSegment.setFIID(strBANK_ID);
   string strTemplateId(pKey->sFM_ACCT_NO, sizeof(pKey->sFM_ACCT_NO));
   trim(strTemplateId);
   m_hWireExportSegment.setTemplateId(strTemplateId);
   m_hReport.report("CN");
   map<string, WireExportSegment>::iterator pResultSet = m_hResultSet.find(strResultKey);
   if (pResultSet != m_hResultSet.end())
      (*pResultSet).second.setInstitutionAmount(dNet + (*pResultSet).second.getInstitutionAmount());
   else
      m_hResultSet.insert(map<string, WireExportSegment>::value_type(strResultKey, m_hWireExportSegment));
  //## end WireTransfer::visitFundsMovementAmount%5EE20828018B.body
}

// Additional Declarations
  //## begin WireTransfer%5EE208280185.declarations preserve=yes
  //## end WireTransfer%5EE208280185.declarations

//## begin module%5EE2089B0268.epilog preserve=yes
//## end module%5EE2089B0268.epilog
