//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39297AD001F5.cm preserve=no
//	$Date:   Jul 14 2020 05:35:26  $ $Author:   e1014059  $
//	$Revision:   1.34  $
//## end module%39297AD001F5.cm

//## begin module%39297AD001F5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%39297AD001F5.cp

//## Module: CXOPAF00%39297AD001F5; Package body
//## Subsystem: AF%39297A540052
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Af\CXOPAF00.cpp

//## begin module%39297AD001F5.additionalIncludes preserve=no
//## end module%39297AD001F5.additionalIncludes

//## begin module%39297AD001F5.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#ifndef CXOSAF06_h
#include "CXODAF06.hpp"
#endif
#ifndef CXOSST88_h
#include "CXODST88.hpp"
#endif
//## end module%39297AD001F5.includes

#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSTC24_h
#include "CXODTC24.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSTC67_h
#include "CXODTC67.hpp"
#endif
#ifndef CXOSTC68_h
#include "CXODTC68.hpp"
#endif
#ifndef CXOSIF32_h
#include "CXODIF32.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSAF02_h
#include "CXODAF02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOPAF00_h
#include "CXODAF00.hpp"
#endif


//## begin module%39297AD001F5.declarations preserve=no
//## end module%39297AD001F5.declarations

//## begin module%39297AD001F5.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new AutomatedFundsMovement();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%39297AD001F5.additionalDeclarations


// Class AutomatedFundsMovement

AutomatedFundsMovement::AutomatedFundsMovement()
  //## begin AutomatedFundsMovement::AutomatedFundsMovement%39296B8E0230_const.hasinit preserve=no
  //## end AutomatedFundsMovement::AutomatedFundsMovement%39296B8E0230_const.hasinit
  //## begin AutomatedFundsMovement::AutomatedFundsMovement%39296B8E0230_const.initialization preserve=yes
  //## end AutomatedFundsMovement::AutomatedFundsMovement%39296B8E0230_const.initialization
{
  //## begin AutomatedFundsMovement::AutomatedFundsMovement%39296B8E0230_const.body preserve=yes
   memcpy(m_sID,"AF00",4);
  //## end AutomatedFundsMovement::AutomatedFundsMovement%39296B8E0230_const.body
}


AutomatedFundsMovement::~AutomatedFundsMovement()
{
  //## begin AutomatedFundsMovement::~AutomatedFundsMovement%39296B8E0230_dest.body preserve=yes
  //## end AutomatedFundsMovement::~AutomatedFundsMovement%39296B8E0230_dest.body
}



//## Other Operations (implementation)
bool AutomatedFundsMovement::getNextFile (database::ExportFile& pExportFile, reusable::string strFileType)
{
  //## begin AutomatedFundsMovement::getNextFile%45C6C08E0051.body preserve=yes
   string strDX_FILE_TYPE;
   bool b = false;
   Query hQuery;
   hQuery.reset();
   pExportFile.bind(hQuery);
   strDX_FILE_TYPE = pExportFile.getDX_FILE_TYPE();
   if (strFileType == "ACH")
   {
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","=",pExportFile.getDX_FILE_TYPE().c_str());
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_STATE","=","FW");
   }
   else
   if (strFileType == "WIRE")
   {
      strDX_FILE_TYPE[3] = 'W';
      hQuery.setBasicPredicate("DX_DATA_CONTROL", "DX_FILE_TYPE", "=", strDX_FILE_TYPE.c_str());
      hQuery.setBasicPredicate("DX_DATA_CONTROL", "DX_STATE", "=", "FW");
      hQuery.setBasicPredicate("DX_DATA_CONTROL", "DATE_RECON", "=", pExportFile.getDATE_RECON().c_str());
      hQuery.setBasicPredicate("DX_DATA_CONTROL", "SCHED_TIME", "=", pExportFile.getSCHED_TIME().c_str());
   }
   else
   if (strFileType == "CSV")
   {
      strDX_FILE_TYPE[3] = 'C';
      hQuery.setBasicPredicate("DX_DATA_CONTROL", "DX_FILE_TYPE", "=", strDX_FILE_TYPE.c_str());
      hQuery.setBasicPredicate("DX_DATA_CONTROL", "DX_STATE", "=", "FW");
      hQuery.setBasicPredicate("DX_DATA_CONTROL", "DATE_RECON", "=", pExportFile.getDATE_RECON().c_str());
      hQuery.setBasicPredicate("DX_DATA_CONTROL", "SCHED_TIME", "=", pExportFile.getSCHED_TIME().c_str());
   }
   else
   if (strFileType == "SETTLE")
   {
      strDX_FILE_TYPE[3] = 'S';
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","=",strDX_FILE_TYPE.c_str());
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DX_STATE","IN",
         "('DW','DC')");
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DATE_RECON","=",pExportFile.getDATE_RECON().c_str() );
      hQuery.setBasicPredicate("DX_DATA_CONTROL","SCHED_TIME","=",pExportFile.getSCHED_TIME().c_str() );
   }
   else
   {
      strDX_FILE_TYPE[3] = 'L';
      hQuery.setBasicPredicate ("DX_DATA_CONTROL","DX_FILE_TYPE","=",strDX_FILE_TYPE.c_str());
      hQuery.setBasicPredicate ("DX_DATA_CONTROL","DX_STATE","=","FW");
      hQuery.setBasicPredicate("DX_DATA_CONTROL","DATE_RECON","=",pExportFile.getDATE_RECON().c_str() );
      hQuery.setBasicPredicate("DX_DATA_CONTROL","SCHED_TIME","=",pExportFile.getSCHED_TIME().c_str() );
   }
   hQuery.setOrderByClause("TSTAMP_INITIATED DESC,DX_FILE_TYPE DESC");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   return (pSelectStatement->execute(hQuery) && pSelectStatement->getRows() > 0);
  //## end AutomatedFundsMovement::getNextFile%45C6C08E0051.body
}

//## Operation: initialize%39296C960316
int AutomatedFundsMovement::initialize ()
{
  //## begin AutomatedFundsMovement::initialize%39296C960316.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("TOTALS","## AF00 START AF");
   if (iRC != 0)
   {
      UseCase::setSuccess(false);
      return iRC;
   }
   platform::Platform::instance()->createDatabaseFactory();
   entitysegment::Customer::instance();
   entitysegment::SwitchBusinessDay::instance();
   Database::instance()->connect();
   TotalsVersionMonitor::instance();
   MinuteTimer::instance()->attach(this);
   return 0;
  //## end AutomatedFundsMovement::initialize%39296C960316.body
}

void AutomatedFundsMovement::process ()
{
  //## begin AutomatedFundsMovement::process%45B0919001E7.body preserve=yes
   UseCase hUseCase("DIST","## AF00 FORMAT FILE");
   const char* pszACHFileType[2] =
   {
      "FINFA0",
      "FINFD0"
   };
   int iDX_FILE_ID;
   bool b = false;
   FinancialSettlementFile* pFinancialSettlementFile = 0;
   if (entitysegment::Customer::instance()->getTotalsVersion() == 1)
      pFinancialSettlementFile = new FinancialSettlementFile1;
   else
      pFinancialSettlementFile = new FinancialSettlementFile2;
   ExportFile* pExportFile = new ExportFile();
   for (int m = 0; m < 2; ++m)
   {
      pExportFile->setDX_FILE_TYPE(pszACHFileType[m]);
      if (getNextFile(*pExportFile, "ACH"))
      {
         iDX_FILE_ID = pExportFile->getDX_FILE_ID();
         if (getNextFile(*pExportFile, "SETTLE"))
         {
            pFinancialSettlementFile->setDX_FILE_ID(pExportFile->getDX_FILE_ID());
            pFinancialSettlementFile->setDX_FILE_TYPE(pExportFile->getDX_FILE_TYPE());
            pFinancialSettlementFile->setDATE_RECON(pExportFile->getDATE_RECON());
         }
         else
            break;
         pFinancialSettlementFile->import();
         ACHFundsMovement hACHFundsMovement;
         hACHFundsMovement.setExportFile(pExportFile);
         pExportFile->setDX_FILE_ID(iDX_FILE_ID);
         pExportFile->setDX_FILE_TYPE(pszACHFileType[m]);
         hACHFundsMovement.begin();
         pFinancialSettlementFile->accept(hACHFundsMovement);
         hACHFundsMovement.end();
         UseCase::addItem();
         UseCase::setSuccess((pExportFile->updateProgress(pExportFile->getDX_FILE_ID(), "DW", Clock::instance()->getYYYYMMDDHHMMSSHN())));
         if (getNextFile(*pExportFile, "LETTER"))
         {
            hACHFundsMovement.letter();
            UseCase::addItem();
            UseCase::setSuccess((pExportFile->updateProgress(pExportFile->getDX_FILE_ID(), "DW", Clock::instance()->getYYYYMMDDHHMMSSHN())));
         }
         pExportFile->setDX_FILE_TYPE(pszACHFileType[m]);
         if (getNextFile(*pExportFile, "CSV"))
         {
            WireTransfer hWireTransfer;
            hWireTransfer.setExportFile(pExportFile);
            hWireTransfer.begin();
            pFinancialSettlementFile->accept(hWireTransfer);
            hWireTransfer.end();
            UseCase::addItem();
            UseCase::setSuccess((pExportFile->updateProgress(pExportFile->getDX_FILE_ID(), "DW", Clock::instance()->getYYYYMMDDHHMMSSHN())));
            if (getNextFile(*pExportFile, "WIRE"))
            {
               hWireTransfer.wireReport();
               UseCase::addItem();
               UseCase::setSuccess((pExportFile->updateProgress(pExportFile->getDX_FILE_ID(), "DW", Clock::instance()->getYYYYMMDDHHMMSSHN())));
            }
         }
      }
   }
   delete pExportFile;
   delete pFinancialSettlementFile;
  //## end AutomatedFundsMovement::process%45B0919001E7.body
}

//## Operation: update%392C1EB7007E
void AutomatedFundsMovement::update (Subject* pSubject)
{
  //## begin AutomatedFundsMovement::update%392C1EB7007E.body preserve=yes
   if (pSubject == MinuteTimer::instance()
      && Database::instance()->state() == Database::CONNECTED)
   {
      process();
      if (Database::instance()->transactionState() == Database::COMMITREQUIRED)
      Database::instance()->commit();
      else
      if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
         Database::instance()->rollback();
   }
   Application::update(pSubject);
  //## end AutomatedFundsMovement::update%392C1EB7007E.body
}

// Additional Declarations
  //## begin AutomatedFundsMovement%39296B8E0230.declarations preserve=yes
  //## end AutomatedFundsMovement%39296B8E0230.declarations

//## begin module%39297AD001F5.epilog preserve=yes
//## end module%39297AD001F5.epilog
