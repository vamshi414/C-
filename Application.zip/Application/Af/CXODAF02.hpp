//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%392AEA7D02CD.cm preserve=no
//## end module%392AEA7D02CD.cm

//## begin module%392AEA7D02CD.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%392AEA7D02CD.cp

//## Module: CXOSAF02%392AEA7D02CD; Package specification
//## Subsystem: AF%39297A540052
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Af\CXODAF02.hpp

#ifndef CXOSAF02_h
#define CXOSAF02_h 1

//## begin module%392AEA7D02CD.additionalIncludes preserve=no
//## end module%392AEA7D02CD.additionalIncludes

//## begin module%392AEA7D02CD.includes preserve=yes
//## end module%392AEA7D02CD.includes

#ifndef CXOSBC21_h
#include "CXODBC21.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSAF05_h
#include "CXODAF05.hpp"
#endif
#ifndef CXOSAF01_h
#include "CXODAF01.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
class Customer;
} // namespace entitysegment

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class DateTime;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Calendar;
class ExportFile;

} // namespace database

//## begin module%392AEA7D02CD.declarations preserve=no
//## end module%392AEA7D02CD.declarations

//## begin module%392AEA7D02CD.additionalDeclarations preserve=yes
//## end module%392AEA7D02CD.additionalDeclarations


//## begin ACHFundsMovement%392AEA370091.preface preserve=yes
//## end ACHFundsMovement%392AEA370091.preface

//## Class: ACHFundsMovement%392AEA370091
//	<body>
//	<title>CG
//	<h1>AF
//	<h2>FI
//	<!-- ACHFundsMovement : General -->
//	<h3>Template
//	<p>
//	The Automated Funds Movement service reads the following
//	template:
//	<ul>
//	<li><i>node001</i>\Alpha\Source\CXOXACHF.txt
//	</ul>
//	<p>
//	The supplied template conforms to the U.S. standard ACH
//	format.
//	It can be modified for your installation.
//	<p>
//	The template contains the following record types:
//	<ul>
//	<li>TL - transmittal letter
//	<li>FH - file header
//	<li>BH - batch header
//	<li>EN - entry
//	<li>BT - batch trailer
//	<li>FT - file trailer
//	<li>FR - file filler
//	<li>SY - symbol definition
//	</ul>
//	The TL records are copied to the Financial Settlement
//	(Funds Movement Cover Letter) and Financial Settlement
//	(Delta Funds Movement Cover Letter) files.
//	The FH, BH, EN, BT, FT and FR records are copied to the
//	Financial Settlement (Funds Movement) and Financial
//	Settlement (Delta Funds Movement) files.
//	<p>
//	The SY record contains the symbol definitions that are
//	available to the template.
//	Symbols in the template are replaced with values from
//	the following sources:
//	<ul>
//	<li>STS_CUSTOMER table
//	<li>DX_DATA_CONTROL table
//	<li>FINSA0 (or FINSD0) result set
//	<li>Calculated amounts
//	</ul>
//	<p>
//	The following values are available from the STS_CUSTOMER
//	table:
//	<p>
//	<table>
//	<tr>
//	<th>Symbol
//	<th>Source
//	<tr>
//	<td>~DEST_ID ~Z.ACH_DEST_ID %-9s
//	<td>STS_CUSTOMER.ACH_DEST_ID
//	<tr>
//	<td>~DEST_IN ~Z.ACH_DEST_INST_ID %-9s
//	<td>STS_CUSTOMER.ACH_DEST_INST_ID
//	<tr>
//	<td>~DEST_NAME ~Z.ACH_DEST_NAME %-23s
//	<td>STS_CUSTOMER.ACH_DEST_NAME
//	<tr>
//	<td>~ORIG_ID ~Z.ACH_ORIG_ID %-9s
//	<td>STS_CUSTOMER.ACH_ORIG_ID
//	<tr>
//	<td>~ORIG_IN ~Z.ACH_ORIG_INST_ID %-9s
//	<td>STS_CUSTOMER.ACH_ORIG_INST_ID
//	<tr>
//	<td>~ORIG_NAME ~Z.ACH_ORIG_NAME %-23s
//	<td>STS_CUSTOMER.ACH_ORIG_NAME
//	</table>
//	<p>
//	The following values are available from the DX_DATA_
//	CONTROL table:
//	<p>
//	<table>
//	<tr>
//	<th>Symbol
//	<th>Source
//	<tr>
//	<td>~BDAT ~Z.BATCH_DATE %-6s
//	<td>DX_DATA_CONTROL.DATE_RECON (YYMMDD)
//	<tr>
//	<td>~D1 ~Z.TransDate %-8s
//	<td>DX_DATA_CONTROL.DATE_RECON (YYYYMMDD)
//	<tr>
//	<td>~T1 ~Z.TransTime %-5s
//	<td>DX_DATA_CONTROL.SCHED_TIME
//	</table>
//	<p>
//	The following values are available from the FINSA0 (or
//	FINSD0) result set:
//	<p>
//	<table>
//	<tr>
//	<th>Symbol
//	<th>Source
//	<tr>
//	<td>~NAME ~Z.Name %-22.22s %-22.22s
//	<td>PROCESSOR.PROC_NAME or INSTITUTION.NAME
//	<tr>
//	<td>~PRID ~Z.ProcID %-6.6s
//	<td>PROCESSOR.PROC_ID
//	<tr>
//	<td>~INST_ID ~Z.InstID %-9.9s
//	<td>INSTITUTION.INST_ID
//	<tr>
//	<td>~ACCT_IN ~Z.FM_INST_ID %-9.9s
//	<td><i>entity</i>_ACCT.FM_INST_ID
//	<tr>
//	<td>~NET ~Z.Net %010d
//	<td>Net funds movement amount
//	<tr>
//	<td>~ACCT_ID ~Z.AccountNumber %-17s
//	<td><i>entity</i>_ACCT.ACCT_ID
//	<tr>
//	<td>~A ~Z.ACCT_TYPE %-2.2s
//	<td><i>entity</i>_ACCT.ACCT_TYPE
//	</table>
//	<p>
//	The following values are available from calculated
//	amounts:
//	<p>
//	<table>
//	<tr>
//	<th>Symbol
//	<th>Source
//	<tr>
//	<td>~DT1 ~Z.YYMMDDHHMMSS %-10s
//	<td>Date and time for the file header
//	<tr>
//	<td>~BCNT ~Z.BATCH_COUNT %07d
//	<td>Batch count for the batch header and trailer
//	<tr>
//	<td>~T ~Z.TranCode %-2s
//	<td>Derived from <i>entity</i>_ACCT.ACCT_TYPE
//	<tr>
//	<td>~SEQNO ~Z.FILE_TRAN_COUNT %07d
//	<td>Sequence number for each detail entry
//	<tr>
//	<td>~BTCNT ~Z.BATCH_TRAN_COUNT %06d
//	<td>Entry count for the batch trailer
//	<tr>
//	<td>~BTHASH ~Z.BATCH_HASH %010d
//	<td>Account number hash total for the batch trailer
//	<tr>
//	<td>~BTDBTOT ~Z.BATCH_DEBITS_TOTAL %012d
//	<td>Subtotal debit amount for the batch trailer
//	<tr>
//	<td>~BTCRTOT ~Z.BATCH_CREDITS_TOTAL %012d
//	<td>Subtotal credit amount for the batch trailer
//	<tr>
//	<td>~FTL_DB_TOT ~Z.FILE_DEBITS_TOTAL %13.2f
//	<td>Total debit amount for the transmittal letter
//	<tr>
//	<td>~FTL_CR_TOT ~Z.FILE_CREDITS_TOTAL %13.2f
//	<td>Total credit amount for the transmittal letter
//	<tr>
//	<td>~FBCNT ~Z.BATCH_COUNT %06d
//	<td>Batch count for the file trailer
//	<tr>
//	<td>~BLCNT ~Z.BlockCount %06d
//	<td>Number of blocks for the file trailer
//	<tr>
//	<td>~FTNCNT ~Z.FILE_TRAN_COUNT %08d
//	<td>Number of transactions for the file trailer
//	<tr>
//	<td>~FILE_HASH ~Z.FILE_HASH %010d
//	<td>Account number hash total for the file trailer
//	<tr>
//	<td>~FL_DB_TOT ~Z.FILE_DEBITS_TOTAL %012d
//	<td>Total debit amount for the file trailer
//	<tr>
//	<td>~FL_CR_TOT ~Z.FILE_CREDITS_TOTAL %012d
//	<td>Total credit amount for the file trailer
//	</table>
//	<p>
//	Note that <i>entity</i>_ACCT can be either PROCESSOR_GRP_
//	ACCT, PROCESSOR_ACCT, INSTITUTION_ACCT, REPORTING_LVL_
//	ACCT or DEVICE_ACCT.
//	</body>
//## Category: Totals Management::AutomatedFundsMovement_CAT%3929699700F2
//## Subsystem: AF%39297A540052
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%393FF89C01A8;IF::Extract { -> F}
//## Uses: <unnamed>%3D6FB4140242;timer::Clock { -> F}
//## Uses: <unnamed>%3D6FC33C02EE;IF::DateTime { -> F}
//## Uses: <unnamed>%45C160C503C5;database::ExportFile { -> F}
//## Uses: <unnamed>%45C2C1AD02B6;entitysegment::Customer { -> F}
//## Uses: <unnamed>%45E33B71002E;timer::Date { -> F}
//## Uses: <unnamed>%5C1A456703DA;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%5C1A458F0008;database::Calendar { -> F}
//## Uses: <unnamed>%668D693201AB;segment::GenericSegment { -> F}

class ACHFundsMovement : public FundsMovement  //## Inherits: <unnamed>%392AEA54004D
{
  //## begin ACHFundsMovement%392AEA370091.initialDeclarations preserve=yes
  //## end ACHFundsMovement%392AEA370091.initialDeclarations

  public:
    //## Constructors (generated)
      ACHFundsMovement();

    //## Destructor (generated)
      virtual ~ACHFundsMovement();


    //## Other Operations (specified)
      //## Operation: begin%392AEAF80067
      virtual bool begin ();

      //## Operation: end%392AEAFA00F6
      virtual bool end ();

      //## Operation: letter%45DE0EB70222
      bool letter ();

    // Additional Public Declarations
      //## begin ACHFundsMovement%392AEA370091.public preserve=yes
      //## end ACHFundsMovement%392AEA370091.public

  protected:

    //## Other Operations (specified)
      //## Operation: process%392AEAFB03AA
      virtual bool process ();

    // Additional Protected Declarations
      //## begin ACHFundsMovement%392AEA370091.protected preserve=yes
      //## end ACHFundsMovement%392AEA370091.protected

  private:
    // Additional Private Declarations
      //## begin ACHFundsMovement%392AEA370091.private preserve=yes
      //## end ACHFundsMovement%392AEA370091.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: SETL_INST_ID%3D75FCA90271
      //## begin ACHFundsMovement::SETL_INST_ID%3D75FCA90271.attr preserve=no  private: string {V} 
      string m_strSETL_INST_ID;
      //## end ACHFundsMovement::SETL_INST_ID%3D75FCA90271.attr

      //## Attribute: YYYYMMDDHHMMSS%3D762A30036B
      //## begin ACHFundsMovement::YYYYMMDDHHMMSS%3D762A30036B.attr preserve=no  private: string {V} 
      string m_strYYYYMMDDHHMMSS;
      //## end ACHFundsMovement::YYYYMMDDHHMMSS%3D762A30036B.attr

    // Data Members for Associations

      //## Association: Totals Management::AutomatedFundsMovement_CAT::<unnamed>%45E339FC00BB
      //## Role: ACHFundsMovement::<m_hACHExportSegment>%45E339FC035B
      //## begin ACHFundsMovement::<m_hACHExportSegment>%45E339FC035B.role preserve=no  public: ACHExportSegment { -> VHgN}
      ACHExportSegment m_hACHExportSegment;
      //## end ACHFundsMovement::<m_hACHExportSegment>%45E339FC035B.role

      //## Association: Totals Management::AutomatedFundsMovement_CAT::<unnamed>%45E33A360203
      //## Role: ACHFundsMovement::<m_hReport>%45E33A370203
      //## begin ACHFundsMovement::<m_hReport>%45E33A370203.role preserve=no  public: command::Report { -> VHgN}
      command::Report m_hReport;
      //## end ACHFundsMovement::<m_hReport>%45E33A370203.role

      //## Association: Totals Management::AutomatedFundsMovement_CAT::<unnamed>%668EABB00230
      //## Role: ACHFundsMovement::<m_hGenericSegment>%668EABB103B7
      //## begin ACHFundsMovement::<m_hGenericSegment>%668EABB103B7.role preserve=no  public: segment::GenericSegment { -> VHgN}
      segment::GenericSegment m_hGenericSegment;
      //## end ACHFundsMovement::<m_hGenericSegment>%668EABB103B7.role

    // Additional Implementation Declarations
      //## begin ACHFundsMovement%392AEA370091.implementation preserve=yes
      //## end ACHFundsMovement%392AEA370091.implementation

};

//## begin ACHFundsMovement%392AEA370091.postscript preserve=yes
//## end ACHFundsMovement%392AEA370091.postscript

//## begin module%392AEA7D02CD.epilog preserve=yes
//## end module%392AEA7D02CD.epilog


#endif
