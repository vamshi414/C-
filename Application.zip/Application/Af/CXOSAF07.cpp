//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EE22E020081.cm preserve=no
//	$Date:   Feb 24 2021 08:58:54  $ $Author:   e1014059  $
//	$Revision:   1.1  $
//## end module%5EE22E020081.cm

//## begin module%5EE22E020081.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5EE22E020081.cp

//## Module: CXOSAF07%5EE22E020081; Package body
//## Subsystem: AF%39297A540052
//## Source file: C:\bV03.2A.R001\Dn\Server\Application\Af\CXOSAF07.cpp

//## begin module%5EE22E020081.additionalIncludes preserve=no
//## end module%5EE22E020081.additionalIncludes

//## begin module%5EE22E020081.includes preserve=yes
//## end module%5EE22E020081.includes

#ifndef CXOSAF07_h
#include "CXODAF07.hpp"
#endif
//## begin module%5EE22E020081.declarations preserve=no
//## end module%5EE22E020081.declarations

//## begin module%5EE22E020081.additionalDeclarations preserve=yes
#define FIELDS 11
Fields WireExportSegment_Fields[FIELDS + 1] =
{
   "d%-18.2f  ", "FileTotal", 0, 0,
   "d%-18.2f  ", "InstitutionAmount", 0, 0,
   "a         ", "InstitutionId", 0, 0,
   "a         ", "FIID", 0, 0,
   "a         ", "InstitutionName", 0, 0,
   "a         ", "InterchangeName", 0, 0,
   "d%-18.2f  ", "InterchangeTotal", 0, 0,
   "a         ", "TranDate", 0, 0,
   "a         ", "InterchangeProcId", 0, 0,
   "a         ", "TemplateId", 0, 0,
   "a         ", "TranDateMMDDYYYY", 0, 0,
   "~", "~", -1, 0,
};
//## end module%5EE22E020081.additionalDeclarations


// Class WireExportSegment 

WireExportSegment::WireExportSegment()
  //## begin WireExportSegment::WireExportSegment%5EE2267B023D_const.hasinit preserve=no
      : m_dFileTotal(0),
        m_dInstitutionAmount(0),
        m_dInterchangeTotal(0)
  //## end WireExportSegment::WireExportSegment%5EE2267B023D_const.hasinit
  //## begin WireExportSegment::WireExportSegment%5EE2267B023D_const.initialization preserve=yes
  //## end WireExportSegment::WireExportSegment%5EE2267B023D_const.initialization
{
  //## begin WireExportSegment::WireExportSegment%5EE2267B023D_const.body preserve=yes
   memcpy(m_sID, "AF07", 4);
   setFields();
  //## end WireExportSegment::WireExportSegment%5EE2267B023D_const.body
}

WireExportSegment::WireExportSegment(const WireExportSegment &right)
  //## begin WireExportSegment::WireExportSegment%5EE2267B023D_copy.hasinit preserve=no
  //## end WireExportSegment::WireExportSegment%5EE2267B023D_copy.hasinit
  //## begin WireExportSegment::WireExportSegment%5EE2267B023D_copy.initialization preserve=yes
  //## end WireExportSegment::WireExportSegment%5EE2267B023D_copy.initialization
{
  //## begin WireExportSegment::WireExportSegment%5EE2267B023D_copy.body preserve=yes
   memcpy(m_sID, "AF07", 4);
   setFields();
   m_dFileTotal = right.m_dFileTotal;
   m_dInstitutionAmount = right.m_dInstitutionAmount;
   m_strInstitutionId = right.m_strInstitutionId;
   m_strFIID = right.m_strFIID;
   m_strInstitutionName = right.m_strInstitutionName;
   m_strInterchangeName = right.m_strInterchangeName;
   m_dInterchangeTotal = right.m_dInterchangeTotal;
   m_strTranDate = right.m_strTranDate;
   m_strInterchangeProcId = right.m_strInterchangeProcId;
   m_strTemplateId = right.m_strTemplateId;
   m_strTranDateMMDDYYYY = right.m_strTranDateMMDDYYYY;
  //## end WireExportSegment::WireExportSegment%5EE2267B023D_copy.body
}


WireExportSegment::~WireExportSegment()
{
  //## begin WireExportSegment::~WireExportSegment%5EE2267B023D_dest.body preserve=yes
   delete[] m_pField;
  //## end WireExportSegment::~WireExportSegment%5EE2267B023D_dest.body
}



//## Other Operations (implementation)
struct  Fields* WireExportSegment::fields () const
{
  //## begin WireExportSegment::fields%5EE2267B025E.body preserve=yes
   return &WireExportSegment_Fields[0];
  //## end WireExportSegment::fields%5EE2267B025E.body
}

void WireExportSegment::setFields ()
{
  //## begin WireExportSegment::setFields%5EE9B22F0047.body preserve=yes
   m_lNumberOfFields = FIELDS;
   m_pField = new void*[FIELDS];
   m_pField[0] = &m_dFileTotal;
   m_pField[1] = &m_dInstitutionAmount;
   m_pField[2] = &m_strInstitutionId;
   m_pField[3] = &m_strFIID;
   m_pField[4] = &m_strInstitutionName;
   m_pField[5] = &m_strInterchangeName;
   m_pField[6] = &m_dInterchangeTotal;
   m_pField[7] = &m_strTranDate;
   m_pField[8] = &m_strInterchangeProcId;
   m_pField[9] = &m_strTemplateId;
   m_pField[10] = &m_strTranDateMMDDYYYY;
  //## end WireExportSegment::setFields%5EE9B22F0047.body
}

// Additional Declarations
  //## begin WireExportSegment%5EE2267B023D.declarations preserve=yes
  //## end WireExportSegment%5EE2267B023D.declarations

//## begin module%5EE22E020081.epilog preserve=yes
//## end module%5EE22E020081.epilog
