//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%392981B701EA.cm preserve=no
//	$Date:   Feb 27 2007 09:58:26  $ $Author:   D02405  $
//	$Revision:   1.13  $
//## end module%392981B701EA.cm

//## begin module%392981B701EA.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%392981B701EA.cp

//## Module: CXOSAF01%392981B701EA; Package specification
//## Subsystem: AF%39297A540052
//## Source file: C:\Devel\Dn\Server\Application\AF\CXODAF01.hpp

#ifndef CXOSAF01_h
#define CXOSAF01_h 1

//## begin module%392981B701EA.additionalIncludes preserve=no
//## end module%392981B701EA.additionalIncludes

//## begin module%392981B701EA.includes preserve=yes
// $Date:   Feb 27 2007 09:58:26  $ $Author:   D02405  $ $Revision:   1.13  $
#include <map>
//## end module%392981B701EA.includes

#ifndef CXOSTC36_h
#include "CXODTC36.hpp"
#endif

//## Modelname: Totals Management::TotalsCommand_CAT%3884FA670353
namespace totalscommand {
class FundsMovementAmount;
} // namespace totalscommand

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class ExportFile;

} // namespace database

//## begin module%392981B701EA.declarations preserve=no
//## end module%392981B701EA.declarations

//## begin module%392981B701EA.additionalDeclarations preserve=yes
//## end module%392981B701EA.additionalDeclarations


//## begin FundsMovement%39297E0603B5.preface preserve=yes
//## end FundsMovement%39297E0603B5.preface

//## Class: FundsMovement%39297E0603B5
//## Category: Totals Management::AutomatedFundsMovement_CAT%3929699700F2
//## Subsystem: AF%39297A540052
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3929801D015E;IF::Extract { -> F}
//## Uses: <unnamed>%3945270803AA;process::Application { -> F}
//## Uses: <unnamed>%45B5CAD1033C;database::ExportFile { -> F}
//## Uses: <unnamed>%45CAC4D40330;totalscommand::FundsMovementAmount { -> F}

class FundsMovement : public totalscommand::FinancialSettlementFileVisitor  //## Inherits: <unnamed>%45B09799032E
{
  //## begin FundsMovement%39297E0603B5.initialDeclarations preserve=yes
  public:
  //## end FundsMovement%39297E0603B5.initialDeclarations

  public:
    //## Constructors (generated)
      FundsMovement();

    //## Destructor (generated)
      virtual ~FundsMovement();


    //## Other Operations (specified)
      //## Operation: begin%392AE6CF027B
      //	Abstract function for any preprocessing that needs to
      //	take place before the processing of the data.
      virtual bool begin () = 0;

      //## Operation: end%392AE71D0205
      //	Abstract function for any postprocessing that needs to
      //	take place after the processing of the data.
      virtual bool end () = 0;

      //## Operation: visitFundsMovementAmount%45B098240279
      virtual void visitFundsMovementAmount (const string& strKey, totalscommand::FundsMovementAmount* pFundsMovementAmount);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ExportFile%45CABAC90274
      void setExportFile (database::ExportFile*& value)
      {
        //## begin FundsMovement::setExportFile%45CABAC90274.set preserve=no
        m_pExportFile = value;
        //## end FundsMovement::setExportFile%45CABAC90274.set
      }


    // Additional Public Declarations
      //## begin FundsMovement%39297E0603B5.public preserve=yes
      //## end FundsMovement%39297E0603B5.public

  protected:

    //## Other Operations (specified)
      //## Operation: process%392AE7370203
      //	Abstract function for the processing of the data.
      virtual bool process () = 0;

    // Data Members for Class Attributes

      //## Attribute: ReconDate%392C2B720321
      //## begin FundsMovement::ReconDate%392C2B720321.attr preserve=no  protected: string {U} 
      string m_strReconDate;
      //## end FundsMovement::ReconDate%392C2B720321.attr

      //## begin FundsMovement::ExportFile%45CABAC90274.attr preserve=no  public: database::ExportFile* {U} 0
      database::ExportFile* m_pExportFile;
      //## end FundsMovement::ExportFile%45CABAC90274.attr

    // Additional Protected Declarations
      //## begin FundsMovement%39297E0603B5.protected preserve=yes
      map<string,string,less<string> > m_hResultSet;
      //## end FundsMovement%39297E0603B5.protected
  private:
    // Additional Private Declarations
      //## begin FundsMovement%39297E0603B5.private preserve=yes
      //## end FundsMovement%39297E0603B5.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin FundsMovement%39297E0603B5.implementation preserve=yes
      //## end FundsMovement%39297E0603B5.implementation

};

//## begin FundsMovement%39297E0603B5.postscript preserve=yes
//## end FundsMovement%39297E0603B5.postscript

//## begin module%392981B701EA.epilog preserve=yes
//## end module%392981B701EA.epilog


#endif
