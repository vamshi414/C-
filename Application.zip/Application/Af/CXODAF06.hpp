//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EE2088D0355.cm preserve=no
//	$Date:   Mar 26 2021 09:30:22  $ $Author:   e1014059  $
//	$Revision:   1.2  $
//## end module%5EE2088D0355.cm

//## begin module%5EE2088D0355.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5EE2088D0355.cp

//## Module: CXOSAF06%5EE2088D0355; Package specification
//## Subsystem: AF%39297A540052
//## Source file: C:\bV03.2A.R001\Dn\Server\Application\Af\CXODAF06.hpp

#ifndef CXOSAF06_h
#define CXOSAF06_h 1

//## begin module%5EE2088D0355.additionalIncludes preserve=no
//## end module%5EE2088D0355.additionalIncludes

//## begin module%5EE2088D0355.includes preserve=yes
#ifndef CXOSNS10_h
#include "CXODNS10.hpp"
#endif
#ifndef CXOSNS11_h
#include "CXODNS11.hpp"
#endif
#ifndef CXOSBC25_h
#include "CXODBC25.hpp"
#endif
#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
//## end module%5EE2088D0355.includes

#ifndef CXOSBC21_h
#include "CXODBC21.hpp"
#endif
#ifndef CXOSAF07_h
#include "CXODAF07.hpp"
#endif
#ifndef CXOSTC36_h
#include "CXODTC36.hpp"
#endif

//## Modelname: Totals Management::TotalsCommand_CAT%3884FA670353
namespace totalscommand {
class FundsMovementAmount;
class FinancialSettlementTotal;
} // namespace totalscommand

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

namespace database {
class ExportFile;

} // namespace database

//## begin module%5EE2088D0355.declarations preserve=no
//## end module%5EE2088D0355.declarations

//## begin module%5EE2088D0355.additionalDeclarations preserve=yes
//## end module%5EE2088D0355.additionalDeclarations


//## begin WireTransfer%5EE208280185.preface preserve=yes
//## end WireTransfer%5EE208280185.preface

//## Class: WireTransfer%5EE208280185
//## Category: Totals Management::AutomatedFundsMovement_CAT%3929699700F2
//## Subsystem: AF%39297A540052
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5EE208380115;process::Application { -> F}
//## Uses: <unnamed>%5EE2083B02E3;database::ExportFile { -> F}
//## Uses: <unnamed>%5EE208400035;totalscommand::FundsMovementAmount { -> F}
//## Uses: <unnamed>%5EE246C7003F;database::ExportFile { -> F}
//## Uses: <unnamed>%5EE4F4C20290;totalscommand::FinancialSettlementTotal { -> F}
//## Uses: <unnamed>%5EE893020263;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%5EE8987303DA;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%5EE8BC3402D9;command::Report { -> F}
//## Uses: <unnamed>%5EEAEFB00002;entitysegment::Customer { -> F}
//## Uses: <unnamed>%5EEAFBBB0096;configuration::ConfigurationRepository { -> F}

class DllExport WireTransfer : public totalscommand::FinancialSettlementFileVisitor  //## Inherits: <unnamed>%5EE20828018E
{
  //## begin WireTransfer%5EE208280185.initialDeclarations preserve=yes
  //## end WireTransfer%5EE208280185.initialDeclarations

  public:
    //## Constructors (generated)
      WireTransfer();

    //## Destructor (generated)
      virtual ~WireTransfer();


    //## Other Operations (specified)
      //## Operation: begin%5EE208280188
      //	Abstract function for any preprocessing that needs to
      //	take place before the processing of the data.
      bool begin ();

      //## Operation: email%605CABC4010C
      void email ();

      //## Operation: end%5EE208280189
      //	Abstract function for any postprocessing that needs to
      //	take place after the processing of the data.
      bool end ();

      //## Operation: wireReport%5EE216130382
      void wireReport ();

      //## Operation: visitFundsMovementAmount%5EE20828018B
      virtual void visitFundsMovementAmount (const string& strKey, totalscommand::FundsMovementAmount* pFundsMovementAmount);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ExportFile%5EE208280187
      void setExportFile (database::ExportFile*& value)
      {
        //## begin WireTransfer::setExportFile%5EE208280187.set preserve=no
        m_pExportFile = value;
        //## end WireTransfer::setExportFile%5EE208280187.set
      }


    // Additional Public Declarations
      //## begin WireTransfer%5EE208280185.public preserve=yes
      //## end WireTransfer%5EE208280185.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: ReconDate%5EE208280186
      //## begin WireTransfer::ReconDate%5EE208280186.attr preserve=no  protected: string {U} 
      string m_strReconDate;
      //## end WireTransfer::ReconDate%5EE208280186.attr

      //## begin WireTransfer::ExportFile%5EE208280187.attr preserve=no  public: database::ExportFile* {U} 0
      database::ExportFile* m_pExportFile;
      //## end WireTransfer::ExportFile%5EE208280187.attr

    // Additional Protected Declarations
      //## begin WireTransfer%5EE208280185.protected preserve=yes
      //## end WireTransfer%5EE208280185.protected

  private:
    // Additional Private Declarations
      //## begin WireTransfer%5EE208280185.private preserve=yes
      //## end WireTransfer%5EE208280185.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Totals Management::AutomatedFundsMovement_CAT::<unnamed>%5EE23D210158
      //## Role: WireTransfer::<m_hWireExportSegment>%5EE23D220260
      //## begin WireTransfer::<m_hWireExportSegment>%5EE23D220260.role preserve=no  public: WireExportSegment { -> VHgN}
      WireExportSegment m_hWireExportSegment;
      //## end WireTransfer::<m_hWireExportSegment>%5EE23D220260.role

      //## Association: Totals Management::AutomatedFundsMovement_CAT::<unnamed>%5EEAE97A02DB
      //## Role: WireTransfer::<m_hReport>%5EEAE97C0028
      //## begin WireTransfer::<m_hReport>%5EEAE97C0028.role preserve=no  public: command::Report { -> VHgN}
      command::Report m_hReport;
      //## end WireTransfer::<m_hReport>%5EEAE97C0028.role

    // Additional Implementation Declarations
      //## begin WireTransfer%5EE208280185.implementation preserve=yes
      map<string, WireExportSegment, less<string> > m_hResultSet;
      map<string, string, less <string> > m_hInterchange;
      ContactSegment m_hContactSegment;
      ContactSearchSegment m_hContactSearchSegment;
      GenericSegment m_hGenericSegment;
      //## end WireTransfer%5EE208280185.implementation
};

//## begin WireTransfer%5EE208280185.postscript preserve=yes
//## end WireTransfer%5EE208280185.postscript

//## begin module%5EE2088D0355.epilog preserve=yes
//## end module%5EE2088D0355.epilog


#endif
