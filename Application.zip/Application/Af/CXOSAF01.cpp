//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%392981F50012.cm preserve=no
//	$Date:   Aug 25 2020 02:15:24  $ $Author:   e1014059  $
//	$Revision:   1.28  $
//## end module%392981F50012.cm

//## begin module%392981F50012.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%392981F50012.cp

//## Module: CXOSAF01%392981F50012; Package body
//## Subsystem: AF%39297A540052
//## Source file: C:\Devel\Dn\Server\Application\AF\CXOSAF01.cpp

//## begin module%392981F50012.additionalIncludes preserve=no
//## end module%392981F50012.additionalIncludes

//## begin module%392981F50012.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#include "CXODIF03.hpp"
#ifndef CXOSTC10_h
#include "CXODTC10.hpp"
#endif
//## end module%392981F50012.includes

#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSTC14_h
#include "CXODTC14.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSAF01_h
#include "CXODAF01.hpp"
#endif


//## begin module%392981F50012.declarations preserve=no
//## end module%392981F50012.declarations

//## begin module%392981F50012.additionalDeclarations preserve=yes
//## end module%392981F50012.additionalDeclarations


// Class FundsMovement 

FundsMovement::FundsMovement()
  //## begin FundsMovement::FundsMovement%39297E0603B5_const.hasinit preserve=no
      : m_pExportFile(0)
  //## end FundsMovement::FundsMovement%39297E0603B5_const.hasinit
  //## begin FundsMovement::FundsMovement%39297E0603B5_const.initialization preserve=yes
  //## end FundsMovement::FundsMovement%39297E0603B5_const.initialization
{
  //## begin FundsMovement::FundsMovement%39297E0603B5_const.body preserve=yes
   memcpy(m_sID,"AF01",4);
  //## end FundsMovement::FundsMovement%39297E0603B5_const.body
}


FundsMovement::~FundsMovement()
{
  //## begin FundsMovement::~FundsMovement%39297E0603B5_dest.body preserve=yes
  //## end FundsMovement::~FundsMovement%39297E0603B5_dest.body
}



//## Other Operations (implementation)
void FundsMovement::visitFundsMovementAmount (const string& strKey, totalscommand::FundsMovementAmount* pFundsMovementAmount)
{
  //## begin FundsMovement::visitFundsMovementAmount%45B098240279.body preserve=yes
   if (strKey.substr(61,17) == "Switch Settlement"
      || (strKey.substr(1,11) == "99999999999" 
         && pFundsMovementAmount->getDebitAmount() == pFundsMovementAmount->getCreditAmount()))
      return;
   //skip wire line items
   if (strKey[59] == 'W')
      return;
   if (Extract::instance()->getCustomCode() == "FIS")
   {
      struct sKey *pKey = (struct sKey*)strKey.data();
      // move surcharge and case indicators in name field to match CMS ACH format
      if (memcmp(pKey->sName + 33, "-S", 2) == 0 || memcmp(pKey->sName + 33, "-A", 2) == 0)
         memcpy_s(pKey->sName + 20, 2, pKey->sName + 33, 2);
   }
   m_hResultSet.erase(m_hResultSet.begin(),m_hResultSet.end());
   m_hResultSet["RowID"] = "NET0000";
   m_hResultSet["Proc/Inst Name"] = strKey.substr(61,35);
   m_hResultSet["Proc ID"] = strKey.substr(12,8);
   m_hResultSet["Inst ID"] = strKey.substr(20,11);
   m_hResultSet["Bank ID"] = strKey.substr(1,11);
   m_hResultSet["Type"] = strKey.substr(0,1);
   char sAmount[PERCENTF];
   if (pFundsMovementAmount->getDebitAmount() >= pFundsMovementAmount->getCreditAmount())
   {
      m_hResultSet["NetDRCR"] = "DR";
      snprintf(sAmount,sizeof(sAmount),"%-18.0f",pFundsMovementAmount->getDebitAmount() - pFundsMovementAmount->getCreditAmount());
   }
   else
   {
      m_hResultSet["NetDRCR"] = "CR";
      snprintf(sAmount,sizeof(sAmount),"%-18.0f",pFundsMovementAmount->getCreditAmount() - pFundsMovementAmount->getDebitAmount());
   }
   m_hResultSet["Net"] = sAmount;
   m_hResultSet["Account Number"] = strKey.substr(31,28);
   m_hResultSet["Account Type"] = strKey.substr(59,2);
   map<string,string,less<string> >::iterator pResultSet;
   string strMessage;
   for (pResultSet = m_hResultSet.begin();pResultSet != m_hResultSet.end();pResultSet++)
   {
      strMessage = (*pResultSet).first;
      strMessage += "=";
      strMessage += (*pResultSet).second;
      Trace::put(strMessage.data(),strMessage.length());
   }
   process();
  //## end FundsMovement::visitFundsMovementAmount%45B098240279.body
}

// Additional Declarations
  //## begin FundsMovement%39297E0603B5.declarations preserve=yes
  //## end FundsMovement%39297E0603B5.declarations

//## begin module%392981F50012.epilog preserve=yes
//## end module%392981F50012.epilog
