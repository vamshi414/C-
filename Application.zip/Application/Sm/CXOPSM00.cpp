//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63EE669D02CD.cm preserve=no
//## end module%63EE669D02CD.cm

//## begin module%63EE669D02CD.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63EE669D02CD.cp

//## Module: CXOPSM00%63EE669D02CD; Package body
//## Subsystem: SM%63EE662703D8
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Sm\CXOPSM00.cpp

//## begin module%63EE669D02CD.additionalIncludes preserve=no
//## end module%63EE669D02CD.additionalIncludes

//## begin module%63EE669D02CD.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),ENVAR('TASK=SM'))
#endif
//## end module%63EE669D02CD.includes

#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSSI21_h
#include "CXODSI21.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOPSM00_h
#include "CXODSM00.hpp"
#endif


//## begin module%63EE669D02CD.declarations preserve=no
//## end module%63EE669D02CD.declarations

//## begin module%63EE669D02CD.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new SharedMemory();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%63EE669D02CD.additionalDeclarations


// Class SharedMemory 

SharedMemory::SharedMemory()
  //## begin SharedMemory::SharedMemory%63EE65CE01B3_const.hasinit preserve=no
  //## end SharedMemory::SharedMemory%63EE65CE01B3_const.hasinit
  //## begin SharedMemory::SharedMemory%63EE65CE01B3_const.initialization preserve=yes
  //## end SharedMemory::SharedMemory%63EE65CE01B3_const.initialization
{
  //## begin SharedMemory::SharedMemory%63EE65CE01B3_const.body preserve=yes
   memcpy(m_sID,"SM00",4);
  //## end SharedMemory::SharedMemory%63EE65CE01B3_const.body
}


SharedMemory::~SharedMemory()
{
  //## begin SharedMemory::~SharedMemory%63EE65CE01B3_dest.body preserve=yes
   delete FeeTable::instance();
  //## end SharedMemory::~SharedMemory%63EE65CE01B3_dest.body
}



//## Other Operations (implementation)
int SharedMemory::initialize ()
{
  //## begin SharedMemory::initialize%63EE66020076.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("DR","## SM00 START SM");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   new MasterPricingTable();
   Database::instance()->connect();
   return 0;
  //## end SharedMemory::initialize%63EE66020076.body
}

// Additional Declarations
  //## begin SharedMemory%63EE65CE01B3.declarations preserve=yes
  //## end SharedMemory%63EE65CE01B3.declarations

//## begin module%63EE669D02CD.epilog preserve=yes
//## end module%63EE669D02CD.epilog
