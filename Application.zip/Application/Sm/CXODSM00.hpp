//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%63EE669B00D5.cm preserve=no
//## end module%63EE669B00D5.cm

//## begin module%63EE669B00D5.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%63EE669B00D5.cp

//## Module: CXOPSM00%63EE669B00D5; Package specification
//## Subsystem: SM%63EE662703D8
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Sm\CXODSM00.hpp

#ifndef CXOPSM00_h
#define CXOPSM00_h 1

//## begin module%63EE669B00D5.additionalIncludes preserve=no
//## end module%63EE669B00D5.additionalIncludes

//## begin module%63EE669B00D5.includes preserve=yes
//## end module%63EE669B00D5.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: DataNavigator Foundation::SwitchInterface_CAT%358EB6E20186
namespace switchinterface {
class MasterPricingTable;
} // namespace switchinterface

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;

} // namespace database

//## begin module%63EE669B00D5.declarations preserve=no
//## end module%63EE669B00D5.declarations

//## begin module%63EE669B00D5.additionalDeclarations preserve=yes
//## end module%63EE669B00D5.additionalDeclarations


//## begin SharedMemory%63EE65CE01B3.preface preserve=yes
//## end SharedMemory%63EE65CE01B3.preface

//## Class: SharedMemory%63EE65CE01B3
//## Category: DataNavigator Foundation::Application::SharedMemory_CAT%63EE658203E5
//## Subsystem: SM%63EE662703D8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%63EE6AA20101;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%63EE6AB60066;monitor::UseCase { -> F}
//## Uses: <unnamed>%63EE6B02006F;switchinterface::MasterPricingTable { -> F}
//## Uses: <unnamed>%63EE6B2E00F7;database::Database { -> F}

class DllExport SharedMemory : public process::Application  //## Inherits: <unnamed>%63EE65ED00B2
{
  //## begin SharedMemory%63EE65CE01B3.initialDeclarations preserve=yes
  //## end SharedMemory%63EE65CE01B3.initialDeclarations

  public:
    //## Constructors (generated)
      SharedMemory();

    //## Destructor (generated)
      virtual ~SharedMemory();


    //## Other Operations (specified)
      //## Operation: initialize%63EE66020076
      virtual int initialize ();

    // Additional Public Declarations
      //## begin SharedMemory%63EE65CE01B3.public preserve=yes
      //## end SharedMemory%63EE65CE01B3.public

  protected:
    // Additional Protected Declarations
      //## begin SharedMemory%63EE65CE01B3.protected preserve=yes
      //## end SharedMemory%63EE65CE01B3.protected

  private:
    // Additional Private Declarations
      //## begin SharedMemory%63EE65CE01B3.private preserve=yes
      //## end SharedMemory%63EE65CE01B3.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin SharedMemory%63EE65CE01B3.implementation preserve=yes
      //## end SharedMemory%63EE65CE01B3.implementation

};

//## begin SharedMemory%63EE65CE01B3.postscript preserve=yes
//## end SharedMemory%63EE65CE01B3.postscript

//## begin module%63EE669B00D5.epilog preserve=yes
//## end module%63EE669B00D5.epilog


#endif
