//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3B1B9759034B.cm preserve=no
//	$Date:   Jun 25 2020 08:44:58  $ $Author:   e1009510  $
//	$Revision:   1.19  $
//## end module%3B1B9759034B.cm

//## begin module%3B1B9759034B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3B1B9759034B.cp

//## Module: CXOPCM00%3B1B9759034B; Package specification
//## Subsystem: CM%3B1B97250213
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Cm\CXODCM00.hpp

#ifndef CXOPCM00_h
#define CXOPCM00_h 1

//## begin module%3B1B9759034B.additionalIncludes preserve=no
//## end module%3B1B9759034B.additionalIncludes

//## begin module%3B1B9759034B.includes preserve=yes
//## end module%3B1B9759034B.includes

#ifndef CXOSPS03_h
#include "CXODPS03.hpp"
#endif

//## Modelname: Device Management::CanisterCommand_CAT%39A2966401E2
namespace canistercommand {
class DeviceViewCommand;
} // namespace canistercommand

//## Modelname: DataNavigator Foundation::EntityCommand_CAT%394E2706012A
namespace entitycommand {
class DeviceDetailListCommand;
class CourierRouteListCommand;
class CourierListCommand;
} // namespace entitycommand

//## Modelname: DataNavigator Foundation::ViewCommand_CAT%394E26F50072
namespace viewcommand {
class ReportMailCommand;
} // namespace viewcommand

//## Modelname: DataNavigator Foundation::UserCommand_CAT%394E26E302E3
namespace usercommand {
class AdminListCommand;
} // namespace usercommand

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: DataNavigator Foundation::SOAPCommand_CAT%4DC0633D0140
namespace soapcommand {
class ATMBalanceCommand;
class ATMListCommand;
} // namespace soapcommand

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

namespace IF {
class Queue;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

namespace database {
class CRTransactionTypeIndicator;

} // namespace database

//## begin module%3B1B9759034B.declarations preserve=no
//## end module%3B1B9759034B.declarations

//## begin module%3B1B9759034B.additionalDeclarations preserve=yes
//## end module%3B1B9759034B.additionalDeclarations


//## begin CashManager%3B17F9B30242.preface preserve=yes
//## end CashManager%3B17F9B30242.preface

//## Class: CashManager%3B17F9B30242
//	<body>
//	<title>CG
//	<h1>CM
//	<h2>AB
//	<p>
//	Cash Management helps you manage your ATM environment
//	more effectively.
//	The DataNavigator client application provides you with
//	near real-time cash positions for your devices and
//	allows you to manage your courier service.
//	<p>
//	You can:
//	<p>
//	<ul>
//	<li>View current cash positions at the device and
//	canister level in near real-time for each device.
//	<li>View canister totals for all devices affiliated with
//	a processor or institution.
//	<li>Determine low cash positions, cash flows, etc. for
//	all your devices.
//	<li>View administrative transactions (i.e., cash add)
//	performed at a specific device.
//	<li>Export the totals information to a spreadsheet.
//	<li>Assign a specific device(s) to a courier and/or
//	courier route.
//	<li>Define device maintenance schedules within your
//	institution for a specific courier office and courier
//	route.
//	<li>Input contact information for a specific courier
//	and/or courier route.
//	<li>View all courier assignment information for your
//	institution or for a specific device.
//	</ul>
//	<p>
//	Cash Management improves productivity and profitability,
//	increases efficiency and decreases the amount of cash
//	needed in a device by providing you the ability to
//	monitor low cash positions daily.
//	Cash Management increases efficiency therefore reducing
//	expenses by assisting you in effectively managing your
//	courier service.
//	</p>
//	<h3>System Flow
//	<p>
//	The DataNavigator server provides device cash management
//	services.
//	<p>
//	The Cash Manager service (<i>ca</i>CM) handles courier
//	related requests from end users.
//	Requests come through the Client Interface service
//	(<i>ca</i>CI01).
//	</p>
//	<img src=CXOCCM00.gif>
//	<p>
//	Refer to the <i>DataNavigator Client Device Services
//	User's Guide</i> for more information.
//	</p>
//	</body>
//	<body>
//	<title>OG
//	<h1>CM
//	<h2>AB
//	<h3>Purpose
//	<p>
//	The DataNavigator server provides device cash management
//	services.
//	<p>
//	The Cash Manager service (<i>ca</i>CM) handles courier
//	related requests from end users.
//	</p>
//	<img src=CXOOCM00.gif>
//	<h2>TS
//	<h3>Verification
//	<p>
//	The state of Cash Manager can be verified as follows:
//	<p>
//	<table>
//	<tr>
//	<th>Operator Console
//	<th>Symptom
//	<th>Resolution
//	<tr>
//	<td>Services
//	<td><i>ca</i>CM State: STOPPED or UNKNOWN
//	<td>Start the service
//	<tr>
//	<td>Clients : <i>customer</i> : Services
//	<td><i>ca</i>CM service not in the list
//	<td>Restart the service
//	<tr>
//	<td>Health : Client
//	<td>Any <i>ca</i>CM statistic with a non-zero Failure
//	count
//	<td>Trace the service to determine the cause
//	</table>
//	<p>
//	<h2>TS
//	<h3>DataNavigator Client
//	<p>
//	<b>Issue:</b>  End user reporting problems with services
//	provided by Cash Manager.
//	<p>
//	<b>Resolution:</b>  Refer to the Troubleshooting tips
//	for the Client Interface in the <i>DataNavigator Server
//	Operations Guide: Foundation</i> manual.
//	</p>
//	</body>
//## Category: Device Management::CashManager_CAT%3B17F94300DA
//## Subsystem: CM%3B1B97250213
//## Persistence: Transient
//## Cardinality/Multiplicity: 0..1



//## Uses: <unnamed>%3B17FB3C0222;IF::Message { -> F}
//## Uses: <unnamed>%3B17FB3E0167;monitor::UseCase { -> F}
//## Uses: <unnamed>%3B17FB4000DA;viewcommand::ReportMailCommand { -> F}
//## Uses: <unnamed>%3B17FB5001C5;database::Database { -> F}
//## Uses: <unnamed>%3B17FB6A00CB;reusable::Transaction { -> F}
//## Uses: <unnamed>%3B17FB890203;timer::Clock { -> F}
//## Uses: <unnamed>%3BCED053036B;IF::Queue { -> F}
//## Uses: <unnamed>%3C0E8281002D;IF::Extract { -> F}
//## Uses: <unnamed>%40AA3DB301F4;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%5C5ADA7802C6;database::CRTransactionTypeIndicator { -> F}

class CashManager : public process::ServiceApplication  //## Inherits: <unnamed>%3BCED033004E
{
  //## begin CashManager%3B17F9B30242.initialDeclarations preserve=yes
  //## end CashManager%3B17F9B30242.initialDeclarations

  public:
    //## Constructors (generated)
      CashManager();

    //## Destructor (generated)
      virtual ~CashManager();


    //## Other Operations (specified)
      //## Operation: initialize%3B17FA1D036B
      virtual int initialize ();

      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin CashManager%3B17F9B30242.public preserve=yes
      //## end CashManager%3B17F9B30242.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%3B17FA2300AB
      virtual int onMessage (Message& hMessage);

    // Additional Protected Declarations
      //## begin CashManager%3B17F9B30242.protected preserve=yes
      //## end CashManager%3B17F9B30242.protected

  private:
    // Additional Private Declarations
      //## begin CashManager%3B17F9B30242.private preserve=yes
      //## end CashManager%3B17F9B30242.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Device Management::CashManager_CAT::<unnamed>%3B17FAE40167
      //## Role: CashManager::<m_pDeviceViewCommand>%3B17FAE403D8
      //## begin CashManager::<m_pDeviceViewCommand>%3B17FAE403D8.role preserve=no  public: canistercommand::DeviceViewCommand { -> RFHgN}
      canistercommand::DeviceViewCommand *m_pDeviceViewCommand;
      //## end CashManager::<m_pDeviceViewCommand>%3B17FAE403D8.role

      //## Association: Device Management::CashManager_CAT::<unnamed>%3B17FAE6032C
      //## Role: CashManager::<m_pAdminListCommand>%3B17FAE70213
      //## begin CashManager::<m_pAdminListCommand>%3B17FAE70213.role preserve=no  public: usercommand::AdminListCommand { -> RFHgN}
      usercommand::AdminListCommand *m_pAdminListCommand;
      //## end CashManager::<m_pAdminListCommand>%3B17FAE70213.role

      //## Association: Device Management::CashManager_CAT::<unnamed>%3B17FAE8033C
      //## Role: CashManager::<m_pCourierListCommand>%3B17FAEA000F
      //## begin CashManager::<m_pCourierListCommand>%3B17FAEA000F.role preserve=no  public: entitycommand::CourierListCommand { -> RFHgN}
      entitycommand::CourierListCommand *m_pCourierListCommand;
      //## end CashManager::<m_pCourierListCommand>%3B17FAEA000F.role

      //## Association: Device Management::CashManager_CAT::<unnamed>%3B17FAEF02EE
      //## Role: CashManager::<m_pCourierRouteListCommand>%3B17FAF0032C
      //## begin CashManager::<m_pCourierRouteListCommand>%3B17FAF0032C.role preserve=no  public: entitycommand::CourierRouteListCommand { -> RFHgN}
      entitycommand::CourierRouteListCommand *m_pCourierRouteListCommand;
      //## end CashManager::<m_pCourierRouteListCommand>%3B17FAF0032C.role

      //## Association: Device Management::CashManager_CAT::<unnamed>%3B17FAF201D4
      //## Role: CashManager::<m_pDeviceDetailListCommand>%3B17FAF30261
      //## begin CashManager::<m_pDeviceDetailListCommand>%3B17FAF30261.role preserve=no  public: entitycommand::DeviceDetailListCommand { -> RFHgN}
      entitycommand::DeviceDetailListCommand *m_pDeviceDetailListCommand;
      //## end CashManager::<m_pDeviceDetailListCommand>%3B17FAF30261.role

      //## Association: Device Management::CashManager_CAT::<unnamed>%5C5AD934007B
      //## Role: CashManager::<m_pATMBalanceCommand>%5C5AD9340355
      //## begin CashManager::<m_pATMBalanceCommand>%5C5AD9340355.role preserve=no  public: soapcommand::ATMBalanceCommand { -> RFHgN}
      soapcommand::ATMBalanceCommand *m_pATMBalanceCommand;
      //## end CashManager::<m_pATMBalanceCommand>%5C5AD9340355.role

      //## Association: Device Management::CashManager_CAT::<unnamed>%5D38473A0266
      //## Role: CashManager::<m_pATMListCommand>%5D38473B017F
      //## begin CashManager::<m_pATMListCommand>%5D38473B017F.role preserve=no  public: soapcommand::ATMListCommand { -> RFHgN}
      soapcommand::ATMListCommand *m_pATMListCommand;
      //## end CashManager::<m_pATMListCommand>%5D38473B017F.role

    // Additional Implementation Declarations
      //## begin CashManager%3B17F9B30242.implementation preserve=yes
      //## end CashManager%3B17F9B30242.implementation

};

//## begin CashManager%3B17F9B30242.postscript preserve=yes
//## end CashManager%3B17F9B30242.postscript

//## begin module%3B1B9759034B.epilog preserve=yes
//## end module%3B1B9759034B.epilog


#endif
