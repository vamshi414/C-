//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3B1B976F000F.cm preserve=no
//	$Date:   Jul 23 2020 13:46:00  $ $Author:   e1009652  $
//	$Revision:   1.33  $
//## end module%3B1B976F000F.cm

//## begin module%3B1B976F000F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3B1B976F000F.cp

//## Module: CXOPCM00%3B1B976F000F; Package body
//## Subsystem: CM%3B1B97250213
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Cm\CXOPCM00.cpp

//## begin module%3B1B976F000F.additionalIncludes preserve=no
//## end module%3B1B976F000F.additionalIncludes

//## begin module%3B1B976F000F.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),ENVAR('TASK=CM'))
#endif
#include "CXODNS40.hpp"
//## end module%3B1B976F000F.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSVC17_h
#include "CXODVC17.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSDB16_h
#include "CXODDB16.hpp"
#endif
#ifndef CXOSCC01_h
#include "CXODCC01.hpp"
#endif
#ifndef CXOSUC12_h
#include "CXODUC12.hpp"
#endif
#ifndef CXOSNC13_h
#include "CXODNC13.hpp"
#endif
#ifndef CXOSNC14_h
#include "CXODNC14.hpp"
#endif
#ifndef CXOSNC16_h
#include "CXODNC16.hpp"
#endif
#ifndef CXOSSX41_h
#include "CXODSX41.hpp"
#endif
#ifndef CXOSSX34_h
#include "CXODSX34.hpp"
#endif
#ifndef CXOPCM00_h
#include "CXODCM00.hpp"
#endif


//## begin module%3B1B976F000F.declarations preserve=no
//## end module%3B1B976F000F.declarations

//## begin module%3B1B976F000F.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new CashManager();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%3B1B976F000F.additionalDeclarations


// Class CashManager

CashManager::CashManager()
  //## begin CashManager::CashManager%3B17F9B30242_const.hasinit preserve=no
      : m_pDeviceViewCommand(0),
        m_pAdminListCommand(0),
        m_pCourierListCommand(0),
        m_pCourierRouteListCommand(0),
        m_pDeviceDetailListCommand(0),
        m_pATMBalanceCommand(0),
        m_pATMListCommand(0)
  //## end CashManager::CashManager%3B17F9B30242_const.hasinit
  //## begin CashManager::CashManager%3B17F9B30242_const.initialization preserve=yes
  //## end CashManager::CashManager%3B17F9B30242_const.initialization
{
  //## begin CashManager::CashManager%3B17F9B30242_const.body preserve=yes
   memcpy(m_sID,"CM00",4);
  //## end CashManager::CashManager%3B17F9B30242_const.body
}


CashManager::~CashManager()
{
  //## begin CashManager::~CashManager%3B17F9B30242_dest.body preserve=yes
   delete m_pATMBalanceCommand;
   delete m_pATMListCommand;
   delete m_pDeviceViewCommand;
   delete m_pAdminListCommand;
   delete m_pCourierListCommand;
   delete m_pCourierRouteListCommand;
   delete m_pDeviceDetailListCommand;
  //## end CashManager::~CashManager%3B17F9B30242_dest.body
}



//## Other Operations (implementation)
int CashManager::initialize ()
{
  //## begin CashManager::initialize%3B17FA1D036B.body preserve=yes
   new dnplatform::DNPlatform();
   int i = ServiceApplication::initialize();
   UseCase hUseCase("CLIENT","## CM00 START CM");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   entitysegment::SwitchBusinessDay::instance();
   database::CRTransactionTypeIndicator::instance();
   ReportMailCommand::instance(0);
   m_pAdminListCommand = new AdminListCommand(ReportMailCommand::instance());
   m_pDeviceViewCommand = new DeviceViewCommand(m_pAdminListCommand);
   m_pCourierListCommand = new CourierListCommand(m_pDeviceViewCommand);
   m_pCourierRouteListCommand = new CourierRouteListCommand(m_pCourierListCommand);
   m_pDeviceDetailListCommand = new DeviceDetailListCommand(m_pCourierRouteListCommand);
   m_pATMListCommand = new soapcommand::ATMListCommand(m_pDeviceDetailListCommand);
   m_pATMBalanceCommand = new soapcommand::ATMBalanceCommand(m_pATMListCommand);
   Database::instance()->attach(this);
   Database::instance()->connect();
   Queue::attach("@##SERVER",Queue::CX_DISTRIBUTION_QUEUE);
   Database::instance()->commit();
   return 0;
  //## end CashManager::initialize%3B17FA1D036B.body
}

int CashManager::onMessage (Message& hMessage)
{
  //## begin CashManager::onMessage%3B17FA2300AB.body preserve=yes
   Transaction::instance()->begin();
   string strTimeStamp(Clock::instance()->getYYYYMMDDHHMMSS(true));
   Transaction::instance()->setTimeStamp(strTimeStamp += "00");
   m_pATMBalanceCommand->update(Message::instance(Message::INBOUND));
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      Database::instance()->rollback();
   else
      Database::instance()->commit();
   Transaction::instance()->commit();
   idle();
   return 0;
  //## end CashManager::onMessage%3B17FA2300AB.body
}

// Additional Declarations
  //## begin CashManager%3B17F9B30242.declarations preserve=yes
void CashManager::update(Subject* pSubject)
{
   process::ServiceApplication::update(pSubject);
}
  //## end CashManager%3B17F9B30242.declarations

//## begin module%3B1B976F000F.epilog preserve=yes
//## end module%3B1B976F000F.epilog
