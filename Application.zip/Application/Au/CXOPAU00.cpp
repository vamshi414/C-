//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4396E638032C.cm preserve=no
//	$Date:   Jan 07 2019 15:27:48  $ $Author:   e1009839  $
//	$Revision:   1.44  $
//## end module%4396E638032C.cm

//## begin module%4396E638032C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4396E638032C.cp

//## Module: CXOPAU00%4396E638032C; Package body
//## Subsystem: AU%4396E60F03B9
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Application\Au\CXOPAU00.cpp

//## begin module%4396E638032C.additionalIncludes preserve=no
//## end module%4396E638032C.additionalIncludes

//## begin module%4396E638032C.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#include <algorithm>
#include "CXODDB25.hpp"
#include "CXODDB16.hpp"
#include "CXODNS10.hpp"
#include "CXODIF03.hpp"
#include "CXODMN02.hpp"
#include "CXODDB50.hpp"
#include "CXODNS44.hpp"
#include "CXODNS45.hpp"
#include "CXODTC66.hpp"
#ifndef CXOSST88_h
#include "CXODST88.hpp"
#endif
//## end module%4396E638032C.includes

#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSRF01_h
#include "CXODRF01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSDB06_h
#include "CXODDB06.hpp"
#endif
#ifndef CXOSRF19_h
#include "CXODRF19.hpp"
#endif
#ifndef CXOSUA03_h
#include "CXODUA03.hpp"
#endif
#ifndef CXOSEC01_h
#include "CXODEC01.hpp"
#endif
#ifndef CXOPAU00_h
#include "CXODAU00.hpp"
#endif


//## begin module%4396E638032C.declarations preserve=no
//## end module%4396E638032C.declarations

//## begin module%4396E638032C.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new AutoReconciliation();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%4396E638032C.additionalDeclarations


// Class AutoReconciliation 

AutoReconciliation::AutoReconciliation()
  //## begin AutoReconciliation::AutoReconciliation%4396E5BC030D_const.hasinit preserve=no
      : m_iItems(0),
        m_iLimit(99),
        m_pBegin(0),
        m_pEnd(0),
        m_pReconciliationFile(0),
        m_pReconTransitionCommand(0)
  //## end AutoReconciliation::AutoReconciliation%4396E5BC030D_const.hasinit
  //## begin AutoReconciliation::AutoReconciliation%4396E5BC030D_const.initialization preserve=yes
  //## end AutoReconciliation::AutoReconciliation%4396E5BC030D_const.initialization
{
  //## begin AutoReconciliation::AutoReconciliation%4396E5BC030D_const.body preserve=yes
   memcpy(m_sID,"AU00",4);
   m_pCursor = m_hFiles.end();
  //## end AutoReconciliation::AutoReconciliation%4396E5BC030D_const.body
}


AutoReconciliation::~AutoReconciliation()
{
  //## begin AutoReconciliation::~AutoReconciliation%4396E5BC030D_dest.body preserve=yes
   delete m_pEnd;
   delete m_pBegin;
  //## end AutoReconciliation::~AutoReconciliation%4396E5BC030D_dest.body
}



//## Other Operations (implementation)
int AutoReconciliation::initialize ()
{
  //## begin AutoReconciliation::initialize%4396E5E700AB.body preserve=yes
   new dnplatform::DNPlatform();
   int i = Application::initialize();
   UseCase hUseCase("AUTO","## AU00 START AU");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   database::DataModel::instance();
   database::CRTransactionTypeIndicator::instance();
   entitysegment::Customer::instance();
   entitysegment::SwitchBusinessDay::instance();
   entitysegment::Processor::instance();
   entitysegment::Institution::instance();
   m_pBegin = new GlobalContext("##BEGIN");
   m_pBegin->attach(this);
   m_pEnd = new GlobalContext("##END");
   m_pEnd->attach(this);
   Database::instance()->connect();
   TotalsVersionMonitor::instance();
   if (entitysegment::Customer::instance()->getTotalsVersion() == 2)
      new totalscommand::FinancialSum;
   Query hQuery;
   hQuery.setBasicPredicate("AU_ENTITY","TASKID","=",name().c_str());
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   if (!pDeleteStatement->execute(hQuery))
   {
      UseCase::setSuccess(false);
      return -1;
   }
   i = 0;
   string strRecord;
   while (IF::Extract::instance()->getRecord(i++,strRecord))
   {
      if (strRecord.length() > 19
         && strRecord.substr(0,16) == "DSPEC   AULIMIT ")
      {
         m_iLimit = atoi(strRecord.substr(16,4).c_str());
         if (m_iLimit < 1 || m_iLimit > 99)
            m_iLimit = 99;
         Count::set("AUTO","## AU11 DELAY FILE START","ITEMS",m_iLimit);
      }
      else
      if (strRecord.length() > 16
         && strRecord.substr(0,16) == "DSPEC   RECON   ")
      {
         vector<string> hTokens;
         int i = Buffer::parse(strRecord.substr(16)," ",hTokens);
         if (i >= 4
            && ReconciliationFileFactory::instance()->verify(hTokens[1]))
         {
            map<string, reconciliationfile::ReconciliationFile>::iterator pCursor;
            pCursor = m_hFiles.find(hTokens[0]);
            if (pCursor == m_hFiles.end())
            {
               reconciliationfile::ReconciliationFile hReconciliationFile;
               hReconciliationFile.setClassName(hTokens[1]);
               hReconciliationFile.setGENNAM(hTokens[0]);
               hReconciliationFile.addEntity(hTokens[2],hTokens[3]);
               if (i >= 6 && hTokens[4] != "UC1" && hTokens[4] != "UC2")
                  hReconciliationFile.addEntity(hTokens[4],hTokens[5]);
               m_hFiles.insert(map<string, reconciliationfile::ReconciliationFile >::value_type(hTokens[0],hReconciliationFile));
               pCursor = m_hFiles.find(hTokens[0]);
            }
            else
            {
               (*pCursor).second.addEntity(hTokens[2],hTokens[3]);
               if (i >= 6 && hTokens[4] != "UC1" && hTokens[4] != "UC2")
                  (*pCursor).second.addEntity(hTokens[4],hTokens[5]);
            }
            vector<string>::iterator p;
            p = find(hTokens.begin(),hTokens.end(),"UC1");
            if (p != hTokens.end() && p+1 != hTokens.end())
               (*pCursor).second.setRepositoryUseCase(*(p+1));

            p = find(hTokens.begin(),hTokens.end(),"UC2");
            if (p != hTokens.end() && p+1 != hTokens.end())
               (*pCursor).second.setTotalsCategoryUseCase(*(p+1));
         }
      }
   }
   if (!m_hFiles.empty())
      m_pCursor = m_hFiles.begin();
   m_pReconTransitionCommand = new reconciliationuserinterface::ReconTransitionCommand();
   m_pCaseCreateCommand = new CaseCreateCommand();
   m_pReconTransitionCommand->setCaseCreateCommand(m_pCaseCreateCommand);
   EMSRulesEngine::instance();
   hQuery.reset();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   string strCustomerID;
   Extract::instance()->getSpec("CUSTOMER",strCustomerID);
   entitysegment::ContactSegment::instance(entitysegment::ContactSegment::SENDER)->bind(hQuery);
   hQuery.setQualifier("QUALIFY","CONTACT_TYPE");
   hQuery.setQualifier("QUALIFY","STS_CUSTOMER");
   hQuery.join("CONTACT_TYPE","INNER","STS_CUSTOMER","CONTACT_ID");
   hQuery.setBasicPredicate("STS_CUSTOMER","CUST_ID","=",strCustomerID.c_str());
   hQuery.setBasicPredicate("STS_CUSTOMER","CC_CHANGE_GRP_ID","IS NULL");
   hQuery.setBasicPredicate("STS_CUSTOMER","CC_STATE","=","A");
   hQuery.setBasicPredicate("CONTACT_TYPE","CONTACT_TYPE","=","AR");
   pSelectStatement->execute(hQuery);
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
   {
      Database::instance()->rollback();
      UseCase::setSuccess(false);
      return -1;
   }
   Database::instance()->commit();
   m_hQuery.attach(this);
   Database::instance()->attach(this);
   MinuteTimer::instance()->attach(this);
   return 0;
  //## end AutoReconciliation::initialize%4396E5E700AB.body
}

int AutoReconciliation::onQuiesce ()
{
  //## begin AutoReconciliation::onQuiesce%5834B7F400BD.body preserve=yes
   setQueueWaitOption(true);
   return Application::onQuiesce();
  //## end AutoReconciliation::onQuiesce%5834B7F400BD.body
}

int AutoReconciliation::onReset (Message& hMessage)
{
  //## begin AutoReconciliation::onReset%43A0779B01F4.body preserve=yes
   if (hMessage.context().length() >= 13
      && memcmp((char*)hMessage.context() + 8,"FORCE",5) == 0)
   {
      string strFile((char*)hMessage.context(),6);
      map<string,reconciliationfile::ReconciliationFile>::iterator p = m_hFiles.find(strFile);
      if (p != m_hFiles.end())
      {
         (*p).second.setForce(true);
         Console::display( "ST149",strFile.c_str());
      }
   }
   if (hMessage.context().length() >= 12
      && memcmp((char*)hMessage.context() + 8,"UNDO",4) == 0)
   {
      string strFile((char*)hMessage.context(),6);
      bool bGDG = (hMessage.context().length() >= 19
         && memcmp((char*)hMessage.context() + 16,"GDG",3) == 0);
      reconciliationfile::ReconciliationFile::undo(strFile,bGDG);
   }
   if (hMessage.context().length() >= 9
      && memcmp((char*)hMessage.context(),"AULIMIT-",8) == 0)
   {
      m_iLimit = atoi((char*)hMessage.context().subString(9));
      if (m_iLimit < 1 || m_iLimit > 99)
         m_iLimit = 99;
      Count::set("AUTO","## AU11 DELAY FILE START","ITEMS",m_iLimit);
   }
   if (!m_hFiles.empty())
      setQueueWaitOption(false);
   return 0;
  //## end AutoReconciliation::onReset%43A0779B01F4.body
}

int AutoReconciliation::onResume (Message& hMessage)
{
  //## begin AutoReconciliation::onResume%4396E5F0001F.body preserve=yes
   {
      Query hQuery;
      string strAU_FILE_NAME;
      hQuery.bind("AU_FILE_CONTROL","AU_FILE_NAME",reusable::Column::STRING,&strAU_FILE_NAME);
      hQuery.setBasicPredicate("AU_FILE_CONTROL","AU_STATE","=","0");
      hQuery.setBasicPredicate("AU_FILE_CONTROL","TASK_RECONCILED","=",name().c_str());
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (pSelectStatement->execute(hQuery) == false)
      {
         setQueueWaitOption(true);
         Database::instance()->commit();
         return true;
      }
      if (pSelectStatement->getRows() == 0)
      {
         int iCount = 0;
         hQuery.reset();
         hQuery.bind("AU_FILE_CONTROL","*",reusable::Column::LONG,&iCount,0,"COUNT");
         hQuery.setBasicPredicate("AU_FILE_CONTROL","AU_STATE","=","0");
         if (pSelectStatement->execute(hQuery) == false)
         {
            setQueueWaitOption(true);
            Database::instance()->commit();
            return true;
         }
         if (m_iLimit <= iCount)
         {
            setQueueWaitOption(true);
            Database::instance()->commit();
            UseCase hUseCase("AUTO","## AU00 DELAY FILE START");
            return true;
         }
      }
      Database::instance()->commit();
   }
   if (!m_pReconciliationFile)
   {
      m_pReconciliationFile = ReconciliationFileFactory::instance()->create((*m_pCursor).second.getClassName());
      *m_pReconciliationFile = (*m_pCursor).second;
      int iRC = m_pReconciliationFile->initialize();
      if (iRC <= 0
         || Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      {
         if (iRC < 0
            || Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
            Database::instance()->rollback();
         else
            Database::instance()->commit();
         delete m_pReconciliationFile;
         m_pReconciliationFile = 0;
         if (++m_pCursor == m_hFiles.end())
         {
            m_pCursor = m_hFiles.begin();
            setQueueWaitOption(true);
         }
         return true;
      }
      Database::instance()->commit();
      m_pReconciliationFile->setForce(false);
   }
   string strUseCase ("## AU00 READ RECON FILE");
   if (m_pReconciliationFile->getRepositoryUseCase().length() >= 4)
      strUseCase.replace(3,4,m_pReconciliationFile->getRepositoryUseCase().data(),4);
   UseCase hUseCase("AUTO",strUseCase.c_str());
   if (m_pReconciliationFile->onResume())
   {
      if (Extract::instance()->getCustomCode() == "MPS"
         && UseCase::getSuccess())
      {
         ExportFile::reschedule("MEROPN",entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(0));
         if (m_pReconciliationFile->getENTITY_ID(0) == "DEBIT")
         {
            ExportFile hExportFile("RECONX","IP","DEBIT",SwitchBusinessDay::instance()->getDATE_RECON(0),"240000");
            hExportFile.setDX_STATE("FW");
            hExportFile.setTSTAMP_INITIATED(SwitchBusinessDay::instance()->getTSTAMP_END(0));
            hExportFile.trigger();
         }
      }
      delete m_pReconciliationFile;
      m_pReconciliationFile = 0;
      if (++m_pCursor == m_hFiles.end())
      {
         m_pCursor = m_hFiles.begin();
         if (m_iItems == 0)
            setQueueWaitOption(true);
         else
            m_iItems = 0;
      }
   }
   m_iItems += hUseCase.getItems();
   return 0;
  //## end AutoReconciliation::onResume%4396E5F0001F.body
}

void AutoReconciliation::update (Subject* pSubject)
{
  //## begin AutoReconciliation::update%4396E5F40271.body preserve=yes
   if (pSubject == MinuteTimer::instance())
   {
      if (name().find("01") != string::npos)
      {
         m_hQuery.reset();
         m_hQuery.setRetainCursor(true);
         m_hQuery.bind("AU_TRAN","AU_TRAN_ID",reusable::Column::LONG,&(m_hReconciliationState.iAU_TRAN_ID));
         m_hQuery.bind("AU_TRAN","AU_FILE_ID",reusable::Column::LONG,&(m_hReconciliationState.iAU_FILE_ID));
         m_hQuery.bind("AU_TRAN","RECON_STATUS",reusable::Column::SHORT,&(m_hReconciliationState.iOld_RECON_STATUS));
         m_hQuery.setBasicPredicate("AU_TRAN","RECON_STATUS","IN","(904,905,921)");
         auto_ptr<SelectStatement>pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
         if (!pSelectStatement->execute(m_hQuery) || m_hQuery.getAbort() == true )
         {
            Database::instance()->rollback();
            if (m_hReconciliationState.iOld_RECON_STATUS != 921)
            {
               m_hReconciliationState.iRECON_STATUS = (m_hReconciliationState.iOld_RECON_STATUS == 904 ? 930 : 931);
               if (m_pReconTransitionCommand->impactTotals(m_hReconciliationState))
                  Database::instance()->commit();
               else
                  Database::instance()->rollback();
            }
            UseCase::setSuccess(false);
            return;
         }
      }
      if (!m_hFiles.empty())
         setQueueWaitOption(false);
   }
   if (pSubject == &m_hQuery)
   {
      Transaction::instance()->begin();
      Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
      string strCustomer;
      Extract::instance()->getSpec("CUSTOMER",strCustomer);
      Transaction::instance()->setCustomer(strCustomer);
      EMSRulesEngine::instance()->reset();
      if (m_pReconTransitionCommand->processException(m_hReconciliationState))
         Database::instance()->commit();
      else
         m_hQuery.setAbort(true);
      return;
   }
   if (pSubject == m_pBegin
      || pSubject == Database::instance())
   {
      string strYYYYMM;
      m_pBegin->get(strYYYYMM,'F');
      reconciliationfile::ReconciliationFile::setBegin(strYYYYMM);
      Database::instance()->commit();
      if (pSubject == m_pBegin)
         return;
   }
   if (pSubject == m_pEnd
      || pSubject == Database::instance())
   {
      string strYYYYMM;
      m_pEnd->get(strYYYYMM,'F');
      reconciliationfile::ReconciliationFile::setEnd(strYYYYMM);
      Database::instance()->commit();
      if (pSubject == m_pEnd)
         return;
   }
   Application::update(pSubject);
  //## end AutoReconciliation::update%4396E5F40271.body
}

// Additional Declarations
  //## begin AutoReconciliation%4396E5BC030D.declarations preserve=yes
  //## end AutoReconciliation%4396E5BC030D.declarations

//## begin module%4396E638032C.epilog preserve=yes
//## end module%4396E638032C.epilog
