//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4396E63700FA.cm preserve=no
//	$Date:   Jan 07 2019 15:27:48  $ $Author:   e1009839  $
//	$Revision:   1.17  $
//## end module%4396E63700FA.cm

//## begin module%4396E63700FA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4396E63700FA.cp

//## Module: CXOPAU00%4396E63700FA; Package specification
//## Subsystem: AU%4396E60F03B9
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Application\Au\CXODAU00.hpp

#ifndef CXOPAU00_h
#define CXOPAU00_h 1

//## begin module%4396E63700FA.additionalIncludes preserve=no
//## end module%4396E63700FA.additionalIncludes

//## begin module%4396E63700FA.includes preserve=yes
#include <map>
//## end module%4396E63700FA.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSST48_h
#include "CXODST48.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
class CaseCreateCommand;
} // namespace emscommand

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSRulesEngine;
} // namespace ems

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Console;
} // namespace IF

namespace reusable {
class Buffer;
class Transaction;
} // namespace reusable

namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class MinuteTimer;
} // namespace timer

namespace database {
class GlobalContext;
class Context;
class DatabaseFactory;
} // namespace database

//## Modelname: Reconciliation::ReconciliationFile_CAT%439754C1037A
namespace reconciliationfile {
class ReconciliationFile;
class ReconciliationFileFactory;
} // namespace reconciliationfile

//## Modelname: Reconciliation::ReconciliationUserInterface_CAT%4F5724BB00C4
namespace reconciliationuserinterface {
class ReconTransitionCommand;

} // namespace reconciliationuserinterface

//## begin module%4396E63700FA.declarations preserve=no
//## end module%4396E63700FA.declarations

//## begin module%4396E63700FA.additionalDeclarations preserve=yes
//## end module%4396E63700FA.additionalDeclarations


//## begin AutoReconciliation%4396E5BC030D.preface preserve=yes
//## end AutoReconciliation%4396E5BC030D.preface

//## Class: AutoReconciliation%4396E5BC030D
//	<body>
//	<title>CG
//	<h1>AU
//	<h2>AB
//	<p>
//	The Auto Reconciliation service processes transaction
//	logs from external endpoints.
//	The file must contain all transactions from the endpoint
//	business day (typically a 24 hour period).
//	The following file formats are accepted:
//	<ol>
//	<li>BAMSIC - Bank of America Transaction Interchange
//	Report
//	<li>TXNACT - FIS Transaction Activity
//	<li>TXNATH - FIS Transaction Activity (ATH (A Toda Hora)
//	Interbank Network Activity transactions)
//	<li>TXNMCI - FIS Transaction Activity (MasterCard IPM
//	Clearing transactions)
//	<li>TXNVNT - FIS Transaction Activity (VISA BASE II
//	Clearing transactions)
//	<li>VNTSMS - FIS Transaction Activity (VISA SMS
//	transactions)
//	</ol>
//	Auto Reconciliation also accepts the following files
//	that are used to update individual transactions:
//	<ol>
//	<li>BAMSRC - Bank of America Transaction Reclass Report
//	<li>BAMSRJ - Bank of America Reject Detail Report
//	</ol>
//	<h3>System Flow
//	<p>
//	The reconciliation process begins when the Auto
//	Reconciliation service (<i>ca</i>AU01) detects a file in
//	one of the configured RF<i>nnnn</i>\Pending folders.
//	The Auto Reconciliation service retrieves the
//	transactions from the FIN_L<i>yyyymm</i> and FIN_
//	RECORD<i>yyyymm</i> tables for the business period
//	corresponding to the transactions in the transaction log.
//	Two export result sets are produced in the DX_DATA_
//	CONTROL and DX_DATA_<i>yyyymmdd</i> tables:
//	<ul>
//	<li>OEAU05 - file preview report
//	<li>RF<i>nnnn</i> - audit report
//	<li>TXNARE - auto reconciliation exceptions (in the
//	standard FIS Transaction Activity format)
//	</ul>
//	<p>
//	Information for each file processed and the state of any
//	detected exceptions are recorded in the following tables:
//	<ul>
//	<li>AU_FILE_CONTROL
//	<li>AU_TRAN
//	<li>AU_TRAN_STATE
//	<li>AU_TOTAL
//	<li>AU_LATE_TRAN
//	<li>AU_DATA_CHG
//	</ul>
//	<p>
//	At the end of the reconciliation process, the
//	transaction log is moved from the Pending folder to the
//	Complete folder.
//	</p>
//	<img src=CXOCAU00.gif>
//	</body>
//	<body>
//	<title>OG
//	<h1>AU
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The Auto Reconciliation service ...
//	</p>
//	<img src=CXOOAU00.gif>
//	</body>
//## Category: Reconciliation::AutoReconciliation_CAT%4397382B03B9
//## Subsystem: AU%4396E60F03B9
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%43974AEF0157;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%43974B0C02BF;monitor::UseCase { -> F}
//## Uses: <unnamed>%43974B1D002E;database::Database { -> F}
//## Uses: <unnamed>%43974C4700EA;IF::Message { -> F}
//## Uses: <unnamed>%439F2AC1037A;reconciliationfile::ReconciliationFileFactory { -> F}
//## Uses: <unnamed>%43C0085A00BB;IF::Extract { -> F}
//## Uses: <unnamed>%4562091403D8;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%45A2493302E1;IF::Console { -> F}
//## Uses: <unnamed>%494A51B50196;reusable::Buffer { -> F}
//## Uses: <unnamed>%4E7998E40331;database::Context { -> F}
//## Uses: <unnamed>%4F7040C702D9;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4F70410F03C4;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%4F70412302F9;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%4F7056C9028C;settlement::ReconciliationTransaction { -> }
//## Uses: <unnamed>%50616D47019A;timer::Clock { -> F}
//## Uses: <unnamed>%50616D890227;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%50616DD400C0;reusable::Transaction { -> F}
//## Uses: <unnamed>%511E83CB01C3;entitysegment::Customer { -> F}

class DllExport AutoReconciliation : public process::Application  //## Inherits: <unnamed>%4396E5DB035B
{
  //## begin AutoReconciliation%4396E5BC030D.initialDeclarations preserve=yes
  //## end AutoReconciliation%4396E5BC030D.initialDeclarations

  public:
    //## Constructors (generated)
      AutoReconciliation();

    //## Destructor (generated)
      virtual ~AutoReconciliation();


    //## Other Operations (specified)
      //## Operation: initialize%4396E5E700AB
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AU
      //	<h2>FI
      //	<!-- AutoReconciliation::initialize Preconditions -->
      //	<h3>Extract File
      //	<p>
      //	Auto Reconciliation accepts any number of input
      //	transaction logs.
      //	Use the CR Client for the DataNavigator Server to define
      //	each input file.
      //	Site Specification data is used to further define each
      //	file to indicate the type of file and the associated
      //	issuer processor (IP) and/or acquirer processor (AP).
      //	Files can also be configured for issuer processor group
      //	(IG) and/or acquirer processor group (AG).
      //	<p>
      //	Here is an example extract:
      //	<pre>
      //	DMISC                                         00000000
      //	00000000 00000000
      //	DUSER   AU
      //	DFILES  RF0001  CDNACMEP\RF0001\Pending\*.txt
      //	DFILES  RF0002  CDNACMEP\RF0002\Pending\*.txt
      //	DFILES  RF0003  CDNACMEP\RF0003\Pending\*.txt
      //	DFILES  RF0004  CDNACMEP\RF0004\Pending\*.txt
      //	DSPEC   RECON   RF0001 TXNACT IP PRC001
      //	DSPEC   RECON   RF0002 TXNACT IP PRC002
      //	DSPEC   RECON   RF0003 TXNACT AP INT001
      //	DSPEC   RECON   RF0003 TXNACT AP INT002
      //	DSPEC   RECON   RF0004 TXNACT AP INT003 IP PRC003
      //	</pre>
      //	<p>
      //	File definitions are in the Task Configuration folder in
      //	the CR Client for the DataNavigator Server.
      //	Custom Table Data is in the Custom Tables folder.
      //	</body>
      virtual int initialize ();

      //## Operation: onQuiesce%5834B7F400BD
      virtual int onQuiesce ();

      //## Operation: update%4396E5F40271
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin AutoReconciliation%4396E5BC030D.public preserve=yes
      //## end AutoReconciliation%4396E5BC030D.public

  protected:

    //## Other Operations (specified)
      //## Operation: onReset%43A0779B01F4
      virtual int onReset (Message& hMessage);

      //## Operation: onResume%4396E5F0001F
      virtual int onResume (Message& hMessage);

    // Additional Protected Declarations
      //## begin AutoReconciliation%4396E5BC030D.protected preserve=yes
      //## end AutoReconciliation%4396E5BC030D.protected

  private:
    // Additional Private Declarations
      //## begin AutoReconciliation%4396E5BC030D.private preserve=yes
      //## end AutoReconciliation%4396E5BC030D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Cursor%43C00D0D000F
      //## begin AutoReconciliation::Cursor%43C00D0D000F.attr preserve=no  private: map<string, reconciliationfile::ReconciliationFile>::iterator {V} 
      map<string, reconciliationfile::ReconciliationFile>::iterator m_pCursor;
      //## end AutoReconciliation::Cursor%43C00D0D000F.attr

      //## Attribute: Files%43C00CC802CE
      //## begin AutoReconciliation::Files%43C00CC802CE.attr preserve=no  private: map<string, reconciliationfile::ReconciliationFile> {V} 
      map<string, reconciliationfile::ReconciliationFile> m_hFiles;
      //## end AutoReconciliation::Files%43C00CC802CE.attr

      //## Attribute: Items%456DE929034B
      //## begin AutoReconciliation::Items%456DE929034B.attr preserve=no  private: int {V} 0
      int m_iItems;
      //## end AutoReconciliation::Items%456DE929034B.attr

      //## Attribute: Limit%5834AF5D005F
      //## begin AutoReconciliation::Limit%5834AF5D005F.attr preserve=no  private: int {V} 99
      int m_iLimit;
      //## end AutoReconciliation::Limit%5834AF5D005F.attr

      //## Attribute: ReconciliationState%4F705530032D
      //## begin AutoReconciliation::ReconciliationState%4F705530032D.attr preserve=no  private: ReconciliationState {V} 
      ReconciliationState m_hReconciliationState;
      //## end AutoReconciliation::ReconciliationState%4F705530032D.attr

    // Data Members for Associations

      //## Association: Reconciliation::AutoReconciliation_CAT::<unnamed>%45C920300119
      //## Role: AutoReconciliation::<m_pBegin>%45C92031006D
      //## begin AutoReconciliation::<m_pBegin>%45C92031006D.role preserve=no  public: database::GlobalContext { -> RFHgN}
      database::GlobalContext *m_pBegin;
      //## end AutoReconciliation::<m_pBegin>%45C92031006D.role

      //## Association: Reconciliation::AutoReconciliation_CAT::<unnamed>%45C922D200BB
      //## Role: AutoReconciliation::<m_pEnd>%45C922D2031C
      //## begin AutoReconciliation::<m_pEnd>%45C922D2031C.role preserve=no  public: database::GlobalContext { -> RFHgN}
      database::GlobalContext *m_pEnd;
      //## end AutoReconciliation::<m_pEnd>%45C922D2031C.role

      //## Association: Reconciliation::AutoReconciliation_CAT::<unnamed>%4D45E4470169
      //## Role: AutoReconciliation::<m_pReconciliationFile>%4D45E44802A1
      //## begin AutoReconciliation::<m_pReconciliationFile>%4D45E44802A1.role preserve=no  public: reconciliationfile::ReconciliationFile { -> RFHgN}
      reconciliationfile::ReconciliationFile *m_pReconciliationFile;
      //## end AutoReconciliation::<m_pReconciliationFile>%4D45E44802A1.role

      //## Association: Reconciliation::AutoReconciliation_CAT::<unnamed>%4F70425B006B
      //## Role: AutoReconciliation::<m_pGlobalContext>%4F70425B00E8
      //## begin AutoReconciliation::<m_pGlobalContext>%4F70425B00E8.role preserve=no  public: database::GlobalContext { -> UFHgN}
      database::GlobalContext m_pGlobalContext;
      //## end AutoReconciliation::<m_pGlobalContext>%4F70425B00E8.role

      //## Association: Reconciliation::AutoReconciliation_CAT::<unnamed>%4F704F4B0323
      //## Role: AutoReconciliation::<m_pReconTransitionCommand>%4F704F4C0352
      //## begin AutoReconciliation::<m_pReconTransitionCommand>%4F704F4C0352.role preserve=no  public: reconciliationuserinterface::ReconTransitionCommand { -> RFHgN}
      reconciliationuserinterface::ReconTransitionCommand *m_pReconTransitionCommand;
      //## end AutoReconciliation::<m_pReconTransitionCommand>%4F704F4C0352.role

      //## Association: Reconciliation::AutoReconciliation_CAT::<unnamed>%4F7057D70307
      //## Role: AutoReconciliation::<m_hQuery>%4F7057D802AA
      //## begin AutoReconciliation::<m_hQuery>%4F7057D802AA.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end AutoReconciliation::<m_hQuery>%4F7057D802AA.role

      //## Association: Reconciliation::AutoReconciliation_CAT::<unnamed>%506172AA00A5
      //## Role: AutoReconciliation::<m_pCaseCreateCommand>%506172AA03E0
      //## begin AutoReconciliation::<m_pCaseCreateCommand>%506172AA03E0.role preserve=no  public: emscommand::CaseCreateCommand { -> RFHgN}
      emscommand::CaseCreateCommand *m_pCaseCreateCommand;
      //## end AutoReconciliation::<m_pCaseCreateCommand>%506172AA03E0.role

    // Additional Implementation Declarations
      //## begin AutoReconciliation%4396E5BC030D.implementation preserve=yes
      //## end AutoReconciliation%4396E5BC030D.implementation

};

//## begin AutoReconciliation%4396E5BC030D.postscript preserve=yes
//## end AutoReconciliation%4396E5BC030D.postscript

//## begin module%4396E63700FA.epilog preserve=yes
//## end module%4396E63700FA.epilog


#endif
