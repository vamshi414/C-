//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5B2AC5120382.cm preserve=no
//	$Date:   Nov 27 2020 04:56:38  $ $Author:   e5563153  $
//	$Revision:   1.11  $
//## end module%5B2AC5120382.cm

//## begin module%5B2AC5120382.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5B2AC5120382.cp

//## Module: CXOPSC00%5B2AC5120382; Package body
//## Subsystem: SC%5B2AC4E90014
//## Source file: D:\V02.9D.R001\Dn\Server\Application\Sc\CXOPSC00.cpp

//## begin module%5B2AC5120382.additionalIncludes preserve=no
//## end module%5B2AC5120382.additionalIncludes

//## begin module%5B2AC5120382.includes preserve=yes
#ifdef _WIN32
#include "xercesc\framework\MemBufInputSource.hpp"
#include "xercesc\util\PlatformUtils.hpp"
#include "xercesc\parsers\SAXParser.hpp"
#else
#include "xercesc/framework/MemBufInputSource.hpp"
#include "xercesc/util/PlatformUtils.hpp"
#include "xercesc/parsers/SAXParser.hpp"
#endif
//## end module%5B2AC5120382.includes

#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSBS06_h
#include "CXODBS06.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF32_h
#include "CXODIF32.hpp"
#endif
#ifndef CXOSIF39_h
#include "CXODIF39.hpp"
#endif
#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
#ifndef CXOSIF25_h
#include "CXODIF25.hpp"
#endif
#ifndef CXOSBS19_h
#include "CXODBS19.hpp"
#endif
#ifndef CXOSBC34_h
#include "CXODBC34.hpp"
#endif
#ifndef CXOSBC35_h
#include "CXODBC35.hpp"
#endif
#ifndef CXOPSC00_h
#include "CXODSC00.hpp"
#endif


//## begin module%5B2AC5120382.declarations preserve=no
//## end module%5B2AC5120382.declarations

//## begin module%5B2AC5120382.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
pApplication = new secuapi::SECUSimulator();
pApplication->parseCommandLine(argc, argv);
if (pApplication->initialize() == 0)
pApplication->run();
#include "CXODPS07.hpp"
//## end module%5B2AC5120382.additionalDeclarations


//## Modelname: Platform \: SECU::SECUSimulator_CAT%5B2AC42C0323
namespace secuapi {
//## begin secuapi%5B2AC42C0323.initialDeclarations preserve=yes
//## end secuapi%5B2AC42C0323.initialDeclarations

// Class secuapi::SECUSimulator 

SECUSimulator::SECUSimulator()
  //## begin SECUSimulator::SECUSimulator%5B2AC4720194_const.hasinit preserve=no
  //## end SECUSimulator::SECUSimulator%5B2AC4720194_const.hasinit
  //## begin SECUSimulator::SECUSimulator%5B2AC4720194_const.initialization preserve=yes
  //## end SECUSimulator::SECUSimulator%5B2AC4720194_const.initialization
{
  //## begin secuapi::SECUSimulator::SECUSimulator%5B2AC4720194_const.body preserve=yes
   memcpy(m_sID, "SC00", 4);
   XMLPlatformUtils::Initialize();
   m_pXMLItem = new XMLItem();
  //## end secuapi::SECUSimulator::SECUSimulator%5B2AC4720194_const.body
}


SECUSimulator::~SECUSimulator()
{
  //## begin secuapi::SECUSimulator::~SECUSimulator%5B2AC4720194_dest.body preserve=yes
   XMLPlatformUtils::Terminate();
   delete m_pXMLItem;
  //## end secuapi::SECUSimulator::~SECUSimulator%5B2AC4720194_dest.body
}



//## Other Operations (implementation)
int SECUSimulator::initialize ()
{
  //## begin secuapi::SECUSimulator::initialize%5B2AC5D800AF.body preserve=yes
   new platform::Platform();
   int i = Application::initialize();
   UseCase hUseCase("CLIENT", "## START SC");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }

   string strHTTP;
   if (Extract::instance()->getSpec("HTTP", strHTTP))
   {
      vector<string> hTokens;
      Buffer::parse(strHTTP, ", ", hTokens);
      if (hTokens.size() >= 2)
      {
         m_pSocketSignal[1] = (Signal*)QueueFactory::instance()->create("Signal", "HTTP");
         m_pSocketQueue[1] = (SocketQueue*)QueueFactory::instance()->create("Queue", "HTTP");
         m_pSocketQueue[1]->setSignal(m_pSocketSignal[1]);
         m_pSocketSignal[1]->attach(m_pSocketQueue[1]);
         enable(m_pSocketSignal[1]);
         m_pSocketQueue[1]->setInterface(SocketQueue::POST);
         if (!m_pSocketQueue[1]->open(hTokens[0].c_str(), hTokens[1].c_str()))
         {
            UseCase::setSuccess(false);
            return -1;
         }
      }
   }
	
   platform::Platform::instance()->createDatabaseFactory();
   return 0;
  //## end secuapi::SECUSimulator::initialize%5B2AC5D800AF.body
}

int SECUSimulator::onMessage (Message& hMessage)
{
  //## begin secuapi::SECUSimulator::onMessage%5B2AC5DC0239.body preserve=yes
   string strBuffer(hMessage.buffer() , hMessage.messageLength());
   vector<string> hTokens;
   Buffer::parse(strBuffer , "\n" , hTokens);
   string strXML = hTokens[1];
   size_t match_DepositAdjustmentRequest = strXML.find("DepositAdjustment");
   size_t match_CardholderAddressRequest = strXML.find("CardholderAddress");
   size_t match_ProvisionalTranRequest = strXML.find("ProvisionalTranRequest");
   unsigned xmlLength = strXML.length();
   char *psBuffer = new char[xmlLength + 1];
   memcpy(psBuffer, strXML.data(), xmlLength);    // just copy XML stuff
   psBuffer[xmlLength] = ' ';   // MJK shouldn't matter what next char is
 
   XMLCh sBufld[2] = {1,0};
   MemBufInputSource hMemBufInputSource((XMLByte*)psBuffer, xmlLength, &sBufld[0]);
   m_pXMLItem->resetToken();
   SAXParser hSAXParser;
   XMLHandler* pXMLHandler = new XMLHandler(m_pXMLItem);
   hSAXParser.setDocumentHandler(pXMLHandler );
   hSAXParser.setErrorHandler(pXMLHandler);
   hSAXParser.parse(hMemBufInputSource);
   delete [] psBuffer;
   delete pXMLHandler;

   string strRespCode("0");
   string strErrCode("0");
   string strResponse;
   string strRetry("");
   string strTranState("0");
   string strInputTranState("0");
   strInputTranState = m_pXMLItem->get("dnv:TranState");
   if (match_DepositAdjustmentRequest != string::npos)
   {
      string strCheckNewAmount = "100.00";
      string strAmtToDelayRsp = "101.00";
      string strAmtToAbortTask = "102.00";
      string strAmtToAutoRetry = "103.00";
      string strAmtToNoRetry = "104.00";
      string strAmtToSuccess = "105.00";
      string strAmtToNegative = "106.00";
	   string strXmlParsingError = "107.00";
      string strAmtToManualRetry = "108.00";
      string strAmtToManualRetry2 = "109.00";
      string strAmtToAutoRetry2 = "110.00";

      if (strAmtToDelayRsp == m_pXMLItem->get("dnv:ChkNewAmt"))
         Sleep::goTo("40000");
      else if (strAmtToAbortTask == m_pXMLItem->get("dnv:ChkNewAmt"))
         abort();
      else if (strCheckNewAmount == m_pXMLItem->get("dnv:ChkNewAmt"))
      {
         if (strInputTranState == "1")
         {
            strRespCode = "0";
            strErrCode = "0";
            strRetry = "";
            strTranState = "";
         }
         else
         {
            strRespCode = "1";
            strErrCode = "1";
            strRetry = "A";
            strTranState = "1";
         }
      }
      else if (strAmtToNegative == m_pXMLItem->get("dnv:ChkNewAmt"))
         strRespCode = "-1";
      else if (strAmtToAutoRetry == m_pXMLItem->get("dnv:ChkNewAmt"))
      {
         strRespCode = "2";
         strErrCode = "1";
         strRetry = "A";
         strTranState = "0";
      }
      else if (strAmtToAutoRetry2 == m_pXMLItem->get("dnv:ChkNewAmt"))
      {
         if (strInputTranState == "0")
         {
            strRespCode = "1";
            strErrCode = "2";
            strRetry = "A";
            strTranState = "2";
         }
         else if (strInputTranState == "2")
         {
            strRespCode = "0";
            strErrCode = "0";
            strRetry = "";
            strTranState = "";
         }

      }
      else if (strAmtToSuccess == m_pXMLItem->get("dnv:ChkNewAmt"))
      {
         strRespCode = "5";
         strErrCode = "1";
      }
      else if (strAmtToManualRetry == m_pXMLItem->get("dnv:ChkNewAmt"))
      {
         strRespCode = "1";
         strErrCode = "-1";
         strRetry = "M";
         strTranState = "0";
      }
      else if (strAmtToManualRetry2 == m_pXMLItem->get("dnv:ChkNewAmt"))
      {
         if (strInputTranState == "0")
         {
            strRespCode = "1";
            strErrCode = "-1";
            strRetry = "M";
            strTranState = "2";
         }
         else if (strInputTranState == "2")
         {
            strRespCode = "0";
            strErrCode = "0";
            strRetry = "";
            strTranState = "";
         }
         
      }
      else if (strAmtToNoRetry == m_pXMLItem->get("dnv:ChkNewAmt"))
      {
         strRespCode = "1";
         strErrCode = "100";
         strRetry = "N";
         strTranState = "1";
      }
      if (strXmlParsingError != m_pXMLItem->get("dnv:ChkNewAmt"))
		 strResponse = "<soap:Envelope><soap:Body><dnv:DepositAdjustmentResponse>"
		 "<dnv:TranInd>" + m_pXMLItem->get("dnv:TranInd") + "</dnv:TranInd>"
		 "<dnv:TranRefNo>" + m_pXMLItem->get("dnv:TranRefNo") + "</dnv:TranRefNo>"
		 "<dnv:TranPan>" + m_pXMLItem->get("dnv:TranPan") + "</dnv:TranPan>"
		 "<dnv:ATMId>" + m_pXMLItem->get("dnv:ATMId") + "</dnv:ATMId>"
		 "<dnv:ATMLoc>" + m_pXMLItem->get("dnv:ATMLoc") + "</dnv:ATMLoc>"
       "<dnv:RsnCode>" + strRespCode + "</dnv:RsnCode>"
       "<dnv:ErrCode>" + strErrCode + "</dnv:ErrCode>"
       "<dnv:ErrMsg>" + "" + "</dnv:ErrMsg>"
       "<dnv:Retry>" + strRetry + "</dnv:Retry>"
       "<dnv:RetryState>" + strTranState + "</dnv:RetryState>"
		 "</dnv:DepositAdjustmentResponse></soap:Body></soap:Envelope>";

      if (strXmlParsingError == m_pXMLItem->get("dnv:ChkNewAmt"))
         strResponse = "HTTP/1.1 501 Method Not Implemented.CONTENT-TYPE: text/html.Date: Mon, 22 Jul 2019 16:05:00 GMT  .Server: IBM_CICS_Transaction_Server/5.4.0(zOS).Content-Length: 000000000000179.Connection: Close....<!doctype html public ..<html>..<head>..<title>CICS Web Interface error</title>..</head>..<body>..<H1>501 Method Not Implemented</H  )";

   }
   else if (match_CardholderAddressRequest != string::npos)
   {
      strErrCode = "0";
      strRespCode = "0";
      string strTranPan = m_pXMLItem->get("dnv:TranPan");
      if (strTranPan == "5812980099887701" || strTranPan.empty())
      {
         strErrCode = "1";
         strRespCode = "1";
      }
      if (strRespCode == "0")
         strResponse = "<soap:Envelope><soap:Body><dnv:CardholderAddressResponse>"
            "<dnv:FirstName1>Liam</dnv:FirstName1>"
            "<dnv:LastName1>Alvarez</dnv:LastName1>"
            "<dnv:Title1>Mr</dnv:Title1>"
            "<dnv:FirstName2>Mia</dnv:FirstName2>"
            "<dnv:LastName2>Alvarez</dnv:LastName2>"
            "<dnv:Title2>Mrs</dnv:Title2>"
            "<dnv:AddressLine1>4710 Candy Castle Ln</dnv:AddressLine1>"
            "<dnv:AddressLine2>Suite 500</dnv:AddressLine2>"
            "<dnv:AddressLine3></dnv:AddressLine3>"
            "<dnv:City>Santa Claus</dnv:City>"
            "<dnv:State>IN</dnv:State>"
            "<dnv:CountryCode>USA</dnv:CountryCode>"
            "<dnv:PostalCode>47579</dnv:PostalCode>"
            "<dnv:PhoneWork>414-999-1234</dnv:PhoneWork>"
            "<dnv:PhoneHome>414-000-1234</dnv:PhoneHome>"
            "<dnv:PhoneFax>414-111-1234</dnv:PhoneFax>"
            "<dnv:EmailPersonal>Liam.Alvarez@candyshop.com</dnv:EmailPersonal>"
            "<dnv:ErrMsg></dnv:ErrMsg>"
            "<dnv:ErrCode>" + strErrCode + "</dnv:ErrCode>"
            "<dnv:RsnCode>" + strRespCode + "</dnv:RsnCode>"
            "</dnv:CardholderAddressResponse></soap:Body></soap:Envelope>";

      /*  from Dane on 4/14
                      Liam Alvarez                                      (First name 1/Last name 1)
                Mr                                                          (Title 1)
                Mia Alvarez                                        (First name 2/Last name 2)
                Mrs                                                        (Title 2)
                4710 Candy Castle Ln                      (Address 1)
                Suite 500                                              (Address 2)
                Santa Claus, IN 47579                      (City, State, Zip)
                USA or 840?                                        (Country Code)
                414-999-1234                                     (Phone Work)
                414-000-1234                                     (Phone Home)
                414-111-1234                                     (PhoneFax)
                Liam.Alvarez@candyshop.com  (email)
      */
      /*  from WSDL on 4/14
                 <xsd:element name="FirstName1" type="tns:Name"></xsd:element>
            <xsd:element name="LastName1" type="tns:Name"></xsd:element>
      	    <xsd:element name="Title1" type="tns:Title"></xsd:element>
      	    <xsd:element name="FirstName2" type="tns:Name"></xsd:element>
      	    <xsd:element name="LastName2" type="tns:Name"></xsd:element>
      	    <xsd:element name="Title2" type="tns:Title"></xsd:element>
      	    <xsd:element name="AddressLine1" type="tns:Addr"></xsd:element>
      	    <xsd:element name="AddressLine2" type="tns:Addr"></xsd:element>
      	    <xsd:element name="AddressLine3" type="tns:Addr"></xsd:element>
      	    <xsd:element name="City" type="tns:City"></xsd:element>
      	    <xsd:element name="State" type="tns:State"></xsd:element>
      	    <xsd:element name="CountryCode" type="tns:CountryCode"></xsd:element>
      	    <xsd:element name="PostalCode" type="tns:PostalCode"></xsd:element>
      	    <xsd:element name="PhoneWork" type="tns:Phone"></xsd:element>
      	    <xsd:element name="PhoneHome" type="tns:Phone"></xsd:element>
      	    <xsd:element name="PhoneFax" type="tns:Phone"></xsd:element>
      	    <xsd:element name="EmailPersonal" type="tns:Email"></xsd:element>

      */
      else
         strResponse = "<soap:Envelope><soap:Body><dnv:CardholderAddressResponse>"
            "<dnv:ErrMsg></dnv:ErrMsg>"
            "<dnv:ErrCode>" + strErrCode + "</dnv:ErrCode>"
            "<dnv:RsnCode>" + strRespCode + "</dnv:RsnCode>"
            "</dnv:CardholderAddressResponse></soap:Body></soap:Envelope>";
   }
   else if (match_ProvisionalTranRequest != string::npos)
   {
      string strAmtToDelayRsp = "101.00";
      string strAmtToAbortTask = "102.00";
      string strAmtToRetry = "103.00";
      string strAmtToSuccess = "105.00";
      string strAmtToNegative = "106.00";
      string strTranAmt = m_pXMLItem->get("dnv:TranAmt");
      if (strAmtToDelayRsp == strTranAmt)
         Sleep::goTo("40000");
      else if (strAmtToAbortTask == strTranAmt)
         abort();
      else if (strAmtToNegative == strTranAmt)
         strRespCode = "-1";
      else if (strAmtToRetry == strTranAmt)
         strRespCode = "2";
      else if (strAmtToSuccess == strTranAmt)
         strRespCode = "5";
      strErrCode = strRespCode;
      strResponse = "<soap:Envelope><soap:Body><dnv:ProvisionalTranResponse>"
         "<dnv:TranRefNo>" + m_pXMLItem->get("dnv:TranRefNo") + "</dnv:TranRefNo>"
         "<dnv:TranPan>" + m_pXMLItem->get("dnv:TranPan") + "</dnv:TranPan>"
         "<dnv:ErrMsg></dnv:ErrMsg>"
         "<dnv:ErrCode>" + strErrCode + "</dnv:ErrCode>"
         "<dnv:RsnCode>" + strRespCode + "</dnv:RsnCode>"
         "</dnv:ProvisionalTranResponse></soap:Body></soap:Envelope>";
   }
   else
      return true;

   Message::instance(Message::INBOUND)->reset("SC AM ", "S1234R",false);  
   m_pDataBuffer = Message::instance(Message::INBOUND)->buffer() + 8;
   CommonHeaderSegment::instance()->deport(&m_pDataBuffer);
   TextSegment hTextSegment;
   hTextSegment.setText(strResponse);
   hTextSegment.deport(&m_pDataBuffer);
   Message::instance(Message::INBOUND)->setMessageLength(strResponse.length() + 222);
   return Message::instance(Message::INBOUND)->reply();

 //## end secuapi::SECUSimulator::onMessage%5B2AC5DC0239.body
}

// Additional Declarations
  //## begin secuapi::SECUSimulator%5B2AC4720194.declarations preserve=yes
  //## end secuapi::SECUSimulator%5B2AC4720194.declarations

} // namespace secuapi

//## begin module%5B2AC5120382.epilog preserve=yes
//## end module%5B2AC5120382.epilog
