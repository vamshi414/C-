//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5B2AC5110182.cm preserve=no
//	$Date:   Dec 20 2018 04:26:48  $ $Author:   e5558744  $
//	$Revision:   1.3  $
//## end module%5B2AC5110182.cm

//## begin module%5B2AC5110182.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5B2AC5110182.cp

//## Module: CXOPSC00%5B2AC5110182; Package specification
//## Subsystem: SC%5B2AC4E90014
//## Source file: D:\V02.9D.R001\Dn\Server\Application\Sc\CXODSC00.hpp

#ifndef CXOPSC00_h
#define CXOPSC00_h 1

//## begin module%5B2AC5110182.additionalIncludes preserve=no
//## end module%5B2AC5110182.additionalIncludes

//## begin module%5B2AC5110182.includes preserve=yes
//## end module%5B2AC5110182.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
   class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
   class Buffer;
   class Signal;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
   class Queue;
   class Message;
   class Trace;
   class SocketQueue;
   class Extract;
   class QueueFactory;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
   class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
   class XMLHandler;
   class XMLItem;

} // namespace command

//## begin module%5B2AC5110182.declarations preserve=no
//## end module%5B2AC5110182.declarations

//## begin module%5B2AC5110182.additionalDeclarations preserve=yes
//## end module%5B2AC5110182.additionalDeclarations


//## Modelname: Platform \: SECU::SECUSimulator_CAT%5B2AC42C0323
namespace secuapi {
   //## begin secuapi%5B2AC42C0323.initialDeclarations preserve=yes
   //## end secuapi%5B2AC42C0323.initialDeclarations

   //## begin secuapi::SECUSimulator%5B2AC4720194.preface preserve=yes
   //## end secuapi::SECUSimulator%5B2AC4720194.preface

   //## Class: SECUSimulator%5B2AC4720194
   //## Category: Platform \: SECU::SECUSimulator_CAT%5B2AC42C0323
   //## Subsystem: SC%5B2AC4E90014
   //## Persistence: Transient
   //## Cardinality/Multiplicity: n



   //## Uses: <unnamed>%5B845F910076;dnplatform::DNPlatform { -> F}
   //## Uses: <unnamed>%5B845F93026F;IF::Message { -> F}
   //## Uses: <unnamed>%5B845F9603D4;IF::Extract { -> F}
   //## Uses: <unnamed>%5B845F9D0356;IF::Trace { -> F}
   //## Uses: <unnamed>%5BDAB43402F6;reusable::Signal { -> F}
   //## Uses: <unnamed>%5BDAB4BF01AE;IF::Queue { -> F}
   //## Uses: <unnamed>%5BDAB4D60338;reusable::Buffer { -> F}
   //## Uses: <unnamed>%5BDAB54C0107;IF::QueueFactory { -> F}
   //## Uses: <unnamed>%5BDAB57D00D6;monitor::UseCase { -> F}
   //## Uses: <unnamed>%5BDAB5A501FD;IF::SocketQueue { -> F}

   class DllExport SECUSimulator : public process::Application  //## Inherits: <unnamed>%5B2AC48D00ED
   {
      //## begin secuapi::SECUSimulator%5B2AC4720194.initialDeclarations preserve=yes
      //## end secuapi::SECUSimulator%5B2AC4720194.initialDeclarations

   public:
      //## Constructors (generated)
      SECUSimulator();

      //## Destructor (generated)
      virtual ~SECUSimulator();


      //## Other Operations (specified)
      //## Operation: initialize%5B2AC5D800AF
      virtual int initialize();

      // Additional Public Declarations
      //## begin secuapi::SECUSimulator%5B2AC4720194.public preserve=yes
      //## end secuapi::SECUSimulator%5B2AC4720194.public

   protected:

      //## Other Operations (specified)
      //## Operation: onMessage%5B2AC5DC0239
      virtual int onMessage(Message& hMessage);

      // Additional Protected Declarations
      //## begin secuapi::SECUSimulator%5B2AC4720194.protected preserve=yes
      //## end secuapi::SECUSimulator%5B2AC4720194.protected

   private:
      // Additional Private Declarations
      //## begin secuapi::SECUSimulator%5B2AC4720194.private preserve=yes
      //## end secuapi::SECUSimulator%5B2AC4720194.private

   private: //## implementation
      // Data Members for Class Attributes

      //## Attribute: SocketQueue%5BDACC2903DE
      //## begin secuapi::SECUSimulator::SocketQueue%5BDACC2903DE.attr preserve=no  private: IF::SocketQueue*[2] {U} 
      IF::SocketQueue* m_pSocketQueue[2];
      //## end secuapi::SECUSimulator::SocketQueue%5BDACC2903DE.attr

      //## Attribute: SocketSignal%5BDACDEC01A1
      //## begin secuapi::SECUSimulator::SocketSignal%5BDACDEC01A1.attr preserve=no  private: reusable::Signal*[2] {U} 
      reusable::Signal* m_pSocketSignal[2];
      //## end secuapi::SECUSimulator::SocketSignal%5BDACDEC01A1.attr

      //## Attribute: DataBuffer%5C17672D02EA
      //## begin secuapi::SECUSimulator::DataBuffer%5C17672D02EA.attr preserve=no  private: char* {U} 
      char* m_pDataBuffer;
      //## end secuapi::SECUSimulator::DataBuffer%5C17672D02EA.attr

      // Data Members for Associations

      //## Association: Platform \: SECU::SECUSimulator_CAT::<unnamed>%5BB4939C01E6
      //## Role: SECUSimulator::<m_pXMLItem>%5BB4939D02B9
      //## begin secuapi::SECUSimulator::<m_pXMLItem>%5BB4939D02B9.role preserve=no  public: command::XMLItem { -> RFHgN}
      command::XMLItem *m_pXMLItem;
      //## end secuapi::SECUSimulator::<m_pXMLItem>%5BB4939D02B9.role

      //## Association: Platform \: SECU::SECUSimulator_CAT::<unnamed>%5BB493A100E3
      //## Role: SECUSimulator::<m_pXMLHandler>%5BB493A20129
      //## begin secuapi::SECUSimulator::<m_pXMLHandler>%5BB493A20129.role preserve=no  public: command::XMLHandler { -> RFHgN}
      command::XMLHandler *m_pXMLHandler;
      //## end secuapi::SECUSimulator::<m_pXMLHandler>%5BB493A20129.role

      // Additional Implementation Declarations
      //## begin secuapi::SECUSimulator%5B2AC4720194.implementation preserve=yes
      //## end secuapi::SECUSimulator%5B2AC4720194.implementation

   };

   //## begin secuapi::SECUSimulator%5B2AC4720194.postscript preserve=yes
   //## end secuapi::SECUSimulator%5B2AC4720194.postscript

} // namespace secuapi

//## begin module%5B2AC5110182.epilog preserve=yes
//## end module%5B2AC5110182.epilog


#endif
