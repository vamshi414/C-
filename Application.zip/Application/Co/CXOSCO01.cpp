//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%394E8F0F0186.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%394E8F0F0186.cm

//## begin module%394E8F0F0186.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%394E8F0F0186.cp

//## Module: CXOSCO01%394E8F0F0186; Package body
//## Subsystem: CO%3664663D019C
//## Source file: C:\Pvcswork\Dn\Server\Application\Co\CXOSCO01.cpp

//## begin module%394E8F0F0186.additionalIncludes preserve=no
//## end module%394E8F0F0186.additionalIncludes

//## begin module%394E8F0F0186.includes preserve=yes
// $Date:   Apr 09 2004 08:09:58  $ $Author:   D02405  $ $Revision:   1.8  $
#include "CXODIF11.hpp"
//## end module%394E8F0F0186.includes

#ifndef CXOSBS09_h
#include "CXODBS09.hpp"
#endif
#ifndef CXOSCO01_h
#include "CXODCO01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRU06_h
#include "CXODRU06.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif


//## begin module%394E8F0F0186.declarations preserve=no
//## end module%394E8F0F0186.declarations

//## begin module%394E8F0F0186.additionalDeclarations preserve=yes
//## end module%394E8F0F0186.additionalDeclarations


// Class EntityCutoff 









EntityCutoff::EntityCutoff()
  //## begin EntityCutoff::EntityCutoff%394E8DF10013_const.hasinit preserve=no
  //## end EntityCutoff::EntityCutoff%394E8DF10013_const.hasinit
  //## begin EntityCutoff::EntityCutoff%394E8DF10013_const.initialization preserve=yes
  //## end EntityCutoff::EntityCutoff%394E8DF10013_const.initialization
{
  //## begin EntityCutoff::EntityCutoff%394E8DF10013_const.body preserve=yes
   memcpy(m_sID,"CO01",4);
   Extract::instance()->getSpec("CUSTOMER",m_strCUST_ID);
  //## end EntityCutoff::EntityCutoff%394E8DF10013_const.body
}


EntityCutoff::~EntityCutoff()
{
  //## begin EntityCutoff::~EntityCutoff%394E8DF10013_dest.body preserve=yes
  //## end EntityCutoff::~EntityCutoff%394E8DF10013_dest.body
}



//## Other Operations (implementation)
bool EntityCutoff::cascade ()
{
  //## begin EntityCutoff::cascade%395230ED0312.body preserve=yes
   UseCase hUseCase("TOTALS","## TM30 CASCADE CUTOFF TIMES");
   string strLastCutoffTime;
   m_strCurrent = Clock::instance()->getYYYYMMDDHHMMSS();
   Context hCascade(Application::instance()->image(),Application::instance()->name());
   if (!hCascade.get("CASCADE PROGRESS",strLastCutoffTime))
   {
      Database::instance()->rollback();
      UseCase::setSuccess(false);
      return false;
   }
   if (strLastCutoffTime.length() == 0)
      strLastCutoffTime = "00000000000000";
   Database::instance()->commit();
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   Query hQuery;
   hQuery.attach(this);
   hQuery.setRetainCursor(true);
   hQuery.setQualifier("QUALIFY","STS_CUSTOMER");
   hQuery.bind("STS_CUSTOMER","CUTOFF_IND",Column::STRING,&m_strCUTOFF_IND);
   hQuery.bind("STS_CUSTOMER","CUTOFF_TIME",Column::STRING,&m_strCUTOFF_TIME);
   hQuery.setBasicPredicate("STS_CUSTOMER","CUST_ID","=",m_strCUST_ID.c_str());
   hQuery.setBasicPredicate("STS_CUSTOMER","CUST_STAT","="," ");
   hQuery.setBasicPredicate("STS_CUSTOMER","CC_TSTAMP_CHANGE",">=",strLastCutoffTime.c_str());
   m_strCUTOFF_START_TIME.erase();
   m_strTableName = "PROCESSOR";
   if (pSelectStatement->execute(hQuery) == false
      || hQuery.getAbort())
   {
      Database::instance()->rollback();
      UseCase::setSuccess(false);
      return false;
   }
   Database::instance()->commit();
   hQuery.reset();
   hQuery.setRetainCursor(true);
   hQuery.setQualifier("QUALIFY","PROCESSOR");
   hQuery.bind("PROCESSOR","CUTOFF_IND",Column::STRING,&m_strCUTOFF_IND);
   hQuery.bind("PROCESSOR","CUTOFF_START_TIME",Column::STRING,&m_strCUTOFF_START_TIME);
   hQuery.bind("PROCESSOR","CUTOFF_TIME",Column::STRING,&m_strCUTOFF_TIME);
   hQuery.bind("PROCESSOR","PROC_ID",Column::STRING,&m_strEntityID);
   hQuery.setBasicPredicate("PROCESSOR","CUST_ID","=",m_strCUST_ID.c_str());
   hQuery.setBasicPredicate("PROCESSOR","CC_TSTAMP_CHANGE",">=",strLastCutoffTime.c_str());
   m_strTableName = "INSTITUTION";
   if (pSelectStatement->execute(hQuery) == false
      || hQuery.getAbort())
   {
      Database::instance()->rollback();
      UseCase::setSuccess(false);
      return false;
   }
   Database::instance()->commit();
   hQuery.reset();
   hQuery.setRetainCursor(true);
   hQuery.setQualifier("QUALIFY","INSTITUTION");
   hQuery.bind("INSTITUTION","CUTOFF_IND",Column::STRING,&m_strCUTOFF_IND);
   hQuery.bind("INSTITUTION","CUTOFF_START_TIME",Column::STRING,&m_strCUTOFF_START_TIME);
   hQuery.bind("INSTITUTION","CUTOFF_TIME",Column::STRING,&m_strCUTOFF_TIME);
   hQuery.bind("INSTITUTION","INST_ID",Column::STRING,&m_strEntityID);
   hQuery.setBasicPredicate("INSTITUTION","CUST_ID","=",m_strCUST_ID.c_str());
   hQuery.setBasicPredicate("INSTITUTION","CC_TSTAMP_CHANGE",">=",strLastCutoffTime.c_str());
   m_strTableName = "DEVICE";
   if (pSelectStatement->execute(hQuery) == false
      || hQuery.getAbort())
   {
      Database::instance()->rollback();
      UseCase::setSuccess(false);
      return false;
   }
   Database::instance()->commit();
   hCascade.put("CASCADE PROGRESS",m_strCurrent.c_str());
   Database::instance()->commit();
   return true;
  //## end EntityCutoff::cascade%395230ED0312.body
}

void EntityCutoff::update (Subject* pSubject)
{
  //## begin EntityCutoff::update%3952308A0324.body preserve=yes
   Table hTable(m_strTableName.c_str());
   hTable.setQualifier("QUALIFY");
   if (m_strTableName == "INSTITUTION")
      hTable.set("PROC_ID",m_strEntityID,false,true);
   else
   if (m_strTableName == "DEVICE")
      hTable.set("INST_ID",m_strEntityID,false,true);
   hTable.set("CUST_ID",m_strCUST_ID,false,true);
   hTable.set("CUTOFF_COPY_FLG","Y",false,true);
   hTable.set("CUTOFF_IND",m_strCUTOFF_IND);
   hTable.set("CUTOFF_START_TIME",m_strCUTOFF_START_TIME);
   hTable.set("CUTOFF_TIME",m_strCUTOFF_TIME);
   hTable.set("CC_TSTAMP_CHANGE",m_strCurrent);
   auto_ptr<Statement> pStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if (pStatement->execute(hTable) == false
      && pStatement->getInfoIDNumber() != STS_RECORD_NOT_FOUND)
   {
      ((Query*)pSubject)->setAbort(true);
      return;
   }
   UseCase::addItem();
   Database::instance()->commit();
  //## end EntityCutoff::update%3952308A0324.body
}

// Additional Declarations
  //## begin EntityCutoff%394E8DF10013.declarations preserve=yes
  //## end EntityCutoff%394E8DF10013.declarations

//## begin module%394E8F0F0186.epilog preserve=yes
//## end module%394E8F0F0186.epilog
