//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36654F8C01FD.cm preserve=no
//	$Date:   Jan 07 2019 15:31:48  $ $Author:   e1009839  $
//	$Revision:   1.20  $
//## end module%36654F8C01FD.cm

//## begin module%36654F8C01FD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%36654F8C01FD.cp

//## Module: CXOPCO00%36654F8C01FD; Package specification
//## Subsystem: CO%3664663D019C
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Application\Co\CXODCO00.hpp

#ifndef CXOPCO00_h
#define CXOPCO00_h 1

//## begin module%36654F8C01FD.additionalIncludes preserve=no
//## end module%36654F8C01FD.additionalIncludes

//## begin module%36654F8C01FD.includes preserve=yes
// $Date:   Jan 07 2019 15:31:48  $ $Author:   e1009839  $ $Revision:   1.20  $
//## end module%36654F8C01FD.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRC04_h
#include "CXODRC04.hpp"
#endif

class EntityCutoff;
//## Modelname: Device Management::ManagementCommand_CAT%3A06C995022A
namespace managementcommand {
class BalanceSheetCreateCommand;
class ATMCutoffMediator;
} // namespace managementcommand

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Progress;
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MidnightAlarm;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class CriticalSection;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class QueueFactory;
class Timestamp;
class Message;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace timer {
class Timer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class CRTransactionTypeIndicator;
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%36654F8C01FD.declarations preserve=no
//## end module%36654F8C01FD.declarations

//## begin module%36654F8C01FD.additionalDeclarations preserve=yes
//## end module%36654F8C01FD.additionalDeclarations


//## begin CutoffManager%36653FD901CC.preface preserve=yes
//## end CutoffManager%36653FD901CC.preface

//## Class: CutoffManager%36653FD901CC
//	<body>
//	<title>CG
//	<h1>CO
//	<h2>AB
//	<p>
//	End of day (EOD) is a predetermined time each day that
//	has been designated as the end of the business day for a
//	particular terminal, financial institution or network.
//	Accurate calculation of financial and settlement totals
//	depends on the correct setting of the cutoff times in
//	DataNavigator.
//	<h3>System Flow
//	<p>
//	The Cutoff Manager service simplifies the management of
//	the business end-of-day times for your processors,
//	institutions and devices.
//	Fixed cutoff times that you modify are automatically
//	copied to subordinate entities (customer to processor,
//	processor to institution, and institution to device).
//	<p>
//	The Cutoff Manager (<i>ca</i>CO) copies the cutoff
//	information when the service starts, at midnight each
//	day and manually by a Reset command.
//	Fixed cutoff information is optionally updated in the
//	processor, institution and device tables.
//	</p>
//	<img src=CXOCCO00.gif>
//	</body>
//	<body>
//	<title>OG
//	<h1>CO
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The Cutoff Manager service simplifies the management of
//	the business end-of-day times for your processors,
//	institutions and devices.
//	Fixed cutoff times that you modify are automatically
//	copied to subordinate entities (customer to processor,
//	processor to institution, and institution to device).
//	</p>
//	<img src=CXOOCO00.gif>
//	</body>
//## Category: Totals Management::CutoffManager_CAT%366465B70172
//## Subsystem: CO%3664663D019C
//## Persistence: Transient
//## Cardinality/Multiplicity: 0..1



//## Uses: <unnamed>%36656409010F;reusable::Statement { -> }
//## Uses: <unnamed>%3667F74F03D0;reusable::Query { -> }
//## Uses: <unnamed>%366C40C4038A;reusable::SelectStatement { -> }
//## Uses: <unnamed>%383583B1030E;IF::QueueFactory { -> F}
//## Uses: <unnamed>%387C9CBB0033;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%38C3C0E4039D;IF::Extract { -> F}
//## Uses: <unnamed>%38C3C498017A;database::Database { -> F}
//## Uses: <unnamed>%38C3C49A02B3;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3C23A2AF008C;EntityCutoff { -> F}
//## Uses: <unnamed>%3C23A2D50232;IF::Message { -> F}
//## Uses: <unnamed>%3C23A4AE01C5;monitor::UseCase { -> F}
//## Uses: <unnamed>%40AA3E9C036B;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%41AC9D9A00EA;managementcommand::ATMCutoffMediator { -> F}
//## Uses: <unnamed>%41AC9F4900CB;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%41ACA2B201B5;IF::Timestamp { -> F}
//## Uses: <unnamed>%41AF672A00CB;entitysegment::Progress { -> F}
//## Uses: <unnamed>%41AF8D7A02AF;managementcommand::BalanceSheetCreateCommand { -> F}
//## Uses: <unnamed>%43DE19BA02EE;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%43DE1A0C0109;entitysegment::Customer { -> F}
//## Uses: <unnamed>%5C17B2BF003B;database::CRTransactionTypeIndicator { -> F}

class CutoffManager : public process::Application  //## Inherits: <unnamed>%36654013020B
{
  //## begin CutoffManager%36653FD901CC.initialDeclarations preserve=yes
  //## end CutoffManager%36653FD901CC.initialDeclarations

  public:
    //## Constructors (generated)
      CutoffManager();

    //## Destructor (generated)
      virtual ~CutoffManager();


    //## Other Operations (specified)
      //## Operation: initialize%3665495D017F
      virtual int initialize ();

      //## Operation: update%3665B25803D2
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin CutoffManager%36653FD901CC.public preserve=yes
      //## end CutoffManager%36653FD901CC.public

  protected:

    //## Other Operations (specified)
      //## Operation: onRefresh%366549AA0143
      virtual int onRefresh ();

      //## Operation: onReset%366549B203BC
      //## Preconditions:
      //	<body>
      //	<title>OG
      //	<h1>CO
      //	<h2>CD
      //	<!-- CutoffManager::onReset Preconditions -->
      //	<h3>Cascade Cutoff Information
      //	<h4>Name
      //	<p>
      //	RESET <i>ca</i>CO
      //	<h4>Description
      //	<p>
      //	The Cutoff Manager service updates the PROCESSOR,
      //	INSTITUTION and DEVICE tables in the DataNavigator
      //	Configuration Repository.
      //	This command can be used after a new configuration file
      //	has been processed by the Configuration Interface (e.g. e
      //	Funds Advantage CED Interface).
      //	The command is done automatically every day at midnight.
      //	</p>
      //	</body>
      virtual int onReset (Message &hMessage);

      //## Operation: onResume%3C275CBA01D4
      virtual int onResume (Message& hMessage);

    // Additional Protected Declarations
      //## begin CutoffManager%36653FD901CC.protected preserve=yes
      //## end CutoffManager%36653FD901CC.protected

  private:
    // Additional Private Declarations
      //## begin CutoffManager%36653FD901CC.private preserve=yes
      //## end CutoffManager%36653FD901CC.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ATMCutOffProgress%41CD7FFA036B
      //## begin CutoffManager::ATMCutOffProgress%41CD7FFA036B.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strATMCutOffProgress;
      //## end CutoffManager::ATMCutOffProgress%41CD7FFA036B.attr

      //## Attribute: CutOffProgress%41CD7F7900EA
      //## begin CutoffManager::CutOffProgress%41CD7F7900EA.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strCutOffProgress;
      //## end CutoffManager::CutOffProgress%41CD7F7900EA.attr

      //## Attribute: MaxDays%3666A5FB00B7
      //## begin CutoffManager::MaxDays%3666A5FB00B7.attr preserve=no  private: int {V} 160
      int m_lMaxDays;
      //## end CutoffManager::MaxDays%3666A5FB00B7.attr

      //## Attribute: NeedCascade%41CD808101D4
      //## begin CutoffManager::NeedCascade%41CD808101D4.attr preserve=no  private: bool {U} false
      bool m_bNeedCascade;
      //## end CutoffManager::NeedCascade%41CD808101D4.attr

    // Data Members for Associations

      //## Association: Totals Management::CutoffManager_CAT::<unnamed>%38C3CF7603C9
      //## Role: CutoffManager::<m_hAddCutoffCommand>%38C3CF770244
      //## begin CutoffManager::<m_hAddCutoffCommand>%38C3CF770244.role preserve=no  public: repositorycommand::AddCutoffCommand { -> VHgN}
      repositorycommand::AddCutoffCommand m_hAddCutoffCommand;
      //## end CutoffManager::<m_hAddCutoffCommand>%38C3CF770244.role

      //## Association: Totals Management::CutoffManager_CAT::<unnamed>%47577EC0006B
      //## Role: CutoffManager::<m_hTimer>%47577EC10108
      //## begin CutoffManager::<m_hTimer>%47577EC10108.role preserve=no  public: timer::Timer { -> VFHgN}
      timer::Timer m_hTimer;
      //## end CutoffManager::<m_hTimer>%47577EC10108.role

    // Additional Implementation Declarations
      //## begin CutoffManager%36653FD901CC.implementation preserve=yes
      //## end CutoffManager%36653FD901CC.implementation

};

//## begin CutoffManager%36653FD901CC.postscript preserve=yes
//## end CutoffManager%36653FD901CC.postscript

//## begin module%36654F8C01FD.epilog preserve=yes
//## end module%36654F8C01FD.epilog


#endif
