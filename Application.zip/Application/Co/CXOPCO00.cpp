//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36654F9100EC.cm preserve=no
//	$Date:   Jan 07 2019 15:31:48  $ $Author:   e1009839  $
//	$Revision:   1.35  $
//## end module%36654F9100EC.cm

//## begin module%36654F9100EC.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%36654F9100EC.cp

//## Module: CXOPCO00%36654F9100EC; Package body
//## Subsystem: CO%3664663D019C
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Application\Co\CXOPCO00.cpp

//## begin module%36654F9100EC.additionalIncludes preserve=no
//## end module%36654F9100EC.additionalIncludes

//## begin module%36654F9100EC.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
//## end module%36654F9100EC.includes

#ifndef CXOSIF32_h
#include "CXODIF32.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSCO01_h
#include "CXODCO01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSMC22_h
#include "CXODMC22.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSNS39_h
#include "CXODNS39.hpp"
#endif
#ifndef CXOSMC04_h
#include "CXODMC04.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSDB16_h
#include "CXODDB16.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOPCO00_h
#include "CXODCO00.hpp"
#endif


//## begin module%36654F9100EC.declarations preserve=no
//## end module%36654F9100EC.declarations

//## begin module%36654F9100EC.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new CutoffManager();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%36654F9100EC.additionalDeclarations


// Class CutoffManager

CutoffManager::CutoffManager()
  //## begin CutoffManager::CutoffManager%36653FD901CC_const.hasinit preserve=no
      : m_lMaxDays(160),
        m_bNeedCascade(false)
  //## end CutoffManager::CutoffManager%36653FD901CC_const.hasinit
  //## begin CutoffManager::CutoffManager%36653FD901CC_const.initialization preserve=yes
  //## end CutoffManager::CutoffManager%36653FD901CC_const.initialization
{
  //## begin CutoffManager::CutoffManager%36653FD901CC_const.body preserve=yes
   memcpy(m_sID,"CO00",4);
  //## end CutoffManager::CutoffManager%36653FD901CC_const.body
}


CutoffManager::~CutoffManager()
{
  //## begin CutoffManager::~CutoffManager%36653FD901CC_dest.body preserve=yes
   MinuteTimer::instance()->detach(this);
   Database::instance()->detach(this);
   m_hTimer.detach(this);
  //## end CutoffManager::~CutoffManager%36653FD901CC_dest.body
}



//## Other Operations (implementation)
int CutoffManager::initialize ()
{
  //## begin CutoffManager::initialize%3665495D017F.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("TOTALS","## TM29 START CO");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   m_hTimer.setAlarm("230000");
   m_hTimer.attach(this);
   platform::Platform::instance()->createDatabaseFactory();
   database::CRTransactionTypeIndicator::instance();
   entitysegment::Progress::instance();
   onRefresh();
   Database::instance()->attach(this);
   Database::instance()->attach(managementcommand::ATMCutoffMediator::instance());
   Database::instance()->connect();
   return 0;
  //## end CutoffManager::initialize%3665495D017F.body
}

int CutoffManager::onRefresh ()
{
  //## begin CutoffManager::onRefresh%366549AA0143.body preserve=yes
   Extract::instance()->getLong("DUSER   ","MAXDAYS=",&m_lMaxDays);
   return 0;
  //## end CutoffManager::onRefresh%366549AA0143.body
}

int CutoffManager::onReset (Message &hMessage)
{
  //## begin CutoffManager::onReset%366549B203BC.body preserve=yes
   if (hMessage.context().subString(1,6) == "CUTOFF")
   {
      UseCase hUseCase("TOTALS","## TM29 START CO");
      m_hAddCutoffCommand.manualAdd(hMessage);
   }
   else
      update(&m_hTimer);
   return Application::onReset(hMessage);
  //## end CutoffManager::onReset%366549B203BC.body
}

int CutoffManager::onResume (Message& hMessage)
{
  //## begin CutoffManager::onResume%3C275CBA01D4.body preserve=yes
   string strResourceName(Customer::instance()->getCUST_ID());
   strResourceName += "TE";
   CriticalSection hCriticalSection(strResourceName.c_str());
   if (m_bNeedCascade)
   {
      m_hAddCutoffCommand.deleteOld(m_lMaxDays);
      // EntityCutoff hEntityCutoff;
      // hEntityCutoff.cascade();
      m_bNeedCascade = false;
   }
   m_strCutOffProgress.erase();
   m_strATMCutOffProgress.erase();
   entitysegment::Progress::instance()->get("CUTOFF PROGRESS",m_strCutOffProgress,Application::instance()->image(),managementcommand::ATMCutoffMediator::instance()->getTASKID().c_str());
   entitysegment::Progress::instance()->get("ATMCUTOFF PROGRESS",m_strATMCutOffProgress);
   if (m_strATMCutOffProgress < m_strCutOffProgress)
   {
      if (m_strATMCutOffProgress.length() == 0)
      {
         m_strATMCutOffProgress = m_strCutOffProgress;
         string strDate(m_strCutOffProgress.data(),11);
         string strTime(m_strCutOffProgress.data() + 11,4);
         strTime += "00";
         Timestamp::adjustGMT(strDate,strTime,-1);
         m_strATMCutOffProgress = strDate;
         m_strATMCutOffProgress += strTime.substr(0,4);
         entitysegment::Progress::instance()->put("ATMCUTOFF PROGRESS",m_strATMCutOffProgress);
      }
      if (managementcommand::ATMCutoffMediator::instance()->execute(m_strATMCutOffProgress))
         setQueueWaitOption(false);
   }
   else
      setQueueWaitOption(true);
   Database::instance()->commit();
   return 0;
  //## end CutoffManager::onResume%3C275CBA01D4.body
}

void CutoffManager::update (Subject* pSubject)
{
  //## begin CutoffManager::update%3665B25803D2.body preserve=yes
   if (pSubject == MinuteTimer::instance())
      setQueueWaitOption(false);
   else
   if ((pSubject == &m_hTimer
      || pSubject == Database::instance())
      && Database::instance()->state() == Database::CONNECTED)
   {
      m_bNeedCascade = true;
      m_hTimer.setAlarm("230000");
      MinuteTimer::instance()->attach(this);
      setQueueWaitOption(false);
   }
   Application::update(pSubject);
  //## end CutoffManager::update%3665B25803D2.body
}

// Additional Declarations
  //## begin CutoffManager%36653FD901CC.declarations preserve=yes
  //## end CutoffManager%36653FD901CC.declarations

//## begin module%36654F9100EC.epilog preserve=yes
//## end module%36654F9100EC.epilog
