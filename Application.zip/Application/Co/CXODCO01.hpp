//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%394E8F09032C.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%394E8F09032C.cm

//## begin module%394E8F09032C.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%394E8F09032C.cp

//## Module: CXOSCO01%394E8F09032C; Package specification
//## Subsystem: CO%3664663D019C
//## Source file: C:\Pvcswork\Dn\Server\Application\Co\CXODCO01.hpp

#ifndef CXOSCO01_h
#define CXOSCO01_h 1

//## begin module%394E8F09032C.additionalIncludes preserve=no
//## end module%394E8F09032C.additionalIncludes

//## begin module%394E8F09032C.includes preserve=yes
// $Date:   Apr 09 2004 08:09:58  $ $Author:   D02405  $ $Revision:   1.7  $
//## end module%394E8F09032C.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif

//## Modelname: DataNavigator Foundation::Database_CAT%3451F34D0218
namespace database {
class Context;
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Foundation::Reusable_CAT%3453F15C01AA
namespace reusable {
class Table;
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Foundation::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Foundation::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Message;
} // namespace IF

//## Modelname: Connex Foundation::Segment_CAT%3471F0BE0219
namespace segment {
class InformationSegment;

} // namespace segment

//## begin module%394E8F09032C.declarations preserve=no
//## end module%394E8F09032C.declarations

//## begin module%394E8F09032C.additionalDeclarations preserve=yes
//## end module%394E8F09032C.additionalDeclarations


//## begin EntityCutoff%394E8DF10013.preface preserve=yes
//## end EntityCutoff%394E8DF10013.preface

//## Class: EntityCutoff%394E8DF10013
//## Category: Totals Management::CutoffManager_CAT%366465B70172
//## Subsystem: CO%3664663D019C
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%395231A401AD;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%395231A90272;reusable::Statement { -> F}
//## Uses: <unnamed>%3952320A0376;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3952320E01A5;database::Database { -> F}
//## Uses: <unnamed>%39BE854A0188;IF::Extract { -> F}
//## Uses: <unnamed>%39BF994301AE;reusable::Table { -> F}
//## Uses: <unnamed>%39D0B5C203BB;timer::Clock { -> F}
//## Uses: <unnamed>%39D0DC96015B;database::Context { -> F}
//## Uses: <unnamed>%39D0E2440288;process::Application { -> F}
//## Uses: <unnamed>%3C23AC3B0109;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C23AC930213;reusable::Query { -> F}
//## Uses: <unnamed>%3C27596001D4;segment::InformationSegment { -> F}
//## Uses: <unnamed>%3D3C5F9002AF;IF::Message { -> F}

class EntityCutoff : public reusable::Observer  //## Inherits: <unnamed>%394E8E9D02F5
{
  //## begin EntityCutoff%394E8DF10013.initialDeclarations preserve=yes
  //## end EntityCutoff%394E8DF10013.initialDeclarations

  public:
    //## Constructors (generated)
      EntityCutoff();

    //## Destructor (generated)
      virtual ~EntityCutoff();


    //## Other Operations (specified)
      //## Operation: cascade%395230ED0312
      bool cascade ();

      //## Operation: update%3952308A0324
      //	Callback function that is invoked by a subject when its
      //	state
      //	changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin EntityCutoff%394E8DF10013.public preserve=yes
      //## end EntityCutoff%394E8DF10013.public

  protected:
    // Additional Protected Declarations
      //## begin EntityCutoff%394E8DF10013.protected preserve=yes
      //## end EntityCutoff%394E8DF10013.protected

  private:
    // Additional Private Declarations
      //## begin EntityCutoff%394E8DF10013.private preserve=yes
      //## end EntityCutoff%394E8DF10013.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Current%39D0B633038B
      //## begin EntityCutoff::Current%39D0B633038B.attr preserve=no  public: string {U} 
      string m_strCurrent;
      //## end EntityCutoff::Current%39D0B633038B.attr

      //## Attribute: CUST_ID%39BF90320034
      //## begin EntityCutoff::CUST_ID%39BF90320034.attr preserve=no  public: string {U} 
      string m_strCUST_ID;
      //## end EntityCutoff::CUST_ID%39BF90320034.attr

      //## Attribute: CUTOFF_COPY_FLG%39BF744A033F
      //## begin EntityCutoff::CUTOFF_COPY_FLG%39BF744A033F.attr preserve=no  public: string {U} 
      string m_strCUTOFF_COPY_FLG;
      //## end EntityCutoff::CUTOFF_COPY_FLG%39BF744A033F.attr

      //## Attribute: CUTOFF_IND%39BF74280065
      //## begin EntityCutoff::CUTOFF_IND%39BF74280065.attr preserve=no  public: string {U} 
      string m_strCUTOFF_IND;
      //## end EntityCutoff::CUTOFF_IND%39BF74280065.attr

      //## Attribute: CUTOFF_START_TIME%3A9ED5B30315
      //## begin EntityCutoff::CUTOFF_START_TIME%3A9ED5B30315.attr preserve=no  public: string {U} 
      string m_strCUTOFF_START_TIME;
      //## end EntityCutoff::CUTOFF_START_TIME%3A9ED5B30315.attr

      //## Attribute: CUTOFF_TIME%39BF8F620202
      //## begin EntityCutoff::CUTOFF_TIME%39BF8F620202.attr preserve=no  public: string {U} 
      string m_strCUTOFF_TIME;
      //## end EntityCutoff::CUTOFF_TIME%39BF8F620202.attr

      //## Attribute: EntityID%39BF7EBA0192
      //## begin EntityCutoff::EntityID%39BF7EBA0192.attr preserve=no  public: string {U} 
      string m_strEntityID;
      //## end EntityCutoff::EntityID%39BF7EBA0192.attr

      //## Attribute: TableName%39D1DA3B0182
      //## begin EntityCutoff::TableName%39D1DA3B0182.attr preserve=no  public: string {U} 
      string m_strTableName;
      //## end EntityCutoff::TableName%39D1DA3B0182.attr

    // Additional Implementation Declarations
      //## begin EntityCutoff%394E8DF10013.implementation preserve=yes
      //## end EntityCutoff%394E8DF10013.implementation

};

//## begin EntityCutoff%394E8DF10013.postscript preserve=yes
//## end EntityCutoff%394E8DF10013.postscript

//## begin module%394E8F09032C.epilog preserve=yes
//## end module%394E8F09032C.epilog


#endif
