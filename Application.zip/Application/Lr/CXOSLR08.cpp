//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%52012E820121.cm preserve=no
//	$Date:   Jul 13 2021 06:10:12  $ $Author:   e3019097  $
//	$Revision:   1.1.1.3  $
//## end module%52012E820121.cm

//## begin module%52012E820121.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%52012E820121.cp

//## Module: CXOSLR08%52012E820121; Package body
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\V02.3B.R009\Build\Dn\Server\Application\Lr\CXOSLR08.cpp

//## begin module%52012E820121.additionalIncludes preserve=no
//## end module%52012E820121.additionalIncludes

//## begin module%52012E820121.includes preserve=yes
#include "CXODMP07.hpp"
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
//## end module%52012E820121.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSLR08_h
#include "CXODLR08.hpp"
#endif


//## begin module%52012E820121.declarations preserve=no
//## end module%52012E820121.declarations

//## begin module%52012E820121.additionalDeclarations preserve=yes
#define FIXED_RECLEN 256
//## end module%52012E820121.additionalDeclarations


// Class MasterCardDraftCaptureFile

MasterCardDraftCaptureFile::MasterCardDraftCaptureFile()
  //## begin MasterCardDraftCaptureFile::MasterCardDraftCaptureFile%52012E2001ED_const.hasinit preserve=no
      : m_dCurrentHash(0),
        m_pDetail(0)
//        m_pHeader(0)
  //## end MasterCardDraftCaptureFile::MasterCardDraftCaptureFile%52012E2001ED_const.hasinit
  //## begin MasterCardDraftCaptureFile::MasterCardDraftCaptureFile%52012E2001ED_const.initialization preserve=yes
  //## end MasterCardDraftCaptureFile::MasterCardDraftCaptureFile%52012E2001ED_const.initialization
{
  //## begin MasterCardDraftCaptureFile::MasterCardDraftCaptureFile%52012E2001ED_const.body preserve=yes
   memcpy(m_sID,"LR08",4);
  //## end MasterCardDraftCaptureFile::MasterCardDraftCaptureFile%52012E2001ED_const.body
}

MasterCardDraftCaptureFile::MasterCardDraftCaptureFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile)
  //## begin MasterCardDraftCaptureFile::MasterCardDraftCaptureFile%52012FDD010F.hasinit preserve=no
      : m_dCurrentHash(0),
        m_pDetail(0)
//        m_pHeader(0)
  //## end MasterCardDraftCaptureFile::MasterCardDraftCaptureFile%52012FDD010F.hasinit
  //## begin MasterCardDraftCaptureFile::MasterCardDraftCaptureFile%52012FDD010F.initialization preserve=yes
   ,LogFile(strIMAGEID,strTASKID,pszName,bVariableBlockFile)
  //## end MasterCardDraftCaptureFile::MasterCardDraftCaptureFile%52012FDD010F.initialization
{
  //## begin MasterCardDraftCaptureFile::MasterCardDraftCaptureFile%52012FDD010F.body preserve=yes
   memcpy(m_sID,"LR08",4);
  //## end MasterCardDraftCaptureFile::MasterCardDraftCaptureFile%52012FDD010F.body
}


MasterCardDraftCaptureFile::~MasterCardDraftCaptureFile()
{
  //## begin MasterCardDraftCaptureFile::~MasterCardDraftCaptureFile%52012E2001ED_dest.body preserve=yes
  //## end MasterCardDraftCaptureFile::~MasterCardDraftCaptureFile%52012E2001ED_dest.body
}



//## Other Operations (implementation)
bool MasterCardDraftCaptureFile::read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward, bool bTruncate)
{
  //## begin MasterCardDraftCaptureFile::read%52012F380271.body preserve=yes
   m_hMessage.reset("LR AI ","S0059D");
   if (!GenerationDataGroup::read(psBuffer,lBufferLength,plRecordLength,bFastForward))
      return false;
   if (*plRecordLength > FIXED_RECLEN && (Extract::instance()->getCustomCode() == "COLES" || Extract::instance()->getCustomCode() == "CBA" || Extract::instance()->getCustomCode() == "PAAS"))
   {
      char szTemp[256];
      string strBaseName;
      GenerationDataGroup::getFlatFile()->getBaseName(strBaseName, true);
      //Mask PAN for 6220 Detail
      if (memcmp(psBuffer, "6220", 4) == 0)
         memcpy(psBuffer + 8, "xxxxxxxxxxxxxxxxxxxx", 20);
      snprintf(szTemp, sizeof(szTemp), "Record length error [%.40s:%.150s] - Partially processed", strBaseName.c_str() , psBuffer);
      Console::display("CL001", szTemp);
      return false;
   }
   if (!bFastForward)
      return true;
   int m = *plRecordLength;
   char psRecType[5] = {"    "};
   memcpy(psRecType,m_szBuffer,4);
   int iRecType = atoi(psRecType);
   switch (iRecType)
   {
      case 6200:
         memcpy(m_pHeader,m_szBuffer,m);
         break;
      case 6220:
         m_pDetail = m_hMessage.data();
         memcpy(m_pDetail, m_pHeader, FIXED_RECLEN);
         char szHash[5];
         memcpy(szHash,m_pDetail,4);
         szHash[4] = '\00';
         m_dCurrentHash += atoi(szHash);
         m_pDetail += FIXED_RECLEN;
         memcpy(m_pDetail,m_szBuffer,m);
         memset(m_pDetail + m,' ',FIXED_RECLEN - m);
         m_pDetail += FIXED_RECLEN;
         break;
      case 6221:
      case 6222:
      case 6223:
      case 6224:
      case 6225:
      case 6226:
      case 6227:
      case 6228:
      case 6229:
      case 6230:
      case 6231:
      case 6232:
      case 6233:
      case 6234:
      case 6235:
      case 6236:
      case 6237:
      case 6238:
      case 6239:
      case 6270:
      case 6283:
      case 6290:
         memcpy(m_pDetail,m_szBuffer,m);
         memset(m_pDetail + m,' ',FIXED_RECLEN - m);
         m_pDetail += FIXED_RECLEN;
         break;
      default:
         break;
   }
   return true;
  //## end MasterCardDraftCaptureFile::read%52012F380271.body
}

bool MasterCardDraftCaptureFile::sendBatch ()
{
  //## begin MasterCardDraftCaptureFile::sendBatch%52012F3D02C2.body preserve=yes
   UseCase hUseCase("LOG","## LG30 SEND MCDCF BATCH");
   m_hMessage.reset("LR AI ","S0059D");
   char psRecType[5] = {"    "};
   m_iRecordsRead = 0;
   size_t m = 0;
   while (read(m_szBuffer,258,&m))
   {
      m_iRecordsRead++;
      memcpy(psRecType,m_szBuffer,4);
      int iRecType = atoi(psRecType);
      switch (iRecType)
      {  //records 5-37 do not have header records
         //but they can have multiple records
         case 6200:
            memcpy(m_pHeader,m_szBuffer,m);
            break;
         case 6220:
            if (m_dCurrentHash > 0)
            {  //one in buffer to send
               if (m_dHashTotal == -1)
                  m_dHashTotal = 0;
               m_dHashTotal += m_dCurrentHash;
               m_dCurrentHash = 0;
               m_hMessage.setDataLength(m_pDetail - m_hMessage.data());
               if (m_hMessage.send(m_strQueueName.c_str()) != 0)
               {
                  return UseCase::setSuccess(false);
               }
            }

            m_pDetail = m_hMessage.data();
            memcpy(m_pDetail, m_pHeader, FIXED_RECLEN);
            char szHash[5];
            memcpy(szHash,m_pDetail,4);
            szHash[4] = '\00';
            m_dCurrentHash += atoi(szHash);
            m_pDetail += FIXED_RECLEN;
            memcpy(m_pDetail,m_szBuffer,m);
            memset(m_pDetail + m,' ',FIXED_RECLEN - m);
            m_pDetail += FIXED_RECLEN;
            if (m_iRecordsRead >= m_iBatchSize)
               return true;
            break;
         case 6221:
         case 6222:
         case 6223:
         case 6224:
         case 6225:
         case 6226:
         case 6227:
         case 6228:
         case 6229:
         case 6230:
         case 6231:
         case 6232:
         case 6233:
         case 6234:
         case 6235:
         case 6236:
         case 6237:
         case 6238:
         case 6239:
         case 6270:
         case 6283:
         case 6290:
            memcpy(m_pDetail,m_szBuffer,m);
            memset(m_pDetail + m,' ',FIXED_RECLEN - m);
            m_pDetail += FIXED_RECLEN;
            break;
         case 6240: // end of acquirer records
            if (m_dCurrentHash > 0)
            {  //send last transaction
               if (m_dHashTotal == -1)
                  m_dHashTotal = 0;
               m_dHashTotal += m_dCurrentHash;
               m_dCurrentHash = 0;
               m_hMessage.setDataLength(m_pDetail - m_hMessage.data());
               if (m_hMessage.send(m_strQueueName.c_str()) != 0)
               {
                  return UseCase::setSuccess(false);
               }
               memcpy(m_pDetail, m_pHeader, FIXED_RECLEN);
            }
         default:
            break;
      }
   }
   return true;
  //## end MasterCardDraftCaptureFile::sendBatch%52012F3D02C2.body
}

// Additional Declarations
  //## begin MasterCardDraftCaptureFile%52012E2001ED.declarations preserve=yes
  //## end MasterCardDraftCaptureFile%52012E2001ED.declarations

//## begin module%52012E820121.epilog preserve=yes
//## end module%52012E820121.epilog
