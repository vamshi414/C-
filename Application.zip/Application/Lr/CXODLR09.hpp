//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%534407BC014E.cm preserve=no
//	$Date:   Jan 07 2019 15:39:16  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%534407BC014E.cm

//## begin module%534407BC014E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%534407BC014E.cp

//## Module: CXOSLR09%534407BC014E; Package specification
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Application\Lr\CXODLR09.hpp

#ifndef CXOSLR09_h
#define CXOSLR09_h 1

//## begin module%534407BC014E.additionalIncludes preserve=no
//## end module%534407BC014E.additionalIncludes

//## begin module%534407BC014E.includes preserve=yes
//## end module%534407BC014E.includes

#ifndef CXOSLR01_h
#include "CXODLR01.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Context;
class Channel;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%534407BC014E.declarations preserve=no
//## end module%534407BC014E.declarations

//## begin module%534407BC014E.additionalDeclarations preserve=yes
//## end module%534407BC014E.additionalDeclarations


//## begin ClearingFile%534404530125.preface preserve=yes
//## end ClearingFile%534404530125.preface

//## Class: ClearingFile%534404530125
//## Category: DataNavigator Foundation::Application::LogReader_CAT%354B34A1001C
//## Subsystem: LR%3597EB340165
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5344075B0361;database::Channel { -> F}
//## Uses: <unnamed>%53440E63026C;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%53440FB901AA;process::Application { -> F}
//## Uses: <unnamed>%534410E302E8;database::Context { -> F}
//## Uses: <unnamed>%5345940100C1;reusable::Buffer { -> F}
//## Uses: <unnamed>%53459652004C;IF::Extract { -> F}

class DllExport ClearingFile : public LogFile  //## Inherits: <unnamed>%5344046D02EF
{
  //## begin ClearingFile%534404530125.initialDeclarations preserve=yes
  //## end ClearingFile%534404530125.initialDeclarations

  public:
    //## Constructors (generated)
      ClearingFile();

    //## Constructors (specified)
      //## Operation: ClearingFile%53444607004A
      ClearingFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile);

    //## Destructor (generated)
      virtual ~ClearingFile();


    //## Other Operations (specified)
      //## Operation: commit%5344062501C9
      virtual bool commit ();

    // Additional Public Declarations
      //## begin ClearingFile%534404530125.public preserve=yes
      //## end ClearingFile%534404530125.public

  protected:
    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Date%5344063F01AC
      void setDate (const reusable::string& value)
      {
        //## begin ClearingFile::setDate%5344063F01AC.set preserve=no
        m_strDate = value;
        //## end ClearingFile::setDate%5344063F01AC.set
      }


    // Additional Protected Declarations
      //## begin ClearingFile%534404530125.protected preserve=yes
      //## end ClearingFile%534404530125.protected

  private:
    // Additional Private Declarations
      //## begin ClearingFile%534404530125.private preserve=yes
      //## end ClearingFile%534404530125.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Count%534406480350
      //## begin ClearingFile::Count%534406480350.attr preserve=no  private: int {V} 1
      int m_iCount;
      //## end ClearingFile::Count%534406480350.attr

      //## begin ClearingFile::Date%5344063F01AC.attr preserve=no  protected: reusable::string {V} 
      reusable::string m_strDate;
      //## end ClearingFile::Date%5344063F01AC.attr

    // Additional Implementation Declarations
      //## begin ClearingFile%534404530125.implementation preserve=yes
      //## end ClearingFile%534404530125.implementation

};

//## begin ClearingFile%534404530125.postscript preserve=yes
//## end ClearingFile%534404530125.postscript

//## begin module%534407BC014E.epilog preserve=yes
//## end module%534407BC014E.epilog


#endif
