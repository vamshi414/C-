//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%454B48C0037A.cm preserve=no
//	$Date:   May 20 2020 16:46:46  $ $Author:   e1009510  $
//	$Revision:   1.8  $
//## end module%454B48C0037A.cm

//## begin module%454B48C0037A.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%454B48C0037A.cp

//## Module: CXOSLR02%454B48C0037A; Package specification
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\Devel\Dn\Server\Application\Lr\CXODLR02.hpp

#ifndef CXOSLR02_h
#define CXOSLR02_h 1

//## begin module%454B48C0037A.additionalIncludes preserve=no
//## end module%454B48C0037A.additionalIncludes

//## begin module%454B48C0037A.includes preserve=yes
#define NACHA_INPUT_LEN 94
//## end module%454B48C0037A.includes

#ifndef CXOSLR01_h
#include "CXODLR01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Console;
class Queue;
class Message;
class DateTime;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;

} // namespace monitor

//## begin module%454B48C0037A.declarations preserve=no
//## end module%454B48C0037A.declarations

//## begin module%454B48C0037A.additionalDeclarations preserve=yes
//## end module%454B48C0037A.additionalDeclarations


//## begin NACHALogFile%454B36F90213.preface preserve=yes
//## end NACHALogFile%454B36F90213.preface

//## Class: NACHALogFile%454B36F90213
//## Category: DataNavigator Foundation::Application::LogReader_CAT%354B34A1001C
//## Subsystem: LR%3597EB340165
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%454BB47E0138;IF::Console { -> F}
//## Uses: <unnamed>%454FA17F02AF;IF::DateTime { -> F}
//## Uses: <unnamed>%456585620300;IF::Message { -> F}
//## Uses: <unnamed>%456585650245;IF::Queue { -> F}
//## Uses: <unnamed>%456585B6034D;IF::Trace { -> F}
//## Uses: <unnamed>%456AD6530390;monitor::UseCase { -> F}

class DllExport NACHALogFile : public LogFile  //## Inherits: <unnamed>%454B37AC0213
{
  //## begin NACHALogFile%454B36F90213.initialDeclarations preserve=yes
  //## end NACHALogFile%454B36F90213.initialDeclarations

  public:
    //## Constructors (generated)
      NACHALogFile();

    //## Constructors (specified)
      //## Operation: NACHALogFile%4562E58C02B8
      NACHALogFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile);

    //## Destructor (generated)
      virtual ~NACHALogFile();


    //## Other Operations (specified)
      //## Operation: read%458112000317
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward = false, bool bTruncate = false);

      //## Operation: sendBatch%454B383A035B
      bool sendBatch ();

    // Additional Public Declarations
      //## begin NACHALogFile%454B36F90213.public preserve=yes
      //## end NACHALogFile%454B36F90213.public

  protected:
    // Additional Protected Declarations
      //## begin NACHALogFile%454B36F90213.protected preserve=yes
      //## end NACHALogFile%454B36F90213.protected

  private:
    // Additional Private Declarations
      //## begin NACHALogFile%454B36F90213.private preserve=yes
      char m_sFileHeader[NACHA_INPUT_LEN+1];
      //## end NACHALogFile%454B36F90213.private
  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Amount%457FAF8703B3
      //## begin NACHALogFile::Amount%457FAF8703B3.attr preserve=no  private: double {V} 0
      double m_dAmount;
      //## end NACHALogFile::Amount%457FAF8703B3.attr

      //## Attribute: Count%457FAFEB008C
      //## begin NACHALogFile::Count%457FAFEB008C.attr preserve=no  private: int {V} 0
      int m_iCount;
      //## end NACHALogFile::Count%457FAFEB008C.attr

      //## Attribute: Hash%457FAFF90213
      //## begin NACHALogFile::Hash%457FAFF90213.attr preserve=no  private: double {V} 0
      double m_dHash;
      //## end NACHALogFile::Hash%457FAFF90213.attr

    // Additional Implementation Declarations
      //## begin NACHALogFile%454B36F90213.implementation preserve=yes
      //## end NACHALogFile%454B36F90213.implementation

};

//## begin NACHALogFile%454B36F90213.postscript preserve=yes
//## end NACHALogFile%454B36F90213.postscript

//## begin module%454B48C0037A.epilog preserve=yes
//## end module%454B48C0037A.epilog


#endif
