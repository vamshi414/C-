//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%454B49460203.cm preserve=no
//	$Date:   May 20 2020 16:46:46  $ $Author:   e1009510  $
//	$Revision:   1.5  $
//## end module%454B49460203.cm

//## begin module%454B49460203.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%454B49460203.cp

//## Module: CXOSLR03%454B49460203; Package specification
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Application\Lr\CXODLR03.hpp

#ifndef CXOSLR03_h
#define CXOSLR03_h 1

//## begin module%454B49460203.additionalIncludes preserve=no
//## end module%454B49460203.additionalIncludes

//## begin module%454B49460203.includes preserve=yes
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
//## end module%454B49460203.includes

#ifndef CXOSLR09_h
#include "CXODLR09.hpp"
#endif

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Console;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;

} // namespace timer

//## begin module%454B49460203.declarations preserve=no
//## end module%454B49460203.declarations

//## begin module%454B49460203.additionalDeclarations preserve=yes
//## end module%454B49460203.additionalDeclarations


//## begin ISTClearingFile%454B3704004E.preface preserve=yes
//## end ISTClearingFile%454B3704004E.preface

//## Class: ISTClearingFile%454B3704004E
//## Category: DataNavigator Foundation::Application::LogReader_CAT%354B34A1001C
//## Subsystem: LR%3597EB340165
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%454BB48B03D8;IF::Console { -> F}
//## Uses: <unnamed>%456AD70A032D;monitor::UseCase { -> F}
//## Uses: <unnamed>%55E6F2080198;timer::Date { -> F}

class DllExport ISTClearingFile : public ClearingFile  //## Inherits: <unnamed>%55E6DB8E0225
{
  //## begin ISTClearingFile%454B3704004E.initialDeclarations preserve=yes
  //## end ISTClearingFile%454B3704004E.initialDeclarations

  public:
    //## Constructors (generated)
      ISTClearingFile();

    //## Constructors (specified)
      //## Operation: ISTClearingFile%456547BC02B4
      ISTClearingFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile);

    //## Destructor (generated)
      virtual ~ISTClearingFile();


    //## Other Operations (specified)
      //## Operation: read%566113A902D5
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward = false, bool bTruncate = false);

      //## Operation: sendBatch%454B38590128
      bool sendBatch ();

    // Additional Public Declarations
      //## begin ISTClearingFile%454B3704004E.public preserve=yes
      //## end ISTClearingFile%454B3704004E.public

  protected:
    // Additional Protected Declarations
      //## begin ISTClearingFile%454B3704004E.protected preserve=yes
      //## end ISTClearingFile%454B3704004E.protected

  private:
    // Additional Private Declarations
      //## begin ISTClearingFile%454B3704004E.private preserve=yes
      //## end ISTClearingFile%454B3704004E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%4D360C1301ED
      //## begin ISTClearingFile::Buffer%4D360C1301ED.attr preserve=no  private: char[4096] {U} 
      char m_szBuffer[4096];
      //## end ISTClearingFile::Buffer%4D360C1301ED.attr

      //## Attribute: CurrentHashValue%4D360B470224
      //## begin ISTClearingFile::CurrentHashValue%4D360B470224.attr preserve=no  private: double {U} 0
      double m_dCurrentHashValue;
      //## end ISTClearingFile::CurrentHashValue%4D360B470224.attr

      //## Attribute: RecordLength%4D360B0D02BD
      //## begin ISTClearingFile::RecordLength%4D360B0D02BD.attr preserve=no  private: int {U} 0
      int m_lRecordLength;
      //## end ISTClearingFile::RecordLength%4D360B0D02BD.attr

    // Additional Implementation Declarations
      //## begin ISTClearingFile%454B3704004E.implementation preserve=yes
      //## end ISTClearingFile%454B3704004E.implementation

};

//## begin ISTClearingFile%454B3704004E.postscript preserve=yes
//## end ISTClearingFile%454B3704004E.postscript

//## begin module%454B49460203.epilog preserve=yes
//## end module%454B49460203.epilog


#endif
