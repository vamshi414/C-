//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%493461540006.cm preserve=no
//	$Date:   May 20 2020 16:59:34  $ $Author:   e1009510  $
//	$Revision:   1.10  $
//## end module%493461540006.cm

//## begin module%493461540006.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%493461540006.cp

//## Module: CXOSLR05%493461540006; Package body
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\Devel\Dn\Server\Application\Lr\CXOSLR05.cpp

//## begin module%493461540006.additionalIncludes preserve=no
//## end module%493461540006.additionalIncludes

//## begin module%493461540006.includes preserve=yes
#include "CXODRS58.hpp"
#include "CXODPF05.hpp"
//## end module%493461540006.includes

#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSLR05_h
#include "CXODLR05.hpp"
#endif


//## begin module%493461540006.declarations preserve=no
//## end module%493461540006.declarations

//## begin module%493461540006.additionalDeclarations preserve=yes
//## end module%493461540006.additionalDeclarations


// Class TransactionActivityLogFile

TransactionActivityLogFile::TransactionActivityLogFile()
  //## begin TransactionActivityLogFile::TransactionActivityLogFile%493460D102A6_const.hasinit preserve=no
      : m_iDataLength(0)
  //## end TransactionActivityLogFile::TransactionActivityLogFile%493460D102A6_const.hasinit
  //## begin TransactionActivityLogFile::TransactionActivityLogFile%493460D102A6_const.initialization preserve=yes
  //## end TransactionActivityLogFile::TransactionActivityLogFile%493460D102A6_const.initialization
{
  //## begin TransactionActivityLogFile::TransactionActivityLogFile%493460D102A6_const.body preserve=yes
   memcpy(m_sID,"LR05",4);
  //## end TransactionActivityLogFile::TransactionActivityLogFile%493460D102A6_const.body
}

TransactionActivityLogFile::TransactionActivityLogFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile)
  //## begin TransactionActivityLogFile::TransactionActivityLogFile%49355FE9004C.hasinit preserve=no
      : m_iDataLength(0)
  //## end TransactionActivityLogFile::TransactionActivityLogFile%49355FE9004C.hasinit
  //## begin TransactionActivityLogFile::TransactionActivityLogFile%49355FE9004C.initialization preserve=yes
   ,LogFile(strIMAGEID,strTASKID,pszName,bVariableBlockFile)
  //## end TransactionActivityLogFile::TransactionActivityLogFile%49355FE9004C.initialization
{
  //## begin TransactionActivityLogFile::TransactionActivityLogFile%49355FE9004C.body preserve=yes
   memcpy(m_sID,"LR05",4);
  //## end TransactionActivityLogFile::TransactionActivityLogFile%49355FE9004C.body
}


TransactionActivityLogFile::~TransactionActivityLogFile()
{
  //## begin TransactionActivityLogFile::~TransactionActivityLogFile%493460D102A6_dest.body preserve=yes
  //## end TransactionActivityLogFile::~TransactionActivityLogFile%493460D102A6_dest.body
}



//## Other Operations (implementation)
bool TransactionActivityLogFile::read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward, bool bTruncate)
{
  //## begin TransactionActivityLogFile::read%493462850163.body preserve=yes
   if (!GenerationDataGroup::read(psBuffer,lBufferLength,plRecordLength,bFastForward))
      return false;
   if (!bFastForward)
   {
      if (memcmp(psBuffer,"ICC",3) != 0)
         m_hTransactionActivityFile.expand(psBuffer,plRecordLength);
      return true;
   }
   //handle fast forward
   if (memcmp(psBuffer,"ICC",3) != 0 ) //not an ICC record
   {
      memcpy(m_szSendBuffer,psBuffer,*plRecordLength);
      m_iDataLength = *plRecordLength;
   }
   else
   {
      memcpy(m_szSendBuffer+m_iDataLength,psBuffer,*plRecordLength);
      m_iDataLength += *plRecordLength;
   }
   return true;
  //## end TransactionActivityLogFile::read%493462850163.body
}

bool TransactionActivityLogFile::sendBatch ()
{
  //## begin TransactionActivityLogFile::sendBatch%493462850172.body preserve=yes
   UseCase hUseCase("LOG","## LR05 SEND BATCH");
   Message::instance(Message::OUTBOUND)->reset("LR AI ","S0059D");
   m_iRecordsRead = 0;
   size_t m = 0;
   while (read(m_szReadBuffer,16384,&m))
   {
      //filter out non transaction data
      struct segTransactionActivity* pDetail = (struct segTransactionActivity*)m_szReadBuffer;
      if ((memcmp(m_szReadBuffer,"ICC",3) != 0 && m < 95) ||
         (memcmp(m_szReadBuffer,"ICC",3) != 0 && pDetail->sTSTAMP_TRANS[0] == ' ' ) ||
         memcmp(m_szReadBuffer,"FH",2) == 0   ||
         memcmp(m_szReadBuffer,"FT",2) == 0  ||
         memcmp(m_szReadBuffer,"Status",6) == 0)
         continue;

      m_iRecordsRead++;
      if (memcmp(m_szReadBuffer,"ICC",3) != 0 && //not an ICC record
         m_iDataLength > 0        ) //and previous record to send exists
      {
         segTransactionActivity* pTransactionActivity = (segTransactionActivity*)m_szSendBuffer;
         if (!send())
            return UseCase::setSuccess(false);
      }
      memcpy(m_szSendBuffer+m_iDataLength,m_szReadBuffer,m);
      m_iDataLength += m;
      if (m_iRecordsRead == m_iBatchSize)
         return true;
   }
   if (m_iDataLength > 0)
      if (!send())
         return UseCase::setSuccess(false);
   return true;
  //## end TransactionActivityLogFile::sendBatch%493462850172.body
}

bool TransactionActivityLogFile::send ()
{
  //## begin TransactionActivityLogFile::send%49358148023B.body preserve=yes
   char* pDetail = (char*)Message::instance(Message::OUTBOUND)->data();
   memcpy(pDetail,m_szSendBuffer,m_iDataLength);
   Message::instance(Message::OUTBOUND)->setDataLength((unsigned short)m_iDataLength);
   if (Message::instance(Message::OUTBOUND)->send(m_strQueueName.c_str()) != 0)
      return UseCase::setSuccess(false);
   UseCase::addItem();
   if (m_dHashTotal == -1)
      m_dHashTotal = 0;
   segTransactionActivity* pTransactionActivity = (segTransactionActivity*)Message::instance(Message::OUTBOUND)->data();
   string strTempHash(pTransactionActivity->sTSTAMP_LOCAL+8,6);
   m_dHashTotal += atol(strTempHash.c_str());
   m_iDataLength = 0;
   return true;
  //## end TransactionActivityLogFile::send%49358148023B.body
}

// Additional Declarations
  //## begin TransactionActivityLogFile%493460D102A6.declarations preserve=yes
  //## end TransactionActivityLogFile%493460D102A6.declarations

//## begin module%493461540006.epilog preserve=yes
//## end module%493461540006.epilog
