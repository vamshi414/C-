//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%454B47140261.cm preserve=no
//	$Date:   Jun 22 2020 19:19:32  $ $Author:   e1009839  $
//	$Revision:   1.20  $
//## end module%454B47140261.cm

//## begin module%454B47140261.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%454B47140261.cp

//## Module: CXOSLR01%454B47140261; Package specification
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\Devel\Dn\Server\Application\Lr\CXODLR01.hpp

#ifndef CXOSLR01_h
#define CXOSLR01_h 1

//## begin module%454B47140261.additionalIncludes preserve=no
//## end module%454B47140261.additionalIncludes

//## begin module%454B47140261.includes preserve=yes
#ifdef _WIN32
#include <winsock.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#include "CXODSI05.hpp"
#include "CXODRU11.hpp"
#define FIS_CONNEX_ON_HP 0
#define FIS_CONNEX_ON_IBM 1
#define ACI_POSTILION 2
#define ACI_BASE24 3
#define FIS_GENERIC 4
#define FIS_IST 5
#define VISA_BASE_II 6
#define FIS_ACH 7
#define FIS_TRANSACTION_ACTIVITY 8
#define MASTERCARD_IPM 9
#define FIS_MAS 10
#define MASTERCARD_DCF 11
//## end module%454B47140261.includes

#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif
#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class ExternalMessageSegment;
} // namespace repositorysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Queue;
class Message;
class DateTime;
class Trace;
class Extract;
class Console;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%454B47140261.declarations preserve=no
//## end module%454B47140261.declarations

//## begin module%454B47140261.additionalDeclarations preserve=yes
//## end module%454B47140261.additionalDeclarations


//## begin LogFile%454B30B1009C.preface preserve=yes
//## end LogFile%454B30B1009C.preface

//## Class: LogFile%454B30B1009C
//## Category: DataNavigator Foundation::Application::LogReader_CAT%354B34A1001C
//## Subsystem: LR%3597EB340165
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%454BAA4C0138;database::Database { -> F}
//## Uses: <unnamed>%454BAA5A032C;IF::Console { -> F}
//## Uses: <unnamed>%454BAA6403B9;IF::Trace { -> F}
//## Uses: <unnamed>%454BAEB00109;IF::DateTime { -> F}
//## Uses: <unnamed>%454FA07D033C;repositorysegment::ExternalMessageSegment { -> F}
//## Uses: <unnamed>%454FA9D80138;timer::Date { -> F}
//## Uses: <unnamed>%4558A93B0213;IF::Queue { -> F}
//## Uses: <unnamed>%45700BE300F2;monitor::UseCase { -> F}
//## Uses: <unnamed>%45B81A7502BF;IF::Extract { -> F}
//## Uses: <unnamed>%45B915790271;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%45BA30C0029F;process::Application { -> F}
//## Uses: <unnamed>%45BA31FD02DE;IF::Message { -> F}
//## Uses: <unnamed>%45C256F303C8;timer::Clock { -> F}
//## Uses: <unnamed>%5849C6CC00A1;reusable::Query { -> F}

class DllExport LogFile : public database::GenerationDataGroup  //## Inherits: <unnamed>%454B32EC0203
{
  //## begin LogFile%454B30B1009C.initialDeclarations preserve=yes
  //## end LogFile%454B30B1009C.initialDeclarations

  public:
    //## Constructors (generated)
      LogFile();

    //## Constructors (specified)
      //## Operation: LogFile%454BA4130109
      LogFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile);

    //## Destructor (generated)
      virtual ~LogFile();


    //## Other Operations (specified)
      //## Operation: onMessage%454B349A035B
      virtual int onMessage (Message& hMessage);

      //## Operation: onResume%454B34C3005D
      virtual bool onResume (Message& hMessage);

      //## Operation: update%454B34F80399
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: InputType%4558ABBD0213
      void setInputType (int value)
      {
        //## begin LogFile::setInputType%4558ABBD0213.set preserve=no
        m_iInputType = value;
        //## end LogFile::setInputType%4558ABBD0213.set
      }


      //## Attribute: Limit%5849C868007A
      void setLimit (int value)
      {
        //## begin LogFile::setLimit%5849C868007A.set preserve=no
        m_lLimit = value;
        //## end LogFile::setLimit%5849C868007A.set
      }


    // Additional Public Declarations
      //## begin LogFile%454B30B1009C.public preserve=yes
      //## end LogFile%454B30B1009C.public

  protected:

    //## Other Operations (specified)
      //## Operation: abort%45BA71910177
      bool abort ();

      //## Operation: onNotify%454B34A802AF
      virtual int onNotify (const char* pszQueueName);

      //## Operation: sendBatch%454B34D6032C
      virtual bool sendBatch ();

      //## Operation: sendHashRequest%454B350A0000
      virtual bool sendHashRequest ();

      //## Operation: sendZeroHash%454B34E80119
      virtual bool sendZeroHash ();

    // Data Members for Class Attributes

      //## Attribute: BatchSize%4558D9A502BF
      //## begin LogFile::BatchSize%4558D9A502BF.attr preserve=no  public: int {U} 500
      int m_iBatchSize;
      //## end LogFile::BatchSize%4558D9A502BF.attr

      //## Attribute: CONTEXT_DATA%5849C98702E8
      //## begin LogFile::CONTEXT_DATA%5849C98702E8.attr preserve=no  protected: string {VA}
      string m_strCONTEXT_DATA;
      //## end LogFile::CONTEXT_DATA%5849C98702E8.attr

      //## Attribute: Count%5849CAC00182
      //## begin LogFile::Count%5849CAC00182.attr preserve=no  public: int {V} 0
      int m_lCount;
      //## end LogFile::Count%5849CAC00182.attr

      //## Attribute: HashTotal%45B90E370399
      //## begin LogFile::HashTotal%45B90E370399.attr preserve=no  protected: double {VA} 0
      double m_dHashTotal;
      //## end LogFile::HashTotal%45B90E370399.attr

      //## begin LogFile::InputType%4558ABBD0213.attr preserve=no  public: int {V} 0
      int m_iInputType;
      //## end LogFile::InputType%4558ABBD0213.attr

      //## begin LogFile::Limit%5849C868007A.attr preserve=no  public: int {V} 99
      int m_lLimit;
      //## end LogFile::Limit%5849C868007A.attr

      //## Attribute: QueueName%45BA3264033C
      //## begin LogFile::QueueName%45BA3264033C.attr preserve=no  protected: string {VA}
      string m_strQueueName;
      //## end LogFile::QueueName%45BA3264033C.attr

      //## Attribute: RecordsRead%45BA3285002E
      //## begin LogFile::RecordsRead%45BA3285002E.attr preserve=no  private: int {V} 0
      int m_iRecordsRead;
      //## end LogFile::RecordsRead%45BA3285002E.attr

      //## Attribute: SeqNo%454FA8550290
      //## begin LogFile::SeqNo%454FA8550290.attr preserve=no  private: int {V} 0
      int m_lSeqNo;
      //## end LogFile::SeqNo%454FA8550290.attr

      //## Attribute: TargetBatchSize%45ADC83B00D1
      //## begin LogFile::TargetBatchSize%45ADC83B00D1.attr preserve=no  public: int {V} 500
      int m_iTargetBatchSize;
      //## end LogFile::TargetBatchSize%45ADC83B00D1.attr

      //## Attribute: TASKID%5850621D00E8
      //## begin LogFile::TASKID%5850621D00E8.attr preserve=no  protected: string {VA}
      string m_strTASKID;
      //## end LogFile::TASKID%5850621D00E8.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LogReader_CAT::<unnamed>%454B998800FA
      //## Role: LogFile::<m_hTimer>%454B9989002E
      //## begin LogFile::<m_hTimer>%454B9989002E.role preserve=no  public: timer::Timer { -> 1VHgN}
      timer::Timer m_hTimer;
      //## end LogFile::<m_hTimer>%454B9989002E.role

    // Additional Protected Declarations
      //## begin LogFile%454B30B1009C.protected preserve=yes
      reusable::Query m_hQuery;
      //## end LogFile%454B30B1009C.protected
  private:
    // Additional Private Declarations
      //## begin LogFile%454B30B1009C.private preserve=yes
      //## end LogFile%454B30B1009C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: IsB24ATM%4C349A1400B1
      //## begin LogFile::IsB24ATM%4C349A1400B1.attr preserve=no  private: bool {U} false
      bool m_bIsB24ATM;
      //## end LogFile::IsB24ATM%4C349A1400B1.attr

      //## Attribute: Delayed%586563E9015B
      //## begin LogFile::Delayed%586563E9015B.attr preserve=no  private: bool {U} false
      bool m_bDelayed;
      //## end LogFile::Delayed%586563E9015B.attr

      //## Attribute: ExtractRestartTime%51DEDC5A02D9
      //## begin LogFile::ExtractRestartTime%51DEDC5A02D9.attr preserve=no  private: int {U} 15
      int m_iExtractRestartTime;
      //## end LogFile::ExtractRestartTime%51DEDC5A02D9.attr

      //## Attribute: Force%585062AE0293
      //## begin LogFile::Force%585062AE0293.attr preserve=no  private: bool {U} false
      bool m_bForce;
      //## end LogFile::Force%585062AE0293.attr

      //## Attribute: Restart%51DEDC5402B8
      //## begin LogFile::Restart%51DEDC5402B8.attr preserve=no  private: int {U} 0
      int m_iRestart;
      //## end LogFile::Restart%51DEDC5402B8.attr

      //## Attribute: Rollback%45BE92290177
      //## begin LogFile::Rollback%45BE92290177.attr preserve=no  private: int {V} 300
      int m_iRollback;
      //## end LogFile::Rollback%45BE92290177.attr

    // Additional Implementation Declarations
      //## begin LogFile%454B30B1009C.implementation preserve=yes
      //## end LogFile%454B30B1009C.implementation

};

//## begin LogFile%454B30B1009C.postscript preserve=yes
#include "CXODRU32.hpp"
struct hMCIPMHeader
{
   char sMTI[4];
   unsigned char sBitmap[16];
   char sFiller1[11];
   char sHashVal[4];
};
// Standard IBM Header
struct hIBMHeader
{
   char sHdrStck[4];
   unsigned int lHdrStckHash;
   char sHdrProcName[8];
   char sHdrMessageID[5];
   //char sStdHeaderFiller[95];
   char cRetryCode;
   char sRejectRsn[18];
   char sStationID[8];
   char sLuName[8];
   char cFlag;
   char sFiller2[7];
   short siDataLength;
   char sDataFormat[2];                // '03' for V3.4 '05' for V3.5
   char sBitMap[16];
   char sConnexBitMap[32];
   char sMSGID[5];
};

// Standard Base24 TLF/PTLF Header
struct hBase24Header
{
   int lHdrTstamp[2];
   char sTypeRec[2];
};

// Standard Base24 TLF/PTLF File Header
struct hBase24FileHeader
{
   char sTypeRec[2];
   char cCharSet;
   char sExtractDateTime[14];
};

struct hCheckPointRecord
{
   int lLastVerifiedRecRead;
   int lLastVerifiedRecSent;
   int lLastVerifiedReqSeqNo;
};

// Standard Oasis OCS File Header
struct hOasisFileHeader
{
   char sRecordType[3];
   char sFieldId[6];
   char sFieldLen[3];
   char sSourceId[10];
   char cFiller1;
   char sProcessingDate[5];
   char cFiller2;
   char sSequenceNo[2];
   char cFiller3;
   char sRepeatInd[1];
};
// Standard Oasis OCS Record Header
struct hOasisRecordHeader
{
   char sRecordType[3];
   char sFieldId[6];
   char sFieldLen[3];
   char sTranSeqNum[12];
};
#include "CXODRU33.hpp"

// IST Record

struct hISTFinancial
{
   int msgtype;
   int flipped_msgtype;
   char pan[20];
   int pcode;                          // Bit 3 - Processing code
   int txntype;
   char fill1[4];
   char amount[16];                    // Bit 4 - Value amount transaction
   char aval_balance[16];              // Bit 54-3.3 - Value amount additional amounts
   char amount_equiv[16];              // Bit 6-3 - Value amount cardholder billing
   char cash_back[16];                 // Bit 54-3 - Value amount additional amounts
   char iss_conv_rate[16];             // Bit 9 - Conversion rate reconciliation (issuer)
   int iss_currency_code;              // Bit 97-1 - Currency code amount net reconciliation (issuer)
   int iss_conv_date;                  // Bit 16 - Date conversion (issuer)
   char acq_conv_rate[16];             // Bit 16 - Conversion rate reconciliation (acquirer)
   int acq_currency_code;              // Bit 4-1 - Currency code amount transaction
   int acq_conv_date;                  // Bit 16 - Date conversion (acquirer)
   char tra_amount[16];
   char tra_conv_rate[16];
   int tra_currency_code;
   int tra_conv_date;
   char fee[16];                       // Reconciliation fee (issuer)
   char new_fee[16];                   // Reconciliation fee (net)
   char new_amount[16];                // Bit 4-3 - Value amount transaction
   char new_setl_amount[16];           // Bit 5-3 - Value amount reconciliation
   char settlement_fee[16];            // Reconciliation fee (net)
   char settlement_rate[16];           // Bit 9 - Conversion rate reconciliation (net)
   int settlement_code;                // Bit 5-1 - Currency code amount reconciliation
   char fill2[4];
   char settlement_amount[16];         // Bit 5-3 - Value amount reconciliation
   int trandate;                       // Bit 7 - Date and time transmission
   int trantime;                       // Bit 7 - Date and time transmission
   // ...
};
//## end LogFile%454B30B1009C.postscript

//## begin module%454B47140261.epilog preserve=yes
//## end module%454B47140261.epilog


#endif
