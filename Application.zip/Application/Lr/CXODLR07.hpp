//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%515DF0800011.cm preserve=no
//	$Date:   May 20 2020 16:52:42  $ $Author:   e1009510  $
//	$Revision:   1.1  $
//## end module%515DF0800011.cm

//## begin module%515DF0800011.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%515DF0800011.cp

//## Module: CXOSLR07%515DF0800011; Package specification
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\bV02.3B.R001\Windows\Build\Dn\Server\Application\Lr\CXODLR07.hpp

#ifndef CXOSLR07_h
#define CXOSLR07_h 1

//## begin module%515DF0800011.additionalIncludes preserve=no
//## end module%515DF0800011.additionalIncludes

//## begin module%515DF0800011.includes preserve=yes
//## end module%515DF0800011.includes

#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
#ifndef CXOSLR01_h
#include "CXODLR01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class CodeTable;
class Message;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Mask;
class KeyRing;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DESKey;

} // namespace database

//## begin module%515DF0800011.declarations preserve=no
//## end module%515DF0800011.declarations

//## begin module%515DF0800011.additionalDeclarations preserve=yes
//## end module%515DF0800011.additionalDeclarations


//## begin ConnexNonStopLogFile%515DEFF8024F.preface preserve=yes
//## end ConnexNonStopLogFile%515DEFF8024F.preface

//## Class: ConnexNonStopLogFile%515DEFF8024F
//## Category: DataNavigator Foundation::Application::LogReader_CAT%354B34A1001C
//## Subsystem: LR%3597EB340165
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%515EE2F101EC;IF::Message { -> F}
//## Uses: <unnamed>%515EE2FD0313;monitor::UseCase { -> F}
//## Uses: <unnamed>%515EE3010352;IF::CodeTable { -> F}
//## Uses: <unnamed>%515EE3070282;IF::Trace { -> F}
//## Uses: <unnamed>%515EE30B00AA;reusable::KeyRing { -> F}
//## Uses: <unnamed>%515EEC4801DB;database::DESKey { -> F}
//## Uses: <unnamed>%515EECC202E6;reusable::Mask { -> F}

class DllExport ConnexNonStopLogFile : public LogFile  //## Inherits: <unnamed>%515DF0150158
{
  //## begin ConnexNonStopLogFile%515DEFF8024F.initialDeclarations preserve=yes
  //## end ConnexNonStopLogFile%515DEFF8024F.initialDeclarations

  public:
    //## Constructors (generated)
      ConnexNonStopLogFile();

    //## Constructors (specified)
      //## Operation: ConnexNonStopLogFile%515ECF8B009B
      ConnexNonStopLogFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile);

    //## Destructor (generated)
      virtual ~ConnexNonStopLogFile();


    //## Other Operations (specified)
      //## Operation: read%515DF0420053
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward = false, bool bTruncate = false);

    // Additional Public Declarations
      //## begin ConnexNonStopLogFile%515DEFF8024F.public preserve=yes
      //## end ConnexNonStopLogFile%515DEFF8024F.public

  protected:

    //## Other Operations (specified)
      //## Operation: sendBatch%515DF035012B
      virtual bool sendBatch ();

    // Additional Protected Declarations
      //## begin ConnexNonStopLogFile%515DEFF8024F.protected preserve=yes
      //## end ConnexNonStopLogFile%515DEFF8024F.protected

  private:
    // Additional Private Declarations
      //## begin ConnexNonStopLogFile%515DEFF8024F.private preserve=yes
      //## end ConnexNonStopLogFile%515DEFF8024F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: SizeOf2400%515EEE3300EB
      //## begin ConnexNonStopLogFile::SizeOf2400%515EEE3300EB.attr preserve=no  private: int {V} 0
      int m_iSizeOf2400;
      //## end ConnexNonStopLogFile::SizeOf2400%515EEE3300EB.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LogReader_CAT::<unnamed>%515EE3420248
      //## Role: ConnexNonStopLogFile::<m_hMemory>%515EE344013B
      //## begin ConnexNonStopLogFile::<m_hMemory>%515EE344013B.role preserve=no  public: IF::Memory { -> VHgN}
      IF::Memory m_hMemory;
      //## end ConnexNonStopLogFile::<m_hMemory>%515EE344013B.role

    // Additional Implementation Declarations
      //## begin ConnexNonStopLogFile%515DEFF8024F.implementation preserve=yes
      //## end ConnexNonStopLogFile%515DEFF8024F.implementation

};

//## begin ConnexNonStopLogFile%515DEFF8024F.postscript preserve=yes
//## end ConnexNonStopLogFile%515DEFF8024F.postscript

//## begin module%515DF0800011.epilog preserve=yes
//## end module%515DF0800011.epilog


#endif
