//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%454B4723038A.cm preserve=no
//	$Date:   May 12 2021 06:44:38  $ $Author:   e3022417  $
//	$Revision:   1.49  $
//## end module%454B4723038A.cm

//## begin module%454B4723038A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%454B4723038A.cp

//## Module: CXOSLR01%454B4723038A; Package body
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\Devel\Dn\Server\Application\Lr\CXOSLR01.cpp

//## begin module%454B4723038A.additionalIncludes preserve=no
//## end module%454B4723038A.additionalIncludes

//## begin module%454B4723038A.includes preserve=yes
#include <algorithm>
#ifdef _WIN32
#include <winsock.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
#ifndef CXOSRS58_h
#include "CXODRS58.hpp"
#endif
#include "CXODIP30.hpp" //segADAMTv34 and segADAMTv35
#include "CXODIP31.hpp" //segTHI
#include "CXODIP25.hpp" //hIBMImmV340
#include "CXODIP26.hpp" //hIBMImmV350
#include "CXODRU12.hpp"
#include "CXODRU37.hpp" //Mask
#include "CXODMN02.hpp"
#include "CXODOP00.hpp" //IST headers
#include "CXODOP12.hpp"
#include "CXODOP13.hpp"
#include "CXODOP19.hpp"
#include "CXODPP02.hpp"
#include "CXODIF04.hpp"
#include "CXODVP04.hpp"
#include "CXODIF26.hpp"
#include "CXODDB02.hpp"
#include "CXODDB37.hpp" //DESKey
#include "CXODRU40.hpp" //KeyRing
#include "CXODRU34.hpp"
#ifndef CXOSBP07_h
#include "CXODBP07.hpp"
#endif
#ifndef CXOSBP11_h
#include "CXODBP11.hpp"
#endif
#ifndef CXOSKP03_HPP
#include "CXODKP03.hpp"
#endif

//## end module%454B4723038A.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSRS12_h
#include "CXODRS12.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSLR01_h
#include "CXODLR01.hpp"
#endif


//## begin module%454B4723038A.declarations preserve=no
//## end module%454B4723038A.declarations

//## begin module%454B4723038A.additionalDeclarations preserve=yes
//## end module%454B4723038A.additionalDeclarations


// Class LogFile

LogFile::LogFile()
  //## begin LogFile::LogFile%454B30B1009C_const.hasinit preserve=no
      : m_bIsB24ATM(false),
        m_iBatchSize(500),
        m_lCount(0),
        m_bDelayed(false),
        m_iExtractRestartTime(15),
        m_bForce(false),
        m_dHashTotal(0),
        m_iInputType(0),
        m_lLimit(99),
        m_iRecordsRead(0),
        m_iRestart(0),
        m_iRollback(300),
        m_lSeqNo(0),
        m_iTargetBatchSize(500)
  //## end LogFile::LogFile%454B30B1009C_const.hasinit
  //## begin LogFile::LogFile%454B30B1009C_const.initialization preserve=yes
  //## end LogFile::LogFile%454B30B1009C_const.initialization
{
  //## begin LogFile::LogFile%454B30B1009C_const.body preserve=yes
   memcpy(m_sID,"LR01",4);
   string strB24RecordType;
   Extract::instance()->getRecord("DUSER   ",strB24RecordType);
   if (strB24RecordType.find("B24ATM") != string::npos)
      m_bIsB24ATM = true;
   int i = 0;
   string strRecord;
   while (Extract::instance()->getRecord(i++,strRecord))
   {
      if (strRecord.length() > 19
         && strRecord.substr(0,16) == "DSPEC   LRLIMIT ")
      {
         int lLimit = atoi(strRecord.substr(16,4).c_str());
         if (lLimit > 0 && lLimit < 100)
            m_lLimit = lLimit;
      }
   }
   m_hQuery.attach(this);
  //## end LogFile::LogFile%454B30B1009C_const.body
}

LogFile::LogFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile)
  //## begin LogFile::LogFile%454BA4130109.hasinit preserve=no
      : m_bIsB24ATM(false),
        m_iBatchSize(500),
        m_lCount(0),
        m_bDelayed(false),
        m_iExtractRestartTime(15),
        m_bForce(false),
        m_dHashTotal(0),
        m_iInputType(0),
        m_lLimit(99),
        m_iRecordsRead(0),
        m_iRestart(0),
        m_iRollback(300),
        m_lSeqNo(0),
        m_iTargetBatchSize(500)
  //## end LogFile::LogFile%454BA4130109.hasinit
  //## begin LogFile::LogFile%454BA4130109.initialization preserve=yes
        ,GenerationDataGroup(strIMAGEID,strTASKID,pszName,bVariableBlockFile)
  //## end LogFile::LogFile%454BA4130109.initialization
{
  //## begin LogFile::LogFile%454BA4130109.body preserve=yes
   memcpy(m_sID,"LR01",4);
   string strB24RecordType;
   Extract::instance()->getRecord("DUSER   ",strB24RecordType);
   if (strB24RecordType.find("B24ATM") != string::npos)
      m_bIsB24ATM = true;
   int i = 0;
   string strRecord;
   while (Extract::instance()->getRecord(i++,strRecord))
   {
      if (strRecord.length() > 19
         && strRecord.substr(0,16) == "DSPEC   LRLIMIT ")
      {
         int lLimit = atoi(strRecord.substr(16,4).c_str());
         if (lLimit > 0 && lLimit < 100)
            m_lLimit = lLimit;
      }
   }
   if (Extract::instance()->getRecord("DQUEUE  AI",strRecord))
      m_strQueueName.assign(strRecord.data() + 16,6);
   else
   {
      m_strQueueName = Application::instance()->name();
      m_strQueueName.replace(2,2,"AI");
   }
   m_strQueueName.resize(m_strQueueName[5] == ' ' ? 5 : 6);
   Queue::observe(m_strQueueName.c_str());
   int iBatchSize = 0;
   if (Extract::instance()->getLong("DUSER   ","BATCH=",&iBatchSize))
   {
      if (iBatchSize < 5)
         m_iBatchSize = 5;
      else
      if (iBatchSize > 5000)
         m_iBatchSize = 5000;
      else
         m_iBatchSize = iBatchSize;
   }
   m_iTargetBatchSize = m_iBatchSize;
   i = 0;
   if ((i = Extract::instance()->getTimer("ROLLBACK")) != -1)
      m_iRollback = i;
   Message::instance(Message::INBOUND)->attach(this);
   MinuteTimer::instance()->attach(this);
   m_hTimer.attach(this);
   m_hQuery.attach(this);
   Application::instance()->setQueueWaitOption(false);
  //## end LogFile::LogFile%454BA4130109.body
}


LogFile::~LogFile()
{
  //## begin LogFile::~LogFile%454B30B1009C_dest.body preserve=yes
   MinuteTimer::instance()->detach(this);
   Message::instance(Message::INBOUND)->detach(this);
  //## end LogFile::~LogFile%454B30B1009C_dest.body
}



//## Other Operations (implementation)
bool LogFile::abort ()
{
  //## begin LogFile::abort%45BA71910177.body preserve=yes
   close();
   m_dHashTotal = -1;
   ++m_lSeqNo; // keeps late ACK in onMessage from prematurely commiting the current file
   Database::instance()->rollback();
   return UseCase::setSuccess(false);
  //## end LogFile::abort%45BA71910177.body
}

int LogFile::onMessage (Message& hMessage)
{
  //## begin LogFile::onMessage%454B349A035B.body preserve=yes
   if (hMessage.messageID() != IString("S0060R"))
      return 0;
   hHashMessage* pResponse = (hHashMessage*)hMessage.data();
   if (pResponse->lSeqNo != m_lSeqNo) // late ACK/NAK ... ignore
      return 0;
   UseCase hUseCase("LOG","## LG26 CHECK HASH");
   m_hTimer.cancel();
   if (pResponse->cStatusFlag == 'Y')
   {
      if (m_dHashTotal != -1)
      {
         if (!checkPoint(m_iRecordsRead))
            return abort();
         Database::instance()->commit();
         if (!sendHashRequest())
            return abort();
         if (m_iRecordsRead >= m_iBatchSize) // not at end of file
         {
            m_iBatchSize = m_iTargetBatchSize;
            return (sendBatch()) ? 0 : abort();
         }
         m_iBatchSize = m_iTargetBatchSize;
         m_iRecordsRead = 0;
         return 0;
      }
      commit();
      Database::instance()->commit();
      m_iBatchSize = m_iTargetBatchSize;
      Application::instance()->setQueueWaitOption(false);
      return 0;
   }
   if (m_iBatchSize > 16)
      m_iBatchSize /= 2;
   return (int)abort();
  //## end LogFile::onMessage%454B349A035B.body
}

int LogFile::onNotify (const char* pszQueueName)
{
  //## begin LogFile::onNotify%454B34A802AF.body preserve=yes
   if (getProgress() != 0)
      abort();
   return 0;
  //## end LogFile::onNotify%454B34A802AF.body
}

bool LogFile::onResume (Message& hMessage)
{
  //## begin LogFile::onResume%454B34C3005D.body preserve=yes
   Application::instance()->setQueueWaitOption(true);
   if (getProgress() > 0)
      return false;
   if (!open()) // no file available
   {
      Database::instance()->commit();
      return true;
   }
   UseCase hUseCase("LOG","## LG22 START FILE");
   if (!sendZeroHash())
      return abort();
   if (!sendBatch())
      return abort();
   if (m_dHashTotal == -1) // found empty file
   {
      commit();
      Database::instance()->commit();
      Application::instance()->setQueueWaitOption(false);
      return true;
   }
   if (!sendHashRequest())
      return abort();
   if (m_iRecordsRead < m_iBatchSize) // reached end of file
      return true;
   if (!sendBatch())
      return abort();
   return true;
  //## end LogFile::onResume%454B34C3005D.body
}

bool LogFile::sendBatch ()
{
  //## begin LogFile::sendBatch%454B34D6032C.body preserve=yes
   UseCase hUseCase("LOG","## LG24 SEND BATCH");
   Message* pMessage = Message::instance(Message::OUTBOUND);
   pMessage->reset("LR AI ","S0059D");
   hIBMHeader* pIBMHeader = (hIBMHeader*)pMessage->data();
   hBase24Header* pB24Record = (hBase24Header*)pMessage->data();
   char* ExternalMsg = pMessage->data();
   hBase24FileHeader* pB24FHRecord = (hBase24FileHeader*)pMessage->data();
   hISTFinancial* pISTFinancial = (hISTFinancial*)pMessage->data();
   hPostilionFinancial* pPostilionFinancial = (hPostilionFinancial*)pMessage->data();
   segTransactionActivity* pTransactionActivity = (segTransactionActivity*)pMessage->data();
   hRGNS_Visa_BaseII* pBaseIIRecord = (hRGNS_Visa_BaseII*)pMessage->data();
   hMCIPMHeader* pMCIPMHeader = (hMCIPMHeader*)pMessage->data();
   segMAS* psegMAS = (segMAS*)pMessage->data();
   int lBufferLength = pMessage->bufferLength() - (pMessage->data() - pMessage->buffer());
   char sB24ExtractDateTime[17] = {"0000000000000000"};
   char sCentury[2];
   m_iRecordsRead = 0;
   int m = 0;
   while (read(pMessage->data(),lBufferLength,&m))
   {
      m_iRecordsRead++;
      char szEyeCatcher[7] = {0x3E,0x44,0x53,0x53,0x2A,0x3C};  //ascii  ">DSS*<"
      if (m > sizeof(struct encryptionHeader)
         && memcmp(pMessage->data(),szEyeCatcher,6) == 0)
      {
         struct encryptionHeader* pHeader = (struct encryptionHeader*)pMessage->data();
         string strKeyId("DK");
         strKeyId.append(pHeader->checkDigits,4);
#ifdef MVS
         if (KeyRing::instance()->isICSF()) //hardware encryption specified
         {
            strKeyId.assign("IBM");
            strKeyId.append(pHeader->checkDigits,4);
            CodeTable::translate((char*)strKeyId.data()+3,4,CodeTable::CX_ASCII_TO_EBCDIC);
         }
         else
            CodeTable::translate((char*)strKeyId.data()+2,4,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
         DESKey* pKey = (DESKey*)KeyRing::instance()->getKey(strKeyId);
         if (pKey)
         {
            short sLength = pHeader->version == 256 ? ntohs(pHeader->recordLength) : pHeader->recordLength;
            string strDATA(pMessage->data()+sizeof(struct encryptionHeader),m-sizeof(struct encryptionHeader));
            pKey->decrypt(strDATA);
            m = sLength;
            memcpy(pMessage->data(),strDATA.data(),sLength);
         }
      }
      pMessage->setDataLength(m);
      if ((m_iInputType == ACI_BASE24)
         && ((memcmp(pB24FHRecord->sTypeRec,"TH",2) == 0)
         || (memcmp(pB24FHRecord->sTypeRec,"FH",2) == 0)))
      {
         DateTime::calcCentury(pB24FHRecord->sExtractDateTime,sCentury);
         memcpy(sB24ExtractDateTime,sCentury,2);
         memcpy(sB24ExtractDateTime+2,pB24FHRecord->sExtractDateTime,sizeof(pB24FHRecord->sExtractDateTime));
      }
      if (m_iInputType == ACI_POSTILION)
      {
         ;
      }
      if (m_iInputType == FIS_GENERIC)
      {
         ExternalMessageSegment::instance()->reset();
         char* p = ExternalMsg;
         ExternalMessageSegment::instance()->import(&p);
      }
      if (m_iInputType == FIS_IST)
      {
         struct hISTLogHeader* pISTLogHeader = (struct hISTLogHeader*)pMessage->data();
         struct hISTInternalHeader* pISTInternalHeader =
            (struct hISTInternalHeader*)((char*)pISTLogHeader + sizeof(hISTLogHeader));
         short siMsgCode = pISTInternalHeader->msgCode;
#ifdef _LITTLE_ENDIAN
         siMsgCode = ntohs(siMsgCode);
#endif
         if (siMsgCode == 400)
         {
            struct hISTHeader* pISTHeader =
               (struct hISTHeader*)((char*)pISTInternalHeader + sizeof(hISTInternalHeader));
            char szLogid[6];
            memcpy(szLogid, pISTHeader->logid, 6);
            char szVersion[3];
            memcpy(szVersion, pISTHeader->version, 3);
#ifdef MVS
            CodeTable::translate(szLogid, 6, CodeTable::CX_ASCII_TO_EBCDIC);
            CodeTable::translate(szVersion, 3, CodeTable::CX_ASCII_TO_EBCDIC);
#endif
            if (memcmp(szLogid, "SHCLOG", 6) == 0)
            {

               char szPAN[19];
               if (memcmp(szVersion, "74", 2) == 0)
               {
                  struct hISTFinancialV74* pISTFinancialV74 =
                     (struct hISTFinancialV74*)((char*)pISTHeader + sizeof(hISTHeader));
                  memcpy(szPAN, pISTFinancialV74->pan, 19);
               }
               else
               {
                  if (memcmp(szVersion, "75", 2) == 0)
                  {
                     struct hISTFinancialV75* pISTFinancialV75 =
                        (struct hISTFinancialV75*)((char*)pISTHeader + sizeof(hISTHeader));
                     memcpy(szPAN, pISTFinancialV75->pan, 19);
                  }

                  else
                  {
                     struct hISTFinancialV76* pISTFinancialV76 =
                        (struct hISTFinancialV76*)((char*)pISTHeader + sizeof(hISTHeader));
                     memcpy(szPAN, pISTFinancialV76->pan, 19);
                  }
               }
#ifdef MVS
               CodeTable::translate(szPAN, 19, CodeTable::CX_ASCII_TO_EBCDIC);
#endif
            }
         }
      }
      if ((m_iInputType == MASTERCARD_IPM)
         || (m_iInputType == FIS_IST)
         || (m_iInputType == FIS_CONNEX_ON_IBM)
         || (m_iInputType == VISA_BASE_II)
         || (m_iInputType == FIS_MAS)
         || ((m_iInputType == FIS_GENERIC) && (m > 88))
         || (m_iInputType == ACI_POSTILION)
         || ((m_iInputType == ACI_BASE24) && ((strncmp(pB24FHRecord->sTypeRec,"DR",2) == 0)
         || (m_iInputType == ACI_BASE24)
         || (strncmp(pB24FHRecord->sTypeRec,"CF",2) == 0)
         || (strncmp(pB24FHRecord->sTypeRec,"TR",2) == 0))))
      {
         char sTemp[8];
         memcpy(sTemp,&m_lNumber,4);
         memcpy(sTemp + 4,&m_lProgress,4);
         pMessage->setReceiverSTCKValue(sTemp);
         if (pMessage->send(m_strQueueName.c_str()) != 0)
         {
            return UseCase::setSuccess(false);
         }
         UseCase::addItem();
         if (m_dHashTotal == -1)
            m_dHashTotal = 0;
         if (m_iInputType == FIS_CONNEX_ON_IBM)
            m_dHashTotal += pIBMHeader->lHdrStckHash;
         else
         if (m_iInputType == ACI_BASE24)
         {
            unsigned int iHash = pB24Record->lHdrTstamp[1];
            m_dHashTotal += iHash;
            struct hB24TLFTransaction* phB24TLFTransaction =
               (struct hB24TLFTransaction*)pMessage->data();
            struct hB24PTLFTransaction* phB24PTLFTransaction =
               (struct hB24PTLFTransaction*)pMessage->data();
            if (m_bIsB24ATM)
            {
#ifdef MVS
               CodeTable::translate(phB24TLFTransaction->sCrdPan,19,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
            }
            else
            {
#ifdef MVS
               CodeTable::translate(phB24PTLFTransaction->sCrdPan,19,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
            }
         }
         else
         if (m_iInputType == ACI_POSTILION)
         {
            m_dHashTotal += ntohl(pPostilionFinancial->itran_nr[1]);
         }
         else
         if (m_iInputType == VISA_BASE_II)
         {
            int lAmount = 0;
            Decimal::asLong(pBaseIIRecord->sAmount+4,4,&lAmount);
            m_dHashTotal += lAmount;
         }
         else
         if (m_iInputType == FIS_GENERIC)
         {
            char szHash[9] = {"        "};
            unsigned int lHashVal = 0;
            memcpy(szHash,ExternalMessageSegment::instance()->getAPHash().data(),8);
            sscanf(szHash,"%x",&lHashVal);
            m_dHashTotal += lHashVal;
         }
         else
         if (m_iInputType == FIS_IST)
         {
#ifdef _LITTLE_ENDIAN
            if (ntohl(pISTFinancial->msgtype) == 400)
               m_dHashTotal += ntohl(pISTFinancial->trantime);
#else
            if (pISTFinancial->msgtype == 400 )
               m_dHashTotal += pISTFinancial->trantime;
#endif
         }
         else
         if (m_iInputType == MASTERCARD_IPM)
         {
            char szHash[5];
            memcpy(szHash,pMCIPMHeader->sHashVal,4);
#ifndef MVS
            if ((unsigned char)szHash[0] > '9')
               CodeTable::translate(szHash,4,CodeTable::CX_EBCDIC_TO_ASCII);
#endif
            szHash[4]='\0';
            unsigned int iHashval = atoi(szHash);
            m_dHashTotal += iHashval;
         }
         else
         if (m_iInputType == FIS_MAS)
         {
            char szHash[9];
            memcpy(szHash,psegMAS->sTSTAMP_TRANS + 8,8);
            szHash[8]='\0';
            unsigned int iHashval = atoi(szHash);
            m_dHashTotal += iHashval;
         }
         if (m_iRecordsRead == m_iBatchSize)
         {
            return true;
         }
      }
   }
   return true;
  //## end LogFile::sendBatch%454B34D6032C.body
}

bool LogFile::sendHashRequest ()
{
  //## begin LogFile::sendHashRequest%454B350A0000.body preserve=yes
   UseCase hUseCase("LOG","## LG25 SEND HASH");
   m_hTimer.set(m_iRollback);
   Message::instance(Message::INBOUND)->reset("LR AI ","S0060D");
   hHashMessage* pRequest = (hHashMessage*)Message::instance(Message::INBOUND)->data();
   memcpy(pRequest->sOperation,"HASHREQ ",8);
   memset(pRequest->sTimeStamp,' ',sizeof(pRequest->sTimeStamp));
   pRequest->lSeqNo = ++m_lSeqNo;
   pRequest->dHashTotal = m_dHashTotal;
   m_dHashTotal = -1;
   pRequest->lLastRecSeqNo = getProgress();
   pRequest->lTranCnt = 0;
   pRequest->cStatusFlag = ' ';
   Message::instance(Message::INBOUND)->setDataLength(sizeof(hHashMessage));
   return UseCase::setSuccess(Message::instance(Message::INBOUND)->send(m_strQueueName.c_str()) == 0);
  //## end LogFile::sendHashRequest%454B350A0000.body
}

bool LogFile::sendZeroHash ()
{
  //## begin LogFile::sendZeroHash%454B34E80119.body preserve=yes
   UseCase hUseCase("LOG","## LG23 SEND ZERO HASH");
   Message::instance(Message::INBOUND)->reset("LR AI ","S0060D");
   hHashMessage* pResponse = (hHashMessage*)Message::instance(Message::INBOUND)->data();
   memcpy(pResponse->sOperation,"ZEROHASH",8);
   pResponse->lSeqNo = 0;
   pResponse->dHashTotal = 0;
   m_dHashTotal = -1;
   pResponse->lLastRecSeqNo = 0;
   pResponse->cStatusFlag = ' ';
   Message::instance(Message::INBOUND)->setDataLength(sizeof(hHashMessage));
   return UseCase::setSuccess(Message::instance(Message::INBOUND)->send(m_strQueueName.c_str()) == 0);
  //## end LogFile::sendZeroHash%454B34E80119.body
}

void LogFile::update (Subject* pSubject)
{
  //## begin LogFile::update%454B34F80399.body preserve=yes
   if (pSubject == Message::instance(Message::INBOUND))
      onMessage(*Message::instance(Message::INBOUND));
   else
   if (pSubject == MinuteTimer::instance())
   {
#ifdef MVS
      if (Clock::instance()->getMinute() == 0
         || m_iBatchSize < m_iTargetBatchSize
         || m_bDelayed)
#endif
         onResume(*Message::instance(Message::INBOUND));
   }
   else
   if (pSubject == &m_hTimer)
   {
      abort();
      onResume(*Message::instance(Message::INBOUND));
   }
   else
   if (pSubject == &m_hQuery)
   {
      vector<string> hTokens;
      if (Buffer::parse(m_strCONTEXT_DATA," ",hTokens) > 1)
      {
         ++m_lCount;
         string strTaskname(Application::instance()->name());
         strTaskname.erase(strTaskname.find_last_not_of(' ')+1,string::npos);
         if (m_strTASKID == strTaskname)
            m_bForce = true;
      }
   }
  //## end LogFile::update%454B34F80399.body
}

// Additional Declarations
  //## begin LogFile%454B30B1009C.declarations preserve=yes
  //## end LogFile%454B30B1009C.declarations

//## begin module%454B4723038A.epilog preserve=yes
//## end module%454B4723038A.epilog
