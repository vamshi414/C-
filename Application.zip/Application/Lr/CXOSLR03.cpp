//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%454B494A02BF.cm preserve=no
//	$Date:   May 20 2020 16:59:30  $ $Author:   e1009510  $
//	$Revision:   1.10  $
//## end module%454B494A02BF.cm

//## begin module%454B494A02BF.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%454B494A02BF.cp

//## Module: CXOSLR03%454B494A02BF; Package body
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\bV02.7D.R001\Windows\Build\Dn\Server\Application\Lr\CXOSLR03.cpp

//## begin module%454B494A02BF.additionalIncludes preserve=no
//## end module%454B494A02BF.additionalIncludes

//## begin module%454B494A02BF.includes preserve=yes
//## end module%454B494A02BF.includes

#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSLR03_h
#include "CXODLR03.hpp"
#endif


//## begin module%454B494A02BF.declarations preserve=no
//## end module%454B494A02BF.declarations

//## begin module%454B494A02BF.additionalDeclarations preserve=yes
//## end module%454B494A02BF.additionalDeclarations


// Class ISTClearingFile

ISTClearingFile::ISTClearingFile()
  //## begin ISTClearingFile::ISTClearingFile%454B3704004E_const.hasinit preserve=no
      : m_dCurrentHashValue(0),
        m_lRecordLength(0)
  //## end ISTClearingFile::ISTClearingFile%454B3704004E_const.hasinit
  //## begin ISTClearingFile::ISTClearingFile%454B3704004E_const.initialization preserve=yes
  //## end ISTClearingFile::ISTClearingFile%454B3704004E_const.initialization
{
  //## begin ISTClearingFile::ISTClearingFile%454B3704004E_const.body preserve=yes
   memcpy(m_sID,"LR03",4);
  //## end ISTClearingFile::ISTClearingFile%454B3704004E_const.body
}

ISTClearingFile::ISTClearingFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile)
  //## begin ISTClearingFile::ISTClearingFile%456547BC02B4.hasinit preserve=no
      : m_dCurrentHashValue(0),
        m_lRecordLength(0)
  //## end ISTClearingFile::ISTClearingFile%456547BC02B4.hasinit
  //## begin ISTClearingFile::ISTClearingFile%456547BC02B4.initialization preserve=yes
   ,ClearingFile(strIMAGEID,strTASKID,pszName,bVariableBlockFile)
  //## end ISTClearingFile::ISTClearingFile%456547BC02B4.initialization
{
  //## begin ISTClearingFile::ISTClearingFile%456547BC02B4.body preserve=yes
   memcpy(m_sID,"LR03",4);
  //## end ISTClearingFile::ISTClearingFile%456547BC02B4.body
}


ISTClearingFile::~ISTClearingFile()
{
  //## begin ISTClearingFile::~ISTClearingFile%454B3704004E_dest.body preserve=yes
  //## end ISTClearingFile::~ISTClearingFile%454B3704004E_dest.body
}



//## Other Operations (implementation)
bool ISTClearingFile::read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward, bool bTruncate)
{
  //## begin ISTClearingFile::read%566113A902D5.body preserve=yes
   Message::instance(Message::OUTBOUND)->reset("LR AI ", "S0059D");
   if (!GenerationDataGroup::read(psBuffer,lBufferLength,plRecordLength,bFastForward))
      return false;
   if (!bFastForward)
      return true;
   return true;
  //## end ISTClearingFile::read%566113A902D5.body
}

bool ISTClearingFile::sendBatch ()
{
  //## begin ISTClearingFile::sendBatch%454B38590128.body preserve=yes
   UseCase hUseCase("LOG","## LG24 SEND BATCH");
   size_t m = 0;
   m_iRecordsRead = 0;
   Message::instance(Message::OUTBOUND)->reset("LR AI ","S0059D");
   if (m_lRecordLength > 0 )
   {  //save last record read before re-starting the read loop
      memcpy(Message::instance(Message::OUTBOUND)->data(),m_szBuffer,m_lRecordLength);
      Message::instance(Message::OUTBOUND)->setDataLength(m_lRecordLength);
      m_iRecordsRead++;
   }
   while (read(m_szBuffer,4096,&m))
   {
      m_iRecordsRead++;
      hOasisRecordHeader* pOasisRecord = (hOasisRecordHeader*)m_szBuffer;
      if (memcmp(pOasisRecord->sRecordType,"FH",2) == 0)
      {  //trace file header info
         if (memcmp(pOasisRecord->sFieldId,"000010",6) == 0)
         {  //processing date is supposed to be part of file name but is optional
            //so just dump out the file name if it's there
            char szLen[4] = {"   "};
            memcpy(szLen,pOasisRecord->sFieldLen,3);
            int iLen = atoi(szLen);
         }
         // Date hDate(Date::today());
         // setDate(hDate.asString("%Y%m%d"));
         continue;
      }
      if ((memcmp(pOasisRecord->sRecordType,"BH",2) == 0) ||  //filter out header/trailer records
          (memcmp(pOasisRecord->sRecordType,"BT",2) == 0) ||
          (memcmp(pOasisRecord->sRecordType,"FT",2) == 0))
         continue;
      if ((memcmp(pOasisRecord->sRecordType,"M  ",3) == 0) ||      // Main Clearing records only
         (memcmp(pOasisRecord->sRecordType,"RCM",3) == 0))
      {  //start of new logical record
         if ((memcmp(pOasisRecord->sFieldId,"000001",6) == 0) &&
               (memcmp(pOasisRecord->sFieldLen,"012",3) == 0))
         {  //capture hash value
            char szHash[5] = {"    "};
            memcpy(szHash,pOasisRecord->sTranSeqNum + 8,4);
            if (m_dHashTotal == -1)
               m_dHashTotal = 0;
            m_dHashTotal += m_dCurrentHashValue;
            m_dCurrentHashValue = atol(szHash) + 1;
         }
         if (m_dHashTotal > 0)
         {  //send previous logical record
            memcpy(Message::instance(Message::OUTBOUND)->data() + m_lRecordLength,"ZZM",3);
            m_lRecordLength += 3;
            Message::instance(Message::OUTBOUND)->setDataLength(m_lRecordLength);
            char sTemp[8];
            memcpy(sTemp,&m_lNumber,4);
            int lProgress = m_lProgress - 1;
            memcpy(sTemp + 4,&lProgress,4);
            Message::instance(Message::OUTBOUND)->setReceiverSTCKValue(sTemp);
            if (Message::instance(Message::OUTBOUND)->send(m_strQueueName.c_str()))
               return UseCase::setSuccess(false);
            UseCase::addItem();
            m_lRecordLength = 0;
            if (m_iRecordsRead >= m_iBatchSize)
            {  //we've just sent a message, have one message in temp buffer
               memcpy(m_szBuffer + m,"ZZR",3);  //finish record before we leave
               m_lRecordLength = m + 3;
               return true;
            }
         }
      }
      memcpy(m_szBuffer+m,"ZZR",3);
      memcpy(Message::instance(Message::OUTBOUND)->data() + m_lRecordLength,m_szBuffer,m+3);
      m_lRecordLength += m+3;
      Message::instance(Message::OUTBOUND)->setDataLength(m_lRecordLength);
   }
   if (m_lRecordLength > 0)
   {
      memcpy(Message::instance(Message::OUTBOUND)->data()+m_lRecordLength,"ZZM",3);
      Message::instance(Message::OUTBOUND)->setDataLength(m_lRecordLength+3);
      if (m_dHashTotal == -1)
         m_dHashTotal = 0;
      m_dHashTotal += m_dCurrentHashValue;
      char sTemp[8];
      memcpy(sTemp,&m_lNumber,4);
      memcpy(sTemp + 4,&m_lProgress,4);
      Message::instance(Message::OUTBOUND)->setReceiverSTCKValue(sTemp);
      if (Message::instance(Message::OUTBOUND)->send(m_strQueueName.c_str()))
         return UseCase::setSuccess(false);
      UseCase::addItem();
   }
   m_iRecordsRead = 0;
   m_lRecordLength = 0;
   m_dCurrentHashValue = 0;
   return true;
  //## end ISTClearingFile::sendBatch%454B38590128.body
}

// Additional Declarations
  //## begin ISTClearingFile%454B3704004E.declarations preserve=yes
  //## end ISTClearingFile%454B3704004E.declarations

//## begin module%454B494A02BF.epilog preserve=yes
//## end module%454B494A02BF.epilog
