//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%454B48C5032C.cm preserve=no
//	$Date:   May 20 2020 16:59:30  $ $Author:   e1009510  $
//	$Revision:   1.14  $
//## end module%454B48C5032C.cm

//## begin module%454B48C5032C.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%454B48C5032C.cp

//## Module: CXOSLR02%454B48C5032C; Package body
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\Devel\Dn\Server\Application\Lr\CXOSLR02.cpp

//## begin module%454B48C5032C.additionalIncludes preserve=no
//## end module%454B48C5032C.additionalIncludes

//## begin module%454B48C5032C.includes preserve=yes

#ifdef _WIN32
//#include <winsock.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
#include "CXODRS60.hpp"
//## end module%454B48C5032C.includes

#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSLR02_h
#include "CXODLR02.hpp"
#endif


//## begin module%454B48C5032C.declarations preserve=no
//## end module%454B48C5032C.declarations

//## begin module%454B48C5032C.additionalDeclarations preserve=yes
//## end module%454B48C5032C.additionalDeclarations


// Class NACHALogFile 

NACHALogFile::NACHALogFile()
  //## begin NACHALogFile::NACHALogFile%454B36F90213_const.hasinit preserve=no
      : m_dAmount(0),
        m_iCount(0),
        m_dHash(0)
  //## end NACHALogFile::NACHALogFile%454B36F90213_const.hasinit
  //## begin NACHALogFile::NACHALogFile%454B36F90213_const.initialization preserve=yes
  //## end NACHALogFile::NACHALogFile%454B36F90213_const.initialization
{
  //## begin NACHALogFile::NACHALogFile%454B36F90213_const.body preserve=yes
   memcpy(m_sID,"LR02",4);
  //## end NACHALogFile::NACHALogFile%454B36F90213_const.body
}

NACHALogFile::NACHALogFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile)
  //## begin NACHALogFile::NACHALogFile%4562E58C02B8.hasinit preserve=no
      : m_dAmount(0),
        m_iCount(0),
        m_dHash(0)
  //## end NACHALogFile::NACHALogFile%4562E58C02B8.hasinit
  //## begin NACHALogFile::NACHALogFile%4562E58C02B8.initialization preserve=yes
   ,LogFile(strIMAGEID,strTASKID,pszName,bVariableBlockFile)
  //## end NACHALogFile::NACHALogFile%4562E58C02B8.initialization
{
  //## begin NACHALogFile::NACHALogFile%4562E58C02B8.body preserve=yes
   memcpy(m_sID,"LR02",4);
  //## end NACHALogFile::NACHALogFile%4562E58C02B8.body
}


NACHALogFile::~NACHALogFile()
{
  //## begin NACHALogFile::~NACHALogFile%454B36F90213_dest.body preserve=yes
  //## end NACHALogFile::~NACHALogFile%454B36F90213_dest.body
}



//## Other Operations (implementation)
bool NACHALogFile::read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward, bool bTruncate)
{
  //## begin NACHALogFile::read%458112000317.body preserve=yes
   Message::instance(Message::OUTBOUND)->reset("LR AI ","S0059D");
   bool b = GenerationDataGroup::read(psBuffer,lBufferLength,plRecordLength,bFastForward);
   segACHEntryDetail* psegACHEntryDetail = (segACHEntryDetail*)psBuffer;
   string strTempHash;
   switch (*psBuffer)
   {
      case '1': // File Header
         m_dAmount = 0;
         m_iCount = 0;
         m_dHash = 0;
         memcpy(Message::instance(Message::OUTBOUND)->data(),psBuffer,*plRecordLength);
         memcpy(m_sFileHeader,psBuffer,*plRecordLength);
         break;
      case '5': // Batch Header
         memcpy(Message::instance(Message::OUTBOUND)->data() + NACHA_INPUT_LEN,psBuffer,*plRecordLength);
         break;
      case '6': // Entry Detail
         m_iCount++;
         memcpy(Message::instance(Message::OUTBOUND)->data(),m_sFileHeader,NACHA_INPUT_LEN);
         memcpy(Message::instance(Message::OUTBOUND)->data() + (NACHA_INPUT_LEN * 2),psBuffer,*plRecordLength);
         memcpy(psegACHEntryDetail->sAmount + 10,"\0",1);
         m_dAmount += atof(psegACHEntryDetail->sAmount);
         memcpy(psegACHEntryDetail->sRDFI + 8,"\0",1);
         if (m_dHashTotal == -1)
            m_dHashTotal = 0;
         m_dHash += atol(psegACHEntryDetail->sRDFI);
         strTempHash.assign(psegACHEntryDetail->sDFIAccountNbr,sizeof(psegACHEntryDetail->sDFIAccountNbr));
         strTempHash.erase(strTempHash.find_last_not_of(" ") + 1);
         if (strTempHash.length() > 3)
            strTempHash = strTempHash.substr(strTempHash.length() - 4,4);
         m_dHashTotal += atof(strTempHash.c_str());
         break;
      case '7': // Entry Addenda
         m_iCount++;
         break;
   }
   return b;
  //## end NACHALogFile::read%458112000317.body
}

bool NACHALogFile::sendBatch ()
{
  //## begin NACHALogFile::sendBatch%454B383A035B.body preserve=yes
   UseCase hUseCase("LOG","## LG27 SEND NACHA BATCH");
   int iAddendaRecords = 0;
   int iAddendaIndex = 0;
   char cPrevRecord = ' ';
   Message::instance(Message::OUTBOUND)->reset("LR AI ","S0059D");
   char* p = Message::instance(Message::OUTBOUND)->data() + (3 * NACHA_INPUT_LEN);
   char sReadBuffer[NACHA_INPUT_LEN + 2];
   segACHEntryDetail* psegACHEntryDetail = (segACHEntryDetail*)sReadBuffer;
   segACHFileTrailer* psegACHFileTrailer = (segACHFileTrailer*)sReadBuffer;
   m_iRecordsRead = 0;
   size_t m = 0;
   while (read(sReadBuffer,NACHA_INPUT_LEN + 2,&m))
   {
      m_iRecordsRead++;
      switch (sReadBuffer[0])
      {
         case '6': // Entry Detail
            if (psegACHEntryDetail->cAddendaInd != '1')
            {
               Message::instance(Message::OUTBOUND)->setDataLength(p - Message::instance(Message::OUTBOUND)->data());
               if (Message::instance(Message::OUTBOUND)->send(m_strQueueName.c_str()) != 0)
                  return UseCase::setSuccess(false);
               if (m_iRecordsRead >= m_iBatchSize)
                  return true;
               p = Message::instance(Message::OUTBOUND)->data() + (3 * NACHA_INPUT_LEN);
            }
            else
            {
               memcpy(psegACHEntryDetail->sAddendaRecords + 4,"\0",1);
               iAddendaRecords = atoi(psegACHEntryDetail->sAddendaRecords);
               iAddendaIndex = 0;
            }
            break;
         case '7': // Entry Addenda
            memcpy(p,sReadBuffer,m);
            p += NACHA_INPUT_LEN;
            if (++iAddendaIndex == iAddendaRecords)
            {
               Message::instance(Message::OUTBOUND)->setDataLength(p - Message::instance(Message::OUTBOUND)->data());
               if (Message::instance(Message::OUTBOUND)->send(m_strQueueName.c_str()) != 0)
                  return UseCase::setSuccess(false);
               if (m_iRecordsRead >= m_iBatchSize)
                  return true;
               p = Message::instance(Message::OUTBOUND)->data() + (3 * NACHA_INPUT_LEN);
            }
            break;
         case '8': // Batch Trailer
            break;
         case '9': // File Trailer
            if (cPrevRecord != '9')
            {
               memcpy(psegACHFileTrailer->sCredit + 12,"\0",1);
               double dCredit = atof(psegACHFileTrailer->sCredit);
               memcpy(psegACHFileTrailer->sDebit + 12,"\0",1);
               double dDebit = atof(psegACHFileTrailer->sDebit);
               memcpy(psegACHFileTrailer->sHash + 10,"\0",1);
               char szTempHash1[PERCENTF];
               char szTempHash2[PERCENTF];
               snprintf(szTempHash1,sizeof(szTempHash1),"%018.0lf",m_dHash);
               if (strlen(szTempHash1) > 10)
               {
                  memcpy(szTempHash2,(szTempHash1 + (strlen(szTempHash1)) - 10),10);
                  szTempHash2[10] = '\0';
               }
               memcpy(szTempHash1,psegACHFileTrailer->sHash,sizeof(psegACHFileTrailer->sHash));
               szTempHash1[sizeof(psegACHFileTrailer->sHash)] = '\0';
               memcpy(psegACHFileTrailer->sCount + 8, "\0",1);
               int iCount = atoi(psegACHFileTrailer->sCount);
               if ((iCount != m_iCount)
                  || ((dDebit + dCredit) != m_dAmount)
                  || (strcmp(szTempHash1,szTempHash2) != 0))
                  Console::display("ST217","NACHA File Hash total Error");
            }
            break;
      }
      cPrevRecord = sReadBuffer[0];
   }
   if (m_bReadError)
      return UseCase::setSuccess(false);
   else
      return true;
  //## end NACHALogFile::sendBatch%454B383A035B.body
}

// Additional Declarations
  //## begin NACHALogFile%454B36F90213.declarations preserve=yes
  //## end NACHALogFile%454B36F90213.declarations

//## begin module%454B48C5032C.epilog preserve=yes
//## end module%454B48C5032C.epilog
