//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6463480E03B1.cm preserve=no
//## end module%6463480E03B1.cm

//## begin module%6463480E03B1.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6463480E03B1.cp

//## Module: CXOSLR10%6463480E03B1; Package body
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Lr\CXOSLR10.cpp

//## begin module%6463480E03B1.additionalIncludes preserve=no
//## end module%6463480E03B1.additionalIncludes

//## begin module%6463480E03B1.includes preserve=yes
#include "CXODKP07.hpp"
//## end module%6463480E03B1.includes

#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSDB28_h
#include "CXODDB28.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSLR10_h
#include "CXODLR10.hpp"
#endif


//## begin module%6463480E03B1.declarations preserve=no
//## end module%6463480E03B1.declarations

//## begin module%6463480E03B1.additionalDeclarations preserve=yes
//## end module%6463480E03B1.additionalDeclarations


// Class MASClearingFile 

MASClearingFile::MASClearingFile()
  //## begin MASClearingFile::MASClearingFile%6463448C004C_const.hasinit preserve=no
      : m_iCount(1),
        m_dCurrentHashValue(0),
        m_lRecordLength(0)
  //## end MASClearingFile::MASClearingFile%6463448C004C_const.hasinit
  //## begin MASClearingFile::MASClearingFile%6463448C004C_const.initialization preserve=yes
  //## end MASClearingFile::MASClearingFile%6463448C004C_const.initialization
{
  //## begin MASClearingFile::MASClearingFile%6463448C004C_const.body preserve=yes
   memcpy(m_sID, "LR10", 4);
  //## end MASClearingFile::MASClearingFile%6463448C004C_const.body
}

MASClearingFile::MASClearingFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile)
  //## begin MASClearingFile::MASClearingFile%646344B7035C.hasinit preserve=no
      : m_iCount(1),
        m_dCurrentHashValue(0),
        m_lRecordLength(0)
  //## end MASClearingFile::MASClearingFile%646344B7035C.hasinit
  //## begin MASClearingFile::MASClearingFile%646344B7035C.initialization preserve=yes
   , ClearingFile(strIMAGEID,strTASKID,pszName,bVariableBlockFile)
  //## end MASClearingFile::MASClearingFile%646344B7035C.initialization
{
  //## begin MASClearingFile::MASClearingFile%646344B7035C.body preserve=yes
   memcpy(m_sID, "LR10", 4);
  //## end MASClearingFile::MASClearingFile%646344B7035C.body
}


MASClearingFile::~MASClearingFile()
{
  //## begin MASClearingFile::~MASClearingFile%6463448C004C_dest.body preserve=yes
  //## end MASClearingFile::~MASClearingFile%6463448C004C_dest.body
}



//## Other Operations (implementation)
bool MASClearingFile::sendBatch ()
{
  //## begin MASClearingFile::sendBatch%646344D300C7.body preserve=yes
   UseCase hUseCase("LOG", "## LR10 SEND BATCH");
   size_t m = 0;
   m_iRecordsRead = 0;
   Message::instance(Message::OUTBOUND)->reset("LR AI ", "S0059D");
   if (m_lRecordLength > 0)
   {  //save last record read before re-starting the read loop
      memcpy(Message::instance(Message::OUTBOUND)->data(), m_szBuffer, m_lRecordLength);
      Message::instance(Message::OUTBOUND)->setDataLength(m_lRecordLength);
      m_iRecordsRead++;
   }
   while (read(m_szBuffer, 4096, &m))
   {
      m_iRecordsRead++;
      segMASOutbounder* pMasHeader = (segMASOutbounder*)m_szBuffer;
      if ((memcmp(pMasHeader->sTRANS_TYPE, "FH", 2) == 0) ||  //filter out header/trailer records
         (memcmp(pMasHeader->sTRANS_TYPE, "FT", 2) == 0))
         continue;
      if ((memcmp(pMasHeader->sTRANS_TYPE, "01", 2) == 0))      // Main Clearing records only
      {  //start of new logical record
         //capture hash value
         char szHash[5] = { "    " };
         memcpy(szHash, pMasHeader->sTRANS_DATE_TIME + 8, 4);
         if (m_dHashTotal == -1)
            m_dHashTotal = 0;
         m_dHashTotal += m_dCurrentHashValue;
         m_dCurrentHashValue = atol(szHash) + 1;
         if (m_dHashTotal > 0)
         {  //send previous logical record
            memcpy(Message::instance(Message::OUTBOUND)->data() + m_lRecordLength, "ZZM", 3);
            m_lRecordLength += 3;
            Message::instance(Message::OUTBOUND)->setDataLength(m_lRecordLength);
            char sTemp[8];
            memcpy(sTemp, &m_lNumber, 4);
            int lProgress = m_lProgress - 1;
            memcpy(sTemp + 4, &lProgress, 4);
            Message::instance(Message::OUTBOUND)->setReceiverSTCKValue(sTemp);
            if (Message::instance(Message::OUTBOUND)->send(m_strQueueName.c_str()))
               return UseCase::setSuccess(false);
            UseCase::addItem();
            m_lRecordLength = 0;
            if (m_iRecordsRead >= m_iBatchSize)
            {  //we've just sent a message, have one message in temp buffer
               memcpy(m_szBuffer + m, "ZZR", 3);  //finish record before we leave
               m_lRecordLength = m + 3;
               return true;
            }
         }
      }
      memcpy(m_szBuffer + m, "ZZR", 3);
      memcpy(Message::instance(Message::OUTBOUND)->data() + m_lRecordLength, m_szBuffer, m + 3);
      m_lRecordLength += m + 3;
      Message::instance(Message::OUTBOUND)->setDataLength(m_lRecordLength);
   }
   if (m_lRecordLength > 0)
   {
      memcpy(Message::instance(Message::OUTBOUND)->data() + m_lRecordLength, "ZZM", 3);
      Message::instance(Message::OUTBOUND)->setDataLength(m_lRecordLength + 3);
      if (m_dHashTotal == -1)
         m_dHashTotal = 0;
      m_dHashTotal += m_dCurrentHashValue;
      char sTemp[8];
      memcpy(sTemp, &m_lNumber, 4);
      memcpy(sTemp + 4, &m_lProgress, 4);
      Message::instance(Message::OUTBOUND)->setReceiverSTCKValue(sTemp);
      if (Message::instance(Message::OUTBOUND)->send(m_strQueueName.c_str()))
         return UseCase::setSuccess(false);
      UseCase::addItem();
   }
   m_iRecordsRead = 0;
   m_lRecordLength = 0;
   m_dCurrentHashValue = 0;
   return true;
  //## end MASClearingFile::sendBatch%646344D300C7.body
}

// Additional Declarations
  //## begin MASClearingFile%6463448C004C.declarations preserve=yes
  //## end MASClearingFile%6463448C004C.declarations

//## begin module%6463480E03B1.epilog preserve=yes
//## end module%6463480E03B1.epilog
