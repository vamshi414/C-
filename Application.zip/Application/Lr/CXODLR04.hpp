//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%454B4A02035B.cm preserve=no
//	$Date:   May 20 2020 16:46:48  $ $Author:   e1009510  $
//	$Revision:   1.9  $
//## end module%454B4A02035B.cm

//## begin module%454B4A02035B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%454B4A02035B.cp

//## Module: CXOSLR04%454B4A02035B; Package specification
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\bV02.4B.R001\Windows\Build\Dn\Server\Application\Lr\CXODLR04.hpp

#ifndef CXOSLR04_h
#define CXOSLR04_h 1

//## begin module%454B4A02035B.additionalIncludes preserve=no
//## end module%454B4A02035B.additionalIncludes

//## begin module%454B4A02035B.includes preserve=yes
#ifndef CXOSVP04_h
#include "CXODVP04.hpp"
#endif
//## end module%454B4A02035B.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSLR09_h
#include "CXODLR09.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Console;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;

} // namespace timer

//## begin module%454B4A02035B.declarations preserve=no
//## end module%454B4A02035B.declarations

//## begin module%454B4A02035B.additionalDeclarations preserve=yes
//## end module%454B4A02035B.additionalDeclarations


//## begin VisaDCLogFile%454B372B004E.preface preserve=yes
//## end VisaDCLogFile%454B372B004E.preface

//## Class: VisaDCLogFile%454B372B004E
//## Category: DataNavigator Foundation::Application::LogReader_CAT%354B34A1001C
//## Subsystem: LR%3597EB340165
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%454BB49602EE;IF::Console { -> F}
//## Uses: <unnamed>%454FAA22031C;timer::Date { -> F}
//## Uses: <unnamed>%45700C130057;monitor::UseCase { -> F}
//## Uses: <unnamed>%45B81BDA01B5;IF::Trace { -> F}

class DllExport VisaDCLogFile : public ClearingFile  //## Inherits: <unnamed>%5344116301FF
{
  //## begin VisaDCLogFile%454B372B004E.initialDeclarations preserve=yes
  //## end VisaDCLogFile%454B372B004E.initialDeclarations

  public:
    //## Constructors (generated)
      VisaDCLogFile();

    //## Constructors (specified)
      //## Operation: VisaDCLogFile%456547EF00D2
      VisaDCLogFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile);

    //## Destructor (generated)
      virtual ~VisaDCLogFile();


    //## Other Operations (specified)
      //## Operation: read%45BE4CC50242
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward = false, bool bTruncate = false);

      //## Operation: sendBatch%454B386D03D8
      bool sendBatch ();

    // Additional Public Declarations
      //## begin VisaDCLogFile%454B372B004E.public preserve=yes
      //## end VisaDCLogFile%454B372B004E.public

  protected:
    // Additional Protected Declarations
      //## begin VisaDCLogFile%454B372B004E.protected preserve=yes
      //## end VisaDCLogFile%454B372B004E.protected

  private:
    // Additional Private Declarations
      //## begin VisaDCLogFile%454B372B004E.private preserve=yes
      //## end VisaDCLogFile%454B372B004E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Detail%45BEA420030D
      //## begin VisaDCLogFile::Detail%45BEA420030D.attr preserve=no  private: char* {V} 0
      char* m_pDetail;
      //## end VisaDCLogFile::Detail%45BEA420030D.attr

      //## Attribute: Header%45BEA57200FA
      //## begin VisaDCLogFile::Header%45BEA57200FA.attr preserve=no  private: char* {V} 0
      char* m_pHeader;
      //## end VisaDCLogFile::Header%45BEA57200FA.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LogReader_CAT::<unnamed>%479CBE870128
      //## Role: VisaDCLogFile::<m_hMessage>%479CBE870399
      //## begin VisaDCLogFile::<m_hMessage>%479CBE870399.role preserve=no  public: IF::Message { -> VHgN}
      IF::Message m_hMessage;
      //## end VisaDCLogFile::<m_hMessage>%479CBE870399.role

    // Additional Implementation Declarations
      //## begin VisaDCLogFile%454B372B004E.implementation preserve=yes
      //## end VisaDCLogFile%454B372B004E.implementation

};

//## begin VisaDCLogFile%454B372B004E.postscript preserve=yes
//## end VisaDCLogFile%454B372B004E.postscript

//## begin module%454B4A02035B.epilog preserve=yes
//## end module%454B4A02035B.epilog


#endif
