//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C5155B802EE.cm preserve=no
//	$Date:   Jun 19 2020 11:43:10  $ $Author:   e1009839  $
//	$Revision:   1.139  $
//## end module%3C5155B802EE.cm

//## begin module%3C5155B802EE.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C5155B802EE.cp

//## Module: CXOPLR00%3C5155B802EE; Package body
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Application\Lr\CXOPLR00.cpp

//## begin module%3C5155B802EE.additionalIncludes preserve=no
//## end module%3C5155B802EE.additionalIncludes

//## begin module%3C5155B802EE.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#include "CXODIF03.hpp"
#include "CXODMN02.hpp"
#include "CXODLR10.hpp"
//## end module%3C5155B802EE.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSLR02_h
#include "CXODLR02.hpp"
#endif
#ifndef CXOSLR04_h
#include "CXODLR04.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSLR05_h
#include "CXODLR05.hpp"
#endif
#ifndef CXOSLR06_h
#include "CXODLR06.hpp"
#endif
#ifndef CXOSLR03_h
#include "CXODLR03.hpp"
#endif
#ifndef CXOSLR07_h
#include "CXODLR07.hpp"
#endif
#ifndef CXOSLR08_h
#include "CXODLR08.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSLR01_h
#include "CXODLR01.hpp"
#endif
#ifndef CXOPLR00_h
#include "CXODLR00.hpp"
#endif


//## begin module%3C5155B802EE.declarations preserve=no
//## end module%3C5155B802EE.declarations

//## begin module%3C5155B802EE.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new LogReader();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%3C5155B802EE.additionalDeclarations


// Class LogReader

LogReader::LogReader()
  //## begin LogReader::LogReader%34567BCB00E7_const.hasinit preserve=no
      : m_pLogFile(0)
  //## end LogReader::LogReader%34567BCB00E7_const.hasinit
  //## begin LogReader::LogReader%34567BCB00E7_const.initialization preserve=yes
  //## end LogReader::LogReader%34567BCB00E7_const.initialization
{
  //## begin LogReader::LogReader%34567BCB00E7_const.body preserve=yes
   memcpy(m_sID,"LR00",4);
  //## end LogReader::LogReader%34567BCB00E7_const.body
}


LogReader::~LogReader()
{
  //## begin LogReader::~LogReader%34567BCB00E7_dest.body preserve=yes
   delete m_pLogFile;
  //## end LogReader::~LogReader%34567BCB00E7_dest.body
}



//## Other Operations (implementation)
int LogReader::initialize ()
{
  //## begin LogReader::initialize%3C51567603B9.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("LOG","## LG21 START LR");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   entitysegment::SwitchBusinessDay::instance();
   Database::instance()->connect();
   int iInputType = 0;
   string strRecord;
   if (Extract::instance()->getRecord("DUSER",strRecord))
   {
      if (strRecord.find("CXOPII00") != string::npos)
         iInputType = FIS_CONNEX_ON_IBM;
      else
      if (strRecord.find("CXOPPI00") != string::npos)
         iInputType = ACI_POSTILION;
      else
      if (strRecord.find("CXOPBI00") != string::npos)
         iInputType = ACI_BASE24;
      else
      if (strRecord.find("CXOPXI00") != string::npos)
         iInputType = FIS_GENERIC;
      else
      if (strRecord.find("CXOPOI00") != string::npos)
         iInputType = FIS_IST;
      else
      if (strRecord.find("CXOPVI00") != string::npos)
         iInputType = VISA_BASE_II;
      else
      if (strRecord.find("CXOPNI00") != string::npos)
         iInputType = FIS_ACH;
      else
      if (strRecord.find("CXOPYI00") != string::npos)
         iInputType = FIS_TRANSACTION_ACTIVITY;
      else
      if (strRecord.find("CXOPMI00") != string::npos)
         iInputType = MASTERCARD_IPM;
      else
      if (strRecord.find("CXOPKI00") != string::npos)
         iInputType = FIS_MAS;
      else
      if (strRecord.find("CXOPMD00") != string::npos)
         iInputType = MASTERCARD_DCF;
   }
   bool bVariableBlockFile =
        (iInputType != VISA_BASE_II
      && iInputType != ACI_POSTILION
      && iInputType != FIS_IST
      && iInputType != FIS_ACH
      && iInputType != FIS_GENERIC
      && iInputType != FIS_TRANSACTION_ACTIVITY
      && iInputType != FIS_MAS
      && iInputType != MASTERCARD_DCF);
   if (Extract::instance()->getCustomCode() == "SBI")
      bVariableBlockFile = false;
   switch (iInputType)
   {
      case FIS_CONNEX_ON_HP:
         m_pLogFile = new ConnexNonStopLogFile(Application::instance()->image(),Application::instance()->name(),"IBMLOG",bVariableBlockFile);
         break;
      case VISA_BASE_II:
         if (Extract::instance()->getCustomCode() == "USPS" || Extract::instance()->getCustomCode() == "BBL"
            || Extract::instance()->getCustomCode() == "RNTS" || Extract::instance()->getCustomCode(1) == "INTT")
            m_pLogFile = new VisaDCLogFile(Application::instance()->image(),Application::instance()->name(),"IBMLOG",bVariableBlockFile);
         else
         if (Extract::instance()->getCustomCode() == "REGIONS")
         {
#ifndef MVS
            bVariableBlockFile = true;
#endif
            m_pLogFile = new LogFile(Application::instance()->image(),Application::instance()->name(),"IBMLOG",bVariableBlockFile);
         }
         else
            m_pLogFile = new VisaBaseIILogFile(Application::instance()->image(),Application::instance()->name(),"IBMLOG",bVariableBlockFile);
         break;
      case FIS_IST:
#ifdef MVS
         bVariableBlockFile = true;
#endif
         m_pLogFile = new ISTClearingFile(Application::instance()->image(),Application::instance()->name(),"IBMLOG",bVariableBlockFile);
         break;
      case FIS_ACH:
         m_pLogFile = new NACHALogFile(Application::instance()->image(),Application::instance()->name(),"IBMLOG",bVariableBlockFile);
         break;
      case FIS_TRANSACTION_ACTIVITY:
         m_pLogFile = new TransactionActivityLogFile(Application::instance()->image(),Application::instance()->name(),"IBMLOG",bVariableBlockFile);
         break;
      case MASTERCARD_DCF:
         m_pLogFile = new MasterCardDraftCaptureFile(Application::instance()->image(),Application::instance()->name(),"IBMLOG",bVariableBlockFile);
         break;
      case FIS_MAS:
         if (Extract::instance()->getCustomCode(1) == "CVRN")
            m_pLogFile = new MASClearingFile(Application::instance()->image(),Application::instance()->name(),"IBMLOG",bVariableBlockFile);
         else
            m_pLogFile = new ClearingFile(Application::instance()->image(),Application::instance()->name(),"IBMLOG",bVariableBlockFile);
         break;
      default:
         m_pLogFile = new LogFile(Application::instance()->image(),Application::instance()->name(),"IBMLOG",bVariableBlockFile);
   }
   m_pLogFile->setInputType(iInputType);
   return 0;
  //## end LogReader::initialize%3C51567603B9.body
}

int LogReader::onReset (Message& hMessage)
{
  //## begin LogReader::onReset%45C255D1002E.body preserve=yes
   if (hMessage.context().length() >= 9
      && memcmp((char*)hMessage.context(),"LRLIMIT-",8) == 0)
   {
      int lLimit = atoi((char*)hMessage.context().subString(9));
      if (lLimit > 0 && lLimit < 100)
         m_pLogFile->setLimit(lLimit);
      Count::set("LOG","## LG31 DELAY FILE START","ITEMS",lLimit);
      return 0;
   }
   return onResume(hMessage);
  //## end LogReader::onReset%45C255D1002E.body
}

int LogReader::onResume (Message& hMessage)
{
  //## begin LogReader::onResume%45B913280119.body preserve=yes
   return (m_pLogFile->onResume(hMessage)) ? 1 : 0;
  //## end LogReader::onResume%45B913280119.body
}

// Additional Declarations
  //## begin LogReader%34567BCB00E7.declarations preserve=yes
  //## end LogReader%34567BCB00E7.declarations

//## begin module%3C5155B802EE.epilog preserve=yes
//## end module%3C5155B802EE.epilog
