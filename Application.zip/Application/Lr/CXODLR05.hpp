//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%4934615200B7.cm preserve=no
//	$Date:   May 20 2020 16:46:48  $ $Author:   e1009510  $
//	$Revision:   1.4  $
//## end module%4934615200B7.cm

//## begin module%4934615200B7.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%4934615200B7.cp

//## Module: CXOSLR05%4934615200B7; Package specification
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\Devel\Dn\Server\Application\Lr\CXODLR05.hpp

#ifndef CXOSLR05_h
#define CXOSLR05_h 1

//## begin module%4934615200B7.additionalIncludes preserve=no
//## end module%4934615200B7.additionalIncludes

//## begin module%4934615200B7.includes preserve=yes
#ifndef CXOSPF05_h
#include "CXODPF05.hpp"
#endif
//## end module%4934615200B7.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSLR01_h
#include "CXODLR01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Console;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
} // namespace timer

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;

} // namespace monitor

//## begin module%4934615200B7.declarations preserve=no
//## end module%4934615200B7.declarations

//## begin module%4934615200B7.additionalDeclarations preserve=yes
//## end module%4934615200B7.additionalDeclarations


//## begin TransactionActivityLogFile%493460D102A6.preface preserve=yes
//## end TransactionActivityLogFile%493460D102A6.preface

//## Class: TransactionActivityLogFile%493460D102A6
//## Category: DataNavigator Foundation::Application::LogReader_CAT%354B34A1001C
//## Subsystem: LR%3597EB340165
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%493460F8004A;IF::Console { -> F}
//## Uses: <unnamed>%493460FA0147;timer::Date { -> F}
//## Uses: <unnamed>%493460FC0118;monitor::UseCase { -> F}
//## Uses: <unnamed>%493460FE016B;IF::Trace { -> F}

class DllExport TransactionActivityLogFile : public LogFile  //## Inherits: <unnamed>%493460E8014B
{
  //## begin TransactionActivityLogFile%493460D102A6.initialDeclarations preserve=yes
  //## end TransactionActivityLogFile%493460D102A6.initialDeclarations

  public:
    //## Constructors (generated)
      TransactionActivityLogFile();

    //## Constructors (specified)
      //## Operation: TransactionActivityLogFile%49355FE9004C
      TransactionActivityLogFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile);

    //## Destructor (generated)
      virtual ~TransactionActivityLogFile();


    //## Other Operations (specified)
      //## Operation: read%493462850163
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward = false, bool bTruncate = false);

    // Additional Public Declarations
      //## begin TransactionActivityLogFile%493460D102A6.public preserve=yes
      //## end TransactionActivityLogFile%493460D102A6.public

  protected:

    //## Other Operations (specified)
      //## Operation: sendBatch%493462850172
      virtual bool sendBatch ();

    // Additional Protected Declarations
      //## begin TransactionActivityLogFile%493460D102A6.protected preserve=yes
      //## end TransactionActivityLogFile%493460D102A6.protected

  private:

    //## Other Operations (specified)
      //## Operation: send%49358148023B
      bool send ();

    // Additional Private Declarations
      //## begin TransactionActivityLogFile%493460D102A6.private preserve=yes
      //## end TransactionActivityLogFile%493460D102A6.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DataLength%493599470388
      //## begin TransactionActivityLogFile::DataLength%493599470388.attr preserve=no  private: int {U} 0
      int m_iDataLength;
      //## end TransactionActivityLogFile::DataLength%493599470388.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LogReader_CAT::<unnamed>%4934610C005C
      //## Role: TransactionActivityLogFile::<m_hMessage>%4934610D0126
      //## begin TransactionActivityLogFile::<m_hMessage>%4934610D0126.role preserve=no  public: IF::Message { -> VHgN}
      IF::Message m_hMessage;
      //## end TransactionActivityLogFile::<m_hMessage>%4934610D0126.role

    // Additional Implementation Declarations
      //## begin TransactionActivityLogFile%493460D102A6.implementation preserve=yes
      char m_szReadBuffer[16384];
      char m_szSendBuffer[16384];
      postingfile::TransactionActivityFile m_hTransactionActivityFile;
      //## end TransactionActivityLogFile%493460D102A6.implementation
};

//## begin TransactionActivityLogFile%493460D102A6.postscript preserve=yes
//## end TransactionActivityLogFile%493460D102A6.postscript

//## begin module%4934615200B7.epilog preserve=yes
//## end module%4934615200B7.epilog


#endif
