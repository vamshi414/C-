//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%454B4A0C035B.cm preserve=no
// $Date:   Jan 17 2021 16:51:52  $ $Author:   e1009839  $
// $Revision:   1.17  $
//## end module%454B4A0C035B.cm

//## begin module%454B4A0C035B.cp preserve=no
// Copyright (c) 1997 - 2012
// FIS
//## end module%454B4A0C035B.cp

//## Module: CXOSLR04%454B4A0C035B; Package body
//## Subsystem: LR%3597EB340165
// .
//## Source file: C:\bV02.4B.R001\Windows\Build\Dn\Server\Application\Lr\CXOSLR04.cpp

//## begin module%454B4A0C035B.additionalIncludes preserve=no
//## end module%454B4A0C035B.additionalIncludes

//## begin module%454B4A0C035B.includes preserve=yes
#define FIXED_RECLEN 2500
//## end module%454B4A0C035B.includes

#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSLR04_h
#include "CXODLR04.hpp"
#endif


//## begin module%454B4A0C035B.declarations preserve=no
//## end module%454B4A0C035B.declarations

//## begin module%454B4A0C035B.additionalDeclarations preserve=yes
//## end module%454B4A0C035B.additionalDeclarations


// Class VisaDCLogFile

VisaDCLogFile::VisaDCLogFile()
  //## begin VisaDCLogFile::VisaDCLogFile%454B372B004E_const.hasinit preserve=no
      : m_pDetail(0),
        m_pHeader(0)
  //## end VisaDCLogFile::VisaDCLogFile%454B372B004E_const.hasinit
  //## begin VisaDCLogFile::VisaDCLogFile%454B372B004E_const.initialization preserve=yes
  //## end VisaDCLogFile::VisaDCLogFile%454B372B004E_const.initialization
{
  //## begin VisaDCLogFile::VisaDCLogFile%454B372B004E_const.body preserve=yes
   memcpy(m_sID,"LR04",4);
  //## end VisaDCLogFile::VisaDCLogFile%454B372B004E_const.body
}

VisaDCLogFile::VisaDCLogFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile)
  //## begin VisaDCLogFile::VisaDCLogFile%456547EF00D2.hasinit preserve=no
      : m_pDetail(0),
        m_pHeader(0)
  //## end VisaDCLogFile::VisaDCLogFile%456547EF00D2.hasinit
  //## begin VisaDCLogFile::VisaDCLogFile%456547EF00D2.initialization preserve=yes
   ,ClearingFile(strIMAGEID,strTASKID,pszName,bVariableBlockFile)
  //## end VisaDCLogFile::VisaDCLogFile%456547EF00D2.initialization
{
  //## begin VisaDCLogFile::VisaDCLogFile%456547EF00D2.body preserve=yes
   memcpy(m_sID,"LR04",4);
  //## end VisaDCLogFile::VisaDCLogFile%456547EF00D2.body
}


VisaDCLogFile::~VisaDCLogFile()
{
  //## begin VisaDCLogFile::~VisaDCLogFile%454B372B004E_dest.body preserve=yes
  //## end VisaDCLogFile::~VisaDCLogFile%454B372B004E_dest.body
}



//## Other Operations (implementation)
bool VisaDCLogFile::read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward, bool bTruncate)
{
  //## begin VisaDCLogFile::read%45BE4CC50242.body preserve=yes
   m_hMessage.reset("LR AI ","S0059D");
   if (!GenerationDataGroup::read(psBuffer,lBufferLength,plRecordLength,bFastForward))
      return false;
   if (!bFastForward)
      return true;
   hCTF* pCTF = (hCTF*)psBuffer;
   char psTransCode[3] = {"  "};
   memcpy(psTransCode,psBuffer,2);
   int iTransCode = 100;
   if (memcmp(psTransCode,"DN",2) != 0
      && memcmp(psTransCode,"US",2) != 0)
      iTransCode = atoi(psTransCode);
   switch (iTransCode)
   {
      case 57:
         if (pCTF->cRecordType == '1')
         {
            if (pCTF->cTransComponentSeqNumber == '0')
               m_pHeader = m_hMessage.data();
            memcpy(m_pHeader,psBuffer,*plRecordLength);
            memset(m_pHeader + *plRecordLength,' ',FIXED_RECLEN - *plRecordLength);
            m_pHeader += FIXED_RECLEN;
            m_pDetail = m_pHeader;
         }
         else
         if (pCTF->cRecordType == '2'
            && pCTF->cTransComponentSeqNumber == '0')
         {
            memcpy(m_pHeader,psBuffer,*plRecordLength);
            memset(m_pHeader + *plRecordLength,' ',FIXED_RECLEN - *plRecordLength);
            m_pDetail = m_pHeader + FIXED_RECLEN;
         }
         break;
   }
   return true;
  //## end VisaDCLogFile::read%45BE4CC50242.body
}

bool VisaDCLogFile::sendBatch ()
{
  //## begin VisaDCLogFile::sendBatch%454B386D03D8.body preserve=yes
   UseCase hUseCase("LOG","## LG29 SEND VISA BATCH");
   char m_szBuffer[2500];
   m_hMessage.reset("LR AI ","S0059D");
   hTC57_TCR0_TxnDetail* pDetail = 0;
   hCTF* pCTF = 0;
   char psTransCode[3] = {"  "};
   m_iRecordsRead = 0;
   size_t m = 0;
   while (read(m_szBuffer,(size_t)2500,&m))
   {
      m_iRecordsRead++;
      pCTF = (hCTF*)m_szBuffer;
      memcpy(psTransCode,m_szBuffer,2);
      int iTransCode = 100;
      if (memcmp(psTransCode,"DN",2) != 0
         && memcmp(psTransCode,"US",2) != 0)
         iTransCode = atoi(psTransCode);
      switch (iTransCode)
      {
         case 57:
            if (pCTF->cTransCodeQualifier == '9')
            {
               if(memcmp(pCTF->sFiller,"DN",2)== 0 || memcmp(pCTF->sFiller,"UP",2) == 0 
                 || memcmp(pCTF->sFiller,"B1",2) == 0)
               {
                  memcpy(m_pDetail,m_szBuffer,m);
                  memset(m_pDetail + m,' ',FIXED_RECLEN -m);
                  m_pDetail += FIXED_RECLEN;
               }
               break;
            }
            if (pCTF->cTransComponentSeqNumber == '3'
               && memcmp(pCTF->sFiller,"X1",2) == 0)
            {
               memcpy(m_pDetail, m_szBuffer,m);
               memset(m_pDetail + m,' ',FIXED_RECLEN - m);
               m_pDetail += FIXED_RECLEN;
               break;
            }
            if ((pCTF->cRecordType == '1'
               || pCTF->cRecordType == '2')
               && pCTF->cTransComponentSeqNumber == '0')
            {
               if (m_pDetail != m_pHeader)
               {
                  pDetail = (hTC57_TCR0_TxnDetail*)m_pHeader;
                  char szTransactionAmt[13];
                  memcpy(szTransactionAmt,pDetail->sTransactionAmt,12);
                  szTransactionAmt[12] = '\00';
                  if (m_dHashTotal == -1)
                     m_dHashTotal = 0;
                  m_dHashTotal += atof(szTransactionAmt);
                  m_hMessage.setDataLength(m_pDetail - m_hMessage.data());
                  if (m_hMessage.send(m_strQueueName.c_str()) != 0)
                     return UseCase::setSuccess(false);
                  m_pDetail = m_pHeader;
               }
            }
            if (pCTF->cRecordType == '1')
            {
               if (pCTF->cTransComponentSeqNumber == '0')
                  m_pHeader = m_hMessage.data();
               memcpy(m_pHeader,m_szBuffer,m);
               memset(m_pHeader + m,' ',FIXED_RECLEN - m);
               m_pHeader += FIXED_RECLEN;
               m_pDetail = m_pHeader;
            }
            else
            if (pCTF->cRecordType == '2')
            {
               memcpy(m_pDetail,m_szBuffer,m);
               memset(m_pDetail + m,' ',FIXED_RECLEN - m);
               m_pDetail += FIXED_RECLEN;
               if (pCTF->cTransComponentSeqNumber == '0'
                  && m_dHashTotal != -1
                  && m_iRecordsRead >= m_iBatchSize)
                  return true;
            }
            break;
         case 100: // DN record or USPS record
            memcpy(m_pDetail,m_szBuffer,m);
            memset(m_pDetail + m,' ',FIXED_RECLEN - m);
            m_pDetail += FIXED_RECLEN;
            break;
         case 90: // file header record
            {
            hTCR90_FileHeader* pTCR90_FileHeader = (hTCR90_FileHeader*)m_szBuffer;
            pTCR90_FileHeader->sFiller1[0] = '\0';
            int iDay = atoi(pTCR90_FileHeader->sProcessingDate + 2);
            pTCR90_FileHeader->sProcessingDate[2] = '\0';
            Date hDate(2000 + atoi(pTCR90_FileHeader->sProcessingDate),iDay);
            setDate(hDate.asString("%Y%m%d"));
            }
            break;
         case 91: // end of batch
            break;
         case 92: // end of file
            if (m_pDetail != m_pHeader)
            {
               pDetail = (hTC57_TCR0_TxnDetail*)m_pHeader;
               char szTransactionAmt[13];
               memcpy(szTransactionAmt,pDetail->sTransactionAmt,12);
               szTransactionAmt[12] = '\00';
               if (m_dHashTotal == -1)
                  m_dHashTotal = 0;
               m_dHashTotal += atof(szTransactionAmt);
               m_hMessage.setDataLength(m_pDetail - m_hMessage.data());
               if (m_hMessage.send(m_strQueueName.c_str()) != 0)
                  return UseCase::setSuccess(false);
               m_pDetail = m_pHeader;
            }
            return true;
      }
   }
   return true;
  //## end VisaDCLogFile::sendBatch%454B386D03D8.body
}

// Additional Declarations
  //## begin VisaDCLogFile%454B372B004E.declarations preserve=yes
  //## end VisaDCLogFile%454B372B004E.declarations

//## begin module%454B4A0C035B.epilog preserve=yes
//## end module%454B4A0C035B.epilog
