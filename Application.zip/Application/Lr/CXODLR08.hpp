//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%52012E8002A9.cm preserve=no
//	$Date:   Feb 14 2020 10:56:30  $ $Author:   e1009510  $
//	$Revision:   1.0.1.0  $
//## end module%52012E8002A9.cm

//## begin module%52012E8002A9.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%52012E8002A9.cp

//## Module: CXOSLR08%52012E8002A9; Package specification
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\V02.3B.R009\Build\Dn\Server\Application\Lr\CXODLR08.hpp

#ifndef CXOSLR08_h
#define CXOSLR08_h 1

//## begin module%52012E8002A9.additionalIncludes preserve=no
//## end module%52012E8002A9.additionalIncludes

//## begin module%52012E8002A9.includes preserve=yes
//## end module%52012E8002A9.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSLR01_h
#include "CXODLR01.hpp"
#endif

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;

} // namespace monitor

//## begin module%52012E8002A9.declarations preserve=no
//## end module%52012E8002A9.declarations

//## begin module%52012E8002A9.additionalDeclarations preserve=yes
//## end module%52012E8002A9.additionalDeclarations


//## begin MasterCardDraftCaptureFile%52012E2001ED.preface preserve=yes
//## end MasterCardDraftCaptureFile%52012E2001ED.preface

//## Class: MasterCardDraftCaptureFile%52012E2001ED
//## Category: DataNavigator Foundation::Application::LogReader_CAT%354B34A1001C
//## Subsystem: LR%3597EB340165
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5201303A0158;monitor::UseCase { -> F}

class DllExport MasterCardDraftCaptureFile : public LogFile  //## Inherits: <unnamed>%52012E5702E7
{
  //## begin MasterCardDraftCaptureFile%52012E2001ED.initialDeclarations preserve=yes
  //## end MasterCardDraftCaptureFile%52012E2001ED.initialDeclarations

  public:
    //## Constructors (generated)
      MasterCardDraftCaptureFile();

    //## Constructors (specified)
      //## Operation: MasterCardDraftCaptureFile%52012FDD010F
      MasterCardDraftCaptureFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile);

    //## Destructor (generated)
      virtual ~MasterCardDraftCaptureFile();


    //## Other Operations (specified)
      //## Operation: read%52012F380271
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward = false, bool bTruncate = false);

      //## Operation: sendBatch%52012F3D02C2
      bool sendBatch ();

    // Additional Public Declarations
      //## begin MasterCardDraftCaptureFile%52012E2001ED.public preserve=yes
      //## end MasterCardDraftCaptureFile%52012E2001ED.public

  protected:
    // Additional Protected Declarations
      //## begin MasterCardDraftCaptureFile%52012E2001ED.protected preserve=yes
      //## end MasterCardDraftCaptureFile%52012E2001ED.protected

  private:
    // Additional Private Declarations
      //## begin MasterCardDraftCaptureFile%52012E2001ED.private preserve=yes
      //## end MasterCardDraftCaptureFile%52012E2001ED.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%520138D20016
      //## begin MasterCardDraftCaptureFile::Buffer%520138D20016.attr preserve=no  private: char {U} 
      char m_szBuffer[260];
      //## end MasterCardDraftCaptureFile::Buffer%520138D20016.attr

      //## Attribute: CurrentHash%520133BE0183
      //## begin MasterCardDraftCaptureFile::CurrentHash%520133BE0183.attr preserve=no  protected: double {U} 0
      double m_dCurrentHash;
      //## end MasterCardDraftCaptureFile::CurrentHash%520133BE0183.attr

      //## Attribute: Detail%5201301A0299
      //## begin MasterCardDraftCaptureFile::Detail%5201301A0299.attr preserve=no  private: char* {V} 0
      char* m_pDetail;
      //## end MasterCardDraftCaptureFile::Detail%5201301A0299.attr

      //## Attribute: Header%5201301D0289
      //## begin MasterCardDraftCaptureFile::Header%5201301D0289.attr preserve=no  private: char* {V} 0
      char m_pHeader[260];
      //## end MasterCardDraftCaptureFile::Header%5201301D0289.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LogReader_CAT::<unnamed>%52012F080222
      //## Role: MasterCardDraftCaptureFile::<m_hMessage>%52012F09003D
      //## begin MasterCardDraftCaptureFile::<m_hMessage>%52012F09003D.role preserve=no  public: IF::Message { -> VHgN}
      IF::Message m_hMessage;
      //## end MasterCardDraftCaptureFile::<m_hMessage>%52012F09003D.role

    // Additional Implementation Declarations
      //## begin MasterCardDraftCaptureFile%52012E2001ED.implementation preserve=yes
      //## end MasterCardDraftCaptureFile%52012E2001ED.implementation

};

//## begin MasterCardDraftCaptureFile%52012E2001ED.postscript preserve=yes
//## end MasterCardDraftCaptureFile%52012E2001ED.postscript

//## begin module%52012E8002A9.epilog preserve=yes
//## end module%52012E8002A9.epilog


#endif
