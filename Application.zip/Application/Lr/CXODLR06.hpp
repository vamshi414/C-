//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%49F5BEAD033D.cm preserve=no
//	$Date:   Feb 14 2020 10:56:30  $ $Author:   e1009510  $
//	$Revision:   1.2.1.0  $
//## end module%49F5BEAD033D.cm

//## begin module%49F5BEAD033D.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%49F5BEAD033D.cp

//## Module: CXOSLR06%49F5BEAD033D; Package specification
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\Devel\Dn\Server\Application\Lr\CXODLR06.hpp

#ifndef CXOSLR06_h
#define CXOSLR06_h 1

//## begin module%49F5BEAD033D.additionalIncludes preserve=no
//## end module%49F5BEAD033D.additionalIncludes

//## begin module%49F5BEAD033D.includes preserve=yes
//## end module%49F5BEAD033D.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSLR01_h
#include "CXODLR01.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Console;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;

} // namespace timer

//## begin module%49F5BEAD033D.declarations preserve=no
//## end module%49F5BEAD033D.declarations

//## begin module%49F5BEAD033D.additionalDeclarations preserve=yes
//## end module%49F5BEAD033D.additionalDeclarations


//## begin VisaBaseIILogFile%49F5B8910167.preface preserve=yes
//## end VisaBaseIILogFile%49F5B8910167.preface

//## Class: VisaBaseIILogFile%49F5B8910167
//## Category: DataNavigator Foundation::Application::LogReader_CAT%354B34A1001C
//## Subsystem: LR%3597EB340165
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%49F5B963012D;IF::Console { -> F}
//## Uses: <unnamed>%49F5B9A60061;timer::Date { -> F}
//## Uses: <unnamed>%49F5B9AC0178;monitor::UseCase { -> F}
//## Uses: <unnamed>%49F5B9B101DA;IF::Trace { -> F}

class DllExport VisaBaseIILogFile : public LogFile  //## Inherits: <unnamed>%49F5B8E001CF
{
  //## begin VisaBaseIILogFile%49F5B8910167.initialDeclarations preserve=yes
  //## end VisaBaseIILogFile%49F5B8910167.initialDeclarations

  public:
    //## Constructors (generated)
      VisaBaseIILogFile();

    //## Constructors (specified)
      //## Operation: VisaBaseIILogFile%49F5D0D20224
      VisaBaseIILogFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile);

    //## Destructor (generated)
      virtual ~VisaBaseIILogFile();


    //## Other Operations (specified)
      //## Operation: read%49F5D0DF004C
      virtual bool read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward = false, bool bTruncate = false);

      //## Operation: sendBatch%49F5D0E30214
      bool sendBatch ();

    // Additional Public Declarations
      //## begin VisaBaseIILogFile%49F5B8910167.public preserve=yes
      //## end VisaBaseIILogFile%49F5B8910167.public

  protected:
    // Additional Protected Declarations
      //## begin VisaBaseIILogFile%49F5B8910167.protected preserve=yes
      //## end VisaBaseIILogFile%49F5B8910167.protected

  private:
    // Additional Private Declarations
      //## begin VisaBaseIILogFile%49F5B8910167.private preserve=yes
      //## end VisaBaseIILogFile%49F5B8910167.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Buffer%4D7003F103DE
      //## begin VisaBaseIILogFile::Buffer%4D7003F103DE.attr preserve=no  private: char[2048] {U} 
      char m_szBuffer[2048];
      //## end VisaBaseIILogFile::Buffer%4D7003F103DE.attr

      //## Attribute: CurrentHash%4D6FD4B90079
      //## begin VisaBaseIILogFile::CurrentHash%4D6FD4B90079.attr preserve=no  private: double {U} 0
      double m_dCurrentHash;
      //## end VisaBaseIILogFile::CurrentHash%4D6FD4B90079.attr

      //## Attribute: Detail%49F5D0BA02B5
      //## begin VisaBaseIILogFile::Detail%49F5D0BA02B5.attr preserve=no  private: char* {V} 0
      char* m_pDetail;
      //## end VisaBaseIILogFile::Detail%49F5D0BA02B5.attr

      //## Attribute: Header%49F5D0BE01F3
      //## begin VisaBaseIILogFile::Header%49F5D0BE01F3.attr preserve=no  private: char* {V} 0
      char* m_pHeader;
      //## end VisaBaseIILogFile::Header%49F5D0BE01F3.attr

    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LogReader_CAT::<unnamed>%49F5B9E30145
      //## Role: VisaBaseIILogFile::<m_hMessage>%49F5B9E30362
      //## begin VisaBaseIILogFile::<m_hMessage>%49F5B9E30362.role preserve=no  public: IF::Message { -> VHgN}
      IF::Message m_hMessage;
      //## end VisaBaseIILogFile::<m_hMessage>%49F5B9E30362.role

    // Additional Implementation Declarations
      //## begin VisaBaseIILogFile%49F5B8910167.implementation preserve=yes
      //## end VisaBaseIILogFile%49F5B8910167.implementation
};

//## begin VisaBaseIILogFile%49F5B8910167.postscript preserve=yes
//## end VisaBaseIILogFile%49F5B8910167.postscript

//## begin module%49F5BEAD033D.epilog preserve=yes
//## end module%49F5BEAD033D.epilog


#endif
