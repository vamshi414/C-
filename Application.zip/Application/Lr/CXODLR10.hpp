//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6463480C02CF.cm preserve=no
//## end module%6463480C02CF.cm

//## begin module%6463480C02CF.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%6463480C02CF.cp

//## Module: CXOSLR10%6463480C02CF; Package specification
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Lr\CXODLR10.hpp

#ifndef CXOSLR10_h
#define CXOSLR10_h 1

//## begin module%6463480C02CF.additionalIncludes preserve=no
//## end module%6463480C02CF.additionalIncludes

//## begin module%6463480C02CF.includes preserve=yes
//## end module%6463480C02CF.includes

#ifndef CXOSLR09_h
#include "CXODLR09.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Context;
} // namespace database

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MidnightAlarm;
} // namespace timer

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace IF {
class DateTime;
} // namespace IF

namespace database {
class Channel;
} // namespace database

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;

} // namespace entitysegment

//## begin module%6463480C02CF.declarations preserve=no
//## end module%6463480C02CF.declarations

//## begin module%6463480C02CF.additionalDeclarations preserve=yes
//## end module%6463480C02CF.additionalDeclarations


//## begin MASClearingFile%6463448C004C.preface preserve=yes
//## end MASClearingFile%6463448C004C.preface

//## Class: MASClearingFile%6463448C004C
//## Category: DataNavigator Foundation::Application::LogReader_CAT%354B34A1001C
//## Subsystem: LR%3597EB340165
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%64634746016F;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%64634795034C;reusable::Buffer { -> F}
//## Uses: <unnamed>%646347990040;IF::Extract { -> F}
//## Uses: <unnamed>%6463479C0296;monitor::UseCase { -> F}
//## Uses: <unnamed>%646347A0001B;database::Context { -> F}
//## Uses: <unnamed>%646347A302AC;database::Channel { -> F}
//## Uses: <unnamed>%646347A7026C;process::Application { -> F}
//## Uses: <unnamed>%6483559801F6;IF::DateTime { -> F}
//## Uses: <unnamed>%6483562901E7;timer::MidnightAlarm { -> F}

class DllExport MASClearingFile : public ClearingFile  //## Inherits: <unnamed>%6463463D0246
{
  //## begin MASClearingFile%6463448C004C.initialDeclarations preserve=yes
  //## end MASClearingFile%6463448C004C.initialDeclarations

  public:
    //## Constructors (generated)
      MASClearingFile();

    //## Constructors (specified)
      //## Operation: MASClearingFile%646344B7035C
      MASClearingFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile);

    //## Destructor (generated)
      virtual ~MASClearingFile();


    //## Other Operations (specified)
      //## Operation: sendBatch%646344D300C7
      bool sendBatch ();

    // Additional Public Declarations
      //## begin MASClearingFile%6463448C004C.public preserve=yes
      //## end MASClearingFile%6463448C004C.public

  protected:
    // Additional Protected Declarations
      //## begin MASClearingFile%6463448C004C.protected preserve=yes
      //## end MASClearingFile%6463448C004C.protected

  private:
    // Additional Private Declarations
      //## begin MASClearingFile%6463448C004C.private preserve=yes
      //## end MASClearingFile%6463448C004C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Count%646345B901EF
      //## begin MASClearingFile::Count%646345B901EF.attr preserve=no  private: int {V} 1
      int m_iCount;
      //## end MASClearingFile::Count%646345B901EF.attr

      //## Attribute: Buffer%646345FF007A
      //## begin MASClearingFile::Buffer%646345FF007A.attr preserve=no  private: char[4096] {U} 
      char m_szBuffer[4096];
      //## end MASClearingFile::Buffer%646345FF007A.attr

      //## Attribute: CurrentHashValue%64634607022B
      //## begin MASClearingFile::CurrentHashValue%64634607022B.attr preserve=no  private: double {U} 0
      double m_dCurrentHashValue;
      //## end MASClearingFile::CurrentHashValue%64634607022B.attr

      //## Attribute: Date%6463460D0380
      //## begin MASClearingFile::Date%6463460D0380.attr preserve=no  protected: string {V} 
      string m_strDate;
      //## end MASClearingFile::Date%6463460D0380.attr

      //## Attribute: RecordLength%64634618029B
      //## begin MASClearingFile::RecordLength%64634618029B.attr preserve=no  private: int {U} 0
      int m_lRecordLength;
      //## end MASClearingFile::RecordLength%64634618029B.attr

    // Additional Implementation Declarations
      //## begin MASClearingFile%6463448C004C.implementation preserve=yes
      //## end MASClearingFile%6463448C004C.implementation

};

//## begin MASClearingFile%6463448C004C.postscript preserve=yes
//## end MASClearingFile%6463448C004C.postscript

//## begin module%6463480C02CF.epilog preserve=yes
//## end module%6463480C02CF.epilog


#endif
