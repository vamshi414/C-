//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C5155B601E4.cm preserve=no
//	$Date:   Jan 07 2019 15:39:14  $ $Author:   e1009839  $
//	$Revision:   1.44  $
//## end module%3C5155B601E4.cm

//## begin module%3C5155B601E4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C5155B601E4.cp

//## Module: CXOPLR00%3C5155B601E4; Package specification
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Application\Lr\CXODLR00.hpp

#ifndef CXOPLR00_h
#define CXOPLR00_h 1

//## begin module%3C5155B601E4.additionalIncludes preserve=no
//## end module%3C5155B601E4.additionalIncludes

//## begin module%3C5155B601E4.includes preserve=yes
//## end module%3C5155B601E4.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class SwitchBusinessDay;
} // namespace entitysegment

class LogFile;
class MasterCardDraftCaptureFile;
class ConnexNonStopLogFile;
class VisaBaseIILogFile;
class TransactionActivityLogFile;
class VisaDCLogFile;
class ISTClearingFile;
class NACHALogFile;
//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;

} // namespace monitor

//## begin module%3C5155B601E4.declarations preserve=no
//## end module%3C5155B601E4.declarations

//## begin module%3C5155B601E4.additionalDeclarations preserve=yes
//## end module%3C5155B601E4.additionalDeclarations


//## begin LogReader%34567BCB00E7.preface preserve=yes
//## end LogReader%34567BCB00E7.preface

//## Class: LogReader%34567BCB00E7
//	<body>
//	<title>CG
//	<h1>LR
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The Log Reader service reads an input file of messages
//	and forwards them in batches to a Transaction Interface
//	service.
//	<p>
//	<img src=CXOCLR00.gif>
//	<title>OG
//	<h1>LR
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The Log Reader service reads an input file of messages
//	and forwards them in batches to a Transaction Interface
//	service.
//	<p>
//	<img src=CXOOLR00.gif>
//	</body>
//## Category: DataNavigator Foundation::Application::LogReader_CAT%354B34A1001C
//## Subsystem: LR%3597EB340165
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3C515CE001C5;database::Database { -> F}
//## Uses: <unnamed>%3C516A8701C5;IF::Extract { -> F}
//## Uses: <unnamed>%40ACB68F00AB;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%4565542B03BD;NACHALogFile { -> F}
//## Uses: <unnamed>%4565547A01E5;VisaDCLogFile { -> F}
//## Uses: <unnamed>%45700C020103;monitor::UseCase { -> F}
//## Uses: <unnamed>%4935657F00C0;TransactionActivityLogFile { -> F}
//## Uses: <unnamed>%49F5FEAE038D;VisaBaseIILogFile { -> F}
//## Uses: <unnamed>%4D360A1203DA;ISTClearingFile { -> F}
//## Uses: <unnamed>%515EED0A03D1;ConnexNonStopLogFile { -> F}
//## Uses: <unnamed>%52399FC40391;MasterCardDraftCaptureFile { -> F}
//## Uses: <unnamed>%53444B4B011E;entitysegment::SwitchBusinessDay { -> F}

class LogReader : public process::Application  //## Inherits: <unnamed>%3505A67501D7
{
  //## begin LogReader%34567BCB00E7.initialDeclarations preserve=yes
  //## end LogReader%34567BCB00E7.initialDeclarations

  public:
    //## Constructors (generated)
      LogReader();

    //## Destructor (generated)
      virtual ~LogReader();


    //## Other Operations (specified)
      //## Operation: initialize%3C51567603B9
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>LR
      //	<h2>MS
      //	<!-- LogReader::initialize : Preconditions -->
      //	<h3>Task Options
      //	<p>
      //	A Log Reader service can process log files from one of
      //	the following platforms.
      //	The name of the associated Transaction Interface program
      //	in the task user data indicates the platform.
      //	<p>
      //	<table>
      //	<tr>
      //	<th>Platform
      //	<th>Task: User Data
      //	<tr>
      //	<td>FIS Connex on HP
      //	<td>CXOPAI00
      //	<tr>
      //	<td>FIS Connex on IBM
      //	<td>CXOPII00
      //	<tr>
      //	<td>FIS IST
      //	<td>CXOPOI00
      //	<tr>
      //	<td>FIS IST Clearing
      //	<td>CXOPOI00
      //	<tr>
      //	<td>FIS Transaction Activity
      //	<td>CXOPYI00
      //	<tr>
      //	<td>FIS ACH-PS
      //	<td>CXOPNI00
      //	<tr>
      //	<td>ACI Base24
      //	<td>CXOPBI00
      //	<tr>
      //	<td>MasterCard IPM
      //	<td>CXOPMI00
      //	<tr>
      //	<td>VISA Base II
      //	<td>CXOPVI00
      //	<tr>
      //	<td>All other (Generic)
      //	<td>CXOPXI00
      //	</table>
      //	<p>
      //	Use CR Client for the DataNavigator Server to change the
      //	Log Reader in the Task book.
      //	Specify the interface program name in the task user data.
      //	<h3>Business Day Close
      //	<p>
      //	The processing of clearing items from the MasterCard IPM
      //	and VISA Base II files must be completed before the
      //	business day is closed in DataNavigator.
      //	Configure the number of files expected each business day.
      //	The default value is 1 file per day.
      //	<p>
      //	The Log Reader task will update 'CHANNEL PROGRESS' in
      //	the TASK _CONTEXT table when the expected number of
      //	files is processed.
      //	The value will be set to the business date and switch
      //	EOD time from the STS_CUSTOMER table.
      //	<p>
      //	Use the CR Client for the DataNavigator Server to change
      //	the Log Reader in the Task book.
      //	The file count can be changed by specifying
      //	FILES=<i>n</i> in the task user data.
      //	The minimum value for <i>n</i> is 1.
      //	<h3>Tuning
      //	<p>
      //	The Log Reader service sends transactions in batches to
      //	the Transaction Interface service.
      //	The default value is 500 transactions per batch.
      //	<p>
      //	DataNavigator transaction loading forces all Load Engine
      //	services to commit at the end of each batch sent by the
      //	Log Reader service.
      //	Confirmation messages (including hash totals) are
      //	returned to the Log Reader following each batch.
      //	If the confirmation fails, the affected batch is resent
      //	until successful.
      //	<p>
      //	The batch size can be increased if necessary to handle
      //	higher volumes of transactions.
      //	The downside is the amount of reprocessing done if
      //	database failures (e.g. contention) occur during the
      //	loading of a batch.
      //	<p>
      //	Use the CR Client for the DataNavigator Server to change
      //	the Log Reader in the Task book.
      //	The batch size can be changed by specifying
      //	BATCH=<i>n</i> in the task user data.
      //	The minimum value for <i>n</i> is 500.
      //	The maximum value is 5000.
      //	</body>
      virtual int initialize ();

    // Additional Public Declarations
      //## begin LogReader%34567BCB00E7.public preserve=yes
      //## end LogReader%34567BCB00E7.public

  protected:

    //## Other Operations (specified)
      //## Operation: onReset%45C255D1002E
      virtual int onReset (Message& hMessage);

      //## Operation: onResume%45B913280119
      virtual int onResume (Message& hMessage);

    // Additional Protected Declarations
      //## begin LogReader%34567BCB00E7.protected preserve=yes
      //## end LogReader%34567BCB00E7.protected

  private:
    // Additional Private Declarations
      //## begin LogReader%34567BCB00E7.private preserve=yes
      //## end LogReader%34567BCB00E7.private

  private: //## implementation
    // Data Members for Associations

      //## Association: DataNavigator Foundation::Application::LogReader_CAT::<unnamed>%454BA27800EA
      //## Role: LogReader::<m_pLogFile>%454BA279003E
      //## begin LogReader::<m_pLogFile>%454BA279003E.role preserve=no  public: LogFile { -> RFHgN}
      LogFile *m_pLogFile;
      //## end LogReader::<m_pLogFile>%454BA279003E.role

    // Additional Implementation Declarations
      //## begin LogReader%34567BCB00E7.implementation preserve=yes
      //## end LogReader%34567BCB00E7.implementation

};

//## begin LogReader%34567BCB00E7.postscript preserve=yes
//## end LogReader%34567BCB00E7.postscript

//## begin module%3C5155B601E4.epilog preserve=yes
//## end module%3C5155B601E4.epilog


#endif
