//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%534407BE020E.cm preserve=no
//	$Date:   May 20 2020 16:59:34  $ $Author:   e1009510  $
//	$Revision:   1.4  $
//## end module%534407BE020E.cm

//## begin module%534407BE020E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%534407BE020E.cp

//## Module: CXOSLR09%534407BE020E; Package body
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Application\Lr\CXOSLR09.cpp

//## begin module%534407BE020E.additionalIncludes preserve=no
//## end module%534407BE020E.additionalIncludes

//## begin module%534407BE020E.includes preserve=yes
#include "CXODTM03.hpp"
//## end module%534407BE020E.includes

#ifndef CXOSDB28_h
#include "CXODDB28.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSLR09_h
#include "CXODLR09.hpp"
#endif


//## begin module%534407BE020E.declarations preserve=no
//## end module%534407BE020E.declarations

//## begin module%534407BE020E.additionalDeclarations preserve=yes
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
//## end module%534407BE020E.additionalDeclarations


// Class ClearingFile 

ClearingFile::ClearingFile()
  //## begin ClearingFile::ClearingFile%534404530125_const.hasinit preserve=no
      : m_iCount(1)
  //## end ClearingFile::ClearingFile%534404530125_const.hasinit
  //## begin ClearingFile::ClearingFile%534404530125_const.initialization preserve=yes
  //## end ClearingFile::ClearingFile%534404530125_const.initialization
{
  //## begin ClearingFile::ClearingFile%534404530125_const.body preserve=yes
  //## end ClearingFile::ClearingFile%534404530125_const.body
}

ClearingFile::ClearingFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile)
  //## begin ClearingFile::ClearingFile%53444607004A.hasinit preserve=no
      : m_iCount(1)
  //## end ClearingFile::ClearingFile%53444607004A.hasinit
  //## begin ClearingFile::ClearingFile%53444607004A.initialization preserve=yes
   ,LogFile(strIMAGEID,strTASKID,pszName,bVariableBlockFile)
  //## end ClearingFile::ClearingFile%53444607004A.initialization
{
  //## begin ClearingFile::ClearingFile%53444607004A.body preserve=yes
   Extract::instance()->getLong("DUSER   ","FILES=",&m_iCount);
  //## end ClearingFile::ClearingFile%53444607004A.body
}


ClearingFile::~ClearingFile()
{
  //## begin ClearingFile::~ClearingFile%534404530125_dest.body preserve=yes
  //## end ClearingFile::~ClearingFile%534404530125_dest.body
}



//## Other Operations (implementation)
bool ClearingFile::commit ()
{
  //## begin ClearingFile::commit%5344062501C9.body preserve=yes
   Context hContext(getIMAGEID(),getTASKID());
   string strCONTEXT_DATA;
   if (hContext.get(getCONTEXT_KEY().c_str(),strCONTEXT_DATA,'F') == false)
      return false;
   entitysegment::SwitchBusinessDay::instance()->update(MidnightAlarm::instance());
   vector<string> hTokens;
   Buffer::parse(strCONTEXT_DATA," ",hTokens);
   int iCount = 0;
   if (m_strDate.empty())
      iCount = (hTokens.size() == 2 && entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(1) == hTokens[0]) ? atoi(hTokens[1].c_str()) + 1 : 1;
   else
      iCount = (hTokens.size() == 2 && m_strDate == hTokens[0]) ? atoi(hTokens[1].c_str()) + 1 : 1;
   char szCONTEXT_DATA[9 + PERCENTD];
   if (m_strDate.empty())
      memcpy(szCONTEXT_DATA, entitysegment::SwitchBusinessDay::instance()->getDATE_RECON(1).data(),8);
   else
      memcpy(szCONTEXT_DATA,m_strDate.data(),8);
   snprintf(szCONTEXT_DATA + 8,sizeof(szCONTEXT_DATA)-8," %04d",iCount);
   if (!hContext.put(getCONTEXT_KEY().c_str(),szCONTEXT_DATA,'F'))
      return false;
   if (iCount >= m_iCount)
   {
      Channel hChannel(Application::instance()->image(),Application::instance()->name());
      string strTimestamp;
      strTimestamp = entitysegment::SwitchBusinessDay::instance()->getTSTAMP_END(2);
      DateTime::adjust(strTimestamp, -1);
      if (!hChannel.setProgress(strTimestamp,0))
         return false;
   }
   return GenerationDataGroup::commit();
  //## end ClearingFile::commit%5344062501C9.body
}

// Additional Declarations
  //## begin ClearingFile%534404530125.declarations preserve=yes
  //## end ClearingFile%534404530125.declarations

//## begin module%534407BE020E.epilog preserve=yes
//## end module%534407BE020E.epilog
