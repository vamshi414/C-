//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%515DF08402A8.cm preserve=no
//	$Date:   May 20 2020 17:09:52  $ $Author:   e1009510  $
//	$Revision:   1.2  $
//## end module%515DF08402A8.cm

//## begin module%515DF08402A8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%515DF08402A8.cp

//## Module: CXOSLR07%515DF08402A8; Package body
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\bV02.3B.R001\Windows\Build\Dn\Server\Application\Lr\CXOSLR07.cpp

//## begin module%515DF08402A8.additionalIncludes preserve=no
//## end module%515DF08402A8.additionalIncludes

//## begin module%515DF08402A8.includes preserve=yes
#ifdef _WIN32
//#include <winsock.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
#include "CXODRS28.hpp"
//## end module%515DF08402A8.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSDB37_h
#include "CXODDB37.hpp"
#endif
#ifndef CXOSRU37_h
#include "CXODRU37.hpp"
#endif
#ifndef CXOSLR07_h
#include "CXODLR07.hpp"
#endif


//## begin module%515DF08402A8.declarations preserve=no
//## end module%515DF08402A8.declarations

//## begin module%515DF08402A8.additionalDeclarations preserve=yes
//## end module%515DF08402A8.additionalDeclarations


// Class ConnexNonStopLogFile 

ConnexNonStopLogFile::ConnexNonStopLogFile()
  //## begin ConnexNonStopLogFile::ConnexNonStopLogFile%515DEFF8024F_const.hasinit preserve=no
      : m_iSizeOf2400(0)
  //## end ConnexNonStopLogFile::ConnexNonStopLogFile%515DEFF8024F_const.hasinit
  //## begin ConnexNonStopLogFile::ConnexNonStopLogFile%515DEFF8024F_const.initialization preserve=yes
  //## end ConnexNonStopLogFile::ConnexNonStopLogFile%515DEFF8024F_const.initialization
{
  //## begin ConnexNonStopLogFile::ConnexNonStopLogFile%515DEFF8024F_const.body preserve=yes
   memcpy(m_sID,"LR07",4);
  //## end ConnexNonStopLogFile::ConnexNonStopLogFile%515DEFF8024F_const.body
}

ConnexNonStopLogFile::ConnexNonStopLogFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile)
  //## begin ConnexNonStopLogFile::ConnexNonStopLogFile%515ECF8B009B.hasinit preserve=no
      : m_iSizeOf2400(0)
  //## end ConnexNonStopLogFile::ConnexNonStopLogFile%515ECF8B009B.hasinit
  //## begin ConnexNonStopLogFile::ConnexNonStopLogFile%515ECF8B009B.initialization preserve=yes
   ,m_hMemory(32768,true)
   ,LogFile(strIMAGEID,strTASKID,pszName,bVariableBlockFile)
  //## end ConnexNonStopLogFile::ConnexNonStopLogFile%515ECF8B009B.initialization
{
  //## begin ConnexNonStopLogFile::ConnexNonStopLogFile%515ECF8B009B.body preserve=yes
   memcpy(m_sID,"LR07",4);
  //## end ConnexNonStopLogFile::ConnexNonStopLogFile%515ECF8B009B.body
}


ConnexNonStopLogFile::~ConnexNonStopLogFile()
{
  //## begin ConnexNonStopLogFile::~ConnexNonStopLogFile%515DEFF8024F_dest.body preserve=yes
  //## end ConnexNonStopLogFile::~ConnexNonStopLogFile%515DEFF8024F_dest.body
}



//## Other Operations (implementation)
bool ConnexNonStopLogFile::read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward, bool bTruncate)
{
  //## begin ConnexNonStopLogFile::read%515DF0420053.body preserve=yes
   if (!GenerationDataGroup::read(psBuffer,lBufferLength,plRecordLength,bFastForward))
      return false;
   if (!bFastForward)
      return true;
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)psBuffer;
   if (ntohs(pV13AdvantageHeader->siHdrMsgCode == 2400))
   {
      memcpy((char*)m_hMemory,psBuffer + m_iSizeOf2400,*plRecordLength);
      m_iSizeOf2400 += *plRecordLength;
   }
   else
      m_iSizeOf2400 = 0;
   return true;
  //## end ConnexNonStopLogFile::read%515DF0420053.body
}

bool ConnexNonStopLogFile::sendBatch ()
{
  //## begin ConnexNonStopLogFile::sendBatch%515DF035012B.body preserve=yes
   UseCase hUseCase("LOG","## LG24 SEND BATCH");
   Message* pMessage = Message::instance(Message::OUTBOUND);
   pMessage->reset("LR AI ","S0059D");
   hV13AdvantageHeader* pAdvgHeader = (hV13AdvantageHeader*)pMessage->data();
   size_t lBufferLength = pMessage->bufferLength() - (pMessage->data() - pMessage->buffer());
   m_iRecordsRead = 0;
   size_t m = 0;
   while (read(pMessage->data(),lBufferLength,&m))
   {
      m_iRecordsRead++;
      char szEyeCatcher[7] = {0x3E,0x44,0x53,0x53,0x2A,0x3C};  //ascii  ">DSS*<"
      if (m > sizeof(struct encryptionHeader)
         && memcmp(pMessage->data(),szEyeCatcher,6) == 0)
      {
         struct encryptionHeader* pHeader = (struct encryptionHeader*)pMessage->data();
         string strKeyId("DK");
         strKeyId.append(pHeader->checkDigits,4);
#ifdef MVS
         if (KeyRing::instance()->isICSF()) //hardware encryption specified
         {
            strKeyId.assign("IBM");
            strKeyId.append(pHeader->checkDigits,4);
            CodeTable::translate((char*)strKeyId.data()+3,4,CodeTable::CX_ASCII_TO_EBCDIC);
         }
         else
            CodeTable::translate((char*)strKeyId.data()+2,4,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
         DESKey* pKey = (DESKey*)KeyRing::instance()->getKey(strKeyId);
         if (pKey)
         {
            short sLength = pHeader->version == 256 ? ntohs(pHeader->recordLength) : pHeader->recordLength;
            string strDATA(pMessage->data() + sizeof(struct encryptionHeader),m - sizeof(struct encryptionHeader));
            pKey->decrypt(strDATA);
            m = sLength;
            memcpy(pMessage->data(),strDATA.data(),sLength);
         }
      }
      hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)pMessage->data();
      short siMsgCode = ntohs(pV13AdvantageHeader->siHdrMsgCode);
      if (siMsgCode == 2400)
      {
         memcpy((char*)m_hMemory,pMessage->data() + m_iSizeOf2400,m);
         m_iSizeOf2400 += m;
         continue;
      }
      if (m_iSizeOf2400)
      {
         memcpy(pMessage->data() + m,(char*)m_hMemory,m_iSizeOf2400);
         m += m_iSizeOf2400;
         m_iSizeOf2400 = 0;
      }
      pMessage->setDataLength((unsigned short)m);
      bool bAsciiInput = true;
      //Check for the leading $ on the source and destination
      if (pV13AdvantageHeader->sHdrSource[0] == 0x5B && pV13AdvantageHeader->sHdrDestination[0] == 0x5B)
         bAsciiInput = false;
      char sTemp[8];
      memcpy(sTemp,&m_lNumber,4);
      memcpy(sTemp + 4,&m_lProgress,4);
      pMessage->setReceiverSTCKValue(sTemp);
      if (pMessage->send(m_strQueueName.c_str()) != 0)
      {
         return UseCase::setSuccess(false);
      }
      UseCase::addItem();
      if (m_dHashTotal == -1)
         m_dHashTotal = 0;
      m_dHashTotal += ntohl(pAdvgHeader->lHdrTstamp2Hash);
      if (m_iRecordsRead == m_iBatchSize)
      {
         return true;
      }
   }
   return true;
  //## end ConnexNonStopLogFile::sendBatch%515DF035012B.body
}

// Additional Declarations
  //## begin ConnexNonStopLogFile%515DEFF8024F.declarations preserve=yes
  //## end ConnexNonStopLogFile%515DEFF8024F.declarations

//## begin module%515DF08402A8.epilog preserve=yes
//## end module%515DF08402A8.epilog
