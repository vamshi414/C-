//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%49F5BEB4024D.cm preserve=no
//	$Date:   May 20 2020 17:05:22  $ $Author:   e1009510  $
//	$Revision:   1.2.1.1  $
//## end module%49F5BEB4024D.cm

//## begin module%49F5BEB4024D.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%49F5BEB4024D.cp

//## Module: CXOSLR06%49F5BEB4024D; Package body
//## Subsystem: LR%3597EB340165
//	.
//## Source file: C:\Devel\Dn\Server\Application\Lr\CXOSLR06.cpp

//## begin module%49F5BEB4024D.additionalIncludes preserve=no
//## end module%49F5BEB4024D.additionalIncludes

//## begin module%49F5BEB4024D.includes preserve=yes
#include "CXODVP04.hpp"
#define FIXED_RECLEN 350
//## end module%49F5BEB4024D.includes

#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSLR06_h
#include "CXODLR06.hpp"
#endif


//## begin module%49F5BEB4024D.declarations preserve=no
//## end module%49F5BEB4024D.declarations

//## begin module%49F5BEB4024D.additionalDeclarations preserve=yes
//## end module%49F5BEB4024D.additionalDeclarations


// Class VisaBaseIILogFile 

VisaBaseIILogFile::VisaBaseIILogFile()
  //## begin VisaBaseIILogFile::VisaBaseIILogFile%49F5B8910167_const.hasinit preserve=no
      : m_dCurrentHash(0),
        m_pDetail(0),
        m_pHeader(0)
  //## end VisaBaseIILogFile::VisaBaseIILogFile%49F5B8910167_const.hasinit
  //## begin VisaBaseIILogFile::VisaBaseIILogFile%49F5B8910167_const.initialization preserve=yes
  //## end VisaBaseIILogFile::VisaBaseIILogFile%49F5B8910167_const.initialization
{
  //## begin VisaBaseIILogFile::VisaBaseIILogFile%49F5B8910167_const.body preserve=yes
   memcpy(m_sID,"LR06",4);
  //## end VisaBaseIILogFile::VisaBaseIILogFile%49F5B8910167_const.body
}

VisaBaseIILogFile::VisaBaseIILogFile (const string& strIMAGEID, const string& strTASKID, const char* pszName, bool bVariableBlockFile)
  //## begin VisaBaseIILogFile::VisaBaseIILogFile%49F5D0D20224.hasinit preserve=no
      : m_dCurrentHash(0),
        m_pDetail(0),
        m_pHeader(0)
  //## end VisaBaseIILogFile::VisaBaseIILogFile%49F5D0D20224.hasinit
  //## begin VisaBaseIILogFile::VisaBaseIILogFile%49F5D0D20224.initialization preserve=yes
   ,LogFile(strIMAGEID,strTASKID,pszName,bVariableBlockFile)
  //## end VisaBaseIILogFile::VisaBaseIILogFile%49F5D0D20224.initialization
{
  //## begin VisaBaseIILogFile::VisaBaseIILogFile%49F5D0D20224.body preserve=yes
   memcpy(m_sID,"LR06",4);
  //## end VisaBaseIILogFile::VisaBaseIILogFile%49F5D0D20224.body
}


VisaBaseIILogFile::~VisaBaseIILogFile()
{
  //## begin VisaBaseIILogFile::~VisaBaseIILogFile%49F5B8910167_dest.body preserve=yes
  //## end VisaBaseIILogFile::~VisaBaseIILogFile%49F5B8910167_dest.body
}



//## Other Operations (implementation)
bool VisaBaseIILogFile::read (char* psBuffer, size_t lBufferLength, size_t* plRecordLength, bool bFastForward, bool bTruncate)
{
  //## begin VisaBaseIILogFile::read%49F5D0DF004C.body preserve=yes
   m_hMessage.reset("LR AI ","S0059D");
   if (!GenerationDataGroup::read(psBuffer,lBufferLength,plRecordLength,bFastForward))
      return false;
   if (!bFastForward)
      return true;
   int m = *plRecordLength;
   hCTF* pCTF = (hCTF*)psBuffer;;
   char psTransCode[3] = {"  "};
   memcpy(psTransCode,psBuffer,2);
   int iTransCode = atoi(psTransCode);
   switch (iTransCode)
   {  //records 5-37 do not have header records
      //but they can have multiple records
      case 5:
      case 6:
      case 7:
      case 9:
      case 15:
      case 16:
      case 17:
      case 19:
      case 20:
      case 25:
      case 26:
      case 27:
      case 35:
      case 36:
      case 37:
         if(pCTF->cTransComponentSeqNumber == '0')
         {  //start of new logical record
            m_pHeader = m_hMessage.data();
            m_pDetail = m_pHeader;
            memcpy(m_pDetail,psBuffer,m);
            memset(m_pDetail + m,' ',FIXED_RECLEN - m);
            char szHash[5];
            memcpy(szHash,m_pDetail,4);
            szHash[4] = '\00';
            m_dCurrentHash = atoi(szHash); 
            m_pDetail += FIXED_RECLEN;
         }
         else
         {  //continuation of record
            memcpy(m_pDetail,psBuffer,m);
            memset(m_pDetail + m,' ',FIXED_RECLEN - m);
            m_pDetail += FIXED_RECLEN;
         }
         break;
      case 33:
         if (pCTF->cTransComponentSeqNumber == '0' && memcmp(pCTF->sFiller + 12, "CP01", 4))
         {
            m_pHeader = m_hMessage.data();
            m_pDetail = m_pHeader;
            memcpy(m_pDetail, psBuffer, m);
            memset(m_pDetail + m, ' ', FIXED_RECLEN - m);
            char szHash[13];
            memcpy(szHash, m_pDetail + 95, 12);
            szHash[12] = '\0';
            m_dCurrentHash = atoi(szHash);
            m_pDetail += FIXED_RECLEN;
         }
         else if (!(memcmp(pCTF->sFiller + 12, "TRLR", 4) == 0 || memcmp(pCTF->sFiller + 12, "HEDR", 4) == 0
            || memcmp(pCTF->sFiller + 12, "CP01", 4) == 0))
         {  //continuation of record
            memcpy(m_pDetail, psBuffer, m);
            memset(m_pDetail + m, ' ', FIXED_RECLEN - m);
            m_pDetail += FIXED_RECLEN;
         }
         break;
      case 57:
         if(pCTF->cRecordType == '1')
         {  //header records
            if(memcmp(m_hMessage.data(),"5700",4) == 0 )
            {  //Batch Header TCR0 
               m_pHeader = m_hMessage.data();
               memcpy(m_pHeader,psBuffer,m);
               memset(m_pHeader + m,' ',FIXED_RECLEN - m);
               m_pHeader += FIXED_RECLEN;
               m_pDetail = m_pHeader;
            }
            else
            if(memcmp(m_hMessage.data(),"5701",4) == 0 )
            {  //batch header TRC1 - continuation of header info
               memcpy(m_pHeader,psBuffer,m);
               memset(m_pHeader + m,' ',FIXED_RECLEN - m);
               m_pHeader += FIXED_RECLEN;
               m_pDetail = m_pHeader;
            }
         }
         else
         if (pCTF->cRecordType == '2')
         {  //detail records
            if(memcmp(m_hMessage.data(),"5700",4) == 0)
            {  //capture hash from main detail record
               memcpy(m_pDetail,psBuffer,m);
               memset(m_pDetail + m,' ',FIXED_RECLEN - m);
               m_pDetail += FIXED_RECLEN;
               char szHash[5];
               hTC57_TCR0_TxnDetail* pDtl = (hTC57_TCR0_TxnDetail*)m_hMessage.data();
               memcpy(szHash,pDtl->sAccountNumber+12,4);
               szHash[4] = '\00';
               m_dCurrentHash = atoi(szHash); 
               memcpy(szHash,pDtl->sTransactionTimeHHMM,4);
               m_dCurrentHash += atoi(szHash); 
            }
            else
            if(memcmp(m_hMessage.data(),"5701",4) == 0 ||
               memcmp(m_hMessage.data(),"5702",4) == 0 ||
               memcmp(m_hMessage.data(),"5703",4) == 0 ||
               memcmp(m_hMessage.data(),"5704",4) == 0 ||
               memcmp(m_hMessage.data(),"5705",4) == 0 )
            {  //append other detail records
               memcpy(m_pDetail,psBuffer,m);
               memset(m_pDetail + m,' ',FIXED_RECLEN - m);
               m_pDetail += FIXED_RECLEN;
            }
         }
   }
   return true;
  //## end VisaBaseIILogFile::read%49F5D0DF004C.body
}

bool VisaBaseIILogFile::sendBatch ()
{
  //## begin VisaBaseIILogFile::sendBatch%49F5D0E30214.body preserve=yes
   UseCase hUseCase("LOG","## LG29 SEND VISA BATCH");
   m_hMessage.reset("LR AI ","S0059D");
   hCTF* pCTF = 0;
   char psTransCode[3] = {"  "};
   m_iRecordsRead = 0;
   size_t m = 0;
   while (read(m_szBuffer,2048,&m))
   {
      m_iRecordsRead++;
      pCTF = (hCTF*)m_szBuffer;
      memcpy(psTransCode,m_szBuffer,2);
      int iTransCode = atoi(psTransCode);
      switch (iTransCode)
      {  //records 5-37 do not have header records
         //but they can have multiple records
         case 5:
         case 6:
         case 7:
         case 9:
         case 15:
         case 16:
         case 17:
         case 19:
         case 20:
         case 25:
         case 26:
         case 27:
         case 35:
         case 36:
         case 37:
            if(pCTF->cTransComponentSeqNumber == '0')
            {
               if (m_dCurrentHash > 0)
               {  //one in buffer to send
                  if (m_dHashTotal == -1)
                     m_dHashTotal = 0;
                  m_dHashTotal += m_dCurrentHash;
                  m_dCurrentHash = 0;
                  m_hMessage.setDataLength(m_pDetail - m_hMessage.data());
                  if (m_hMessage.send(m_strQueueName.c_str()) != 0)
                     return UseCase::setSuccess(false);
               }
               m_pHeader = m_hMessage.data();
               m_pDetail = m_pHeader;
               memcpy(m_pDetail,m_szBuffer,m);
               memset(m_pDetail + m,' ',FIXED_RECLEN - m);
               char szHash[5];
               memcpy(szHash,m_pDetail,4);
               szHash[4] = '\00';
               m_dCurrentHash += atoi(szHash); 
               m_pDetail += FIXED_RECLEN;
               if (m_iRecordsRead >= m_iBatchSize)
                  return true;
            }
            else
            {
               memcpy(m_pDetail,m_szBuffer,m);
               memset(m_pDetail + m,' ',FIXED_RECLEN - m);
               m_pDetail += FIXED_RECLEN;
            }
            break;
         case 33:
            if (pCTF->cTransComponentSeqNumber == '0' && memcmp(pCTF->sFiller + 12, "CP01", 4) == 0)
            {
               if (m_dCurrentHash > 0)
               {  //one in buffer to send
                  if (m_dHashTotal == -1)
                     m_dHashTotal = 0;
                  m_dHashTotal += m_dCurrentHash;
                  m_dCurrentHash = 0;
                  m_hMessage.setDataLength(m_pDetail - m_hMessage.data());
                  if (m_hMessage.send(m_strQueueName.c_str()) != 0)
                  {
                     return UseCase::setSuccess(false);
                  }
               }
               m_pHeader = m_hMessage.data();
               m_pDetail = m_pHeader;
               memcpy(m_pDetail, m_szBuffer, m);
               memset(m_pDetail + m, ' ', FIXED_RECLEN - m);
               char szHash[13];
               memcpy(szHash, m_pDetail + 95, 12);
               szHash[12] = '\0';
               m_dCurrentHash += atoi(szHash);
               m_pDetail += FIXED_RECLEN;
               if (m_iRecordsRead >= m_iBatchSize)
                  return true;
            }
            else if (!(memcmp(pCTF->sFiller + 12, "TRLR", 4) == 0 || memcmp(pCTF->sFiller + 12, "HEDR", 4) == 0
               || memcmp(pCTF->sFiller + 12, "CP01", 4) == 0))
            {
               memcpy(m_pDetail, m_szBuffer, m);
               memset(m_pDetail + m, ' ', FIXED_RECLEN - m);
               m_pDetail += FIXED_RECLEN;
            }
            break;
         case 57:
            if(pCTF->cRecordType == '1')
            {  //header records
               if(memcmp(pCTF,"5700",4) == 0 )
               {  //Batch Header TCR0 
                  if (m_dCurrentHash > 0)
                  {  //one in buffer to send
                     if (m_dHashTotal == -1)
                        m_dHashTotal = 0;
                     m_dHashTotal += m_dCurrentHash;
                     m_dCurrentHash = 0;
                     m_hMessage.setDataLength(m_pDetail - m_hMessage.data());
                     if (m_hMessage.send(m_strQueueName.c_str()) != 0)
                        return UseCase::setSuccess(false);
                  }
                  m_pHeader = m_hMessage.data();
                  memcpy(m_pHeader,m_szBuffer,m);
                  memset(m_pHeader + m,' ',FIXED_RECLEN - m);
                  m_pHeader += FIXED_RECLEN;
                  m_pDetail = m_pHeader;
                  if (m_iRecordsRead >= m_iBatchSize)
                     return true;
               }
               else
               if(memcmp(pCTF,"5701",4) == 0 )
               {  //batch header TRC1 - continuation of header info
                  memcpy(m_pHeader,m_szBuffer,m);
                  memset(m_pHeader + m,' ',FIXED_RECLEN - m);
                  m_pHeader += FIXED_RECLEN;
                  m_pDetail = m_pHeader;
               }
            }
            else
            if (pCTF->cRecordType == '2')
            {  //detail records
               if(memcmp(pCTF,"5700",4) == 0)
               {  //capture hash from main detail record
                  memcpy(m_pDetail,m_szBuffer,m);
                  memset(m_pDetail + m,' ',FIXED_RECLEN - m);
                  char szHash[5];
                  hTC57_TCR0_TxnDetail* pDtl = (hTC57_TCR0_TxnDetail*)m_pDetail;
                  memcpy(szHash,pDtl->sAccountNumber+12,4);
                  szHash[4] = '\00';
                  m_dCurrentHash = atoi(szHash); 
                  memcpy(szHash,pDtl->sTransactionTimeHHMM,4);
                  m_dCurrentHash += atoi(szHash); 
                  m_pDetail += FIXED_RECLEN;

               }
               else
               if(memcmp(pCTF,"5701",4) == 0 ||
                  memcmp(pCTF,"5702",4) == 0 ||
                  memcmp(pCTF,"5703",4) == 0 ||
                  memcmp(pCTF,"5704",4) == 0 ||
                  memcmp(pCTF,"5705",4) == 0 )
               {  //append other detail records
                  memcpy(m_pDetail,m_szBuffer,m);
                  memset(m_pDetail + m,' ',FIXED_RECLEN - m);
                  m_pDetail += FIXED_RECLEN;
               }
            }   
            break;
         case 90: // file header record
            break;
         case 91: // end of batch
            break;
         case 92: // end of file
            if (m_dCurrentHash > 0)
            {  //send last transaction
               if (m_dHashTotal == -1)
                  m_dHashTotal = 0;
               m_dHashTotal += m_dCurrentHash;
               m_dCurrentHash = 0;
               m_hMessage.setDataLength(m_pDetail - m_hMessage.data());
               if (m_hMessage.send(m_strQueueName.c_str()) != 0)
                  return UseCase::setSuccess(false);
               m_pDetail = m_pHeader;
            }
            return true;
         default:
            break;
      }
   }
   return true;
  //## end VisaBaseIILogFile::sendBatch%49F5D0E30214.body
}

// Additional Declarations
  //## begin VisaBaseIILogFile%49F5B8910167.declarations preserve=yes
  //## end VisaBaseIILogFile%49F5B8910167.declarations

//## begin module%49F5BEB4024D.epilog preserve=yes
//## end module%49F5BEB4024D.epilog
