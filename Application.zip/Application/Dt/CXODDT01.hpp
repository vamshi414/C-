//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%419CCB6402CE.cm preserve=no
//## end module%419CCB6402CE.cm

//## begin module%419CCB6402CE.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%419CCB6402CE.cp

//## Module: CXOSDT01%419CCB6402CE; Package specification
//## Subsystem: DT%41A35178038A
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Dt\CXODDT01.hpp

#ifndef CXOSDT01_h
#define CXOSDT01_h 1

//## begin module%419CCB6402CE.additionalIncludes preserve=no
//## end module%419CCB6402CE.additionalIncludes

//## begin module%419CCB6402CE.includes preserve=yes
//## end module%419CCB6402CE.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSDT02_h
#include "CXODDT02.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntityHierarchy_CAT%394E27190055
namespace entityhierarchy {
class Contact;
} // namespace entityhierarchy

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class DateTime;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
class Statement;
class SelectStatement;
class Query;
class FormatSelectVisitor;
} // namespace reusable

namespace IF {
class FlatFile;
class Trace;
class Memory;
class Extract;
class Job;
class Sleep;
class Timestamp;
class Console;
class SiteSpecification;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
class Interval;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Timer;
class Clock;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
class ExportFile;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Data Distribution::Report_CAT%5C473883000E
namespace report {
class TerminalActivity;

} // namespace report

//## begin module%419CCB6402CE.declarations preserve=no
//## end module%419CCB6402CE.declarations

//## begin module%419CCB6402CE.additionalDeclarations preserve=yes
//## end module%419CCB6402CE.additionalDeclarations


//## begin FileWriter%419CCAB200DA.preface preserve=yes
//## end FileWriter%419CCAB200DA.preface

//## Class: FileWriter%419CCAB200DA
//	<body>
//	<title>CG
//	<h1>DT
//	<h2>MS
//	<!-- File Writer : General -->
//	<body>
//	<h3 id="DT01">How do I configure an export file
//	<p>
//	There are three steps to configuring file distribution
//	using the CR Client for the DataNavigator Server:
//	<ul>
//	<li>Step 1: Define a file
//	<li>Step 2: Associate the file with a group
//	<li>Step 3: Provide the file group to an endpoint
//	</ul>
//	<h4>Step 1: Define a file
//	<p>
//	Configure a new file (Task Configuration > File)
//	associated with the File Distributor task:
//	<ol>
//	<li>On the Keys > Keys tab, enter:
//	<ul>
//	<li>File = user chosen name for the file (typically
//	<i>custabbr</i> followed by the file type)
//	</ul>
//	<li>On the Detail > Definition tab, enter:
//	<ul>
//	<li>Label = the type (e.g. TXNACT) of the file
//	<li>Description = optional description of the file
//	</ul>
//	<li>On the Detail > Dataset tab, enter:
//	<ul>
//	<li>Dataset Name = the path name of the dataset in the
//	DataNavigator file system
//	</ul>
//	<li>On the Detail > Associations tab, enter:
//	<ul>
//	<li>Task = the File Distributor service (<i>ca</i>DT01)
//	</ul>
//	</ol>
//	<img src=CXOCDT04.gif>
//	<h4>Step 2: Associate the file with a group
//	<p>
//	A set of files can be grouped and then delivered to any
//	Institution, Processor or Reporting Level.
//	<ol>
//	<li>In the File Group book (File Distribution > File
//	Group), add an entry to the group.
//	File groups can be defined using up to 8 characters.
//	Some standard file groups are:
//	<ul>
//	<li>INST: Institution level
//	<li>PROC: Processor level
//	<li>RPTLVL: Reporting Level
//	<li>SWITCH: Switch Level
//	</ul>
//	<li>Click on Detail tab and enter the desired
//	description.
//	<li>On the Entries > Entry tab, enter:
//	<ul>
//	<li>User File Name = user defined 8-character name
//	<li>File Type = the type of the file (must match the
//	'Label' of the file in the File Definition)
//	<li>Scheduling Frequency defines when the report is
//	created:
//	<ul>
//	<li>C = Entity Cutoff
//	<li>M = Monthly
//	<li>D = Device Cutoff
//	<li>E = Everyday
//	</ul>
//	<li>Scheduling Offset is used in conjunction with the
//	scheduling offset time:
//	<ul>
//	<li>B = Before (specified time)
//	<li>A = After (specified time)
//	</ul>
//	<li>Scheduling Offset Time = the time that the file is
//	to be created entered in the format: hhmmss.
//	</ul>
//	</ol>
//	<img src=CXOCDT05.gif>
//	<h4>Step 3: Provide the file group to an endpoint
//	<p>
//	In the CR Client, under File Distribution, three
//	destination choices are available:
//	<p>
//	<ul>
//	<li>Processor Destination
//	<li>Institution Destination
//	<li>Reporting Level Destination
//	</ul>
//	A Processor Destination can be any PROC_ID in the
//	PROCESSOR table.
//	The file will contain transaction detail or totals
//	associated with FIN_L<i>yyyymm</i>.PROC_ID_ACQ_B or FIN_
//	L<i>yyyymm</i>.PROC_ID_ISS_B.
//	<p>
//	An Institution Destination can be any INST_ID in the
//	INSTITUTION table.
//	The file will contain transaction detail or totals
//	associated with FIN_L<i>yyyymm</i>.INST_ID_RECN_ACQ_B or
//	FIN_L<i>yyyymm</i>.INST_ID_RECN_ISS_B.
//	<p>
//	A Reporting Level Destination can be any RPT_LVL_ID in
//	the REPORTING_LVL table.
//	The file will contain transaction detail or totals
//	associated with FIN_L<i>yyyymm</i>.RPT_LVL_ID_B.
//	<p>
//	Switch level reports must be defined in Processor
//	Destination and associated with the switch level
//	processor (i.e. STS_CUSTOMER.FUNDS_PROC_ID).
//	<p>
//	For example, if the file is at the processor level,
//	select Processor Destination (File Distribution >
//	Processor Destination) in the CR Client for the Data
//	Navigator Server:
//	<p>
//	<ol>
//	<li>On the Keys > Keys tab:
//	<ul>
//	<li>Processor Destination = a user chosen name for this
//	destination
//	</ul>
//	<li>On the Keys > Associations tab:
//	<ul>
//	<li>Processor = an actual PROC_ID from the PROCESSOR
//	table
//	</ul>
//	<li>Click on the Detail tab and enter�
//	<ul>
//	<li>Description = an optional description of this file
//	<li>Routing Method = the method of delivery (ftp is the
//	only available option at this time)
//	<li>Routing User ID = the user ID for ftp
//	<li>Routing Password = the password for ftp
//	<li>Routing Data = the server name (or IP address) of
//	the destination
//	</ul>
//	<li>On the Detail > Associations tab:
//	<ul>
//	<li>File Group = the set of files to deliver to the
//	destination
//	<li>Customer = the actual CUST_ID associated with the
//	PROC_ID
//	</ul>
//	</ol>
//	<img src=CXOCDT06.gif>
//	<p>
//	Create a script to process the file after it is written.
//	</p>
//	</body>
//## Category: Data Distribution::DataDistribution_CAT (DT)%41A350EC02BF
//## Subsystem: DT%41A35178038A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%419CCE99029F;IF::Trace { -> F}
//## Uses: <unnamed>%419CCE9C037A;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%419CCEA0031C;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%419CCEAD034B;monitor::UseCase { -> F}
//## Uses: <unnamed>%419CCEB901A5;IF::Extract { -> F}
//## Uses: <unnamed>%419CCEC300AB;IF::Job { -> F}
//## Uses: <unnamed>%419CCECC005D;database::Database { -> F}
//## Uses: <unnamed>%419D01F7034B;reusable::Statement { -> F}
//## Uses: <unnamed>%41BA095B030D;IF::Console { -> F}
//## Uses: <unnamed>%41E2E146032C;timer::Timer { -> F}
//## Uses: <unnamed>%41E2E176030D;process::Application { -> F}
//## Uses: <unnamed>%41E2E3E40109;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%41E83C8B033C;reusable::Query { -> F}
//## Uses: <unnamed>%41EE83CD004E;IF::DateTime { -> F}
//## Uses: <unnamed>%47751D5703A9;entityhierarchy::Contact { -> F}
//## Uses: <unnamed>%48FE220300BB;reusable::FormatSelectVisitor { -> F}
//## Uses: <unnamed>%5C40AFBE027B;timer::Clock { -> F}
//## Uses: <unnamed>%5C40B08801E9;IF::SiteSpecification { -> F}
//## Uses: <unnamed>%5C40B0B500D9;IF::Timestamp { -> F}
//## Uses: <unnamed>%5C40B0DA0000;monitor::Interval { -> F}
//## Uses: <unnamed>%5C40E1080158;reusable::Buffer { -> F}
//## Uses: <unnamed>%5CA80A5E0251;report::TerminalActivity { -> F}
//## Uses: <unnamed>%6310BC10030A;IF::Sleep { -> F}

class DllExport FileWriter : public reusable::Observer  //## Inherits: <unnamed>%419CCADB0222
{
  //## begin FileWriter%419CCAB200DA.initialDeclarations preserve=yes
  //## end FileWriter%419CCAB200DA.initialDeclarations

  public:
    //## Constructors (generated)
      FileWriter();

    //## Destructor (generated)
      virtual ~FileWriter();


    //## Other Operations (specified)
      //## Operation: bind%6310B99300D4
      void bind (const string& strTableName, Query& hQuery);

      //## Operation: complete%41DAD3CC002E
      bool complete (int iDX_FILE_ID);

      //## Operation: redistribute%41B9F92A0148
      void redistribute (int iDX_FILE_ID);

      //## Operation: update%419CDDC8030D
      virtual void update (Subject* pSubject	// Instance of the Subject that has changed state.
      );

    // Additional Public Declarations
      //## begin FileWriter%419CCAB200DA.public preserve=yes
      //## end FileWriter%419CCAB200DA.public

  protected:
    // Additional Protected Declarations
      //## begin FileWriter%419CCAB200DA.protected preserve=yes
      //## end FileWriter%419CCAB200DA.protected

  private:

    //## Other Operations (specified)
      //## Operation: displayIssues%48B7C0F703CA
      void displayIssues ();

      //## Operation: distribute%419CCFC3034B
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>DT
      //	<h2>FI
      //	<!-- FileDistributor::distribute : Preconditions -->
      //	<h3>Script Variables
      //	<p>
      //	Script variables are updated by the File Distributor
      //	service when a script is copied from the Source folder
      //	to the Bin folder for execution.
      //	The following variables can be specified in the scripts:
      //	<ul>
      //	<li>&NODE001. - file system high level
      //	<li>&CUSTQUAL. - customer database schema name
      //	<li>&FILEID. - DX_DATA_CONTROL.DX_FILE_ID
      //	<li>&ENTITY. - DX_DATA_CONTROL.ENTITY_ID
      //	<li>&DATE. - DX_DATA_CONTROL.DATE_RECON and DX_DATA_
      //	CONTROL.SCHED_TIME as D<i>yymmdd</i>.T<i>hhmmss</i>
      //	<li>&DATA. - DX_PROC_DEST.ROUTING_DATA
      //	<li>&USER. - DX_PROC_DEST.ROUTING_USER_ID
      //	<li>&PASS. - DX_PROC_DEST.ROUTING_PASSWORD
      //	<li>&PATH. - full path name of new dataset
      //	<li>&FOLDER1. through &FOLDER<i>n</i>. - each folder
      //	from &PATH.
      //	<li>&FILE. - file name from &PATH.
      //	</ul>
      //	<h3>Script (Perl)
      //	<p>
      //	A Perl script can be used to process the exported
      //	dataset.
      //	The standard Transaction Activity file format produced
      //	by the Totals Engine service is also supported as an
      //	input to the Auto Reconciliation service.
      //	The following example sorts the Transaction Activity
      //	file by PAN and retrieval reference number and copies it
      //	for use as input to test Auto Reconciliation.
      //	<p>
      //	<img src=CXOCDT01.gif>
      //	<h3>Script (command or shell)
      //	<p>
      //	After copying a result set from the data export tables
      //	to the file system,
      //	a command or shell script can be executed by the File
      //	Distributor service.
      //	The File Distributor service will modify the NODE001 and
      //	PATH variables in the script and copy it to the Bin
      //	folder for execution.
      //	The command is executed and the stdout and stderr output
      //	is copied to the Trace folder.
      //	<p>
      //	The following shows an example Alpha\Source input file,
      //	the customized script in the Bin folder and the
      //	resulting stdout and stderr output files in the Trace
      //	folder.
      //	In this example, an audit report in the form of an email
      //	is copied to the Smtp\Inbox.
      //	This document will be picked up by the DataNavigator
      //	Mail Transfer Agent service and forwarded to your email
      //	system.
      //	<p>
      //	<img src=CXOCDT02.gif>
      //	<h3>Script (ftp)
      //	<p>
      //	If the script template contains ftp commands, the File
      //	Distributor service will modify the variables in the
      //	template and copy it to the Bin folder for input to ftp.
      //	The ExecuteFTP.cmd file is then executed with 2
      //	parameters:
      //	<ul>
      //	<li>%1 - Alpha\Bin\&<i>custabbr</i>.TXNDBA.txt
      //	<li>%2 - <i>node001</i>\Trace\<i>yyyy-mm-dd~hh_mm_
      //	ss</i>~TXNDBA~Results.txt
      //	</ul>
      //	<p>
      //	<img src=CXOCDT03.gif>
      //	</body>
      bool distribute ();

      //## Operation: format%5D0BF68B0242
      //	<body>
      //	<title>CG
      //	<h1>DT
      //	<h2>FI
      //	<!-- FileDistributor::format : General -->
      //	<h3>Script Variables
      //	<p>
      //	Script variables are updated by the File Distributor
      //	service when a script is copied from the Source folder
      //	to the Bin folder for execution.
      //	The following variables can be specified in the scripts:
      //	<ul>
      //	<li>&NODE001. - file system high level
      //	<li>&CUSTQUAL. - customer database schema name
      //	<li>&FILEID. - DX_DATA_CONTROL.DX_FILE_ID
      //	<li>&ENTITY. - DX_DATA_CONTROL.ENTITY_ID
      //	<li>&DATE. - DX_DATA_CONTROL.DATE_RECON and DX_DATA_
      //	CONTROL.SCHED_TIME as D<i>yymmdd</i>.T<i>hhmmss</i>
      //	<li>&DATA. - DX_PROC_DEST.ROUTING_DATA
      //	<li>&USER. - DX_PROC_DEST.ROUTING_USER_ID
      //	<li>&PASS. - DX_PROC_DEST.ROUTING_PASSWORD
      //	<li>&PATH. - full path name of new dataset
      //	<li>&FOLDER1. through &FOLDER<i>n</i>. - each folder
      //	from &PATH.
      //	<li>&FILE. - file name from &PATH.
      //	</ul>
      //	<h3>Script (Perl)
      //	<p>
      //	A Perl script can be used to process the exported
      //	dataset.
      //	The standard Transaction Activity file format produced
      //	by the Totals Engine service is also supported as an
      //	input to the Auto Reconciliation service.
      //	The following example sorts the Transaction Activity
      //	file by PAN and retrieval reference number and copies it
      //	for use as input to test Auto Reconciliation.
      //	<p>
      //	<img src=CXOCDT01.gif>
      //	<h3>Script (command or shell)
      //	<p>
      //	After copying a result set from the data export tables
      //	to the file system,
      //	a command or shell script can be executed by the File
      //	Distributor service.
      //	The File Distributor service will modify the NODE001 and
      //	PATH variables in the script and copy it to the Bin
      //	folder for execution.
      //	The command is executed and the stdout and stderr output
      //	is copied to the Trace folder.
      //	<p>
      //	The following shows an example Alpha\Source input file,
      //	the customized script in the Bin folder and the
      //	resulting stdout and stderr output files in the Trace
      //	folder.
      //	In this example, an audit report in the form of an email
      //	is copied to the Smtp\Inbox.
      //	This document will be picked up by the DataNavigator
      //	Mail Transfer Agent service and forwarded to your email
      //	system.
      //	<p>
      //	<img src=CXOCDT02.gif>
      //	<h3>Script (ftp)
      //	<p>
      //	If the script template contains ftp commands, the File
      //	Distributor service will modify the variables in the
      //	template and copy it to the Bin folder for input to ftp.
      //	The ExecuteFTP.cmd file is then executed with 2
      //	parameters:
      //	<ul>
      //	<li>%1 - Alpha\Bin\&<i>custabbr</i>.TXNDBA.txt
      //	<li>%2 - <i>node001</i>\Trace\<i>yyyy-mm-dd~hh_mm_
      //	ss</i>~TXNDBA~Results.txt
      //	</ul>
      //	<p>
      //	<img src=CXOCDT03.gif>
      //	<h3>IBM z/OS batch job
      //	<p>
      //	On the IBM z/OS platform, a batch job is used to copy
      //	the exported file to another location (e.g., a GDG).
      //	The job also communicates completion of this copy
      //	operation to mark the file as distribution completed (DX_
      //	DATA_CONTROL.DX_STATE = 'DC'.
      //	<p>
      //	The following variables can be referenced in the batch
      //	job:
      //	<ul>
      //	<li>&FILEID - DX_DATA_CONTROL.DX_FILE_ID
      //	<li>&ENTITY - DX_DATA_CONTROL.ENTITY_ID
      //	<li>&DATE - DX_DATA_CONTROL.DATE_RECON and DX_DATA_
      //	CONTROL.SCHED_TIME as D<i>yymmdd</i>.T<i>hhmmss</i>
      //	<li>&DATA - DX_PROC_DEST.ROUTING_DATA
      //	<li>&USER - DX_PROC_DEST.ROUTING_USER_ID
      //	<li>&PASS - DX_PROC_DEST.ROUTING_PASSWORD
      //	<li>&PATH - full path name of new dataset
      //	<li>&DATE - DX_DATA_CONTROL.DATE_RECON as D<i>yymmdd</i>
      //	<li>&TASKID - DT task name (e.g. ABDT02)
      //	<li>&DSN - export file dataset name
      //	</ul>
      //	<p>
      //	Refer to <a href="../../../IBMz
      //	OS/Export/DXEMSACT.txt"><i>node001.qualify</i>USER.CNTL(<
      //	i>ca</i>EMSACT</a> as a sample job that copies the
      //	exported EMS activity file to a GDG.
      //	The second step executes the RESET command to notify the
      //	DT task that the distribution process has completed
      //	successfully.
      //	</body>
      bool format (const string& strDX_FILE_TYPE);

      //## Operation: updateProgress%419CEA130251
      bool updateProgress (int iDX_FILE_ID, const char* pszDX_STATE);

      //## Operation: updatePath%63C7F2CB03AA
      bool updatePath (int iDX_FILE_ID);

    // Additional Private Declarations
      //## begin FileWriter%419CCAB200DA.private preserve=yes
      //## end FileWriter%419CCAB200DA.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: ALT_REC_KEY%5C4091020332
      //## begin FileWriter::ALT_REC_KEY%5C4091020332.attr preserve=no  private: string {V} 
      string m_strALT_REC_KEY;
      //## end FileWriter::ALT_REC_KEY%5C4091020332.attr

      //## Attribute: Class%5C40D81D00B8
      //## begin FileWriter::Class%5C40D81D00B8.attr preserve=no  private: multimap<string,string,less<string> > {V} 
      //multimap<string,string,less<string> > m_hClass;
      //## end FileWriter::Class%5C40D81D00B8.attr

      //## Attribute: DATA_BUFFER%419CE9FF01F4
      //## begin FileWriter::DATA_BUFFER%419CE9FF01F4.attr preserve=no  private: string[2] {V} 
      string m_strDATA_BUFFER[2];
      //## end FileWriter::DATA_BUFFER%419CE9FF01F4.attr

      //## Attribute: DATE_RECON%5D10C10200B4
      //## begin FileWriter::DATE_RECON%5D10C10200B4.attr preserve=no  private: string {V} 
      string m_strDATE_RECON;
      //## end FileWriter::DATE_RECON%5D10C10200B4.attr

      //## Attribute: DX_FILE_ID%41DABB090271
      //## begin FileWriter::DX_FILE_ID%41DABB090271.attr preserve=no  private: int[2] {V} 
      int m_iDX_FILE_ID[2];
      //## end FileWriter::DX_FILE_ID%41DABB090271.attr

      //## Attribute: DX_FILE_TYPE%419CE9E60271
      //## begin FileWriter::DX_FILE_TYPE%419CE9E60271.attr preserve=no  private: string {V} 
      string m_strDX_FILE_TYPE[2];
      //## end FileWriter::DX_FILE_TYPE%419CE9E60271.attr

      //## Attribute: DX_FILE_TYPE_InList%63EE635D02C2
      //## begin FileWriter::DX_FILE_TYPE_InList%63EE635D02C2.attr preserve=no  private: string {V} 
      string m_strDX_FILE_TYPE_InList;
      //## end FileWriter::DX_FILE_TYPE_InList%63EE635D02C2.attr

      //## Attribute: DX_PATH%63F79CBB00E2
      //## begin FileWriter::DX_PATH%63F79CBB00E2.attr preserve=no  private: string {V} 
      string m_strDX_PATH;
      //## end FileWriter::DX_PATH%63F79CBB00E2.attr

      //## Attribute: DX_REPORT_ID%5D10C29D0336
      //## begin FileWriter::DX_REPORT_ID%5D10C29D0336.attr preserve=no  private: int {V} 0
      int m_iDX_REPORT_ID;
      //## end FileWriter::DX_REPORT_ID%5D10C29D0336.attr

      //## Attribute: DX_STATE%6310B92C03DE
      //## begin FileWriter::DX_STATE%6310B92C03DE.attr preserve=no  private: string {V} 
      string m_strDX_STATE;
      //## end FileWriter::DX_STATE%6310B92C03DE.attr

      //## Attribute: ENTITY_ID%5D10C14F003E
      //## begin FileWriter::ENTITY_ID%5D10C14F003E.attr preserve=no  private: string {V} 
      string m_strENTITY_ID;
      //## end FileWriter::ENTITY_ID%5D10C14F003E.attr

      //## Attribute: ENTITY_TYPE%5D10C19003E7
      //## begin FileWriter::ENTITY_TYPE%5D10C19003E7.attr preserve=no  private: string {V} 
      string m_strENTITY_TYPE;
      //## end FileWriter::ENTITY_TYPE%5D10C19003E7.attr

      //## Attribute: EXPORT_RETRY_COUNT%41EE7BD301D4
      //## begin FileWriter::EXPORT_RETRY_COUNT%41EE7BD301D4.attr preserve=no  private: int {V} 0
      int m_iEXPORT_RETRY_COUNT;
      //## end FileWriter::EXPORT_RETRY_COUNT%41EE7BD301D4.attr

      //## Attribute: Null%5D10C36C0222
      //## begin FileWriter::Null%5D10C36C0222.attr preserve=no  private: short {V} 0
      short m_siNull;
      //## end FileWriter::Null%5D10C36C0222.attr

      //## Attribute: ORDER_BY%6310B9430377
      //## begin FileWriter::ORDER_BY%6310B9430377.attr preserve=no  private: string {V} 
      string m_strORDER_BY;
      //## end FileWriter::ORDER_BY%6310B9430377.attr

      //## Attribute: ROUTING_DATA%5D10C1B701EC
      //## begin FileWriter::ROUTING_DATA%5D10C1B701EC.attr preserve=no  private: string {V} 
      string m_strROUTING_DATA;
      //## end FileWriter::ROUTING_DATA%5D10C1B701EC.attr

      //## Attribute: ROUTING_PASSWORD%5D10C30D0059
      //## begin FileWriter::ROUTING_PASSWORD%5D10C30D0059.attr preserve=no  private: string {V} 
      string m_strROUTING_PASSWORD;
      //## end FileWriter::ROUTING_PASSWORD%5D10C30D0059.attr

      //## Attribute: ROUTING_TYPE%5D10C1E402FC
      //## begin FileWriter::ROUTING_TYPE%5D10C1E402FC.attr preserve=no  private: string {V} 
      string m_strROUTING_TYPE;
      //## end FileWriter::ROUTING_TYPE%5D10C1E402FC.attr

      //## Attribute: ROUTING_USER_ID%5D10C228022E
      //## begin FileWriter::ROUTING_USER_ID%5D10C228022E.attr preserve=no  private: string {V} 
      string m_strROUTING_USER_ID;
      //## end FileWriter::ROUTING_USER_ID%5D10C228022E.attr

      //## Attribute: SCHED_TIME%5D10C254011A
      //## begin FileWriter::SCHED_TIME%5D10C254011A.attr preserve=no  private: string {V} 
      string m_strSCHED_TIME;
      //## end FileWriter::SCHED_TIME%5D10C254011A.attr

      //## Attribute: TASK_FORMATTED%6310B94302B7
      //## begin FileWriter::TASK_FORMATTED%6310B94302B7.attr preserve=no  private: string {V} 
      string m_strTASK_FORMATTED;
      //## end FileWriter::TASK_FORMATTED%6310B94302B7.attr

      //## Attribute: TSTAMP_FORMATTED%5D96116602E4
      //## begin FileWriter::TSTAMP_FORMATTED%5D96116602E4.attr preserve=no  private: string {V} 
      string m_strTSTAMP_FORMATTED;
      //## end FileWriter::TSTAMP_FORMATTED%5D96116602E4.attr

    // Data Members for Associations

      //## Association: Data Distribution::DataDistribution_CAT (DT)::<unnamed>%46B9CE6501F4
      //## Role: FileWriter::<m_pExportFile>%46B9CE6600AB
      //## begin FileWriter::<m_pExportFile>%46B9CE6600AB.role preserve=no  public: database::ExportFile { -> RFHgN}
      database::ExportFile *m_pExportFile;
      //## end FileWriter::<m_pExportFile>%46B9CE6600AB.role

      //## Association: Data Distribution::DataDistribution_CAT (DT)::<unnamed>%477921CE01C5
      //## Role: FileWriter::<m_hDistributionFileFactory>%477921CF0232
      //## begin FileWriter::<m_hDistributionFileFactory>%477921CF0232.role preserve=no  public: DistributionFileFactory { -> VHgN}
      DistributionFileFactory m_hDistributionFileFactory;
      //## end FileWriter::<m_hDistributionFileFactory>%477921CF0232.role

      //## Association: Data Distribution::DataDistribution_CAT (DT)::<unnamed>%4FEC8065004C
      //## Role: FileWriter::<m_pFlatFile>%4FEC8065038A
      //## begin FileWriter::<m_pFlatFile>%4FEC8065038A.role preserve=no  public: IF::FlatFile { -> RFHgN}
      IF::FlatFile *m_pFlatFile;
      //## end FileWriter::<m_pFlatFile>%4FEC8065038A.role

      //## Association: Connex Library::Command_CAT::<unnamed>%419CCDAE031C
      //## Role: FileWriter::<m_pMemory>%419CCDAF0271
      //## begin FileWriter::<m_pMemory>%419CCDAF0271.role preserve=no  public: IF::Memory { -> RFHgN}
      IF::Memory *m_pMemory;
      //## end FileWriter::<m_pMemory>%419CCDAF0271.role

    // Additional Implementation Declarations
      //## begin FileWriter%419CCAB200DA.implementation preserve=yes
      #define STS_DUPLICATE_RECORD 35
      string m_strTASKID;
      //## end FileWriter%419CCAB200DA.implementation
};

//## begin FileWriter%419CCAB200DA.postscript preserve=yes
//## end FileWriter%419CCAB200DA.postscript

//## begin module%419CCB6402CE.epilog preserve=yes
//## end module%419CCB6402CE.epilog


#endif
