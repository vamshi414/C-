//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%47791DB700FA.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%47791DB700FA.cm

//## begin module%47791DB700FA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%47791DB700FA.cp

//## Module: CXOSDT02%47791DB700FA; Package body
//## Subsystem: DT%41A35178038A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Dt\CXOSDT02.cpp

//## begin module%47791DB700FA.additionalIncludes preserve=no
//## end module%47791DB700FA.additionalIncludes

//## begin module%47791DB700FA.includes preserve=yes
//## end module%47791DB700FA.includes

#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSTC30_h
#include "CXODTC30.hpp"
#endif
#ifndef CXOSPF04_h
#include "CXODPF04.hpp"
#endif
#ifndef CXOSTC54_h
#include "CXODTC54.hpp"
#endif
#ifndef CXOSTC67_h
#include "CXODTC67.hpp"
#endif
#ifndef CXOSTC68_h
#include "CXODTC68.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSPF28_h
#include "CXODPF28.hpp"
#endif
#ifndef CXOSPF05_h
#include "CXODPF05.hpp"
#endif
#ifndef CXOSPF33_h
#include "CXODPF33.hpp"
#endif
#ifndef CXOSMG58_h
#include "CXODMG58.hpp"
#endif
#ifndef CXOSEF07_h
#include "CXODEF07.hpp"
#endif
#ifndef CXOSRF23_h
#include "CXODRF23.hpp"
#endif
#ifndef CXOSTC80_h
#include "CXODTC80.hpp"
#endif
#ifndef CXOSDT02_h
#include "CXODDT02.hpp"
#endif


//## begin module%47791DB700FA.declarations preserve=no
//## end module%47791DB700FA.declarations

//## begin module%47791DB700FA.additionalDeclarations preserve=yes
//## end module%47791DB700FA.additionalDeclarations


// Class DistributionFileFactory 

DistributionFileFactory::DistributionFileFactory()
  //## begin DistributionFileFactory::DistributionFileFactory%47791CC901B5_const.hasinit preserve=no
  //## end DistributionFileFactory::DistributionFileFactory%47791CC901B5_const.hasinit
  //## begin DistributionFileFactory::DistributionFileFactory%47791CC901B5_const.initialization preserve=yes
  //## end DistributionFileFactory::DistributionFileFactory%47791CC901B5_const.initialization
{
  //## begin DistributionFileFactory::DistributionFileFactory%47791CC901B5_const.body preserve=yes
   memcpy(m_sID,"DT02",4);
#define CLASSES 32
   const char* pszClass[CLASSES] =
   {
      "FINSA0",
      "FINXII",
      "FINXIP",
      "FINXPP",
      "FINFA0",
      "FINFA1",
      "FINFA2",
      "FINFA3",
      "FINFA4",
      "FINFA5",
      "FINFA6",
      "FINFA7",
      "FINFA8",
      "FINFA9",
      "FINFD0",
      "FINFD1",
      "FINFD2",
      "FINFD3",
      "FINFD4",
      "FINFD5",
      "FINFD6",
      "FINFD7",
      "FINFD8",
      "FINFD9",
      "ECOUT",
      "ECHIST",
      "TXNACT",
      "FINMBL",
      "EMSMBL",
      "EMSACT",
      "TRMBAL",
      "PSTEHB"
   };
   string strClass;
   for (int m = 0;m < CLASSES;++m)
   {
      strClass = pszClass[m];
      m_hClasses.insert(map<string,int,less<string> >::value_type(strClass,m));
   }
  //## end DistributionFileFactory::DistributionFileFactory%47791CC901B5_const.body
}


DistributionFileFactory::~DistributionFileFactory()
{
  //## begin DistributionFileFactory::~DistributionFileFactory%47791CC901B5_dest.body preserve=yes
  //## end DistributionFileFactory::~DistributionFileFactory%47791CC901B5_dest.body
}



//## Other Operations (implementation)
database::ExportFile* DistributionFileFactory::create (const ExportFile& hExportFile)
{
  //## begin DistributionFileFactory::create%47791D5E03D8.body preserve=yes
   string strDX_FILE_TYPE(hExportFile.getDX_FILE_TYPE());
   map<string,int,less<string> >::iterator pClass = m_hClasses.find(strDX_FILE_TYPE);
   ExportFile* pExportFile = 0;
   if (pClass == m_hClasses.end())
   {
      pExportFile = new database::ExportFile();
      return pExportFile;
   }
   switch ((*pClass).second)
   {
      case 0:
         if (entitysegment::Customer::instance()->getTotalsVersion() == 1)
            pExportFile = new totalscommand::FinancialSettlementFile1();
         else
            pExportFile = new totalscommand::FinancialSettlementFile2();
         break;
      case 1:
      case 2:
      case 3:
         pExportFile = new totalscommand::ActivityByInterchangeFile();
         break;
      case 4:
      case 5:
      case 6:
      case 7:
      case 8:
      case 9:
      case 10:
      case 11:
      case 12:
      case 13:
      case 14:
      case 15:
      case 16:
      case 17:
      case 18:
      case 19:
      case 20:
      case 21:
      case 22:
      case 23:
         pExportFile = new totalscommand::ACHFile();
         break;
      case 24:
         pExportFile = new postingfile::CaseReplicationExport();
         break;
      case 25:
         pExportFile = new postingfile::CaseHistoryExport();
         break;
      case 26:
         pExportFile = new postingfile::TransactionActivityFile();
         break;
      case 27:
      case 28:
         pExportFile = new managementinformation::FinancialBillingFile1();
         break;
      case 29:
         pExportFile = new postingfile::CaseReportFile();
         break;
      case 30:
         pExportFile = new totalscommand::TerminalCashBalance();
         break;
      case 31:
         pExportFile = new reconciliationfile::PayPalPostingFile();
         break;
      default:
         pExportFile = new database::ExportFile();
         break;
   }
   return pExportFile;
  //## end DistributionFileFactory::create%47791D5E03D8.body
}

void DistributionFileFactory::update (Subject* pSubject)
{
  //## begin DistributionFileFactory::update%48060ECC00C9.body preserve=yes
   // avoid FileFactory::update()
  //## end DistributionFileFactory::update%48060ECC00C9.body
}

// Additional Declarations
  //## begin DistributionFileFactory%47791CC901B5.declarations preserve=yes
  //## end DistributionFileFactory%47791CC901B5.declarations

//## begin module%47791DB700FA.epilog preserve=yes
//## end module%47791DB700FA.epilog
