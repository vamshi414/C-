//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41B487FE005D.cm preserve=no
//## end module%41B487FE005D.cm

//## begin module%41B487FE005D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%41B487FE005D.cp

//## Module: CXOPDT00%41B487FE005D; Package body
//## Subsystem: DT%41A35178038A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Dt\CXOPDT00.cpp

//## begin module%41B487FE005D.additionalIncludes preserve=no
//## end module%41B487FE005D.additionalIncludes

//## begin module%41B487FE005D.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#ifndef CXOSST88_h
#include "CXODST88.hpp"
#endif
//## end module%41B487FE005D.includes

#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDZ03_h
#include "CXODDZ03.hpp"
#endif
#ifndef CXOSDZ04_h
#include "CXODDZ04.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSIF37_h
#include "CXODIF37.hpp"
#endif
#ifndef CXOSDB16_h
#include "CXODDB16.hpp"
#endif
#ifndef CXOSTC66_h
#include "CXODTC66.hpp"
#endif
#ifndef CXOSNS44_h
#include "CXODNS44.hpp"
#endif
#ifndef CXOSPF38_h
#include "CXODPF38.hpp"
#endif
#ifndef CXOSTC32_h
#include "CXODTC32.hpp"
#endif
#ifndef CXOSDT01_h
#include "CXODDT01.hpp"
#endif
#ifndef CXOPDT00_h
#include "CXODDT00.hpp"
#endif


//## begin module%41B487FE005D.declarations preserve=no
//## end module%41B487FE005D.declarations

//## begin module%41B487FE005D.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new FileDistributor();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%41B487FE005D.additionalDeclarations


// Class FileDistributor 

FileDistributor::FileDistributor()
  //## begin FileDistributor::FileDistributor%41B485F400FA_const.hasinit preserve=no
      : m_pFileWriter(0)
  //## end FileDistributor::FileDistributor%41B485F400FA_const.hasinit
  //## begin FileDistributor::FileDistributor%41B485F400FA_const.initialization preserve=yes
  //## end FileDistributor::FileDistributor%41B485F400FA_const.initialization
{
  //## begin FileDistributor::FileDistributor%41B485F400FA_const.body preserve=yes
   memcpy(m_sID,"DT00",4);
  //## end FileDistributor::FileDistributor%41B485F400FA_const.body
}


FileDistributor::~FileDistributor()
{
  //## begin FileDistributor::~FileDistributor%41B485F400FA_dest.body preserve=yes
   delete m_pFileWriter;
  //## end FileDistributor::~FileDistributor%41B485F400FA_dest.body
}



//## Other Operations (implementation)
int FileDistributor::initialize ()
{
  //## begin FileDistributor::initialize%41B4939A0399.body preserve=yes
   new dnplatform::DNPlatform();
   int i = Application::initialize();
   UseCase hUseCase("DIST","## DT00 START DT");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
#ifndef MVS
   string strTaskName(Application::instance()->name());
   if (strTaskName.substr(2,4) > "DT01")
   {
      strTaskName.replace(4,2,"01",2);
      Extract::instance()->read("EDB     ",strTaskName.c_str());
   }
#endif
   platform::Platform::instance()->createDatabaseFactory();
   m_pFileWriter = new FileWriter;
   Database::instance()->attach(this);
   entitysegment::Customer::instance();
   entitysegment::Processor::instance();
   entitysegment::SwitchBusinessDay::instance();
   CRTransactionTypeIndicator::instance();
   postingfile::Reports::instance();
   totalscommand::DirectRoute::instance();
   Database::instance()->connect();
   TotalsVersionMonitor::instance();
   string strCustomer;
   IF::Extract::instance()->getSpec("CUSTOMER",strCustomer);
   Transaction::instance()->setCustomer(strCustomer);
   Transaction::instance()->begin();
   Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   new ExceptionFactory();
   new dnplatform::NetworkFactory();
   EMSRulesEngine::instance();
   MidnightAlarm::instance()->attach(this);
   if (entitysegment::Customer::instance()->getTotalsVersion() == 2)
      new totalscommand::FinancialSum;
   return 0;
  //## end FileDistributor::initialize%41B4939A0399.body
}

int FileDistributor::onMessage (Message& hMessage)
{
  //## begin FileDistributor::onMessage%4C7EA5E402AD.body preserve=yes
   if (hMessage.messageID() == "H5050D")
   {
      Trace::put("H5050D received from console");
      string strData(hMessage.data(),hMessage.dataLength());
      Trace::put(strData.data(),strData.length());
      vector<string> hTokens;
      Buffer::parse(strData,".",hTokens);
      if (hTokens.size() == 2)
      {
         int iDX_FILE_ID = atoi(hTokens[1].c_str());
         if (hTokens[0] == "RESEND")
            m_pFileWriter->redistribute(iDX_FILE_ID);
         else
         if (hTokens[0] == "COMPLETE")
            m_pFileWriter->complete(iDX_FILE_ID);
      }
      IF::ResultSet hResultSet;
      hResultSet.close();
   }
   return 0;
  //## end FileDistributor::onMessage%4C7EA5E402AD.body
}

int FileDistributor::onReset (Message& hMessage)
{
  //## begin FileDistributor::onReset%41B4939A03C8.body preserve=yes
   if (hMessage.context().length() >= 8
      && memcmp((char*)hMessage.context(),"RESEND-",7) == 0)
   {
      int iDX_FILE_ID = atoi((char*)hMessage.context().subString(8));
      m_pFileWriter->redistribute(iDX_FILE_ID);
   }
   else
   if (hMessage.context().length() >= 10
      && memcmp((char*)hMessage.context(),"COMPLETE-",9) == 0)
   {
      int iDX_FILE_ID = atoi((char*)hMessage.context().subString(10));
      m_pFileWriter->complete(iDX_FILE_ID);
   }
   else
   if (hMessage.context().indexOf("HOLD-"))
   {
   }
   else
   if (hMessage.context().indexOf("RELEASE-"))
   {
   }
   return 0;
  //## end FileDistributor::onReset%41B4939A03C8.body
}

void FileDistributor::update (Subject* pSubject)
{
  //## begin FileDistributor::update%43B59646035B.body preserve=yes
   if ((pSubject == Database::instance()
      || pSubject == MidnightAlarm::instance())
      && Database::instance()->state() == Database::CONNECTED)
   {
      UseCase hUseCase("DIST","## DT00 SCHEDULE MIS FILE");
      ExportFile hExportFile;
      hExportFile.setDX_STATE("FW");
      int i = 0;
      string strRecord;
      while (IF::Extract::instance()->getRecord(i++,strRecord))
      {
         if (strRecord.size() >= 16
            && strRecord.substr(0,10) == "DFILES  MI")
         {
            Customer::instance()->getFUNDS_PROC_ID().empty() ? hExportFile.setENTITY_ID("PRC999") : hExportFile.setENTITY_ID(Customer::instance()->getFUNDS_PROC_ID());
            hExportFile.setDX_FILE_TYPE(strRecord.substr(8,8));
            if (strRecord.substr(10,1) == "U" || strRecord.substr(12,2) == "  ")
               hExportFile.setENTITY_TYPE("AS");
            else
               hExportFile.setENTITY_TYPE(strRecord.substr(12,2));
            Date hDate(Date::today());
            if (strRecord.substr(11,1) == "M"
               || strRecord.substr(11,1) == "Y")
            {
               // schedule monthly/yearly report
               hExportFile.setDATE_RECON(hDate.asString("%Y%m00"));
               hDate.incrementMonth(1);
               string strDateInitiated(hDate.asString("%Y%m0806000000"));
               string strSchedule;
               if (Extract::instance()->getSpec("MIMSCHED",strSchedule))
                  strDateInitiated.replace(6,2,strSchedule);
               hExportFile.setTSTAMP_INITIATED(strDateInitiated);
            }
            else
            {
               // schedule daily report
               hExportFile.setDATE_RECON(hDate.asString("%Y%m%d"));
               hDate += 1;
               hExportFile.setTSTAMP_INITIATED(hDate.asString("%Y%m%d06000000"));
            }
            hExportFile.trigger();
            UseCase::addItem();
         }
      }
      Database::instance()->commit();
   }
   Application::update(pSubject);
  //## end FileDistributor::update%43B59646035B.body
}

// Additional Declarations
  //## begin FileDistributor%41B485F400FA.declarations preserve=yes
  //## end FileDistributor%41B485F400FA.declarations

//## begin module%41B487FE005D.epilog preserve=yes
//## end module%41B487FE005D.epilog
