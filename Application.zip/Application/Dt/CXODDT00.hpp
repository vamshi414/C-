//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41B487FC0280.cm preserve=no
//## end module%41B487FC0280.cm

//## begin module%41B487FC0280.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%41B487FC0280.cp

//## Module: CXOPDT00%41B487FC0280; Package specification
//## Subsystem: DT%41A35178038A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Dt\CXODDT00.hpp

#ifndef CXOPDT00_h
#define CXOPDT00_h 1

//## begin module%41B487FC0280.additionalIncludes preserve=no
//## end module%41B487FC0280.additionalIncludes

//## begin module%41B487FC0280.includes preserve=yes
// $Date:   May 10 2019 07:40:12  $ $Author:   e1009839  $ $Revision:   1.15  $
//## end module%41B487FC0280.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Totals Management::TotalsCommand_CAT%3884FA670353
namespace totalscommand {
class DirectRoute;
class FinancialSum;
} // namespace totalscommand

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSRulesEngine;
} // namespace ems

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Processor;
class SwitchBusinessDay;
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
class NetworkFactory;
class ExceptionFactory;
} // namespace dnplatform

namespace reusable {
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace IF {
class Extract;
class ResultSet;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
class MidnightAlarm;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseFactory;
class ExportFile;
class CRTransactionTypeIndicator;
} // namespace database

class FileWriter;
//## Modelname: Data Distribution::PostingFile_CAT%41E951230177
namespace postingfile {
class Reports;

} // namespace postingfile

//## begin module%41B487FC0280.declarations preserve=no
//## end module%41B487FC0280.declarations

//## begin module%41B487FC0280.additionalDeclarations preserve=yes
//## end module%41B487FC0280.additionalDeclarations


//## begin FileDistributor%41B485F400FA.preface preserve=yes
//## end FileDistributor%41B485F400FA.preface

//## Class: FileDistributor%41B485F400FA
//	<body>
//	<title>CG
//	<h1>DT
//	<h2>AB
//	<!-- FileDistributor : General-->
//	<p>
//	The DataNavigator server provides export files to:
//	<ul>
//	<li>your backoffice systems
//	<li>card associations
//	<li>regional networks
//	<li>processors
//	<li>financial institutions
//	<li>merchants
//	</ul>
//	<h3>System Flow
//	<p>
//	DataNavigator services (e.g. File Formatter, Totals
//	Engine, Exception Manager and Exception Interface)
//	generate result sets in the Data Distribution tables (DX_
//	DATA_CONTROL and DX_DATA_<i>yyyymmdd</i>).
//	The File Distributor service (<i>ca</i>DT01):
//	<ul>
//	<li>retrieves the result set from the data distribution
//	table
//	<li>optionally converts results sets into formatted
//	reports
//	<li>writes the data to a new dataset in the file system
//	<li>retrieves the corresponding script template from the
//	Alpha\Source folder
//	<li>customizes the script and saves it in the Alpha\Bin
//	folder
//	<li>executes the script
//	</ul>
//	<p>
//	The script (e.g. shell, ftp or Perl program) can be used
//	to provide the dataset to another application or to a
//	system outside of DataNavigator.
//	</p>
//	<img src=CXOCDT00.gif>
//	</p>
//	<h2>FO
//	<!-- FileDistributor : General -->
//	<h3>Formatted Reports
//	<p>
//	The following reports are available:
//	<ul>
//	<li><a href="Acquirer Interchange Report.html">Acquirer
//	Interchange Report</a>
//	<li><a href="Cardholder Activity Report.html">Cardholder
//	Activity Report</a>
//	<li><a href="Issuer Interchange Report.html">Issuer
//	Interchange Report</a>
//	<li><a href="Terminal Activity Report.html">Terminal
//	Activity Report</a>
//	</ul>
//	<h3>Export Files
//	<p>
//	The File Distributor service produces the following
//	files:
//	<p>
//	<table>
//	<tr>
//	<th>DX_FILE_TYPE
//	<th>Description
//	<th>Format
//	<th>Size
//	<th>Type
//	<tr>
//	<td>ATMBAL
//	<td>ATM Balancing Summary
//	<td>Fixed
//	<td>
//	<tr>
//	<td>ATMDEP
//	<td>ATM Deposit Activity
//	<td>Fixed
//	<td>
//	<tr>
//	<td>AAXACT
//	<td>Acquirer Adjustments Interchange Report
//	<td>Fixed
//	<td>132
//	<tr>
//	<td>ATXACT
//	<td>Acquirer Interchange Report
//	<td>Fixed
//	<td>132
//	<tr>
//	<td>AUDRM3
//	<td>Visa Resolve Online Processing Report Download Audit
//	<td>Fixed
//	<td>
//	<tr>
//	<td>AUDRM5
//	<td>Visa Resolve Online Bulk Questionnaire and Image
//	Download Audit
//	<td>Fixed
//	<td>
//	<tr>
//	<td>BALAMX
//	<td>Card Association Balancing Worksheet (American
//	Express)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>BALDBT
//	<td>Card Association Balancing Worksheet (Debit)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>BALDIS
//	<td>Card Association Balancing Worksheet (Discover)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>BALMCI
//	<td>Card Association Balancing Worksheet (MasterCard)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>BALVNT
//	<td>Card Association Balancing Worksheet (VISA)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>BAMSA1
//	<td>Bank of America Exception Export Audit Report
//	<td>Fixed
//	<td>
//	<tr>
//	<td>BAMSRP
//	<td>Bank of America Exception Export
//	<td>Fixed
//	<td>
//	<tr>
//	<td>BULK
//	<td>EMS Document Bulk Print
//	<td>Fixed
//	<td>550
//	<tr>
//	<td>CRDACT
//	<td>Cardholder Activity Report
//	<td>Fixed
//	<td>132
//	<tr>
//	<td>ECIN
//	<td>EFD EMS Case Import Audit Report
//	<td>Fixed
//	<td>
//	<tr>
//	<td>ECOUT
//	<td>EFD EMS Case Export
//	<td>Fixed
//	<td>
//	<tr>
//	<td>ECPOST
//	<td>Exception Item Accounting
//	<td>Fixed
//	<td>
//	<tr>
//	<td>EMCEE
//	<td>Merchant eCommerce Accounting Export
//	<td>Fixed
//	<td>
//	<tr>
//	<td>EMCER
//	<td>Merchant Retail Accounting Export
//	<td>Fixed
//	<td>
//	<tr>
//	<td>EMSACT
//	<td>Case Transaction Activity
//	<td>Fixed
//	<td>
//	<tr>
//	<td>EPEPUL
//	<td>Pulse Exception Export
//	<td>Fixed
//	<td>450
//	<tr>
//	<td>FINDEI
//	<td>Financial Business Day Detail (Institution)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINDEM
//	<td>Financial Business Day Detail (Merchant)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINDEP
//	<td>Financial Business Day Detail (Processor)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINDET
//	<td>Financial Business Day Detail (Terminal)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINFA0
//	<td>Financial Settlement (Funds Movement)
//	<td>Fixed
//	<td>94
//	<tr>
//	<td>FINLA0
//	<td>Financial Settlement (Funds Movement Cover Letter)
//	<td>Fixed
//	<td>94
//	<tr>
//	<td>FINMCP
//	<td>Financial Business Day Summary (Processors)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINMIM
//	<td>Financial Business Day Summary (Merchants by
//	Institution)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINMIT
//	<td>Financial Business Day Summary (Terminals by
//	Institution)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINMMT
//	<td>Financial Business Day Summary (Terminals by
//	Merchant)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINMPI
//	<td>Financial Business Day Summary (Institutions by
//	Processor)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINSA0
//	<td>Financial Settlement
//	<td>Fixed
//	<td>175
//	<td>CSV (Comma delimited)
//	<tr>
//	<td>FINSD0
//	<td>Financial Settlement (Delta)
//	<td>Fixed
//	<td>175
//	<td>CSV (Comma delimited)
//	<tr>
//	<td>FINXII
//	<td>Totals by Interchange (Institution vs. Institution)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINXIG
//	<td>Totals by Interchange (Institution vs. Network)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINXIP
//	<td>Totals by Interchange (Institution vs. Processor)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINXMI
//	<td>Totals by Interchange (Merchant vs. Institution)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINXMG
//	<td>Totals by Interchange (Merchant vs. Network)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINXMP
//	<td>Totals by Interchange (Merchant vs. Processor)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINXPG
//	<td>Totals by Interchange (Processor vs. Network)
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FINXPP
//	<td>Totals by Interchange (Processor vs. Processor)
//	<tr>
//	<td>FRDIN
//	<td>Mastercard SAFE Import Audit
//	<td>Fixed
//	<td>
//	<tr>
//	<td>FRDOUT
//	<td>Mastercard SAFE
//	<td>Fixed
//	<td>
//	<tr>
//	<td>IAXACT
//	<td>Issuer Adjustments Interchange Report
//	<td>Fixed
//	<td>132
//	<tr>
//	<td>INTAMX
//	<td>Interchange Comparison Worksheet (American Express)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>INTDIS
//	<td>Interchange Comparison Worksheet (Discover)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>INTMCI
//	<td>Interchange Comparison Worksheet (MasterCard)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>INTVNT
//	<td>Interchange Comparison Worksheet (VISA)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>IPAAMX
//	<td>Interchange Profitability Worksheet (American
//	Express)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>IPADIS
//	<td>Interchange Profitability Worksheet (Discover)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>IPAMCI
//	<td>Interchange Profitability Worksheet (MasterCard)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>IPAVNT
//	<td>Interchange Profitability Worksheet (VISA)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>ITXACT
//	<td>Issuer Interchange Report
//	<td>Fixed
//	<td>132
//	<tr>
//	<td>MERALL
//	<td>Merchant Reconciliation Worksheet
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>MERDBT
//	<td>Merchant Reconciliation Worksheet (Debit)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>MERDIS
//	<td>Merchant Reconciliation Worksheet (Discover)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>MERMCI
//	<td>Merchant Reconciliation Worksheet (MasterCard)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>MERVNT
//	<td>Merchant Reconciliation Worksheet (VISA)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>MIS***
//	<td>MIS Totals
//	<td>Fixed
//	<td>260
//	<tr>
//	<td>PULIN
//	<td>Pulse Exception Import Audit
//	<td>Fixed
//	<td>200
//	<tr>
//	<td>RCNAMX
//	<td>Card Association Reconciliation Worksheet (American
//	Express)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>RCNDBT
//	<td>Card Association Reconciliation Worksheet (Debit)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>RCNDIS
//	<td>Card Association Reconciliation Worksheet (Discover)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>RCNMCI
//	<td>Card Association Reconciliation Worksheet (Master
//	Card)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>RCNVNT
//	<td>Card Association Reconciliation Worksheet (VISA)
//	<td>Fixed
//	<td>80
//	<td>SYLK (Symbolic Link)
//	<tr>
//	<td>TRMACT
//	<td>Terminal Activity Report
//	<td>Fixed
//	<td>132
//	<tr>
//	<td>TXNACT
//	<td>Transaction Activity File
//	<td>Fixed
//	<td>2344
//	<td>CSV (Comma delimited)
//	<tr>
//	<td>TXNARE
//	<td>Transaction Activity (Auto Reconciliation Exceptions)
//	<td>Fixed
//	<td>2344
//	<td>CSV (Comma delimited)
//	<tr>
//	<td>TXNDBA
//	<td>Monthly Debit Transaction File
//	<td>Fixed
//	<td>
//	<tr>
//	<td>TXNSUS
//	<td>Suspect Transaction File
//	<td>Fixed
//	<td>
//	<tr>
//	<td>VRBUA5
//	<td>VROL BQI Upload Request Descriptor
//	<td>Fixed
//	<td>
//	<tr>
//	<td>VRRUA5
//	<td>VROL Bulk SI Upload Request
//	<td>Fixed
//	<td>
//	</table>
//	</body>
//	<body>
//	<title>OG
//	<h1>DT
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server provides export files to
//	external systems and endpoints.
//	</p>
//	<img src=CXOODT00.gif>
//	</p>
//	</body>
//## Category: Data Distribution::DataDistribution_CAT (DT)%41A350EC02BF
//## Subsystem: DT%41A35178038A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%41B4930B00FA;database::Database { -> F}
//## Uses: <unnamed>%41B4930D0261;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%41B4931000DA;IF::Message { -> F}
//## Uses: <unnamed>%41B494D401B5;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%43B596260167;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%43B596330222;database::ExportFile { -> F}
//## Uses: <unnamed>%43B596670213;IF::Extract { -> F}
//## Uses: <unnamed>%43B59CE403B9;timer::Date { -> F}
//## Uses: <unnamed>%44E5BAF30280;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%44EEF27200EA;monitor::UseCase { -> F}
//## Uses: <unnamed>%4B2F768C01F4;dnplatform::ExceptionFactory { -> F}
//## Uses: <unnamed>%4B2F7690030D;dnplatform::NetworkFactory { -> F}
//## Uses: <unnamed>%4C7EB72001E9;reusable::Buffer { -> F}
//## Uses: <unnamed>%4C93E7E702C2;IF::Trace { -> F}
//## Uses: <unnamed>%4CAA199B005D;reusable::Transaction { -> F}
//## Uses: <unnamed>%4CAA19E503A1;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%4CAA19FC00A5;timer::Clock { -> F}
//## Uses: <unnamed>%51D3FE840024;entitysegment::Customer { -> F}
//## Uses: <unnamed>%5C1A472303E1;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%5C1A474E0012;IF::ResultSet { -> F}
//## Uses: <unnamed>%5C813F640289;database::CRTransactionTypeIndicator { -> F}
//## Uses: <unnamed>%5CD483D00092;totalscommand::FinancialSum { -> F}
//## Uses: <unnamed>%6310C0BB0014;entitysegment::Processor { -> F}
//## Uses: <unnamed>%6310C0E802B4;postingfile::Reports { -> F}
//## Uses: <unnamed>%6310C1650154;totalscommand::DirectRoute { -> F}

class DllExport FileDistributor : public process::Application  //## Inherits: <unnamed>%41B486040109
{
  //## begin FileDistributor%41B485F400FA.initialDeclarations preserve=yes
  //## end FileDistributor%41B485F400FA.initialDeclarations

  public:
    //## Constructors (generated)
      FileDistributor();

    //## Destructor (generated)
      virtual ~FileDistributor();


    //## Other Operations (specified)
      //## Operation: initialize%41B4939A0399
      virtual int initialize ();

      //## Operation: update%43B59646035B
      //	Interprets the inbound Message and calls:
      //
      //	   Application::onConfirm
      //	   Application::onMessage
      //	   Application::onNotify
      //	   Application::onQuiesce
      //	   Application::onRefresh
      //	   Application::onReset
      //	   Application::shutdown
      //	   Timer::elapsed
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin FileDistributor%41B485F400FA.public preserve=yes
      //## end FileDistributor%41B485F400FA.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%4C7EA5E402AD
      virtual int onMessage (Message& hMessage);

      //## Operation: onReset%41B4939A03C8
      virtual int onReset (Message& hMessage);

    // Additional Protected Declarations
      //## begin FileDistributor%41B485F400FA.protected preserve=yes
      //## end FileDistributor%41B485F400FA.protected

  private:
    // Additional Private Declarations
      //## begin FileDistributor%41B485F400FA.private preserve=yes
      //## end FileDistributor%41B485F400FA.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Data Distribution::DataDistribution_CAT (DT)::<unnamed>%41B9C19403C8
      //## Role: FileDistributor::<m_pFileWriter>%41B9C19502EE
      //## begin FileDistributor::<m_pFileWriter>%41B9C19502EE.role preserve=no  public: FileWriter { -> RFHgN}
      FileWriter *m_pFileWriter;
      //## end FileDistributor::<m_pFileWriter>%41B9C19502EE.role

    // Additional Implementation Declarations
      //## begin FileDistributor%41B485F400FA.implementation preserve=yes
      //## end FileDistributor%41B485F400FA.implementation

};

//## begin FileDistributor%41B485F400FA.postscript preserve=yes
//## end FileDistributor%41B485F400FA.postscript

//## begin module%41B487FC0280.epilog preserve=yes
//## end module%41B487FC0280.epilog


#endif
