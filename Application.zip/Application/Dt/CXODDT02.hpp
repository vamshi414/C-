//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%47791DB5038A.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%47791DB5038A.cm

//## begin module%47791DB5038A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%47791DB5038A.cp

//## Module: CXOSDT02%47791DB5038A; Package specification
//## Subsystem: DT%41A35178038A
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Dt\CXODDT02.hpp

#ifndef CXOSDT02_h
#define CXOSDT02_h 1

//## begin module%47791DB5038A.additionalIncludes preserve=no
//## end module%47791DB5038A.additionalIncludes

//## begin module%47791DB5038A.includes preserve=yes
//## end module%47791DB5038A.includes

#ifndef CXOSDB26_h
#include "CXODDB26.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::ExceptionFile_CAT%516E8CC70289
namespace exceptionfile {
class ExceptionBillingFile;
} // namespace exceptionfile

//## Modelname: Totals Management::TotalsCommand_CAT%3884FA670353
namespace totalscommand {
class ActivityByInterchangeFile;
class TerminalCashBalance;
class FinancialSettlementFile2;
class FinancialSettlementFile1;
class ACHFile;
} // namespace totalscommand

//## Modelname: Totals Management::ManagementInformation_CAT%440DDD48031C
namespace managementinformation {
class FinancialBillingFile;
} // namespace managementinformation

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class ExportFile;
} // namespace database

//## Modelname: Data Distribution::PostingFile_CAT%41E951230177
namespace postingfile {
class TransactionActivityFile;
class CaseReplicationExport;
class CaseReportFile;
class CaseHistoryExport;
} // namespace postingfile

//## Modelname: Reconciliation::ReconciliationFile_CAT%439754C1037A
namespace reconciliationfile {
class PayPalPostingFile;

} // namespace reconciliationfile

//## begin module%47791DB5038A.declarations preserve=no
//## end module%47791DB5038A.declarations

//## begin module%47791DB5038A.additionalDeclarations preserve=yes
//## end module%47791DB5038A.additionalDeclarations


//## begin DistributionFileFactory%47791CC901B5.preface preserve=yes
//## end DistributionFileFactory%47791CC901B5.preface

//## Class: DistributionFileFactory%47791CC901B5
//## Category: Data Distribution::DataDistribution_CAT (DT)%41A350EC02BF
//## Subsystem: DT%41A35178038A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%47791D150213;database::ExportFile { -> F}
//## Uses: <unnamed>%47792C5502AF;totalscommand::ActivityByInterchangeFile { -> F}
//## Uses: <unnamed>%4B153DC0038A;postingfile::CaseReplicationExport { -> F}
//## Uses: <unnamed>%4EFC731E0393;totalscommand::ACHFile { -> F}
//## Uses: <unnamed>%5CB77F4E0017;totalscommand::FinancialSettlementFile1 { -> F}
//## Uses: <unnamed>%5CB77F5303E0;totalscommand::FinancialSettlementFile2 { -> F}
//## Uses: <unnamed>%5CC072CC0317;entitysegment::Customer { -> F}
//## Uses: <unnamed>%6107F9270208;postingfile::CaseHistoryExport { -> F}
//## Uses: <unnamed>%6107F9480030;postingfile::TransactionActivityFile { -> F}
//## Uses: <unnamed>%6107F96500B0;postingfile::CaseReportFile { -> F}
//## Uses: <unnamed>%6107F9D000E9;managementinformation::FinancialBillingFile { -> F}
//## Uses: <unnamed>%6107F9D4030A;exceptionfile::ExceptionBillingFile { -> F}
//## Uses: <unnamed>%6108100002F1;reconciliationfile::PayPalPostingFile { -> F}
//## Uses: <unnamed>%610814E60188;totalscommand::TerminalCashBalance { -> F}

class DllExport DistributionFileFactory : public database::FileFactory  //## Inherits: <unnamed>%47791D05004E
{
  //## begin DistributionFileFactory%47791CC901B5.initialDeclarations preserve=yes
  //## end DistributionFileFactory%47791CC901B5.initialDeclarations

  public:
    //## Constructors (generated)
      DistributionFileFactory();

    //## Destructor (generated)
      virtual ~DistributionFileFactory();


    //## Other Operations (specified)
      //## Operation: create%47791D5E03D8
      database::ExportFile* create (const ExportFile& hExportFile);

      //## Operation: update%48060ECC00C9
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin DistributionFileFactory%47791CC901B5.public preserve=yes
      //## end DistributionFileFactory%47791CC901B5.public

  protected:
    // Additional Protected Declarations
      //## begin DistributionFileFactory%47791CC901B5.protected preserve=yes
      //## end DistributionFileFactory%47791CC901B5.protected

  private:
    // Additional Private Declarations
      //## begin DistributionFileFactory%47791CC901B5.private preserve=yes
      //## end DistributionFileFactory%47791CC901B5.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin DistributionFileFactory%47791CC901B5.implementation preserve=yes
      //## end DistributionFileFactory%47791CC901B5.implementation

};

//## begin DistributionFileFactory%47791CC901B5.postscript preserve=yes
//## end DistributionFileFactory%47791CC901B5.postscript

//## begin module%47791DB5038A.epilog preserve=yes
//## end module%47791DB5038A.epilog


#endif
