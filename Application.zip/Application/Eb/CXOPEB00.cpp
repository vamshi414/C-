//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4F5A27AC01E5.cm preserve=no
//	$Date:   Jun 22 2021 05:34:10  $ $Author:   e5563153  $
//	$Revision:   1.11.1.8.1.2  $
//## end module%4F5A27AC01E5.cm

//## begin module%4F5A27AC01E5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4F5A27AC01E5.cp

//## Module: CXOPEB00%4F5A27AC01E5; Package body
//## Subsystem: EB%4F5F829D00B4
//## Source file: C:\bV02.8A.R005\Windows\Build\Dn\Server\Application\Eb\CXOPEB00.cpp

//## begin module%4F5A27AC01E5.additionalIncludes preserve=no
//## end module%4F5A27AC01E5.additionalIncludes

//## begin module%4F5A27AC01E5.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),ENVAR('TASK=EB'))
#endif
#include "CXODDB27.hpp"
#include "CXODSX12.hpp"
#include "CXODDZ03.hpp"
#include "CXODDZ04.hpp"
#include "CXODDZ06.hpp"
#include "CXODCF01.hpp"
#include "CXODDB16.hpp"
#include "CXODDB50.hpp"
#include "CXODDZ08.hpp"
#include "CXODIF03.hpp"
#ifndef CXOSEX76_h
#include "CXODEX76.hpp"
#endif
#include "CXODSA12.hpp"
//## end module%4F5A27AC01E5.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSEC24_h
#include "CXODEC24.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSBC18_h
#include "CXODBC18.hpp"
#endif
#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOSDZ02_h
#include "CXODDZ02.hpp"
#endif
#ifndef CXOSPF01_h
#include "CXODPF01.hpp"
#endif
#ifndef CXOSBC53_h
#include "CXODBC53.hpp"
#endif
#ifndef CXOSEC01_h
#include "CXODEC01.hpp"
#endif
#ifndef CXOSEC02_h
#include "CXODEC02.hpp"
#endif
#ifndef CXOSVE21_h
#include "CXODVE21.hpp"
#endif
#ifndef CXOSME39_h
#include "CXODME39.hpp"
#endif
#ifndef CXOSME50_h
#include "CXODME50.hpp"
#endif
#ifndef CXOPEB00_h
#include "CXODEB00.hpp"
#endif


//## begin module%4F5A27AC01E5.declarations preserve=no
//## end module%4F5A27AC01E5.declarations

//## begin module%4F5A27AC01E5.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new ExceptionBatchInterface();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
#include "CXODFX14.hpp"
#include "CXODDB06.hpp"
#include "CXODEE09.hpp"
//## end module%4F5A27AC01E5.additionalDeclarations


// Class ExceptionBatchInterface 

ExceptionBatchInterface::ExceptionBatchInterface()
  //## begin ExceptionBatchInterface::ExceptionBatchInterface%4F5A26990397_const.hasinit preserve=no
      : m_lAPIType(INPUT_UNDEFINED),
        m_pCaseCreateCommand(0),
        m_pCaseUpdateCommand(0)
  //## end ExceptionBatchInterface::ExceptionBatchInterface%4F5A26990397_const.hasinit
  //## begin ExceptionBatchInterface::ExceptionBatchInterface%4F5A26990397_const.initialization preserve=yes
   ,m_pProvisionalTranCommand(0)
   , m_pEFTPosImportRecord(0)
  //## end ExceptionBatchInterface::ExceptionBatchInterface%4F5A26990397_const.initialization
{
  //## begin ExceptionBatchInterface::ExceptionBatchInterface%4F5A26990397_const.body preserve=yes
   memcpy(m_sID,"EB00",4);
  //## end ExceptionBatchInterface::ExceptionBatchInterface%4F5A26990397_const.body
}


ExceptionBatchInterface::~ExceptionBatchInterface()
{
  //## begin ExceptionBatchInterface::~ExceptionBatchInterface%4F5A26990397_dest.body preserve=yes
   delete m_pCaseCreateCommand;
   delete m_pCaseUpdateCommand;
   delete m_pProvisionalTranCommand;
   delete m_pEFTPosImportRecord;
   delete EMSRulesEngine::instance();
  //## end ExceptionBatchInterface::~ExceptionBatchInterface%4F5A26990397_dest.body
}



//## Other Operations (implementation)
int ExceptionBatchInterface::initialize ()
{
  //## begin ExceptionBatchInterface::initialize%4F5A2C4201C8.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("DR","##DR94  START EB");
   if (iRC == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->attach(this);
   database::DataModel::instance();
   database::CRTransactionTypeIndicator::instance();
   new PostingFileFactory();
   new dnplatform::APIExportFactory();   
   new dnplatform::APIQueueExportFactory();
   string strAPIType;
   IF::Extract::instance()->getSpec("APITYPE", strAPIType);
   Trace::put("API Type");
   Trace::put(strAPIType.c_str());

   if (strAPIType == "VCR")
      m_lAPIType = VCR;
   else if (strAPIType == "MCOM")
      m_lAPIType = MCOM;
   else if (strAPIType == "CMSE")
      m_lAPIType = CMSE;
   else if (strAPIType == "SECU")
      m_lAPIType = SECU;
   else if (strAPIType == "EFTPOS")
      m_lAPIType = EFTPOS;
   else
      m_lAPIType = INPUT_UNDEFINED;
   switch (m_lAPIType)
   {
      case VCR:
         m_pVCRImportRecord = new visaexception::VCRImportRecord();
         APIImport::instance()->add("VCR", m_pVCRImportRecord);
         break;
      case MCOM:
         m_pMasterComAPIImportRecord = new mastercardexception::MasterComAPIImportRecord();
		 m_pMasterComQueueImportRecord = new mastercardexception::MasterComQueueImportRecord();
         APIImport::instance()->add("MCOM",m_pMasterComAPIImportRecord);
		 APIImport::instance()->add("MQUE", m_pMasterComQueueImportRecord);
         APIImport::instance()->add("MFLD", m_pMasterComAPIImportRecord);
         break;
     case CMSE:
          m_pCardBaseImportRecord = new fis::CardBaseImportRecord();
          ClientCommand::setGlobalContext(ClientCommand::BEGIN, new GlobalContext("##BEGIN"));
          ClientCommand::setGlobalContext(ClientCommand::END, new GlobalContext("##END"));
          break;
      case SECU:
         m_pProvisionalTranCommand = new secuapi::ProvisionalTranCommand();
         break;
      case EFTPOS:
         m_pEFTPosImportRecord = new eftposexception::EFTPosImportRecord();
         APIImport::instance()->add("EFTPOS", m_pEFTPosImportRecord);
         break;
      default:
         ImportFile::instance()->add("DNBTCH", emscommand::BatchItem::instance(), 0);
         ImportFile::instance()->add("DNBXML", soapcommand::CaseCreateCommand::instance(), 0);
   }
   Database::instance()->connect();
   if(m_lAPIType == INPUT_UNDEFINED)
      Supervisor::instance()->update(0);
   string strCustomer;
   Extract::instance()->getSpec("CUSTOMER",strCustomer);
   Transaction::instance()->setCustomer(strCustomer);
   m_pCaseUpdateCommand = new CaseUpdateCommand();
   m_pCaseCreateCommand = new CaseCreateCommand();
   BatchItem::instance()->setCaseCreateCommand(m_pCaseCreateCommand);
   BatchItem::instance()->setCaseUpdateCommand(m_pCaseUpdateCommand);
   EMSRulesEngine::instance();
   DataControl::instance();
   new ActionFactory();
   new ExceptionFactory();
   new dnplatform::NetworkFactory();
   MinuteTimer::instance()->attach(this);
   ConfigurationRepository::instance()->loadTable("COUNTRY_CODE");
   return 0;
  //## end ExceptionBatchInterface::initialize%4F5A2C4201C8.body
}

int ExceptionBatchInterface::onMessage (Message& hMessage)
{
  //## begin ExceptionBatchInterface::onMessage%4F5A2C6202CD.body preserve=yes
   return 0;
  //## end ExceptionBatchInterface::onMessage%4F5A2C6202CD.body
}

int ExceptionBatchInterface::onReset (Message& hMessage)
{
  //## begin ExceptionBatchInterface::onReset%4F5A32230339.body preserve=yes
   Transaction::instance()->begin();
   Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSS(true) += "00");
   EMSRulesEngine::instance()->reset();
   if (!memcmp((char*)hMessage.context(), "VCR", 3))
   {
      if (m_pVCRImportRecord == 0)
      {
         m_pVCRImportRecord = new visaexception::VCRImportRecord();
         APIImport::instance()->add("VCR", m_pVCRImportRecord);
      }
      APIImport::instance()->onResume();
   }
   if (!memcmp((char*)hMessage.context(),"MCOM",4))
   {
      if (m_pMasterComAPIImportRecord == 0)      
      {
         m_pMasterComAPIImportRecord = new mastercardexception::MasterComAPIImportRecord();
         APIImport::instance()->add("MCOM", m_pMasterComAPIImportRecord);
      }
	  if (m_pMasterComQueueImportRecord == 0)
	  {
		  m_pMasterComQueueImportRecord = new mastercardexception::MasterComQueueImportRecord();
		  APIImport::instance()->add("MQUE", m_pMasterComQueueImportRecord);
	  }
      APIImport::instance()->onResume();
   }
   if (!memcmp((char*)hMessage.context(), "EFTPOS", 6))
   {
      if (m_pEFTPosImportRecord == 0)
      {
         m_pEFTPosImportRecord = new  eftposexception::EFTPosImportRecord();
         APIImport::instance()->add("EFTPOS", m_pEFTPosImportRecord);
      }
      APIImport::instance()->onResume();
   }
   if (!memcmp((char*)hMessage.context(), "CMSE", 4))
   {
      if (m_pCardBaseImportRecord == 0)
      {
         m_pCardBaseImportRecord = new  fis::CardBaseImportRecord();
         m_pCardBaseImportRecord->execute();
      }
   }
   if (!memcmp((char*)hMessage.context(), "SECU", 4))
   {
      if (m_pProvisionalTranCommand == 0)
         m_pProvisionalTranCommand = new  secuapi::ProvisionalTranCommand();
      m_pProvisionalTranCommand->execute();
   }
   if (Database::instance()->transactionState() == Database::COMMITREQUIRED)
      Database::instance()->commit();
   else
      Database::instance()->rollback();
   Transaction::instance()->commit();
   return 0;
  //## end ExceptionBatchInterface::onReset%4F5A32230339.body
}

int ExceptionBatchInterface::onResume (Message& hMessage)
{
  //## begin ExceptionBatchInterface::onResume%4F5A322B0005.body preserve=yes
   Transaction::instance()->begin();
   Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   EMSRulesEngine::instance()->reset();
   switch (m_lAPIType)
   {
      case VCR:
         Trace::put("resume of vcr");
         if (m_pVCRImportRecord != 0)
            APIImport::instance()->onResume();
         Trace::put("resume of vcr done");
         break;
      case MCOM:
         Trace::put("resume of MasterComm");
         if (m_pMasterComAPIImportRecord != 0)
            APIImport::instance()->onResume();
		 if (m_pMasterComQueueImportRecord != 0)
			 APIImport::instance()->onResume();
         Trace::put("resume of MasterComm done");
         break;
     case CMSE:
        Trace::put("resume of Provisional Credit");
        m_pCardBaseImportRecord = new  fis::CardBaseImportRecord();
        m_pCardBaseImportRecord->execute();
		break;
     case EFTPOS:
        Trace::put("resume of EFTPOS");
        if (m_pEFTPosImportRecord != 0)
           APIImport::instance()->onResume();
        Trace::put("resume of EFTPOS done");
        break;
      default:
         ImportFile::instance()->onResume();
   }
   if (Database::instance()->transactionState() == Database::COMMITREQUIRED)
      Database::instance()->commit();
   else
      Database::instance()->rollback();
   Transaction::instance()->commit();
   return 0;
  //## end ExceptionBatchInterface::onResume%4F5A322B0005.body
}

void ExceptionBatchInterface::update (Subject* pSubject)
{
  //## begin ExceptionBatchInterface::update%4F5A2C5403C6.body preserve=yes
   if (pSubject == MinuteTimer::instance())
      setQueueWaitOption(false);
   if (pSubject == Database::instance()
      && Database::instance()->state() == Database::CONNECTED)
      setQueueWaitOption(false);
   Application::update(pSubject);
  //## end ExceptionBatchInterface::update%4F5A2C5403C6.body
}

// Additional Declarations
  //## begin ExceptionBatchInterface%4F5A26990397.declarations preserve=yes
  //## end ExceptionBatchInterface%4F5A26990397.declarations

//## begin module%4F5A27AC01E5.epilog preserve=yes
//## end module%4F5A27AC01E5.epilog
