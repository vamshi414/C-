//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4F5A27AB002C.cm preserve=no
//	$Date:   Apr 07 2021 04:48:56  $ $Author:   e5627846  $
//	$Revision:   1.8.1.0  $
//## end module%4F5A27AB002C.cm

//## begin module%4F5A27AB002C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%4F5A27AB002C.cp

//## Module: CXOPEB00%4F5A27AB002C; Package specification
//## Subsystem: EB%4F5F829D00B4
//## Source file: C:\bV02.9A.R008\Windows\Build\Dn\Server\Application\Eb\CXODEB00.hpp

#ifndef CXOPEB00_h
#define CXOPEB00_h 1

//## begin module%4F5A27AB002C.additionalIncludes preserve=no
//## end module%4F5A27AB002C.additionalIncludes

//## begin module%4F5A27AB002C.includes preserve=yes
//## end module%4F5A27AB002C.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Data Distribution::PostingFile_CAT%41E951230177
namespace postingfile {
class PostingFileFactory;
} // namespace postingfile

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Transaction;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class APIImport;
} // namespace command

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

namespace command {
class ImportFile;
} // namespace command

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Message;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class MinuteTimer;
} // namespace timer

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class ActionFactory;
class DNPlatform;
} // namespace dnplatform

//## Modelname: Transaction Research and Adjustments::EMSCommand_CAT%394E266C015B
namespace emscommand {
class BatchItem;
class CaseCreateCommand;
class CaseUpdateCommand;
} // namespace emscommand

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSRulesEngine;
} // namespace ems

//## Modelname: Transaction Research and Adjustments::VisaException_CAT%4097A16101D4
namespace visaexception {
class VCRImportRecord;
} // namespace visaexception

//## Modelname: Transaction Research and Adjustments::MasterCardException_CAT%4242FC56001F
namespace mastercardexception {
class MasterComAPIImportRecord;
class MasterComAPIImportRecord;

} // namespace mastercardexception

//## Modelname: Platform \: SECU::SECUAPI%5B7380FC01F4
namespace secuapi {
    class ProvisionalTranCommand;

} // namespace secuapi

//## begin module%4F5A27AB002C.declarations preserve=no
//## end module%4F5A27AB002C.declarations

//## begin module%4F5A27AB002C.additionalDeclarations preserve=yes
//## end module%4F5A27AB002C.additionalDeclarations


//## begin ExceptionBatchInterface%4F5A26990397.preface preserve=yes
namespace fis {
   class CardBaseImportRecord;
}
namespace eftposexception {
   class EFTPosImportRecord;
}
//## end ExceptionBatchInterface%4F5A26990397.preface

//## Class: ExceptionBatchInterface%4F5A26990397
//	<body>
//	<title>CG
//	<h1>EB
//	<h2>AB
//	<h3>System Flow
//	<p>
//	DataNavigator can process disputes on individual
//	transactions or sets of related transactions (e.g. for
//	fraud related issues).
//	For a set of related transactions, the request is staged
//	for the end user to be processed in the background to
//	free the user to do other work without waiting.
//	<p>
//	The Exception Batch service (<i>ca</i>EB) polls the data
//	import control table (DI_DATA_CONTROL) for new batches
//	staged by end users.
//	Each item for that batch in the data import table (DI_
//	DATA) is processed to initiate a new dispute in the EMS
//	case tables (EMS_CASE, EMS_PHASE, EMS_TRANSITION, etc).
//	</p>
//	<img src=CXOCEB00.gif>
//	<p>
//	Refer to the various <i>DataNavigator Client Exception
//	Management User's Guides</i> for more information.
//	</p>
//	</body>
//	<body>
//	<title>OG
//	<h1>EB
//	<h2>AB
//	<h3>System Flow
//	<p>
//	For exception item processing, the DataNavigator server
//	provides batch interfaces to other systems (e.g. VISA or
//	MasterCard).
//	<p>
//	<img src=CXOOEB00.gif>
//	</p>
//	</body>
//## Category: Transaction Research and Adjustments::ExceptionBatchInterface_CAT (EB)%4F5F818801B9
//## Subsystem: EB%4F5F829D00B4
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4F5A3B110222;IF::Message { -> F}
//## Uses: <unnamed>%4F5A3CED012D;database::Database { -> F}
//## Uses: <unnamed>%4F5A3D0B02BE;monitor::UseCase { -> F}
//## Uses: <unnamed>%4F5A3E0302C2;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%4F5A3E670059;IF::Extract { -> F}
//## Uses: <unnamed>%4F5A3E9E0294;reusable::Transaction { -> F}
//## Uses: <unnamed>%4F5A3ED30015;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%4F5A3F2B02F1;emscommand::BatchItem { -> F}
//## Uses: <unnamed>%4F5A3F90016D;timer::Clock { -> F}
//## Uses: <unnamed>%4F5A400D02B9;command::ImportFile { -> F}
//## Uses: <unnamed>%4F5A416C0004;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%4F5FA1E40372;dnplatform::ActionFactory { -> F}
//## Uses: <unnamed>%4F7A129F0079;postingfile::PostingFileFactory { -> F}
//## Uses: <unnamed>%589B43D3030F;command::APIImport { -> F}

class DllExport ExceptionBatchInterface : public process::Application  //## Inherits: <unnamed>%4F5A28A40149
{
  //## begin ExceptionBatchInterface%4F5A26990397.initialDeclarations preserve=yes
public:
   enum APIType
   {
      INPUT_UNDEFINED = -1,
      VCR,
      MCOM,
      CMSE,
      SECU,
      EFTPOS
   };
  //## end ExceptionBatchInterface%4F5A26990397.initialDeclarations

  public:
    //## Constructors (generated)
      ExceptionBatchInterface();

    //## Destructor (generated)
      virtual ~ExceptionBatchInterface();


    //## Other Operations (specified)
      //## Operation: initialize%4F5A2C4201C8
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>EB
      //	<h2>MS
      //	<h3>Configuration
      //	<p>
      //	The Exception Batch service requires the following
      //	configuration:
      //	<ol>
      //	<li>Modules : add Module 'EB' with Description
      //	'Exception Batch':
      //	<table>
      //	<tr>
      //	<th>Type
      //	<th>Label
      //	<th>Module
      //	<th>Parms
      //	<tr>
      //	<td>E
      //	<td>DRIVER
      //	<td>CXRS3X00
      //	<td>
      //	<tr>
      //	<td>E
      //	<td>MISC
      //	<td>CXRS3X40
      //	<td>
      //	<tr>
      //	<td>E
      //	<td>FILE
      //	<td>CXRS3X20
      //	<td>
      //	<tr>
      //	<td>L
      //	<td>DRIVER
      //	<td>CXOPEB00
      //	<td>C++
      //	</table>
      //	<li>Task Type/SubType : add Type '<i>ca</i>EB' Subtype
      //	'*':
      //	<table>
      //	<tr>
      //	<th>Detail
      //	<th>Value
      //	<tr>
      //	<td>Description
      //	<td>Exception Batch
      //	<tr>
      //	<td>Dispatching Priority
      //	<td>128
      //	<tr>
      //	<td>Supports Quiesce/Restart
      //	<td>checked
      //	<tr>
      //	<td>Automatic Quiesce/Restart
      //	<td>checked
      //	<tr>
      //	<td>Supports Partial Refresh
      //	<td>checked
      //	</table>
      //	<li>Task : add Task '<i>ca</i>EB':
      //	<ul>
      //	<li>Detail : General
      //	<li>Detail : Buffers
      //	</ul>
      //	<li>File : add the following:
      //	</ol>
      //	</p>
      //	</body>
      virtual int initialize ();

      //## Operation: update%4F5A2C5403C6
      //	Interprets the inbound Message and calls:
      //
      //	   Application::onConfirm
      //	   Application::onMessage
      //	   Application::onNotify
      //	   Application::onQuiesce
      //	   Application::onRefresh
      //	   Application::onReset
      //	   Application::shutdown
      //	   Timer::elapsed
      //## Postconditions:
      //	<body>
      //	<title>CG
      //	<h1>FM
      //	<h2>FO
      //	<h3>Messages
      //	<p>
      //	Messages displayed by the DataNavigator services are
      //	saved in:
      //	<ul>
      //	<li><i>qualify</i>.CONSOLE_MSG
      //	</ul>
      //	</body>
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin ExceptionBatchInterface%4F5A26990397.public preserve=yes
      //## end ExceptionBatchInterface%4F5A26990397.public

  protected:

    //## Other Operations (specified)
      //## Operation: onMessage%4F5A2C6202CD
      virtual int onMessage (Message& hMessage);

      //## Operation: onReset%4F5A32230339
      virtual int onReset (Message& hMessage);

      //## Operation: onResume%4F5A322B0005
      virtual int onResume (Message& hMessage);

    // Additional Protected Declarations
      //## begin ExceptionBatchInterface%4F5A26990397.protected preserve=yes
      //## end ExceptionBatchInterface%4F5A26990397.protected

  private:
    // Additional Private Declarations
      //## begin ExceptionBatchInterface%4F5A26990397.private preserve=yes
      //## end ExceptionBatchInterface%4F5A26990397.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: APIType%589B3BE003E2
      //	Defines whether the EB task is processing DI_DATA or VCR
      //	responses.
      //## begin ExceptionBatchInterface::APIType%589B3BE003E2.attr preserve=no  public: APIType {U} INPUT_UNDEFINED
      APIType m_lAPIType;
      //## end ExceptionBatchInterface::APIType%589B3BE003E2.attr

    // Data Members for Associations

      //## Association: Transaction Research and Adjustments::ExceptionBatchInterface_CAT (EB)::<unnamed>%4F5F83A30369
      //## Role: ExceptionBatchInterface::<m_pCaseCreateCommand>%4F5F83A402B5
      //## begin ExceptionBatchInterface::<m_pCaseCreateCommand>%4F5F83A402B5.role preserve=no  public: emscommand::CaseCreateCommand { -> RFHgN}
      emscommand::CaseCreateCommand *m_pCaseCreateCommand;
      //## end ExceptionBatchInterface::<m_pCaseCreateCommand>%4F5F83A402B5.role

      //## Association: Transaction Research and Adjustments::ExceptionBatchInterface_CAT (EB)::<unnamed>%4F5F83A800AE
      //## Role: ExceptionBatchInterface::<m_pCaseUpdateCommand>%4F5F83A803C4
      //## begin ExceptionBatchInterface::<m_pCaseUpdateCommand>%4F5F83A803C4.role preserve=no  public: emscommand::CaseUpdateCommand { -> RFHgN}
      emscommand::CaseUpdateCommand *m_pCaseUpdateCommand;
      //## end ExceptionBatchInterface::<m_pCaseUpdateCommand>%4F5F83A803C4.role

      //## Association: Transaction Research and Adjustments::ExceptionBatchInterface_CAT (EB)::<unnamed>%58A04AD20002
      //## Role: ExceptionBatchInterface::<m_pVCRImportRecord>%58A04AD203BC
      //## begin ExceptionBatchInterface::<m_pVCRImportRecord>%58A04AD203BC.role preserve=no  public: visaexception::VCRImportRecord { -> RFHgN}
      visaexception::VCRImportRecord *m_pVCRImportRecord;
      //## end ExceptionBatchInterface::<m_pVCRImportRecord>%58A04AD203BC.role

      //## Association: Transaction Research and Adjustments::ExceptionBatchInterface_CAT (EB)::<unnamed>%5B69E34701DD
      //## Role: ExceptionBatchInterface::<m_pMasterComAPIImportRecord>%5B69E348016C
      //## begin ExceptionBatchInterface::<m_pMasterComAPIImportRecord>%5B69E348016C.role preserve=no  public: mastercardexception::MasterComAPIImportRecord { -> RFHgN}
      mastercardexception::MasterComAPIImportRecord *m_pMasterComAPIImportRecord;
      //## end ExceptionBatchInterface::<m_pMasterComAPIImportRecord>%5B69E348016C.role

	  //## Association: Transaction Research and Adjustments::ExceptionBatchInterface_CAT (EB)::<unnamed>%5BFBB34D012F
	  //## Role: ExceptionBatchInterface::<m_pMasterComQueueImportRecord>%5BFBB34E01F7
	  //## begin ExceptionBatchInterface::<m_pMasterComQueueImportRecord>%5BFBB34E01F7.role preserve=no  public: mastercardexception::MasterComQueueImportRecord { -> RFHgN}
	  mastercardexception::MasterComQueueImportRecord *m_pMasterComQueueImportRecord;
      //## end ExceptionBatchInterface::<m_pMasterComQueueImportRecord>%5BFBB34E01F7.role

    // Additional Implementation Declarations
      //## begin ExceptionBatchInterface%4F5A26990397.implementation preserve=yes
     fis::CardBaseImportRecord *m_pCardBaseImportRecord;
      secuapi::ProvisionalTranCommand* m_pProvisionalTranCommand;
      eftposexception::EFTPosImportRecord *m_pEFTPosImportRecord;
      //## end ExceptionBatchInterface%4F5A26990397.implementation

};

//## begin ExceptionBatchInterface%4F5A26990397.postscript preserve=yes
//## end ExceptionBatchInterface%4F5A26990397.postscript

//## begin module%4F5A27AB002C.epilog preserve=yes
//## end module%4F5A27AB002C.epilog


#endif
