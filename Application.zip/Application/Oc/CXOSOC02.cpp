//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%424D82BC029F.cm preserve=no
//## end module%424D82BC029F.cm

//## begin module%424D82BC029F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%424D82BC029F.cp

//## Module: CXOSOC02%424D82BC029F; Package body
//## Subsystem: OC%424D79890000
//## Source file: C:\Program Files (x86)\Rational\Application\Oc\CXOSOC02.cpp

//## begin module%424D82BC029F.additionalIncludes preserve=no
//## end module%424D82BC029F.additionalIncludes

//## begin module%424D82BC029F.includes preserve=yes
#include <algorithm>
#include "CXODRU19.hpp"
#include "CXODTM04.hpp"
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#include "CXODRU34.hpp"
//## end module%424D82BC029F.includes

#ifndef CXOSNS01_h
#include "CXODNS01.hpp"
#endif
#ifndef CXOSNS02_h
#include "CXODNS02.hpp"
#endif
#ifndef CXOSNS03_h
#include "CXODNS03.hpp"
#endif
#ifndef CXOSNS05_h
#include "CXODNS05.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF41_h
#include "CXODIF41.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSNS04_h
#include "CXODNS04.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSNS10_h
#include "CXODNS10.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSDB04_h
#include "CXODDB04.hpp"
#endif
#ifndef CXOSNC01_h
#include "CXODNC01.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSNS47_h
#include "CXODNS47.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSNS48_h
#include "CXODNS48.hpp"
#endif
#ifndef CXOSOC02_h
#include "CXODOC02.hpp"
#endif


//## begin module%424D82BC029F.declarations preserve=no
//## end module%424D82BC029F.declarations

//## begin module%424D82BC029F.additionalDeclarations preserve=yes
//## end module%424D82BC029F.additionalDeclarations


// Class OasisEntityFile 

OasisEntityFile::OasisEntityFile()
  //## begin OasisEntityFile::OasisEntityFile%427B310F0090_const.hasinit preserve=no
      : m_bHeaderValidated(false),
        m_iInsertCount(0),
        m_bReadInstitutionMap(false)
  //## end OasisEntityFile::OasisEntityFile%427B310F0090_const.hasinit
  //## begin OasisEntityFile::OasisEntityFile%427B310F0090_const.initialization preserve=yes
   ,CRFile("CED")
  //## end OasisEntityFile::OasisEntityFile%427B310F0090_const.initialization
{
  //## begin OasisEntityFile::OasisEntityFile%427B310F0090_const.body preserve=yes
   memcpy(m_sID,"OC02",4);
  //## end OasisEntityFile::OasisEntityFile%427B310F0090_const.body
}


OasisEntityFile::~OasisEntityFile()
{
  //## begin OasisEntityFile::~OasisEntityFile%427B310F0090_dest.body preserve=yes
  //## end OasisEntityFile::~OasisEntityFile%427B310F0090_dest.body
}



//## Other Operations (implementation)
void OasisEntityFile::copyATM ()
{
  //## begin OasisEntityFile::copyATM%4E78187B010D.body preserve=yes
   UseCase hUseCase("IST","## IS08 ATM");
   m_pFileSegment = CRDeviceSegment::instance();
   CRDeviceSegment::instance()->reset();
   CRDeviceSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   const char* pszCursor = m_psBuffer;
   extract(&pszCursor).c_str(); // EntityCategory
   extract(&pszCursor).c_str(); //
   CRDeviceSegment::instance()->setDEVICE_ID(extract(&pszCursor,8).c_str()); // TermId
   CRDeviceSegment::instance()->setINST_ID(extract(&pszCursor,11).c_str()); //InstId
   extract(&pszCursor).c_str(); //
   extract(&pszCursor).c_str(); //
   extract(&pszCursor).c_str(); //
   extract(&pszCursor).c_str(); // Unit
   CRDeviceSegment::instance()->setRPT_LVL_ID(extract(&pszCursor,16).c_str()); // // ParentEntityId
   extract(&pszCursor).c_str(); //atm cutofftime
   CRDeviceSegment::instance()->setADDRESS(extract(&pszCursor,28).c_str()); // Address1
   CRDeviceSegment::instance()->setCITY(extract(&pszCursor,27).c_str()); // City
   CRDeviceSegment::instance()->setREGION(extract(&pszCursor,3).c_str()); // ProvStateCode
   string strCOUNTY(extract(&pszCursor,3));
   CRDeviceSegment::instance()->setCOUNTY(strCOUNTY.c_str()); // CountyCode
   extract(&pszCursor).c_str(); // County
   CRDeviceSegment::instance()->setPOSTAL_CODE(extract(&pszCursor,10).c_str()); // PostalCodeZip
   CRDeviceSegment::instance()->setCOUNTRY(extract(&pszCursor,3).c_str()); // CountryCode
   extract(&pszCursor).c_str(); // Model
   //extract(&pszCursor).c_str(); // Make
   //extract(&pszCursor).c_str(); // Term Corp
   //extract(&pszCursor).c_str(); // Manufacturer
   //extract(&pszCursor).c_str(); // Emulation
  //## end OasisEntityFile::copyATM%4E78187B010D.body
}

void OasisEntityFile::copyATMGroup ()
{
  //## begin OasisEntityFile::copyATMGroup %4E7819220242.body preserve=yes
   UseCase hUseCase("IST","## IS09 ATM GROUP");
   m_pFileSegment = CRReportingLevelSegment::instance();
   CRReportingLevelSegment::instance()->reset();
   CRReportingLevelSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   const char* pszCursor = m_psBuffer;
   extract(&pszCursor).c_str(); // EntityCategory
   CRReportingLevelSegment::instance()->setRPT_LVL_ID(extract(&pszCursor,16).c_str()); // EntityId
   extract(&pszCursor); // InstitutionId
   CRReportingLevelSegment::instance()->setNEXT_ID(extract(&pszCursor,16).c_str()); // ParentEntityId ...
   CRReportingLevelSegment::instance()->setNEXT_CUST_ID(Customer::instance()->getCUST_ID());
  //## end OasisEntityFile::copyATMGroup %4E7819220242.body
}

void OasisEntityFile::copyEntity ()
{
  //## begin OasisEntityFile::copyEntity%5706C668009D.body preserve=yes
   UseCase hUseCase("IST","## IS04 REPORTING LEVEL");
   const char* pszCursor = m_psBuffer;
   extract(&pszCursor).c_str(); // EntityCategory
   string strEntityLevel(extract(&pszCursor,1)); // EntityLevel
   string strEntityId(extract(&pszCursor)); // AGENT/CHAIN
   extract(&pszCursor).c_str(); // AGENT/CHAIN
   if (strEntityId == "ACQ_BUS_UNIT")
   {
      m_pFileSegment = CRProcessorSegment::instance();
      CRProcessorSegment::instance()->reset();
      CRProcessorSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
      CRProcessorSegment::instance()->setPROC_ID(extract(&pszCursor,8));
      CRProcessorSegment::instance()->setPROC_GRP_ID(extract(&pszCursor,8));
   }
   else
   if (strEntityId == "PRINCIPAL"
      || strEntityId == "PORTFOLIO")
   {
      m_pFileSegment = CRInstitutionSegment::instance();
      CRInstitutionSegment::instance()->reset();
      CRInstitutionSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
      CRInstitutionSegment::instance()->setINST_ID(extract(&pszCursor,11));
      extract(&pszCursor).c_str(); // FISDIR
      CRInstitutionSegment::instance()->setNAME(extract(&pszCursor,35));
      extract(&pszCursor).c_str(); // LOADER
      extract(&pszCursor).c_str(); // A
      CRInstitutionSegment::instance()->setPROC_ID(extract(&pszCursor,8));
      if (CRInstitutionSegment::instance()->getPROC_ID().empty())
         CRInstitutionSegment::instance()->setPROC_ID(Customer::instance()->getCUST_ID());
   }
   else
   if (strEntityId == "AGENT"
      || strEntityId == "CHAIN")
   {
      m_pFileSegment = CRReportingLevelSegment::instance();
      CRReportingLevelSegment::instance()->reset();
      CRReportingLevelSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
      string strRPT_LVL_ID(extract(&pszCursor,16));
      CRReportingLevelSegment::instance()->setRPT_LVL_ID(strRPT_LVL_ID);
      extract(&pszCursor).c_str(); // FISDIR
      CRReportingLevelSegment::instance()->setRPT_LVL_NAME(extract(&pszCursor,35));
      extract(&pszCursor).c_str(); // LOADER
      extract(&pszCursor).c_str(); // A
      string strNEXT_ID(extract(&pszCursor,16));
      if (strEntityId == "AGENT")
         m_hAgents.insert(map<string,string,less<string> >::value_type(strRPT_LVL_ID,strNEXT_ID));
      else
      {
         CRReportingLevelSegment::instance()->setNEXT_ID(strNEXT_ID);
         CRReportingLevelSegment::instance()->setNEXT_CUST_ID(Customer::instance()->getCUST_ID());
         m_hChains.insert(map<string,string,less<string> >::value_type(strRPT_LVL_ID,strNEXT_ID));
      }
   }
  //## end OasisEntityFile::copyEntity%5706C668009D.body
}

void OasisEntityFile::copyInstitution ()
{
  //## begin OasisEntityFile::copyInstitution%428345F80276.body preserve=yes
   UseCase hUseCase("IST","## IS03 INSTITUTION ");
   m_pFileSegment = CRInstitutionSegment::instance();
   CRInstitutionSegment::instance()->reset();
   CRInstitutionSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   const char* pszCursor = m_psBuffer;
   extract(&pszCursor).c_str(); // EntityCategory
   extract(&pszCursor).c_str(); // EntityLevel
   extract(&pszCursor).c_str(); // EntityType
   string strEntityDescription(extract(&pszCursor)); // EntityDescription
   string strINST_ID(extract(&pszCursor, 11).c_str());
   if (Extract::instance()->getCustomCode() == "PAAS")
      transform(strINST_ID.begin(), strINST_ID.end(), strINST_ID.begin(), ::toupper);
   
   CRInstitutionSegment::instance()->setINST_ID(strINST_ID); // EntityId
   CRInstitutionSegment::instance()->setNAME(extract(&pszCursor,35).c_str()); // InstitutionName
   if (Extract::instance()->getCustomCode() == "MPS")
   {
      CRInstitutionSegment::instance()->setPROC_ID(Customer::instance()->getCUST_ID());
   }
   else
   {
      if (strEntityDescription == "DB MEM/ISS" && m_strDebitPROC_ID.length() > 0)
         CRInstitutionSegment::instance()->setPROC_ID(m_strDebitPROC_ID.c_str());
      else
      if (strEntityDescription == "CR CARD_AS" && m_strCreditPROC_ID.length() > 0)
         CRInstitutionSegment::instance()->setPROC_ID(m_strCreditPROC_ID.c_str());
      else
      if (strEntityDescription == "DB CARD_AS" && m_strDebitPROC_ID.length() > 0)
         CRInstitutionSegment::instance()->setPROC_ID(m_strDebitPROC_ID.c_str());
      else
      if (m_strPROC_ID.length() > 0)
         CRInstitutionSegment::instance()->setPROC_ID(m_strPROC_ID.c_str());
      else
         CRInstitutionSegment::instance()->setPROC_ID(Customer::instance()->getCUST_ID());
   }
   extract(&pszCursor).c_str(); // InstitutionFiscalYearEnd
   extract(&pszCursor).c_str(); // LanguageCode
   extract(&pszCursor).c_str(); // SecondaryLanguageCode
   extract(&pszCursor).c_str(); // ISOCurrencyCode
   string strCUTOFF_TIME(extract(&pszCursor,8));
   strCUTOFF_TIME.resize(8,'0');
   CRInstitutionSegment::instance()->setCUTOFF_TIME(strCUTOFF_TIME);
   string strAddress1(extract(&pszCursor,60).c_str()); // Address1
   string strAddress2(extract(&pszCursor,60).c_str()); // Address2
   string strCity(extract(&pszCursor,60).c_str()); // City
   extract(&pszCursor).c_str(); // ProvStateCode
   extract(&pszCursor).c_str(); // ProvStateNumberCode
   string strProvinceState(extract(&pszCursor,60).c_str()); // ProvinceState
   extract(&pszCursor).c_str(); // CountyCode
   string strOrgName(extract(&pszCursor,60).c_str()); // OrgName
   string strPostalCodeZip(extract(&pszCursor,10).c_str()); // PostalCodeZip
   extract(&pszCursor).c_str(); // CountryCode
   extract(&pszCursor).c_str(); // Country
   string strPhone1(extract(&pszCursor,20).c_str()); // Phone1
   extract(&pszCursor).c_str(); // Phone2
   extract(&pszCursor).c_str(); // Fax
   string strEmail(extract(&pszCursor,60).c_str()); // Email
   extract(&pszCursor).c_str(); // URL
   extract(&pszCursor).c_str(); // ModifiedDate
   string strPROC_ID;
   if (strEntityDescription == "MAIN_INST")
   {
      strPROC_ID = extract(&pszCursor,8).c_str(); // Processor
      if (strPROC_ID.length() > 0)
          CRInstitutionSegment::instance()->setPROC_ID(strPROC_ID);
   }

   if (Extract::instance()->getCustomCode() == "COLES")
   {
      transform(strINST_ID.begin(), strINST_ID.end(), strINST_ID.begin(), ::toupper);
      transform(strPROC_ID.begin(), strPROC_ID.end(), strPROC_ID.begin(), ::toupper);
      CRInstitutionSegment::instance()->setINST_ID(strINST_ID);
      CRInstitutionSegment::instance()->setPROC_ID(strPROC_ID);
      ContactSegment::instance(ContactSegment::SENDER)->setINST_ID(CRInstitutionSegment::instance()->getINST_ID());
      ContactSegment::instance(ContactSegment::SENDER)->setCONTACT_TYPE("ALL");
      ContactSegment::instance(ContactSegment::SENDER)->setNAME(CRInstitutionSegment::instance()->getNAME());
      ContactSegment::instance(ContactSegment::SENDER)->setORG_NAME(strOrgName);
      ContactSegment::instance(ContactSegment::SENDER)->setTELEPHONE_NO(strPhone1);
      ContactSegment::instance(ContactSegment::SENDER)->setCITY(strCity);
      ContactSegment::instance(ContactSegment::SENDER)->setPOSTAL_CODE(strPostalCodeZip);
      ContactSegment::instance(ContactSegment::SENDER)->setUPDATED_BY_USER_ID("SYSTEM");
      ContactSegment::instance(ContactSegment::SENDER)->setTSTAMP_UPDATED(Clock::instance()->getYYYYMMDDHHMMSSHN());
      ContactSegment::instance(ContactSegment::SENDER)->setADDRESS_LINE_1(strAddress1);
      ContactSegment::instance(ContactSegment::SENDER)->setADDRESS_LINE_2(strAddress2);
      ContactSegment::instance(ContactSegment::SENDER)->setADDRESS_LINE_3(strProvinceState);
      ContactSegment::instance(ContactSegment::SENDER)->setEMAIL_ADDRESS(strEmail);
      ContactSegment::instance(ContactSegment::SENDER)->setCONTACT_METHOD("E");
      ContactSegment::instance(ContactSegment::SENDER)->setPresence(true);
   }
   else if (Extract::instance()->getCustomCode() == "CBA")
   {
      ContactSegment::instance(ContactSegment::SENDER)->setPOSTAL_CODE(strPostalCodeZip);
      ContactSegment::instance(ContactSegment::SENDER)->setEMAIL_ADDRESS(strEmail);
      if (!strEmail.empty())
         ContactSegment::instance(ContactSegment::SENDER)->setCONTACT_METHOD("E");
      else if (!strPostalCodeZip.empty())
         ContactSegment::instance(ContactSegment::SENDER)->setCONTACT_METHOD("N");
      ContactSegment::instance(ContactSegment::SENDER)->setPresence(true);
   }
  //## end OasisEntityFile::copyInstitution%428345F80276.body
}

void OasisEntityFile::copyMerchant ()
{
  //## begin OasisEntityFile::copyMerchant%4283461C00A2.body preserve=yes
   UseCase hUseCase("IST","## IS04 REPORTING LEVEL");
   m_pFileSegment = CRReportingLevelSegment::instance();
   CRReportingLevelSegment::instance()->reset();
   CRReportingLevelSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   const char* pszCursor = m_psBuffer;
   extract(&pszCursor).c_str(); // EntityCategory
   string strEntityLevel(extract(&pszCursor,1)); // EntityLevel
   string strEntityId(extract(&pszCursor)); // EntityId
   extract(&pszCursor).c_str(); // InstitutionId
   string strName(extract(&pszCursor,35)); // EntityName
   string strEntityDBAName(extract(&pszCursor,30).c_str()); // EntityDBAName
   extract(&pszCursor).c_str(); // EntityABANumber
   extract(&pszCursor).c_str(); // EntityStatus
   string strParentEntityId(extract(&pszCursor,16).c_str()); // ParentEntityId ...
   if (Extract::instance()->getCustomCode() == "PAAS")
      transform(strParentEntityId.begin(), strParentEntityId.end(), strParentEntityId.begin(), ::toupper);
   
   string strExternalEntityId(extract(&pszCursor,16).c_str()); // ExternalEntityId
   extract(&pszCursor).c_str(); // CreationDate
   extract(&pszCursor).c_str(); // ExpectedStartDate
   extract(&pszCursor).c_str(); // ActualStartDate
   extract(&pszCursor).c_str(); // TerminationDate
   extract(&pszCursor).c_str(); // VATRegNumber
   extract(&pszCursor).c_str(); // SettlementAgent
   extract(&pszCursor).c_str(); // TimeZoneDiff
   extract(&pszCursor).c_str(); // InvoiceBatch
   extract(&pszCursor).c_str(); // InvoiceSubCode
   extract(&pszCursor).c_str(); // ProcessChild
   extract(&pszCursor).c_str(); // CAPNumber
   extract(&pszCursor).c_str(); // TravelAgencyCode
   extract(&pszCursor).c_str(); // TravelAgencyName
   extract(&pszCursor).c_str(); // MVV
   extract(&pszCursor).c_str(); // OilCoBrandName
   extract(&pszCursor).c_str(); // pos_fcutover_time
   string strRPT_LVL_ID(extract(&pszCursor,16));
   CRReportingLevelSegment::instance()->setRPT_LVL_NAME(strName.c_str()); // EntityName
   ContactSegment::instance(ContactSegment::SENDER)->setNAME(strName);
   extract(&pszCursor).c_str(); // area
   string strDistrict(extract(&pszCursor,11).c_str()); // district
   ContactSegment::instance(ContactSegment::SENDER)->setADDRESS_LINE_1(extract(&pszCursor,28).c_str()); // Address
   (extract(&pszCursor).c_str()); //
   ContactSegment::instance(ContactSegment::SENDER)->setCITY(extract(&pszCursor,27).c_str()); // City
   ContactSegment::instance(ContactSegment::SENDER)->setREGION(extract(&pszCursor,2).c_str()); // State
   string strProvinceState(extract(&pszCursor,60).c_str()); //ProvinceState
   string strPhone1(extract(&pszCursor,20).c_str()); //Phone1
   string strOrgName(extract(&pszCursor,60).c_str()); //OrgName
   string strEmail(extract(&pszCursor,60).c_str()); //Email
   string strPostalCodeZip(extract(&pszCursor, 10).c_str()); // zip code
   ContactSegment::instance(ContactSegment::SENDER)->setPOSTAL_CODE(strPostalCodeZip);
   ContactSegment::instance(ContactSegment::SENDER)->setCONTACT_TYPE("ALL");
   ContactSegment::instance(ContactSegment::SENDER)->setUPDATED_BY_USER_ID("SYSTEM");
   ContactSegment::instance(ContactSegment::SENDER)->setTSTAMP_UPDATED(Clock::instance()->getYYYYMMDDHHMMSSHN());
   if (Extract::instance()->getCustomCode() != "MPS")
      ContactSegment::instance(ContactSegment::SENDER)->setPresence(true);
   if (Extract::instance()->getCustomCode(1) == "CVRN")
   {
      CRReportingLevelSegment::instance()->setNEXT_ID(strParentEntityId);
      CRReportingLevelSegment::instance()->setNEXT_CUST_ID(Customer::instance()->getCUST_ID());
      m_hMerchantMap.insert(map<string,pair<string,string>,less<string> >::value_type(strEntityId,make_pair(strEntityId,strParentEntityId)));
      CRReportingLevelSegment::instance()->setRPT_LVL_ID(strEntityId);
   }
   else if (strEntityLevel == "5")
   {
      CRReportingLevelSegment::instance()->setRPT_LVL_ID(strRPT_LVL_ID); // station id
      ContactSegment::instance(ContactSegment::SENDER)->setRPT_LVL_ID(strRPT_LVL_ID);
      if (strParentEntityId == "25") //Internet merchant
         processInternetMerchant(strRPT_LVL_ID,strEntityDBAName);
      pair<string,string> hStationDistrict(strRPT_LVL_ID,strDistrict);
      m_hMerchantMap.insert(map<string,pair<string,string>,less<string> >::value_type(strEntityId,hStationDistrict));
      m_hInstitutionMap.insert(map<string,int,less<string> >::value_type(strDistrict,1));
   }
   else
   {
      if (m_hAgents.find(strParentEntityId) != m_hAgents.end()
         || m_hChains.find(strParentEntityId) != m_hChains.end())
      {
         CRReportingLevelSegment::instance()->setNEXT_ID(strParentEntityId);
         CRReportingLevelSegment::instance()->setNEXT_CUST_ID(Customer::instance()->getCUST_ID());
         m_hMerchants.insert(map<string,string,less<string> >::value_type(strEntityId,strParentEntityId));
      }
      else
         m_hMerchantMap.insert(map<string,pair<string,string>,less<string> >::value_type(strEntityId,make_pair(strEntityId,strParentEntityId)));
      CRReportingLevelSegment::instance()->setRPT_LVL_ID(strEntityId.length() > 16 ? strEntityId.substr(0,16).c_str():strEntityId.c_str());
      ContactSegment::instance(ContactSegment::SENDER)->setRPT_LVL_ID(strEntityId.length() > 16 ? strEntityId.substr(0,16).c_str():strEntityId.c_str());
   }

   if (Extract::instance()->getCustomCode() == "COLES")
   {
      transform(strEntityId.begin(), strEntityId.end(), strEntityId.begin(), ::toupper);
      CRReportingLevelSegment::instance()->setRPT_LVL_ID(strEntityId);
      CRReportingLevelSegment::instance()->setFEE_BILL_INST_ID(strExternalEntityId); // Store Number
      ContactSegment::instance(ContactSegment::SENDER)->setORG_NAME(strOrgName);
      ContactSegment::instance(ContactSegment::SENDER)->setTELEPHONE_NO(strPhone1);
      ContactSegment::instance(ContactSegment::SENDER)->setADDRESS_LINE_3(strProvinceState);
      ContactSegment::instance(ContactSegment::SENDER)->setEMAIL_ADDRESS(strEmail);
      ContactSegment::instance(ContactSegment::SENDER)->setCONTACT_METHOD("E");
   }
   else if (Extract::instance()->getCustomCode() == "CBA")
   {
      CRReportingLevelSegment::instance()->setFEE_BILL_INST_ID(strExternalEntityId);
      ContactSegment::instance(ContactSegment::SENDER)->setORG_NAME(strOrgName);
      ContactSegment::instance(ContactSegment::SENDER)->setTELEPHONE_NO(strPhone1);
      ContactSegment::instance(ContactSegment::SENDER)->setADDRESS_LINE_3(strProvinceState);
      ContactSegment::instance(ContactSegment::SENDER)->setEMAIL_ADDRESS(strEmail);
      if (!strEmail.empty())
         ContactSegment::instance(ContactSegment::SENDER)->setCONTACT_METHOD("E");
      else if (!strPostalCodeZip.empty())
         ContactSegment::instance(ContactSegment::SENDER)->setCONTACT_METHOD("N");
   }
  //## end OasisEntityFile::copyMerchant%4283461C00A2.body
}

void OasisEntityFile::copyMerchantDetail ()
{
  //## begin OasisEntityFile::copyMerchantDetail%640EF506039D.body preserve=yes
   UseCase hUseCase("IST","## OC02 REPORTING_LVL_BUS");
   m_pFileSegment = CRReportingLevelBusSegment::instance();
   CRReportingLevelBusSegment::instance()->reset();
   CRReportingLevelBusSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   const char* pszCursor = m_psBuffer;
   string strEntityCategory(extract(&pszCursor));
   string strEntityLevel(extract(&pszCursor));
   string strRPT_LVL_ID(extract(&pszCursor));
   CRReportingLevelBusSegment::instance()->setRPT_LVL_ID(strRPT_LVL_ID);
   extract(&pszCursor);
   extract(&pszCursor);
   if (strEntityLevel == "50")
   {
      string strBusType(extract(&pszCursor));
      vector<string> hTokens(8,"");
      Buffer::parse(strBusType.data(),",",hTokens);
      for (int i = 0; i < 8; i++) {
         CRReportingLevelBusSegment::instance()->setBUS_TYPEn(hTokens[i],i);
      }
      CRReportingLevelBusSegment::instance()->setBUS_UNIT(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setREL_LOC_VALUE(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setDIVISION_NO(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setLOCATION_CODE(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setOXY_FUEL_FLG(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setSHIP_TO_CUST(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setSHIP_TO_NAME2(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setLEGAL_STATUS(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setATTR_6_CO_BRAND(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setPROFIT_CENTER(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setSTATION_PLANT(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setCOMPANY_CODE(extract(&pszCursor));
      extract(&pszCursor);
      CRReportingLevelBusSegment::instance()->setPAYEE_NUM_PREV(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setOPER_EFF_DT_PREV(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setLOCATION_STATUS(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setBUS_LOC_TYPE(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setTAX_ID(extract(&pszCursor));
      CRReportingLevelBusSegment::instance()->setTAX_ID_TYPE(extract(&pszCursor));
   }
   else if (strEntityLevel == "40")
   {
      CRReportingLevelBusSegment::instance()->setMASTER_ZLINK_NO(extract(&pszCursor,35));
      CRReportingLevelBusSegment::instance()->setMASTER_CRA_IND(extract(&pszCursor));
   }
   else if (strEntityLevel == "90")
   {
      CRReportingLevelBusSegment::instance()->setDATE_START(extract(&pszCursor, 8));
      CRReportingLevelBusSegment::instance()->setDATE_END(extract(&pszCursor, 8));
      CRReportingLevelBusSegment::instance()->setALLOWANCE_ID(extract(&pszCursor, 12));
      CRReportingLevelBusSegment::instance()->setPSP_PFC_ID(extract(&pszCursor, 20));
      CRReportingLevelBusSegment::instance()->setECOM_MERCH_FLG(extract(&pszCursor, 1));
      string strSETTLEMENT_TIME(extract(&pszCursor, 8));
      strSETTLEMENT_TIME.resize(8, '0');
      CRReportingLevelBusSegment::instance()->setSETTLEMENT_TIME(strSETTLEMENT_TIME);
   }
  //## end OasisEntityFile::copyMerchantDetail%640EF506039D.body
}

void OasisEntityFile::copyProcessor ()
{
  //## begin OasisEntityFile::copyProcessor%4283460A0361.body preserve=yes
   UseCase hUseCase("IST","## IS05 PROCESSOR ");
   m_pFileSegment = CRProcessorSegment::instance();
   CRProcessorSegment::instance()->reset();
   CRProcessorSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   const char* pszCursor = m_psBuffer;
   extract(&pszCursor).c_str(); // EntityCategory
   extract(&pszCursor).c_str(); // EntityLevel
   extract(&pszCursor).c_str(); // EntityType
   string strEntityDescription = extract(&pszCursor); // EntityDescription
   string strPROC_ID(extract(&pszCursor,8));
   CRProcessorSegment::instance()->setPROC_ID(strPROC_ID.c_str());
   CRProcessorSegment::instance()->setPROC_NAME(extract(&pszCursor,35).c_str());
   extract(&pszCursor).c_str(); // InstitutionFiscalYearEnd
   extract(&pszCursor).c_str(); // LanguageCode
   extract(&pszCursor).c_str(); // SecondaryLanguageCode
   extract(&pszCursor).c_str(); // ISOCurrencyCode
   string strCUTOFF_TIME(extract(&pszCursor,8));
   strCUTOFF_TIME.resize(8,'0');
   CRProcessorSegment::instance()->setCUTOFF_TIME(strCUTOFF_TIME);
   string strAddress1(extract(&pszCursor,60).c_str()); // Address1
   string strAddress2(extract(&pszCursor,60).c_str()); // Address2
   string strCity(extract(&pszCursor,60).c_str()); // City
   extract(&pszCursor).c_str(); // ProvStateCode
   extract(&pszCursor).c_str(); // ProvStateNumberCode
   string strProvinceState(extract(&pszCursor,60).c_str()); // ProvinceState
   extract(&pszCursor).c_str(); // CountyCode
   string strOrgName(extract(&pszCursor,60).c_str()); // OrgName
   string strPostalCodeZip(extract(&pszCursor,10).c_str()); // PostalCodeZip
   string strCountry(extract(&pszCursor,3).c_str()); // CountryCode
   extract(&pszCursor).c_str(); // Country
   string strPhone1(extract(&pszCursor,20).c_str()); // Phone1
   extract(&pszCursor).c_str(); // Phone2
   extract(&pszCursor).c_str(); // Fax
   string strEmail(extract(&pszCursor,60).c_str()); // Email
   extract(&pszCursor).c_str(); // URL
   extract(&pszCursor).c_str(); // ModifiedDate
   string strPROC_GRP_ID(extract(&pszCursor,8)); //Processor Group ID
   if (strPROC_GRP_ID.length() > 0)
      CRProcessorSegment::instance()->setPROC_GRP_ID(strPROC_GRP_ID.c_str());
   else
      CRProcessorSegment::instance()->setPROC_GRP_ID(Customer::instance()->getCUST_ID());
   if (strEntityDescription == "CUSTOMER")
      m_strPROC_ID.assign(strPROC_ID.c_str(),strPROC_ID.length());
   else
   if (strEntityDescription == "CR PROC")
      m_strCreditPROC_ID.assign(strPROC_ID.c_str(),strPROC_ID.length());
   else
   if (strEntityDescription == "DB PROC")
      m_strDebitPROC_ID.assign(strPROC_ID.c_str(),strPROC_ID.length());

   if (Extract::instance()->getCustomCode() == "COLES")
   {
      transform(strPROC_ID.begin(), strPROC_ID.end(), strPROC_ID.begin(), ::toupper);
      transform(strPROC_GRP_ID.begin(), strPROC_GRP_ID.end(), strPROC_GRP_ID.begin(), ::toupper);
      CRProcessorSegment::instance()->setPROC_ID(strPROC_ID);
      CRProcessorSegment::instance()->setPROC_GRP_ID(strPROC_GRP_ID);
      ContactSegment::instance(ContactSegment::SENDER)->setPROC_ID(CRProcessorSegment::instance()->getPROC_ID());
      ContactSegment::instance(ContactSegment::SENDER)->setCONTACT_TYPE("ALL");
      ContactSegment::instance(ContactSegment::SENDER)->setNAME(CRProcessorSegment::instance()->getPROC_NAME());
      ContactSegment::instance(ContactSegment::SENDER)->setORG_NAME(strOrgName);
      ContactSegment::instance(ContactSegment::SENDER)->setTELEPHONE_NO(strPhone1);
      ContactSegment::instance(ContactSegment::SENDER)->setCITY(strCity);
      ContactSegment::instance(ContactSegment::SENDER)->setPOSTAL_CODE(strPostalCodeZip);
      ContactSegment::instance(ContactSegment::SENDER)->setCOUNTRY(strCountry);
      ContactSegment::instance(ContactSegment::SENDER)->setUPDATED_BY_USER_ID("SYSTEM");
      ContactSegment::instance(ContactSegment::SENDER)->setTSTAMP_UPDATED(Clock::instance()->getYYYYMMDDHHMMSSHN());
      ContactSegment::instance(ContactSegment::SENDER)->setADDRESS_LINE_1(strAddress1);
      ContactSegment::instance(ContactSegment::SENDER)->setADDRESS_LINE_2(strAddress2);
      ContactSegment::instance(ContactSegment::SENDER)->setADDRESS_LINE_3(strProvinceState);
      ContactSegment::instance(ContactSegment::SENDER)->setEMAIL_ADDRESS(strEmail);
      ContactSegment::instance(ContactSegment::SENDER)->setCONTACT_METHOD("E");
      ContactSegment::instance(ContactSegment::SENDER)->setPresence(true);
   }
  //## end OasisEntityFile::copyProcessor%4283460A0361.body
}

void OasisEntityFile::copyProcessorGroup ()
{
  //## begin OasisEntityFile::copyProcessorGroup%42898AFB01FF.body preserve=yes
   UseCase hUseCase("IST","## IS06 PROC GROUP");
   m_pFileSegment = CRProcessorGroupSegment::instance();
   CRProcessorGroupSegment::instance()->reset();
   CRProcessorGroupSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   const char* pszCursor = m_psBuffer;
   extract(&pszCursor).c_str(); // EntityCategory
   extract(&pszCursor).c_str(); // EntityLevel
   extract(&pszCursor).c_str(); // EntityType
   extract(&pszCursor).c_str(); // EntityDescription
   CRProcessorGroupSegment::instance()->setPROC_GRP_ID(extract(&pszCursor,8).c_str()); // EntityId
   CRProcessorGroupSegment::instance()->setPROC_GRP_NAME(extract(&pszCursor,35).c_str()); // InstitutionName
  //## end OasisEntityFile::copyProcessorGroup%42898AFB01FF.body
}

void OasisEntityFile::copyTerminal ()
{
  //## begin OasisEntityFile::copyTerminal%428346410334.body preserve=yes
   UseCase hUseCase("IST","## IS07 TERMINAL");
   m_pFileSegment = CRDeviceSegment::instance();
   CRDeviceSegment::instance()->reset();
   CRDeviceSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   const char* pszCursor = m_psBuffer;
   extract(&pszCursor).c_str(); // EntityCategory
   extract(&pszCursor).c_str(); // TerminalGroupId
   string strDEVICE_ID(extract(&pszCursor,32));
   if (strDEVICE_ID.length() > 8)
      strDEVICE_ID.erase(0,strDEVICE_ID.length() - 8);
   CRDeviceSegment::instance()->setDEVICE_ID(strDEVICE_ID.c_str()); // TerminalId
   string strINST_ID(extract(&pszCursor,11).c_str()); //InstitutionId
   CRDeviceSegment::instance()->setINST_ID(strINST_ID.c_str());
   if (Extract::instance()->getCustomCode() == "PAAS")
      transform(strINST_ID.begin(), strINST_ID.end(), strINST_ID.begin(), ::toupper);

   extract(&pszCursor).c_str(); // BarAccess
   extract(&pszCursor).c_str(); // ActualStartDate
   extract(&pszCursor).c_str(); // TerminationDate
   extract(&pszCursor).c_str(); // TerminalIdNumber
   string strParentEntityId(extract(&pszCursor)); // ParentEntityId
   strParentEntityId.resize(16,' ');
   extract(&pszCursor).c_str(); // DefaultCurrencyCode
   extract(&pszCursor).c_str(); // CPSEligible
   extract(&pszCursor).c_str(); // DefaultMCC
   extract(&pszCursor).c_str(); // CaptureType
   extract(&pszCursor).c_str(); // pos_fcutover_time
   // CRDeviceSegment::instance()->setCUTOFF_TIME(extract(&pszCursor,8).c_str()); // pos_fcutover_time
   CRDeviceSegment::instance()->setADDRESS(extract(&pszCursor,28).c_str()); // Address1
   extract(&pszCursor).c_str(); // Address2
   CRDeviceSegment::instance()->setCITY(extract(&pszCursor,27).c_str()); // City
   CRDeviceSegment::instance()->setREGION(extract(&pszCursor,3).c_str()); // ProvStateCode
   extract(&pszCursor).c_str(); // ProvStateNumberCode
   extract(&pszCursor).c_str(); // ProvinceState
   string strCOUNTY(extract(&pszCursor,3));
   CRDeviceSegment::instance()->setCOUNTY(strCOUNTY.c_str()); // CountyCode
   extract(&pszCursor).c_str(); // County
   CRDeviceSegment::instance()->setPOSTAL_CODE(extract(&pszCursor,10).c_str()); // PostalCodeZip
   CRDeviceSegment::instance()->setCOUNTRY(extract(&pszCursor,3).c_str()); // CountryCode
   //extract(&pszCursor).c_str(); // Country
   //extract(&pszCursor).c_str(); // Phone1
   //extract(&pszCursor).c_str(); // Phone2
   //extract(&pszCursor).c_str(); // Fax
   //extract(&pszCursor).c_str(); // Email
   //extract(&pszCursor).c_str(); // URL
   //extract(&pszCursor).c_str(); // Modified Date
   map<string,pair<string,string>,less<string> >::iterator p;
   p = m_hMerchantMap.find(strParentEntityId);
   if (p != m_hMerchantMap.end())
   {
      CRDeviceSegment::instance()->setRPT_LVL_ID((*p).second.first.c_str()); //stationid
      CRDeviceSegment::instance()->setINST_ID((*p).second.second.c_str()); // InstitutionId
   }
   else
   {
      if (!m_hChains.empty())
      {
         map<string,string,less<string> >::iterator p = m_hMerchants.find(strParentEntityId);
         if (p != m_hMerchants.end())
         {
            map<string,string,less<string> >::iterator q = m_hChains.find((*p).second);
            if (q != m_hChains.end())
            {
               map<string,string,less<string> >::iterator r = m_hAgents.find((*q).second);
               if (r != m_hAgents.end())
                  CRDeviceSegment::instance()->setINST_ID((*r).second);
            }
         }
      }
      else
         CRDeviceSegment::instance()->setINST_ID(strINST_ID.c_str());
      CRDeviceSegment::instance()->setRPT_LVL_ID(strParentEntityId); //stationid
   }

    if (Extract::instance()->getCustomCode() == "COLES")
    {
       transform(strDEVICE_ID.begin(), strDEVICE_ID.end(), strDEVICE_ID.begin(), ::toupper);
       transform(strINST_ID.begin(), strINST_ID.end(), strINST_ID.begin(), ::toupper);
       transform(strParentEntityId.begin(), strParentEntityId.end(), strParentEntityId.begin(), ::toupper);
       CRDeviceSegment::instance()->setDEVICE_ID(strDEVICE_ID.c_str());
       CRDeviceSegment::instance()->setINST_ID(strINST_ID.c_str());
       CRDeviceSegment::instance()->setRPT_LVL_ID(strParentEntityId.c_str());
    }
    if (Extract::instance()->getCustomCode() == "CBA")
       CRDeviceSegment::instance()->setCUSTOM_DATA(extract(&pszCursor, 2).c_str());
  //## end OasisEntityFile::copyTerminal%428346410334.body
}

string OasisEntityFile::extract (const char** ppszCursor, int iLength)
{
  //## begin OasisEntityFile::extract%428A09030043.body preserve=yes
   const char* pszCursor = *ppszCursor;
   const char* p;
   if (*pszCursor == '"')
   {
      ++pszCursor;
      p = strchr(pszCursor,'"');
      if (!p)
         p = pszCursor;
      else
         *ppszCursor = p + 2;
   }
   else
   {
#ifdef MVS
      p = strchr(pszCursor,0x6A);
      if (!p)
#endif
         p = strchr(pszCursor,'|');
      if (!p)
      {
         p = pszCursor;
         string strTemp(pszCursor);
         *ppszCursor = p + strTemp.length();
         return strTemp;
      }
      else
         *ppszCursor = p + 1;
   }
   if (iLength == 0)
      return string(pszCursor,p - pszCursor);
   return string(pszCursor,min((int)(p - pszCursor),iLength));
  //## end OasisEntityFile::extract%428A09030043.body
}

string OasisEntityFile::getNextTERM_CLASS ()
{
  //## begin OasisEntityFile::getNextTERM_CLASS%4583233A020C.body preserve=yes
   Query hQuery;
   string strTERM_CLASS;
   short iNull;
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   hQuery.setQualifier("QUALIFY","X_IST_TERM_TYPE");
   hQuery.setBasicPredicate("X_IST_TERM_TYPE","X_TYPE","=","2");
   hQuery.bind("X_IST_TERM_TYPE","TERM_CLASS",Column::STRING,&strTERM_CLASS,&iNull,"MAX");
   pSelectStatement->execute(hQuery);
   if (strTERM_CLASS == "")
      return string("A0");
   char buffer[2];
   memcpy(buffer,strTERM_CLASS.data(),2);
   if (buffer[1] == '9')
   {
      buffer[1] = '0';
      //handle breaks in EBCDIC sequence
      if (buffer[0] == 'I')
         buffer[0] = 'J';
      else if (buffer[0] == 'R')
         buffer[0] = 'S';
      else if (buffer[0] == 'Z')
      {
         buffer[1] = '9';  //Z9 out of values to assign (max 260 values)
      }
      else
         buffer[0] += 1;
   }
   else
      buffer[1] += 1;
   strTERM_CLASS.assign(buffer,2);
   return strTERM_CLASS;
  //## end OasisEntityFile::getNextTERM_CLASS%4583233A020C.body
}

void OasisEntityFile::process ()
{
  //## begin OasisEntityFile::process%45D5FC090346.body preserve=yes
   m_bHeaderValidated = false;
   m_bReadInstitutionMap = false;
   m_hInstitutionMap.erase(m_hInstitutionMap.begin(),m_hInstitutionMap.end());
   m_hMerchantMap.erase(m_hMerchantMap.begin(),m_hMerchantMap.end());
   m_hAgents.erase(m_hAgents.begin(),m_hAgents.end());
   m_hChains.erase(m_hChains.begin(),m_hChains.end());
   CRFile::process();
   if (Extract::instance()->getCustomCode() == "BBL" &&
      Clock::instance()->getMinute() != 0)
      return;
   Query hQuery;
   short iNull = 0;
   hQuery.setQualifier("QUALIFY","DEVICE");
   hQuery.bind("DEVICE","DEVICE_ID",Column::STRING,&m_strDEVICE_ID,&iNull,"MAX");
   hQuery.setBasicPredicate("DEVICE","DEVICE_ID","LIKE","Z%");
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   if (!pSelectStatement->execute(hQuery))
      return;
   if (iNull == -1)
      m_strDEVICE_ID.assign("Z0000000");
   m_iInsertCount = 0;
   m_hQuery.attach(this);
   m_hQuery.reset();
   if (Extract::instance()->getCustomCode() == "MPS")
   {
      if (m_hAgents.empty())
         return;
      Query hQuery;
      hQuery.setQualifier("QUALIFY","DEVICE");
      hQuery.setSubSelect(true);
      hQuery.setDistinct(true);
      hQuery.bind("DEVICE","RPT_LVL_ID",Column::STRING,0);
      auto_ptr<FormatSelectVisitor> pFormatSelectVisitor((FormatSelectVisitor*)DatabaseFactory::instance()->create("FormatSelectVisitor"));
      hQuery.accept(*pFormatSelectVisitor);
      string strTemp = "(" + pFormatSelectVisitor->SQLText() + ")";
      m_hQuery.setQualifier("QUALIFY","REPORTING_LVL");
      m_hQuery.bind("REPORTING_LVL","RPT_LVL_ID",Column::STRING,&m_strRPT_LVL_ID);
      m_hQuery.setBasicPredicate("REPORTING_LVL","RPT_LVL_ID","NOT IN",strTemp.c_str());
      m_hQuery.setIndex(2);
   }
   else
   {
      m_hQuery.setIndex(1);
      m_hQuery.setQualifier("QUALIFY","INSTITUTION");
      m_hQuery.setQualifier("QUALIFY","DEVICE");
      m_hQuery.setRetainCursor(true);
      m_hQuery.join("INSTITUTION","LEFT OUTER","DEVICE","CUST_ID");
      m_hQuery.join("INSTITUTION","LEFT OUTER","DEVICE","CUST_STAT");
      m_hQuery.join("INSTITUTION","LEFT OUTER","DEVICE","INST_ID");
      m_hQuery.join("INSTITUTION","LEFT OUTER","DEVICE","INST_STAT");
      m_hQuery.bind("INSTITUTION","INST_ID",Column::STRING,&m_strINST_ID);
      m_hQuery.setBasicPredicate("INSTITUTION","CC_CHANGE_GRP_ID","IS NULL");
      m_hQuery.setBasicPredicate("INSTITUTION","CC_STATE","=","A");
      m_hQuery.setBasicPredicate("DEVICE","DEVICE_ID","IS NULL");
   }
   if (!pSelectStatement->execute(m_hQuery) || m_hQuery.getAbort() == true)
      Database::instance()->rollback();
   else
      Database::instance()->commit();
  //## end OasisEntityFile::process%45D5FC090346.body
}

void OasisEntityFile::processInternetMerchant (const string& strEntityId, const string& strEntityDBAName)
{
  //## begin OasisEntityFile::processInternetMerchant%458322BE01D2.body preserve=yes
   Query hQuery;
   hQuery.reset();
   m_strTERM_CLASS_DESC.empty();
   hQuery.setQualifier("QUALIFY","X_IST_TERM_TYPE");
   hQuery.bind("X_IST_TERM_TYPE","TERM_CLASS_DESC",Column::STRING,&m_strTERM_CLASS_DESC);
   hQuery.setBasicPredicate("X_IST_TERM_TYPE","IST_TERM_TYPE","=",strEntityId.c_str());
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   pSelectStatement->execute(hQuery);
   if (pSelectStatement->getRows() && strEntityDBAName != m_strTERM_CLASS_DESC)
   {
      reusable::Table hTable("X_IST_TERM_TYPE");
      hTable.setQualifier("QUALIFY");
      hTable.set("TERM_CLASS_DESC",strEntityDBAName,false,false);
      hTable.set("CC_LAST_OPERATION","UPD",false,false);
      hTable.set("CC_TSTAMP_CHANGE",Clock::instance()->getYYYYMMDDHHMMSS(),false,false);
      hTable.set("CC_STATE","A",false,false);
      hTable.set("IST_TERM_TYPE",strEntityId,false,true);
      auto_ptr<reusable::Statement> pUpdateStatement((reusable::Statement*)database::DatabaseFactory::instance()->create("UpdateStatement"));
      pUpdateStatement->execute(hTable);
      return;
   }
   if (pSelectStatement->getRows() == 0)
   {
      string strTERM_CLASS;
      strTERM_CLASS = getNextTERM_CLASS();
      auto_ptr<Statement> pInsertStatement((Statement*)DatabaseFactory::instance()->create("InsertStatement"));
      Table hTable("X_IST_TERM_TYPE");
      hTable.setQualifier("QUALIFY");
      hTable.set("IST_TERM_TYPE",strEntityId);
      hTable.set("TERM_CLASS_DESC",strEntityDBAName);
      hTable.set("X_TYPE","2");
      hTable.set("TERM_CLASS",strTERM_CLASS);
      hTable.set("CC_LAST_OPERATION","INS");
      hTable.set("CC_TSTAMP_CHANGE",Clock::instance()->getYYYYMMDDHHMMSS());
      hTable.set("CC_STATE","A");
      hTable.set("CC_USER_ID",Application::instance()->name());
      hTable.set("X_STAT","");
      pInsertStatement->execute(hTable);
   }
  //## end OasisEntityFile::processInternetMerchant%458322BE01D2.body
}

bool OasisEntityFile::read ()
{
  //## begin OasisEntityFile::read%4281E9360057.body preserve=yes
   if (m_bReadInstitutionMap)
   {
      map<string,int, less<string> >::iterator p;
      p = m_hInstitutionMap.begin();
      if (p != m_hInstitutionMap.end())
      {
         UseCase hUseCase("IST","## IS03 INSTITUTION ");
         m_pFileSegment = CRInstitutionSegment::instance();
         CRInstitutionSegment::instance()->reset();
         CRInstitutionSegment::instance()->setINST_ID((*p).first);
         CRInstitutionSegment::instance()->setPROC_ID(m_strPROC_ID);
         m_pFileSegment->setPresence(true);
         m_hInstitutionMap.erase(m_hInstitutionMap.begin());
         return true;
      }
      else
      {
         m_bReadInstitutionMap = false;
         copyTerminal();
         m_pFileSegment->setPresence(true);
         return true;
      }
   }
   size_t lRecordLength = 0;
   if (!m_pGenerationDataGroup)
   {
      m_pGenerationDataGroup = new GenerationDataGroup(Application::instance()->image(),
                                                       Application::instance()->name(),
                                                       getName().c_str());
      if (!m_pGenerationDataGroup->open())
         return false;
   }
   if (m_pFileSegment)
      m_pFileSegment->setPresence(false);
   m_pFileSegment = 0;
   if (!m_bHeaderValidated)
   {
      if (!m_pGenerationDataGroup->read(m_psBuffer,4096,&lRecordLength))
         return false;
      if ((m_bHeaderValidated = validateFileHeader()) != true)
      {
         m_pGenerationDataGroup->commit();
         if (Extract::instance()->getCustomCode() == "COLES")
         {
            string strBaseName;
            char szTemp[254];
            m_pGenerationDataGroup->getFlatFile()->getBaseName(strBaseName, true);
            snprintf(szTemp, sizeof(szTemp), "%s - File Rejected! There is no HEADER Record", strBaseName.c_str());
            Console::display("CL001", szTemp);
         }
         Database::instance()->commit();
         return false;
      }
   }
   while (m_pFileSegment == 0)
   {
      lRecordLength = 0;
      if (!m_pGenerationDataGroup->read(m_psBuffer,4096,&lRecordLength))
      {
         if (!m_bRecordsFound)
         {
            m_pGenerationDataGroup->commit();
            Database::instance()->commit();
         }
         return false;
      }
      const char* pszCursor = m_psBuffer;
      size_t n = string::npos;
      string strEntityCategory(extract(&pszCursor));
      string strEntityLevel(extract(&pszCursor)); //EntityLevel
      string strEntityType(extract(&pszCursor));
      if (strEntityCategory == "MERCHANT" || strEntityCategory == "TERMINAL")
         n = strEntityType.find_first_not_of(' '); //For Merchant and Terminal 3rd field is EntityId in CED file
      string strEntityDescription(extract(&pszCursor));
      string strEntityId(extract(&pszCursor));
      extract(&pszCursor).c_str(); // EntityDBAName
      extract(&pszCursor).c_str(); // EntityABANumber
      extract(&pszCursor).c_str(); // EntityStatus
      string strParentEntityId(extract(&pszCursor, 16).c_str()); // ParentEntityId 
      string strExternalEntityId(extract(&pszCursor, 16).c_str()); // ExternalEntityId
      bool bMandatoryFieldsExist = true;
      if(Extract::instance()->getCustomCode() == "CBA" && strEntityCategory == "MERCHANT" && strExternalEntityId.empty())
         bMandatoryFieldsExist = false;
      if ((Extract::instance()->getCustomCode() == "COLES" || Extract::instance()->getCustomCode() == "CBA") && 
         (((strEntityCategory == "MERCHANT" || strEntityCategory == "TERMINAL") && (n == string::npos || !bMandatoryFieldsExist))
            || (strEntityCategory == "INSTITUTION" && (n = strEntityId.find_first_not_of(' ')) == string::npos)))
      {
         char szTemp[PERCENTF];
         string strEntityType = (strEntityDescription == "DB PROC") ? "PROCESSOR" : strEntityCategory;
         Trace::put(szTemp, snprintf(szTemp, sizeof(szTemp), "Warning! Record skipped since there is no Primary key or Mandatory field found [%s]", m_psBuffer), true);
         snprintf(szTemp, sizeof(szTemp), " %s record skipped, no primary key or Mandatory field found", strEntityType.c_str());
         Console::display("CL001", szTemp);
         m_iSkipCount++;
         continue;
      }
      ContactSegment::instance(ContactSegment::SENDER)->reset();
      if (strEntityCategory == "INSTITUTION")
      {
         if (Extract::instance()->getCustomCode() == "MPS")
         {
            if (strEntityDescription == "MEMBER/ACQUIRER"
               || strEntityDescription == "MEMBER")
               copyProcessorGroup();
            else
            if (strEntityDescription == "CARD_ASSC"
               || strEntityDescription == "PRINCIPAL"
               || strEntityDescription == "MEMBER/ISSUER")
               copyInstitution();
         }
         else
         {
            n = strEntityId.find_first_not_of(' ');
            if (n != string::npos)
            {
               if (strEntityDescription == "CUSTOMER"
                  || strEntityDescription == "CR PROC"
                  || strEntityDescription == "DB PROC"
                  || strEntityDescription == "CARD_ASSC")
                  copyProcessor();
               else
               if (strEntityDescription == "MAIN_INST")
                  copyInstitution();
               else
               if (strEntityType == "INSTITUTION")
                  copyInstitution();
            }
         }
      }
      else
      if (strEntityCategory == "ENTITY")
      {
         if (Extract::instance()->getCustomCode() == "MPS")
         {
            if (strEntityDescription == "ACQ_BUS_UNIT"
               || strEntityDescription == "PRINCIPAL"
               || strEntityDescription == "AGENT"
               || strEntityDescription == "CHAIN"
               || strEntityDescription == "PORTFOLIO")
               copyEntity();
            else
            if (strEntityDescription == "MAIN_INST")
               copyInstitution();
         }
      }
      else
      if (strEntityCategory == "MERCHANT" && n != string::npos)
      {
         if (strEntityLevel == "81" && Extract::instance()->getCustomCode() == "CBA")
            copyReportingLevelCase();
         else
            copyMerchant();
      }
      else
      if (strEntityCategory == "USER_DEFINED")
      {
         copyMerchantDetail();
      }
      else
      if (strEntityCategory == "TERMINAL" && n != string::npos)
      {
         if (m_hInstitutionMap.size() > 0)
         {
            m_bReadInstitutionMap= true;
            read();
         }
         else
            copyTerminal();
      }
      else
      if (strEntityCategory == "ATM Group")
         copyATMGroup();
      else
      if (strEntityCategory == "ATM Terminal")
         copyATM();
   }
   m_bRecordsFound = true;
   m_pFileSegment->setPresence(true);
   return true;
  //## end OasisEntityFile::read%4281E9360057.body
}

void OasisEntityFile::update (Subject* pSubject)
{
  //## begin OasisEntityFile::update%45D21FC000C5.body preserve=yes
   if (pSubject != &m_hQuery)
      return CRFile::update(pSubject);
   if (m_hQuery.getIndex() == 1)
   {
      if (m_strINST_ID.empty())
         return;
      int iDEVICE_ID = atoi(m_strDEVICE_ID.substr(1).c_str());
      char szTemp[PERCENTD+2] = {"        "};
      m_strDEVICE_ID.assign(szTemp, snprintf(szTemp, sizeof(szTemp), "Z%07d", ++iDEVICE_ID));
      //insert psuedo REPORTING_LVL and psuedo DEVICE
      UseCase hUseCase("IST","## IS04 REPORTING LEVEL");
      CRDeviceSegment::instance()->reset();
      CRReportingLevelSegment::instance()->reset();
      CRReportingLevelSegment::instance()->setPresence(true);
      CRReportingLevelSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
      string strRPT_LVL_ID(m_strDEVICE_ID);
      strRPT_LVL_ID.insert(1,"00");
      CRReportingLevelSegment::instance()->setRPT_LVL_ID(strRPT_LVL_ID.c_str());
      if (!CRUpdateCommand::instance()->execute(true))
      {
         CRReportingLevelSegment::instance()->setPresence(false);
         m_hQuery.setAbort(true);
         hUseCase.setSuccess(false);
         return;
      }
      CRReportingLevelSegment::instance()->setPresence(false);
      UseCase hUseCase2("IST","## IS07 TERMINAL");
      CRReportingLevelSegment::instance()->reset();
      CRDeviceSegment::instance()->reset();
      CRDeviceSegment::instance()->setPresence(true);
      CRDeviceSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
      CRDeviceSegment::instance()->setDEVICE_ID(m_strDEVICE_ID.c_str());
      CRDeviceSegment::instance()->setINST_ID(m_strINST_ID.c_str());
      CRDeviceSegment::instance()->setRPT_LVL_ID(strRPT_LVL_ID.c_str());
      CRDeviceSegment::instance()->setPSEUDO_TERM_FLG("Y");
      if (!CRUpdateCommand::instance()->execute(true))
      {
         CRDeviceSegment::instance()->setPresence(false);
         m_hQuery.setAbort(true);
         hUseCase2.setSuccess(false);
         return;
      }
      CRDeviceSegment::instance()->setPresence(false);
   }
   else
   {
      if (m_hAgents.find(m_strRPT_LVL_ID) == m_hAgents.end()
         && m_hChains.find(m_strRPT_LVL_ID) == m_hChains.end())
      {
         Trace::put(m_strRPT_LVL_ID.c_str());
         UseCase hUseCase2("IST","## IS07 TERMINAL");
         CRDeviceSegment::instance()->reset();
         CRDeviceSegment::instance()->setPresence(true);
         CRDeviceSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
         CRDeviceSegment::instance()->setDEVICE_ID(m_strDEVICE_ID.c_str());
         CRDeviceSegment::instance()->setRPT_LVL_ID(m_strRPT_LVL_ID.c_str());
         CRDeviceSegment::instance()->setPSEUDO_TERM_FLG("Y");
         map<string,pair<string,string>,less<string> >::iterator p = m_hMerchantMap.find(m_strRPT_LVL_ID);
         if (p != m_hMerchantMap.end())
            CRDeviceSegment::instance()->setINST_ID((*p).second.second.c_str());
         else
         {
            if (!m_hChains.empty())
            {
               map<string, string, less<string> >::iterator p = m_hMerchants.find(m_strRPT_LVL_ID);
               if (p != m_hMerchants.end())
               {
                  map<string,string,less<string> >::iterator q = m_hChains.find((*p).second);
                  if (q != m_hChains.end())
                  {
                     map<string,string,less<string> >::iterator r = m_hAgents.find((*q).second);
                     CRDeviceSegment::instance()->setINST_ID((*r).second);
                  }
                  else
                     return;
               }
               else
                  return;
            }
            else
               return;
         }
         int i = atoi(m_strDEVICE_ID.substr(1).c_str());
         char szTemp[PERCENTD + 2] = {"        "};
         m_strDEVICE_ID.assign(szTemp, snprintf(szTemp, sizeof(szTemp), "Z%07d", ++i));
         CRDeviceSegment::instance()->setDEVICE_ID(m_strDEVICE_ID.c_str());
         if (!CRUpdateCommand::instance()->execute(true))
         {
            CRDeviceSegment::instance()->setPresence(false);
            m_hQuery.setAbort(true);
            hUseCase2.setSuccess(false);
            return;
         }
         CRDeviceSegment::instance()->setPresence(false);
         return;
      }
   }
   if (++m_iInsertCount % 100 == 0)
      Database::instance()->commit();
  //## end OasisEntityFile::update%45D21FC000C5.body
}

bool OasisEntityFile::validateFileHeader ()
{
  //## begin OasisEntityFile::validateFileHeader%4296EEAA0045.body preserve=yes
   const char* pszCursor = m_psBuffer;
   string strToken(extract(&pszCursor)); // RecordType
   if (!memcmp(strToken.c_str(),"HEADER",6) == 0)
      return false;
   extract(&pszCursor).c_str(); // FileType
   extract(&pszCursor).c_str(); // Version
   extract(&pszCursor).c_str(); // ExtractType
   extract(&pszCursor).c_str(); // ExtractDate
   return true;
  //## end OasisEntityFile::validateFileHeader%4296EEAA0045.body
}

void OasisEntityFile::copyReportingLevelCase ()
{
  //## begin OasisEntityFile::copyReportingLevelCase%6501F2DB03AC.body preserve=yes
   UseCase hUseCase("IST", "## IS08 REPORTING LEVEL CASE");
   m_pFileSegment = CRReportingLevelCaseSegment::instance();
   CRReportingLevelCaseSegment::instance()->reset();
   CRReportingLevelCaseSegment::instance()->setCUST_ID(Customer::instance()->getCUST_ID());
   const char* pszCursor = m_psBuffer;
   extract(&pszCursor).c_str(); // EntityCategory
   extract(&pszCursor).c_str(); // EntityLevel
   CRReportingLevelCaseSegment::instance()->setRPT_LVL_ID(extract(&pszCursor)); // EntityId
   extract(&pszCursor).c_str(); // InstitutionId
   CRReportingLevelCaseSegment::instance()->setALT_CB_PROC(extract(&pszCursor));
   CRReportingLevelCaseSegment::instance()->setCREDIT_FLOOR_LIMIT(atof(extract(&pszCursor).c_str()));
   CRReportingLevelCaseSegment::instance()->setDEBIT_FLOOR_LIMIT(atof(extract(&pszCursor).c_str()));
   CRReportingLevelCaseSegment::instance()->setSAF_LIMIT(atof(extract(&pszCursor).c_str()));
   CRReportingLevelCaseSegment::instance()->setCHILD_RPT_SEL_FLAG(extract(&pszCursor));
   CRReportingLevelCaseSegment::instance()->setCOMPLIANCE_IND(extract(&pszCursor));
   CRReportingLevelCaseSegment::instance()->setPSB_IND(extract(&pszCursor));
  //## end OasisEntityFile::copyReportingLevelCase%6501F2DB03AC.body
}

// Additional Declarations
  //## begin OasisEntityFile%427B310F0090.declarations preserve=yes
  //## end OasisEntityFile%427B310F0090.declarations

//## begin module%424D82BC029F.epilog preserve=yes
//## end module%424D82BC029F.epilog
