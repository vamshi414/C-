//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%424D8149005D.cm preserve=no
//## end module%424D8149005D.cm

//## begin module%424D8149005D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%424D8149005D.cp

//## Module: CXOSOC02%424D8149005D; Package specification
//## Subsystem: OC%424D79890000
//## Source file: C:\Program Files (x86)\Rational\Application\Oc\CXODOC02.hpp

#ifndef CXOSOC02_h
#define CXOSOC02_h 1

//## begin module%424D8149005D.additionalIncludes preserve=no
//## end module%424D8149005D.additionalIncludes

//## begin module%424D8149005D.includes preserve=yes
#include <map>
//## end module%424D8149005D.includes

#ifndef CXOSNC19_h
#include "CXODNC19.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

namespace database {
class GenerationDataGroup;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
} // namespace timer

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class CodeTable;
class VariableBlockFile;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Buffer;
class Statement;
} // namespace reusable

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class ContactSegment;
class CRProcessorGroupSegment;
class CRDeviceSegment;
class CRInstitutionSegment;
class CRProcessorSegment;
class CRReportingLevelSegment;
class CRReportingLevelCaseSegment;
class CRReportingLevelBusSegment;
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::EntityCommand_CAT%394E2706012A
namespace entitycommand {
class CRUpdateCommand;

} // namespace entitycommand

//## begin module%424D8149005D.declarations preserve=no
//## end module%424D8149005D.declarations

//## begin module%424D8149005D.additionalDeclarations preserve=yes
//## end module%424D8149005D.additionalDeclarations


//## begin OasisEntityFile%427B310F0090.preface preserve=yes
//## end OasisEntityFile%427B310F0090.preface

//## Class: OasisEntityFile%427B310F0090
//	<body>
//	<title>CG
//	<h1>OC
//	<h2>FI
//	<!-- OasisEntityFile General -->
//	<h3>FIS IST Configuration
//	<p>
//	The FIS IST Configuration file must be transmitted from
//	your IST switch platform to the DataNavigator server.
//	The FIS IST Configuration Interface service reads the
//	file:
//	<ul>
//	<li><i>node001\custqual</i>\Pending\*CED.txt
//	</ul>
//	<p>
//	New files are automatically detected within one minute
//	of arrival in the Pending folder.
//	After processing the file, the FIS IST Configuration
//	Interface moves the file to the Complete folder:
//	<ul>
//	<li><i>node001\custqual</i>\Complete
//	</ul>
//	</body>
//## Category: Platform \: FIS IST::OasisEntityFileReader_CAT%424D780301F4
//## Subsystem: OC%424D79890000
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%42806AEB0112;entitysegment::CRDeviceSegment { -> F}
//## Uses: <unnamed>%42806B3D0087;entitysegment::CRInstitutionSegment { -> F}
//## Uses: <unnamed>%42806B7100E6;entitysegment::CRProcessorSegment { -> F}
//## Uses: <unnamed>%42806B9901D2;entitysegment::CRReportingLevelSegment { -> F}
//## Uses: <unnamed>%42806C7502D2;IF::CodeTable { -> F}
//## Uses: <unnamed>%42806C9801C9;IF::VariableBlockFile { -> F}
//## Uses: <unnamed>%42806CDA02D4;IF::Extract { -> F}
//## Uses: <unnamed>%4289A30D03DB;monitor::UseCase { -> F}
//## Uses: <unnamed>%428B12A6019F;entitysegment::Customer { -> F}
//## Uses: <unnamed>%429992BA0391;entitysegment::CRProcessorGroupSegment { -> F}
//## Uses: <unnamed>%42A2C0B00334;IF::Trace { -> F}
//## Uses: <unnamed>%4309A5540265;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%4309A647028A;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%45180A47007D;entitysegment::ContactSegment { -> F}
//## Uses: <unnamed>%45213462033C;timer::Clock { -> F}
//## Uses: <unnamed>%452B8B2203B7;reusable::Statement { -> F}
//## Uses: <unnamed>%452C80500157;process::Application { -> F}
//## Uses: <unnamed>%461F7430028A;database::GenerationDataGroup { -> F}
//## Uses: <unnamed>%570BA21503C9;entitycommand::CRUpdateCommand { -> F}
//## Uses: <unnamed>%570BA22C0017;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%640EF4670380;entitysegment::CRReportingLevelBusSegment { -> F}
//## Uses: <unnamed>%640EF4F0033D;reusable::Buffer { -> F}
//## Uses: <unnamed>%640EF89100F7;database::Database { -> F}
//## Uses: <unnamed>%6501F321033C;entitysegment::CRReportingLevelCaseSegment { -> F}

class DllExport OasisEntityFile : public entitycommand::CRFile  //## Inherits: <unnamed>%427B3222023B
{
  //## begin OasisEntityFile%427B310F0090.initialDeclarations preserve=yes
  //## end OasisEntityFile%427B310F0090.initialDeclarations

  public:
    //## Constructors (generated)
      OasisEntityFile();

    //## Destructor (generated)
      virtual ~OasisEntityFile();


    //## Other Operations (specified)
      //## Operation: copyATM%4E78187B010D
      virtual void copyATM ();

      //## Operation: copyATMGroup %4E7819220242
      virtual void copyATMGroup ();

      //## Operation: copyEntity%5706C668009D
      virtual void copyEntity ();

      //## Operation: copyInstitution%428345F80276
      virtual void copyInstitution ();

      //## Operation: copyMerchant%4283461C00A2
      virtual void copyMerchant ();

      //## Operation: copyMerchantDetail%640EF506039D
      void copyMerchantDetail ();

      //## Operation: copyProcessor%4283460A0361
      virtual void copyProcessor ();

      //## Operation: copyProcessorGroup%42898AFB01FF
      virtual void copyProcessorGroup ();

      //## Operation: copyTerminal%428346410334
      virtual void copyTerminal ();

      //## Operation: extract%428A09030043
      virtual reusable::string extract (const char** ppszCursor, int iLength = 0);

      //## Operation: process%45D5FC090346
      virtual void process ();

      //## Operation: read%4281E9360057
      virtual bool read ();

      //## Operation: update%45D21FC000C5
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

      //## Operation: validateFileHeader%4296EEAA0045
      virtual bool validateFileHeader ();

      //## Operation: copyReportingLevelCase%6501F2DB03AC
      void copyReportingLevelCase ();

    // Additional Public Declarations
      //## begin OasisEntityFile%427B310F0090.public preserve=yes
      //## end OasisEntityFile%427B310F0090.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: HeaderValidated%42B12D110147
      //## begin OasisEntityFile::HeaderValidated%42B12D110147.attr preserve=no  protected: bool {U} false
      bool m_bHeaderValidated;
      //## end OasisEntityFile::HeaderValidated%42B12D110147.attr

      //## Attribute: PROC_ID%45519DBA0160
      //## begin OasisEntityFile::PROC_ID%45519DBA0160.attr preserve=no  protected: string {U} 
      string m_strPROC_ID;
      //## end OasisEntityFile::PROC_ID%45519DBA0160.attr

    // Additional Protected Declarations
      //## begin OasisEntityFile%427B310F0090.protected preserve=yes
      //## end OasisEntityFile%427B310F0090.protected

  private:

    //## Other Operations (specified)
      //## Operation: getNextTERM_CLASS%4583233A020C
      reusable::string getNextTERM_CLASS ();

      //## Operation: processInternetMerchant%458322BE01D2
      void processInternetMerchant (const string& strEntityId, const string& strEntityDBAName);

    // Additional Private Declarations
      //## begin OasisEntityFile%427B310F0090.private preserve=yes
      //## end OasisEntityFile%427B310F0090.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Agents%570BA28000B6
      //## begin OasisEntityFile::Agents%570BA28000B6.attr preserve=no  private: map<string,string,less<string> > {V} 
      map<string,string,less<string> > m_hAgents;
      //## end OasisEntityFile::Agents%570BA28000B6.attr

      //## Attribute: Chains%570BA27F034D
      //## begin OasisEntityFile::Chains%570BA27F034D.attr preserve=no  private: map<string,string,less<string> > {V} 
      map<string,string,less<string> > m_hChains;
      //## end OasisEntityFile::Chains%570BA27F034D.attr

      //## Attribute: CreditPROC_ID%458318B3033E
      //## begin OasisEntityFile::CreditPROC_ID%458318B3033E.attr preserve=no  private: string {U} 
      string m_strCreditPROC_ID;
      //## end OasisEntityFile::CreditPROC_ID%458318B3033E.attr

      //## Attribute: DebitPROC_ID%45832252008C
      //## begin OasisEntityFile::DebitPROC_ID%45832252008C.attr preserve=no  private: string {U} 
      string m_strDebitPROC_ID;
      //## end OasisEntityFile::DebitPROC_ID%45832252008C.attr

      //## Attribute: DEVICE_ID%45D21FCB025B
      //## begin OasisEntityFile::DEVICE_ID%45D21FCB025B.attr preserve=no  private: string {U} 
      string m_strDEVICE_ID;
      //## end OasisEntityFile::DEVICE_ID%45D21FCB025B.attr

      //## Attribute: InsertCount%570BA03B0384
      //## begin OasisEntityFile::InsertCount%570BA03B0384.attr preserve=no  private: int {V} 0
      int m_iInsertCount;
      //## end OasisEntityFile::InsertCount%570BA03B0384.attr

      //## Attribute: INST_ID%45D220010335
      //## begin OasisEntityFile::INST_ID%45D220010335.attr preserve=no  private: string {U} 
      string m_strINST_ID;
      //## end OasisEntityFile::INST_ID%45D220010335.attr

      //## Attribute: InstitutionMap%570BA0BC0368
      //## begin OasisEntityFile::InstitutionMap%570BA0BC0368.attr preserve=no  private: map<string,int, less<string> > {V} 
      map<string,int, less<string> > m_hInstitutionMap;
      //## end OasisEntityFile::InstitutionMap%570BA0BC0368.attr

      //## Attribute: MerchantMap%570BA0EA0018
      //## begin OasisEntityFile::MerchantMap%570BA0EA0018.attr preserve=no  private: map<string,pair<string,string>,less<string> > {V} 
      map<string,pair<string,string>,less<string> > m_hMerchantMap;
      //## end OasisEntityFile::MerchantMap%570BA0EA0018.attr

      //## Attribute: Merchants%570BA6BD01CF
      //## begin OasisEntityFile::Merchants%570BA6BD01CF.attr preserve=no  private: map<string,string,less<string> > {V} 
      map<string,string,less<string> > m_hMerchants;
      //## end OasisEntityFile::Merchants%570BA6BD01CF.attr

      //## Attribute: ReadInstitutionMap%4583189A011B
      //## begin OasisEntityFile::ReadInstitutionMap%4583189A011B.attr preserve=no  private: bool {U} false
      bool m_bReadInstitutionMap;
      //## end OasisEntityFile::ReadInstitutionMap%4583189A011B.attr

      //## Attribute: TERM_CLASS_DESC%458322530319
      //## begin OasisEntityFile::TERM_CLASS_DESC%458322530319.attr preserve=no  private: string {U} 
      string m_strTERM_CLASS_DESC;
      //## end OasisEntityFile::TERM_CLASS_DESC%458322530319.attr

    // Data Members for Associations

      //## Association: Platform \: FIS IST::OasisEntityFileReader_CAT::<unnamed>%570BA08103A3
      //## Role: OasisEntityFile::<m_hQuery>%570BA08203CB
      //## begin OasisEntityFile::<m_hQuery>%570BA08203CB.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end OasisEntityFile::<m_hQuery>%570BA08203CB.role

    // Additional Implementation Declarations
      //## begin OasisEntityFile%427B310F0090.implementation preserve=yes
      string m_strRPT_LVL_ID;
      string m_strPseudoDevice;
      //## end OasisEntityFile%427B310F0090.implementation
};

//## begin OasisEntityFile%427B310F0090.postscript preserve=yes
//## end OasisEntityFile%427B310F0090.postscript

//## begin module%424D8149005D.epilog preserve=yes
//## end module%424D8149005D.epilog


#endif
