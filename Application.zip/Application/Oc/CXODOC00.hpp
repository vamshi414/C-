//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%424D82FB0186.cm preserve=no
//	$Date:   May 08 2007 03:25:18  $ $Author:   d01575  $
//	$Revision:   1.8  $
//## end module%424D82FB0186.cm

//## begin module%424D82FB0186.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%424D82FB0186.cp

//## Module: CXOSOC00%424D82FB0186; Package specification
//## Subsystem: OC%424D79890000
//## Source file: C:\Devel\Dn\Server\Application\OC\CXODOC00.hpp

#ifndef CXOSOC00_h
#define CXOSOC00_h 1

//## begin module%424D82FB0186.additionalIncludes preserve=no
//## end module%424D82FB0186.additionalIncludes

//## begin module%424D82FB0186.includes preserve=yes
//## end module%424D82FB0186.includes

#ifndef CXOSOC02_h
#include "CXODOC02.hpp"
#endif
#ifndef CXOSNC19_h
#include "CXODNC19.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
} // namespace database

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Console;
class Message;
} // namespace IF

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: DataNavigator Foundation::EntityCommand_CAT%394E2706012A
namespace entitycommand {
class CRUpdateCommand;

} // namespace entitycommand

//## begin module%424D82FB0186.declarations preserve=no
//## end module%424D82FB0186.declarations

//## begin module%424D82FB0186.additionalDeclarations preserve=yes
//## end module%424D82FB0186.additionalDeclarations


//## begin OasisEntityFileReader%427B2DA601E7.preface preserve=yes
//## end OasisEntityFileReader%427B2DA601E7.preface

//## Class: OasisEntityFileReader%427B2DA601E7
//	<body>
//	<title>CG
//	<h1>OC
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server requires replicated
//	configuration information from the acquiring platform
//	switch database.
//	<p>
//	The EFD IST configuration file (CF) is read by the EFD
//	IST Configuration Interface (<i>ca</i>CU) to update the
//	DataNavigator Configuration Repository (CR).
//	A new file should be copied to the DataNavigator Server
//	following the completion of any related maintenance to
//	the EFD IST configuration.
//	</p>
//	<img src=CXOCOC00.gif>
//	<h2>FO
//	<h3>Entity Tables
//	<p>
//	The eFunds IST Configuration Interface populates the
//	following tables in the configuration repository:
//	<ul>
//	<li><i>qualify</i>.PROCESSOR
//	<li><i>qualify</i>.REPORTING_LVL
//	<li><i>qualify</i>.INSTITUTION
//	<li><i>qualify</i>.DEVICE
//	</ul>
//	<p>
//	After entities are added by the EFD IST Configuration
//	Interface, additional manual changes can be made using
//	the CR Client.
//	These tables are in the EFT-Entity Tables folder in the
//	CR Client for the DataNavigator Server.
//	<p>
//	Your DBA contact is notified of any new entities via an
//	email.
//	The Generic Configuration Interface service
//	documentation contains information on modifying the
//	email template.
//	</body>
//	<body>
//	<title>OG
//	<h1>OC
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server requires replicated
//	configuration information from the acquiring platform
//	switch database.
//	</p>
//	<img src=CXOOOC00.gif>
//	</body>
//## Category: Platform \: eFunds IST::OasisEntityFileReader_CAT%424D780301F4
//## Subsystem: OC%424D79890000
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%427B32ED03D5;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%427B338A0280;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%427B33F20011;monitor::UseCase { -> F}
//## Uses: <unnamed>%42881E5A0248;IF::Message { -> F}
//## Uses: <unnamed>%42881EE70132;entitycommand::CRUpdateCommand { -> F}
//## Uses: <unnamed>%428871BA016A;database::Database { -> F}
//## Uses: <unnamed>%45D60B8E0046;IF::Console { -> F}

class DllExport OasisEntityFileReader : public process::Application  //## Inherits: <unnamed>%427B2F4E00C6
{
  //## begin OasisEntityFileReader%427B2DA601E7.initialDeclarations preserve=yes
  //## end OasisEntityFileReader%427B2DA601E7.initialDeclarations

  public:
    //## Constructors (generated)
      OasisEntityFileReader();

    //## Destructor (generated)
      virtual ~OasisEntityFileReader();


    //## Other Operations (specified)
      //## Operation: initialize%42881C9B01DE
      int initialize ();

    // Additional Public Declarations
      //## begin OasisEntityFileReader%427B2DA601E7.public preserve=yes
      //## end OasisEntityFileReader%427B2DA601E7.public

  protected:

    //## Other Operations (specified)
      //## Operation: onReset%42881CDD000B
      int onReset (IF::Message& hMessage);

    // Additional Protected Declarations
      //## begin OasisEntityFileReader%427B2DA601E7.protected preserve=yes
      //## end OasisEntityFileReader%427B2DA601E7.protected

  private:
    // Additional Private Declarations
      //## begin OasisEntityFileReader%427B2DA601E7.private preserve=yes
      //## end OasisEntityFileReader%427B2DA601E7.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: eFunds IST::OasisEntityFileReader_CAT::<unnamed>%461F714701BA
      //## Role: OasisEntityFileReader::<m_hCRFile>%461F71480072
      //## begin OasisEntityFileReader::<m_hCRFile>%461F71480072.role preserve=no  public: entitycommand::CRFile { -> VHgN}
      entitycommand::CRFile m_hCRFile;
      //## end OasisEntityFileReader::<m_hCRFile>%461F71480072.role

      //## Association: Platform \: eFunds IST::OasisEntityFileReader_CAT::<unnamed>%461F71ED014E
      //## Role: OasisEntityFileReader::<m_hOasisEntityFile>%461F71ED0371
      //## begin OasisEntityFileReader::<m_hOasisEntityFile>%461F71ED0371.role preserve=no  public: OasisEntityFile { -> VHgN}
      OasisEntityFile m_hOasisEntityFile;
      //## end OasisEntityFileReader::<m_hOasisEntityFile>%461F71ED0371.role

    // Additional Implementation Declarations
      //## begin OasisEntityFileReader%427B2DA601E7.implementation preserve=yes
      //## end OasisEntityFileReader%427B2DA601E7.implementation

};

//## begin OasisEntityFileReader%427B2DA601E7.postscript preserve=yes
//## end OasisEntityFileReader%427B2DA601E7.postscript

//## begin module%424D82FB0186.epilog preserve=yes
//## end module%424D82FB0186.epilog


#endif
