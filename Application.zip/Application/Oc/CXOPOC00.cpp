//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%424D830201F4.cm preserve=no
//	$Date:   Jul 26 2013 09:39:26  $ $Author:   e1009652  $
//	$Revision:   1.13  $
//## end module%424D830201F4.cm

//## begin module%424D830201F4.cp preserve=no
//	Copyright (c) 1998 - 2005
//	eFunds Corporation
//## end module%424D830201F4.cp

//## Module: CXOSOC00%424D830201F4; Package body
//## Subsystem: OC%424D79890000
//## Source file: C:\Devel\Dn\Server\Application\OC\CXOPOC00.cpp

//## begin module%424D830201F4.additionalIncludes preserve=no
//## end module%424D830201F4.additionalIncludes

//## begin module%424D830201F4.includes preserve=yes
// $Date:   Jul 26 2013 09:39:26  $ $Author:   e1009652  $ $Revision:   1.13  $
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#ifndef CXOSBS27_h
#include "CXODBS27.hpp"
#endif
//## end module%424D830201F4.includes

#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSNC01_h
#include "CXODNC01.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSOC00_h
#include "CXODOC00.hpp"
#endif


//## begin module%424D830201F4.declarations preserve=no
//## end module%424D830201F4.declarations

//## begin module%424D830201F4.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new OasisEntityFileReader();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%424D830201F4.additionalDeclarations


// Class OasisEntityFileReader 

OasisEntityFileReader::OasisEntityFileReader()
  //## begin OasisEntityFileReader::OasisEntityFileReader%427B2DA601E7_const.hasinit preserve=no
  //## end OasisEntityFileReader::OasisEntityFileReader%427B2DA601E7_const.hasinit
  //## begin OasisEntityFileReader::OasisEntityFileReader%427B2DA601E7_const.initialization preserve=yes
  :m_hCRFile("CR")
  //## end OasisEntityFileReader::OasisEntityFileReader%427B2DA601E7_const.initialization
{
  //## begin OasisEntityFileReader::OasisEntityFileReader%427B2DA601E7_const.body preserve=yes
   memcpy(m_sID,"OC00",4);
  //## end OasisEntityFileReader::OasisEntityFileReader%427B2DA601E7_const.body
}


OasisEntityFileReader::~OasisEntityFileReader()
{
  //## begin OasisEntityFileReader::~OasisEntityFileReader%427B2DA601E7_dest.body preserve=yes
  //## end OasisEntityFileReader::~OasisEntityFileReader%427B2DA601E7_dest.body
}



//## Other Operations (implementation)
int OasisEntityFileReader::initialize ()
{
  //## begin OasisEntityFileReader::initialize%42881C9B01DE.body preserve=yes
   new dnplatform::DNPlatform();
   new segment::AuditEvent;
   int i = Application::initialize();
   UseCase hUseCase("IST","## IS01 START IST");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   CRUpdateCommand::instance();
   Database::instance()->connect();
   return 0;
  //## end OasisEntityFileReader::initialize%42881C9B01DE.body
}

int OasisEntityFileReader::onReset (IF::Message& hMessage)
{
  //## begin OasisEntityFileReader::onReset%42881CDD000B.body preserve=yes
   UseCase hUseCase("IST","## IS02 RESET OC");
   if (hMessage.context().subString(1,2) == "CR")
   {
      m_hCRFile.process();
      CRUpdateCommand::instance()->notify();
      Console::display("ST128");
   }
   else
   {
      m_hOasisEntityFile.process();
      CRUpdateCommand::instance()->notify();
      Console::display("ST128");
   }
  return 0;
  //## end OasisEntityFileReader::onReset%42881CDD000B.body
}

// Additional Declarations
  //## begin OasisEntityFileReader%427B2DA601E7.declarations preserve=yes
  //## end OasisEntityFileReader%427B2DA601E7.declarations

//## begin module%424D830201F4.epilog preserve=yes
//## end module%424D830201F4.epilog
