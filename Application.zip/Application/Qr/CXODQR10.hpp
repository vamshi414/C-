//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39CA0DA902B4.cm preserve=no
//## end module%39CA0DA902B4.cm

//## begin module%39CA0DA902B4.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%39CA0DA902B4.cp

//## Module: CXOSQR10%39CA0DA902B4; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR10.hpp

#ifndef CXOSQR10_h
#define CXOSQR10_h 1

//## begin module%39CA0DA902B4.additionalIncludes preserve=no
//## end module%39CA0DA902B4.additionalIncludes

//## begin module%39CA0DA902B4.includes preserve=yes
// $Date:   Sep 03 2010 06:36:12  $ $Author:   D02684  $ $Revision:   1.9  $
//## end module%39CA0DA902B4.includes

#ifndef CXOSRU14_h
#include "CXODRU14.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Batch;
class APEventHandler;
class Control;
} // namespace qr

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class CXString;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class DateTime;
class Extract;
class Console;
class Queue;
class Trace;

} // namespace IF

//## begin module%39CA0DA902B4.declarations preserve=no
//## end module%39CA0DA902B4.declarations

//## begin module%39CA0DA902B4.additionalDeclarations preserve=yes
//## end module%39CA0DA902B4.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::B24APTranHandler%39C97279021A.preface preserve=yes
//## end qr::B24APTranHandler%39C97279021A.preface

//## Class: B24APTranHandler%39C97279021A
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39C974C301AF;IF::Console { -> F}
//## Uses: <unnamed>%39C974DE009F;Batch { -> F}
//## Uses: <unnamed>%39C9754F00B5;IF::Message { -> F}
//## Uses: <unnamed>%39C975540081;IF::Queue { -> F}
//## Uses: <unnamed>%39CA1F310299;IF::DateTime { -> F}
//## Uses: <unnamed>%39CA1F4501D0;IF::Trace { -> F}
//## Uses: <unnamed>%39CA1F700041;Control { -> F}
//## Uses: <unnamed>%4BC8353F02A4;APEventHandler { -> F}
//## Uses: <unnamed>%4BC8360D038C;IF::Extract { -> F}
//## Uses: <unnamed>%4BC83662010A;reusable::CXString { -> F}

class B24APTranHandler : public reusable::Handler  //## Inherits: <unnamed>%39C975740358
{
  //## begin qr::B24APTranHandler%39C97279021A.initialDeclarations preserve=yes
  //## end qr::B24APTranHandler%39C97279021A.initialDeclarations

  public:
    //## Constructors (generated)
      B24APTranHandler();

    //## Constructors (specified)
      //## Operation: B24APTranHandler%39C9740603DE
      B24APTranHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~B24APTranHandler();


    //## Other Operations (specified)
      //## Operation: update%39C9740700A0
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin qr::B24APTranHandler%39C97279021A.public preserve=yes
      //## end qr::B24APTranHandler%39C97279021A.public

  protected:
    // Additional Protected Declarations
      //## begin qr::B24APTranHandler%39C97279021A.protected preserve=yes
      //## end qr::B24APTranHandler%39C97279021A.protected

  private:
    // Additional Private Declarations
      //## begin qr::B24APTranHandler%39C97279021A.private preserve=yes
      //## end qr::B24APTranHandler%39C97279021A.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: IsB24ATM%4C1F7AB6008A
      //## begin qr::B24APTranHandler::IsB24ATM%4C1F7AB6008A.attr preserve=no  private: bool {U} false
      bool m_bIsB24ATM;
      //## end qr::B24APTranHandler::IsB24ATM%4C1F7AB6008A.attr

      //## Attribute: LoggerName%39C9743E0063
      //## begin qr::B24APTranHandler::LoggerName%39C9743E0063.attr preserve=no  private: string {U} 
      string m_strLoggerName;
      //## end qr::B24APTranHandler::LoggerName%39C9743E0063.attr

      //## Attribute: LogOpenTimestamp%39C9743E0121
      //## begin qr::B24APTranHandler::LogOpenTimestamp%39C9743E0121.attr preserve=no  private: string {U} 
      string m_strLogOpenTimestamp;
      //## end qr::B24APTranHandler::LogOpenTimestamp%39C9743E0121.attr

      //## Attribute: B24MessageTypes%4C80D8E601EC
      //## begin qr::B24APTranHandler::B24MessageTypes%4C80D8E601EC.attr preserve=no  private: string {U} 
      string m_strB24MessageTypes;
      //## end qr::B24APTranHandler::B24MessageTypes%4C80D8E601EC.attr

    // Additional Implementation Declarations
      //## begin qr::B24APTranHandler%39C97279021A.implementation preserve=yes
      //## end qr::B24APTranHandler%39C97279021A.implementation

};

//## begin qr::B24APTranHandler%39C97279021A.postscript preserve=yes
//## end qr::B24APTranHandler%39C97279021A.postscript

} // namespace qr

//## begin module%39CA0DA902B4.epilog preserve=yes
//## end module%39CA0DA902B4.epilog


#endif
