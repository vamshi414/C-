//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36F9482602AA.cm preserve=no
//## end module%36F9482602AA.cm

//## begin module%36F9482602AA.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36F9482602AA.cp

//## Module: CXOSQR03%36F9482602AA; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR03.cpp

//## begin module%36F9482602AA.additionalIncludes preserve=no
//## end module%36F9482602AA.additionalIncludes

//## begin module%36F9482602AA.includes preserve=yes
#include <stdio.h>
#include "CXODIF11.hpp"
#include "CXODRU24.hpp"
#include "CXODTM03.hpp"
#include "CXODRU34.hpp"
#include "CXODIF28.hpp"
#ifdef MVS
#include "CXODTM12.hpp"
#endif
//## end module%36F9482602AA.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif
#ifndef CXOSQR04_h
#include "CXODQR04.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSQR00_h
#include "CXODQR00.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif


//## begin module%36F9482602AA.declarations preserve=no
//## end module%36F9482602AA.declarations

//## begin module%36F9482602AA.additionalDeclarations preserve=yes
#define _REGISTER_MIN -2147483647
#define _REGISTER_MAX 2147483648
//## end module%36F9482602AA.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::Control 

//## begin qr::Control::Controls%36F9499600FA.attr preserve=no  private: static map<string, Control*, less<string> >* {U} 0
map<string, Control*, less<string> >* Control::m_pControls = 0;
//## end qr::Control::Controls%36F9499600FA.attr

//## begin qr::Control::Logging%3D23058C0232.attr preserve=no  public: static bool {U} false
bool Control::m_bLogging = false;
//## end qr::Control::Logging%3D23058C0232.attr

Control::Control()
  //## begin Control::Control%36F947F70049_const.hasinit preserve=no
      : m_lAP_Count(0),
        m_dAP_Hash(0),
        m_lCDN_Count(0),
        m_dCDN_Hash(0),
        m_bDST(false),
        m_iGMTOffset(0),
        m_lTemp_CDN_Count(0),
        m_dTemp_CDN_Hash(0),
        m_bCountsMatch(false),
        m_bAmountsMatch(false)
  //## end Control::Control%36F947F70049_const.hasinit
  //## begin Control::Control%36F947F70049_const.initialization preserve=yes
  //## end Control::Control%36F947F70049_const.initialization
{
  //## begin qr::Control::Control%36F947F70049_const.body preserve=yes
   memcpy(m_sID,"QR03",4);
   setGMT();
  //## end qr::Control::Control%36F947F70049_const.body
}

Control::Control (string& strLoggerName, string& strLogOpenTimestamp)
  //## begin qr::Control::Control%36F95192006D.hasinit preserve=no
      : m_lAP_Count(0),
        m_dAP_Hash(0),
        m_lCDN_Count(0),
        m_dCDN_Hash(0),
        m_bDST(false),
        m_iGMTOffset(0),
        m_lTemp_CDN_Count(0),
        m_dTemp_CDN_Hash(0),
        m_bCountsMatch(false),
        m_bAmountsMatch(false)
  //## end qr::Control::Control%36F95192006D.hasinit
  //## begin qr::Control::Control%36F95192006D.initialization preserve=yes
  //## end qr::Control::Control%36F95192006D.initialization
{
  //## begin qr::Control::Control%36F95192006D.body preserve=yes
   memcpy(m_sID,"QR03",4);
   m_strLoggerName = strLoggerName;
   m_strLogOpenTimestamp = strLogOpenTimestamp;
   setGMT();
  //## end qr::Control::Control%36F95192006D.body
}


Control::~Control()
{
  //## begin qr::Control::~Control%36F947F70049_dest.body preserve=yes
  //## end qr::Control::~Control%36F947F70049_dest.body
}



//## Other Operations (implementation)
void Control::ageOffRecords ()
{
  //## begin qr::Control::ageOffRecords%3729EB920268.body preserve=yes
   string strCurrentDateTime((Clock::instance()->getDate()).substr(0,8));
   int lMaxDays = 14;
   Extract::instance()->getLong("DUSER   ","MAX_DAYS=",&lMaxDays);
   char x9[9] = {"        "};
   memcpy(x9,(char*)strCurrentDateTime.data(),8);
   int iDay = atoi(x9 + 6);
   x9[6] = '\0';
   int iMonth = atoi(x9 + 4);
   x9[4] = '\0';
   int iYear = atoi(x9);
   Date hDate(iYear,iMonth,iDay);
   hDate -= lMaxDays;
   string strDate(hDate.asString("%Y%m%d"));
   strDate += "00000000";
   auto_ptr<SelectStatement> pDeleteStatement((SelectStatement*)DatabaseFactory::instance()->create("DeleteStatement"));
   Query hQuery;
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_KEY","<",strDate.c_str());
   string strTASKID(Application::instance()->name());
   if (strTASKID.length() > 3)
      strTASKID.erase(4);
   strTASKID += "%";
   hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","LIKE",strTASKID.c_str());
   hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=","C");
   pDeleteStatement->execute(hQuery);
   Database::instance()->commit();
  //## end qr::Control::ageOffRecords%3729EB920268.body
}

int Control::commit ()
{
  //## begin qr::Control::commit%36FA50C80303.body preserve=yes
   if (m_pControls == 0)
      return 0;
   string strContextKey;
   string strLatestTimestamp;
   char szContextData[4 * PERCENTD + 2 * PERCENTF];
   Context* pContext = new Context(Application::instance()->image(),Application::instance()->name());
   map<string,Control*,less<string> >::iterator pControl;
   for (pControl = m_pControls->begin();pControl != m_pControls->end();++pControl)
   {
      if ((*pControl).second->m_lTemp_CDN_Count > 0
         || (*pControl).second->m_lAP_Count > 0)
      {
         double dCDN_Hash = (*pControl).second->m_dCDN_Hash + (*pControl).second->m_dTemp_CDN_Hash;
         int iCDN_Count = (*pControl).second->m_lCDN_Count + (*pControl).second->m_lTemp_CDN_Count;
         strContextKey = (*pControl).second->m_strLogOpenTimestamp +
            "," + (*pControl).second->m_strLoggerName;
         snprintf(szContextData,sizeof(szContextData),"%d,%d,%.2f,%.2f,%d,%d",
            (*pControl).second->m_lAP_Count,
            iCDN_Count,
            (*pControl).second->m_dAP_Hash,
            dCDN_Hash,
            (int)((*pControl).second->m_bCountsMatch),
            (int)((*pControl).second->m_bAmountsMatch));
         if (!pContext->put(strContextKey.c_str(),szContextData,'C'))
         {
            Console::display("ST503");
            //(*pControl).second->m_dCDN_Hash -= (*pControl).second->m_dTemp_CDN_Hash;
            //(*pControl).second->m_lCDN_Count -= (*pControl).second->m_lTemp_CDN_Count;
            delete pContext;
            return 1;
         }
         if (!(APEventHandler::instance()->locate((*pControl).second->m_strLoggerName,strLatestTimestamp)))
            strLatestTimestamp = "0000000000000000";
         else if ((*pControl).second->m_iGMTOffset != 0)
         {
#ifdef MVS
            GMT::instance()->asLocal(strLatestTimestamp,(*pControl).second->m_iGMTOffset,(*pControl).second->m_bDST);
#else
            Timestamp::gmtToLocal(strLatestTimestamp);
#endif
         }
         if (!pContext->put((*pControl).second->m_strLoggerName.c_str(),strLatestTimestamp.c_str(),'L'))
         {
            Console::display("ST503");
            //(*pControl).second->m_dCDN_Hash -= (*pControl).second->m_dTemp_CDN_Hash;
            //(*pControl).second->m_lCDN_Count -= (*pControl).second->m_lTemp_CDN_Count;
            delete pContext;
            return 1;
         }
        // (*pControl).second->m_dTemp_CDN_Hash = 0;
        // (*pControl).second->m_lTemp_CDN_Count = 0;
      }
   }
   delete pContext;
   return 0;
  //## end qr::Control::commit%36FA50C80303.body
}

Control* Control::locate (string& strLoggerName, string& strLogOpenTimestamp)
{
  //## begin qr::Control::locate%36F94DE003AC.body preserve=yes
   string strContextKey = strLogOpenTimestamp + "," + strLoggerName;
   if (m_pControls == 0)
      m_pControls = new map<string,Control*,less<string> >;
   map<string,Control*,less<string> >::iterator pControl = m_pControls->find(strContextKey);
   if (pControl != m_pControls->end())
      return (*pControl).second;
   Control* p = new Control(strLoggerName,strLogOpenTimestamp);
   // try reading this info from the datbase
   Context* pContext = new Context(Application::instance()->image(),Application::instance()->name());
   string strData;
   pContext->get(strContextKey.c_str(),strData,'C');
   Database::instance()->commit();
   if (!strData.empty())
   {
      vector<string> hTokens;
      Buffer::parse(strData,",",hTokens);
      if (hTokens.size() == 6)
      {
         p->m_lAP_Count = atoi(hTokens[0].c_str());
         p->m_lCDN_Count = atoi(hTokens[1].c_str());
         p->m_dAP_Hash = atof(hTokens[2].c_str());
         p->m_dCDN_Hash = atof(hTokens[3].c_str());
         p->m_bCountsMatch = hTokens[4] == "1";
         p->m_bAmountsMatch = hTokens[5] == "1";
      }
   }
   delete pContext;
   m_pControls->insert(map<string,Control*,less<string> >::value_type(strContextKey,p));
   return p;
  //## end qr::Control::locate%36F94DE003AC.body
}

void Control::remove ()
{
  //## begin qr::Control::remove%37160AF50032.body preserve=yes
   if (m_pControls == 0)
      return;
   string strYesterday(MidnightAlarm::instance()->getYesterday());
   strYesterday.append("00000000",8);
   map<string,Control*,less<string> >::iterator pControl = m_pControls->begin();
   while (pControl != m_pControls->end())
   {
      if ((*pControl).second->m_strLogOpenTimestamp < strYesterday
         && (*pControl).second->m_lTemp_CDN_Count == 0)
      {
         delete ((*pControl).second);
         m_pControls->erase(pControl);
         pControl = m_pControls->begin();
      }
      else
         ++pControl;
   }
  //## end qr::Control::remove%37160AF50032.body
}

void Control::reset ()
{
  //## begin qr::Control::reset%51375912011D.body preserve=yes
   if (m_pControls == 0)
      return;
   map<string,Control*,less<string> >::iterator pControl;
   for (pControl = m_pControls->begin();pControl != m_pControls->end();++pControl)
   {
      (*pControl).second->m_dTemp_CDN_Hash = 0;
      (*pControl).second->m_lTemp_CDN_Count = 0;
   }
  //## end qr::Control::reset%51375912011D.body
}

int Control::rollback ()
{
  //## begin qr::Control::rollback%36FA50E0038A.body preserve=yes
   if (m_pControls == 0)
      return 0;
   map<string,Control*,less<string> >::iterator pControl;
   for (pControl = m_pControls->begin();pControl != m_pControls->end();++pControl)
   {
      if ((*pControl).second->m_lTemp_CDN_Count != 0)
      {
        (*pControl).second->m_dTemp_CDN_Hash = 0;
        (*pControl).second->m_lTemp_CDN_Count = 0;
      }
   }
   return 0;
  //## end qr::Control::rollback%36FA50E0038A.body
}

void Control::setGMT ()
{
  //## begin qr::Control::setGMT%665E18B10349.body preserve=yes
   string strDSTSpec;
   if (Extract::instance()->getSpec("GMT", strDSTSpec))
   {
      strDSTSpec.resize(6, ' ');
      m_bDST = strDSTSpec[5] == 'D';
      m_iGMTOffset = atoi(strDSTSpec.substr(0, 5).c_str());
   }
  //## end qr::Control::setGMT%665E18B10349.body
}

void Control::terminate ()
{
  //## begin qr::Control::terminate%3783824B0392.body preserve=yes
   if (m_pControls == 0)
      return;
   map<string,Control*,less<string> >::iterator pControl;
   for (pControl = m_pControls->begin();pControl != m_pControls->end();++pControl)
      delete (*pControl).second;
   m_pControls->erase(m_pControls->begin(),m_pControls->end());
  //## end qr::Control::terminate%3783824B0392.body
}

void Control::update ()
{
  //## begin qr::Control::update%513758EB0075.body preserve=yes
   if (m_pControls == 0)
      return;
   map<string,Control*,less<string> >::iterator pControl;
   for (pControl = m_pControls->begin();pControl != m_pControls->end();++pControl)
   {
      (*pControl).second->m_dCDN_Hash += (*pControl).second->m_dTemp_CDN_Hash;
      (*pControl).second->m_lCDN_Count += (*pControl).second->m_lTemp_CDN_Count;
      (*pControl).second->m_dTemp_CDN_Hash = 0;
      (*pControl).second->m_lTemp_CDN_Count = 0;
   }
  //## end qr::Control::update%513758EB0075.body
}

void Control::updateCDNHash (double dAPHash)
{
  //## begin qr::Control::updateCDNHash%36F95339001B.body preserve=yes
   if (dAPHash < 2147483648 && dAPHash > -2147483647)
      m_dTemp_CDN_Hash += dAPHash;
   m_lTemp_CDN_Count++;
   if (m_lAP_Count !=0)
   {
      string strKey = m_strLogOpenTimestamp + "," + m_strLoggerName;
      if (!m_bCountsMatch)
      {
         if ((m_lAP_Count != 0) && (m_lAP_Count == (m_lTemp_CDN_Count + m_lCDN_Count)))
         {
            Console::display("ST504",strKey.c_str());
            m_bCountsMatch = true;
         }
      }
      if (!m_bAmountsMatch)
      {
         if ((m_dAP_Hash != 0) && (m_dAP_Hash == (m_dTemp_CDN_Hash + m_dCDN_Hash)))
         {
            Console::display("ST505",strKey.c_str());
            m_bAmountsMatch = true;
         }
      }
      if (m_bCountsMatch)
      {
         if ((m_lAP_Count != (m_lTemp_CDN_Count + m_lCDN_Count)))
         {
            Console::display("ST517",strKey.c_str());
            m_bCountsMatch = false;
         }
      }
      if (m_bAmountsMatch)
      {
         if ((m_dAP_Hash != (m_dTemp_CDN_Hash + m_dCDN_Hash)))
         {
            Console::display("ST501",strKey.c_str());
            m_bAmountsMatch = false;
         }
      }
   }
  //## end qr::Control::updateCDNHash%36F95339001B.body
}

// Additional Declarations
  //## begin qr::Control%36F947F70049.declarations preserve=yes
  //## end qr::Control%36F947F70049.declarations

} // namespace qr

//## begin module%36F9482602AA.epilog preserve=yes
//## end module%36F9482602AA.epilog
