//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%37F8F1D70114.cm preserve=no
//## end module%37F8F1D70114.cm

//## begin module%37F8F1D70114.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%37F8F1D70114.cp

//## Module: CXOSQR08%37F8F1D70114; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR08.cpp

//## begin module%37F8F1D70114.additionalIncludes preserve=no
//## end module%37F8F1D70114.additionalIncludes

//## begin module%37F8F1D70114.includes preserve=yes
// $Date:   Jun 21 2017 08:05:26  $ $Author:   e1009839  $ $Revision:   1.9  $
#include "CXODRU24.hpp"
#include "CXODIP04.hpp"
#include "CXODIF11.hpp"
//## end module%37F8F1D70114.includes

#ifndef CXOSQR09_h
#include "CXODQR09.hpp"
#endif
#ifndef CXOSQR04_h
#include "CXODQR04.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif
#ifndef CXOSQR08_h
#include "CXODQR08.hpp"
#endif


//## begin module%37F8F1D70114.declarations preserve=no
//## end module%37F8F1D70114.declarations

//## begin module%37F8F1D70114.additionalDeclarations preserve=yes
//## end module%37F8F1D70114.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::IBMAPControlHandler 

IBMAPControlHandler::IBMAPControlHandler()
  //## begin IBMAPControlHandler::IBMAPControlHandler%37F8F0F00203_const.hasinit preserve=no
  //## end IBMAPControlHandler::IBMAPControlHandler%37F8F0F00203_const.hasinit
  //## begin IBMAPControlHandler::IBMAPControlHandler%37F8F0F00203_const.initialization preserve=yes
  //## end IBMAPControlHandler::IBMAPControlHandler%37F8F0F00203_const.initialization
{
  //## begin qr::IBMAPControlHandler::IBMAPControlHandler%37F8F0F00203_const.body preserve=yes
   memcpy(m_sID,"QR08",4);
  //## end qr::IBMAPControlHandler::IBMAPControlHandler%37F8F0F00203_const.body
}

IBMAPControlHandler::IBMAPControlHandler (Handler* pHandler)
  //## begin qr::IBMAPControlHandler::IBMAPControlHandler%37FB899302DA.hasinit preserve=no
  //## end qr::IBMAPControlHandler::IBMAPControlHandler%37FB899302DA.hasinit
  //## begin qr::IBMAPControlHandler::IBMAPControlHandler%37FB899302DA.initialization preserve=yes
  //## end qr::IBMAPControlHandler::IBMAPControlHandler%37FB899302DA.initialization
{
  //## begin qr::IBMAPControlHandler::IBMAPControlHandler%37FB899302DA.body preserve=yes
   m_pSuccessor = pHandler;
   memcpy(m_sID,"QR08",4);
  //## end qr::IBMAPControlHandler::IBMAPControlHandler%37FB899302DA.body
}


IBMAPControlHandler::~IBMAPControlHandler()
{
  //## begin qr::IBMAPControlHandler::~IBMAPControlHandler%37F8F0F00203_dest.body preserve=yes
  //## end qr::IBMAPControlHandler::~IBMAPControlHandler%37F8F0F00203_dest.body
}



//## Other Operations (implementation)
void IBMAPControlHandler::update (Subject* pSubject)
{
  //## begin qr::IBMAPControlHandler::update%37FA07870340.body preserve=yes
   Message* pMessage = (Message*)pSubject;
   hIBMLogHeader* pIBMLogHeader = (hIBMLogHeader*)pMessage->data();
   hC0904Message* pIBMMsg = (hC0904Message*)pMessage->data();
   DateTime hDateTime;
   IString strTempLogOpenTimestamp;
#ifdef MVS
   if ((strncmp(((Message*)pSubject)->getDestination().data(),"AP",2) != 0) || (strncmp(pIBMLogHeader->sMessageID,"C0904",5) != 0))
#else
   if ((strncmp(((Message*)pSubject)->getDestination().data(),"AP",2) != 0))
#endif
   {
      m_pSuccessor->update(pSubject);
      return;
   }
   //these control records indicate IBM inactivity and should be ignored
   if ((pIBMMsg->lTranCnt == 1) && (pIBMMsg->lHashValue == 0))
   {
      Trace::put("IBM inactivity record dropped",29);
      return;
   }
   m_strLoggerName.assign(pIBMMsg->sProcessName,8);
   hDateTime.setFromIBM(pIBMMsg->sBatchIdSTCK,strTempLogOpenTimestamp);
   m_strLogOpenTimestamp.assign(strTempLogOpenTimestamp,16);
   if (!APEventHandler::instance()->isValidLoggerName(m_strLoggerName))
      return;
   m_dAPHash  = pIBMMsg->lHashValue;
   m_lAPCount = pIBMMsg->lTranCnt;
   Control* pControl = Control::locate(m_strLoggerName,m_strLogOpenTimestamp);
   pControl->updateCDNHash(0);
   APControlHandler::update(pSubject);
  //## end qr::IBMAPControlHandler::update%37FA07870340.body
}

// Additional Declarations
  //## begin qr::IBMAPControlHandler%37F8F0F00203.declarations preserve=yes
  //## end qr::IBMAPControlHandler%37F8F0F00203.declarations

} // namespace qr

//## begin module%37F8F1D70114.epilog preserve=yes
//## end module%37F8F1D70114.epilog
