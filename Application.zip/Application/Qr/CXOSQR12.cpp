//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%393559D30178.cm preserve=no
//## end module%393559D30178.cm

//## begin module%393559D30178.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%393559D30178.cp

//## Module: CXOSQR12%393559D30178; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR12.cpp

//## begin module%393559D30178.additionalIncludes preserve=no
//## end module%393559D30178.additionalIncludes

//## begin module%393559D30178.includes preserve=yes
// $Date:   May 20 2020 17:36:22  $ $Author:   e1009510  $ $Revision:   1.20  $
#ifdef _WIN32
//#include <winsock.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
#include <stdio.h>
#include "CXODRU24.hpp"
#include "CXODRS18.hpp"
#include "CXODRS25.hpp"
//## end module%393559D30178.includes

#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif
#ifndef CXOSQR04_h
#include "CXODQR04.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSRS12_h
#include "CXODRS12.hpp"
#endif
#ifndef CXOSQR22_h
#include "CXODQR22.hpp"
#endif
#ifndef CXOSQR12_h
#include "CXODQR12.hpp"
#endif


//## begin module%393559D30178.declarations preserve=no
//## end module%393559D30178.declarations

//## begin module%393559D30178.additionalDeclarations preserve=yes
//## end module%393559D30178.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::ExtAPTranHandler 

//## begin qr::ExtAPTranHandler::Logging%39355EBB0138.attr preserve=no  public: static bool {U} false
bool ExtAPTranHandler::m_bLogging = false;
//## end qr::ExtAPTranHandler::Logging%39355EBB0138.attr

ExtAPTranHandler::ExtAPTranHandler()
  //## begin ExtAPTranHandler::ExtAPTranHandler%3935581501F9_const.hasinit preserve=no
  //## end ExtAPTranHandler::ExtAPTranHandler%3935581501F9_const.hasinit
  //## begin ExtAPTranHandler::ExtAPTranHandler%3935581501F9_const.initialization preserve=yes
  //## end ExtAPTranHandler::ExtAPTranHandler%3935581501F9_const.initialization
{
  //## begin qr::ExtAPTranHandler::ExtAPTranHandler%3935581501F9_const.body preserve=yes
  //## end qr::ExtAPTranHandler::ExtAPTranHandler%3935581501F9_const.body
}

ExtAPTranHandler::ExtAPTranHandler (Handler* pHandler)
  //## begin qr::ExtAPTranHandler::ExtAPTranHandler%39355DC5001C.hasinit preserve=no
  //## end qr::ExtAPTranHandler::ExtAPTranHandler%39355DC5001C.hasinit
  //## begin qr::ExtAPTranHandler::ExtAPTranHandler%39355DC5001C.initialization preserve=yes
  //## end qr::ExtAPTranHandler::ExtAPTranHandler%39355DC5001C.initialization
{
  //## begin qr::ExtAPTranHandler::ExtAPTranHandler%39355DC5001C.body preserve=yes
   memcpy(m_sID,"QR12",4);
   m_pSuccessor = pHandler;
  //## end qr::ExtAPTranHandler::ExtAPTranHandler%39355DC5001C.body
}


ExtAPTranHandler::~ExtAPTranHandler()
{
  //## begin qr::ExtAPTranHandler::~ExtAPTranHandler%3935581501F9_dest.body preserve=yes
  //## end qr::ExtAPTranHandler::~ExtAPTranHandler%3935581501F9_dest.body
}



//## Other Operations (implementation)
void ExtAPTranHandler::update (Subject* pSubject)
{
  //## begin qr::ExtAPTranHandler::update%39355DC302FE.body preserve=yes
   char* pMsg = Message::instance(Message::INBOUND)->data();
   ExternalMessageSegment::instance()->reset();
   ExternalMessageSegment::instance()->import(&pMsg);
   if (Message::instance(Message::INBOUND)->messageLength() <=
      ExternalMessageSegment::instance()->size())
   {
      m_pSuccessor->update(pSubject);
      return;
   }
   if (!SwitchInterfacePool::instance()->send(Message::instance(Message::INBOUND), Queue::DATAGRAM))
   {
      Console::display("ST248");
      Batch::instance()->restart();
      return;
   }
#ifdef MVS
   if (!APEventHandler::instance()->isValidLoggerName(m_strLoggerName))
      return;
#endif
   // ** log the transaction and update the confirmation vector:
   if (m_bLogging)
   {
      char temp[12];
      int iBatchCount = Batch::instance()->getCount();
      double dBatchNumber = Batch::instance()->getTicks();
      memcpy(temp,(char*)&iBatchCount,4);
      memcpy(temp+4,(char*)&dBatchNumber,8);
      if (Log::put(Message::instance(Message::INBOUND)->data(),Message::instance(Message::INBOUND)->dataLength(),"S0042D","Log Message",temp,"CUSTLOG") != 0)
      {
         Console::display("ST506");
         Batch::instance()->restart();
         return;
      }
      Batch::instance()->updateLogConfirmation();
   }
   // ** update the control record with the Transaction Amount ***
   m_strLoggerName = ExternalMessageSegment::instance()->getNodeName();
   m_strLogOpenTimestamp = ExternalMessageSegment::instance()->getNodeTstamp();
   Control* pControl = Control::locate(m_strLoggerName,m_strLogOpenTimestamp);
   string strTimestamp;
   double dAmtTran = 0;
   string strTranType((char*)Message::instance(Message::INBOUND)->data() + ExternalMessageSegment::instance()->size(),4);
   if (strTranType == "S200")
   {
      segBaseSegment* pBaseSegment = (segBaseSegment*)(Message::instance(Message::INBOUND)->data() + ExternalMessageSegment::instance()->size());
      dAmtTran = atof(pBaseSegment->AMT_TRAN);
      strTimestamp.assign(pBaseSegment->TSTAMP_TRANS,16);
   }
   else
   if (strTranType == "S907")
   {
      segStatusSegment* pStatusSegment = (segStatusSegment*)(Message::instance(Message::INBOUND)->data() + ExternalMessageSegment::instance()->size());
      strTimestamp.assign(pStatusSegment->TSTAMP_TRANS,16);
   }
   pControl->updateCDNHash(dAmtTran);
   char szHash[9] = {"        "};
   memcpy(szHash,ExternalMessageSegment::instance()->getAPHash().data(),8);
   unsigned int lHashVal = 0;
   sscanf(szHash,"%x",&lHashVal);
   Batch::instance()->addRecord(lHashVal);
   // update Logger in map of loggers with latest TIMESTAMP
   APEventHandler::instance()->update(m_strLoggerName,strTimestamp);
   Batch::instance()->update(Message::instance(Message::INBOUND)->getDestination(),strTimestamp);
  //## end qr::ExtAPTranHandler::update%39355DC302FE.body
}

// Additional Declarations
  //## begin qr::ExtAPTranHandler%3935581501F9.declarations preserve=yes
  //## end qr::ExtAPTranHandler%3935581501F9.declarations

} // namespace qr

//## begin module%393559D30178.epilog preserve=yes
//## end module%393559D30178.epilog
