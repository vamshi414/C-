//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%37F8EFFC0082.cm preserve=no
//## end module%37F8EFFC0082.cm

//## begin module%37F8EFFC0082.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%37F8EFFC0082.cp

//## Module: CXOSQR07%37F8EFFC0082; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR07.cpp

//## begin module%37F8EFFC0082.additionalIncludes preserve=no
//## end module%37F8EFFC0082.additionalIncludes

//## begin module%37F8EFFC0082.includes preserve=yes
#ifdef _WIN32
#include <winsock.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
#include "CXODRS28.hpp"
//## end module%37F8EFFC0082.includes

#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif
#ifndef CXOSQR04_h
#include "CXODQR04.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF26_h
#include "CXODIF26.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSQR01_h
#include "CXODQR01.hpp"
#endif
#ifndef CXOSTM10_h
#include "CXODTM10.hpp"
#endif
#ifndef CXOSQR22_h
#include "CXODQR22.hpp"
#endif
#ifndef CXOSQR07_h
#include "CXODQR07.hpp"
#endif


//## begin module%37F8EFFC0082.declarations preserve=no
//## end module%37F8EFFC0082.declarations

//## begin module%37F8EFFC0082.additionalDeclarations preserve=yes
//## end module%37F8EFFC0082.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::AdvgAPTranHandler 

//## begin qr::AdvgAPTranHandler::Logging%37F9102B0074.attr preserve=no  public: static bool {U} false
bool AdvgAPTranHandler::m_bLogging = false;
//## end qr::AdvgAPTranHandler::Logging%37F9102B0074.attr

AdvgAPTranHandler::AdvgAPTranHandler()
  //## begin AdvgAPTranHandler::AdvgAPTranHandler%37F8F0900269_const.hasinit preserve=no
  //## end AdvgAPTranHandler::AdvgAPTranHandler%37F8F0900269_const.hasinit
  //## begin AdvgAPTranHandler::AdvgAPTranHandler%37F8F0900269_const.initialization preserve=yes
  //## end AdvgAPTranHandler::AdvgAPTranHandler%37F8F0900269_const.initialization
{
  //## begin qr::AdvgAPTranHandler::AdvgAPTranHandler%37F8F0900269_const.body preserve=yes
  //## end qr::AdvgAPTranHandler::AdvgAPTranHandler%37F8F0900269_const.body
}

AdvgAPTranHandler::AdvgAPTranHandler (Handler* pHandler)
  //## begin qr::AdvgAPTranHandler::AdvgAPTranHandler%37F916340367.hasinit preserve=no
  //## end qr::AdvgAPTranHandler::AdvgAPTranHandler%37F916340367.hasinit
  //## begin qr::AdvgAPTranHandler::AdvgAPTranHandler%37F916340367.initialization preserve=yes
  //## end qr::AdvgAPTranHandler::AdvgAPTranHandler%37F916340367.initialization
{
  //## begin qr::AdvgAPTranHandler::AdvgAPTranHandler%37F916340367.body preserve=yes
   memcpy(m_sID,"QR07",4);
   m_pSuccessor = pHandler;
  //## end qr::AdvgAPTranHandler::AdvgAPTranHandler%37F916340367.body
}


AdvgAPTranHandler::~AdvgAPTranHandler()
{
  //## begin qr::AdvgAPTranHandler::~AdvgAPTranHandler%37F8F0900269_dest.body preserve=yes
  //## end qr::AdvgAPTranHandler::~AdvgAPTranHandler%37F8F0900269_dest.body
}



//## Other Operations (implementation)
void AdvgAPTranHandler::update (Subject* pSubject)
{
  //## begin qr::AdvgAPTranHandler::update%37F914DD0170.body preserve=yes
   if (!APAdvgHeader::instance()->parse())
      return;
   switch (APAdvgHeader::instance()->getMsgCode())
   {
      /*
      case 2400:
         m_hMessage.push_back(*Message::instance(Message::INBOUND));
         return;
      */
   case 904:
      m_pSuccessor->update(pSubject);
      break;
      /*
      default:
         if (!m_hMessage.empty())
         {
            vector<Message>::iterator p;
            for (p = m_hMessage.begin();p != m_hMessage.end();++p)
               *Message::instance(Message::INBOUND) += (*p);
            m_hMessage.erase(m_hMessage.begin(),m_hMessage.end());
         }
      */
   }
   if (!SwitchInterfacePool::instance()->send(Message::instance(Message::INBOUND), Queue::DATAGRAM))
   {
      Console::display("ST248");
      Batch::instance()->restart();
      return;
   }
   if (m_bLogging)
   {
      char temp[12];
      int iBatchCount = Batch::instance()->getCount();
      double dBatchNumber = Batch::instance()->getTicks();
      memcpy(temp,(char*)&iBatchCount,4);
      memcpy(temp+4,(char*)&dBatchNumber,8);
      if (Log::put(Message::instance(Message::INBOUND)->data(),Message::instance(Message::INBOUND)->dataLength(),"S0042D","Log Message",temp,"CUSTLOG") != 0)
      {
         Console::display("ST506");
         Batch::instance()->restart();
         return;
      }
      Batch::instance()->updateLogConfirmation();
   }
   hV13AdvantageHeader* pAdvgV13LoggerHeader = (hV13AdvantageHeader*)Message::instance(Message::INBOUND)->data();
   m_strLogOpenTimestamp = timer::NonStopClock::getYYYYMMDDHHMMSShh(pAdvgV13LoggerHeader->sHdrTimestamp1);
   m_strLoggerName = APAdvgHeader::instance()->getLoggerName();
   Control* pControl = Control::locate(m_strLoggerName,m_strLogOpenTimestamp);
   if (APAdvgHeader::instance()->getMsgCode() != 904)
      pControl->updateCDNHash(APAdvgHeader::instance()->getAPHash());
#ifdef _LITTLE_ENDIAN
   char szBuffer[64];
   Trace::put(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"hash value sent %d",ntohl(*((unsigned int*)(Message::instance(Message::INBOUND)->data() + 8)))));
   Batch::instance()->addRecord(ntohl(*((unsigned int*)(Message::instance(Message::INBOUND)->data() + 8))));
#else
   Batch::instance()->addRecord(*((unsigned int*)(Message::instance(Message::INBOUND)->data() + 8)));
#endif
   string strYYYYMMDDHHMMSShh(NonStopClock::getYYYYMMDDHHMMSShh(pAdvgV13LoggerHeader->sFiller));
   APEventHandler::instance()->update(m_strLoggerName,strYYYYMMDDHHMMSShh);
   Batch::instance()->update(Message::instance(Message::INBOUND)->getDestination(),strYYYYMMDDHHMMSShh);
  //## end qr::AdvgAPTranHandler::update%37F914DD0170.body
}

// Additional Declarations
  //## begin qr::AdvgAPTranHandler%37F8F0900269.declarations preserve=yes
  //## end qr::AdvgAPTranHandler%37F8F0900269.declarations

} // namespace qr

//## begin module%37F8EFFC0082.epilog preserve=yes
//## end module%37F8EFFC0082.epilog
