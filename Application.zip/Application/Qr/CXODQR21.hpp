//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EC7398A037B.cm preserve=no
//## end module%5EC7398A037B.cm

//## begin module%5EC7398A037B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5EC7398A037B.cp

//## Module: CXOSQR21%5EC7398A037B; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR21.hpp

#ifndef CXOSQR21_h
#define CXOSQR21_h 1

//## begin module%5EC7398A037B.additionalIncludes preserve=no
//## end module%5EC7398A037B.additionalIncludes

//## begin module%5EC7398A037B.includes preserve=yes
//## end module%5EC7398A037B.includes

#ifndef CXOSQR02_h
#include "CXODQR02.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class SwitchInterfacePool;
class Control;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;

} // namespace segment

//## begin module%5EC7398A037B.declarations preserve=no
//## end module%5EC7398A037B.declarations

//## begin module%5EC7398A037B.additionalDeclarations preserve=yes
//## end module%5EC7398A037B.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::PostilionControlHandler%5EC6DA6E01CF.preface preserve=yes
//## end qr::PostilionControlHandler%5EC6DA6E01CF.preface

//## Class: PostilionControlHandler%5EC6DA6E01CF
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5EC741C603AB;IF::Message { -> F}
//## Uses: <unnamed>%5EC742920250;Control { -> F}
//## Uses: <unnamed>%5EC742CB010E;segment::Segment { -> F}
//## Uses: <unnamed>%6391129802AB;SwitchInterfacePool { -> F}

class DllExport PostilionControlHandler : public APControlHandler  //## Inherits: <unnamed>%5EC6DAE80204
{
  //## begin qr::PostilionControlHandler%5EC6DA6E01CF.initialDeclarations preserve=yes
  //## end qr::PostilionControlHandler%5EC6DA6E01CF.initialDeclarations

  public:
    //## Constructors (generated)
      PostilionControlHandler();

    //## Constructors (specified)
      //## Operation: PostilionControlHandler%5EC7368C0347
      PostilionControlHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~PostilionControlHandler();


    //## Other Operations (specified)
      //## Operation: update%5EC73695008D
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin qr::PostilionControlHandler%5EC6DA6E01CF.public preserve=yes
      //## end qr::PostilionControlHandler%5EC6DA6E01CF.public

  protected:
    // Additional Protected Declarations
      //## begin qr::PostilionControlHandler%5EC6DA6E01CF.protected preserve=yes
      //## end qr::PostilionControlHandler%5EC6DA6E01CF.protected

  private:
    // Additional Private Declarations
      //## begin qr::PostilionControlHandler%5EC6DA6E01CF.private preserve=yes
      //## end qr::PostilionControlHandler%5EC6DA6E01CF.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin qr::PostilionControlHandler%5EC6DA6E01CF.implementation preserve=yes
      //## end qr::PostilionControlHandler%5EC6DA6E01CF.implementation

};

//## begin qr::PostilionControlHandler%5EC6DA6E01CF.postscript preserve=yes
//## end qr::PostilionControlHandler%5EC6DA6E01CF.postscript

} // namespace qr

//## begin module%5EC7398A037B.epilog preserve=yes
//## end module%5EC7398A037B.epilog


#endif
