//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3899EE3601C8.cm preserve=no
//## end module%3899EE3601C8.cm

//## begin module%3899EE3601C8.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3899EE3601C8.cp

//## Module: CXOSQR01%3899EE3601C8; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR01.hpp

#ifndef CXOSQR01_h
#define CXOSQR01_h 1

//## begin module%3899EE3601C8.additionalIncludes preserve=no
//## end module%3899EE3601C8.additionalIncludes

//## begin module%3899EE3601C8.includes preserve=yes
//## end module%3899EE3601C8.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class APEventHandler;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;

} // namespace segment

//## begin module%3899EE3601C8.declarations preserve=no
//## end module%3899EE3601C8.declarations

//## begin module%3899EE3601C8.additionalDeclarations preserve=yes
//## end module%3899EE3601C8.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::APAdvgHeader%389AEBA50287.preface preserve=yes
//## end qr::APAdvgHeader%389AEBA50287.preface

//## Class: APAdvgHeader%389AEBA50287
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%389B00F102D7;IF::Message { -> F}
//## Uses: <unnamed>%389B334300E6;IF::CodeTable { -> F}
//## Uses: <unnamed>%389C45B40343;segment::Segment { -> F}
//## Uses: <unnamed>%38A1D0AD0265;APEventHandler { -> F}

class APAdvgHeader : public reusable::Object  //## Inherits: <unnamed>%389AEC170372
{
  //## begin qr::APAdvgHeader%389AEBA50287.initialDeclarations preserve=yes
  //## end qr::APAdvgHeader%389AEBA50287.initialDeclarations

  public:
    //## Constructors (generated)
      APAdvgHeader();

    //## Destructor (generated)
      virtual ~APAdvgHeader();


    //## Other Operations (specified)
      //## Operation: instance%389AECB00386
      static APAdvgHeader* instance ();

      //## Operation: parse%389B43060373
      bool parse ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: ControlLoggerName%389C3FD5005D
      const string& getControlLoggerName () const
      {
        //## begin qr::APAdvgHeader::getControlLoggerName%389C3FD5005D.get preserve=no
        return m_strControlLoggerName;
        //## end qr::APAdvgHeader::getControlLoggerName%389C3FD5005D.get
      }


      //## Attribute: APHash%38A1A7C40284
      const double& getAPHash () const
      {
        //## begin qr::APAdvgHeader::getAPHash%38A1A7C40284.get preserve=no
        return m_dAPHash;
        //## end qr::APAdvgHeader::getAPHash%38A1A7C40284.get
      }


      //## Attribute: LoggerName%389B468D0032
      const string& getLoggerName () const
      {
        //## begin qr::APAdvgHeader::getLoggerName%389B468D0032.get preserve=no
        return m_strLoggerName;
        //## end qr::APAdvgHeader::getLoggerName%389B468D0032.get
      }


      //## Attribute: Logger%389B4DF301C6
      const string& getLogger () const
      {
        //## begin qr::APAdvgHeader::getLogger%389B4DF301C6.get preserve=no
        return m_strLogger;
        //## end qr::APAdvgHeader::getLogger%389B4DF301C6.get
      }


      //## Attribute: MsgCode%38A1B75D039E
      const int& getMsgCode () const
      {
        //## begin qr::APAdvgHeader::getMsgCode%38A1B75D039E.get preserve=no
        return m_iMsgCode;
        //## end qr::APAdvgHeader::getMsgCode%38A1B75D039E.get
      }


      //## Attribute: APCount%38A1C22202A8
      const int& getAPCount () const
      {
        //## begin qr::APAdvgHeader::getAPCount%38A1C22202A8.get preserve=no
        return m_lAPCount;
        //## end qr::APAdvgHeader::getAPCount%38A1C22202A8.get
      }


      //## Attribute: LogOpenTime%5166BA290129
      const string& getLogOpenTime () const
      {
        //## begin qr::APAdvgHeader::getLogOpenTime%5166BA290129.get preserve=no
        return m_strLogOpenTime;
        //## end qr::APAdvgHeader::getLogOpenTime%5166BA290129.get
      }


    // Additional Public Declarations
      //## begin qr::APAdvgHeader%389AEBA50287.public preserve=yes
      //## end qr::APAdvgHeader%389AEBA50287.public

  protected:
    // Additional Protected Declarations
      //## begin qr::APAdvgHeader%389AEBA50287.protected preserve=yes
      //## end qr::APAdvgHeader%389AEBA50287.protected

  private:

    //## Other Operations (specified)
      //## Operation: setLogger%38A168A80391
      bool setLogger ();

      //## Operation: set904Logger%38A1EEB70245
      bool set904Logger ();

      //## Operation: setV13Logger%389C465A037E
      void setV13Logger (string& strLoggerName);

      //## Operation: getFinancialData%38A1A6AD03A5
      void getFinancialData ();

      //## Operation: getControlData%38A1C1910169
      void getControlData ();

    // Additional Private Declarations
      //## begin qr::APAdvgHeader%389AEBA50287.private preserve=yes
      //## end qr::APAdvgHeader%389AEBA50287.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin qr::APAdvgHeader::ControlLoggerName%389C3FD5005D.attr preserve=no  public: string {V} 
      string m_strControlLoggerName;
      //## end qr::APAdvgHeader::ControlLoggerName%389C3FD5005D.attr

      //## Attribute: Instance%389AEC1F00AC
      //## begin qr::APAdvgHeader::Instance%389AEC1F00AC.attr preserve=no  private: static APAdvgHeader* {U} 0
      static APAdvgHeader* m_pInstance;
      //## end qr::APAdvgHeader::Instance%389AEC1F00AC.attr

      //## begin qr::APAdvgHeader::APHash%38A1A7C40284.attr preserve=no  public: double {U} 0
      double m_dAPHash;
      //## end qr::APAdvgHeader::APHash%38A1A7C40284.attr

      //## begin qr::APAdvgHeader::LoggerName%389B468D0032.attr preserve=no  public: string {U} 
      string m_strLoggerName;
      //## end qr::APAdvgHeader::LoggerName%389B468D0032.attr

      //## begin qr::APAdvgHeader::Logger%389B4DF301C6.attr preserve=no  public: string {U} 
      string m_strLogger;
      //## end qr::APAdvgHeader::Logger%389B4DF301C6.attr

      //## Attribute: NodeName%389C404E006B
      //## begin qr::APAdvgHeader::NodeName%389C404E006B.attr preserve=no  private: string {U} 
      string m_strNodeName;
      //## end qr::APAdvgHeader::NodeName%389C404E006B.attr

      //## begin qr::APAdvgHeader::MsgCode%38A1B75D039E.attr preserve=no  public: int {U} 0
      int m_iMsgCode;
      //## end qr::APAdvgHeader::MsgCode%38A1B75D039E.attr

      //## begin qr::APAdvgHeader::APCount%38A1C22202A8.attr preserve=no  public: int {U} 0
      int m_lAPCount;
      //## end qr::APAdvgHeader::APCount%38A1C22202A8.attr

      //## Attribute: EBCDIC%38A315A402B8
      //## begin qr::APAdvgHeader::EBCDIC%38A315A402B8.attr preserve=no  public: bool {U} false
      bool m_bEBCDIC;
      //## end qr::APAdvgHeader::EBCDIC%38A315A402B8.attr

      //## begin qr::APAdvgHeader::LogOpenTime%5166BA290129.attr preserve=no  public: string {V} 
      string m_strLogOpenTime;
      //## end qr::APAdvgHeader::LogOpenTime%5166BA290129.attr

    // Additional Implementation Declarations
      //## begin qr::APAdvgHeader%389AEBA50287.implementation preserve=yes
      //## end qr::APAdvgHeader%389AEBA50287.implementation

};

//## begin qr::APAdvgHeader%389AEBA50287.postscript preserve=yes
//## end qr::APAdvgHeader%389AEBA50287.postscript

} // namespace qr

//## begin module%3899EE3601C8.epilog preserve=yes
//## end module%3899EE3601C8.epilog


#endif
