//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%420B8AF20109.cm preserve=no
//## end module%420B8AF20109.cm

//## begin module%420B8AF20109.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%420B8AF20109.cp

//## Module: CXOSQR14%420B8AF20109; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR14.hpp

#ifndef CXOSQR14_h
#define CXOSQR14_h 1

//## begin module%420B8AF20109.additionalIncludes preserve=no
//## end module%420B8AF20109.additionalIncludes

//## begin module%420B8AF20109.includes preserve=yes
//## end module%420B8AF20109.includes

#ifndef CXOSRU14_h
#include "CXODRU14.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Batch;
class SwitchInterfacePool;
class APISTHeader;
class APEventHandler;
class Control;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class DateTime;
class Extract;
class Console;
class Decimal;
class Queue;
class CodeTable;
class Trace;
class Log;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;

} // namespace segment

//## begin module%420B8AF20109.declarations preserve=no
//## end module%420B8AF20109.declarations

//## begin module%420B8AF20109.additionalDeclarations preserve=yes
//## end module%420B8AF20109.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::ISTAPTranHandler%420B7B38033C.preface preserve=yes
//## end qr::ISTAPTranHandler%420B7B38033C.preface

//## Class: ISTAPTranHandler%420B7B38033C
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%420B7EAC0232;APEventHandler { -> F}
//## Uses: <unnamed>%420B7EAE03C8;Batch { -> F}
//## Uses: <unnamed>%420B7EB5006D;IF::CodeTable { -> F}
//## Uses: <unnamed>%420B7EB7036B;IF::Console { -> F}
//## Uses: <unnamed>%420B7EBA030D;Control { -> F}
//## Uses: <unnamed>%420B7EBD0280;IF::DateTime { -> F}
//## Uses: <unnamed>%420B7EC002EE;IF::Decimal { -> F}
//## Uses: <unnamed>%420B7EC30167;IF::Extract { -> F}
//## Uses: <unnamed>%420B7ECA0148;IF::Trace { -> F}
//## Uses: <unnamed>%420B7ED501F4;segment::Segment { -> F}
//## Uses: <unnamed>%420B7EDB02AF;IF::Queue { -> F}
//## Uses: <unnamed>%420B7EE001F4;IF::Message { -> F}
//## Uses: <unnamed>%420B7EE4006D;IF::Log { -> F}
//## Uses: <unnamed>%523C60C00202;APISTHeader { -> F}
//## Uses: <unnamed>%639111C80043;SwitchInterfacePool { -> F}

class DllExport ISTAPTranHandler : public reusable::Handler  //## Inherits: <unnamed>%420B7D33030D
{
  //## begin qr::ISTAPTranHandler%420B7B38033C.initialDeclarations preserve=yes
  //## end qr::ISTAPTranHandler%420B7B38033C.initialDeclarations

  public:
    //## Constructors (generated)
      ISTAPTranHandler();

    //## Constructors (specified)
      //## Operation: ISTAPTranHandler%420B7F6403B9
      ISTAPTranHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~ISTAPTranHandler();


    //## Other Operations (specified)
      //## Operation: update%420B7F850242
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Logging%420B804C003E
      static const bool getLogging ()
      {
        //## begin qr::ISTAPTranHandler::getLogging%420B804C003E.get preserve=no
        return m_bLogging;
        //## end qr::ISTAPTranHandler::getLogging%420B804C003E.get
      }

      static void setLogging (bool value)
      {
        //## begin qr::ISTAPTranHandler::setLogging%420B804C003E.set preserve=no
        m_bLogging = value;
        //## end qr::ISTAPTranHandler::setLogging%420B804C003E.set
      }


    // Additional Public Declarations
      //## begin qr::ISTAPTranHandler%420B7B38033C.public preserve=yes
      //## end qr::ISTAPTranHandler%420B7B38033C.public

  protected:
    // Additional Protected Declarations
      //## begin qr::ISTAPTranHandler%420B7B38033C.protected preserve=yes
      //## end qr::ISTAPTranHandler%420B7B38033C.protected

  private:
    // Additional Private Declarations
      //## begin qr::ISTAPTranHandler%420B7B38033C.private preserve=yes
      //## end qr::ISTAPTranHandler%420B7B38033C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: LoggerName%420B8042004E
      //## begin qr::ISTAPTranHandler::LoggerName%420B8042004E.attr preserve=no  private: string {U} 
      string m_strLoggerName;
      //## end qr::ISTAPTranHandler::LoggerName%420B8042004E.attr

      //## Attribute: LogOpenTimestamp%420B804800BB
      //## begin qr::ISTAPTranHandler::LogOpenTimestamp%420B804800BB.attr preserve=no  private: string {U} 
      string m_strLogOpenTimestamp;
      //## end qr::ISTAPTranHandler::LogOpenTimestamp%420B804800BB.attr

      //## begin qr::ISTAPTranHandler::Logging%420B804C003E.attr preserve=no  public: static bool {U} false
      static bool m_bLogging;
      //## end qr::ISTAPTranHandler::Logging%420B804C003E.attr

    // Additional Implementation Declarations
      //## begin qr::ISTAPTranHandler%420B7B38033C.implementation preserve=yes
      //## end qr::ISTAPTranHandler%420B7B38033C.implementation

};

//## begin qr::ISTAPTranHandler%420B7B38033C.postscript preserve=yes
//## end qr::ISTAPTranHandler%420B7B38033C.postscript

} // namespace qr

//## begin module%420B8AF20109.epilog preserve=yes
//## end module%420B8AF20109.epilog


#endif
