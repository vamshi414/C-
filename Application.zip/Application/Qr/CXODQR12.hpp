//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%393559D102A1.cm preserve=no
//## end module%393559D102A1.cm

//## begin module%393559D102A1.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%393559D102A1.cp

//## Module: CXOSQR12%393559D102A1; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR12.hpp

#ifndef CXOSQR12_h
#define CXOSQR12_h 1

//## begin module%393559D102A1.additionalIncludes preserve=no
//## end module%393559D102A1.additionalIncludes

//## begin module%393559D102A1.includes preserve=yes
// $Date:   Apr 09 2004 07:48:40  $ $Author:   D02405  $ $Revision:   1.6  $
//## end module%393559D102A1.includes

#ifndef CXOSRU14_h
#include "CXODRU14.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Batch;
class SwitchInterfacePool;
class APEventHandler;
class Control;
} // namespace qr

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class ExternalMessageSegment;
} // namespace repositorysegment

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class DateTime;
class Extract;
class Console;
class Queue;
class CodeTable;
class Trace;
class Log;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;

} // namespace segment

//## begin module%393559D102A1.declarations preserve=no
//## end module%393559D102A1.declarations

//## begin module%393559D102A1.additionalDeclarations preserve=yes
//## end module%393559D102A1.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::ExtAPTranHandler%3935581501F9.preface preserve=yes
//## end qr::ExtAPTranHandler%3935581501F9.preface

//## Class: ExtAPTranHandler%3935581501F9
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39355D840307;APEventHandler { -> F}
//## Uses: <unnamed>%39355D870225;Batch { -> F}
//## Uses: <unnamed>%39355D8A008F;IF::CodeTable { -> F}
//## Uses: <unnamed>%39355D8C0218;IF::Console { -> F}
//## Uses: <unnamed>%39355D8F02B3;Control { -> F}
//## Uses: <unnamed>%39355D9200D7;IF::DateTime { -> F}
//## Uses: <unnamed>%39355D9403DD;IF::Extract { -> F}
//## Uses: <unnamed>%39355D970214;IF::Log { -> F}
//## Uses: <unnamed>%39355D9A02CD;IF::Message { -> F}
//## Uses: <unnamed>%39355D9D0155;IF::Queue { -> F}
//## Uses: <unnamed>%39355DA702B7;IF::Trace { -> F}
//## Uses: <unnamed>%39355DAA013F;segment::Segment { -> F}
//## Uses: <unnamed>%3937C7570043;repositorysegment::ExternalMessageSegment { -> F}
//## Uses: <unnamed>%639111390210;SwitchInterfacePool { -> F}

class ExtAPTranHandler : public reusable::Handler  //## Inherits: <unnamed>%3935584C00AD
{
  //## begin qr::ExtAPTranHandler%3935581501F9.initialDeclarations preserve=yes
  //## end qr::ExtAPTranHandler%3935581501F9.initialDeclarations

  public:
    //## Constructors (generated)
      ExtAPTranHandler();

    //## Constructors (specified)
      //## Operation: ExtAPTranHandler%39355DC5001C
      ExtAPTranHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~ExtAPTranHandler();


    //## Other Operations (specified)
      //## Operation: update%39355DC302FE
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Logging%39355EBB0138
      static const bool getLogging ()
      {
        //## begin qr::ExtAPTranHandler::getLogging%39355EBB0138.get preserve=no
        return m_bLogging;
        //## end qr::ExtAPTranHandler::getLogging%39355EBB0138.get
      }

      static void setLogging (bool value)
      {
        //## begin qr::ExtAPTranHandler::setLogging%39355EBB0138.set preserve=no
        m_bLogging = value;
        //## end qr::ExtAPTranHandler::setLogging%39355EBB0138.set
      }


    // Additional Public Declarations
      //## begin qr::ExtAPTranHandler%3935581501F9.public preserve=yes
      //## end qr::ExtAPTranHandler%3935581501F9.public

  protected:
    // Additional Protected Declarations
      //## begin qr::ExtAPTranHandler%3935581501F9.protected preserve=yes
      //## end qr::ExtAPTranHandler%3935581501F9.protected

  private:
    // Additional Private Declarations
      //## begin qr::ExtAPTranHandler%3935581501F9.private preserve=yes
      //## end qr::ExtAPTranHandler%3935581501F9.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: LoggerName%39355E78034E
      //## begin qr::ExtAPTranHandler::LoggerName%39355E78034E.attr preserve=no  private: string {U} 
      string m_strLoggerName;
      //## end qr::ExtAPTranHandler::LoggerName%39355E78034E.attr

      //## Attribute: LogOpenTimestamp%39355E7A00DA
      //## begin qr::ExtAPTranHandler::LogOpenTimestamp%39355E7A00DA.attr preserve=no  private: string {U} 
      string m_strLogOpenTimestamp;
      //## end qr::ExtAPTranHandler::LogOpenTimestamp%39355E7A00DA.attr

      //## begin qr::ExtAPTranHandler::Logging%39355EBB0138.attr preserve=no  public: static bool {U} false
      static bool m_bLogging;
      //## end qr::ExtAPTranHandler::Logging%39355EBB0138.attr

    // Additional Implementation Declarations
      //## begin qr::ExtAPTranHandler%3935581501F9.implementation preserve=yes
      //## end qr::ExtAPTranHandler%3935581501F9.implementation

};

//## begin qr::ExtAPTranHandler%3935581501F9.postscript preserve=yes
//## end qr::ExtAPTranHandler%3935581501F9.postscript

} // namespace qr

//## begin module%393559D102A1.epilog preserve=yes
//## end module%393559D102A1.epilog


#endif
