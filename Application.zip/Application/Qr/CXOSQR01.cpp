//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3899EE380293.cm preserve=no
//## end module%3899EE380293.cm

//## begin module%3899EE380293.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3899EE380293.cp

//## Module: CXOSQR01%3899EE380293; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR01.cpp

//## begin module%3899EE380293.additionalIncludes preserve=no
//## end module%3899EE380293.additionalIncludes

//## begin module%3899EE380293.includes preserve=yes
#ifdef _WIN32
#include <winsock.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
#include "CXODRS28.hpp"
#ifndef CXODRU37_h
#include "CXODRU37.hpp"
#endif
//## end module%3899EE380293.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif
#ifndef CXOSQR01_h
#include "CXODQR01.hpp"
#endif


//## begin module%3899EE380293.declarations preserve=no
//## end module%3899EE380293.declarations

//## begin module%3899EE380293.additionalDeclarations preserve=yes
struct hAdvgControlMessage
{
#ifdef MVS
   short siHdrMsgCode;
   short siHdrMsgStep;
#else
   char sHdrMsgCode[4];
#endif
   char sSource[6];
   char sDestination[6];
   char sInputOnlyInfo[8];
   short siReplyExpected;
   short siMsgLength;
   char sLoggerName[6];
   char sLogOpenTime[6];
   int lUnloadRecordCount;
   int lUnloadTstampHash;
   int lUnloadAmtHash[2];
};
//## end module%3899EE380293.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::APAdvgHeader 

//## begin qr::APAdvgHeader::Instance%389AEC1F00AC.attr preserve=no  private: static qr::APAdvgHeader* {U} 0
qr::APAdvgHeader* APAdvgHeader::m_pInstance = 0;
//## end qr::APAdvgHeader::Instance%389AEC1F00AC.attr

APAdvgHeader::APAdvgHeader()
  //## begin APAdvgHeader::APAdvgHeader%389AEBA50287_const.hasinit preserve=no
      : m_dAPHash(0),
        m_iMsgCode(0),
        m_lAPCount(0),
        m_bEBCDIC(false)
  //## end APAdvgHeader::APAdvgHeader%389AEBA50287_const.hasinit
  //## begin APAdvgHeader::APAdvgHeader%389AEBA50287_const.initialization preserve=yes
  //## end APAdvgHeader::APAdvgHeader%389AEBA50287_const.initialization
{
  //## begin qr::APAdvgHeader::APAdvgHeader%389AEBA50287_const.body preserve=yes
   memcpy(m_sID,"QR01",4);
  //## end qr::APAdvgHeader::APAdvgHeader%389AEBA50287_const.body
}


APAdvgHeader::~APAdvgHeader()
{
  //## begin qr::APAdvgHeader::~APAdvgHeader%389AEBA50287_dest.body preserve=yes
  //## end qr::APAdvgHeader::~APAdvgHeader%389AEBA50287_dest.body
}



//## Other Operations (implementation)
APAdvgHeader* APAdvgHeader::instance ()
{
  //## begin qr::APAdvgHeader::instance%389AECB00386.body preserve=yes
   if (m_pInstance == 0)
      m_pInstance = new APAdvgHeader();
   return m_pInstance;
  //## end qr::APAdvgHeader::instance%389AECB00386.body
}

bool APAdvgHeader::parse ()
{
  //## begin qr::APAdvgHeader::parse%389B43060373.body preserve=yes
   m_dAPHash = 0;
   m_strNodeName.erase();
   m_bEBCDIC = false;
   if (!setLogger())
      return false;
   if (m_iMsgCode == 400)
      getFinancialData();
   else
   if (m_iMsgCode == 904)
      getControlData();
   return true;
  //## end qr::APAdvgHeader::parse%389B43060373.body
}

bool APAdvgHeader::setLogger ()
{
  //## begin qr::APAdvgHeader::setLogger%38A168A80391.body preserve=yes
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)Message::instance(Message::INBOUND)->data();
   m_strLogger.assign(pV13AdvantageHeader->sHdrDestination,6);
   if (m_strLogger[0] != '$')
      CodeTable::translate((char*)m_strLogger.data(),6,CodeTable::CX_ASCII_TO_EBCDIC);
   else
      m_bEBCDIC = true;
   if (!APEventHandler::instance()->isValidLoggerName(m_strLogger))
      return false;
   m_strNodeName.assign(pV13AdvantageHeader->sNode,8);
   if (!m_bEBCDIC)
      CodeTable::translate((char*)m_strNodeName.data(),8,CodeTable::CX_ASCII_TO_EBCDIC);
   size_t n = m_strNodeName.find_first_of(' ');
   if (n != string::npos)
      m_strNodeName.erase(n);
   setV13Logger(m_strLoggerName);
   m_iMsgCode = ntohs(pV13AdvantageHeader->siHdrMsgCode);
   if (m_iMsgCode == 904)
   {
      if (!set904Logger())
         return false;
   }
   return true;
  //## end qr::APAdvgHeader::setLogger%38A168A80391.body
}

bool APAdvgHeader::set904Logger ()
{
  //## begin qr::APAdvgHeader::set904Logger%38A1EEB70245.body preserve=yes
   hAdvgControlMessage* pAdvgControlMessage = (hAdvgControlMessage*)(Message::instance(Message::INBOUND)->data() + 24);
   m_strLogger.assign(pAdvgControlMessage->sLoggerName, 6);
   if (m_strLogger[0] != '$')
      CodeTable::translate((char*)m_strLogger.data(),6,CodeTable::CX_ASCII_TO_EBCDIC);
   if (!APEventHandler::instance()->isValidLoggerName(m_strLogger))
      return false;
   setV13Logger(m_strControlLoggerName);
   return true;
  //## end qr::APAdvgHeader::set904Logger%38A1EEB70245.body
}

void APAdvgHeader::setV13Logger (string& strLoggerName)
{
  //## begin qr::APAdvgHeader::setV13Logger%389C465A037E.body preserve=yes
   // ** format the Logger Name:- 'Node.LoggerName'   ***
   strLoggerName = m_strNodeName;
   strLoggerName += ".";
   strLoggerName += m_strLogger;
  //## end qr::APAdvgHeader::setV13Logger%389C465A037E.body
}

void APAdvgHeader::getFinancialData ()
{
  //## begin qr::APAdvgHeader::getFinancialData%38A1A6AD03A5.body preserve=yes
   hFinancialSeg1* pFinancialSeg1 = (hFinancialSeg1*)(Message::instance(Message::INBOUND)->data() + sizeof(hV13AdvantageHeader));
   m_dAPHash = Segment::lltof(ntohl(pFinancialSeg1->lAmtTran[0]),ntohl(pFinancialSeg1->lAmtTran[1]));
  //## end qr::APAdvgHeader::getFinancialData%38A1A6AD03A5.body
}

void APAdvgHeader::getControlData ()
{
  //## begin qr::APAdvgHeader::getControlData%38A1C1910169.body preserve=yes
   hAdvgControlMessage* pAdvgControlMessage = (hAdvgControlMessage*)(Message::instance(Message::INBOUND)->data() + 24);
   m_dAPHash = Segment::lltof(ntohl(pAdvgControlMessage->lUnloadAmtHash[0]),ntohl(pAdvgControlMessage->lUnloadAmtHash[1]));
   m_lAPCount = ntohl(pAdvgControlMessage->lUnloadRecordCount);
   m_strLogOpenTime.assign(pAdvgControlMessage->sLogOpenTime,6);
  //## end qr::APAdvgHeader::getControlData%38A1C1910169.body
}

// Additional Declarations
  //## begin qr::APAdvgHeader%389AEBA50287.declarations preserve=yes
  //## end qr::APAdvgHeader%389AEBA50287.declarations

} // namespace qr

//## begin module%3899EE380293.epilog preserve=yes
//## end module%3899EE380293.epilog
