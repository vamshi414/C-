//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%378E2EFE02DF.cm preserve=no
//## end module%378E2EFE02DF.cm

//## begin module%378E2EFE02DF.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%378E2EFE02DF.cp

//## Module: CXOSQR05%378E2EFE02DF; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR05.cpp

//## begin module%378E2EFE02DF.additionalIncludes preserve=no
//## end module%378E2EFE02DF.additionalIncludes

//## begin module%378E2EFE02DF.includes preserve=yes
// $Date$ $Author$ $Revision$
#include <stdio.h>
#include "CXODRU24.hpp"
#include "CXODIF11.hpp"
//## end module%378E2EFE02DF.includes

#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSQR04_h
#include "CXODQR04.hpp"
#endif
#ifndef CXOSQR06_h
#include "CXODQR06.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSTM06_h
#include "CXODTM06.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSDB05_h
#include "CXODDB05.hpp"
#endif
#ifndef CXOSQR00_h
#include "CXODQR00.hpp"
#endif
#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif


//## begin module%378E2EFE02DF.declarations preserve=no
//## end module%378E2EFE02DF.declarations

//## begin module%378E2EFE02DF.additionalDeclarations preserve=yes
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
//## end module%378E2EFE02DF.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::APEventHandler 

//## begin qr::APEventHandler::Instance%378E30B302AB.attr preserve=no  private: static qr::APEventHandler* {U} 0
qr::APEventHandler* APEventHandler::m_pInstance = 0;
//## end qr::APEventHandler::Instance%378E30B302AB.attr

//## begin qr::APEventHandler::PrimaryQR%3D612243026E.attr preserve=no  public: static bool {U} false
bool APEventHandler::m_bPrimaryQR = false;
//## end qr::APEventHandler::PrimaryQR%3D612243026E.attr

APEventHandler::APEventHandler()
  //## begin APEventHandler::APEventHandler%378E2E9102B0_const.hasinit preserve=no
      : m_nCutState(IDLE),
        m_nEodState(IDLE),
        m_strAuditTime("110000"),
        m_nContextQueryType(AUDITC)
  //## end APEventHandler::APEventHandler%378E2E9102B0_const.hasinit
  //## begin APEventHandler::APEventHandler%378E2E9102B0_const.initialization preserve=yes
  //## end APEventHandler::APEventHandler%378E2E9102B0_const.initialization
{
  //## begin qr::APEventHandler::APEventHandler%378E2E9102B0_const.body preserve=yes
   memcpy(m_sID,"QR05",4);
   Extract::instance()->attach(this);
   m_hTimer[FIVE_SECOND].attach(this);
   m_hTimer[NINE_AM].attach(this);
   m_hTimer[NINE_AM].setAlarm(m_strAuditTime.data());
  //## end qr::APEventHandler::APEventHandler%378E2E9102B0_const.body
}


APEventHandler::~APEventHandler()
{
  //## begin qr::APEventHandler::~APEventHandler%378E2E9102B0_dest.body preserve=yes
   Extract::instance()->detach(this);
   m_hAPLoggers.erase(m_hAPLoggers.begin(),m_hAPLoggers.end());
   m_hCutTimeStamps.erase(m_hCutTimeStamps.begin(),m_hCutTimeStamps.end());
  //## end qr::APEventHandler::~APEventHandler%378E2E9102B0_dest.body
}



//## Other Operations (implementation)
void APEventHandler::auditControls ()
{
  //## begin qr::APEventHandler::auditControls%387642AB0032.body preserve=yes
   Trace::put("APEventHandler::auditControls()",31);
   char szTime[7] = {"000000"};
   char szDate[9] = {"00000000"};
   string strCurrentDateTime = Clock::instance()->getYYYYMMDDHHMMSS();
   memcpy(szDate,(char*)strCurrentDateTime.data(),8);
   string strTodaysDate = szDate;
   memcpy(szTime,(char*)strCurrentDateTime.data() + 8,6);
   strTodaysDate += szTime;
   memcpy(szDate,(char*)strCurrentDateTime.data(),8);
   int iDay = atoi(szDate + 6);
   szDate[6] = '\0';
   int iMonth = atoi(szDate + 4);
   szDate[4] = '\0';
   int iYear = atoi(szDate);
   Date hDate(iYear,iMonth,iDay);
   string strRecord;
   Extract::instance()->getRecord("DUSER   ",strRecord);
   if (strRecord.find("CXOPOI00") != string::npos)
      hDate -= 2;
   else
      hDate -= 1;
   string strPreviousDate = hDate.asString("%Y%m%d");
   strPreviousDate += '%';
   auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
   m_hQuery.reset();
   m_hQuery.setDistinct(false);
   m_hQuery.bind("TASK_CONTEXT","CONTEXT_KEY",Column::STRING,&m_strCONTEXT_KEY);
   m_hQuery.bind("TASK_CONTEXT","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA);
   m_hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=", "C");
   m_hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_KEY","LIKE", strPreviousDate.c_str());
   m_hQuery.setBasicPredicate("TASK_CONTEXT","TASKID","=",Application::instance()->name().c_str());
   m_hQuery.attach(this);
   m_nContextQueryType = AUDITC;
   pSelectStatement->execute(m_hQuery);
   if (m_bPrimaryQR)
   {
      short iNull;
      m_hQuery.reset();
      m_hQuery.setDistinct(false);
      m_hQuery.bind("TASK_CONTEXT","CONTEXT_KEY",Column::STRING,&m_strCONTEXT_KEY);
      m_hQuery.bind("TASK_CONTEXT","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA,&iNull,"MAX");
      m_hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=", "L");
      m_hQuery.setGroupByClause("TASK_CONTEXT.CONTEXT_KEY");
      m_hQuery.attach(this);
      m_nContextQueryType = AUDITL;
      pSelectStatement->execute(m_hQuery);
   }
  //## end qr::APEventHandler::auditControls%387642AB0032.body
}

int APEventHandler::cut ()
{
  //## begin qr::APEventHandler::cut%378E484600BE.body preserve=yes
   m_iPendingCount = 0;
   if (!("0000000000000000" == m_strCutTimestamp))
   {
      short iNull;
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      m_hQuery.reset();
      m_hQuery.bind("TASK_CONTEXT","CONTEXT_KEY",Column::STRING,&m_strCONTEXT_KEY);
      m_hQuery.bind("TASK_CONTEXT","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA,&iNull,"MAX");
      m_hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=", "L");
      m_hQuery.setGroupByClause("TASK_CONTEXT.CONTEXT_KEY");
      m_hQuery.attach(this);
      m_nContextQueryType = CUT;
      pSelectStatement->execute(m_hQuery);
   }

   if (m_iPendingCount > 0)
   {
      char message[50];
      snprintf(message,sizeof(message),"Pending Cut because %d files have not caught up",m_iPendingCount);
      Trace::put(message,strlen(message));
      Console::display("ST510",m_iPendingCount);
      m_nCutState = PENDING;
      MinuteTimer::instance()->attach(this);
      return 1;
   }

   Log::cut("CUSTLOG");
   m_nCutState = IDLE;
   m_hCutTimeStamps.pop_front();
   if ("0000000000000000" == m_strCutTimestamp)
      if (!m_hCutTimeStamps.empty())
         m_hCutTimeStamps.pop_front();

   auto_ptr<Context> pContext(new Context(Application::instance()->image(),Application::instance()->name()));
   string strData(m_strCutTimestamp);
   strData += " Complete";
   Trace::put(strData.c_str(),25);

   if(!pContext->put("CUTLOG", strData.c_str()))
   {
      Console::display("ST503");
      Batch::instance()->restart();
   }
   else
      Database::instance()->commit();

   return 0;
  //## end qr::APEventHandler::cut%378E484600BE.body
}

int APEventHandler::eod ()
{
  //## begin qr::APEventHandler::eod%378E48550033.body preserve=yes
   m_iPendingCount = 0;
   if (!("0000000000000000" == m_strEodTimestamp))
   {
      short iNull;
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      m_hQuery.reset();
      m_hQuery.bind("TASK_CONTEXT","CONTEXT_KEY",Column::STRING,&m_strCONTEXT_KEY);
      m_hQuery.bind("TASK_CONTEXT","CONTEXT_DATA",Column::STRING,&m_strCONTEXT_DATA,&iNull,"MAX");
      m_hQuery.setBasicPredicate("TASK_CONTEXT","CONTEXT_TYPE","=", "L");
      m_hQuery.setGroupByClause("TASK_CONTEXT.CONTEXT_KEY");
      m_hQuery.attach(this);
      m_nContextQueryType = EOD;
      pSelectStatement->execute(m_hQuery);
   }

   if (m_iPendingCount > 0)
   {
      char message[50];
      snprintf(message,sizeof(message),"Pending EOD because %d files have not caught up",m_iPendingCount);
      Trace::put(message,strlen(message));
      Console::display("ST511",m_iPendingCount);
      m_nEodState = PENDING;
      MinuteTimer::instance()->attach(this);
      return 1;
   }

   Log::endOfDay("CUSTLOG");
   m_nEodState = IDLE;

   auto_ptr<Context> pContext(new Context(Application::instance()->image(),Application::instance()->name()));
   string strData(m_strEodTimestamp);
   strData = strData + " Complete";

   if(!pContext->put("EOD", strData.c_str()))
   {
      Console::display("ST503");
      Batch::instance()->restart();
   }
   else
      Database::instance()->commit();

   return 0;
  //## end qr::APEventHandler::eod%378E48550033.body
}

APEventHandler* APEventHandler::instance ()
{
  //## begin qr::APEventHandler::instance%378E312802E5.body preserve=yes
   if(m_pInstance == 0)
      m_pInstance = new APEventHandler();

   return(m_pInstance);
  //## end qr::APEventHandler::instance%378E312802E5.body
}

bool APEventHandler::isValidLoggerName (string& strLoggerName)
{
  //## begin qr::APEventHandler::isValidLoggerName%37A6095F02AC.body preserve=yes
   if (m_strLoggerNameFmt.length() > 0)
   {
     if ((strLoggerName.length() >= m_strLoggerNameFmt.length()) &&
         (!memcmp(strLoggerName.data(),m_strLoggerNameFmt.data(),m_strLoggerNameFmt.length())))
       return true;
     else
     {
       // ST512 - "LOGGER NAME NOT VALID: @@@@@@@@"
       Console::display("ST512",strLoggerName.c_str());
       Batch::instance()->restart();
       return false;
     }
   }
   return true;
  //## end qr::APEventHandler::isValidLoggerName%37A6095F02AC.body
}

bool APEventHandler::locate (string& strLoggerName, string& strLatestTimestamp)
{
  //## begin qr::APEventHandler::locate%3C7E5AF201C2.body preserve=yes
   map<string,string,less<string> >::iterator pAPLogger;
   if ((pAPLogger = m_hAPLoggers.find(strLoggerName)) != m_hAPLoggers.end())
   {
      strLatestTimestamp = (*pAPLogger).second;
      return true;
   }
   return false;
  //## end qr::APEventHandler::locate%3C7E5AF201C2.body
}

void APEventHandler::refresh ()
{
  //## begin qr::APEventHandler::refresh%3870BCEE0389.body preserve=yes
   //fetch any pending loggers cut/eod timestamps
   Trace::put("APEventHandler::refresh()",25);
   auto_ptr<Context> pContext(new Context(Application::instance()->image(),Application::instance()->name()));
   string strData;

   if ((pContext->get("CUTLOG", strData) == true) && (strData.length() > 0))
   {
         Trace::put("APEventHandler::recfound",24);
         size_t pos = strData.find_last_not_of(' ');
         if (pos != string::npos)
            strData.erase(pos+1);
         if(strData.length() > 0 &&
            strData.find("Complete") == string::npos)
         {
            Trace::put("APEventHandler::attached",24);
            size_t start;
            for (start = 0; start <= strData.length()-16; start+= 16)
               setCutTimestamp(strData.substr(start, 16).c_str());
            m_nCutState = PENDING;
            MinuteTimer::instance()->attach(this);
         }
   }
   strData.erase();
   if ((pContext->get("EOD", strData) == true) && (strData.length() > 0))
   {
         if (strData.length() < 18
            || strData[17] != 'C')
         {
            rtrim(strData);
            setEodTimestamp(strData.c_str());
            m_nEodState = PENDING;
            MinuteTimer::instance()->attach(this);
         }
   }
  //## end qr::APEventHandler::refresh%3870BCEE0389.body
}

int APEventHandler::startCutLog ()
{
  //## begin qr::APEventHandler::startCutLog%3872594A0383.body preserve=yes
   Trace::put("APEventHandler::startCutLog()",29);
   auto_ptr<Context> pContext(new Context(Application::instance()->image(),Application::instance()->name()));
   m_nCutState = PENDING;

   string strData;
   list<string> ::iterator pCutTimestamp;
   for (pCutTimestamp = m_hCutTimeStamps.begin();
        (pCutTimestamp != m_hCutTimeStamps.end() && (strData.length() + m_strCutTimestamp.length() < 100));
        pCutTimestamp++)
        strData += pCutTimestamp->c_str();

   if (!pContext->put("CUTLOG", strData.c_str()))
   {
      Console::display("ST503");
      Batch::instance()->restart();
      return 1;
   }
   Database::instance()->commit();
   m_hTimer[FIVE_SECOND].set("00000500");
   return 0;
  //## end qr::APEventHandler::startCutLog%3872594A0383.body
}

int APEventHandler::startEod ()
{
  //## begin qr::APEventHandler::startEod%3872593D00DB.body preserve=yes
   auto_ptr<Context> pContext(new Context(Application::instance()->image(),Application::instance()->name()));
   m_nEodState = PENDING;
   if (!pContext->put("EOD", m_strEodTimestamp.c_str()))
   {
      Console::display("ST503");
      Batch::instance()->restart();
      return 1;
   }
   Database::instance()->commit();
   m_hTimer[FIVE_SECOND].set("00000500");
   return 0;
  //## end qr::APEventHandler::startEod%3872593D00DB.body
}

void APEventHandler::update (string& strLoggerName, string& strTimestamp)
{
  //## begin qr::APEventHandler::update%378E31C30306.body preserve=yes
   map<string,string,less<string> >::iterator pAPLogger;
   if ((pAPLogger = m_hAPLoggers.find(strLoggerName)) != m_hAPLoggers.end())
   {
      if ((*pAPLogger).second < strTimestamp)
         (*pAPLogger).second = strTimestamp;
   }
   else
      m_hAPLoggers.insert(map<string,string,less<string> >::value_type(strLoggerName,strTimestamp));
  //## end qr::APEventHandler::update%378E31C30306.body
}

void APEventHandler::update (Subject* pSubject)
{
  //## begin qr::APEventHandler::update%378E4C8702EB.body preserve=yes
   if (pSubject == Extract::instance())
   {
      if (Extract::instance()->getString("DUSER   ","AUDIT_TIMER=",m_strAuditTime,6))
         if (m_strAuditTime == "999999")
            m_hTimer[NINE_AM].cancel();
         else
            m_hTimer[NINE_AM].setAlarm(m_strAuditTime.data());
      if (!Extract::instance()->getString("DUSER   ","LOG_NAME_FMT=",m_strLoggerNameFmt,8))
         Console::display("ST532");
   }

   if (pSubject == MinuteTimer::instance() || pSubject == &m_hTimer[FIVE_SECOND])
   {
      int i = 0, j = 0;
      if (m_nCutState == PENDING)
         i = cut();

      if (m_nEodState == PENDING)
         j = eod();

      if ((i == 0) && (j == 0))
         MinuteTimer::instance()->detach(this);

      if (i == 0)
      {
         if (!m_hCutTimeStamps.empty())
         {
            m_strCutTimestamp = m_hCutTimeStamps.front();
            startCutLog();
         }
      }
   }

   if (pSubject == &m_hTimer[NINE_AM])
   {
      APEventHandler::auditControls();
      m_hTimer[NINE_AM].setAlarm(m_strAuditTime.data());
   }

   if (pSubject == &m_hQuery)
   {
      string strKey;
      vector<string> hTokens;
      int lAPCount;
      int lCDN_Count;
      double dAPHash;
      double dCDNHash;
      string strLatestDateTime;
      string strYesterday;
      DateTime hDateTime;
      IString strDateTime;
      int iLength;
      int i;
      Trace::put("APEventHandler::update - Query",-1);
      if (m_strCONTEXT_DATA.length() != 0)
      {
         switch (m_nContextQueryType)
         {
            case AUDITC:
               iLength = m_strCONTEXT_KEY.length();
               if (iLength < 16)
               {
                  Trace::put("APEventHandler::update - invalid timestamp for logger control record", -1);
                  return;
               }
               strKey = m_strCONTEXT_KEY.substr(0, 16) + "," + (iLength > 16 ? m_strCONTEXT_KEY.substr(17, min(size_t(11), (size_t)(iLength - 17))) : "");
               Buffer::parse(m_strCONTEXT_DATA, ",", hTokens);
               if (hTokens.size() < 4)
               {
                  Trace::put("APEventHandler::update - invalid values for logger control record", -1);
                  return;
               }
               lAPCount = atoi(hTokens[0].c_str());
               lCDN_Count = atoi(hTokens[1].c_str());
               dAPHash = atof(hTokens[2].c_str());
               dCDNHash = atof(hTokens[3].c_str());
               if (lAPCount == 0)
                  Console::display("ST514",strKey.c_str());
               else
               {
                  if (lAPCount != lCDN_Count)
                    Console::display("ST515",strKey.c_str());
                  if (dAPHash != 0 && (dAPHash != dCDNHash))
                     Console::display("ST516",strKey.c_str());
                }
               break;
            case AUDITL:
               strLatestDateTime = m_strCONTEXT_DATA;
               hDateTime.setCurrent(strDateTime);
               for (i=0; i<2; ++i)
                  hDateTime.timeAdjust(strDateTime,-720);
               strYesterday = (char*)strDateTime;
               if (strLatestDateTime < strYesterday)
                  Console::display("ST519",m_strCONTEXT_KEY.c_str());
               break;
            case CUT:
               strLatestDateTime = m_strCONTEXT_DATA;
               if (strLatestDateTime < m_strCutTimestamp)
                  m_iPendingCount++;
               break;
            case EOD:
               strLatestDateTime = m_strCONTEXT_DATA;
               if (strLatestDateTime < m_strEodTimestamp)
                  m_iPendingCount++;
               break;
         }
      }
   }
  //## end qr::APEventHandler::update%378E4C8702EB.body
}

// Additional Declarations
  //## begin qr::APEventHandler%378E2E9102B0.declarations preserve=yes
  //## end qr::APEventHandler%378E2E9102B0.declarations

} // namespace qr

//## begin module%378E2EFE02DF.epilog preserve=yes
//## end module%378E2EFE02DF.epilog
