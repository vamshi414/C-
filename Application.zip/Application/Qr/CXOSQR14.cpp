//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%420B8AF7000F.cm preserve=no
//## end module%420B8AF7000F.cm

//## begin module%420B8AF7000F.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%420B8AF7000F.cp

//## Module: CXOSQR14%420B8AF7000F; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR14.cpp

//## begin module%420B8AF7000F.additionalIncludes preserve=no
//## end module%420B8AF7000F.additionalIncludes

//## begin module%420B8AF7000F.includes preserve=yes
#ifdef _WIN32
//#include <winsock.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
#ifndef CXOSOP00_h
#include "CXODOP00.hpp"
#endif
#include "CXODTM10.hpp"
#include "CXODOP12.hpp"
#include "CXODOP13.hpp"
#include "CXODOP19.hpp"
//## end module%420B8AF7000F.includes

#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif
#ifndef CXOSQR04_h
#include "CXODQR04.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF26_h
#include "CXODIF26.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSQR18_h
#include "CXODQR18.hpp"
#endif
#ifndef CXOSQR22_h
#include "CXODQR22.hpp"
#endif
#ifndef CXOSQR14_h
#include "CXODQR14.hpp"
#endif


//## begin module%420B8AF7000F.declarations preserve=no
//## end module%420B8AF7000F.declarations

//## begin module%420B8AF7000F.additionalDeclarations preserve=yes
//## end module%420B8AF7000F.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::ISTAPTranHandler 

//## begin qr::ISTAPTranHandler::Logging%420B804C003E.attr preserve=no  public: static bool {U} false
bool ISTAPTranHandler::m_bLogging = false;
//## end qr::ISTAPTranHandler::Logging%420B804C003E.attr

ISTAPTranHandler::ISTAPTranHandler()
  //## begin ISTAPTranHandler::ISTAPTranHandler%420B7B38033C_const.hasinit preserve=no
  //## end ISTAPTranHandler::ISTAPTranHandler%420B7B38033C_const.hasinit
  //## begin ISTAPTranHandler::ISTAPTranHandler%420B7B38033C_const.initialization preserve=yes
  //## end ISTAPTranHandler::ISTAPTranHandler%420B7B38033C_const.initialization
{
  //## begin qr::ISTAPTranHandler::ISTAPTranHandler%420B7B38033C_const.body preserve=yes
  //## end qr::ISTAPTranHandler::ISTAPTranHandler%420B7B38033C_const.body
}

ISTAPTranHandler::ISTAPTranHandler (Handler* pHandler)
  //## begin qr::ISTAPTranHandler::ISTAPTranHandler%420B7F6403B9.hasinit preserve=no
  //## end qr::ISTAPTranHandler::ISTAPTranHandler%420B7F6403B9.hasinit
  //## begin qr::ISTAPTranHandler::ISTAPTranHandler%420B7F6403B9.initialization preserve=yes
  //## end qr::ISTAPTranHandler::ISTAPTranHandler%420B7F6403B9.initialization
{
  //## begin qr::ISTAPTranHandler::ISTAPTranHandler%420B7F6403B9.body preserve=yes
   memcpy(m_sID,"QR14",4);
   m_pSuccessor = pHandler;
  //## end qr::ISTAPTranHandler::ISTAPTranHandler%420B7F6403B9.body
}


ISTAPTranHandler::~ISTAPTranHandler()
{
  //## begin qr::ISTAPTranHandler::~ISTAPTranHandler%420B7B38033C_dest.body preserve=yes
  //## end qr::ISTAPTranHandler::~ISTAPTranHandler%420B7B38033C_dest.body
}



//## Other Operations (implementation)
void ISTAPTranHandler::update (Subject* pSubject)
{
  //## begin qr::ISTAPTranHandler::update%420B7F850242.body preserve=yes
   Control* pControl = 0;
   if (!APISTHeader::instance()->parse())
      return;
   if (APISTHeader::instance()->getMsgCode() == 904 )
      m_pSuccessor->update(pSubject);

   if (!SwitchInterfacePool::instance()->send(Message::instance(Message::INBOUND), Queue::DATAGRAM))
   {
      Console::display("ST248");
      Batch::instance()->restart();
      return;
   }
   if (m_bLogging)
   {
      char temp[12];
      int iBatchCount = Batch::instance()->getCount();
      double dBatchNumber = Batch::instance()->getTicks();
      memcpy(temp,(char*)&iBatchCount,4);
      memcpy(temp+4,(char*)&dBatchNumber,8);
      if (Log::put(Message::instance(Message::INBOUND)->data(),Message::instance(Message::INBOUND)->dataLength(),"S0042D","Log Message",temp,"CUSTLOG") != 0)
      {
         Console::display("ST506");
         Batch::instance()->restart();
         return;
      }
      Batch::instance()->updateLogConfirmation();
   }
   m_strLogOpenTimestamp.assign(APISTHeader::instance()->getLogOpenTime());
   m_strLoggerName.assign(APISTHeader::instance()->getLoggerName());
   pControl = Control::locate(m_strLoggerName,m_strLogOpenTimestamp);
   if (APISTHeader::instance()->getMsgCode() != 904)
   {
      char szBuffer[64];
      if (pControl)
         pControl->updateCDNHash(APISTHeader::instance()->getAPHash());
      Batch::instance()->addRecord(APISTHeader::instance()->getAPHash());
      Trace::put(szBuffer,snprintf(szBuffer,sizeof(szBuffer),"hash value sent %d",APISTHeader::instance()->getAPHash()));
   }
   else
      Batch::instance()->addRecord(0);

   string strTemp = APISTHeader::instance()->getTransmissionDateTime();
   APEventHandler::instance()->update(m_strLoggerName,strTemp);
   Batch::instance()->update(Message::instance(Message::INBOUND)->getDestination(),APISTHeader::instance()->getTransmissionDateTime());
  //## end qr::ISTAPTranHandler::update%420B7F850242.body
}

// Additional Declarations
  //## begin qr::ISTAPTranHandler%420B7B38033C.declarations preserve=yes
  //## end qr::ISTAPTranHandler%420B7B38033C.declarations

} // namespace qr

//## begin module%420B8AF7000F.epilog preserve=yes
//## end module%420B8AF7000F.epilog
