//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39CA0B130276.cm preserve=no
//## end module%39CA0B130276.cm

//## begin module%39CA0B130276.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%39CA0B130276.cp

//## Module: CXOSQR11%39CA0B130276; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR11.cpp

//## begin module%39CA0B130276.additionalIncludes preserve=no
//## end module%39CA0B130276.additionalIncludes

//## begin module%39CA0B130276.includes preserve=yes
#ifdef _WIN32
#include <winsock.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#include "CXODRU24.hpp"
#include "CXODIF03.hpp"
#include "CXODTM10.hpp"
#ifndef CXOSBP06_h
#include "CXODBP06.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
//## end module%39CA0B130276.includes

#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSQR11_h
#include "CXODQR11.hpp"
#endif


//## begin module%39CA0B130276.declarations preserve=no
//## end module%39CA0B130276.declarations

//## begin module%39CA0B130276.additionalDeclarations preserve=yes
//## end module%39CA0B130276.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::B24APControlHandler 

B24APControlHandler::B24APControlHandler()
  //## begin B24APControlHandler::B24APControlHandler%39C9670603A6_const.hasinit preserve=no
  //## end B24APControlHandler::B24APControlHandler%39C9670603A6_const.hasinit
  //## begin B24APControlHandler::B24APControlHandler%39C9670603A6_const.initialization preserve=yes
  //## end B24APControlHandler::B24APControlHandler%39C9670603A6_const.initialization
{
  //## begin qr::B24APControlHandler::B24APControlHandler%39C9670603A6_const.body preserve=yes
  //## end qr::B24APControlHandler::B24APControlHandler%39C9670603A6_const.body
}

B24APControlHandler::B24APControlHandler (Handler* pHandler)
  //## begin qr::B24APControlHandler::B24APControlHandler%39C969AF0160.hasinit preserve=no
  //## end qr::B24APControlHandler::B24APControlHandler%39C969AF0160.hasinit
  //## begin qr::B24APControlHandler::B24APControlHandler%39C969AF0160.initialization preserve=yes
  //## end qr::B24APControlHandler::B24APControlHandler%39C969AF0160.initialization
{
  //## begin qr::B24APControlHandler::B24APControlHandler%39C969AF0160.body preserve=yes
   m_pSuccessor = pHandler;
   memcpy(m_sID,"QR11",4);
  //## end qr::B24APControlHandler::B24APControlHandler%39C969AF0160.body
}


B24APControlHandler::~B24APControlHandler()
{
  //## begin qr::B24APControlHandler::~B24APControlHandler%39C9670603A6_dest.body preserve=yes
  //## end qr::B24APControlHandler::~B24APControlHandler%39C9670603A6_dest.body
}



//## Other Operations (implementation)
void B24APControlHandler::update (Subject* pSubject)
{
  //## begin qr::B24APControlHandler::update%39C9699C01B3.body preserve=yes
   hB24ControlMessage* phB24ControlMessage = (hB24ControlMessage*)Message::instance(Message::INBOUND)->data();
#ifdef MVS
   CodeTable::translate(phB24ControlMessage->sLoggerName,6,CodeTable::CX_ASCII_TO_EBCDIC);
   CodeTable::translate(phB24ControlMessage->sLogOpenTime,16,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   m_strLoggerName.assign(phB24ControlMessage->sLoggerName,6);
   m_strLogOpenTimestamp.assign(phB24ControlMessage->sLogOpenTime,16);
   m_dAPHash  = Segment::lltof(ntohl(phB24ControlMessage->lUnloadTstampHash[0]),ntohl(phB24ControlMessage->lUnloadTstampHash[1]));
   m_lAPCount = ntohl(phB24ControlMessage->lUnloadRecordCount);
   Control* pControl = Control::locate(m_strLoggerName,m_strLogOpenTimestamp);
   pControl->updateCDNHash(0);
   APControlHandler::update(pSubject);
  //## end qr::B24APControlHandler::update%39C9699C01B3.body
}

// Additional Declarations
  //## begin qr::B24APControlHandler%39C9670603A6.declarations preserve=yes
  //## end qr::B24APControlHandler%39C9670603A6.declarations

} // namespace qr

//## begin module%39CA0B130276.epilog preserve=yes
//## end module%39CA0B130276.epilog
