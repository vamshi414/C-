//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%37F8ED55000E.cm preserve=no
//## end module%37F8ED55000E.cm

//## begin module%37F8ED55000E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%37F8ED55000E.cp

//## Module: CXOSQR06%37F8ED55000E; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR06.cpp

//## begin module%37F8ED55000E.additionalIncludes preserve=no
//## end module%37F8ED55000E.additionalIncludes

//## begin module%37F8ED55000E.includes preserve=yes
// $Date:   Jun 21 2017 08:08:28  $ $Author:   e1009839  $ $Revision:   1.9  $
#include "CXODRU24.hpp"
#include "CXODRS28.hpp"
#include "CXODIF11.hpp"
#include "CXODTM10.hpp"
//## end module%37F8ED55000E.includes

#ifndef CXOSQR07_h
#include "CXODQR07.hpp"
#endif
#ifndef CXOSQR04_h
#include "CXODQR04.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif
#ifndef CXOSQR01_h
#include "CXODQR01.hpp"
#endif
#ifndef CXOSQR06_h
#include "CXODQR06.hpp"
#endif


//## begin module%37F8ED55000E.declarations preserve=no
//## end module%37F8ED55000E.declarations

//## begin module%37F8ED55000E.additionalDeclarations preserve=yes
//## end module%37F8ED55000E.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::AdvgAPControlHandler 

AdvgAPControlHandler::AdvgAPControlHandler()
  //## begin AdvgAPControlHandler::AdvgAPControlHandler%37F8ECD503AD_const.hasinit preserve=no
  //## end AdvgAPControlHandler::AdvgAPControlHandler%37F8ECD503AD_const.hasinit
  //## begin AdvgAPControlHandler::AdvgAPControlHandler%37F8ECD503AD_const.initialization preserve=yes
  //## end AdvgAPControlHandler::AdvgAPControlHandler%37F8ECD503AD_const.initialization
{
  //## begin qr::AdvgAPControlHandler::AdvgAPControlHandler%37F8ECD503AD_const.body preserve=yes
   memcpy(m_sID,"QR06",4);

  //## end qr::AdvgAPControlHandler::AdvgAPControlHandler%37F8ECD503AD_const.body
}

AdvgAPControlHandler::AdvgAPControlHandler (Handler* pHandler)
  //## begin qr::AdvgAPControlHandler::AdvgAPControlHandler%37FB89F60156.hasinit preserve=no
  //## end qr::AdvgAPControlHandler::AdvgAPControlHandler%37FB89F60156.hasinit
  //## begin qr::AdvgAPControlHandler::AdvgAPControlHandler%37FB89F60156.initialization preserve=yes
  //## end qr::AdvgAPControlHandler::AdvgAPControlHandler%37FB89F60156.initialization
{
  //## begin qr::AdvgAPControlHandler::AdvgAPControlHandler%37FB89F60156.body preserve=yes
   m_pSuccessor = pHandler;
   memcpy(m_sID,"QR06",4);
  //## end qr::AdvgAPControlHandler::AdvgAPControlHandler%37FB89F60156.body
}


AdvgAPControlHandler::~AdvgAPControlHandler()
{
  //## begin qr::AdvgAPControlHandler::~AdvgAPControlHandler%37F8ECD503AD_dest.body preserve=yes
  //## end qr::AdvgAPControlHandler::~AdvgAPControlHandler%37F8ECD503AD_dest.body
}



//## Other Operations (implementation)
void AdvgAPControlHandler::update (Subject* pSubject)
{
  //## begin qr::AdvgAPControlHandler::update%37F90BF002DC.body preserve=yes
   m_strLogOpenTimestamp = NonStopClock::getYYYYMMDDHHMMSShh(APAdvgHeader::instance()->getLogOpenTime().data());
   m_strLoggerName = APAdvgHeader::instance()->getControlLoggerName();
   m_dAPHash  = (APAdvgHeader::instance()->getAPHash());
   m_lAPCount = (APAdvgHeader::instance()->getAPCount());
   APControlHandler::update(pSubject);
   // ******************************
   // ** new logger control card ***
   hV13AdvantageHeader* pAdvgV13LoggerHeader = (hV13AdvantageHeader*)Message::instance(Message::INBOUND)->data();
   m_strLoggerName = APAdvgHeader::instance()->getLoggerName();
   m_strLogOpenTimestamp = NonStopClock::getYYYYMMDDHHMMSShh(pAdvgV13LoggerHeader->sHdrTimestamp1);
   Control* pControl = Control::locate(m_strLoggerName,m_strLogOpenTimestamp);
   pControl->updateCDNHash(0);
   // ******************************
  //## end qr::AdvgAPControlHandler::update%37F90BF002DC.body
}

// Additional Declarations
  //## begin qr::AdvgAPControlHandler%37F8ECD503AD.declarations preserve=yes
  //## end qr::AdvgAPControlHandler%37F8ECD503AD.declarations

} // namespace qr

//## begin module%37F8ED55000E.epilog preserve=yes
//## end module%37F8ED55000E.epilog
