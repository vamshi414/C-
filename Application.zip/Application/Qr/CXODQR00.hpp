//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36C87DCB02E8.cm preserve=no
//## end module%36C87DCB02E8.cm

//## begin module%36C87DCB02E8.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36C87DCB02E8.cp

//## Module: CXOSQR00%36C87DCB02E8; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR00.hpp

#ifndef CXOSQR00_h
#define CXOSQR00_h 1

//## begin module%36C87DCB02E8.additionalIncludes preserve=no
//## end module%36C87DCB02E8.additionalIncludes

//## begin module%36C87DCB02E8.includes preserve=yes
// $Date:   Jun 20 2020 16:06:12  $ $Author:   e1009839  $ $Revision:   1.33.1.1  $
#ifndef _UNIX
#include "CXODMQ02.hpp"
#endif
//## end module%36C87DCB02E8.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Continuous Feed::MQSeries_CAT%36C82B100167
namespace mqseries {
class MqQueueManager;
} // namespace mqseries

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Batch;
class APControlHandler;
class IBMAPTranHandler;
class SwitchInterfacePool;
class PostilionControlHandler;
class PostilionHandler;
class TransactionActivityControlHandler;
class TransactionActivityHandler;
class ISTAPControlHandler;
class ISTAPTranHandler;
class B24APTranHandler;
class B24APControlHandler;
class ExtAPControlHandler;
class ExtAPTranHandler;
class APAdvgHeader;
class IBMAPControlHandler;
class AdvgAPTranHandler;
class AdvgAPControlHandler;
class APEventHandler;
class Control;
} // namespace qr

//## Modelname: Continuous Feed::TableQueue_CAT%4194F6500109
namespace tablequeue {
class TableQueueFactory;
class TableQueueManager;
} // namespace tablequeue

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Extract;
class QueueFactory;
class Console;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Signal;
class SelectStatement;
class Query;
class Handler;
} // namespace reusable

namespace IF {
class Memory;
class Log;
class ExternalQueue;
class ExternalQueueFactory;
class QueueManager;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class MidnightAlarm;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class DatabaseFactory;
class Database;

} // namespace database

//## begin module%36C87DCB02E8.declarations preserve=no
//## end module%36C87DCB02E8.declarations

//## begin module%36C87DCB02E8.additionalDeclarations preserve=yes
//## end module%36C87DCB02E8.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::QueueReader%36C87D3C0274.preface preserve=yes
//## end qr::QueueReader%36C87D3C0274.preface

//## Class: QueueReader%36C87D3C0274
//	<body>
//	<title>CG
//	<h1>QR
//	<h2>AB
//	<!-- QueueReader : General -->
//	<h3>System Flow
//	<p>
//	The Queue Reader service reads a queue of transactions
//	and forwards them in batches to a Transaction Interface
//	service.
//	The queue can be either an IBM WebSphere MQ queue or an
//	FIS Connex OE DataDistributor database table.
//	<p>
//	Refer to the IBM WebSphere MQ or FIS Connex OE Data
//	Distributor documentation for more information on
//	configuration of the middleware.
//	</body>
//	<body>
//	<title>CG
//	<h1>QR
//	<h2>MS
//	<!-- QueueReader : General -->
//	<h3>Task Options
//	<p>
//	A Queue Reader service can process messages from any
//	switch platform.
//	The name of the associated Transaction Interface program
//	name in the task user data indicates the platform.
//	<p>
//	<table>
//	<tr>
//	<th>Platform
//	<th>Task: User Data
//	<tr>
//	<td>FIS IST SHCLOG
//	<td>CXOPOI00
//	<tr>
//	<td>FIS IST OCS
//	<td>CXOPOI00
//	<tr>
//	<td>FIS Connex on HP
//	<td>CXOPAI00
//	<tr>
//	<td>FIS Connex on IBM
//	<td>CXOPII00
//	<tr>
//	<td>FIS TXNACT
//	<td>CXOPYI00
//	<tr>
//	<td>ACI Base24
//	<td>CXOPBI00
//	<tr>
//	<td>ACI Postilion
//	<td>CXOPPI00
//	<tr>
//	<td>NCR Authentic
//	<td>CXOPHI00
//	</table>
//	<p>
//	Task definitions are in the Task Configuration folder in
//	the CR Client for the DataNavigator Server.
//	<!-- QueueReader : General -->
//	<h3>Tuning
//	<p>
//	The Queue Reader service sends transactions in batches
//	to the Transaction Interface task.
//	The batch size is continually tuned by Queue Reader to
//	achieve the configured elapsed transaction time.
//	The default value is 30 seconds.
//	The transaction time can be adjusted from 1 to 199
//	seconds.
//	<p>
//	DataNavigator transaction loading forces all Load Engine
//	services to commit at the end of each batch sent by the
//	Queue Reader.
//	Confirmation messages (including hash totals) are
//	returned to the Queue Reader following each batch.
//	If the confirmation fails, the affected batch is resent
//	until successful.
//	<p>
//	The transaction time can be increased if necessary to
//	handle higher volumes of transactions.
//	The downside is the amount of reprocessing done if
//	database failures (e.g. contention) occur during the
//	loading of a batch.
//	<p>
//	Use the CR Client to change the Queue Reader service.
//	The batch time can be changed by specifying
//	BATCHTIME=<i>nnnnnn</i> in the task user data.
//	The minimum value for <i>nnnnnn</i> is 000001.
//	The maximum value is 000199.
//	<p>
//	Task definitions are in the Task Configuration folder in
//	the CR Client for the DataNavigator Server.
//	<!-- QueueReader : General -->
//	<h3>Timing
//	<p>
//	The Queue Reader service supports two timers that affect
//	the handling of batches of transactions:
//	<table>
//	<tr>
//	<th>Timer
//	<th>Purpose
//	<th>Default value
//	<tr>
//	<td>ROLLBACK
//	<td>Amount of time Queue Reader waits for a batch to
//	complete before issuing a rollback and retry.
//	<td>5 minutes
//	<tr>
//	<td>RESTART
//	<td>Amount of time Queue Reader will wait before
//	retrying a batch after a rollback.
//	<td>15 minutes
//	</table>
//	<p>
//	Task definitions are in the Task Configuration folder in
//	the CR Client for the DataNavigator Server.
//	</body>
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%36E0539A03C7;mqseries::MqQueueManager { -> F}
//## Uses: <unnamed>%36E54D8D02DC;IF::QueueFactory { -> F}
//## Uses: <unnamed>%36E54E6302C6;timer::Clock { -> F}
//## Uses: <unnamed>%36E55A4A02EF;reusable::Signal { -> F}
//## Uses: <unnamed>%36E55AF300FD;IF::Message { -> F}
//## Uses: <unnamed>%36E820BB02CB;IF::Log { -> F}
//## Uses: <unnamed>%36F7CDE402E4;Batch { -> F}
//## Uses: <unnamed>%36F7CF95034B;database::Database { -> F}
//## Uses: <unnamed>%3716102B00BC;IF::Extract { -> F}
//## Uses: <unnamed>%3729F5370006;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%3756B895023A;IF::Console { -> F}
//## Uses: <unnamed>%37838367020A;Control { -> F}
//## Uses: <unnamed>%378F3A4603D5;APEventHandler { -> F}
//## Uses: <unnamed>%37FB4F7F0255;AdvgAPControlHandler { -> F}
//## Uses: <unnamed>%37FB4F9D028A;IBMAPControlHandler { -> F}
//## Uses: <unnamed>%386BA7A902A4;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%386F09BD0074;reusable::Query { -> F}
//## Uses: <unnamed>%386F09C001EB;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%38A04E9E0336;APAdvgHeader { -> F}
//## Uses: <unnamed>%3937F04C027B;ExtAPControlHandler { -> F}
//## Uses: <unnamed>%39CA26510274;B24APControlHandler { -> F}
//## Uses: <unnamed>%3A4A1C2C0028;monitor::UseCase { -> F}
//## Uses: <unnamed>%40A4D762008C;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%40A4D764036B;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%41ACA9920167;IF::QueueManager { -> F}
//## Uses: <unnamed>%41AD137C0203;IF::ExternalQueueFactory { -> F}
//## Uses: <unnamed>%41B61E2703A9;tablequeue::TableQueueFactory { -> F}
//## Uses: <unnamed>%41B61F7603D8;tablequeue::TableQueueManager { -> F}
//## Uses: <unnamed>%428B42A5037A;ISTAPControlHandler { -> F}
//## Uses: <unnamed>%49B966B900BB;IF::ExternalQueue { -> F}
//## Uses: <unnamed>%4F16E818008C;TransactionActivityControlHandler { -> F}
//## Uses: <unnamed>%531784A60397;B24APTranHandler { -> F}
//## Uses: <unnamed>%5ED15163021F;IBMAPTranHandler { -> F}
//## Uses: <unnamed>%5ED1516C0345;ExtAPTranHandler { -> F}
//## Uses: <unnamed>%5ED1517300D7;AdvgAPTranHandler { -> F}
//## Uses: <unnamed>%5ED1517A022E;ISTAPTranHandler { -> F}
//## Uses: <unnamed>%5ED1518300D7;TransactionActivityHandler { -> F}
//## Uses: <unnamed>%5ED1538A000F;PostilionControlHandler { -> F}
//## Uses: <unnamed>%5ED1538E02D8;PostilionHandler { -> F}
//## Uses: <unnamed>%632CC7BB014C;SwitchInterfacePool { -> F}

class QueueReader : public process::Application  //## Inherits: <unnamed>%36C87D580242
{
  //## begin qr::QueueReader%36C87D3C0274.initialDeclarations preserve=yes
  public:
      enum TranHandler
      {
         INPUT_UNDEFINED = -1,
         ADVG_INPUT,
         IBM_INPUT,
         EXT_INPUT,
         B24_INPUT,
         IST_INPUT,
         TXNACT_INPUT,
         ACI_POSTILION_INPUT
      };
  //## end qr::QueueReader%36C87D3C0274.initialDeclarations

  public:
    //## Constructors (generated)
      QueueReader();

    //## Destructor (generated)
      virtual ~QueueReader();


    //## Other Operations (specified)
      //## Operation: initialize%36D5B1090164
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>QR
      //	<h2>MS
      //	<!-- QueueReader::initialize Preconditions -->
      //	<h3>Input Queue
      //	<p>
      //	The Queue Reader service supports either IBM WebSphere
      //	MQ or FIS DataDistributor.
      //	For IBM WebSphere MQ, use the CR Client to specify the
      //	input queue name in custom table data:
      //	<p>
      //	DSPEC AP QM_LP007373@GTWY.QUEUE1
      //	<p>
      //	For FIS DataDistributor, use the CR Client to specify
      //	the input database table name:
      //	<p>
      //	DSPEC AP DATADIST_QUEUE_01
      //	<p>
      //	Custom Table Data definitions are in the Custom Tables
      //	folder in the CR Client for the DataNavigator Server.
      //	</body>
      virtual int initialize ();

    // Additional Public Declarations
      //## begin qr::QueueReader%36C87D3C0274.public preserve=yes
      //## end qr::QueueReader%36C87D3C0274.public

  protected:

    //## Other Operations (specified)
      //## Operation: onConfirm%36ED2B310052
      virtual int onConfirm (Message& hMessage);

      //## Operation: onMessage%36F920DA0127
      virtual int onMessage (Message& hMessage);

      //## Operation: onNotify%371242DF0226
      virtual int onNotify (const char* pszQueueName);

      //## Operation: onRefresh%371611070343
      virtual int onRefresh ();

      //## Operation: onReset%378F7DC301E4
      virtual int onReset (Message& hMessage);

    // Additional Protected Declarations
      //## begin qr::QueueReader%36C87D3C0274.protected preserve=yes
      //## end qr::QueueReader%36C87D3C0274.protected

  private:

    //## Other Operations (specified)
      //## Operation: refresh%38187A8B00E6
      int refresh ();

    // Additional Private Declarations
      //## begin qr::QueueReader%36C87D3C0274.private preserve=yes
      //## end qr::QueueReader%36C87D3C0274.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: APQueue%36E558BA0268
      //## begin qr::QueueReader::APQueue%36E558BA0268.attr preserve=no  private: IF::ExternalQueue* {U} 0
      IF::ExternalQueue* m_pAPQueue;
      //## end qr::QueueReader::APQueue%36E558BA0268.attr

      //## Attribute: APSignal%36E54F250210
      //## begin qr::QueueReader::APSignal%36E54F250210.attr preserve=no  private: reusable::Signal* {U} 0
      reusable::Signal* m_pAPSignal;
      //## end qr::QueueReader::APSignal%36E54F250210.attr

      //## Attribute: InputType%37C6B91F007D
      //	defines whether the Queue Reader is processing Advantage
      //	or IBM logs
      //## begin qr::QueueReader::InputType%37C6B91F007D.attr preserve=no  public: TranHandler {U} INPUT_UNDEFINED
      TranHandler m_lInputType;
      //## end qr::QueueReader::InputType%37C6B91F007D.attr

      //## Attribute: Logging%3C7E68E20128
      //## begin qr::QueueReader::Logging%3C7E68E20128.attr preserve=no  public: bool {U} false
      bool m_bLogging;
      //## end qr::QueueReader::Logging%3C7E68E20128.attr

      //## Attribute: PrimaryQR%3C7E69700108
      //## begin qr::QueueReader::PrimaryQR%3C7E69700108.attr preserve=no  public: bool {U} false
      bool m_bPrimaryQR;
      //## end qr::QueueReader::PrimaryQR%3C7E69700108.attr

      //## Attribute: Unblocked%37A09575022F
      //## begin qr::QueueReader::Unblocked%37A09575022F.attr preserve=no  public: bool {U} false
      bool m_bUnblocked;
      //## end qr::QueueReader::Unblocked%37A09575022F.attr

    // Data Members for Associations

      //## Association: Continuous Feed::QueueReader_CAT::<unnamed>%36FA741302A0
      //## Role: QueueReader::<m_pAPControlHandler>%36FA74140298
      //## begin qr::QueueReader::<m_pAPControlHandler>%36FA74140298.role preserve=no  public: qr::APControlHandler { -> RFHgN}
      APControlHandler *m_pAPControlHandler;
      //## end qr::QueueReader::<m_pAPControlHandler>%36FA74140298.role

      //## Association: Continuous Feed::QueueReader_CAT::<unnamed>%379DF1BE0069
      //## Role: QueueReader::<m_pMemory>%379DF1BF006B
      //## begin qr::QueueReader::<m_pMemory>%379DF1BF006B.role preserve=no  public: IF::Memory { -> RFHgN}
      IF::Memory *m_pMemory;
      //## end qr::QueueReader::<m_pMemory>%379DF1BF006B.role

      //## Association: Continuous Feed::QueueReader_CAT::<unnamed>%5ED151490347
      //## Role: QueueReader::<m_pHandler>%5ED1514A0316
      //## begin qr::QueueReader::<m_pHandler>%5ED1514A0316.role preserve=no  public: reusable::Handler { -> RFHgN}
      reusable::Handler *m_pHandler;
      //## end qr::QueueReader::<m_pHandler>%5ED1514A0316.role

    // Additional Implementation Declarations
      //## begin qr::QueueReader%36C87D3C0274.implementation preserve=yes
      //## end qr::QueueReader%36C87D3C0274.implementation

};

//## begin qr::QueueReader%36C87D3C0274.postscript preserve=yes
//## end qr::QueueReader%36C87D3C0274.postscript

} // namespace qr

//## begin module%36C87DCB02E8.epilog preserve=yes
//## end module%36C87DCB02E8.epilog


#endif
