//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39CA0B0E0016.cm preserve=no
//## end module%39CA0B0E0016.cm

//## begin module%39CA0B0E0016.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%39CA0B0E0016.cp

//## Module: CXOSQR11%39CA0B0E0016; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR11.hpp

#ifndef CXOSQR11_h
#define CXOSQR11_h 1

//## begin module%39CA0B0E0016.additionalIncludes preserve=no
//## end module%39CA0B0E0016.additionalIncludes

//## begin module%39CA0B0E0016.includes preserve=yes
// $Date:   Jul 06 2010 01:25:28  $ $Author:   D02684  $ $Revision:   1.7  $
//## end module%39CA0B0E0016.includes

#ifndef CXOSQR02_h
#include "CXODQR02.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Control;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class DateTime;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;

} // namespace segment

//## begin module%39CA0B0E0016.declarations preserve=no
//## end module%39CA0B0E0016.declarations

//## begin module%39CA0B0E0016.additionalDeclarations preserve=yes
//## end module%39CA0B0E0016.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::B24APControlHandler%39C9670603A6.preface preserve=yes
#include "CXODRU32.hpp"
struct hB24ControlRecord
{
   char  sTypeRec[2];
   char  sXmitTstamp[8];
   char  sFiller[2];
   char  sBatchTstamp[6];
   char  sLogName[8];
   int  lTranCount;
   int  lHashValue;
};
#include "CXODRU33.hpp"
//## end qr::B24APControlHandler%39C9670603A6.preface

//## Class: B24APControlHandler%39C9670603A6
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39C971860289;Control { -> F}
//## Uses: <unnamed>%39C971BA0157;IF::Message { -> F}
//## Uses: <unnamed>%39CA1DBF01F7;IF::DateTime { -> F}
//## Uses: <unnamed>%4BC849B20393;segment::Segment { -> F}

class B24APControlHandler : public APControlHandler  //## Inherits: <unnamed>%39C9701802BF
{
  //## begin qr::B24APControlHandler%39C9670603A6.initialDeclarations preserve=yes
  //## end qr::B24APControlHandler%39C9670603A6.initialDeclarations

  public:
    //## Constructors (generated)
      B24APControlHandler();

    //## Constructors (specified)
      //## Operation: B24APControlHandler%39C969AF0160
      B24APControlHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~B24APControlHandler();


    //## Other Operations (specified)
      //## Operation: update%39C9699C01B3
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin qr::B24APControlHandler%39C9670603A6.public preserve=yes
      //## end qr::B24APControlHandler%39C9670603A6.public

  protected:
    // Additional Protected Declarations
      //## begin qr::B24APControlHandler%39C9670603A6.protected preserve=yes
      //## end qr::B24APControlHandler%39C9670603A6.protected

  private:
    // Additional Private Declarations
      //## begin qr::B24APControlHandler%39C9670603A6.private preserve=yes
      //## end qr::B24APControlHandler%39C9670603A6.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin qr::B24APControlHandler%39C9670603A6.implementation preserve=yes
      //## end qr::B24APControlHandler%39C9670603A6.implementation

};

//## begin qr::B24APControlHandler%39C9670603A6.postscript preserve=yes
//## end qr::B24APControlHandler%39C9670603A6.postscript

} // namespace qr

//## begin module%39CA0B0E0016.epilog preserve=yes
//## end module%39CA0B0E0016.epilog


#endif
