//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%523C5C3F008D.cm preserve=no
//## end module%523C5C3F008D.cm

//## begin module%523C5C3F008D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%523C5C3F008D.cp

//## Module: CXOSQR18%523C5C3F008D; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR18.cpp

//## begin module%523C5C3F008D.additionalIncludes preserve=no
//## end module%523C5C3F008D.additionalIncludes

//## begin module%523C5C3F008D.includes preserve=yes
#ifdef _WIN32
#include <winsock.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
#ifndef CXOSOP00_h
#include "CXODOP00.hpp"
#endif
#include "CXODOP12.hpp"
#include "CXODOP13.hpp"
#include "CXODOP19.hpp"
#include "CXODOP34.hpp"
#include "CXODOP54.hpp"
//## end module%523C5C3F008D.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSQR18_h
#include "CXODQR18.hpp"
#endif


//## begin module%523C5C3F008D.declarations preserve=no
//## end module%523C5C3F008D.declarations

//## begin module%523C5C3F008D.additionalDeclarations preserve=yes
//## end module%523C5C3F008D.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::APISTHeader 

//## begin qr::APISTHeader::Instance%523C5AE3037D.attr preserve=no  private: static qr::APISTHeader* {U} 0
qr::APISTHeader* APISTHeader::m_pInstance = 0;
//## end qr::APISTHeader::Instance%523C5AE3037D.attr

APISTHeader::APISTHeader()
  //## begin APISTHeader::APISTHeader%523C5AE3034B_const.hasinit preserve=no
      : m_lAPCount(0),
        m_dAPHash(0),
        m_pISTData(0),
        m_pISTInternalHeader(0),
        m_pISTLogHeader(0),
        m_iMsgCode(0)
  //## end APISTHeader::APISTHeader%523C5AE3034B_const.hasinit
  //## begin APISTHeader::APISTHeader%523C5AE3034B_const.initialization preserve=yes
  //## end APISTHeader::APISTHeader%523C5AE3034B_const.initialization
{
  //## begin qr::APISTHeader::APISTHeader%523C5AE3034B_const.body preserve=yes
  //## end qr::APISTHeader::APISTHeader%523C5AE3034B_const.body
}


APISTHeader::~APISTHeader()
{
  //## begin qr::APISTHeader::~APISTHeader%523C5AE3034B_dest.body preserve=yes
  //## end qr::APISTHeader::~APISTHeader%523C5AE3034B_dest.body
}



//## Other Operations (implementation)
void APISTHeader::getControlData ()
{
  //## begin qr::APISTHeader::getControlData%523C5AE30397.body preserve=yes
   if (m_pISTLogHeader)
   {
      hISTControlMessage* pISTControlMessage = (hISTControlMessage*)(m_pISTLogHeader + sizeof(hISTLogHeader));
      m_dAPHash  = Segment::lltof(ntohl(pISTControlMessage->lUnloadAmtHash[0]),ntohl(pISTControlMessage->lUnloadAmtHash[1]));
      m_lAPCount = ntohl(pISTControlMessage->lUnloadRecordCount);
      m_strTransmissionDateTime.assign(pISTControlMessage->sLogOpenTime,16);
   }
  //## end qr::APISTHeader::getControlData%523C5AE30397.body
}

void APISTHeader::getElectronicJournalData ()
{
  //## begin qr::APISTHeader::getElectronicJournalData%52401779007A.body preserve=yes
   if (m_pISTData)
   {
      struct oasisocsmessageprocessor::segEJ* psegEJ = (oasisocsmessageprocessor::segEJ*)m_pISTData;
      setTstampAndHash(psegEJ->iDate,psegEJ->iTime);
   }
  //## end qr::APISTHeader::getElectronicJournalData%52401779007A.body
}

void APISTHeader::getFinancialData ()
{
  //## begin qr::APISTHeader::getFinancialData%523C5AE30396.body preserve=yes
   if (memcmp(Message::instance(Message::INBOUND)->data(),"M  ",3) == 0)
   {
      char szTemp[5] = {"    "};
      memcpy(szTemp,Message::instance(Message::INBOUND)->data() + 20,4);
      m_dAPHash = atoi(szTemp) + 1;
   }
   else if((memcmp(m_pISTData,"4100",4) == 0) ||
      (memcmp(m_pISTData,"4200",4) == 0) ||
      (memcmp(m_pISTData,"4300",4) == 0) ||
      (memcmp(m_pISTData,"4400",4) == 0))
   {
      setTstampAndHash(m_pISTData + 39,14);
   }
   else if (m_pISTData != 0)
   {
      char* p = m_pISTData;
      struct hISTHeader* pHeader = (struct hISTHeader*)p;
      char szHeaderSize[6] = {"00000"};
      memcpy(szHeaderSize,pHeader->headersize,5);
#ifdef MVS
      CodeTable::translate(szHeaderSize,5,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
      p += atoi(szHeaderSize);
      char szVersion[4] = {"   "};
      memcpy(szVersion,pHeader->version,3);
#ifdef MVS
      CodeTable::translate(szVersion,3,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
      int iTranDate = 0;
      int iTranTime = 0 ;
      if (memcmp(szVersion,"74",2) == 0)
      {
         struct hISTFinancialV74* pISTFinancialV74 = (struct hISTFinancialV74*)p;
         iTranDate = pISTFinancialV74->trandate;
         iTranTime = pISTFinancialV74->trantime;
      }
      else if (memcmp(szVersion,"75",2) == 0)
      {
         struct hISTFinancialV75* pISTFinancialV75 = (struct hISTFinancialV75*)p;
         iTranDate = pISTFinancialV75->trandate;
         iTranTime = pISTFinancialV75->trantime;
      }
      else if (memcmp(szVersion,"76",2) == 0)
      {
         struct hISTFinancialV76* pISTFinancialV76 = (struct hISTFinancialV76*)p;
         iTranDate = pISTFinancialV76->trandate;
         iTranTime = pISTFinancialV76->trantime;
      }
      else if (memcmp(szVersion,"77",2) == 0)
      {
         struct IST_V77::hISTFinancial* pISTFinancial = (struct IST_V77::hISTFinancial*)p;
         iTranDate = pISTFinancial->trandate;
         iTranTime = pISTFinancial->trantime;
      }
      else if (memcmp(szVersion, "78", 2) == 0)
      {
         struct IST_V78::hISTFinancial* pISTFinancial = (struct IST_V78::hISTFinancial*)p;
         iTranDate = pISTFinancial->trandate;
         iTranTime = pISTFinancial->trantime;
      }
      setTstampAndHash(iTranDate,iTranTime);
   }
  //## end qr::APISTHeader::getFinancialData%523C5AE30396.body
}

void APISTHeader::getNetStatStatusData ()
{
  //## begin qr::APISTHeader::getNetStatStatusData%52414A2803B5.body preserve=yes
   if (m_pISTData)
   {
      struct oasisocsmessageprocessor::hNetstatStatus* pNetstatStatus =
         (oasisocsmessageprocessor::hNetstatStatus*)m_pISTData;
      setTstampAndHash(pNetstatStatus->iDate,pNetstatStatus->iTime);
   }
  //## end qr::APISTHeader::getNetStatStatusData%52414A2803B5.body
}

void APISTHeader::getTerminalAdminData ()
{
  //## begin qr::APISTHeader::getTerminalAdminData%523C5EC60363.body preserve=yes
   if (m_pISTData)
   {
      struct oasisocsmessageprocessor::hTerminalAdmin* pTerminalAdmin =
         (oasisocsmessageprocessor::hTerminalAdmin*)m_pISTData;
      setTstampAndHash(pTerminalAdmin->iDate,pTerminalAdmin->iTime);
   }
  //## end qr::APISTHeader::getTerminalAdminData%523C5EC60363.body
}

void APISTHeader::getTerminalAdviceData ()
{
  //## begin qr::APISTHeader::getTerminalAdviceData%5240176500C9.body preserve=yes
   if(m_pISTData)
   {
      struct oasisocsmessageprocessor::hTerminalAdvice* pTerminalAdvice =
         (oasisocsmessageprocessor::hTerminalAdvice*)m_pISTData;
      setTstampAndHash(pTerminalAdvice->iDate,pTerminalAdvice->iTime);
   }
  //## end qr::APISTHeader::getTerminalAdviceData%5240176500C9.body
}

APISTHeader* APISTHeader::instance ()
{
  //## begin qr::APISTHeader::instance%523C5AE30390.body preserve=yes
   if (m_pInstance == 0)
      m_pInstance = new APISTHeader();
   return m_pInstance;
  //## end qr::APISTHeader::instance%523C5AE30390.body
}

bool APISTHeader::parse ()
{
  //## begin qr::APISTHeader::parse%523C5AE30391.body preserve=yes
   m_iMsgCode                = 400;
   m_dAPHash                 = 0;
   m_lAPCount                = 0 ;
   m_pISTData                = 0;
   m_pISTInternalHeader      = 0;
   m_pISTLogHeader           = 0 ;
   m_strTransmissionDateTime = "0000000000000000";
#ifdef MVS
   if (Message::instance(Message::INBOUND)->data()[0] == 0x4D
      && Message::instance(Message::INBOUND)->data()[1] == 0x20
      && Message::instance(Message::INBOUND)->data()[2] == 0x20)
      CodeTable::translate(Message::instance(Message::INBOUND)->data(),Message::instance(Message::INBOUND)->dataLength(),CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   if (memcmp(Message::instance(Message::INBOUND)->data(),"M  ",3) != 0)
   {
      m_pISTLogHeader = Message::instance(Message::INBOUND)->data();
      struct hISTLogHeader* pISTLogHeader = (struct hISTLogHeader*)m_pISTLogHeader;
      char* p = (char*)pISTLogHeader;
      p += sizeof(hISTLogHeader);
      m_pISTInternalHeader = p;
      struct hISTInternalHeader* pISTInternalHeader = (struct hISTInternalHeader*)p;
      m_iMsgCode = ntohs(pISTInternalHeader->msgCode);
      m_pISTData = p + sizeof(hISTInternalHeader);
   }
   switch (m_iMsgCode)
   {
   case 400 : getFinancialData(); break;
   case 904 : getControlData();break;
   case 461 : getTerminalAdviceData();break;
   case 483 : getTerminalAdminData();break;
   case 623 : getElectronicJournalData();break;
   case 1521 :getNetStatStatusData();break;
   default  : return false;
   }
   return setLogger();
  //## end qr::APISTHeader::parse%523C5AE30391.body
}

bool APISTHeader::set904Logger ()
{
  //## begin qr::APISTHeader::set904Logger%523FFFAB0281.body preserve=yes
   if (m_pISTLogHeader == 0 )
      return false;
   hISTControlMessage* pISTControlMessage = (hISTControlMessage*)(m_pISTLogHeader + sizeof(hISTLogHeader));
#ifdef MVS
   CodeTable::translate(pISTControlMessage->sLoggerName,6,CodeTable::CX_ASCII_TO_EBCDIC);
   CodeTable::translate(pISTControlMessage->sLogOpenTime,16,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   m_strLoggerName.assign(pISTControlMessage->sLoggerName,6);
   m_strLogOpenTime.assign(pISTControlMessage->sLogOpenTime,16);
   return true;
  //## end qr::APISTHeader::set904Logger%523FFFAB0281.body
}

bool APISTHeader::setLogger ()
{
  //## begin qr::APISTHeader::setLogger%523C5AE30392.body preserve=yes
   if (m_iMsgCode == 904 )
      return set904Logger();
   if (m_pISTLogHeader)
   {
      struct hISTLogHeader* pISTLogHeader = (struct hISTLogHeader*)m_pISTLogHeader;
      struct hISTInternalHeader* pISTInternalHeader = (struct hISTInternalHeader*)m_pISTInternalHeader;
#ifdef MVS
      CodeTable::translate(pISTLogHeader->loggersTimestamp,16,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pISTInternalHeader->destination,6,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
      m_strLogOpenTime.assign(pISTLogHeader->loggersTimestamp,16);
      m_strLoggerName.assign(pISTInternalHeader->destination,6);
   }
   return true;
  //## end qr::APISTHeader::setLogger%523C5AE30392.body
}

void APISTHeader::setTstampAndHash (const int iDate, const int iTime)
{
  //## begin qr::APISTHeader::setTstampAndHash%5240464F0292.body preserve=yes
   int iTranDate = 0;
   int iTranTime = 0 ;
   iTranDate = ntohl(iDate);
   iTranTime = ntohl(iTime);
   m_dAPHash = iTranTime;
   char szTimestamp[17];
   snprintf(szTimestamp,sizeof(szTimestamp),"%08d%06d00",iTranDate,iTranTime);
   m_strTransmissionDateTime.assign(szTimestamp,16);
  //## end qr::APISTHeader::setTstampAndHash%5240464F0292.body
}

void APISTHeader::setTstampAndHash (const char* psText, unsigned iTextLength)
{
  //## begin qr::APISTHeader::setTstampAndHash%5D1E0C3203AA.body preserve=yes
   m_strTransmissionDateTime.assign(psText,iTextLength);
   m_dAPHash = atoi(m_strTransmissionDateTime.substr(8, 6).c_str());   
  //## end qr::APISTHeader::setTstampAndHash%5D1E0C3203AA.body
}

// Additional Declarations
  //## begin qr::APISTHeader%523C5AE3034B.declarations preserve=yes
  //## end qr::APISTHeader%523C5AE3034B.declarations

} // namespace qr

//## begin module%523C5C3F008D.epilog preserve=yes
//## end module%523C5C3F008D.epilog
