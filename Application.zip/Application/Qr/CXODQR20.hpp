//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EC7392A01D0.cm preserve=no
//## end module%5EC7392A01D0.cm

//## begin module%5EC7392A01D0.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5EC7392A01D0.cp

//## Module: CXOSQR20%5EC7392A01D0; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR20.hpp

#ifndef CXOSQR20_h
#define CXOSQR20_h 1

//## begin module%5EC7392A01D0.additionalIncludes preserve=no
//## end module%5EC7392A01D0.additionalIncludes

//## begin module%5EC7392A01D0.includes preserve=yes
//## end module%5EC7392A01D0.includes

#ifndef CXOSRU14_h
#include "CXODRU14.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Batch;
class SwitchInterfacePool;
class APEventHandler;
class Control;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Console;
class Queue;

} // namespace IF

//## begin module%5EC7392A01D0.declarations preserve=no
//## end module%5EC7392A01D0.declarations

//## begin module%5EC7392A01D0.additionalDeclarations preserve=yes
//## end module%5EC7392A01D0.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::PostilionHandler%5EC6DA4C0126.preface preserve=yes
//## end qr::PostilionHandler%5EC6DA4C0126.preface

//## Class: PostilionHandler%5EC6DA4C0126
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5ECD4DED0149;IF::Message { -> F}
//## Uses: <unnamed>%5ECD4E030339;IF::Console { -> F}
//## Uses: <unnamed>%5ECD4E0F02E2;Batch { -> F}
//## Uses: <unnamed>%5ECD4E1F0112;Control { -> F}
//## Uses: <unnamed>%5ECD4E5F00F3;IF::Queue { -> F}
//## Uses: <unnamed>%5ECD4EDF033D;APEventHandler { -> F}
//## Uses: <unnamed>%63911330031A;SwitchInterfacePool { -> F}

class DllExport PostilionHandler : public reusable::Handler  //## Inherits: <unnamed>%5EC6DAFB00C7
{
  //## begin qr::PostilionHandler%5EC6DA4C0126.initialDeclarations preserve=yes
  //## end qr::PostilionHandler%5EC6DA4C0126.initialDeclarations

  public:
    //## Constructors (generated)
      PostilionHandler();

    //## Constructors (specified)
      //## Operation: PostilionHandler%5EC737DF01B0
      PostilionHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~PostilionHandler();


    //## Other Operations (specified)
      //## Operation: update%5EC737ED0134
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin qr::PostilionHandler%5EC6DA4C0126.public preserve=yes
      //## end qr::PostilionHandler%5EC6DA4C0126.public

  protected:
    // Additional Protected Declarations
      //## begin qr::PostilionHandler%5EC6DA4C0126.protected preserve=yes
      //## end qr::PostilionHandler%5EC6DA4C0126.protected

  private:
    // Additional Private Declarations
      //## begin qr::PostilionHandler%5EC6DA4C0126.private preserve=yes
      //## end qr::PostilionHandler%5EC6DA4C0126.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin qr::PostilionHandler%5EC6DA4C0126.implementation preserve=yes
      //## end qr::PostilionHandler%5EC6DA4C0126.implementation

};

//## begin qr::PostilionHandler%5EC6DA4C0126.postscript preserve=yes
//## end qr::PostilionHandler%5EC6DA4C0126.postscript

} // namespace qr

//## begin module%5EC7392A01D0.epilog preserve=yes
//## end module%5EC7392A01D0.epilog


#endif
