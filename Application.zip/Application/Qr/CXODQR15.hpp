//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%420B85AB003E.cm preserve=no
//## end module%420B85AB003E.cm

//## begin module%420B85AB003E.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%420B85AB003E.cp

//## Module: CXOSQR15%420B85AB003E; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR15.hpp

#ifndef CXOSQR15_h
#define CXOSQR15_h 1

//## begin module%420B85AB003E.additionalIncludes preserve=no
//## end module%420B85AB003E.additionalIncludes

//## begin module%420B85AB003E.includes preserve=yes
//## end module%420B85AB003E.includes

#ifndef CXOSQR02_h
#include "CXODQR02.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class APISTHeader;
class Control;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;

} // namespace segment

//## begin module%420B85AB003E.declarations preserve=no
//## end module%420B85AB003E.declarations

//## begin module%420B85AB003E.additionalDeclarations preserve=yes
//## end module%420B85AB003E.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::ISTAPControlHandler%420B7C22007D.preface preserve=yes
//## end qr::ISTAPControlHandler%420B7C22007D.preface

//## Class: ISTAPControlHandler%420B7C22007D
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%420D2EAF01D4;IF::CodeTable { -> F}
//## Uses: <unnamed>%420D2EB303B9;Control { -> F}
//## Uses: <unnamed>%420D2EC00242;IF::Message { -> F}
//## Uses: <unnamed>%420D2EC300FA;segment::Segment { -> F}
//## Uses: <unnamed>%523C608302D5;APISTHeader { -> F}

class DllExport ISTAPControlHandler : public APControlHandler  //## Inherits: <unnamed>%420D2E5C0196
{
  //## begin qr::ISTAPControlHandler%420B7C22007D.initialDeclarations preserve=yes
  //## end qr::ISTAPControlHandler%420B7C22007D.initialDeclarations

  public:
    //## Constructors (generated)
      ISTAPControlHandler();

    //## Constructors (specified)
      //## Operation: ISTAPControlHandler%420D317A032C
      ISTAPControlHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~ISTAPControlHandler();


    //## Other Operations (specified)
      //## Operation: update%420D2EE403D8
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin qr::ISTAPControlHandler%420B7C22007D.public preserve=yes
      //## end qr::ISTAPControlHandler%420B7C22007D.public

  protected:
    // Additional Protected Declarations
      //## begin qr::ISTAPControlHandler%420B7C22007D.protected preserve=yes
      //## end qr::ISTAPControlHandler%420B7C22007D.protected

  private:
    // Additional Private Declarations
      //## begin qr::ISTAPControlHandler%420B7C22007D.private preserve=yes
      //## end qr::ISTAPControlHandler%420B7C22007D.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin qr::ISTAPControlHandler%420B7C22007D.implementation preserve=yes
      //## end qr::ISTAPControlHandler%420B7C22007D.implementation

};

//## begin qr::ISTAPControlHandler%420B7C22007D.postscript preserve=yes
//## end qr::ISTAPControlHandler%420B7C22007D.postscript

} // namespace qr

//## begin module%420B85AB003E.epilog preserve=yes
//## end module%420B85AB003E.epilog


#endif
