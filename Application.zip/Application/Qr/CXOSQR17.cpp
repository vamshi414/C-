//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4F1641CC000B.cm preserve=no
//## end module%4F1641CC000B.cm

//## begin module%4F1641CC000B.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4F1641CC000B.cp

//## Module: CXOSQR17%4F1641CC000B; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR17.cpp

//## begin module%4F1641CC000B.additionalIncludes preserve=no
//## end module%4F1641CC000B.additionalIncludes

//## begin module%4F1641CC000B.includes preserve=yes
//## end module%4F1641CC000B.includes

#ifndef CXOSQR17_h
#include "CXODQR17.hpp"
#endif
//## begin module%4F1641CC000B.declarations preserve=no
//## end module%4F1641CC000B.declarations

//## begin module%4F1641CC000B.additionalDeclarations preserve=yes
//## end module%4F1641CC000B.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::TransactionActivityControlHandler 

TransactionActivityControlHandler::TransactionActivityControlHandler()
  //## begin TransactionActivityControlHandler::TransactionActivityControlHandler%4F163F7A02C1_const.hasinit preserve=no
  //## end TransactionActivityControlHandler::TransactionActivityControlHandler%4F163F7A02C1_const.hasinit
  //## begin TransactionActivityControlHandler::TransactionActivityControlHandler%4F163F7A02C1_const.initialization preserve=yes
  //## end TransactionActivityControlHandler::TransactionActivityControlHandler%4F163F7A02C1_const.initialization
{
  //## begin qr::TransactionActivityControlHandler::TransactionActivityControlHandler%4F163F7A02C1_const.body preserve=yes
   memcpy(m_sID,"QR17",4);
  //## end qr::TransactionActivityControlHandler::TransactionActivityControlHandler%4F163F7A02C1_const.body
}

TransactionActivityControlHandler::TransactionActivityControlHandler (Handler* pHandler)
  //## begin qr::TransactionActivityControlHandler::TransactionActivityControlHandler%4F16409702FA.hasinit preserve=no
  //## end qr::TransactionActivityControlHandler::TransactionActivityControlHandler%4F16409702FA.hasinit
  //## begin qr::TransactionActivityControlHandler::TransactionActivityControlHandler%4F16409702FA.initialization preserve=yes
  //## end qr::TransactionActivityControlHandler::TransactionActivityControlHandler%4F16409702FA.initialization
{
  //## begin qr::TransactionActivityControlHandler::TransactionActivityControlHandler%4F16409702FA.body preserve=yes
   memcpy(m_sID,"QR17",4);
  //## end qr::TransactionActivityControlHandler::TransactionActivityControlHandler%4F16409702FA.body
}


TransactionActivityControlHandler::~TransactionActivityControlHandler()
{
  //## begin qr::TransactionActivityControlHandler::~TransactionActivityControlHandler%4F163F7A02C1_dest.body preserve=yes
  //## end qr::TransactionActivityControlHandler::~TransactionActivityControlHandler%4F163F7A02C1_dest.body
}



//## Other Operations (implementation)
void TransactionActivityControlHandler::update (Subject* pSubject)
{
  //## begin qr::TransactionActivityControlHandler::update%4F163FA0024C.body preserve=yes
  //## end qr::TransactionActivityControlHandler::update%4F163FA0024C.body
}

// Additional Declarations
  //## begin qr::TransactionActivityControlHandler%4F163F7A02C1.declarations preserve=yes
  //## end qr::TransactionActivityControlHandler%4F163F7A02C1.declarations

} // namespace qr

//## begin module%4F1641CC000B.epilog preserve=yes
//## end module%4F1641CC000B.epilog
