//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%39CA0DAC00A6.cm preserve=no
//## end module%39CA0DAC00A6.cm

//## begin module%39CA0DAC00A6.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%39CA0DAC00A6.cp

//## Module: CXOSQR10%39CA0DAC00A6; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR10.cpp

//## begin module%39CA0DAC00A6.additionalIncludes preserve=no
//## end module%39CA0DAC00A6.additionalIncludes

//## begin module%39CA0DAC00A6.includes preserve=yes
#ifdef _WIN32
#include <winsock.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#include "CXODRU24.hpp"
#include "CXODTM10.hpp"
#ifndef CXOSBP06_h
#include "CXODBP06.hpp"
#endif
#ifndef CXOSBP07_h
#include "CXODBP07.hpp"
#endif
#ifndef CXOSBP11_h
#include "CXODBP11.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
//## end module%39CA0DAC00A6.includes

#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSQR04_h
#include "CXODQR04.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU03_h
#include "CXODRU03.hpp"
#endif
#ifndef CXOSQR10_h
#include "CXODQR10.hpp"
#endif


//## begin module%39CA0DAC00A6.declarations preserve=no
//## end module%39CA0DAC00A6.declarations

//## begin module%39CA0DAC00A6.additionalDeclarations preserve=yes
//## end module%39CA0DAC00A6.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::B24APTranHandler 

B24APTranHandler::B24APTranHandler()
  //## begin B24APTranHandler::B24APTranHandler%39C97279021A_const.hasinit preserve=no
      : m_bIsB24ATM(false)
  //## end B24APTranHandler::B24APTranHandler%39C97279021A_const.hasinit
  //## begin B24APTranHandler::B24APTranHandler%39C97279021A_const.initialization preserve=yes
  //## end B24APTranHandler::B24APTranHandler%39C97279021A_const.initialization
{
  //## begin qr::B24APTranHandler::B24APTranHandler%39C97279021A_const.body preserve=yes
  //## end qr::B24APTranHandler::B24APTranHandler%39C97279021A_const.body
}

B24APTranHandler::B24APTranHandler (Handler* pHandler)
  //## begin qr::B24APTranHandler::B24APTranHandler%39C9740603DE.hasinit preserve=no
      : m_bIsB24ATM(false)
  //## end qr::B24APTranHandler::B24APTranHandler%39C9740603DE.hasinit
  //## begin qr::B24APTranHandler::B24APTranHandler%39C9740603DE.initialization preserve=yes
  //## end qr::B24APTranHandler::B24APTranHandler%39C9740603DE.initialization
{
  //## begin qr::B24APTranHandler::B24APTranHandler%39C9740603DE.body preserve=yes
   memcpy(m_sID,"QR10",4);
   m_pSuccessor = pHandler;
   string strB24RecordType;
   Extract::instance()->getRecord("DUSER   ",strB24RecordType);
   if (strB24RecordType.find("B24ATM") != string::npos)
      m_bIsB24ATM = true;
   m_strB24MessageTypes = "TLF01,TLF20,TLF21,"
                          "PTLF01,PTLF20,PTLF21,PTLF22,PTLF23";
  //## end qr::B24APTranHandler::B24APTranHandler%39C9740603DE.body
}


B24APTranHandler::~B24APTranHandler()
{
  //## begin qr::B24APTranHandler::~B24APTranHandler%39C97279021A_dest.body preserve=yes
  //## end qr::B24APTranHandler::~B24APTranHandler%39C97279021A_dest.body
}



//## Other Operations (implementation)
void B24APTranHandler::update (Subject* pSubject)
{
  //## begin qr::B24APTranHandler::update%39C9740700A0.body preserve=yes
   bool bIsCtrlRecord = false;
   struct hB24ControlHeader* phB24ControlHeader = (struct hB24ControlHeader*)Message::instance(Message::INBOUND)->data();
   char* p = (char*)phB24ControlHeader;
   p += sizeof(hB24ControlHeader);
#ifdef MVS
   CodeTable::translate(phB24ControlHeader->sTypeRec,2,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   if (memcmp(phB24ControlHeader->sTypeRec,"CR",2) == 0)
   {
       m_pSuccessor->update(pSubject);
       bIsCtrlRecord = true;
   }
   Message::instance(Message::OUTBOUND)->reset("QR AI ","S0059D");
   if (bIsCtrlRecord)
   {
      struct hB24LogHeader tmpB24LogHeader;
      char * q = (char *) &tmpB24LogHeader;
      tmpB24LogHeader.lHdrHash[0]=0;
      tmpB24LogHeader.lHdrHash[1]=0;
      memset(tmpB24LogHeader.sRecTyp,'0',sizeof(tmpB24LogHeader.sRecTyp));
      memcpy(Message::instance(Message::OUTBOUND)->data(),(char *)q,sizeof(hB24LogHeader));
      Message::instance(Message::OUTBOUND)->setDataLength(sizeof(hB24LogHeader));
   }
   else
   {
      memcpy(Message::instance(Message::OUTBOUND)->data(),(char*)p,Message::instance(Message::INBOUND)->dataLength() - sizeof(hB24ControlHeader));
      Message::instance(Message::OUTBOUND)->setDataLength(Message::instance(Message::INBOUND)->dataLength() - sizeof(hB24ControlHeader));
   }
   if (!(Queue::send("AI",Message::instance(Message::OUTBOUND),Queue::DATAGRAM)))
   {
      Console::display("ST248");
      // ST248 - "CONNECTION TO AI QUEUE HAS BEEN LOST"
      Batch::instance()->restart();
      return;
   }
   if (bIsCtrlRecord)
   {
      Batch::instance()->addRecord(0);
      return;
   }
#ifdef MVS
   CodeTable::translate(phB24ControlHeader->sLogOpenTime,16,CodeTable::CX_ASCII_TO_EBCDIC);
   CodeTable::translate(phB24ControlHeader->sLoggerName,6,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   m_strLogOpenTimestamp.assign(phB24ControlHeader->sLogOpenTime,16);
   m_strLoggerName.assign(phB24ControlHeader->sLoggerName,6);
   Control* pControl = Control::locate(m_strLoggerName,m_strLogOpenTimestamp);
   struct hB24TLFTransaction* phB24TLFTransaction =
      (struct hB24TLFTransaction*)p;
   struct hB24PTLFTransaction* phB24PTLFTransaction =
      (struct hB24PTLFTransaction*)p;
   struct hB24LogHeader* phB24LogHeader = (struct hB24LogHeader*)p;
   int lHdrHash = phB24LogHeader->lHdrHash[1];
   int iEntrytime0(0);
   int iEntrytime1(0);
   pControl->updateCDNHash(ntohl(lHdrHash));
   Batch::instance()->addRecord(ntohl(lHdrHash));
   if (m_bIsB24ATM)
   {
       iEntrytime0= ntohl(phB24TLFTransaction->lEntryTim[0]);
       iEntrytime1= ntohl(phB24TLFTransaction->lEntryTim[1]);
   }
   else
   {
       iEntrytime0= ntohl(phB24PTLFTransaction->lEntryTim[0]);
       iEntrytime1= ntohl(phB24PTLFTransaction->lEntryTim[1]);
   }
   char szRectyp[3];
   memcpy(szRectyp,phB24LogHeader->sRecTyp,2);
   szRectyp[2]='\0';
#ifdef MVS
   CodeTable::translate(szRectyp,2,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   string strMsgtype (m_bIsB24ATM ? "TLF" : "PTLF");
   strMsgtype.append(szRectyp,2);
   if (strstr(m_strB24MessageTypes.c_str(),strMsgtype.c_str()))
   {
      IString hTemp;
      DateTime hEntryTime;
      hEntryTime.setFromB24(iEntrytime0,iEntrytime1,hTemp);
      string strTemp(hTemp);
      // ** update Logger in map of loggers with latest TIMESTAMP
      APEventHandler::instance()->update(m_strLoggerName, strTemp);
      Batch::instance()->update(Message::instance(Message::INBOUND)->getDestination(),strTemp);
      strTemp.insert(0,"Entry time:");
      Trace::put(strTemp.c_str());
   }
  //## end qr::B24APTranHandler::update%39C9740700A0.body
}

// Additional Declarations
  //## begin qr::B24APTranHandler%39C97279021A.declarations preserve=yes
  //## end qr::B24APTranHandler%39C97279021A.declarations

} // namespace qr

//## begin module%39CA0DAC00A6.epilog preserve=yes
//## end module%39CA0DAC00A6.epilog
