//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36F9482501C2.cm preserve=no
//## end module%36F9482501C2.cm

//## begin module%36F9482501C2.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36F9482501C2.cp

//## Module: CXOSQR03%36F9482501C2; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR03.hpp

#ifndef CXOSQR03_h
#define CXOSQR03_h 1

//## begin module%36F9482501C2.additionalIncludes preserve=no
//## end module%36F9482501C2.additionalIncludes

//## begin module%36F9482501C2.includes preserve=yes
// $Date:   Jul 30 2013 04:33:10  $ $Author:   e1014316  $ $Revision:   1.18  $
#include <map>
//## end module%36F9482501C2.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Batch;
class QueueReader;
class APEventHandler;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
class Query;
} // namespace reusable

namespace IF {
class Extract;
class Console;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Context;
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%36F9482501C2.declarations preserve=no
//## end module%36F9482501C2.declarations

//## begin module%36F9482501C2.additionalDeclarations preserve=yes
//## end module%36F9482501C2.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::Control%36F947F70049.preface preserve=yes
//## end qr::Control%36F947F70049.preface

//## Class: Control%36F947F70049
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%36FA4DEA00FF;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%36FFCB3402A6;IF::Trace { -> F}
//## Uses: <unnamed>%371650730231;timer::Clock { -> F}
//## Uses: <unnamed>%3729EFA6027E;IF::Extract { -> F}
//## Uses: <unnamed>%3729F039035B;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%3729F063021B;reusable::Query { -> F}
//## Uses: <unnamed>%3729F3740011;process::Application { -> F}
//## Uses: <unnamed>%373AD99F0333;database::Database { -> F}
//## Uses: <unnamed>%373C8DAA029F;IF::Console { -> F}
//## Uses: <unnamed>%37A608F80114;APEventHandler { -> F}
//## Uses: <unnamed>%37AF014A034E;Batch { -> F}
//## Uses: <unnamed>%3856B1D70333;timer::Date { -> F}
//## Uses: <unnamed>%3C7E7E3F0156;database::Context { -> F}
//## Uses: <unnamed>%3C83E8CA0042;QueueReader { -> F}

class Control : public reusable::Object  //## Inherits: <unnamed>%36F948D701D2
{
  //## begin qr::Control%36F947F70049.initialDeclarations preserve=yes
  //## end qr::Control%36F947F70049.initialDeclarations

  public:
    //## Constructors (generated)
      Control();

    //## Constructors (specified)
      //## Operation: Control%36F95192006D
      Control (string& strLoggerName, string& strLogOpenTimestamp);

    //## Destructor (generated)
      virtual ~Control();


    //## Other Operations (specified)
      //## Operation: ageOffRecords%3729EB920268
      static void ageOffRecords ();

      //## Operation: commit%36FA50C80303
      static int commit ();

      //## Operation: locate%36F94DE003AC
      static Control* locate (string& strLoggerName, string& strLogOpenTimestamp);

      //## Operation: remove%37160AF50032
      static void remove ();

      //## Operation: reset%51375912011D
      static void reset ();

      //## Operation: rollback%36FA50E0038A
      static int rollback ();

      //## Operation: setGMT%665E18B10349
      void setGMT ();

      //## Operation: terminate%3783824B0392
      static void terminate ();

      //## Operation: update%513758EB0075
      static void update ();

      //## Operation: updateCDNHash%36F95339001B
      void updateCDNHash (double dAPHash);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: AP_Count%36F9495E03D5
      const int getAP_Count () const
      {
        //## begin qr::Control::getAP_Count%36F9495E03D5.get preserve=no
        return m_lAP_Count;
        //## end qr::Control::getAP_Count%36F9495E03D5.get
      }

      void setAP_Count (int value)
      {
        //## begin qr::Control::setAP_Count%36F9495E03D5.set preserve=no
        m_lAP_Count = value;
        //## end qr::Control::setAP_Count%36F9495E03D5.set
      }


      //## Attribute: AP_Hash%36F9494D018B
      const double getAP_Hash () const
      {
        //## begin qr::Control::getAP_Hash%36F9494D018B.get preserve=no
        return m_dAP_Hash;
        //## end qr::Control::getAP_Hash%36F9494D018B.get
      }

      void setAP_Hash (double value)
      {
        //## begin qr::Control::setAP_Hash%36F9494D018B.set preserve=no
        m_dAP_Hash = value;
        //## end qr::Control::setAP_Hash%36F9494D018B.set
      }


      //## Attribute: CDN_Count%36F9493D00FC
      const int getCDN_Count () const
      {
        //## begin qr::Control::getCDN_Count%36F9493D00FC.get preserve=no
        return m_lCDN_Count;
        //## end qr::Control::getCDN_Count%36F9493D00FC.get
      }


      //## Attribute: CDN_Hash%36F9491902EF
      const double getCDN_Hash () const
      {
        //## begin qr::Control::getCDN_Hash%36F9491902EF.get preserve=no
        return m_dCDN_Hash;
        //## end qr::Control::getCDN_Hash%36F9491902EF.get
      }


      //## Attribute: DST%666767FF02C2
      void setDST (const bool& value)
      {
        //## begin qr::Control::setDST%666767FF02C2.set preserve=no
        m_bDST = value;
        //## end qr::Control::setDST%666767FF02C2.set
      }


      //## Attribute: GMTOffset%665E187D02D1
      const int getGMTOffset () const
      {
        //## begin qr::Control::getGMTOffset%665E187D02D1.get preserve=no
        return m_iGMTOffset;
        //## end qr::Control::getGMTOffset%665E187D02D1.get
      }


      //## Attribute: Temp_CDN_Count%36FA4FE00381
      const int getTemp_CDN_Count () const
      {
        //## begin qr::Control::getTemp_CDN_Count%36FA4FE00381.get preserve=no
        return m_lTemp_CDN_Count;
        //## end qr::Control::getTemp_CDN_Count%36FA4FE00381.get
      }


      //## Attribute: Temp_CDN_Hash%36FA4FF90106
      const double getTemp_CDN_Hash () const
      {
        //## begin qr::Control::getTemp_CDN_Hash%36FA4FF90106.get preserve=no
        return m_dTemp_CDN_Hash;
        //## end qr::Control::getTemp_CDN_Hash%36FA4FF90106.get
      }


      //## Attribute: CountsMatch%38739CE10394
      void setCountsMatch (const bool& value)
      {
        //## begin qr::Control::setCountsMatch%38739CE10394.set preserve=no
        m_bCountsMatch = value;
        //## end qr::Control::setCountsMatch%38739CE10394.set
      }


      //## Attribute: AmountsMatch%38739D1700E8
      void setAmountsMatch (const bool& value)
      {
        //## begin qr::Control::setAmountsMatch%38739D1700E8.set preserve=no
        m_bAmountsMatch = value;
        //## end qr::Control::setAmountsMatch%38739D1700E8.set
      }


      //## Attribute: Logging%3D23058C0232
      static const bool getLogging ()
      {
        //## begin qr::Control::getLogging%3D23058C0232.get preserve=no
        return m_bLogging;
        //## end qr::Control::getLogging%3D23058C0232.get
      }

      static void setLogging (bool value)
      {
        //## begin qr::Control::setLogging%3D23058C0232.set preserve=no
        m_bLogging = value;
        //## end qr::Control::setLogging%3D23058C0232.set
      }


    // Additional Public Declarations
      //## begin qr::Control%36F947F70049.public preserve=yes
      //## end qr::Control%36F947F70049.public

  protected:
    // Additional Protected Declarations
      //## begin qr::Control%36F947F70049.protected preserve=yes
      //## end qr::Control%36F947F70049.protected

  private:
    // Additional Private Declarations
      //## begin qr::Control%36F947F70049.private preserve=yes
      //## end qr::Control%36F947F70049.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin qr::Control::AP_Count%36F9495E03D5.attr preserve=no  public: int {U} 0
      int m_lAP_Count;
      //## end qr::Control::AP_Count%36F9495E03D5.attr

      //## begin qr::Control::AP_Hash%36F9494D018B.attr preserve=no  public: double {U} 0
      double m_dAP_Hash;
      //## end qr::Control::AP_Hash%36F9494D018B.attr

      //## begin qr::Control::CDN_Count%36F9493D00FC.attr preserve=no  public: int {U} 0
      int m_lCDN_Count;
      //## end qr::Control::CDN_Count%36F9493D00FC.attr

      //## begin qr::Control::CDN_Hash%36F9491902EF.attr preserve=no  public: double {U} 0
      double m_dCDN_Hash;
      //## end qr::Control::CDN_Hash%36F9491902EF.attr

      //## Attribute: Controls%36F9499600FA
      //## begin qr::Control::Controls%36F9499600FA.attr preserve=no  private: static map<string, Control*, less<string> >* {U} 0
      static map<string, Control*, less<string> >* m_pControls;
      //## end qr::Control::Controls%36F9499600FA.attr

      //## begin qr::Control::DST%666767FF02C2.attr preserve=no  public: bool {U} false
      bool m_bDST;
      //## end qr::Control::DST%666767FF02C2.attr

      //## begin qr::Control::GMTOffset%665E187D02D1.attr preserve=no  public: int {U} 0
      int m_iGMTOffset;
      //## end qr::Control::GMTOffset%665E187D02D1.attr

      //## Attribute: LoggerName%36F948E60328
      //## begin qr::Control::LoggerName%36F948E60328.attr preserve=no  private: string {U} 
      string m_strLoggerName;
      //## end qr::Control::LoggerName%36F948E60328.attr

      //## Attribute: LogOpenTimestamp%36F949060342
      //## begin qr::Control::LogOpenTimestamp%36F949060342.attr preserve=no  private: string {U} 
      string m_strLogOpenTimestamp;
      //## end qr::Control::LogOpenTimestamp%36F949060342.attr

      //## begin qr::Control::Temp_CDN_Count%36FA4FE00381.attr preserve=no  public: int {U} 0
      int m_lTemp_CDN_Count;
      //## end qr::Control::Temp_CDN_Count%36FA4FE00381.attr

      //## begin qr::Control::Temp_CDN_Hash%36FA4FF90106.attr preserve=no  public: double {U} 0
      double m_dTemp_CDN_Hash;
      //## end qr::Control::Temp_CDN_Hash%36FA4FF90106.attr

      //## begin qr::Control::CountsMatch%38739CE10394.attr preserve=no  public: bool {U} false
      bool m_bCountsMatch;
      //## end qr::Control::CountsMatch%38739CE10394.attr

      //## begin qr::Control::AmountsMatch%38739D1700E8.attr preserve=no  public: bool {U} false
      bool m_bAmountsMatch;
      //## end qr::Control::AmountsMatch%38739D1700E8.attr

      //## begin qr::Control::Logging%3D23058C0232.attr preserve=no  public: static bool {U} false
      static bool m_bLogging;
      //## end qr::Control::Logging%3D23058C0232.attr

    // Additional Implementation Declarations
      //## begin qr::Control%36F947F70049.implementation preserve=yes
      //## end qr::Control%36F947F70049.implementation

};

//## begin qr::Control%36F947F70049.postscript preserve=yes
//## end qr::Control%36F947F70049.postscript

} // namespace qr

//## begin module%36F9482501C2.epilog preserve=yes
//## end module%36F9482501C2.epilog


#endif
