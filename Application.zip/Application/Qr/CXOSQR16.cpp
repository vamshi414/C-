//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4F16415E02B3.cm preserve=no
//## end module%4F16415E02B3.cm

//## begin module%4F16415E02B3.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4F16415E02B3.cp

//## Module: CXOSQR16%4F16415E02B3; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR16.cpp

//## begin module%4F16415E02B3.additionalIncludes preserve=no
//## end module%4F16415E02B3.additionalIncludes

//## begin module%4F16415E02B3.includes preserve=yes
#include "CXODRS58.hpp"
//## end module%4F16415E02B3.includes

#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSQR04_h
#include "CXODQR04.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSQR22_h
#include "CXODQR22.hpp"
#endif
#ifndef CXOSQR16_h
#include "CXODQR16.hpp"
#endif


//## begin module%4F16415E02B3.declarations preserve=no
//## end module%4F16415E02B3.declarations

//## begin module%4F16415E02B3.additionalDeclarations preserve=yes
//## end module%4F16415E02B3.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::TransactionActivityHandler 

TransactionActivityHandler::TransactionActivityHandler()
  //## begin TransactionActivityHandler::TransactionActivityHandler%4F163F2503A8_const.hasinit preserve=no
  //## end TransactionActivityHandler::TransactionActivityHandler%4F163F2503A8_const.hasinit
  //## begin TransactionActivityHandler::TransactionActivityHandler%4F163F2503A8_const.initialization preserve=yes
  //## end TransactionActivityHandler::TransactionActivityHandler%4F163F2503A8_const.initialization
{
  //## begin qr::TransactionActivityHandler::TransactionActivityHandler%4F163F2503A8_const.body preserve=yes
   memcpy(m_sID,"QR16",4);
  //## end qr::TransactionActivityHandler::TransactionActivityHandler%4F163F2503A8_const.body
}

TransactionActivityHandler::TransactionActivityHandler (Handler* pHandler)
  //## begin qr::TransactionActivityHandler::TransactionActivityHandler%4F163FEE0036.hasinit preserve=no
  //## end qr::TransactionActivityHandler::TransactionActivityHandler%4F163FEE0036.hasinit
  //## begin qr::TransactionActivityHandler::TransactionActivityHandler%4F163FEE0036.initialization preserve=yes
  //## end qr::TransactionActivityHandler::TransactionActivityHandler%4F163FEE0036.initialization
{
  //## begin qr::TransactionActivityHandler::TransactionActivityHandler%4F163FEE0036.body preserve=yes
   memcpy(m_sID,"QR16",4);
   m_pSuccessor = pHandler;
  //## end qr::TransactionActivityHandler::TransactionActivityHandler%4F163FEE0036.body
}


TransactionActivityHandler::~TransactionActivityHandler()
{
  //## begin qr::TransactionActivityHandler::~TransactionActivityHandler%4F163F2503A8_dest.body preserve=yes
  //## end qr::TransactionActivityHandler::~TransactionActivityHandler%4F163F2503A8_dest.body
}



//## Other Operations (implementation)
void TransactionActivityHandler::update (Subject* pSubject)
{
  //## begin qr::TransactionActivityHandler::update%4F163F4F034B.body preserve=yes
   if (!SwitchInterfacePool::instance()->send(Message::instance(Message::INBOUND), Queue::DATAGRAM))
   {
      Console::display("ST248");
      Batch::instance()->restart();
      return;
   }
   segTransactionActivity* pTransactionActivity = (segTransactionActivity*)Message::instance(Message::INBOUND)->data();
   string strHash(pTransactionActivity->sTSTAMP_LOCAL + 8,6);
   unsigned int lHash = atol(strHash.c_str());
   string strLoggerName("TXNACT");
   string strLogOpenTimestamp("0000000000000000");
   Control* pControl = Control::locate(strLoggerName,strLogOpenTimestamp);
   string strTemp(pTransactionActivity->sTSTAMP_TRANS,16);
   pControl->updateCDNHash(lHash);
   Batch::instance()->addRecord(lHash);
   // update Logger in map of loggers with latest TIMESTAMP
   APEventHandler::instance()->update(strLoggerName,strTemp);
   Batch::instance()->update(Message::instance(Message::INBOUND)->getDestination(),strTemp);
  //## end qr::TransactionActivityHandler::update%4F163F4F034B.body
}

// Additional Declarations
  //## begin qr::TransactionActivityHandler%4F163F2503A8.declarations preserve=yes
  //## end qr::TransactionActivityHandler%4F163F2503A8.declarations

} // namespace qr

//## begin module%4F16415E02B3.epilog preserve=yes
//## end module%4F16415E02B3.epilog
