//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36F7C9F90346.cm preserve=no
//## end module%36F7C9F90346.cm

//## begin module%36F7C9F90346.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36F7C9F90346.cp

//## Module: CXOSQR04%36F7C9F90346; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR04.hpp

#ifndef CXOSQR04_h
#define CXOSQR04_h 1

//## begin module%36F7C9F90346.additionalIncludes preserve=no
//## end module%36F7C9F90346.additionalIncludes

//## begin module%36F7C9F90346.includes preserve=yes
#include <vector>
#include "CXODRS28.hpp"
//## end module%36F7C9F90346.includes

#ifndef CXOSIF84_h
#include "CXODIF84.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN03_h
#include "CXODMN03.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class SwitchInterfacePool;
} // namespace qr

//## Modelname: DataNavigator Foundation::SwitchInterface_CAT%358EB6E20186
namespace switchinterface {
class Hash;
} // namespace switchinterface

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class CriticalSection;
class Signal;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
class Timestamp;
class Console;
class ExternalQueue;
class QueueManager;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
class Count;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Clock;
class MidnightAlarm;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%36F7C9F90346.declarations preserve=no
//## end module%36F7C9F90346.declarations

//## begin module%36F7C9F90346.additionalDeclarations preserve=yes
//## end module%36F7C9F90346.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::Batch%36F7C9D8033F.preface preserve=yes
//## end qr::Batch%36F7C9D8033F.preface

//## Class: Batch%36F7C9D8033F
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%36F7CF3E0273;reusable::Signal { -> F}
//## Uses: <unnamed>%36F7E148035A;database::Database { -> F}
//## Uses: <unnamed>%36F7E4DF0239;timer::Clock { -> F}
//## Uses: <unnamed>%36F7E68E0026;IF::QueueManager { -> F}
//## Uses: <unnamed>%36F8FB9F0082;IF::Message { -> }
//## Uses: <unnamed>%36FA65C000EF;Control { -> }
//## Uses: <unnamed>%3716034700D5;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%37163B6503D5;IF::Console { -> F}
//## Uses: <unnamed>%3725E1E9020F;process::Application { -> F}
//## Uses: <unnamed>%372DC91D0000;monitor::Count { -> F}
//## Uses: <unnamed>%3A4A1FE50141;monitor::UseCase { -> F}
//## Uses: <unnamed>%3CB20EC50167;reusable::CriticalSection { -> F}
//## Uses: <unnamed>%49B954A8004E;IF::ExternalQueue { -> F}
//## Uses: <unnamed>%4A43A5880186;switchinterface::Hash { -> F}
//## Uses: <unnamed>%4AA94E810399;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%50D6A1E201B4;IF::Timestamp { -> F}
//## Uses: <unnamed>%50D6A2E102E3;IF::Extract { -> F}
//## Uses: <unnamed>%632CC7EF021B;SwitchInterfacePool { -> F}

class Batch : public IF::Batch  //## Inherits: <unnamed>%665A026D03CB
{
  //## begin qr::Batch%36F7C9D8033F.initialDeclarations preserve=yes
  //## end qr::Batch%36F7C9D8033F.initialDeclarations

  public:
    //## Constructors (generated)
      Batch();

    //## Destructor (generated)
      virtual ~Batch();


    //## Other Operations (specified)
      //## Operation: add%49B952E4037A
      void add (reusable::Signal* pSignal = 0, ExternalQueue* pQueue = 0);

      //## Operation: addRecord%36F80C7A0260
      void addRecord (unsigned int iHash);

      //## Operation: beginBlock%49BEBF4C00DA
      void beginBlock ();

      //## Operation: endBlock%4AAA79AE0186
      void endBlock ();

      //## Operation: onConfirm%36F9093702CB
      void onConfirm ();

      //## Operation: restart%3714B6AF027F
      void restart (int iSeconds = 0);

      //## Operation: update%36F7CCFE0301
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

      //## Operation: update%4C5EBE960338
      void update (const string& strQueueName, const string& strTimestamp);

      //## Operation: updateLogConfirmation%37319D4C0315
      void updateLogConfirmation ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: State%36F7E441017E
      const State& getState () const
      {
        //## begin qr::Batch::getState%36F7E441017E.get preserve=no
        return m_nState;
        //## end qr::Batch::getState%36F7E441017E.get
      }


    // Additional Public Declarations
      //## begin qr::Batch%36F7C9D8033F.public preserve=yes
      //## end qr::Batch%36F7C9D8033F.public

  protected:
    // Additional Protected Declarations
      //## begin qr::Batch%36F7C9D8033F.protected preserve=yes
      //## end qr::Batch%36F7C9D8033F.protected

  private:

    //## Other Operations (specified)
      //## Operation: begin%36F7E1AE03B1
      void begin (bool bMinuteTimer = false);

      //## Operation: clear%4AA9261C032C
      bool clear ();

      //## Operation: commit%36F7E60A02D9
      bool commit ();

      //## Operation: end%36F8F910018F
      void end ();

      //## Operation: rollback%36F809FF01C7
      int rollback ();

    // Additional Private Declarations
      //## begin qr::Batch%36F7C9D8033F.private preserve=yes
      //## end qr::Batch%36F7C9D8033F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: LogConfirmations%36F7E2E801DC
      //## begin qr::Batch::LogConfirmations%36F7E2E801DC.attr preserve=no  private: vector<int> {U} 
      vector<int> m_hLogConfirmations;
      //## end qr::Batch::LogConfirmations%36F7E2E801DC.attr

      //## Attribute: Queue%49B952A10128
      //## begin qr::Batch::Queue%49B952A10128.attr preserve=no  private: vector<pair<Signal*, ExternalQueue*> > {U} 
      vector<pair<Signal*, ExternalQueue*> > m_hQueue;
      //## end qr::Batch::Queue%49B952A10128.attr

      //## begin qr::Batch::State%36F7E441017E.attr preserve=no  public: State {U} IDLE
      State m_nState;
      //## end qr::Batch::State%36F7E441017E.attr

    // Data Members for Associations

      //## Association: Continuous Feed::QueueReader_CAT::<unnamed>%3C60270A0271
      //## Role: Batch::<m_hInterval>%3C60270B0177
      //## begin qr::Batch::<m_hInterval>%3C60270B0177.role preserve=no  public: monitor::Interval { -> VHgN}
      monitor::Interval m_hInterval;
      //## end qr::Batch::<m_hInterval>%3C60270B0177.role

    // Additional Implementation Declarations
      //## begin qr::Batch%36F7C9D8033F.implementation preserve=yes
      //## end qr::Batch%36F7C9D8033F.implementation

};

//## begin qr::Batch%36F7C9D8033F.postscript preserve=yes
//## end qr::Batch%36F7C9D8033F.postscript

} // namespace qr

//## begin module%36F7C9F90346.epilog preserve=yes
using namespace qr;
//## end module%36F7C9F90346.epilog


#endif
