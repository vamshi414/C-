//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%393559490288.cm preserve=no
//## end module%393559490288.cm

//## begin module%393559490288.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%393559490288.cp

//## Module: CXOSQR13%393559490288; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR13.cpp

//## begin module%393559490288.additionalIncludes preserve=no
//## end module%393559490288.additionalIncludes

//## begin module%393559490288.includes preserve=yes
// $Date:   Apr 09 2004 07:48:44  $ $Author:   D02405  $ $Revision:   1.8  $
#include <stdio.h>
#include "CXODRU24.hpp"
//## end module%393559490288.includes

#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif
#ifndef CXOSQR12_h
#include "CXODQR12.hpp"
#endif
#ifndef CXOSRS12_h
#include "CXODRS12.hpp"
#endif
#ifndef CXOSQR13_h
#include "CXODQR13.hpp"
#endif


//## begin module%393559490288.declarations preserve=no
//## end module%393559490288.declarations

//## begin module%393559490288.additionalDeclarations preserve=yes
//## end module%393559490288.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::ExtAPControlHandler 

ExtAPControlHandler::ExtAPControlHandler()
  //## begin ExtAPControlHandler::ExtAPControlHandler%3935589F0175_const.hasinit preserve=no
  //## end ExtAPControlHandler::ExtAPControlHandler%3935589F0175_const.hasinit
  //## begin ExtAPControlHandler::ExtAPControlHandler%3935589F0175_const.initialization preserve=yes
  //## end ExtAPControlHandler::ExtAPControlHandler%3935589F0175_const.initialization
{
  //## begin qr::ExtAPControlHandler::ExtAPControlHandler%3935589F0175_const.body preserve=yes
   memcpy(m_sID,"QR13",4);
  //## end qr::ExtAPControlHandler::ExtAPControlHandler%3935589F0175_const.body
}

ExtAPControlHandler::ExtAPControlHandler (Handler* pHandler)
  //## begin qr::ExtAPControlHandler::ExtAPControlHandler%39355C130180.hasinit preserve=no
  //## end qr::ExtAPControlHandler::ExtAPControlHandler%39355C130180.hasinit
  //## begin qr::ExtAPControlHandler::ExtAPControlHandler%39355C130180.initialization preserve=yes
  //## end qr::ExtAPControlHandler::ExtAPControlHandler%39355C130180.initialization
{
  //## begin qr::ExtAPControlHandler::ExtAPControlHandler%39355C130180.body preserve=yes
   m_pSuccessor = pHandler;
   memcpy(m_sID,"QR13",4);
  //## end qr::ExtAPControlHandler::ExtAPControlHandler%39355C130180.body
}


ExtAPControlHandler::~ExtAPControlHandler()
{
  //## begin qr::ExtAPControlHandler::~ExtAPControlHandler%3935589F0175_dest.body preserve=yes
  //## end qr::ExtAPControlHandler::~ExtAPControlHandler%3935589F0175_dest.body
}



//## Other Operations (implementation)
void ExtAPControlHandler::update (Subject* pSubject)
{
  //## begin qr::ExtAPControlHandler::update%39355C0E020F.body preserve=yes
   // ** previous logger totals: ***
   m_strLoggerName = ExternalMessageSegment::instance()->getNodeName();
   m_strLogOpenTimestamp = ExternalMessageSegment::instance()->getNodeTstamp();

   if (!APEventHandler::instance()->isValidLoggerName(m_strLoggerName))
      return;

   m_dAPHash  = atof(ExternalMessageSegment::instance()->getTotalTransAmt().c_str());
   m_lAPCount = (ExternalMessageSegment::instance()->getTotalTransCnt());
   APControlHandler::update(pSubject);
  //## end qr::ExtAPControlHandler::update%39355C0E020F.body
}

// Additional Declarations
  //## begin qr::ExtAPControlHandler%3935589F0175.declarations preserve=yes
  //## end qr::ExtAPControlHandler%3935589F0175.declarations

} // namespace qr

//## begin module%393559490288.epilog preserve=yes
//## end module%393559490288.epilog
