//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4F1641C80302.cm preserve=no
//## end module%4F1641C80302.cm

//## begin module%4F1641C80302.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4F1641C80302.cp

//## Module: CXOSQR17%4F1641C80302; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR17.hpp

#ifndef CXOSQR17_h
#define CXOSQR17_h 1

//## begin module%4F1641C80302.additionalIncludes preserve=no
//## end module%4F1641C80302.additionalIncludes

//## begin module%4F1641C80302.includes preserve=yes
//## end module%4F1641C80302.includes

#ifndef CXOSQR02_h
#include "CXODQR02.hpp"
#endif
//## begin module%4F1641C80302.declarations preserve=no
//## end module%4F1641C80302.declarations

//## begin module%4F1641C80302.additionalDeclarations preserve=yes
//## end module%4F1641C80302.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::TransactionActivityControlHandler%4F163F7A02C1.preface preserve=yes
//## end qr::TransactionActivityControlHandler%4F163F7A02C1.preface

//## Class: TransactionActivityControlHandler%4F163F7A02C1
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport TransactionActivityControlHandler : public APControlHandler  //## Inherits: <unnamed>%4F16E92A005B
{
  //## begin qr::TransactionActivityControlHandler%4F163F7A02C1.initialDeclarations preserve=yes
  //## end qr::TransactionActivityControlHandler%4F163F7A02C1.initialDeclarations

  public:
    //## Constructors (generated)
      TransactionActivityControlHandler();

    //## Constructors (specified)
      //## Operation: TransactionActivityControlHandler%4F16409702FA
      TransactionActivityControlHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~TransactionActivityControlHandler();


    //## Other Operations (specified)
      //## Operation: update%4F163FA0024C
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin qr::TransactionActivityControlHandler%4F163F7A02C1.public preserve=yes
      //## end qr::TransactionActivityControlHandler%4F163F7A02C1.public

  protected:
    // Additional Protected Declarations
      //## begin qr::TransactionActivityControlHandler%4F163F7A02C1.protected preserve=yes
      //## end qr::TransactionActivityControlHandler%4F163F7A02C1.protected

  private:
    // Additional Private Declarations
      //## begin qr::TransactionActivityControlHandler%4F163F7A02C1.private preserve=yes
      //## end qr::TransactionActivityControlHandler%4F163F7A02C1.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin qr::TransactionActivityControlHandler%4F163F7A02C1.implementation preserve=yes
      //## end qr::TransactionActivityControlHandler%4F163F7A02C1.implementation

};

//## begin qr::TransactionActivityControlHandler%4F163F7A02C1.postscript preserve=yes
//## end qr::TransactionActivityControlHandler%4F163F7A02C1.postscript

} // namespace qr

//## begin module%4F1641C80302.epilog preserve=yes
//## end module%4F1641C80302.epilog


#endif
