//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36F2D03F01D0.cm preserve=no
//## end module%36F2D03F01D0.cm

//## begin module%36F2D03F01D0.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36F2D03F01D0.cp

//## Module: CXOSQR09%36F2D03F01D0; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR09.hpp

#ifndef CXOSQR09_h
#define CXOSQR09_h 1

//## begin module%36F2D03F01D0.additionalIncludes preserve=no
//## end module%36F2D03F01D0.additionalIncludes

//## begin module%36F2D03F01D0.includes preserve=yes
// $Date:   Apr 09 2004 07:48:38  $ $Author:   D02405  $ $Revision:   1.5  $
//## end module%36F2D03F01D0.includes

#ifndef CXOSRU14_h
#include "CXODRU14.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Batch;
class SwitchInterfacePool;
class APEventHandler;
class Control;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class DateTime;
class Extract;
class Console;
class Decimal;
class Queue;
class CodeTable;
class Trace;
class Log;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;

} // namespace segment

//## begin module%36F2D03F01D0.declarations preserve=no
//## end module%36F2D03F01D0.declarations

//## begin module%36F2D03F01D0.additionalDeclarations preserve=yes
//## end module%36F2D03F01D0.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::IBMAPTranHandler%36F2CF6F028F.preface preserve=yes
//## end qr::IBMAPTranHandler%36F2CF6F028F.preface

//## Class: IBMAPTranHandler%36F2CF6F028F
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%36F8018801F3;IF::Message { -> F}
//## Uses: <unnamed>%36F808E50294;Batch { -> F}
//## Uses: <unnamed>%36F8090103CB;IF::Log { -> F}
//## Uses: <unnamed>%36F80B4D002D;IF::Queue { -> F}
//## Uses: <unnamed>%36FA653203DA;Control { -> F}
//## Uses: <unnamed>%36FFCA34010D;IF::Trace { -> F}
//## Uses: <unnamed>%370A509C01A2;segment::Segment { -> F}
//## Uses: <unnamed>%37125EA90013;IF::DateTime { -> F}
//## Uses: <unnamed>%371DF5670250;IF::CodeTable { -> F}
//## Uses: <unnamed>%3725DFCE03B8;IF::Extract { -> F}
//## Uses: <unnamed>%3756B66C0259;IF::Console { -> F}
//## Uses: <unnamed>%378E5326018A;APEventHandler { -> F}
//## Uses: <unnamed>%37CA9F0E0348;IF::Decimal { -> F}
//## Uses: <unnamed>%6391124E031A;SwitchInterfacePool { -> F}

class IBMAPTranHandler : public reusable::Handler  //## Inherits: <unnamed>%36F7BFB901DA
{
  //## begin qr::IBMAPTranHandler%36F2CF6F028F.initialDeclarations preserve=yes
  //## end qr::IBMAPTranHandler%36F2CF6F028F.initialDeclarations

  public:
    //## Constructors (generated)
      IBMAPTranHandler();

    //## Constructors (specified)
      //## Operation: IBMAPTranHandler%36F7F7DA011E
      IBMAPTranHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~IBMAPTranHandler();


    //## Other Operations (specified)
      //## Operation: update%36F7FCE50002
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Logging%3729C05203DA
      static const bool getLogging ()
      {
        //## begin qr::IBMAPTranHandler::getLogging%3729C05203DA.get preserve=no
        return m_bLogging;
        //## end qr::IBMAPTranHandler::getLogging%3729C05203DA.get
      }

      static void setLogging (bool value)
      {
        //## begin qr::IBMAPTranHandler::setLogging%3729C05203DA.set preserve=no
        m_bLogging = value;
        //## end qr::IBMAPTranHandler::setLogging%3729C05203DA.set
      }


    // Additional Public Declarations
      //## begin qr::IBMAPTranHandler%36F2CF6F028F.public preserve=yes
      //## end qr::IBMAPTranHandler%36F2CF6F028F.public

  protected:
    // Additional Protected Declarations
      //## begin qr::IBMAPTranHandler%36F2CF6F028F.protected preserve=yes
      //## end qr::IBMAPTranHandler%36F2CF6F028F.protected

  private:
    // Additional Private Declarations
      //## begin qr::IBMAPTranHandler%36F2CF6F028F.private preserve=yes
      //## end qr::IBMAPTranHandler%36F2CF6F028F.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: LoggerName%371252530044
      //## begin qr::IBMAPTranHandler::LoggerName%371252530044.attr preserve=no  private: string {U} 
      string m_strLoggerName;
      //## end qr::IBMAPTranHandler::LoggerName%371252530044.attr

      //## Attribute: LogOpenTimestamp%3712526B0193
      //## begin qr::IBMAPTranHandler::LogOpenTimestamp%3712526B0193.attr preserve=no  private: string {U} 
      string m_strLogOpenTimestamp;
      //## end qr::IBMAPTranHandler::LogOpenTimestamp%3712526B0193.attr

      //## begin qr::IBMAPTranHandler::Logging%3729C05203DA.attr preserve=no  public: static bool {U} false
      static bool m_bLogging;
      //## end qr::IBMAPTranHandler::Logging%3729C05203DA.attr

    // Additional Implementation Declarations
      //## begin qr::IBMAPTranHandler%36F2CF6F028F.implementation preserve=yes
      //## end qr::IBMAPTranHandler%36F2CF6F028F.implementation

};

//## begin qr::IBMAPTranHandler%36F2CF6F028F.postscript preserve=yes
//## end qr::IBMAPTranHandler%36F2CF6F028F.postscript

} // namespace qr

//## begin module%36F2D03F01D0.epilog preserve=yes
//## end module%36F2D03F01D0.epilog


#endif
