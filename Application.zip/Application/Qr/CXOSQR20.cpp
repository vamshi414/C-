//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EC7392C02DD.cm preserve=no
//## end module%5EC7392C02DD.cm

//## begin module%5EC7392C02DD.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5EC7392C02DD.cp

//## Module: CXOSQR20%5EC7392C02DD; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR20.cpp

//## begin module%5EC7392C02DD.additionalIncludes preserve=no
//## end module%5EC7392C02DD.additionalIncludes

//## begin module%5EC7392C02DD.includes preserve=yes
#ifdef _WIN32
#include <winsock.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
#
#include "CXODPP02.hpp"
#include "CXODIF04.hpp"
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
//## end module%5EC7392C02DD.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSQR04_h
#include "CXODQR04.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif
#ifndef CXOSQR22_h
#include "CXODQR22.hpp"
#endif
#ifndef CXOSQR20_h
#include "CXODQR20.hpp"
#endif


//## begin module%5EC7392C02DD.declarations preserve=no
//## end module%5EC7392C02DD.declarations

//## begin module%5EC7392C02DD.additionalDeclarations preserve=yes
//## end module%5EC7392C02DD.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::PostilionHandler 

PostilionHandler::PostilionHandler()
  //## begin PostilionHandler::PostilionHandler%5EC6DA4C0126_const.hasinit preserve=no
  //## end PostilionHandler::PostilionHandler%5EC6DA4C0126_const.hasinit
  //## begin PostilionHandler::PostilionHandler%5EC6DA4C0126_const.initialization preserve=yes
  //## end PostilionHandler::PostilionHandler%5EC6DA4C0126_const.initialization
{
  //## begin qr::PostilionHandler::PostilionHandler%5EC6DA4C0126_const.body preserve=yes
  //## end qr::PostilionHandler::PostilionHandler%5EC6DA4C0126_const.body
}

PostilionHandler::PostilionHandler (Handler* pHandler)
  //## begin qr::PostilionHandler::PostilionHandler%5EC737DF01B0.hasinit preserve=no
  //## end qr::PostilionHandler::PostilionHandler%5EC737DF01B0.hasinit
  //## begin qr::PostilionHandler::PostilionHandler%5EC737DF01B0.initialization preserve=yes
  //## end qr::PostilionHandler::PostilionHandler%5EC737DF01B0.initialization
{
  //## begin qr::PostilionHandler::PostilionHandler%5EC737DF01B0.body preserve=yes
   memcpy(m_sID,"QR20",4);
   m_pSuccessor = pHandler;
  //## end qr::PostilionHandler::PostilionHandler%5EC737DF01B0.body
}


PostilionHandler::~PostilionHandler()
{
  //## begin qr::PostilionHandler::~PostilionHandler%5EC6DA4C0126_dest.body preserve=yes
  //## end qr::PostilionHandler::~PostilionHandler%5EC6DA4C0126_dest.body
}



//## Other Operations (implementation)
void PostilionHandler::update (Subject* pSubject)
{
  //## begin qr::PostilionHandler::update%5EC737ED0134.body preserve=yes
   struct hPostilionControl* pPostilionControl = (struct hPostilionControl*)Message::instance(Message::INBOUND)->data();
   struct hPostilionFinancial* pPostilionFinancial = (struct hPostilionFinancial*)Message::instance(Message::INBOUND)->data();
   char* p = (char*)pPostilionControl;
   if (ntohs(pPostilionControl->siMsgType) == 904)
       m_pSuccessor->update(pSubject);
   Message::instance(Message::OUTBOUND)->reset("QR AI ","S0059D");
   memcpy(Message::instance(Message::OUTBOUND)->data(),p,Message::instance(Message::INBOUND)->dataLength());
   Message::instance(Message::OUTBOUND)->setDataLength(Message::instance(Message::INBOUND)->dataLength());
   if (!SwitchInterfacePool::instance()->send(Message::instance(Message::OUTBOUND), Queue::DATAGRAM))
   {
      Console::display("ST248");
      Batch::instance()->restart();
      return;
   }
   if (ntohs(pPostilionControl->siMsgType) == 904)
   {
      Batch::instance()->addRecord(0);
      return;
   }
#ifdef MVS
   CodeTable::translate(pPostilionControl->sLoggerName,6,CodeTable::CX_ASCII_TO_EBCDIC);
   CodeTable::translate(pPostilionControl->sLogOpenTime,16,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   string strLogOpenTimestamp(pPostilionControl->sLogOpenTime,16);
   string strLoggerName(pPostilionControl->sLoggerName,6);
   Control* pControl = Control::locate(strLoggerName,strLogOpenTimestamp);
   double dAPHash = Segment::atol(pPostilionFinancial->stime_local, 6);  // !!! confirm with Nick
   pControl->updateCDNHash(dAPHash);
   Batch::instance()->addRecord(dAPHash);
   string strTimestamp(pPostilionFinancial->sin_req, 16);
   if (ntohl(pPostilionFinancial->imsg_type) == 0x420 || ntohl(pPostilionFinancial->imsg_type) == 0x421)
      strTimestamp.assign(pPostilionFinancial->sin_rev, 16);
   else if (ntohl(pPostilionFinancial->imsg_type) == 0x120 || ntohl(pPostilionFinancial->imsg_type) == 0x220
      || ntohl(pPostilionFinancial->imsg_type) == 0x221 || ntohl(pPostilionFinancial->imsg_type) == 0x620)
      strTimestamp.assign(pPostilionFinancial->sin_adv, 16);
   APEventHandler::instance()->update(strLoggerName,strTimestamp);
   Batch::instance()->update(Message::instance(Message::INBOUND)->getDestination(),strTimestamp);
  //## end qr::PostilionHandler::update%5EC737ED0134.body
}

// Additional Declarations
  //## begin qr::PostilionHandler%5EC6DA4C0126.declarations preserve=yes
  //## end qr::PostilionHandler%5EC6DA4C0126.declarations

} // namespace qr

//## begin module%5EC7392C02DD.epilog preserve=yes
//## end module%5EC7392C02DD.epilog
