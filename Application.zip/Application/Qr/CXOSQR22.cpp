//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%632B4D68017A.cm preserve=no
//## end module%632B4D68017A.cm

//## begin module%632B4D68017A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%632B4D68017A.cp

//## Module: CXOSQR22%632B4D68017A; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR22.cpp

//## begin module%632B4D68017A.additionalIncludes preserve=no
//## end module%632B4D68017A.additionalIncludes

//## begin module%632B4D68017A.includes preserve=yes
//## end module%632B4D68017A.includes

#ifndef CXOSSI05_h
#include "CXODSI05.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSQR22_h
#include "CXODQR22.hpp"
#endif


//## begin module%632B4D68017A.declarations preserve=no
//## end module%632B4D68017A.declarations

//## begin module%632B4D68017A.additionalDeclarations preserve=yes
//## end module%632B4D68017A.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::SwitchInterfacePool 

//## begin qr::SwitchInterfacePool::Instance%632CC62C03D0.attr preserve=no  private: static qr::SwitchInterfacePool {R} 0
qr::SwitchInterfacePool *SwitchInterfacePool::m_pInstance = 0;
//## end qr::SwitchInterfacePool::Instance%632CC62C03D0.attr

SwitchInterfacePool::SwitchInterfacePool()
  //## begin SwitchInterfacePool::SwitchInterfacePool%632B4D170274_const.hasinit preserve=no
      : m_iHashSentCount(0),
        m_bHashFail(false)
  //## end SwitchInterfacePool::SwitchInterfacePool%632B4D170274_const.hasinit
  //## begin SwitchInterfacePool::SwitchInterfacePool%632B4D170274_const.initialization preserve=yes
  //## end SwitchInterfacePool::SwitchInterfacePool%632B4D170274_const.initialization
{
  //## begin qr::SwitchInterfacePool::SwitchInterfacePool%632B4D170274_const.body preserve=yes
   m_pAI = m_hPool[AVAILABLE].end();
  //## end qr::SwitchInterfacePool::SwitchInterfacePool%632B4D170274_const.body
}


SwitchInterfacePool::~SwitchInterfacePool()
{
  //## begin qr::SwitchInterfacePool::~SwitchInterfacePool%632B4D170274_dest.body preserve=yes
  //## end qr::SwitchInterfacePool::~SwitchInterfacePool%632B4D170274_dest.body
}



//## Other Operations (implementation)
void SwitchInterfacePool::add (const string strSwitchInterface)
{
  //## begin qr::SwitchInterfacePool::add%632B546A036A.body preserve=yes
   map<string,pair<double,int>, less<string> >::iterator p;
   p = m_hPool[AVAILABLE].find(strSwitchInterface);
   if (p == m_hPool[AVAILABLE].end())
   {
      pair<double, int> hPair(0, 0);
      char buf[20];
      IF::Trace::put(buf, sprintf(buf, "add: %s", strSwitchInterface.c_str()));
      m_hPool[AVAILABLE].insert(map<string, pair<double, int>, less<string> >::value_type(strSwitchInterface, hPair));
      m_pAI = m_hPool[AVAILABLE].begin();
   }
   p = m_hPool[UNAVAILABLE].find(strSwitchInterface); 
   if (p != m_hPool[UNAVAILABLE].end())
      m_hPool[UNAVAILABLE].erase(p);
  //## end qr::SwitchInterfacePool::add%632B546A036A.body
}

void SwitchInterfacePool::clear ()
{
  //## begin qr::SwitchInterfacePool::clear%639219530157.body preserve=yes
   map<string, pair<double,int>, less<string> >::iterator p;
   for (p = m_hPool[AVAILABLE].begin(); p != m_hPool[AVAILABLE].end(); p++)
   {
      (*p).second.first = 0;
      (*p).second.second = 0;
   }
   m_bHashFail = false;
  //## end qr::SwitchInterfacePool::clear%639219530157.body
}

void SwitchInterfacePool::drop (const string strSwitchInterface)
{
  //## begin qr::SwitchInterfacePool::drop%632B54C60228.body preserve=yes
   map<string, pair<double,int>, less<string> >::iterator p;
   p = m_hPool[AVAILABLE].find(strSwitchInterface);
   if (p != m_hPool[AVAILABLE].end())
   {
      m_hPool[AVAILABLE].erase(p);
      char buf[20];
      IF::Trace::put(buf, sprintf(buf, "drop: %s", strSwitchInterface.c_str()));
      m_pAI = (m_hPool[AVAILABLE].size() > 0) ? m_hPool[AVAILABLE].begin() : m_hPool[AVAILABLE].end();
   }
   p = m_hPool[UNAVAILABLE].find(strSwitchInterface);
   if (p == m_hPool[UNAVAILABLE].end())
   {
      pair<double, int> hPair(0, 0);
      m_hPool[UNAVAILABLE].insert(map<string, pair<double, int>, less<string> >::value_type(strSwitchInterface, hPair));
   }
  //## end qr::SwitchInterfacePool::drop%632B54C60228.body
}

int SwitchInterfacePool::handleHashResponse ()
{
  //## begin qr::SwitchInterfacePool::handleHashResponse%632CB76801A7.body preserve=yes
   Message* pMessage = Message::instance(Message::INBOUND);
   hHashMessage* pResponse = (hHashMessage*)pMessage->data();
   if (pResponse->cStatusFlag == 'N')
      m_bHashFail = true;
   if (--m_iHashSentCount == 0)
      return m_bHashFail ? -1 : 1;
   else
      return 0;
  //## end qr::SwitchInterfacePool::handleHashResponse%632CB76801A7.body
}

int SwitchInterfacePool::initialize ()
{
  //## begin qr::SwitchInterfacePool::initialize%632B4F7F0239.body preserve=yes
   int i = 0;
   string strBuffer;
   while (Extract::instance()->getRecord(i, strBuffer))
   {
      if (strBuffer.substr(0, 8) == "DQUEUE  "
         && strBuffer.substr(8, 2) == "AI"
         && strBuffer.find("CXOP") == string::npos)
         add(strBuffer.substr(8, 8).c_str());
      ++i;
   }
   return 0;
  //## end qr::SwitchInterfacePool::initialize%632B4F7F0239.body
}

SwitchInterfacePool* SwitchInterfacePool::instance ()
{
  //## begin qr::SwitchInterfacePool::instance%632CC6AE0006.body preserve=yes
   if (m_pInstance == 0)
      m_pInstance = new SwitchInterfacePool();
   return m_pInstance;
  //## end qr::SwitchInterfacePool::instance%632CC6AE0006.body
}

bool SwitchInterfacePool::send (Message* pMessage, Queue::MessageType nMessageType)
{
  //## begin qr::SwitchInterfacePool::send%632C90570136.body preserve=yes
   if (nMessageType == Queue::REQUEST)
   {
      hHashMessage* pRequest = (hHashMessage*)pMessage->data();
      if(!memcmp(pRequest->sOperation, "ZEROHASH", 8))
      {
         map<string, pair<double, int>, less<string> >::iterator p;
         for (p = m_hPool[AVAILABLE].begin(); p != m_hPool[AVAILABLE].end(); p++)
            Queue::send((*p).first.c_str(), pMessage, Queue::REQUEST);
         if (m_hPool[AVAILABLE].size() == 0)
         {
            vector<string> m_hAdd;
            for (p = m_hPool[UNAVAILABLE].begin(); p != m_hPool[UNAVAILABLE].end(); p++)
            {
               if (Queue::send((*p).first.c_str(), pMessage, Queue::REQUEST))
                  m_hAdd.push_back((*p).first);
            }
            for (int i = 0; i < m_hAdd.size(); i++)
               add(m_hAdd[i]);
         }
         return m_hPool[AVAILABLE].size() > 0;
      }
      else
      if (!memcmp(pRequest->sOperation, "HASHREQ", 7))
      {
         map<string, pair<double, int>, less<string> >::iterator p;
         m_iHashSentCount = 0;
         for (p = m_hPool[AVAILABLE].begin(); p != m_hPool[AVAILABLE].end(); p++)
         {
            //reset values for Acquiring Interface
            pRequest->dHashTotal = (*p).second.first;
            pRequest->lLastRecSeqNo = (*p).second.second;
            pRequest->lTranCnt = (*p).second.second;
            if (!Queue::send((*p).first.c_str(), pMessage, Queue::REQUEST))
            {
               drop((*p).first);
               return false;
            }
            m_iHashSentCount++;
         }
         //send zerohash to unavailable AIs, move to available if send succeeds
         vector<string> m_hAdd;
         for (p = m_hPool[UNAVAILABLE].begin(); p != m_hPool[UNAVAILABLE].end(); p++)
         {
            memcpy(pRequest->sOperation, "ZEROHASH", 8);
            if (Queue::send((*p).first.c_str(), pMessage, Queue::REQUEST))
               m_hAdd.push_back((*p).first);
         }
         for (int i = 0; i < m_hAdd.size(); i++)
            add(m_hAdd[i]);
      }
   }
   else
   if (nMessageType == Queue::DATAGRAM)
   {
      if (m_hPool[AVAILABLE].size() == 0)
         return false;
      m_pAI++;
      if (m_pAI == m_hPool[AVAILABLE].end())
         m_pAI = m_hPool[AVAILABLE].begin();
      if (!Queue::send((*m_pAI).first.c_str(), pMessage, Queue::DATAGRAM))
      {
         drop((*m_pAI).first);
         return false;
      }
   }
   return true;
  //## end qr::SwitchInterfacePool::send%632C90570136.body
}

void SwitchInterfacePool::updateHash (double dHash)
{
  //## begin qr::SwitchInterfacePool::updateHash%6392196501F3.body preserve=yes
   map<string, pair<double,int>, less<string> >::iterator p;
   p = m_hPool[AVAILABLE].find((*m_pAI).first);
   if (p != m_hPool[AVAILABLE].end())
   {
      (*p).second.first += dHash;
      (*p).second.second += 1;
   }
  //## end qr::SwitchInterfacePool::updateHash%6392196501F3.body
}

// Additional Declarations
  //## begin qr::SwitchInterfacePool%632B4D170274.declarations preserve=yes
  //## end qr::SwitchInterfacePool%632B4D170274.declarations

} // namespace qr

//## begin module%632B4D68017A.epilog preserve=yes
//## end module%632B4D68017A.epilog
