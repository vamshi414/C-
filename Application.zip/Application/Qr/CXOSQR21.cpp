//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EC7398D00DC.cm preserve=no
//## end module%5EC7398D00DC.cm

//## begin module%5EC7398D00DC.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%5EC7398D00DC.cp

//## Module: CXOSQR21%5EC7398D00DC; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR21.cpp

//## begin module%5EC7398D00DC.additionalIncludes preserve=no
//## end module%5EC7398D00DC.additionalIncludes

//## begin module%5EC7398D00DC.includes preserve=yes
#ifdef _WIN32
#include <winsock.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
#include "CXODPP02.hpp"
#include "CXODIF04.hpp"
//## end module%5EC7398D00DC.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSQR22_h
#include "CXODQR22.hpp"
#endif
#ifndef CXOSQR21_h
#include "CXODQR21.hpp"
#endif


//## begin module%5EC7398D00DC.declarations preserve=no
//## end module%5EC7398D00DC.declarations

//## begin module%5EC7398D00DC.additionalDeclarations preserve=yes
//## end module%5EC7398D00DC.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::PostilionControlHandler 

PostilionControlHandler::PostilionControlHandler()
  //## begin PostilionControlHandler::PostilionControlHandler%5EC6DA6E01CF_const.hasinit preserve=no
  //## end PostilionControlHandler::PostilionControlHandler%5EC6DA6E01CF_const.hasinit
  //## begin PostilionControlHandler::PostilionControlHandler%5EC6DA6E01CF_const.initialization preserve=yes
  //## end PostilionControlHandler::PostilionControlHandler%5EC6DA6E01CF_const.initialization
{
  //## begin qr::PostilionControlHandler::PostilionControlHandler%5EC6DA6E01CF_const.body preserve=yes
  //## end qr::PostilionControlHandler::PostilionControlHandler%5EC6DA6E01CF_const.body
}

PostilionControlHandler::PostilionControlHandler (Handler* pHandler)
  //## begin qr::PostilionControlHandler::PostilionControlHandler%5EC7368C0347.hasinit preserve=no
  //## end qr::PostilionControlHandler::PostilionControlHandler%5EC7368C0347.hasinit
  //## begin qr::PostilionControlHandler::PostilionControlHandler%5EC7368C0347.initialization preserve=yes
  //## end qr::PostilionControlHandler::PostilionControlHandler%5EC7368C0347.initialization
{
  //## begin qr::PostilionControlHandler::PostilionControlHandler%5EC7368C0347.body preserve=yes
   memcpy(m_sID,"QR21",4);
   m_pSuccessor = pHandler;
  //## end qr::PostilionControlHandler::PostilionControlHandler%5EC7368C0347.body
}


PostilionControlHandler::~PostilionControlHandler()
{
  //## begin qr::PostilionControlHandler::~PostilionControlHandler%5EC6DA6E01CF_dest.body preserve=yes
  //## end qr::PostilionControlHandler::~PostilionControlHandler%5EC6DA6E01CF_dest.body
}



//## Other Operations (implementation)
void PostilionControlHandler::update (Subject* pSubject)
{
  //## begin qr::PostilionControlHandler::update%5EC73695008D.body preserve=yes
   hPostilionControl* p = (hPostilionControl*)Message::instance(Message::INBOUND)->data();
#ifdef MVS
   CodeTable::translate(p->sLoggerName,6,CodeTable::CX_ASCII_TO_EBCDIC);
   CodeTable::translate(p->sLogOpenTime,16,CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   m_strLoggerName.assign(p->sLoggerName,6);
   m_strLogOpenTimestamp.assign(p->sLogOpenTime,16);
   m_dAPHash  = Segment::lltof(ntohl(p->iHash[0]),ntohl(p->iHash[1]));
   m_lAPCount = ntohl(p->iCount);
   Control* pControl = Control::locate(m_strLoggerName,m_strLogOpenTimestamp);
   pControl->updateCDNHash(0);
   APControlHandler::update(pSubject);
  //## end qr::PostilionControlHandler::update%5EC73695008D.body
}

// Additional Declarations
  //## begin qr::PostilionControlHandler%5EC6DA6E01CF.declarations preserve=yes
  //## end qr::PostilionControlHandler%5EC6DA6E01CF.declarations

} // namespace qr

//## begin module%5EC7398D00DC.epilog preserve=yes
//## end module%5EC7398D00DC.epilog
