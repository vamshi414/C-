//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36C87DCD010A.cm preserve=no
//## end module%36C87DCD010A.cm

//## begin module%36C87DCD010A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36C87DCD010A.cp

//## Module: CXOSQR00%36C87DCD010A; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOPQR00.cpp

//## begin module%36C87DCD010A.additionalIncludes preserve=no
//## end module%36C87DCD010A.additionalIncludes

//## begin module%36C87DCD010A.includes preserve=yes
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
#include "CXODIF11.hpp"
#include "CXODIF25.hpp"
#ifndef _UNIX
#include "CXODMQ01.hpp"
#include "CXODMQ04.hpp"
#endif
#include "CXODIF03.hpp"
//## end module%36C87DCD010A.includes

#ifndef CXOSIF32_h
#include "CXODIF32.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSQR04_h
#include "CXODQR04.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif
#ifndef CXOSQR06_h
#include "CXODQR06.hpp"
#endif
#ifndef CXOSQR08_h
#include "CXODQR08.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSQR01_h
#include "CXODQR01.hpp"
#endif
#ifndef CXOSQR13_h
#include "CXODQR13.hpp"
#endif
#ifndef CXOSQR11_h
#include "CXODQR11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF46_h
#include "CXODIF46.hpp"
#endif
#ifndef CXOSIF47_h
#include "CXODIF47.hpp"
#endif
#ifndef CXOSTQ02_h
#include "CXODTQ02.hpp"
#endif
#ifndef CXOSTQ03_h
#include "CXODTQ03.hpp"
#endif
#ifndef CXOSQR15_h
#include "CXODQR15.hpp"
#endif
#ifndef CXOSIF55_h
#include "CXODIF55.hpp"
#endif
#ifndef CXOSQR17_h
#include "CXODQR17.hpp"
#endif
#ifndef CXOSQR10_h
#include "CXODQR10.hpp"
#endif
#ifndef CXOSQR09_h
#include "CXODQR09.hpp"
#endif
#ifndef CXOSQR12_h
#include "CXODQR12.hpp"
#endif
#ifndef CXOSQR07_h
#include "CXODQR07.hpp"
#endif
#ifndef CXOSQR14_h
#include "CXODQR14.hpp"
#endif
#ifndef CXOSQR16_h
#include "CXODQR16.hpp"
#endif
#ifndef CXOSQR21_h
#include "CXODQR21.hpp"
#endif
#ifndef CXOSQR20_h
#include "CXODQR20.hpp"
#endif
#ifndef CXOSQR22_h
#include "CXODQR22.hpp"
#endif
#ifndef CXOSQR02_h
#include "CXODQR02.hpp"
#endif
#ifndef CXOSIF05_h
#include "CXODIF05.hpp"
#endif
#ifndef CXOSRU14_h
#include "CXODRU14.hpp"
#endif
#ifndef CXOSQR00_h
#include "CXODQR00.hpp"
#endif


//## begin module%36C87DCD010A.declarations preserve=no
//## end module%36C87DCD010A.declarations

//## begin module%36C87DCD010A.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new qr::QueueReader();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%36C87DCD010A.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::QueueReader 

QueueReader::QueueReader()
  //## begin QueueReader::QueueReader%36C87D3C0274_const.hasinit preserve=no
      : m_pAPQueue(0),
        m_pAPSignal(0),
        m_lInputType(INPUT_UNDEFINED),
        m_bLogging(false),
        m_bPrimaryQR(false),
        m_bUnblocked(false),
        m_pAPControlHandler(0),
        m_pHandler(0)
  //## end QueueReader::QueueReader%36C87D3C0274_const.hasinit
  //## begin QueueReader::QueueReader%36C87D3C0274_const.initialization preserve=yes
  //## end QueueReader::QueueReader%36C87D3C0274_const.initialization
{
  //## begin qr::QueueReader::QueueReader%36C87D3C0274_const.body preserve=yes
   memcpy(m_sID,"QR00",4);
   m_pMemory = new Memory(4096);
  //## end qr::QueueReader::QueueReader%36C87D3C0274_const.body
}


QueueReader::~QueueReader()
{
  //## begin qr::QueueReader::~QueueReader%36C87D3C0274_dest.body preserve=yes
   if (m_pAPControlHandler)
   {
      delete Batch::instance();
      delete m_pHandler;
      delete m_pAPControlHandler;
      delete APAdvgHeader::instance();
      delete APEventHandler::instance();
      Control::terminate();
   }
   delete m_pMemory;
  //## end qr::QueueReader::~QueueReader%36C87D3C0274_dest.body
}



//## Other Operations (implementation)
int QueueReader::initialize ()
{
  //## begin qr::QueueReader::initialize%36D5B1090164.body preserve=yes
   new dnplatform::DNPlatform();
   int iRC = Application::initialize();
   UseCase hUseCase("LOG","## QR00 START QR");
   if (iRC != 0)
   {
      UseCase::setSuccess(false);
      return iRC;
   }
   SwitchInterfacePool::instance()->initialize();
   int i = 0;
   string strRecord;
   string strSignal;
   Signal* pSignal = 0;
   ExternalQueue* pExternalQueue = 0;
   new qr::Batch();
   while (Extract::instance()->getRecord(i++,strRecord))
   {
      if (strRecord.length() > 16
         && strRecord.substr(0,10) == "DSPEC   AP")
      {
         strSignal = strRecord.substr(8,8);
         size_t pos = strSignal.find(' ');
         if (pos != string::npos)
            strSignal.erase(pos);
         if (!pSignal)
         {
            if (strRecord.find("DATADIST_QUEUE") != string::npos)
               new TableQueueFactory();
#ifndef _UNIX
            else
               new MqQueueFactory();
#endif
         }
         pSignal = new Signal(strSignal.c_str());
         pExternalQueue = (ExternalQueue*)ExternalQueueFactory::instance()->create("Queue",strSignal.c_str());
         Batch::instance()->add(pSignal,pExternalQueue);
      }
   }
   if (!pSignal)
   {
      Trace::put("Extract DSPEC value not found for: APnn",-1,true);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->attach(Batch::instance());
   Database::instance()->connect();
   refresh();
   switch (m_lInputType)
   {
      case IBM_INPUT:
         m_pAPControlHandler = new IBMAPControlHandler(Batch::instance());
         m_pHandler = new IBMAPTranHandler(m_pAPControlHandler);
         break;
      case ADVG_INPUT:
         m_pAPControlHandler = new AdvgAPControlHandler(Batch::instance());
         m_pHandler = new AdvgAPTranHandler(m_pAPControlHandler);
         break;
      case EXT_INPUT:
         m_pAPControlHandler = new ExtAPControlHandler(Batch::instance());
         m_pHandler = new ExtAPTranHandler(m_pAPControlHandler);
         break;
      case B24_INPUT:
         m_pAPControlHandler = new B24APControlHandler(Batch::instance());
         m_pHandler = new B24APTranHandler(m_pAPControlHandler);
         break;
      case IST_INPUT:
         m_pAPControlHandler = new ISTAPControlHandler(Batch::instance());
         m_pHandler = new ISTAPTranHandler(m_pAPControlHandler);
         break;
      case TXNACT_INPUT:
         m_pAPControlHandler = new TransactionActivityControlHandler(Batch::instance());
         m_pHandler = new TransactionActivityHandler(m_pAPControlHandler);
         break;
      case ACI_POSTILION_INPUT:
         m_pAPControlHandler = new PostilionControlHandler(Batch::instance());
         m_pHandler = new PostilionHandler(m_pAPControlHandler);
         break;
	  default:
         return -1;
   }
   Batch::instance()->update(MidnightAlarm::instance());
   return 0;
  //## end qr::QueueReader::initialize%36D5B1090164.body
}

int QueueReader::onConfirm (Message& hMessage)
{
  //## begin qr::QueueReader::onConfirm%36ED2B310052.body preserve=yes
   UseCase hUseCase("LOG","## QR00 LOG CONFIRMATION",false);
   Batch::instance()->onConfirm();
   return 0;
  //## end qr::QueueReader::onConfirm%36ED2B310052.body
}

int QueueReader::onMessage (Message& hMessage)
{
  //## begin qr::QueueReader::onMessage%36F920DA0127.body preserve=yes
   if (hMessage.messageLength() < 1)
      hMessage.setMessageLength(1);
   if (strncmp(hMessage.getDestination().data(),"AP",2) != 0)
   {
       Batch::instance()->update(&hMessage);
       return 0;
   }
   UseCase hUseCase("LOG","## QR00 RECEIVE TRANSACTION",false);
   Batch::instance()->beginBlock();
   int iMinMsgSize = 0;
   short iTotalLength = 0;
   char* p = 0;
   switch (m_lInputType)
   {
      case IBM_INPUT:
         m_bUnblocked = true;
#ifdef MVS
         if (*(short*)hMessage.data() == hMessage.dataLength()
#else
         if (ntohs(*(short*)hMessage.data()) == hMessage.dataLength()
#endif
            && ((*(hMessage.data() + 2) == 0x00
            && *(hMessage.data() + 3) == 0x00)
            || (*(hMessage.data() + 2) == 0x20
            && *(hMessage.data() + 3) == 0x20)))
            m_bUnblocked = false;
         iMinMsgSize = sizeof(hV13AdvantageHeader) + m_bUnblocked ? 0 : 8;
         if (hMessage.messageLength() < iMinMsgSize)
         {
            Log::put(hMessage.buffer(),hMessage.messageLength(), "C0000D","INVALID MSG LENGTH");
            break;
         }
         if (m_bUnblocked == true)
         {
            if (hMessage.messageLength() < 60)
               Log::put(hMessage.buffer(),hMessage.messageLength(), "C0000D","INVALID MSG LENGTH");
            else
               m_pHandler->update(&hMessage);
            break;
         }
         if (hMessage.messageLength() > m_pMemory->getLength())
         {
            delete m_pMemory;
            m_pMemory = new Memory(hMessage.messageLength());
         }
         memcpy((char*)*m_pMemory,hMessage.data(),hMessage.dataLength());
         p = (char*)*m_pMemory;
#ifdef MVS
         iTotalLength  = *((short*)p);
#else
         iTotalLength  = ntohs(*((short*)p));
#endif
         iTotalLength -= 4;
         p += 4;
         while (iTotalLength > 0)
         {
#ifdef MVS
            unsigned short iMessageLen = *((unsigned short*)p);
#else
            unsigned short iMessageLen = ntohs(*((unsigned short*)p));
#endif
            p += 4;
            iTotalLength -= iMessageLen;
            iMessageLen -= 4;
            hMessage.reset("QR AI ","S0059D");
            memcpy(hMessage.data(),p,iMessageLen);
            hMessage.setDataLength(iMessageLen);
            p+= iMessageLen;
            if (Batch::instance()->getState() != Batch::RESTART)
               if (hMessage.messageLength() < 60)
                  Log::put(hMessage.buffer(),hMessage.messageLength(), "C0000D","INVALID MSG LENGTH");
               else
                  m_pHandler->update(&hMessage);
         }
         break;
      case ADVG_INPUT:
         m_bUnblocked = true;
#ifdef MVS
         if (*(short*)hMessage.data() == hMessage.dataLength()
#else
         if (ntohs(*(short*)hMessage.data()) == hMessage.dataLength()
#endif
            && ((*(hMessage.data() + 2) == 0x00
            && *(hMessage.data() + 3) == 0x00)
            || (*(hMessage.data() + 2) == 0x20
            && *(hMessage.data() + 3) == 0x20)))
            m_bUnblocked = false;
         iMinMsgSize = sizeof(hV13AdvantageHeader) + m_bUnblocked ? 0 : 8;
         if (hMessage.messageLength() < iMinMsgSize)
         {
            Log::put(hMessage.buffer(),hMessage.messageLength(), "C0000D","INVALID MSG LENGTH");
            break;
         }
         if (m_bUnblocked == true)
         {
            m_pHandler->update(&hMessage);
            break;
         }
         if (hMessage.messageLength() > m_pMemory->getLength())
         {
            delete m_pMemory;
            m_pMemory = new Memory(hMessage.messageLength());
         }
         memcpy((char*)*m_pMemory,hMessage.data(),hMessage.dataLength());
         p = (char*)*m_pMemory;
#ifdef MVS
         iTotalLength  = *((short*)p);
#else
         iTotalLength  = ntohs(*((short*)p));
#endif
         iTotalLength -= 4;
         p += 4;
         while (iTotalLength > 0)
         {
#ifdef MVS
            unsigned short iMessageLen = *((unsigned short*)p);
#else
            unsigned short iMessageLen = ntohs(*((unsigned short*)p));
#endif
            p += 4;
            iTotalLength -= iMessageLen;
            iMessageLen -= 4;
            hMessage.reset("QR AI ","S0059D");
            memcpy(hMessage.data(),p,iMessageLen);
            hMessage.setDataLength(iMessageLen);
            p+= iMessageLen;
            if (Batch::instance()->getState() != Batch::RESTART)
               m_pHandler->update(&hMessage);
         }
         break;
      case B24_INPUT:
         m_bUnblocked = true;
         //blocked messages: int, space*2, int, space*2
         if ((*((short*)hMessage.buffer()) == hMessage.messageLength()) &&
            (*(hMessage.buffer() + 2) == 0x20) && (*(hMessage.buffer() + 3) == 0x20)  )
               m_bUnblocked = false;
         //if (hMessage.messageLength() < 132)
         //{
         //   Log::put(hMessage.buffer(),hMessage.messageLength(), "C0000D","INVALID MSG LENGTH");
         //   break;
         //}
         if (m_bUnblocked == true)
         {
            m_pHandler->update(&hMessage);
            break;
         }
         if (hMessage.messageLength() > m_pMemory->getLength())
         {
            delete m_pMemory;
            m_pMemory = new Memory(hMessage.messageLength());
         }
         memcpy((char*)*m_pMemory,hMessage.buffer(), hMessage.messageLength());
         p = (char*)*m_pMemory;
         iTotalLength  = *((short*)p);
         iTotalLength -= 4;
         p += 4;
         while (iTotalLength > 0)
         {
            short iMessageLen = *((short*)p);
            p += 4;
            iTotalLength -= iMessageLen;
            iMessageLen -= 4;
            memcpy(hMessage.buffer(),p,iMessageLen);
            hMessage.setMessageLength(iMessageLen);
            p += iMessageLen;
            if (Batch::instance()->getState() != Batch::RESTART)
               m_pHandler->update(&hMessage);
         }
         break;
      default:
         m_pHandler->update(&hMessage);
         break;
   }
   Batch::instance()->endBlock();
   return 0;
  //## end qr::QueueReader::onMessage%36F920DA0127.body
}

int QueueReader::onNotify (const char* pszQueueName)
{
  //## begin qr::QueueReader::onNotify%371242DF0226.body preserve=yes
   // ST248 - "CONNECTION TO AI QUEUE HAS BEEN LOST"
   Console::display("ST248");
   Batch::instance()->restart();
   return 0;
  //## end qr::QueueReader::onNotify%371242DF0226.body
}

int QueueReader::onRefresh ()
{
  //## begin qr::QueueReader::onRefresh%371611070343.body preserve=yes
   UseCase hUseCase("LOG","## QR00 REFRESH QR");
   refresh();
   return Application::onRefresh();
  //## end qr::QueueReader::onRefresh%371611070343.body
}

int QueueReader::onReset (Message& hMessage)
{
  //## begin qr::QueueReader::onReset%378F7DC301E4.body preserve=yes
   if ((!m_bLogging) || (!m_bPrimaryQR))
   {
      Console::display("ST518");
      return 0;
   }
   string strCurrentTime = Clock::instance()->getYYYYMMDDHHMMSS();
   //zero date will force a cut even if loggers are pending
   if (hMessage.context().indexOf("FORCE"))
      strCurrentTime = "00000000000000";
   strCurrentTime += "00";
   if (hMessage.context().indexOf("CUTLOG"))
   {
      APEventHandler::instance()->setCutTimestamp(strCurrentTime);
      APEventHandler::instance()->startCutLog();
   }
   else
   if (hMessage.context().indexOf("EOD"))
   {
      APEventHandler::instance()->setEodTimestamp(strCurrentTime);
      APEventHandler::instance()->startEod();
   }
   return 0;
  //## end qr::QueueReader::onReset%378F7DC301E4.body
}

int QueueReader::refresh ()
{
  //## begin qr::QueueReader::refresh%38187A8B00E6.body preserve=yes
   int lBatchTime = 0;
   Extract::instance()->getLong("DUSER   ","BATCHTIME=",&lBatchTime);
   if (lBatchTime > 0 && lBatchTime < 200)
      Batch::instance()->setTime(lBatchTime);
   string strRecord;
   m_bPrimaryQR = (Application::instance()->name().find("QR2") != string::npos);
   Control::setLogging(m_bLogging);
   APEventHandler::setPrimaryQR(m_bPrimaryQR);
   if (m_lInputType == INPUT_UNDEFINED)
   {
      if (Extract::instance()->getRecord("DUSER   ",strRecord) != false)
      {
         if (strRecord.find("CXOPII00") != string::npos)
            m_lInputType = IBM_INPUT;
         else
         if (strRecord.find("CXOPAI00") != string::npos)
            m_lInputType = ADVG_INPUT;
         else
         if (strRecord.find("CXOPBI00") != string::npos)
            m_lInputType = B24_INPUT;
  	     else
         if (strRecord.find("CXOPHI00") != string::npos)
		        m_lInputType = IST_INPUT;
         else
         if (strRecord.find("CXOPOI00") != string::npos)
            m_lInputType = IST_INPUT;
         else
         if (strRecord.find("CXOPPI00") != string::npos)
            m_lInputType = ACI_POSTILION_INPUT;
         else
         if (strRecord.find("CXOPXI00") != string::npos)
            m_lInputType = EXT_INPUT;
         else
         if (strRecord.find("CXOPYI00") != string::npos)
            m_lInputType = TXNACT_INPUT;
         else
            return -1;
      }
      else
         return -1;
   }
   int l = 0;
   if ((l = Extract::instance()->getTimer("ROLLBACK")) != -1)
      Batch::instance()->setRollbackSeconds(l);
   if ((l = Extract::instance()->getTimer("RESTART ")) != -1)
      Batch::instance()->setRestartSeconds(l);
   // read the list of all the loggers
   APEventHandler::instance()->update(Extract::instance());
   if (m_bLogging)
   {
      APEventHandler::instance()->refresh();
      int i = 0;
      string strBuffer;
      while (Extract::instance()->getRecord(i,strBuffer))
      {
         if (strBuffer.length() > 33
            && strBuffer.substr(0,8) == "DQUEUE  "
            && strBuffer.substr(32,2) == "CL"
            && strBuffer.substr(8,2) == name().substr(0,2))
         {
            if (strBuffer.substr(10,4) == "LOGP")
               Log::setPriCustLogger(strBuffer.substr(8,8));
            else
               Log::setSecCustLogger(strBuffer.substr(8,8));
         }
         ++i;
      }
   }
   return 0;
  //## end qr::QueueReader::refresh%38187A8B00E6.body
}

// Additional Declarations
  //## begin qr::QueueReader%36C87D3C0274.declarations preserve=yes
  //## end qr::QueueReader%36C87D3C0274.declarations

} // namespace qr

//## begin module%36C87DCD010A.epilog preserve=yes
//## end module%36C87DCD010A.epilog
