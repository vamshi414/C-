//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%4F16415C00AC.cm preserve=no
//## end module%4F16415C00AC.cm

//## begin module%4F16415C00AC.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%4F16415C00AC.cp

//## Module: CXOSQR16%4F16415C00AC; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR16.hpp

#ifndef CXOSQR16_h
#define CXOSQR16_h 1

//## begin module%4F16415C00AC.additionalIncludes preserve=no
//## end module%4F16415C00AC.additionalIncludes

//## begin module%4F16415C00AC.includes preserve=yes
//## end module%4F16415C00AC.includes

#ifndef CXOSRU14_h
#include "CXODRU14.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Batch;
class SwitchInterfacePool;
class APEventHandler;
class Control;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Console;
class Queue;

} // namespace IF

//## begin module%4F16415C00AC.declarations preserve=no
//## end module%4F16415C00AC.declarations

//## begin module%4F16415C00AC.additionalDeclarations preserve=yes
//## end module%4F16415C00AC.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::TransactionActivityHandler%4F163F2503A8.preface preserve=yes
//## end qr::TransactionActivityHandler%4F163F2503A8.preface

//## Class: TransactionActivityHandler%4F163F2503A8
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4F16F0CE0082;IF::Console { -> F}
//## Uses: <unnamed>%4F16F0ED0228;Batch { -> F}
//## Uses: <unnamed>%4F16F136011B;Control { -> F}
//## Uses: <unnamed>%4F16F144003A;APEventHandler { -> F}
//## Uses: <unnamed>%4F16F14F009B;IF::Message { -> F}
//## Uses: <unnamed>%4F16F17C0165;IF::Queue { -> F}
//## Uses: <unnamed>%6391133E01C8;SwitchInterfacePool { -> F}

class DllExport TransactionActivityHandler : public reusable::Handler  //## Inherits: <unnamed>%4F163F4702B9
{
  //## begin qr::TransactionActivityHandler%4F163F2503A8.initialDeclarations preserve=yes
  //## end qr::TransactionActivityHandler%4F163F2503A8.initialDeclarations

  public:
    //## Constructors (generated)
      TransactionActivityHandler();

    //## Constructors (specified)
      //## Operation: TransactionActivityHandler%4F163FEE0036
      TransactionActivityHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~TransactionActivityHandler();


    //## Other Operations (specified)
      //## Operation: update%4F163F4F034B
      //	Callback function that is invoked by a subject when its
      //	state changes.
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin qr::TransactionActivityHandler%4F163F2503A8.public preserve=yes
      //## end qr::TransactionActivityHandler%4F163F2503A8.public

  protected:
    // Additional Protected Declarations
      //## begin qr::TransactionActivityHandler%4F163F2503A8.protected preserve=yes
      //## end qr::TransactionActivityHandler%4F163F2503A8.protected

  private:
    // Additional Private Declarations
      //## begin qr::TransactionActivityHandler%4F163F2503A8.private preserve=yes
      //## end qr::TransactionActivityHandler%4F163F2503A8.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin qr::TransactionActivityHandler%4F163F2503A8.implementation preserve=yes
      //## end qr::TransactionActivityHandler%4F163F2503A8.implementation

};

//## begin qr::TransactionActivityHandler%4F163F2503A8.postscript preserve=yes
//## end qr::TransactionActivityHandler%4F163F2503A8.postscript

} // namespace qr

//## begin module%4F16415C00AC.epilog preserve=yes
//## end module%4F16415C00AC.epilog


#endif
