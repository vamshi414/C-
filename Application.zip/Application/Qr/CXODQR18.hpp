//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%523C5BED03C1.cm preserve=no
//## end module%523C5BED03C1.cm

//## begin module%523C5BED03C1.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%523C5BED03C1.cp

//## Module: CXOSQR18%523C5BED03C1; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR18.hpp

#ifndef CXOSQR18_h
#define CXOSQR18_h 1

//## begin module%523C5BED03C1.additionalIncludes preserve=no
//## end module%523C5BED03C1.additionalIncludes

//## begin module%523C5BED03C1.includes preserve=yes
//## end module%523C5BED03C1.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class APEventHandler;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Extract;
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;

} // namespace segment

//## begin module%523C5BED03C1.declarations preserve=no
//## end module%523C5BED03C1.declarations

//## begin module%523C5BED03C1.additionalDeclarations preserve=yes
//## end module%523C5BED03C1.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::APISTHeader%523C5AE3034B.preface preserve=yes
//## end qr::APISTHeader%523C5AE3034B.preface

//## Class: APISTHeader%523C5AE3034B
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%523C5B4C00E3;IF::Message { -> F}
//## Uses: <unnamed>%523C5B4F033A;IF::CodeTable { -> F}
//## Uses: <unnamed>%523C5B53025F;segment::Segment { -> F}
//## Uses: <unnamed>%523C5B58027B;APEventHandler { -> F}
//## Uses: <unnamed>%5D1E0D7C0317;IF::Extract { -> F}

class DllExport APISTHeader : public reusable::Object  //## Inherits: <unnamed>%523C5B48010D
{
  //## begin qr::APISTHeader%523C5AE3034B.initialDeclarations preserve=yes
  //## end qr::APISTHeader%523C5AE3034B.initialDeclarations

  public:
    //## Constructors (generated)
      APISTHeader();

    //## Destructor (generated)
      virtual ~APISTHeader();


    //## Other Operations (specified)
      //## Operation: instance%523C5AE30390
      static APISTHeader* instance ();

      //## Operation: parse%523C5AE30391
      bool parse ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: APCount%523C5AE30389
      const int& getAPCount () const
      {
        //## begin qr::APISTHeader::getAPCount%523C5AE30389.get preserve=no
        return m_lAPCount;
        //## end qr::APISTHeader::getAPCount%523C5AE30389.get
      }


      //## Attribute: APHash%523C5AE3037F
      const double& getAPHash () const
      {
        //## begin qr::APISTHeader::getAPHash%523C5AE3037F.get preserve=no
        return m_dAPHash;
        //## end qr::APISTHeader::getAPHash%523C5AE3037F.get
      }


      //## Attribute: LoggerName%523C5AE30381
      const string& getLoggerName () const
      {
        //## begin qr::APISTHeader::getLoggerName%523C5AE30381.get preserve=no
        return m_strLoggerName;
        //## end qr::APISTHeader::getLoggerName%523C5AE30381.get
      }


      //## Attribute: LogOpenTime%523C5AE3038D
      const string& getLogOpenTime () const
      {
        //## begin qr::APISTHeader::getLogOpenTime%523C5AE3038D.get preserve=no
        return m_strLogOpenTime;
        //## end qr::APISTHeader::getLogOpenTime%523C5AE3038D.get
      }


      //## Attribute: MsgCode%523C5AE30387
      const int& getMsgCode () const
      {
        //## begin qr::APISTHeader::getMsgCode%523C5AE30387.get preserve=no
        return m_iMsgCode;
        //## end qr::APISTHeader::getMsgCode%523C5AE30387.get
      }


      //## Attribute: TransmissionDateTime%523FFAC901FF
      const string& getTransmissionDateTime () const
      {
        //## begin qr::APISTHeader::getTransmissionDateTime%523FFAC901FF.get preserve=no
        return m_strTransmissionDateTime;
        //## end qr::APISTHeader::getTransmissionDateTime%523FFAC901FF.get
      }


    // Additional Public Declarations
      //## begin qr::APISTHeader%523C5AE3034B.public preserve=yes
      //## end qr::APISTHeader%523C5AE3034B.public

  protected:
    // Additional Protected Declarations
      //## begin qr::APISTHeader%523C5AE3034B.protected preserve=yes
      //## end qr::APISTHeader%523C5AE3034B.protected

  private:

    //## Other Operations (specified)
      //## Operation: getControlData%523C5AE30397
      void getControlData ();

      //## Operation: getElectronicJournalData%52401779007A
      void getElectronicJournalData ();

      //## Operation: getFinancialData%523C5AE30396
      void getFinancialData ();

      //## Operation: getNetStatStatusData%52414A2803B5
      void getNetStatStatusData ();

      //## Operation: getTerminalAdminData%523C5EC60363
      void getTerminalAdminData ();

      //## Operation: getTerminalAdviceData%5240176500C9
      void getTerminalAdviceData ();

      //## Operation: set904Logger%523FFFAB0281
      bool set904Logger ();

      //## Operation: setLogger%523C5AE30392
      bool setLogger ();

      //## Operation: setTstampAndHash%5240464F0292
      void setTstampAndHash (const int iDate, const int iTime);

      //## Operation: setTstampAndHash%5D1E0C3203AA
      void setTstampAndHash (const char* psText, unsigned iTextLength);

    // Additional Private Declarations
      //## begin qr::APISTHeader%523C5AE3034B.private preserve=yes
      //## end qr::APISTHeader%523C5AE3034B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin qr::APISTHeader::APCount%523C5AE30389.attr preserve=no  public: int {U} 0
      int m_lAPCount;
      //## end qr::APISTHeader::APCount%523C5AE30389.attr

      //## begin qr::APISTHeader::APHash%523C5AE3037F.attr preserve=no  public: double {U} 0
      double m_dAPHash;
      //## end qr::APISTHeader::APHash%523C5AE3037F.attr

      //## Attribute: Instance%523C5AE3037D
      //## begin qr::APISTHeader::Instance%523C5AE3037D.attr preserve=no  private: static APISTHeader* {U} 0
      static APISTHeader* m_pInstance;
      //## end qr::APISTHeader::Instance%523C5AE3037D.attr

      //## Attribute: ISTData%524047B30278
      //## begin qr::APISTHeader::ISTData%524047B30278.attr preserve=no  private: char* {U} 0
      char* m_pISTData;
      //## end qr::APISTHeader::ISTData%524047B30278.attr

      //## Attribute: ISTInternalHeader%524047590000
      //## begin qr::APISTHeader::ISTInternalHeader%524047590000.attr preserve=no  private: char* {U} 0
      char* m_pISTInternalHeader;
      //## end qr::APISTHeader::ISTInternalHeader%524047590000.attr

      //## Attribute: ISTLogHeader%52404F5F019F
      //## begin qr::APISTHeader::ISTLogHeader%52404F5F019F.attr preserve=no  private: char* {U} 0
      char* m_pISTLogHeader;
      //## end qr::APISTHeader::ISTLogHeader%52404F5F019F.attr

      //## begin qr::APISTHeader::LoggerName%523C5AE30381.attr preserve=no  public: string {U} 
      string m_strLoggerName;
      //## end qr::APISTHeader::LoggerName%523C5AE30381.attr

      //## begin qr::APISTHeader::LogOpenTime%523C5AE3038D.attr preserve=no  public: string {V} 
      string m_strLogOpenTime;
      //## end qr::APISTHeader::LogOpenTime%523C5AE3038D.attr

      //## begin qr::APISTHeader::MsgCode%523C5AE30387.attr preserve=no  public: int {U} 0
      int m_iMsgCode;
      //## end qr::APISTHeader::MsgCode%523C5AE30387.attr

      //## begin qr::APISTHeader::TransmissionDateTime%523FFAC901FF.attr preserve=no  public: string {U} 
      string m_strTransmissionDateTime;
      //## end qr::APISTHeader::TransmissionDateTime%523FFAC901FF.attr

    // Additional Implementation Declarations
      //## begin qr::APISTHeader%523C5AE3034B.implementation preserve=yes
      //## end qr::APISTHeader%523C5AE3034B.implementation

};

//## begin qr::APISTHeader%523C5AE3034B.postscript preserve=yes
//## end qr::APISTHeader%523C5AE3034B.postscript

} // namespace qr

//## begin module%523C5BED03C1.epilog preserve=yes
//## end module%523C5BED03C1.epilog


#endif
