//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%378E2EFC01E1.cm preserve=no
//## end module%378E2EFC01E1.cm

//## begin module%378E2EFC01E1.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%378E2EFC01E1.cp

//## Module: CXOSQR05%378E2EFC01E1; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR05.hpp

#ifndef CXOSQR05_h
#define CXOSQR05_h 1

//## begin module%378E2EFC01E1.additionalIncludes preserve=no
//## end module%378E2EFC01E1.additionalIncludes

//## begin module%378E2EFC01E1.includes preserve=yes
// $Date$ $Author$ $Revision$
#include <map>
#include <list>
//## end module%378E2EFC01E1.includes

#ifndef CXOSRU02_h
#include "CXODRU02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSTM01_h
#include "CXODTM01.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Batch;
class QueueReader;
class AdvgAPControlHandler;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class DateTime;
class Extract;
class Timestamp;
class Console;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

namespace IF {
class Trace;
class Log;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Context;
class DatabaseFactory;
class Database;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%378E2EFC01E1.declarations preserve=no
//## end module%378E2EFC01E1.declarations

//## begin module%378E2EFC01E1.additionalDeclarations preserve=yes
//## end module%378E2EFC01E1.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::APEventHandler%378E2E9102B0.preface preserve=yes
//## end qr::APEventHandler%378E2E9102B0.preface

//## Class: APEventHandler%378E2E9102B0
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%378E4B9F0189;IF::Trace { -> F}
//## Uses: <unnamed>%378E4D1701B1;IF::Extract { -> F}
//## Uses: <unnamed>%378E4E3B03B0;IF::Log { -> F}
//## Uses: <unnamed>%37A097CD028C;IF::Console { -> F}
//## Uses: <unnamed>%3869F2480297;Batch { -> F}
//## Uses: <unnamed>%3869FEBA000D;AdvgAPControlHandler { -> F}
//## Uses: <unnamed>%386BA8A5022E;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%3870B04E02EC;database::Database { -> F}
//## Uses: <unnamed>%3870B50C003E;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%387643B4032C;reusable::Query { -> F}
//## Uses: <unnamed>%387643B800B1;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%38764F6D025F;timer::Clock { -> F}
//## Uses: <unnamed>%38764F71016A;IF::DateTime { -> F}
//## Uses: <unnamed>%38764FEE019C;timer::Date { -> F}
//## Uses: <unnamed>%387651B1014B;process::Application { -> F}
//## Uses: <unnamed>%3878A727014C;IF::Timestamp { -> F}
//## Uses: <unnamed>%3879BFE001CB;reusable::Query { -> F}
//## Uses: <unnamed>%3C7E7E5903A2;database::Context { -> F}
//## Uses: <unnamed>%3C83DEF2025E;QueueReader { -> F}

class APEventHandler : public reusable::Observer  //## Inherits: <unnamed>%378E303201E7
{
  //## begin qr::APEventHandler%378E2E9102B0.initialDeclarations preserve=yes
  public:
      enum State
      {
         IDLE,
         PENDING
      };

     enum Timers
     {
         FIVE_SECOND,
         NINE_AM         
     };
     
     enum Type
     {
         AUDITC,
         AUDITL,
         CUT,
         EOD
     };
  //## end qr::APEventHandler%378E2E9102B0.initialDeclarations

  public:
    //## Constructors (generated)
      APEventHandler();

    //## Destructor (generated)
      virtual ~APEventHandler();


    //## Other Operations (specified)
      //## Operation: auditControls%387642AB0032
      void auditControls ();

      //## Operation: cut%378E484600BE
      int cut ();

      //## Operation: eod%378E48550033
      int eod ();

      //## Operation: instance%378E312802E5
      static APEventHandler* instance ();

      //## Operation: isValidLoggerName%37A6095F02AC
      bool isValidLoggerName (string& strLoggerName);

      //## Operation: locate%3C7E5AF201C2
      bool locate (string& strLoggerName, string& strLatestTimestamp);

      //## Operation: refresh%3870BCEE0389
      virtual void refresh ();

      //## Operation: startCutLog%3872594A0383
      int startCutLog ();

      //## Operation: startEod%3872593D00DB
      int startEod ();

      //## Operation: update%378E31C30306
      void update (string& strLoggerName, string& strTimestamp);

      //## Operation: update%378E4C8702EB
      //	Callback function that is invoked by a subject when its
      //	state changes.
      //## Postconditions:
      //	<body>
      //	<title>CG
      //	<h1>QR
      //	<h2>MS
      //	<!-- APEventHandler : Postconditions-->
      //	<h3>Controls Audit
      //	<p>
      //	The Queue Reader service counts and calculates a hash
      //	total for all transactions received from the acquiring
      //	platform.
      //	The counts and totals are maintained for each log file
      //	produced by the switch.
      //	Any mismatches from the prior day between the control
      //	record provided by the switch and the counts calculated
      //	by the Queue Reader are reported on the operator console
      //	at 11:00 AM:
      //	<ul>
      //	<li>DataNavigator count <> control record count: ST515 :
      //	TRAN COUNT MISMATCH
      //	<li>DataNavigator hash <> control record hash: ST516 :
      //	HASH AMOUNT MISMATCH
      //	<li>Control record not received: ST514 : CONTROL RECORD
      //	NOT RECEIVED
      //	</ul>
      //	The audit messages display at 11:00 AM by default.
      //	The time can be overridden by specifying AUDIT_
      //	TIMER=<i>hhmmss</i> in the task user data.
      //	The messages can be suppressed (not recommended) by
      //	specifying AUDIT_TIMER=999999.
      //	<p>
      //	User data is defined in the Task definition which is in
      //	the Task Configuration folder in the CR Client for the
      //	DataNavigator Server.
      //	</body>
      void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: CutTimestamp%378E48EB027E
      void setCutTimestamp (const string& value)
      {
        //## begin qr::APEventHandler::setCutTimestamp%378E48EB027E.set preserve=no
        m_strCutTimestamp = value;
        //## end qr::APEventHandler::setCutTimestamp%378E48EB027E.set
      }


      //## Attribute: EodTimestamp%378E490201CD
      void setEodTimestamp (const string& value)
      {
        //## begin qr::APEventHandler::setEodTimestamp%378E490201CD.set preserve=no
        m_strEodTimestamp = value;
        //## end qr::APEventHandler::setEodTimestamp%378E490201CD.set
      }


      //## Attribute: PrimaryQR%3D612243026E
      static const bool getPrimaryQR ()
      {
        //## begin qr::APEventHandler::getPrimaryQR%3D612243026E.get preserve=no
        return m_bPrimaryQR;
        //## end qr::APEventHandler::getPrimaryQR%3D612243026E.get
      }

      static void setPrimaryQR (bool value)
      {
        //## begin qr::APEventHandler::setPrimaryQR%3D612243026E.set preserve=no
        m_bPrimaryQR = value;
        //## end qr::APEventHandler::setPrimaryQR%3D612243026E.set
      }


    // Additional Public Declarations
      //## begin qr::APEventHandler%378E2E9102B0.public preserve=yes
      //## end qr::APEventHandler%378E2E9102B0.public

  protected:
    // Additional Protected Declarations
      //## begin qr::APEventHandler%378E2E9102B0.protected preserve=yes
      //## end qr::APEventHandler%378E2E9102B0.protected

  private:
    // Additional Private Declarations
      //## begin qr::APEventHandler%378E2E9102B0.private preserve=yes
      //## end qr::APEventHandler%378E2E9102B0.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%378E30B302AB
      //## begin qr::APEventHandler::Instance%378E30B302AB.attr preserve=no  private: static APEventHandler* {U} 0
      static APEventHandler* m_pInstance;
      //## end qr::APEventHandler::Instance%378E30B302AB.attr

      //## Attribute: APLoggers%378E33A302DE
      //## begin qr::APEventHandler::APLoggers%378E33A302DE.attr preserve=no  private: map<string,string,less<string> > {U} 
      map<string,string,less<string> > m_hAPLoggers;
      //## end qr::APEventHandler::APLoggers%378E33A302DE.attr

      //## Attribute: CutState%378E32C300B5
      //## begin qr::APEventHandler::CutState%378E32C300B5.attr preserve=no  private: State {U} IDLE
      State m_nCutState;
      //## end qr::APEventHandler::CutState%378E32C300B5.attr

      //## begin qr::APEventHandler::CutTimestamp%378E48EB027E.attr preserve=no  public: string {U} 
      string m_strCutTimestamp;
      //## end qr::APEventHandler::CutTimestamp%378E48EB027E.attr

      //## Attribute: EodState%378E32DC01DE
      //## begin qr::APEventHandler::EodState%378E32DC01DE.attr preserve=no  private: State {U} IDLE
      State m_nEodState;
      //## end qr::APEventHandler::EodState%378E32DC01DE.attr

      //## begin qr::APEventHandler::EodTimestamp%378E490201CD.attr preserve=no  public: string {U} 
      string m_strEodTimestamp;
      //## end qr::APEventHandler::EodTimestamp%378E490201CD.attr

      //## Attribute: CONTEXT_DATA%38790C5A0357
      //## begin qr::APEventHandler::CONTEXT_DATA%38790C5A0357.attr preserve=no  private: string {U} 
      string m_strCONTEXT_DATA;
      //## end qr::APEventHandler::CONTEXT_DATA%38790C5A0357.attr

      //## Attribute: CONTEXT_KEY%38790C6D0214
      //## begin qr::APEventHandler::CONTEXT_KEY%38790C6D0214.attr preserve=no  private: string {U} 
      string m_strCONTEXT_KEY;
      //## end qr::APEventHandler::CONTEXT_KEY%38790C6D0214.attr

      //## Attribute: AuditTime%387F96AB0269
      //## begin qr::APEventHandler::AuditTime%387F96AB0269.attr preserve=no  private: string {U} "110000"
      string m_strAuditTime;
      //## end qr::APEventHandler::AuditTime%387F96AB0269.attr

      //## Attribute: ContextQueryType%3C7E8FC90218
      //## begin qr::APEventHandler::ContextQueryType%3C7E8FC90218.attr preserve=no  private: Type {U} AUDITC
      Type m_nContextQueryType;
      //## end qr::APEventHandler::ContextQueryType%3C7E8FC90218.attr

      //## Attribute: PendingCount%3C7EAFC90087
      //## begin qr::APEventHandler::PendingCount%3C7EAFC90087.attr preserve=no  public: int {U} 
      int m_iPendingCount;
      //## end qr::APEventHandler::PendingCount%3C7EAFC90087.attr

      //## begin qr::APEventHandler::PrimaryQR%3D612243026E.attr preserve=no  public: static bool {U} false
      static bool m_bPrimaryQR;
      //## end qr::APEventHandler::PrimaryQR%3D612243026E.attr

      //## Attribute: LoggerNameFmt%3DE2A61A0177
      //## begin qr::APEventHandler::LoggerNameFmt%3DE2A61A0177.attr preserve=no  private: string {U} 
      string m_strLoggerNameFmt;
      //## end qr::APEventHandler::LoggerNameFmt%3DE2A61A0177.attr

      //## Attribute: CutTimeStamps%407A87B400EA
      //	Contains the list of pending CUT timestamps.
      //## begin qr::APEventHandler::CutTimeStamps%407A87B400EA.attr preserve=no  private: list<string> {U} 
      list<string> m_hCutTimeStamps;
      //## end qr::APEventHandler::CutTimeStamps%407A87B400EA.attr

    // Data Members for Associations

      //## Association: Continuous Feed::QueueReader_CAT::<unnamed>%38726CDC03CD
      //## Role: APEventHandler::<m_hTimer>%38726CDD01DA
      //## begin qr::APEventHandler::<m_hTimer>%38726CDD01DA.role preserve=no  public: timer::Timer { -> 2VHgN}
      timer::Timer m_hTimer[2];
      //## end qr::APEventHandler::<m_hTimer>%38726CDD01DA.role

      //## Association: Continuous Feed::QueueReader_CAT::<unnamed>%3879C04B0229
      //## Role: APEventHandler::<m_hQuery>%3879C04D0113
      //## begin qr::APEventHandler::<m_hQuery>%3879C04D0113.role preserve=no  public: reusable::Query { -> VHgN}
      reusable::Query m_hQuery;
      //## end qr::APEventHandler::<m_hQuery>%3879C04D0113.role

    // Additional Implementation Declarations
      //## begin qr::APEventHandler%378E2E9102B0.implementation preserve=yes
      //## end qr::APEventHandler%378E2E9102B0.implementation

};

//## begin qr::APEventHandler%378E2E9102B0.postscript preserve=yes
//## end qr::APEventHandler%378E2E9102B0.postscript

} // namespace qr

//## begin module%378E2EFC01E1.epilog preserve=yes
//## end module%378E2EFC01E1.epilog


#endif
