//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36F7C9FB0028.cm preserve=no
//## end module%36F7C9FB0028.cm

//## begin module%36F7C9FB0028.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36F7C9FB0028.cp

//## Module: CXOSQR04%36F7C9FB0028; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR04.cpp

//## begin module%36F7C9FB0028.additionalIncludes preserve=no
//## end module%36F7C9FB0028.additionalIncludes

//## begin module%36F7C9FB0028.includes preserve=yes
#include <algorithm>
#include <map>
#include "CXODDB28.hpp"
#ifdef MVS
#include "CXODTM12.hpp"
#endif

//## end module%36F7C9FB0028.includes

#ifndef CXOSRU13_h
#include "CXODRU13.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSTM04_h
#include "CXODTM04.hpp"
#endif
#ifndef CXOSIF46_h
#include "CXODIF46.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSMN02_h
#include "CXODMN02.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU29_h
#include "CXODRU29.hpp"
#endif
#ifndef CXOSIF55_h
#include "CXODIF55.hpp"
#endif
#ifndef CXOSSI05_h
#include "CXODSI05.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSIF28_h
#include "CXODIF28.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSQR22_h
#include "CXODQR22.hpp"
#endif
#ifndef CXOSQR04_h
#include "CXODQR04.hpp"
#endif


//## begin module%36F7C9FB0028.declarations preserve=no
//## end module%36F7C9FB0028.declarations

//## begin module%36F7C9FB0028.additionalDeclarations preserve=yes
//## end module%36F7C9FB0028.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::Batch 

Batch::Batch()
  //## begin Batch::Batch%36F7C9D8033F_const.hasinit preserve=no
      : m_nState(IDLE)
  //## end Batch::Batch%36F7C9D8033F_const.hasinit
  //## begin Batch::Batch%36F7C9D8033F_const.initialization preserve=yes
   ,m_hInterval("LOG","## LG03 BEGIN BATCH","AVETIME")
  //## end Batch::Batch%36F7C9D8033F_const.initialization
{
  //## begin qr::Batch::Batch%36F7C9D8033F_const.body preserve=yes
   memcpy(m_sID,"QR04",4);
   MinuteTimer::instance()->attach(this);
   MidnightAlarm::instance()->attach(this);
   string strDSTSpec;
   if (Extract::instance()->getSpec("GMT",strDSTSpec))
   {
      strDSTSpec.resize(6,' ');
      m_bDST = strDSTSpec[5] == 'D';
      m_iGMTOffset = atoi(strDSTSpec.substr(0,5).c_str());
   }
  //## end qr::Batch::Batch%36F7C9D8033F_const.body
}


Batch::~Batch()
{
  //## begin qr::Batch::~Batch%36F7C9D8033F_dest.body preserve=yes
   rollback();
   MidnightAlarm::instance()->detach(this);
   MinuteTimer::instance()->detach(this);
   vector<pair<Signal*,ExternalQueue*> >::iterator q;
   for (q = m_hQueue.begin();q != m_hQueue.end();++q)
   {
      if (q == m_hQueue.begin())
         QueueManager::instance((*q).second->getQueueManager())->detach(this);
      delete (*q).first;
      delete (*q).second;
   }
  //## end qr::Batch::~Batch%36F7C9D8033F_dest.body
}



//## Other Operations (implementation)
void Batch::add (reusable::Signal* pSignal, ExternalQueue* pQueue)
{
  //## begin qr::Batch::add%49B952E4037A.body preserve=yes
   pQueue->setSignal(pSignal);
   pSignal->attach(pQueue);
   m_hQueue.push_back(make_pair(pSignal,pQueue));
   if (m_hQueue.size() == 1)
      QueueManager::instance(pQueue->getQueueManager())->attach(this);
  //## end qr::Batch::add%49B952E4037A.body
}

void Batch::addRecord (unsigned int iHash)
{
  //## begin qr::Batch::addRecord%36F80C7A0260.body preserve=yes
   SwitchInterfacePool::instance()->updateHash(iHash);
  //## end qr::Batch::addRecord%36F80C7A0260.body
}

void Batch::begin (bool bMinuteTimer)
{
  //## begin qr::Batch::begin%36F7E1AE03B1.body preserve=yes
   UseCase hUseCase("LOG","## LG03 BEGIN BATCH",false);
   m_hInterval.stop();
   // target is 'n' seconds per batch
   if (bMinuteTimer)
      m_iSize[0] = 1000;
   else
   {
      if (m_hInterval.getSample() > 0)
         m_iSize[0] = (int)((double)((m_iTime * 1000) / (double)m_hInterval.getSample()) * (double)m_iSize[0]);
      if (m_iSize[0] < 100)
         m_iSize[0] = 100;
      else
#ifdef MVS
      if (m_iSize[0] > 1000)
         m_iSize[0] = 1000;
#else
      if (m_iSize[0] > 5000)
         m_iSize[0] = 5000;
#endif
   }
   ExternalQueue* pQueue = 0;
   int iSize = 0;
   multimap<string,pair<ExternalQueue*,int>,less<string> > hDepth;
   for (unsigned int i = 0;i < m_hQueue.size();i++)
   {
      pQueue = m_hQueue[i].second;
      pQueue->setInBatch(false);
      int iDepth = pQueue->getDepth();
      if (iDepth > 0)
      {
         iSize += iDepth;
         hDepth.insert(multimap<string,pair<ExternalQueue*,int>,less<string> >::value_type(pQueue->getTimestamp(),make_pair(pQueue,iDepth)));
      }
      else
         pQueue->setBatchSize(0);
   }
   Count::set("LOG","## LG03 BEGIN BATCH","ITEMS",iSize);
   multimap<string,pair<ExternalQueue*,int>,less<string> >::iterator p = hDepth.begin();
   if (!hDepth.empty())
   {
      if ((*p).first.empty() == false
         && (*p).first != "0000000000000000")
      {
         Channel hChannel(Application::instance()->image(), Application::instance()->name());
         if (m_iGMTOffset != 0)
         {
            string strTSTAMP_TRANS((*p).first);
#ifdef MVS
            GMT::instance()->asLocal(strTSTAMP_TRANS, m_iGMTOffset, m_bDST);
#else
            Timestamp::gmtToLocal(strTSTAMP_TRANS);
#endif
            hChannel.setProgress(strTSTAMP_TRANS, iSize);
         }
         else
            hChannel.setProgress((*p).first, iSize);
         Database::instance()->commit();
      }
   }
   if (iSize >= m_iSize[0])
      iSize = m_iSize[0];
   else
      m_iSize[0] = (bMinuteTimer ) ? iSize : 0;
   m_iSize[1] = m_iSize[0];
   if (m_iSize[0] == 0)
   {
      Database::instance()->commit();
      return;
   }
   while (p != hDepth.end())
   {
      if ((*p).second.second < iSize)
      {
         (*p).second.first->setBatchSize((*p).second.second);
         iSize -= (*p).second.second;
      }
      else
      {
         (*p).second.first->setBatchSize(iSize);
         iSize = 0;
      }
      ++p;
   }
   for (unsigned int i = 0;i < m_hQueue.size();i++)
   {
      if ((m_hQueue[i].second)->getBatchSize() > 0)
      {
         m_iIndex = i;
         Application::instance()->enable(m_hQueue[i].first);
         m_hQueue[m_iIndex].second->setInBatch(true);
         break;
      }
   }

   m_nState = IDLE;
   m_iCount = 0;
   m_hLogConfirmations.erase(m_hLogConfirmations.begin(),m_hLogConfirmations.end());
   m_dTicks = Clock::instance()->getTicks();
   m_hInterval.start();
   SwitchInterfacePool::instance()->clear();
  //## end qr::Batch::begin%36F7E1AE03B1.body
}

void Batch::beginBlock ()
{
  //## begin qr::Batch::beginBlock%49BEBF4C00DA.body preserve=yes
   m_nState = BUSY;
   m_iCount++;
   m_hQueue[m_iIndex].second->setBatchSize(m_hQueue[m_iIndex].second->getBatchSize() - 1);
  //## end qr::Batch::beginBlock%49BEBF4C00DA.body
}

bool Batch::clear ()
{
  //## begin qr::Batch::clear%4AA9261C032C.body preserve=yes
   Message hMessage;
   hMessage.reset("QR AI ","S0060D");
   hHashMessage* pRequest = (hHashMessage*)hMessage.data();
   memcpy(pRequest->sOperation,"ZEROHASH",8);
   memset(pRequest->sTimeStamp,' ',sizeof(pRequest->sTimeStamp));
   pRequest->lSeqNo = 0;
   pRequest->dHashTotal = 0;
   pRequest->lLastRecSeqNo = 0;
   pRequest->lTranCnt = 0;
   pRequest->cStatusFlag = ' ';
   hMessage.setDataLength(sizeof(hHashMessage));
   if (SwitchInterfacePool::instance()->send(&hMessage, Queue::REQUEST))
      return true;
   Console::display("ST248");
   restart();
   return false;
  //## end qr::Batch::clear%4AA9261C032C.body
}

bool Batch::commit ()
{
  //## begin qr::Batch::commit%36F7E60A02D9.body preserve=yes
   UseCase hUseCase("LOG","## LG07 COMMIT BATCH",true, Extract::instance()->getPerf() == "PERF");
   CriticalSection hCriticalSection("CONTROLS");
   vector<pair<Signal*,ExternalQueue*> >::iterator q;
   for (q = m_hQueue.begin();q != m_hQueue.end();++q)
      if (((*q).second)->getInBatch())
         (*q).second->backup();
   int attempts = 0;
   do
   {
      if (Control::commit() != 0)
         continue;
      vector<pair<Signal*,ExternalQueue*> >::iterator q = m_hQueue.begin();
      bool b = true;
      for (q = m_hQueue.begin();q != m_hQueue.end();++q)
         if (((*q).second)->getInBatch())
            if (!((*q).second)->commit())
            {
               b = false;
               break;
            }
      if (b)
         if (QueueManager::instance((m_hQueue[0].second)->getQueueManager())->commit())
         {
            Control::update();
            for (q = m_hQueue.begin();q != m_hQueue.end();++q)
               if (((*q).second)->getInBatch())
                  (*q).second->reset();
            return true;
         }
   }
   while (++attempts < 3);
   Control::reset();
   for (q = m_hQueue.begin();q != m_hQueue.end();++q)
      if (((*q).second)->getInBatch())
         (*q).second->reset();
   return false;
  //## end qr::Batch::commit%36F7E60A02D9.body
}

void Batch::end ()
{
  //## begin qr::Batch::end%36F8F910018F.body preserve=yes
   UseCase hUseCase("LOG","## LG15 SEND BATCH",false);
   Application::instance()->enable(m_hQueue[m_iIndex].first,false);
   Message hMessage;
   hMessage.reset("QR AI ","S0060D");
   hHashMessage* pRequest = (hHashMessage*)hMessage.data();
   memcpy(pRequest->sOperation,"HASHREQ ",8);
   memset(pRequest->sTimeStamp,' ',sizeof(pRequest->sTimeStamp));
   if (++m_iNumber > 10000)
      m_iNumber = 1;
   pRequest->lSeqNo = m_iNumber;
   pRequest->cStatusFlag = ' ';
   hMessage.setDataLength(sizeof(hHashMessage));
   if (SwitchInterfacePool::instance()->send(&hMessage, Queue::REQUEST))
   {
      m_nState = HASH_SENT;
      m_iRollback = m_iRollbackSeconds / 60;
      return;
   }
   Console::display("ST248");
   restart();
  //## end qr::Batch::end%36F8F910018F.body
}

void Batch::endBlock ()
{
  //## begin qr::Batch::endBlock%4AAA79AE0186.body preserve=yes
   if (m_iCount >= m_iSize[1])
   {
      end();
      return;
   }
   if (m_hQueue[m_iIndex].second->getBatchSize() == 0)
   {
      Application::instance()->enable(m_hQueue[m_iIndex].first,false);
      while (++m_iIndex < m_hQueue.size())
         if (m_hQueue[m_iIndex].second->getBatchSize() > 0)
         {
            Application::instance()->enable(m_hQueue[m_iIndex].first);
            m_hQueue[m_iIndex].second->setInBatch(true);
            break;
         }
   }
  //## end qr::Batch::endBlock%4AAA79AE0186.body
}

void Batch::onConfirm ()
{
  //## begin qr::Batch::onConfirm%36F9093702CB.body preserve=yes
   Message* pMessage = Message::instance(Message::INBOUND);
   if (*((double*)(((char*)pMessage->context()) + 4)) < m_dTicks)
      return;
   vector<int>::iterator pLogConfirmation;
   pLogConfirmation = remove(m_hLogConfirmations.begin(),m_hLogConfirmations.end(),*((int*)((char*)pMessage->context())));
   if (pLogConfirmation == m_hLogConfirmations.end())
   {
      Console::display("ST507");
      restart();
      return;
   }
   m_hLogConfirmations.erase(pLogConfirmation,m_hLogConfirmations.end());
   if (m_nState == HASH_RECEIVED
      && m_hLogConfirmations.size() == 0)
      if (commit())
         begin();
      else
      {
         Console::display("ST508");
         restart(60);
      }
  //## end qr::Batch::onConfirm%36F9093702CB.body
}

void Batch::restart (int iSeconds)
{
  //## begin qr::Batch::restart%3714B6AF027F.body preserve=yes
   rollback();
   m_nState = RESTART;
   Application::instance()->enable(m_hQueue[m_iIndex].first,false);
   m_iRestart = (iSeconds) ? iSeconds / 60 : m_iRestartSeconds / 60;
   Console::display("ST115",m_iRestart);
  //## end qr::Batch::restart%3714B6AF027F.body
}

int Batch::rollback ()
{
  //## begin qr::Batch::rollback%36F809FF01C7.body preserve=yes
   UseCase hUseCase("LOG","## LG08 ROLLBACK BATCH");
   SwitchInterfacePool::instance()->clear();
   m_iCount = 0;
   if (++m_iNumber > 10000)
      m_iNumber = 1;
   vector<pair<Signal*,ExternalQueue*> >::iterator q = m_hQueue.begin();
   for (q = m_hQueue.begin();q != m_hQueue.end();++q)
   {
      if (((*q).second)->getInBatch())
         ((*q).second)->rollback();
   }
   QueueManager::instance((m_hQueue[0].second)->getQueueManager())->rollback();
   Control::rollback();
   return 0;
  //## end qr::Batch::rollback%36F809FF01C7.body
}

void Batch::update (Subject* pSubject)
{
  //## begin qr::Batch::update%36F7CCFE0301.body preserve=yes
   if (pSubject == Database::instance())
   {
      if (Database::instance()->state() == Database::CONNECTED)
      {
         vector<pair<Signal*,ExternalQueue*> >::iterator q = m_hQueue.begin();
         for (q = m_hQueue.begin();q != m_hQueue.end();++q)
            (*q).second->open();
         if (clear())
            begin();
      }
      return;
   }
   if (pSubject == QueueManager::instance((m_hQueue[m_iIndex].second)->getQueueManager()))
   {
      if (QueueManager::instance((m_hQueue[m_iIndex].second)->getQueueManager())->getState() == QueueManager::DISCONNECTED)
      {
         rollback();
         Application::instance()->enable(m_hQueue[m_iIndex].first,false);
         return;
      }
      if (clear())
         begin();
      return;
   }
   if (pSubject == Message::instance(Message::INBOUND))
   {
      Message* pMessage = Message::instance(Message::INBOUND);
      if (pMessage->messageID() == IString("S0060R"))
      {
         UseCase hUseCase("LOG","## LG06 RECEIVE HASH RESPONSE",false);
         hHashMessage* pResponse = (hHashMessage*)pMessage->data();
         if (pResponse->lSeqNo != m_iNumber) // late ACK/NAK ... ignore
            return;
         int rc = SwitchInterfacePool::instance()->handleHashResponse();
         if (rc == 0)
            return;  //wait for all responses
         m_iRollback = 0;
         if (rc > 0)
         {
            m_nState = HASH_RECEIVED;
            m_iCount = 0;
            if (m_hLogConfirmations.size() == 0)
            {
               if (commit())
                  begin();
               else
               {
                  Console::display("ST508"); // ACK
                  restart(60);
               }
            }
            return;
         }
         char szMessage[32];
         snprintf(szMessage,sizeof(szMessage),"%07i",m_iNumber);
         Console::display("ST207",szMessage); // NAK
         restart();
         UseCase::setSuccess(false);
      }
      return;
   }
   if (pSubject == MinuteTimer::instance())
   {
      if (m_iRestart > 0)
      {
         if (--m_iRestart == 0)
            if (clear())
               begin(true);
         return;
      }
      if (m_iSize[0] == 0)
      {
         begin(true);
         return;
      }
      if (m_nState == IDLE)
      {
         UseCase hUseCase("LOG","## LG09 TIMER ENDS BATCH");
         end();
         return;
      }
      if (m_iRollback > 0)
         if (--m_iRollback == 0)
         {
            UseCase hUseCase("LOG","## LG10 TIMEOUT ROLLBACK");
            Console::display("ST509");
            restart(60);
         }
      if (m_nState == BUSY)
         m_nState = IDLE;
      return;
   }
   if (pSubject == MidnightAlarm::instance())
   {
      Control::remove();
      Control::ageOffRecords();
   }
  //## end qr::Batch::update%36F7CCFE0301.body
}

void Batch::update (const string& strQueueName, const string& strTimestamp)
{
  //## begin qr::Batch::update%4C5EBE960338.body preserve=yes
   for (unsigned int i = 0;i < m_hQueue.size();i++)
   {
      if (m_hQueue[i].second->getName() == strQueueName)
      {
         if (strTimestamp <= Clock::instance()->getYYYYMMDDHHMMSSHN())
            m_hQueue[i].second->setTimestamp(strTimestamp);
         break;
      }
   }
  //## end qr::Batch::update%4C5EBE960338.body
}

void Batch::updateLogConfirmation ()
{
  //## begin qr::Batch::updateLogConfirmation%37319D4C0315.body preserve=yes
   m_hLogConfirmations.push_back(m_iCount);
  //## end qr::Batch::updateLogConfirmation%37319D4C0315.body
}

// Additional Declarations
  //## begin qr::Batch%36F7C9D8033F.declarations preserve=yes
  //## end qr::Batch%36F7C9D8033F.declarations

} // namespace qr

//## begin module%36F7C9FB0028.epilog preserve=yes
//## end module%36F7C9FB0028.epilog
