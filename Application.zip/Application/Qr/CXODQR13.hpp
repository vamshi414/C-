//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3935594701C7.cm preserve=no
//## end module%3935594701C7.cm

//## begin module%3935594701C7.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3935594701C7.cp

//## Module: CXOSQR13%3935594701C7; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR13.hpp

#ifndef CXOSQR13_h
#define CXOSQR13_h 1

//## begin module%3935594701C7.additionalIncludes preserve=no
//## end module%3935594701C7.additionalIncludes

//## begin module%3935594701C7.includes preserve=yes
// $Date:   Apr 09 2004 07:48:40  $ $Author:   D02405  $ $Revision:   1.4  $
//## end module%3935594701C7.includes

#ifndef CXOSQR02_h
#include "CXODQR02.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class ExtAPTranHandler;
class APEventHandler;
} // namespace qr

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class ExternalMessageSegment;

} // namespace repositorysegment

//## begin module%3935594701C7.declarations preserve=no
//## end module%3935594701C7.declarations

//## begin module%3935594701C7.additionalDeclarations preserve=yes
//## end module%3935594701C7.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::ExtAPControlHandler%3935589F0175.preface preserve=yes
//## end qr::ExtAPControlHandler%3935589F0175.preface

//## Class: ExtAPControlHandler%3935589F0175
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%39355B9603D9;APEventHandler { -> F}
//## Uses: <unnamed>%39355BB20357;ExtAPTranHandler { -> F}
//## Uses: <unnamed>%3937CE0503A9;repositorysegment::ExternalMessageSegment { -> F}

class ExtAPControlHandler : public APControlHandler  //## Inherits: <unnamed>%393558B20104
{
  //## begin qr::ExtAPControlHandler%3935589F0175.initialDeclarations preserve=yes
  //## end qr::ExtAPControlHandler%3935589F0175.initialDeclarations

  public:
    //## Constructors (generated)
      ExtAPControlHandler();

    //## Constructors (specified)
      //## Operation: ExtAPControlHandler%39355C130180
      ExtAPControlHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~ExtAPControlHandler();


    //## Other Operations (specified)
      //## Operation: update%39355C0E020F
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin qr::ExtAPControlHandler%3935589F0175.public preserve=yes
      //## end qr::ExtAPControlHandler%3935589F0175.public

  protected:
    // Additional Protected Declarations
      //## begin qr::ExtAPControlHandler%3935589F0175.protected preserve=yes
      //## end qr::ExtAPControlHandler%3935589F0175.protected

  private:
    // Additional Private Declarations
      //## begin qr::ExtAPControlHandler%3935589F0175.private preserve=yes
      //## end qr::ExtAPControlHandler%3935589F0175.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin qr::ExtAPControlHandler%3935589F0175.implementation preserve=yes
      //## end qr::ExtAPControlHandler%3935589F0175.implementation

};

//## begin qr::ExtAPControlHandler%3935589F0175.postscript preserve=yes
//## end qr::ExtAPControlHandler%3935589F0175.postscript

} // namespace qr

//## begin module%3935594701C7.epilog preserve=yes
//## end module%3935594701C7.epilog


#endif
