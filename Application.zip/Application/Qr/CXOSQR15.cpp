//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%420B85AF03A9.cm preserve=no
//## end module%420B85AF03A9.cm

//## begin module%420B85AF03A9.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%420B85AF03A9.cp

//## Module: CXOSQR15%420B85AF03A9; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR15.cpp

//## begin module%420B85AF03A9.additionalIncludes preserve=no
//## end module%420B85AF03A9.additionalIncludes

//## begin module%420B85AF03A9.includes preserve=yes
#ifdef _WIN32
//#include <winsock.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
#ifndef CXOSOP00_h
#include "CXODOP00.hpp"
#endif
//## end module%420B85AF03A9.includes

#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSQR18_h
#include "CXODQR18.hpp"
#endif
#ifndef CXOSQR15_h
#include "CXODQR15.hpp"
#endif


//## begin module%420B85AF03A9.declarations preserve=no
//## end module%420B85AF03A9.declarations

//## begin module%420B85AF03A9.additionalDeclarations preserve=yes
//## end module%420B85AF03A9.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::ISTAPControlHandler 

ISTAPControlHandler::ISTAPControlHandler()
  //## begin ISTAPControlHandler::ISTAPControlHandler%420B7C22007D_const.hasinit preserve=no
  //## end ISTAPControlHandler::ISTAPControlHandler%420B7C22007D_const.hasinit
  //## begin ISTAPControlHandler::ISTAPControlHandler%420B7C22007D_const.initialization preserve=yes
  //## end ISTAPControlHandler::ISTAPControlHandler%420B7C22007D_const.initialization
{
  //## begin qr::ISTAPControlHandler::ISTAPControlHandler%420B7C22007D_const.body preserve=yes
   memcpy(m_sID,"QR15",4);
  //## end qr::ISTAPControlHandler::ISTAPControlHandler%420B7C22007D_const.body
}

ISTAPControlHandler::ISTAPControlHandler (Handler* pHandler)
  //## begin qr::ISTAPControlHandler::ISTAPControlHandler%420D317A032C.hasinit preserve=no
  //## end qr::ISTAPControlHandler::ISTAPControlHandler%420D317A032C.hasinit
  //## begin qr::ISTAPControlHandler::ISTAPControlHandler%420D317A032C.initialization preserve=yes
  //## end qr::ISTAPControlHandler::ISTAPControlHandler%420D317A032C.initialization
{
  //## begin qr::ISTAPControlHandler::ISTAPControlHandler%420D317A032C.body preserve=yes
   m_pSuccessor = pHandler;
   memcpy(m_sID,"QR15",4);
  //## end qr::ISTAPControlHandler::ISTAPControlHandler%420D317A032C.body
}


ISTAPControlHandler::~ISTAPControlHandler()
{
  //## begin qr::ISTAPControlHandler::~ISTAPControlHandler%420B7C22007D_dest.body preserve=yes
  //## end qr::ISTAPControlHandler::~ISTAPControlHandler%420B7C22007D_dest.body
}



//## Other Operations (implementation)
void ISTAPControlHandler::update (Subject* pSubject)
{
  //## begin qr::ISTAPControlHandler::update%420D2EE403D8.body preserve=yes
   m_strLoggerName.assign(APISTHeader::instance()->getLoggerName());
   m_strLogOpenTimestamp.assign(APISTHeader::instance()->getLogOpenTime());
   m_dAPHash  = APISTHeader::instance()->getAPHash();
   m_lAPCount = APISTHeader::instance()->getAPCount();
   Control* pControl = Control::locate(m_strLoggerName,m_strLogOpenTimestamp);
   pControl->updateCDNHash(0);
   APControlHandler::update(pSubject);
  //## end qr::ISTAPControlHandler::update%420D2EE403D8.body
}

// Additional Declarations
  //## begin qr::ISTAPControlHandler%420B7C22007D.declarations preserve=yes
  //## end qr::ISTAPControlHandler%420B7C22007D.declarations

} // namespace qr

//## begin module%420B85AF03A9.epilog preserve=yes
//## end module%420B85AF03A9.epilog
