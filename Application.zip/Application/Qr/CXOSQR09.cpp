//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36F2D04002E0.cm preserve=no
//## end module%36F2D04002E0.cm

//## begin module%36F2D04002E0.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36F2D04002E0.cp

//## Module: CXOSQR09%36F2D04002E0; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR09.cpp

//## begin module%36F2D04002E0.additionalIncludes preserve=no
//## end module%36F2D04002E0.additionalIncludes

//## begin module%36F2D04002E0.includes preserve=yes
// $Date:   Jun 20 2020 16:08:14  $ $Author:   e1009839  $ $Revision:   1.21  $
#ifdef _WIN32
#include <winsock.h>
#endif
#ifdef _UNIX
#include <netinet/in.h>
#endif
#include "CXODIP31.hpp"
#include "CXODIP30.hpp"
#include "CXODRU24.hpp"
#include "CXODIP04.hpp"
#include "CXODIP11.hpp"
#include "CXODIP12.hpp"
#include "CXODIP13.hpp"
#include "CXODIP14.hpp"
#include "CXODIP15.hpp"
#include "CXODIP16.hpp"
#include "CXODIP18.hpp"
#include "CXODIP21.hpp"
#include "CXODIP25.hpp"
#include "CXODIP26.hpp"
//## end module%36F2D04002E0.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSQR04_h
#include "CXODQR04.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSIF22_h
#include "CXODIF22.hpp"
#endif
#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSQR05_h
#include "CXODQR05.hpp"
#endif
#ifndef CXOSIF26_h
#include "CXODIF26.hpp"
#endif
#ifndef CXOSQR22_h
#include "CXODQR22.hpp"
#endif
#ifndef CXOSQR09_h
#include "CXODQR09.hpp"
#endif


//## begin module%36F2D04002E0.declarations preserve=no
//## end module%36F2D04002E0.declarations

//## begin module%36F2D04002E0.additionalDeclarations preserve=yes
//## end module%36F2D04002E0.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::IBMAPTranHandler 

//## begin qr::IBMAPTranHandler::Logging%3729C05203DA.attr preserve=no  public: static bool {U} false
bool IBMAPTranHandler::m_bLogging = false;
//## end qr::IBMAPTranHandler::Logging%3729C05203DA.attr

IBMAPTranHandler::IBMAPTranHandler()
  //## begin IBMAPTranHandler::IBMAPTranHandler%36F2CF6F028F_const.hasinit preserve=no
  //## end IBMAPTranHandler::IBMAPTranHandler%36F2CF6F028F_const.hasinit
  //## begin IBMAPTranHandler::IBMAPTranHandler%36F2CF6F028F_const.initialization preserve=yes
  //## end IBMAPTranHandler::IBMAPTranHandler%36F2CF6F028F_const.initialization
{
  //## begin qr::IBMAPTranHandler::IBMAPTranHandler%36F2CF6F028F_const.body preserve=yes
  //## end qr::IBMAPTranHandler::IBMAPTranHandler%36F2CF6F028F_const.body
}

IBMAPTranHandler::IBMAPTranHandler (Handler* pHandler)
  //## begin qr::IBMAPTranHandler::IBMAPTranHandler%36F7F7DA011E.hasinit preserve=no
  //## end qr::IBMAPTranHandler::IBMAPTranHandler%36F7F7DA011E.hasinit
  //## begin qr::IBMAPTranHandler::IBMAPTranHandler%36F7F7DA011E.initialization preserve=yes
  //## end qr::IBMAPTranHandler::IBMAPTranHandler%36F7F7DA011E.initialization
{
  //## begin qr::IBMAPTranHandler::IBMAPTranHandler%36F7F7DA011E.body preserve=yes
   memcpy(m_sID,"QR09",4);
   m_pSuccessor = pHandler;
  //## end qr::IBMAPTranHandler::IBMAPTranHandler%36F7F7DA011E.body
}


IBMAPTranHandler::~IBMAPTranHandler()
{
  //## begin qr::IBMAPTranHandler::~IBMAPTranHandler%36F2CF6F028F_dest.body preserve=yes
  //## end qr::IBMAPTranHandler::~IBMAPTranHandler%36F2CF6F028F_dest.body
}



//## Other Operations (implementation)
void IBMAPTranHandler::update (Subject* pSubject)
{
  //## begin qr::IBMAPTranHandler::update%36F7FCE50002.body preserve=yes
   hIBMLogHeader* pIBMLogHeader = (hIBMLogHeader*)Message::instance(Message::INBOUND)->data();
   hIBMImmV340* pIBMImmV340 = (hIBMImmV340*)Message::instance(Message::INBOUND)->data();
   hIBMImmV350* pIBMImmV350 = (hIBMImmV350*)Message::instance(Message::INBOUND)->data();
   if ((memcmp(((Message*)pSubject)->getDestination().data(),"AP",2) != 0)
      || (memcmp(pIBMLogHeader->sMessageID,"C0904",5) == 0))
   {
      m_pSuccessor->update(pSubject);
      return;
   }
   double dAPHash = 0;
   DateTime hDateTime;
   IString strLogOpenTimestamp;
   IString strCorrelId = Message::instance(Message::INBOUND)->getCorrelId();
   m_strLoggerName.assign(strCorrelId,8);
   hDateTime.setFromIBM((char*)strCorrelId+8,strLogOpenTimestamp);
   m_strLogOpenTimestamp.assign(strLogOpenTimestamp,16);
   if (!SwitchInterfacePool::instance()->send(Message::instance(Message::INBOUND), Queue::DATAGRAM))
   {
      Console::display("ST248");
      Batch::instance()->restart();
      return;
   }
   if (!APEventHandler::instance()->isValidLoggerName(m_strLoggerName))
      return;
   if (m_bLogging)
   {
      char temp[12];
      int iBatchCount = Batch::instance()->getCount();
      double dBatchNumber = Batch::instance()->getTicks();
      memcpy(temp,(char*)&iBatchCount,4);
      memcpy(temp+4,(char*)&dBatchNumber,8);
      if (Log::put(Message::instance(Message::INBOUND)->data(),Message::instance(Message::INBOUND)->dataLength(),"S0042D","Log Message",temp,"CUSTLOG") != 0)
      {
         Console::display("ST506");
         Batch::instance()->restart();
         return;
      }
      Batch::instance()->updateLogConfirmation();
   }
   if ((memcmp(pIBMLogHeader->sMessageID,"A01",3) == 0)
      || (memcmp(pIBMLogHeader->sMessageID,"A02",3) == 0)
      || (memcmp(pIBMLogHeader->sMessageID,"A04",3) == 0))
   {
      int lTempLong = 0;
      if (memcmp(pIBMLogHeader->sDataFormat,"05",2) == 0)
         Decimal::asLong(pIBMImmV350->sAMT1,7,&lTempLong);
      else
         Decimal::asLong(pIBMImmV340->sAMT1,7,&lTempLong);
      dAPHash = lTempLong;
   }
   Control* pControl = Control::locate(m_strLoggerName,m_strLogOpenTimestamp);
   pControl->updateCDNHash(dAPHash);
#ifdef _LITTLE_ENDIAN
   Batch::instance()->addRecord(ntohl(*((int*)(Message::instance(Message::INBOUND)->data() + 4))));
#else
   Batch::instance()->addRecord(*((int*)(Message::instance(Message::INBOUND)->data() + 4)));
#endif
   IString strTSTAMP_TRANS;
   char szTemp[17] = {"0000000000000000"};
   if ((memcmp(pIBMLogHeader->sMessageID,"A01",3) == 0)
      || (memcmp(pIBMLogHeader->sMessageID,"A02",3) == 0)
      || (memcmp(pIBMLogHeader->sMessageID,"A04",3) == 0))
   {
      if (memcmp(pIBMLogHeader->sDataFormat,"05",2) == 0)
      {
         if (pIBMImmV350->sTS1[0] == 0x00)
         {
            if (pIBMImmV350->sTS3[0] == 0x00)
               hDateTime.setFromIBM(pIBMImmV350->sFiller,strTSTAMP_TRANS);
            else
               hDateTime.setFromIBM(pIBMImmV350->sTS3,strTSTAMP_TRANS);
         }
         else
            hDateTime.setFromIBM(pIBMImmV350->sTS1,strTSTAMP_TRANS);
      }
      else
      {
         if (pIBMImmV340->sTS1[0] == 0x00)
         {
            if (pIBMImmV340->sTS3[0] == 0x00)
               hDateTime.setFromIBM(pIBMImmV340->sFiller,strTSTAMP_TRANS);
            else
               hDateTime.setFromIBM(pIBMImmV340->sTS3,strTSTAMP_TRANS);
         }
         else
            hDateTime.setFromIBM(pIBMImmV340->sTS1,strTSTAMP_TRANS);
      }
   }
   else
   if ((memcmp(pIBMLogHeader->sMessageID,"C6507",5) == 0)
      || (memcmp(pIBMLogHeader->sMessageID,"C6508",5) == 0)
      || (memcmp(pIBMLogHeader->sMessageID,"C6511",5) == 0))
   {
      hIBMAp* pIBMAp = (hIBMAp*)Message::instance(Message::INBOUND)->data();
      hDateTime.setFromIBM(pIBMAp->sTimestamp,strTSTAMP_TRANS);
   }
   else
   if (memcmp(pIBMLogHeader->sMessageID,"A03",3) == 0)
   {
      hIBMNegFile* pIBMNegFile = (hIBMNegFile*)Message::instance(Message::INBOUND)->data();
      hDateTime.setFromIBM(pIBMNegFile->sTimestamp8,strTSTAMP_TRANS);
   }
   else
   if (memcmp(pIBMLogHeader->sMessageID,"H4001",5) == 0)
   {
      hIBMTermStatus* pIBMTermStatus = (hIBMTermStatus*)Message::instance(Message::INBOUND)->data();
      hDateTime.setFromIBM(pIBMTermStatus->sHdrStck,strTSTAMP_TRANS);
   }
   else
   if ((memcmp(pIBMLogHeader->sMessageID,"H4002",5) == 0)
      || (memcmp(pIBMLogHeader->sMessageID,"H4003",5) == 0))
   {
      hIBMProcStatus* pIBMProcStatus = (hIBMProcStatus*)Message::instance(Message::INBOUND)->data();
      hDateTime.setFromIBM(pIBMProcStatus->sHdrStck,strTSTAMP_TRANS);
   }
   else
   if (memcmp(pIBMLogHeader->sMessageID,"H4006",5) == 0)
   {
      hIBMLineStatus* pIBMLineStatus = (hIBMLineStatus*)Message::instance(Message::INBOUND)->data();
      hDateTime.setFromIBM(pIBMLineStatus->sHdrStck,strTSTAMP_TRANS);
   }
   else
   if (memcmp(pIBMLogHeader->sMessageID,"C7",2) == 0)
   {
      hIBMStdAdjustment* pIBMStdAdjustment = (hIBMStdAdjustment*)Message::instance(Message::INBOUND)->data();
      hDateTime.setFromIBM(pIBMStdAdjustment->sHdrStck,strTSTAMP_TRANS);
   }
   else
   if (memcmp(pIBMLogHeader->sMessageID,"A08",3) == 0)
   {
      hIBMNetworkManagement* pIBMNetworkManagement = (hIBMNetworkManagement*)Message::instance(Message::INBOUND)->data();
      memcpy(szTemp,pIBMNetworkManagement->sPSDateMMDDYYYY + 4,4);
      memcpy(szTemp + 4,pIBMNetworkManagement->sPSDateMMDDYYYY,4);
      memcpy(szTemp + 8,pIBMNetworkManagement->sPsTimeHHMMSS,6);
      strTSTAMP_TRANS = szTemp;
   }
   else
   if (memcmp(pIBMLogHeader->sMessageID,"C1031",5) == 0)
   {
      hIBMTermTotals* pIBMTermTotals = (hIBMTermTotals*)Message::instance(Message::INBOUND)->data();
      memcpy(szTemp,pIBMTermTotals->sPsDateMMDDYYYY + 4,4);
      memcpy(szTemp + 4,pIBMTermTotals->sPsDateMMDDYYYY,4);
      memcpy(szTemp + 8,pIBMTermTotals->sPsTimeHHMMSS,6);
      strTSTAMP_TRANS = szTemp;
   }
   else
      return;
   string strTemp(strTSTAMP_TRANS);
   APEventHandler::instance()->update(m_strLoggerName,strTemp);
   Batch::instance()->update(Message::instance(Message::INBOUND)->getDestination(),strTemp);
  //## end qr::IBMAPTranHandler::update%36F7FCE50002.body
}

// Additional Declarations
  //## begin qr::IBMAPTranHandler%36F2CF6F028F.declarations preserve=yes
  //## end qr::IBMAPTranHandler%36F2CF6F028F.declarations

} // namespace qr

//## begin module%36F2D04002E0.epilog preserve=yes
//## end module%36F2D04002E0.epilog
