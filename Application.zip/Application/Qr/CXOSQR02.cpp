//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36F7BE7703E0.cm preserve=no
//## end module%36F7BE7703E0.cm

//## begin module%36F7BE7703E0.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36F7BE7703E0.cp

//## Module: CXOSQR02%36F7BE7703E0; Package body
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXOSQR02.cpp

//## begin module%36F7BE7703E0.additionalIncludes preserve=no
//## end module%36F7BE7703E0.additionalIncludes

//## begin module%36F7BE7703E0.includes preserve=yes
// $Date:   Apr 09 2004 07:48:40  $ $Author:   D02405  $ $Revision:   1.18  $
//## end module%36F7BE7703E0.includes

#ifndef CXOSQR03_h
#include "CXODQR03.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSQR02_h
#include "CXODQR02.hpp"
#endif


//## begin module%36F7BE7703E0.declarations preserve=no
//## end module%36F7BE7703E0.declarations

//## begin module%36F7BE7703E0.additionalDeclarations preserve=yes
//## end module%36F7BE7703E0.additionalDeclarations


//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

// Class qr::APControlHandler 

APControlHandler::APControlHandler()
  //## begin APControlHandler::APControlHandler%36F2CF930219_const.hasinit preserve=no
      : m_lAPCount(0),
        m_dAPHash(0)
  //## end APControlHandler::APControlHandler%36F2CF930219_const.hasinit
  //## begin APControlHandler::APControlHandler%36F2CF930219_const.initialization preserve=yes
  //## end APControlHandler::APControlHandler%36F2CF930219_const.initialization
{
  //## begin qr::APControlHandler::APControlHandler%36F2CF930219_const.body preserve=yes
   memcpy(m_sID,"QR02",4);
  //## end qr::APControlHandler::APControlHandler%36F2CF930219_const.body
}

APControlHandler::APControlHandler (Handler* pHandler)
  //## begin qr::APControlHandler::APControlHandler%36FA755002BA.hasinit preserve=no
      : m_lAPCount(0),
        m_dAPHash(0)
  //## end qr::APControlHandler::APControlHandler%36FA755002BA.hasinit
  //## begin qr::APControlHandler::APControlHandler%36FA755002BA.initialization preserve=yes
  //## end qr::APControlHandler::APControlHandler%36FA755002BA.initialization
{
  //## begin qr::APControlHandler::APControlHandler%36FA755002BA.body preserve=yes
   memcpy(m_sID,"QR02",4);
   m_pSuccessor = pHandler;
  //## end qr::APControlHandler::APControlHandler%36FA755002BA.body
}


APControlHandler::~APControlHandler()
{
  //## begin qr::APControlHandler::~APControlHandler%36F2CF930219_dest.body preserve=yes
  //## end qr::APControlHandler::~APControlHandler%36F2CF930219_dest.body
}



//## Other Operations (implementation)
void APControlHandler::update (Subject* pSubject)
{
  //## begin qr::APControlHandler::update%36F93F0B0153.body preserve=yes
   Control* pControl = Control::locate(m_strLoggerName,m_strLogOpenTimestamp);
   string strKey = m_strLogOpenTimestamp + "," + m_strLoggerName;
   if (((pControl->getAP_Count() != 0) || (pControl->getAP_Hash() != 0))  &&
      ((pControl->getAP_Count() != m_lAPCount) || (pControl->getAP_Hash() != m_dAPHash)))
      // control message already received
      Console::display("ST502",strKey.c_str());
   if (m_dAPHash != pControl->getCDN_Hash() + pControl->getTemp_CDN_Hash())
      // unload hash totals do not match
      Console::display("ST501",strKey.c_str());
   else
      pControl->setAmountsMatch(true);
   if (m_lAPCount > pControl->getCDN_Count() + pControl->getTemp_CDN_Count())
      // record counts do not match - DataNavigator missing records
      Console::display("ST500",strKey.c_str());
   else
   if (m_lAPCount < pControl->getCDN_Count() + pControl->getTemp_CDN_Count())
      // record counts do not match - DataNavigator got too many records
      Console::display("ST517",strKey.c_str());
   else
      pControl->setCountsMatch(true);
   pControl->setAP_Count(m_lAPCount);
   pControl->setAP_Hash(m_dAPHash);
  //## end qr::APControlHandler::update%36F93F0B0153.body
}

// Additional Declarations
  //## begin qr::APControlHandler%36F2CF930219.declarations preserve=yes
  //## end qr::APControlHandler%36F2CF930219.declarations

} // namespace qr

//## begin module%36F7BE7703E0.epilog preserve=yes
//## end module%36F7BE7703E0.epilog
