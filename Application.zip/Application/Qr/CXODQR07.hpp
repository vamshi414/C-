//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%37F8EFAB002C.cm preserve=no
//## end module%37F8EFAB002C.cm

//## begin module%37F8EFAB002C.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%37F8EFAB002C.cp

//## Module: CXOSQR07%37F8EFAB002C; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR07.hpp

#ifndef CXOSQR07_h
#define CXOSQR07_h 1

//## begin module%37F8EFAB002C.additionalIncludes preserve=no
//## end module%37F8EFAB002C.additionalIncludes

//## begin module%37F8EFAB002C.includes preserve=yes
//## end module%37F8EFAB002C.includes

#ifndef CXOSRU14_h
#include "CXODRU14.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Batch;
class SwitchInterfacePool;
class APAdvgHeader;
class APEventHandler;
class Control;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class DateTime;
class Console;
class Decimal;
class Queue;
class CodeTable;
class Trace;
class Log;
} // namespace IF

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class NonStopClock;

} // namespace timer

//## begin module%37F8EFAB002C.declarations preserve=no
//## end module%37F8EFAB002C.declarations

//## begin module%37F8EFAB002C.additionalDeclarations preserve=yes
//## end module%37F8EFAB002C.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::AdvgAPTranHandler%37F8F0900269.preface preserve=yes
//## end qr::AdvgAPTranHandler%37F8F0900269.preface

//## Class: AdvgAPTranHandler%37F8F0900269
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%37F919550205;APEventHandler { -> F}
//## Uses: <unnamed>%37F91B1D010B;Batch { -> F}
//## Uses: <unnamed>%37F91B47031E;Control { -> F}
//## Uses: <unnamed>%37F91C15005D;IF::CodeTable { -> F}
//## Uses: <unnamed>%37F91C220369;IF::DateTime { -> F}
//## Uses: <unnamed>%37F91C560260;IF::Decimal { -> F}
//## Uses: <unnamed>%37F91C92011B;IF::Log { -> F}
//## Uses: <unnamed>%37F91CC8014B;IF::Queue { -> F}
//## Uses: <unnamed>%37F91CE9006C;IF::Trace { -> F}
//## Uses: <unnamed>%37FBABCD0168;IF::Console { -> F}
//## Uses: <unnamed>%389B2C53027C;APAdvgHeader { -> F}
//## Uses: <unnamed>%515D6DBA0049;timer::NonStopClock { -> F}
//## Uses: <unnamed>%63A0D328010F;SwitchInterfacePool { -> F}

class AdvgAPTranHandler : public reusable::Handler  //## Inherits: <unnamed>%389ACF1B00FB
{
  //## begin qr::AdvgAPTranHandler%37F8F0900269.initialDeclarations preserve=yes
  //## end qr::AdvgAPTranHandler%37F8F0900269.initialDeclarations

  public:
    //## Constructors (generated)
      AdvgAPTranHandler();

    //## Constructors (specified)
      //## Operation: AdvgAPTranHandler%37F916340367
      AdvgAPTranHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~AdvgAPTranHandler();


    //## Other Operations (specified)
      //## Operation: update%37F914DD0170
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: Logging%37F9102B0074
      static const bool getLogging ()
      {
        //## begin qr::AdvgAPTranHandler::getLogging%37F9102B0074.get preserve=no
        return m_bLogging;
        //## end qr::AdvgAPTranHandler::getLogging%37F9102B0074.get
      }

      static void setLogging (bool value)
      {
        //## begin qr::AdvgAPTranHandler::setLogging%37F9102B0074.set preserve=no
        m_bLogging = value;
        //## end qr::AdvgAPTranHandler::setLogging%37F9102B0074.set
      }


    // Additional Public Declarations
      //## begin qr::AdvgAPTranHandler%37F8F0900269.public preserve=yes
      //## end qr::AdvgAPTranHandler%37F8F0900269.public

  protected:
    // Additional Protected Declarations
      //## begin qr::AdvgAPTranHandler%37F8F0900269.protected preserve=yes
      //## end qr::AdvgAPTranHandler%37F8F0900269.protected

  private:
    // Additional Private Declarations
      //## begin qr::AdvgAPTranHandler%37F8F0900269.private preserve=yes
      //## end qr::AdvgAPTranHandler%37F8F0900269.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: LoggerName%37F90F72031C
      //## begin qr::AdvgAPTranHandler::LoggerName%37F90F72031C.attr preserve=no  private: string {U} 
      string m_strLoggerName;
      //## end qr::AdvgAPTranHandler::LoggerName%37F90F72031C.attr

      //## Attribute: LogOpenTimestamp%37F90F9E0316
      //## begin qr::AdvgAPTranHandler::LogOpenTimestamp%37F90F9E0316.attr preserve=no  private: string {U} 
      string m_strLogOpenTimestamp;
      //## end qr::AdvgAPTranHandler::LogOpenTimestamp%37F90F9E0316.attr

      //## begin qr::AdvgAPTranHandler::Logging%37F9102B0074.attr preserve=no  public: static bool {U} false
      static bool m_bLogging;
      //## end qr::AdvgAPTranHandler::Logging%37F9102B0074.attr

    // Data Members for Associations

      //## Association: Continuous Feed::QueueReader_CAT::<unnamed>%515D6D020221
      //## Role: AdvgAPTranHandler::<m_hMessage>%515D6D0300A1
      //## begin qr::AdvgAPTranHandler::<m_hMessage>%515D6D0300A1.role preserve=no  public: IF::Message { -> 0..*VHgN}
      vector<IF::Message> m_hMessage;
      //## end qr::AdvgAPTranHandler::<m_hMessage>%515D6D0300A1.role

    // Additional Implementation Declarations
      //## begin qr::AdvgAPTranHandler%37F8F0900269.implementation preserve=yes
      //## end qr::AdvgAPTranHandler%37F8F0900269.implementation

};

//## begin qr::AdvgAPTranHandler%37F8F0900269.postscript preserve=yes
//## end qr::AdvgAPTranHandler%37F8F0900269.postscript

} // namespace qr

//## begin module%37F8EFAB002C.epilog preserve=yes
//## end module%37F8EFAB002C.epilog


#endif
