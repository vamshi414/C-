//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%37F8F1D4037D.cm preserve=no
//## end module%37F8F1D4037D.cm

//## begin module%37F8F1D4037D.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%37F8F1D4037D.cp

//## Module: CXOSQR08%37F8F1D4037D; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR08.hpp

#ifndef CXOSQR08_h
#define CXOSQR08_h 1

//## begin module%37F8F1D4037D.additionalIncludes preserve=no
//## end module%37F8F1D4037D.additionalIncludes

//## begin module%37F8F1D4037D.includes preserve=yes
// $Date:   Sep 06 2006 15:36:16  $ $Author:   D02405  $ $Revision:   1.8  $
//## end module%37F8F1D4037D.includes

#ifndef CXOSQR02_h
#include "CXODQR02.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Batch;
class IBMAPTranHandler;
class APEventHandler;
class Control;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class DateTime;
class Extract;
class Console;
class CodeTable;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;

} // namespace segment

//## begin module%37F8F1D4037D.declarations preserve=no
//## end module%37F8F1D4037D.declarations

//## begin module%37F8F1D4037D.additionalDeclarations preserve=yes
//## end module%37F8F1D4037D.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::IBMAPControlHandler%37F8F0F00203.preface preserve=yes
#include "CXODRU32.hpp"
struct hC0904Message{
 //C0904 Message header structure
   char   sSTCK[8];
   char   sTaskName[8];
   char   sMsgID[5];
   char   sRetryInd[1];
   char   sReasonCode[18];
   char   sStationID[8];
   char   sLUName[8];
   char   sFlag[1];
   char   sFiller[7];
 //C0904 Message structure
   short  siMsgLen;
   char   sMsgFormat[2];
   char   sProcessName[8];
   char   sBatchIdSTCK[8];
   int   lTranCnt;
   unsigned int lHashValue;
};
#include "CXODRU33.hpp"
//## end qr::IBMAPControlHandler%37F8F0F00203.preface

//## Class: IBMAPControlHandler%37F8F0F00203
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%37FA07C30274;IBMAPTranHandler { -> F}
//## Uses: <unnamed>%37FA07E8032C;Batch { -> F}
//## Uses: <unnamed>%37FA080A02BF;Control { -> F}
//## Uses: <unnamed>%37FA08370288;process::Application { -> F}
//## Uses: <unnamed>%37FA085E02FC;segment::Segment { -> F}
//## Uses: <unnamed>%37FA08A9037C;IF::DateTime { -> F}
//## Uses: <unnamed>%37FA08AF017C;IF::CodeTable { -> F}
//## Uses: <unnamed>%37FA08C402EF;IF::Console { -> F}
//## Uses: <unnamed>%37FA08E10264;IF::Extract { -> F}
//## Uses: <unnamed>%37FA08FD0138;IF::Message { -> F}
//## Uses: <unnamed>%37FA090E0269;IF::Trace { -> F}
//## Uses: <unnamed>%3869FEF6021C;APEventHandler { -> F}

class IBMAPControlHandler : public APControlHandler  //## Inherits: <unnamed>%37FA077600B1
{
  //## begin qr::IBMAPControlHandler%37F8F0F00203.initialDeclarations preserve=yes
  //## end qr::IBMAPControlHandler%37F8F0F00203.initialDeclarations

  public:
    //## Constructors (generated)
      IBMAPControlHandler();

    //## Constructors (specified)
      //## Operation: IBMAPControlHandler%37FB899302DA
      IBMAPControlHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~IBMAPControlHandler();


    //## Other Operations (specified)
      //## Operation: update%37FA07870340
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin qr::IBMAPControlHandler%37F8F0F00203.public preserve=yes
      //## end qr::IBMAPControlHandler%37F8F0F00203.public

  protected:
    // Additional Protected Declarations
      //## begin qr::IBMAPControlHandler%37F8F0F00203.protected preserve=yes
      //## end qr::IBMAPControlHandler%37F8F0F00203.protected

  private:
    // Additional Private Declarations
      //## begin qr::IBMAPControlHandler%37F8F0F00203.private preserve=yes
      //## end qr::IBMAPControlHandler%37F8F0F00203.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin qr::IBMAPControlHandler%37F8F0F00203.implementation preserve=yes
      //## end qr::IBMAPControlHandler%37F8F0F00203.implementation

};

//## begin qr::IBMAPControlHandler%37F8F0F00203.postscript preserve=yes
//## end qr::IBMAPControlHandler%37F8F0F00203.postscript

} // namespace qr

//## begin module%37F8F1D4037D.epilog preserve=yes
//## end module%37F8F1D4037D.epilog


#endif
