//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%36F7BE7601EA.cm preserve=no
//## end module%36F7BE7601EA.cm

//## begin module%36F7BE7601EA.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%36F7BE7601EA.cp

//## Module: CXOSQR02%36F7BE7601EA; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR02.hpp

#ifndef CXOSQR02_h
#define CXOSQR02_h 1

//## begin module%36F7BE7601EA.additionalIncludes preserve=no
//## end module%36F7BE7601EA.additionalIncludes

//## begin module%36F7BE7601EA.includes preserve=yes
// $Date:   Jun 30 2006 12:12:40  $ $Author:   D02405  $ $Revision:   1.14  $
//## end module%36F7BE7601EA.includes

#ifndef CXOSRU14_h
#include "CXODRU14.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Control;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Console;

} // namespace IF

//## begin module%36F7BE7601EA.declarations preserve=no
//## end module%36F7BE7601EA.declarations

//## begin module%36F7BE7601EA.additionalDeclarations preserve=yes
//## end module%36F7BE7601EA.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::APControlHandler%36F2CF930219.preface preserve=yes
//## end qr::APControlHandler%36F2CF930219.preface

//## Class: APControlHandler%36F2CF930219
//	<body>
//	<title>CG
//	<h1>QR
//	<h2>MS
//	<!-- APControlHandler : General -->
//	<h3>Controls
//	<p>
//	The Queue Reader service counts and calculates a hash
//	total for all transactions received from the acquiring
//	platform.
//	The counts and totals are maintained for each log file
//	produced by the switch.
//	Mismatches between the control record provided by the
//	switch and the counts calculated by the Queue Reader are
//	reported on the operator console:
//	<ul>
//	<li>DataNavigator count < control record count: ST500 :
//	TRAN COUNT MISMATCH
//	<li>DataNavigator hash <> control record hash: ST501 :
//	HASH AMOUNT MISMATCH
//	<li>DataNavigator count > control record count: ST517 :
//	DATANAVIGATOR > SWITCH
//	<li>Duplicate control record received: ST502 : CONTROL
//	RECORD ALREADY RECEIVED
//	</ul>
//	<p>
//	The control information is check pointed in the TASK_
//	CONTEXT table.
//	The key to the entry is the log open timestamp and the
//	logger name.
//	The data contains the following information:
//	<ul>
//	<li>Switch transaction count
//	<li>DataNavigator transaction count
//	<li>Switch hash total
//	<li>DataNavigator hash total
//	<li>0 (false) or 1 (true) if counts match
//	<li>0 (false) or 1 (true) if hash totals match
//	</ul>
//	<p>
//	The key and data for a sample matching entry appears in
//	TASK_CONTEXT as:
//	<p>
//	2012071801593394,\NS4.$CALG6
//	3949,3949,14160894.00,14160894.00,1,1
//	<p>
//	All control records are logged with a context type of
//	'C'.
//	</body>
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%36FA692B01A1;Control { -> F}
//## Uses: <unnamed>%3714FEBD01BB;IF::Console { -> F}

class APControlHandler : public reusable::Handler  //## Inherits: <unnamed>%36F93E8702A8
{
  //## begin qr::APControlHandler%36F2CF930219.initialDeclarations preserve=yes
  //## end qr::APControlHandler%36F2CF930219.initialDeclarations

  public:
    //## Constructors (generated)
      APControlHandler();

    //## Constructors (specified)
      //## Operation: APControlHandler%36FA755002BA
      APControlHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~APControlHandler();


    //## Other Operations (specified)
      //## Operation: update%36F93F0B0153
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin qr::APControlHandler%36F2CF930219.public preserve=yes
      //## end qr::APControlHandler%36F2CF930219.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: APCount%37FB8AF500C6
      //## begin qr::APControlHandler::APCount%37FB8AF500C6.attr preserve=no  protected: int {V} 0
      int m_lAPCount;
      //## end qr::APControlHandler::APCount%37FB8AF500C6.attr

      //## Attribute: APHash%37FB8A9E0157
      //## begin qr::APControlHandler::APHash%37FB8A9E0157.attr preserve=no  protected: double {V} 0
      double m_dAPHash;
      //## end qr::APControlHandler::APHash%37FB8A9E0157.attr

      //## Attribute: LoggerName%37FB8B200154
      //## begin qr::APControlHandler::LoggerName%37FB8B200154.attr preserve=no  protected: string {V} 
      string m_strLoggerName;
      //## end qr::APControlHandler::LoggerName%37FB8B200154.attr

      //## Attribute: LogOpenTimestamp%37FB8B4603B2
      //## begin qr::APControlHandler::LogOpenTimestamp%37FB8B4603B2.attr preserve=no  protected: string {V} 
      string m_strLogOpenTimestamp;
      //## end qr::APControlHandler::LogOpenTimestamp%37FB8B4603B2.attr

    // Additional Protected Declarations
      //## begin qr::APControlHandler%36F2CF930219.protected preserve=yes
      //## end qr::APControlHandler%36F2CF930219.protected

  private:
    // Additional Private Declarations
      //## begin qr::APControlHandler%36F2CF930219.private preserve=yes
      //## end qr::APControlHandler%36F2CF930219.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin qr::APControlHandler%36F2CF930219.implementation preserve=yes
      //## end qr::APControlHandler%36F2CF930219.implementation

};

//## begin qr::APControlHandler%36F2CF930219.postscript preserve=yes
//## end qr::APControlHandler%36F2CF930219.postscript

} // namespace qr

//## begin module%36F7BE7601EA.epilog preserve=yes
//## end module%36F7BE7601EA.epilog


#endif
