//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%37F8ED510199.cm preserve=no
//## end module%37F8ED510199.cm

//## begin module%37F8ED510199.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%37F8ED510199.cp

//## Module: CXOSQR06%37F8ED510199; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR06.hpp

#ifndef CXOSQR06_h
#define CXOSQR06_h 1

//## begin module%37F8ED510199.additionalIncludes preserve=no
//## end module%37F8ED510199.additionalIncludes

//## begin module%37F8ED510199.includes preserve=yes
// $Date:   Apr 09 2004 07:48:36  $ $Author:   D02405  $ $Revision:   1.5  $
//## end module%37F8ED510199.includes

#ifndef CXOSQR02_h
#include "CXODQR02.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Batch;
class APAdvgHeader;
class AdvgAPTranHandler;
class APEventHandler;
class Control;
} // namespace qr

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class DateTime;
class Extract;
class Console;
class CodeTable;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;

} // namespace segment

//## begin module%37F8ED510199.declarations preserve=no
//## end module%37F8ED510199.declarations

//## begin module%37F8ED510199.additionalDeclarations preserve=yes
//## end module%37F8ED510199.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::AdvgAPControlHandler%37F8ECD503AD.preface preserve=yes
//## end qr::AdvgAPControlHandler%37F8ECD503AD.preface

//## Class: AdvgAPControlHandler%37F8ECD503AD
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%37FA039E038E;AdvgAPTranHandler { -> F}
//## Uses: <unnamed>%37FA03B60284;Batch { -> F}
//## Uses: <unnamed>%37FA03CF03AD;Control { -> F}
//## Uses: <unnamed>%37FA040E00FA;process::Application { -> F}
//## Uses: <unnamed>%37FA046101D6;IF::CodeTable { -> F}
//## Uses: <unnamed>%37FA047D0279;IF::Console { -> F}
//## Uses: <unnamed>%37FA04E6002B;IF::DateTime { -> F}
//## Uses: <unnamed>%37FA04E90148;IF::Extract { -> F}
//## Uses: <unnamed>%37FA04EC0138;IF::Message { -> F}
//## Uses: <unnamed>%37FA04F002ED;IF::Trace { -> F}
//## Uses: <unnamed>%37FA052103B6;segment::Segment { -> F}
//## Uses: <unnamed>%3869FEC201E5;APEventHandler { -> F}
//## Uses: <unnamed>%389C5DC9012B;APAdvgHeader { -> F}

class AdvgAPControlHandler : public APControlHandler  //## Inherits: <unnamed>%37F90BBF00FB
{
  //## begin qr::AdvgAPControlHandler%37F8ECD503AD.initialDeclarations preserve=yes
  //## end qr::AdvgAPControlHandler%37F8ECD503AD.initialDeclarations

  public:
    //## Constructors (generated)
      AdvgAPControlHandler();

    //## Constructors (specified)
      //## Operation: AdvgAPControlHandler%37FB89F60156
      AdvgAPControlHandler (Handler* pHandler);

    //## Destructor (generated)
      virtual ~AdvgAPControlHandler();


    //## Other Operations (specified)
      //## Operation: update%37F90BF002DC
      //	Callback function that is invoked by a subject when its
      //	state changes.
      void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin qr::AdvgAPControlHandler%37F8ECD503AD.public preserve=yes
      //## end qr::AdvgAPControlHandler%37F8ECD503AD.public

  protected:
    // Additional Protected Declarations
      //## begin qr::AdvgAPControlHandler%37F8ECD503AD.protected preserve=yes
      //## end qr::AdvgAPControlHandler%37F8ECD503AD.protected

  private:
    // Additional Private Declarations
      //## begin qr::AdvgAPControlHandler%37F8ECD503AD.private preserve=yes
      //## end qr::AdvgAPControlHandler%37F8ECD503AD.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin qr::AdvgAPControlHandler%37F8ECD503AD.implementation preserve=yes
      //## end qr::AdvgAPControlHandler%37F8ECD503AD.implementation

};

//## begin qr::AdvgAPControlHandler%37F8ECD503AD.postscript preserve=yes
//## end qr::AdvgAPControlHandler%37F8ECD503AD.postscript

} // namespace qr

//## begin module%37F8ED510199.epilog preserve=yes
//## end module%37F8ED510199.epilog


#endif
