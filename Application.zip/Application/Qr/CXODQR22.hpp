//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%632B4D6503B0.cm preserve=no
//## end module%632B4D6503B0.cm

//## begin module%632B4D6503B0.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%632B4D6503B0.cp

//## Module: CXOSQR22%632B4D6503B0; Package specification
//## Subsystem: QR%36C87D9902C8
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Qr\CXODQR22.hpp

#ifndef CXOSQR22_h
#define CXOSQR22_h 1

//## begin module%632B4D6503B0.additionalIncludes preserve=no
//## end module%632B4D6503B0.additionalIncludes

//## begin module%632B4D6503B0.includes preserve=yes
#include <map>
#include "CXODIF11.hpp"
#include "CXODIF22.hpp"
//## end module%632B4D6503B0.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Continuous Feed::QueueReader_CAT%36C82D990201
namespace qr {
class Control;
} // namespace qr

//## Modelname: DataNavigator Foundation::SwitchInterface_CAT%358EB6E20186
namespace switchinterface {
class Hash;
} // namespace switchinterface

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class Extract;
class Queue;
class Trace;

} // namespace IF

//## begin module%632B4D6503B0.declarations preserve=no
//## end module%632B4D6503B0.declarations

//## begin module%632B4D6503B0.additionalDeclarations preserve=yes
//## end module%632B4D6503B0.additionalDeclarations


namespace qr {
//## begin qr%36C82D990201.initialDeclarations preserve=yes
//## end qr%36C82D990201.initialDeclarations

//## begin qr::SwitchInterfacePool%632B4D170274.preface preserve=yes
//## end qr::SwitchInterfacePool%632B4D170274.preface

//## Class: SwitchInterfacePool%632B4D170274
//## Category: Continuous Feed::QueueReader_CAT%36C82D990201
//## Subsystem: QR%36C87D9902C8
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%632B5067010E;switchinterface::Hash { -> F}
//## Uses: <unnamed>%632B5C21027B;IF::Extract { -> F}
//## Uses: <unnamed>%632CCACF02BC;IF::Message { -> F}
//## Uses: <unnamed>%63921F2802E1;Control { -> F}
//## Uses: <unnamed>%63921F8703DC;IF::Queue { -> F}
//## Uses: <unnamed>%63A0D1A302E6;IF::Trace { -> F}

class DllExport SwitchInterfacePool : public reusable::Object  //## Inherits: <unnamed>%632CC92101D3
{
  //## begin qr::SwitchInterfacePool%632B4D170274.initialDeclarations preserve=yes
  public: 
   enum SwitchInterfaceStatus
   {
      AVAILABLE,
      UNAVAILABLE
   };

  //## end qr::SwitchInterfacePool%632B4D170274.initialDeclarations

  public:
    //## Constructors (generated)
      SwitchInterfacePool();

    //## Destructor (generated)
      virtual ~SwitchInterfacePool();


    //## Other Operations (specified)
      //## Operation: add%632B546A036A
      void add (const string strSwitchInterface);

      //## Operation: clear%639219530157
      void clear ();

      //## Operation: drop%632B54C60228
      void drop (const string strSwitchInterface);

      //## Operation: handleHashResponse%632CB76801A7
      int handleHashResponse ();

      //## Operation: initialize%632B4F7F0239
      virtual int initialize ();

      //## Operation: instance%632CC6AE0006
      static SwitchInterfacePool* instance ();

      //## Operation: send%632C90570136
      bool send (Message* pMessage, Queue::MessageType nMessageType);

      //## Operation: updateHash%6392196501F3
      void updateHash (double dHash);

    // Additional Public Declarations
      //## begin qr::SwitchInterfacePool%632B4D170274.public preserve=yes
      //## end qr::SwitchInterfacePool%632B4D170274.public

  protected:
    // Additional Protected Declarations
      //## begin qr::SwitchInterfacePool%632B4D170274.protected preserve=yes
      //## end qr::SwitchInterfacePool%632B4D170274.protected

  private:
    // Additional Private Declarations
      //## begin qr::SwitchInterfacePool%632B4D170274.private preserve=yes
      //## end qr::SwitchInterfacePool%632B4D170274.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Pool%632B55EB024C
      //## begin qr::SwitchInterfacePool::Pool%632B55EB024C.attr preserve=no  private: map<string,pair<double,int>,less<string> > {U} 
      map<string,pair<double,int>,less<string> > m_hPool[2];
      //## end qr::SwitchInterfacePool::Pool%632B55EB024C.attr

      //## Attribute: AI%632B631D00B4
      //## begin qr::SwitchInterfacePool::AI%632B631D00B4.attr preserve=no  private: map<string,pair<double,int>,less<string> >::iterator {V} 
      map<string,pair<double,int>,less<string> >::iterator m_pAI;
      //## end qr::SwitchInterfacePool::AI%632B631D00B4.attr

      //## Attribute: HashSentCount%632CB9C3024A
      //## begin qr::SwitchInterfacePool::HashSentCount%632CB9C3024A.attr preserve=no  public: int {U} 0
      int m_iHashSentCount;
      //## end qr::SwitchInterfacePool::HashSentCount%632CB9C3024A.attr

      //## Attribute: Instance%632CC62C03D0
      //## begin qr::SwitchInterfacePool::Instance%632CC62C03D0.attr preserve=no  private: static SwitchInterfacePool {R} 0
      static SwitchInterfacePool *m_pInstance;
      //## end qr::SwitchInterfacePool::Instance%632CC62C03D0.attr

      //## Attribute: HashFail%6398FE690143
      //## begin qr::SwitchInterfacePool::HashFail%6398FE690143.attr preserve=no  private: bool {U} false
      bool m_bHashFail;
      //## end qr::SwitchInterfacePool::HashFail%6398FE690143.attr

    // Additional Implementation Declarations
      //## begin qr::SwitchInterfacePool%632B4D170274.implementation preserve=yes
      //## end qr::SwitchInterfacePool%632B4D170274.implementation

};

//## begin qr::SwitchInterfacePool%632B4D170274.postscript preserve=yes
//## end qr::SwitchInterfacePool%632B4D170274.postscript

} // namespace qr

//## begin module%632B4D6503B0.epilog preserve=yes
//## end module%632B4D6503B0.epilog


#endif
