// Copyright (c) 1998 - 2020
// FIS
// $Date:   Jun 19 2020 13:25:50  $ $Author:   e1009839  $ $Revision:   1.0  $

#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif

#include "CXODSI01.hpp"
#include "CXODPP01.hpp"
#include "CXODMN05.hpp"
#include "CXODDZ01.hpp"

#include "CXODPS06.hpp"
   pApplication = new SwitchInterface();
   pApplication->parseCommandLine(argc,argv);
   new dnplatform::DNPlatform();
   ((SwitchInterface*)pApplication)->setMessageProcessor(new postilionmessageprocessor::PostilionMessageProcessor);
   int iRC = 0;
   {
      iRC = pApplication->initialize();
      UseCase hUseCase("ACI","## PI00 START PI");
      if (iRC == -1)
         UseCase::setSuccess(false);
   }
   if (iRC == 0)
      pApplication->run();
#include "CXODPS07.hpp"
