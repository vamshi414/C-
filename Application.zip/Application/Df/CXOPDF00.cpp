//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41B4878C03D8.cm preserve=no
//	$Date:   Aug 21 2020 16:47:48  $ $Author:   e1009652  $
//	$Revision:   1.62.1.7  $
//## end module%41B4878C03D8.cm

//## begin module%41B4878C03D8.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%41B4878C03D8.cp

//## Module: CXOPDF00%41B4878C03D8; Package body
//## Subsystem: DF%41A351850261
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Df\CXOPDF00.cpp

//## begin module%41B4878C03D8.additionalIncludes preserve=no
//## end module%41B4878C03D8.additionalIncludes

//## begin module%41B4878C03D8.includes preserve=yes
#define STS_RECORD_NOT_FOUND 14
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE),ENVAR('TASK=DF'))
#endif
#ifndef CXOSTC32_h
#include "CXODTC32.hpp"
#endif
#include "CXODCF01.hpp"
#ifndef CXOSST88_h
#include "CXODST88.hpp"
#endif
//## end module%41B4878C03D8.includes

#ifndef CXOSDB02_h
#include "CXODDB02.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSTM03_h
#include "CXODTM03.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSRU12_h
#include "CXODRU12.hpp"
#endif
#ifndef CXOSDB26_h
#include "CXODDB26.hpp"
#endif
#ifndef CXODDF01_h
#include "CXODDF01.hpp"
#endif
#ifndef CXOSRU08_h
#include "CXODRU08.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSEX17_h
#include "CXODEX17.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU10_h
#include "CXODRU10.hpp"
#endif
#ifndef CXOSDB08_h
#include "CXODDB08.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSDZ04_h
#include "CXODDZ04.hpp"
#endif
#ifndef CXOSDZ03_h
#include "CXODDZ03.hpp"
#endif
#ifndef CXOSPF01_h
#include "CXODPF01.hpp"
#endif
#ifndef CXOSNS40_h
#include "CXODNS40.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSDB16_h
#include "CXODDB16.hpp"
#endif
#ifndef CXOSDB27_h
#include "CXODDB27.hpp"
#endif
#ifndef CXOSDB50_h
#include "CXODDB50.hpp"
#endif
#ifndef CXOSNR12_h
#include "CXODNR12.hpp"
#endif
#ifndef CXOSNS44_h
#include "CXODNS44.hpp"
#endif
#ifndef CXOSPF38_h
#include "CXODPF38.hpp"
#endif
#ifndef CXOSTC66_h
#include "CXODTC66.hpp"
#endif
#ifndef CXOSTC46_h
#include "CXODTC46.hpp"
#endif
#ifndef CXOSEX88_h
#include "CXODEX88.hpp"
#endif
#ifndef CXOPDF00_h
#include "CXODDF00.hpp"
#endif


//## begin module%41B4878C03D8.declarations preserve=no
//## end module%41B4878C03D8.declarations

//## begin module%41B4878C03D8.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new DataFormatter();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
#define WALL 0
#define SWITCH 1
#define ALL 2
//## end module%41B4878C03D8.additionalDeclarations


// Class DataFormatter 

DataFormatter::DataFormatter()
  //## begin DataFormatter::DataFormatter%41B47F0003B9_const.hasinit preserve=no
      : m_iDX_FILE_ID(0),
        m_pExportFile(0),
        m_lEXPORT_RETRY_COUNT(0),
        m_pTroller(0)
  //## end DataFormatter::DataFormatter%41B47F0003B9_const.hasinit
  //## begin DataFormatter::DataFormatter%41B47F0003B9_const.initialization preserve=yes
  //## end DataFormatter::DataFormatter%41B47F0003B9_const.initialization
{
  //## begin DataFormatter::DataFormatter%41B47F0003B9_const.body preserve=yes
   memcpy(m_sID,"DF00",4);
   m_hQuery[0].attach(this);
  //## end DataFormatter::DataFormatter%41B47F0003B9_const.body
}


DataFormatter::~DataFormatter()
{
  //## begin DataFormatter::~DataFormatter%41B47F0003B9_dest.body preserve=yes
   delete m_pTroller;
   delete m_pExportFile;
  //## end DataFormatter::~DataFormatter%41B47F0003B9_dest.body
}



//## Other Operations (implementation)
void DataFormatter::cleanUp ()
{
  //## begin DataFormatter::cleanUp%422CBF5F0000.body preserve=yes
  //## end DataFormatter::cleanUp%422CBF5F0000.body
}

int DataFormatter::initialize ()
{
  //## begin DataFormatter::initialize%41B49F2D003E.body preserve=yes
   new dnplatform::DNPlatform();
   int i = Application::initialize();
   UseCase hUseCase("DIST","## DT01 START DF");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   database::DataModel::instance();
   database::CRTransactionTypeIndicator::instance();
   Customer::instance();
   postingfile::Reports::instance();
   entitysegment::SwitchBusinessDay::instance();
   networkreconciliation::TotalType::instance();
   entitysegment::Processor::instance();
   new ExportFileFactory();
   totalscommand::DirectRoute::instance();
   if (Extract::instance()->getCustomCode() == "UAES")
      ems::FeeTable::instance();
   Database::instance()->attach(this);
   Database::instance()->connect();
   TotalsVersionMonitor::instance();
   string strCustomer;
   Extract::instance()->getSpec("CUSTOMER",strCustomer);
   Transaction::instance()->setCustomer(strCustomer);
   Transaction::instance()->begin();
   Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   EMSRulesEngine::instance();
   DataControl::instance();
   new ExceptionFactory();
   new dnplatform::NetworkFactory();
   string strRecord;
   if (Extract::instance()->getRecord("DFILES  TROLLE  ",strRecord))
      m_pTroller = new totalscommand::Troller();
   if (entitysegment::Customer::instance()->getTotalsVersion() == 2)
      new totalscommand::FinancialSum;
   string strFirst("PRC001");
   string strSecond;
   ConfigurationRepository::instance()->translate("PROCESSOR",strFirst,strSecond,"","",0,false);
   return 0;
  //## end DataFormatter::initialize%41B49F2D003E.body
}

int DataFormatter::onResume (Message& hMessage)
{
  //## begin DataFormatter::onResume%450850870213.body preserve=yes
   process();
   return 0;
  //## end DataFormatter::onResume%450850870213.body
}

void DataFormatter::process ()
{
  //## begin DataFormatter::process%4242CF660128.body preserve=yes
   UseCase hUseCase("DIST","## DT08 FORMAT FILE");
   SwitchClock::instance()->update(0);
   if (entitysegment::SwitchBusinessDay::instance()->isRolled() == false)
   {
      setQueueWaitOption(true);
      return;
   }
   m_hQuery[0].reset();
   m_pExportFile->bind(m_hQuery[0]);
   string strTASK_FORMATTED("(' ','");
   strTASK_FORMATTED.append(Application::instance()->name());
   strTASK_FORMATTED.append("')");
   m_hQuery[0].bind("DX_DATA_CONTROL","EXPORT_RETRY_COUNT",reusable::Column::LONG,&m_lEXPORT_RETRY_COUNT);
   m_hQuery[0].getSearchCondition().append("(");
   string strTemp("('FW','FI')");
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","DX_STATE","IN",strTemp.c_str());
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","TASK_FORMATTED","IN",strTASK_FORMATTED.c_str());
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","TSTAMP_INITIATED","<",Clock::instance()->getYYYYMMDDHHMMSSHN().c_str());
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","IN",ExportFileFactory::instance()->getClockFiles(WALL).c_str());
   m_hQuery[0].getSearchCondition().append(") OR (");
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","DX_STATE","=","FW");
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","TSTAMP_INITIATED","<=",SwitchClock::instance()->getYYYYMMDDHHMMSSHN().c_str());
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","IN",ExportFileFactory::instance()->getClockFiles(SWITCH).c_str());
   m_hQuery[0].getSearchCondition().append(") OR (");
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","DX_STATE","=","FW");
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","TSTAMP_INITIATED","<=",SwitchClock::instance()->getYYYYMMDDHHMMSSHN().c_str());
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","LIKE","MIS%");
   m_hQuery[0].getSearchCondition().append(") OR (");
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","DX_STATE","=","FW");
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","TSTAMP_INITIATED","<=",SwitchClock::instance()->getYYYYMMDDHHMMSSHN().c_str());
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","LIKE","MIC%");
   m_hQuery[0].getSearchCondition().append(") OR (");
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","DX_STATE","=","FE");
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","TSTAMP_NEXT_EXPORT","<",Clock::instance()->getYYYYMMDDHHMMSSHN().c_str());
   m_hQuery[0].setBasicPredicate("DX_DATA_CONTROL","DX_FILE_TYPE","IN",ExportFileFactory::instance()->getClockFiles(ALL).c_str());
   m_hQuery[0].getSearchCondition().append(")");
   m_hQuery[0].setOrderByClause("DATE_RECON ASC,TSTAMP_INITIATED ASC");
   {
      auto_ptr<SelectStatement> pSelectStatement((SelectStatement*)DatabaseFactory::instance()->create("SelectStatement"));
      if (pSelectStatement->execute(m_hQuery[0]) == false 
         || pSelectStatement->getRows() == 0)
      {
         Database::instance()->commit();
         setQueueWaitOption(true);
         return;
      }
   }
   Transaction::instance()->begin();
   Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   m_pExportFile->setDX_STATE("FI");
   if (!updateProgress(m_pExportFile->getDX_FILE_ID(),"FI",Clock::instance()->getYYYYMMDDHHMMSSHN()))
   {
      UseCase::setSuccess(false);
      setQueueWaitOption(true);
      Transaction::instance()->rollback();
      return;
   }
   ExportFile* pExportFile = ExportFileFactory::instance()->create(*m_pExportFile);
   if (pExportFile
      && pExportFile->erase()
      && pExportFile->create()) 
   {
      UseCase::addItem();
      pExportFile->setTSTAMP_FORMATTED(Clock::instance()->getYYYYMMDDHHMMSSHN());
      UseCase::setSuccess(pExportFile->close());
      Database::instance()->commit();
   }
   else
   {
      Database::instance()->rollback();
      Transaction::instance()->rollback();
      updateProgress(m_pExportFile->getDX_FILE_ID(),"FE",Clock::instance()->getYYYYMMDDHHMMSSHN());
      UseCase::setSuccess(false);
      setQueueWaitOption(true);
   }
   delete pExportFile;
   Transaction::instance()->commit();
  //## end DataFormatter::process%4242CF660128.body
}

void DataFormatter::update (Subject* pSubject)
{
  //## begin DataFormatter::update%41B49F2D004E.body preserve=yes
   if (pSubject == &m_hQuery[0])
   {
      m_hQuery[0].setAbort(true);
      return;
   }
   else
   if (pSubject == Database::instance()
      && Database::instance()->state() == Database::CONNECTED)
   {
      if (m_pExportFile == 0)
         m_pExportFile = new ExportFile();
      MinuteTimer::instance()->attach(this);
   }
   else
   if (pSubject == MinuteTimer::instance()
      && Database::instance()->state() == Database::CONNECTED)
   {
      setQueueWaitOption(false);
      process();
   }
   Application::update(pSubject);
  //## end DataFormatter::update%41B49F2D004E.body
}

bool DataFormatter::updateProgress (int iDX_FILE_ID, const char* pszDX_STATE, const string& strTSTAMP_FORMATTED)
{
  //## begin DataFormatter::updateProgress%422CBB09007D.body preserve=yes
   Table hTable("DX_DATA_CONTROL");
   hTable.set("DX_FILE_ID",iDX_FILE_ID,true);
   string strDX_STATE(pszDX_STATE);
   hTable.set("DX_STATE",strDX_STATE);
   hTable.set("TASK_FORMATTED",Application::instance()->name());
   hTable.set("TSTAMP_FORMATTED",strTSTAMP_FORMATTED);
   if (strDX_STATE == "FE")
   {
      //set RETRY_TSTAMP to GMT time + 1 hour and bump retry count
      reusable::IString strYYYYMMDDHHMMSShh = Clock::instance()->getYYYYMMDDHHMMSSHN().c_str();
      DateTime hDateTime;
      hDateTime.timeAdjust(strYYYYMMDDHHMMSShh,15);
      hTable.set("TSTAMP_NEXT_EXPORT",string((char*)strYYYYMMDDHHMMSShh));
      hTable.set("EXPORT_RETRY_COUNT",++m_lEXPORT_RETRY_COUNT);
   }
   else
   if (strDX_STATE == "DW")
      hTable.set("EXPORT_RETRY_COUNT",(int)0); // reset count for distributor
   auto_ptr<Statement> pUpdateStatement((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   if (!pUpdateStatement->execute(hTable))
   {
      Database::instance()->rollback();
      return UseCase::setSuccess(false);
   }
   Database::instance()->commit();
   return UseCase::setSuccess(true);
  //## end DataFormatter::updateProgress%422CBB09007D.body
}

int DataFormatter::onReset (Message& hMessage)
{
  //## begin DataFormatter::onReset%4962158C01BD.body preserve=yes
   Transaction::instance()->begin();
   Transaction::instance()->setTimeStamp(Clock::instance()->getYYYYMMDDHHMMSSHN(true));
   if (hMessage.context().length() >= 9
      && memcmp((char*)hMessage.context(),"TRIGGER-",8) == 0)
   {
      int iDX_FILE_ID = atoi((char*)hMessage.context().subString(9));
      if (trigger(iDX_FILE_ID))
      {
         char szTemp[48];
         snprintf(szTemp,sizeof(szTemp),"TRIGGERING IS SUCCESSFUL FOR FILE ID : %d",iDX_FILE_ID); 
         Console::display("CX000",szTemp);
      }
   }
   else
   if (hMessage.context().length() >= 6
      && memcmp((char*)hMessage.context(),"HOLD-",5) == 0)
   {
      int iDX_FILE_ID = atoi((char*)hMessage.context().subString(6));
      if (putOnHold(iDX_FILE_ID))
      {
         char szTemp[64];
         snprintf(szTemp,sizeof(szTemp),"HOLD SUCCESSFUL FOR FILE ID : %d",iDX_FILE_ID); 
         Console::display("CX000",szTemp);
      }
   }   
   Database::instance()->commit();
   updateConsole();
   return 0;
  //## end DataFormatter::onReset%4962158C01BD.body
}

bool DataFormatter::trigger (int iDX_FILE_ID)
{
  //## begin DataFormatter::trigger%496215CA0383.body preserve=yes
   string strSWITCH_CLOCK;
   auto_ptr<GlobalContext> pGlobalContext(new GlobalContext("SWITCH CLOCK"));
   pGlobalContext->get(strSWITCH_CLOCK);
   if (strSWITCH_CLOCK.length() == 0)
      strSWITCH_CLOCK = Clock::instance()->getYYYYMMDDHHMMSSHN();
   Table hTable("DX_DATA_CONTROL");
   hTable.set("TSTAMP_INITIATED",strSWITCH_CLOCK.c_str());
   hTable.set("DX_STATE","FW");
   hTable.set("TASK_FORMATTED"," ");
   hTable.set("TSTAMP_FORMATTED"," ");
   hTable.set("EXPORT_RETRY_COUNT",0);
   hTable.set("DX_FILE_ID",iDX_FILE_ID,true);
   auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   return pUpdateStatement->execute(hTable);
  //## end DataFormatter::trigger%496215CA0383.body
}

bool DataFormatter::putOnHold (int iDX_FILE_ID)
{
  //## begin DataFormatter::putOnHold%496215F90307.body preserve=yes
   Table hTable("DX_DATA_CONTROL");
   hTable.set("TSTAMP_INITIATED","9999123123595999");
   hTable.set("DX_FILE_ID",iDX_FILE_ID,true);
   auto_ptr<Statement> pUpdateStatement ((Statement*)DatabaseFactory::instance()->create("UpdateStatement"));
   return pUpdateStatement->execute(hTable);
  //## end DataFormatter::putOnHold%496215F90307.body
}

// Additional Declarations
  //## begin DataFormatter%41B47F0003B9.declarations preserve=yes
  //## end DataFormatter%41B47F0003B9.declarations

//## begin module%41B4878C03D8.epilog preserve=yes
//## end module%41B4878C03D8.epilog
