//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41EC3C9C037A.cm preserve=no
//	$Date:   Sep 22 2021 04:38:42  $ $Author:   e5627846  $
//	$Revision:   1.61  $
//## end module%41EC3C9C037A.cm

//## begin module%41EC3C9C037A.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%41EC3C9C037A.cp

//## Module: CXODDF01%41EC3C9C037A; Package specification
//## Subsystem: DF%41A351850261
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Df\CXODDF01.hpp

#ifndef CXODDF01_h
#define CXODDF01_h 1

//## begin module%41EC3C9C037A.additionalIncludes preserve=no
//## end module%41EC3C9C037A.additionalIncludes

//## begin module%41EC3C9C037A.includes preserve=yes
//## end module%41EC3C9C037A.includes

#ifndef CXOSDB26_h
#include "CXODDB26.hpp"
#endif

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class MasterCardFraudActivityFile;
class VisaFraudActivityFile;
class CaseTransitionActivityFile;
class AdjustmentPosting;
class AccountFile;
} // namespace ems

//## Modelname: Transaction Research and Adjustments::VisaException_CAT%4097A16101D4
namespace visaexception {
class VisaExceptionExport;
} // namespace visaexception

//## Modelname: Transaction Research and Adjustments::MasterCardException_CAT%4242FC56001F
namespace mastercardexception {
class MasterComProExport;
class IPMExceptionExport;
class MasterCardExceptionExport;
class SAFEExportFile;
} // namespace mastercardexception

//## Modelname: Transaction Research and Adjustments::GenericException_CAT%4ADF1B4C003E
namespace genericexception {
class BulkSIUploadRequestPackage;
class BulkSIUploadRequestBatchDescriptor;
} // namespace genericexception

//## Modelname: Transaction Research and Adjustments::PulseException_CAT%481B74D302AF
namespace pulseexception {
class PulseExport;
} // namespace pulseexception

//## Modelname: Transaction Research and Adjustments::ZappException_CAT%52B9AF58018F
namespace zapp {
class CaseZappActivityFile;
} // namespace zapp

//## Modelname: Transaction Research and Adjustments::NyceException_CAT%55BF69210380
namespace nyceexception {
class NYCEExport;
} // namespace nyceexception

//## Modelname: Transaction Research and Adjustments::ExceptionFile_CAT%516E8CC70289
namespace exceptionfile {
class ExceptionBillingFile; 
class TIBillingFile;
class MCBSBillingFile; 
class Billing;
class PrepaidExceptionBillingFile;
class PrepaidBillingFile;
} // namespace exceptionfile

//## Modelname: Totals Management::TotalsCommand_CAT%3884FA670353
namespace totalscommand {
class ATMGeneralLedgerFile;
class InstitutionGeneralLedgerFile;
class LMDetailSettlementPosition;
class ZeroTerminalActivityFile;
class MonthlyFeeFile;
class LinkDetailSettlementPosition;
class FinancialSettlementFile;
} // namespace totalscommand

//## Modelname: Totals Management::ManagementInformation_CAT%440DDD48031C
namespace managementinformation {
class PaymentSummary;
class ChargebackReport;
class InterchangeDowngradeReport;
class InterchangeFeeReport;
class CardBrand;
class PaymentRange;
class CardActivity;
class NetworkSales;
class ChannelTransactions;
class ManagementTotals;
} // namespace managementinformation

namespace totalscommand {
class ActivityByInterchangeFile; 
class FinancialSummaryFile;  
class FinancialDetailFile; 
class MerchantControlFile; 
class AcquirerSurchargeActivityReport;  
class FinancialDetailFile2;
class FinancialDetailFile1;
class FinancialSummaryFile2;    
class FinancialSummaryFile1;
class TransfundATMReport;  
class TerminalCashBalance;
class CardholderForeignItemsAnalysis;
class TerminalForeignItemsAnalysis;
class ActivityByInterchangeFile2;
class ActivityByInterchangeFile1;
class DailyTotalsRecap;
class MerchantRevenue;
} // namespace totalscommand

namespace managementinformation {
class FinancialBillingFile;  
class FinancialTotalsReport;  
class LCPLCombinedFeeReport;
class LCPLSwitchFeeReport;
class PaymentRangeByTranClass;
class AuditEventFile;
class TransactionSummaryReport;
class ElectronicJournalExport;
class UnmatchedReport;
class CombinedReconciliationReport;
class SwitchFeeReport;
class ATMInterchangeFee;
class InterchangeTransferFee;
class FeeBilling;
class ExceptionReport;
class AVSReport;
} // namespace managementinformation

//## Modelname: Device Management::ManagementCommand_CAT%3A06C995022A
namespace managementcommand {
class SunCoastDepositExport;
class CheckDepositExport;
class BalanceSheetFile;
class DepositExport;
} // namespace managementcommand

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::RepositoryCommand_CAT%394E267C0078
namespace repositorycommand {
class AuditMaintenanceActivity;
} // namespace repositorycommand

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class BarTime;
} // namespace timer

//## Modelname: Reconciliation::NetworkReconciliation_CAT%5637978002B1
namespace networkreconciliation {
class OpenItemWorksheet;  
class NetworkDisputeWorksheet;  
class NetworkFeeWorksheet;  
class VisaVSS900ExportFile;
class VisaVSS130ExportFile;
class InterchangeWorksheet;  
class VisaSMS601ExportFile;
class DiscoverExportFile;
class MasterCardT884ExportFile;  
class BalanceSheet;  
class NetworkWorksheet;  
class MerchantWorksheet; 
} // namespace networkreconciliation

//## Modelname: Reconciliation::ReconciliationFile_CAT%439754C1037A
namespace reconciliationfile {
class AutoAdjustment;
class CounterParty;
} // namespace reconciliationfile

//## Modelname: Data Distribution::PostingFile_CAT%41E951230177
namespace postingfile {
class CaseReplicationExport;
class CaseReportFile;  
class CaseHistoryExport; 
class ExceptionActivityFile;
} // namespace postingfile

//## Modelname: Platform \: Bank Of America::BankOfAmericaProcessing_CAT%4421791802DE
namespace bamsprocessing {
class ChesapeakeExport;  
class BAMSExport;  
} // namespace bamsprocessing

//## Modelname: Platform \: Regions::RegionsAPI%49C79DB0002E
namespace regionsapi {
class BulkPrintExportFile;

} // namespace regionsapi

//## begin module%41EC3C9C037A.declarations preserve=no
//## end module%41EC3C9C037A.declarations

//## begin module%41EC3C9C037A.additionalDeclarations preserve=yes
//## end module%41EC3C9C037A.additionalDeclarations


//## begin ExportFileFactory%41E973D2035B.preface preserve=yes
//## end ExportFileFactory%41E973D2035B.preface

//## Class: ExportFileFactory%41E973D2035B
//## Category: Data Distribution::DataFormatter_CAT (DF)%41A35057001F
//## Subsystem: DF%41A351850261
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%4235C7F8034B;managementcommand::DepositExport { -> F}
//## Uses: <unnamed>%430A26FA0222;managementcommand::BalanceSheetFile { -> F}
//## Uses: <unnamed>%430B76FD004E;monitor::UseCase { -> F}
//## Uses: <unnamed>%434BD0C800B6;postingfile::ExceptionActivityFile { -> F}
//## Uses: <unnamed>%43B44287031C;managementinformation::ManagementTotals { -> F}
//## Uses: <unnamed>%441095E9033C;managementinformation::ChannelTransactions { -> F}
//## Uses: <unnamed>%441095EB02BF;managementinformation::NetworkSales { -> F}
//## Uses: <unnamed>%4469E4C2004E;totalscommand::FinancialSettlementFile { -> F}
//## Uses: <unnamed>%44D2DB89034F;managementinformation::AVSReport { -> F}
//## Uses: <unnamed>%44E2333F0000;managementinformation::CardActivity { -> F}
//## Uses: <unnamed>%44E2336A006D;managementinformation::PaymentRange { -> F}
//## Uses: <unnamed>%44E23394038A;managementinformation::CardBrand { -> F}
//## Uses: <unnamed>%44E233B7030D;managementinformation::PaymentSummary { -> F}
//## Uses: <unnamed>%4506B58D016A;totalscommand::LinkDetailSettlementPosition { -> F}
//## Uses: <unnamed>%453D116F0000;managementinformation::InterchangeFeeReport { -> F}
//## Uses: <unnamed>%453D11700186;managementinformation::InterchangeDowngradeReport { -> F}
//## Uses: <unnamed>%453D117102DE;managementinformation::ChargebackReport { -> F}
//## Uses: <unnamed>%453D11850138;managementinformation::ExceptionReport { -> F}
//## Uses: <unnamed>%45AB855500EA;totalscommand::MonthlyFeeFile { -> F}
//## Uses: <unnamed>%45C199E60152;ems::AdjustmentPosting { -> F}
//## Uses: <unnamed>%45E34D8B01D3;visaexception::VisaExceptionExport { -> F}
//## Uses: <unnamed>%46A712DC0164;totalscommand::ZeroTerminalActivityFile { -> F}
//## Uses: <unnamed>%470CA631029A;mastercardexception::SAFEExportFile { -> F}
//## Uses: <unnamed>%47599525015D;managementinformation::ATMInterchangeFee { -> F}
//## Uses: <unnamed>%47599527021E;managementinformation::InterchangeTransferFee { -> F}
//## Uses: <unnamed>%47599529028F;managementinformation::SwitchFeeReport { -> F}
//## Uses: <unnamed>%47B52967037A;mastercardexception::MasterCardExceptionExport { -> F}
//## Uses: <unnamed>%47CED76C03E0;managementinformation::CombinedReconciliationReport { -> F}
//## Uses: <unnamed>%47CED771001C;managementinformation::UnmatchedReport { -> F}
//## Uses: <unnamed>%47F22EF5038D;managementcommand::CheckDepositExport { -> F}
//## Uses: <unnamed>%48204E7E007D;pulseexception::PulseExport { -> F}
//## Uses: <unnamed>%48914C69038A;reconciliationfile::AutoAdjustment { -> F}
//## Uses: <unnamed>%48CE35F503B5;totalscommand::LMDetailSettlementPosition { -> F}
//## Uses: <unnamed>%48CE362D01DB;managementinformation::ElectronicJournalExport { -> F}
//## Uses: <unnamed>%4B7AF0CF0338;genericexception::BulkSIUploadRequestBatchDescriptor { -> F}
//## Uses: <unnamed>%4B7AF0D203D4;genericexception::BulkSIUploadRequestPackage { -> F}
//## Uses: <unnamed>%4B7B2C170366;ems::CaseTransitionActivityFile { -> F}
//## Uses: <unnamed>%4B7B2DB70126;genericexception::BulkSIUploadRequestBatchDescriptor { -> F}
//## Uses: <unnamed>%4B7B2DF201D0;genericexception::BulkSIUploadRequestPackage { -> F}
//## Uses: <unnamed>%4D1858020283;managementcommand::SunCoastDepositExport { -> F}
//## Uses: <unnamed>%4E4CFEEE0321;totalscommand::InstitutionGeneralLedgerFile { -> F}
//## Uses: <unnamed>%4E4D13EA015D;totalscommand::ATMGeneralLedgerFile { -> F}
//## Uses: <unnamed>%4F46613D012B;ems::VisaFraudActivityFile { -> F}
//## Uses: <unnamed>%4F46617B0207;ems::MasterCardFraudActivityFile { -> F}
//## Uses: <unnamed>%4F6B57770184;postingfile::CaseHistoryExport { -> F}
//## Uses: <unnamed>%4F6B577901D3;postingfile::CaseReplicationExport { -> F}
//## Uses: <unnamed>%517137200139;exceptionfile::PrepaidBillingFile { -> F}
//## Uses: <unnamed>%519363D002AB;managementinformation::TransactionSummaryReport { -> F}
//## Uses: <unnamed>%51B0A0B302D9;mastercardexception::IPMExceptionExport { -> F}
//## Uses: <unnamed>%52EB8B9A0021;managementinformation::PaymentRangeByTranClass { -> F}
//## Uses: <unnamed>%52EF99FD0397;mastercardexception::MasterComProExport { -> F}
//## Uses: <unnamed>%53E51C030371;exceptionfile::PrepaidExceptionBillingFile { -> F}
//## Uses: <unnamed>%558909E103AF;managementinformation::LCPLCombinedFeeReport { -> F}
//## Uses: <unnamed>%558909E6002E;managementinformation::LCPLSwitchFeeReport { -> F}
//## Uses: <unnamed>%55A6625B0081;timer::BarTime { -> F}
//## Uses: <unnamed>%55A663AC00ED;IF::Extract { -> F}
//## Uses: <unnamed>%55A663FD0032;zapp::CaseZappActivityFile { -> F}
//## Uses: <unnamed>%55A66418029F;managementinformation::AuditEventFile { -> F}
//## Uses: <unnamed>%55A6643400D4;regionsapi::BulkPrintExportFile { -> F}
//## Uses: <unnamed>%55A6644F029F;repositorycommand::AuditMaintenanceActivity { -> F}
//## Uses: <unnamed>%5683BB0000B3;nyceexception::NYCEExport { -> F}
//## Uses: <unnamed>%568509AE0055;exceptionfile::Billing { -> F}
//## Uses: <unnamed>%56A699F900A1;reconciliationfile::CounterParty { -> F}
//## Uses: <unnamed>%56A78723003D;managementinformation::FeeBilling { -> F}
//## Uses: <unnamed>%56E6B033018F;networkreconciliation::DiscoverExportFile { -> F}
//## Uses: <unnamed>%571E2DB501D8;networkreconciliation::VisaVSS130ExportFile { -> F}
//## Uses: <unnamed>%571E405F0260;networkreconciliation::VisaSMS601ExportFile { -> F}
//## Uses: <unnamed>%571F66FB009E;networkreconciliation::VisaVSS900ExportFile { -> F}
//## Uses: <unnamed>%576AD87D0014;totalscommand::MerchantRevenue { -> F}
//## Uses: <unnamed>%5CC85C5C00E4;totalscommand::ActivityByInterchangeFile1 { -> F}
//## Uses: <unnamed>%5CC85C61003B;totalscommand::ActivityByInterchangeFile2 { -> F}
//## Uses: <unnamed>%5CC85D580395;entitysegment::Customer { -> F}
//## Uses: <unnamed>%5CC85DEB033C;exceptionfile::TIBillingFile { -> F}
//## Uses: <unnamed>%5CEEEDA0025E;totalscommand::DailyTotalsRecap { -> F}
//## Uses: <unnamed>%5DB90014013B;totalscommand::TerminalForeignItemsAnalysis { -> F}
//## Uses: <unnamed>%5DD6B7110149;totalscommand::CardholderForeignItemsAnalysis { -> F}
//## Uses: <unnamed>%5DE6800C0000;totalscommand::TerminalCashBalance { -> F}
//## Uses: <unnamed>%5E4D913402EE;totalscommand::FinancialSummaryFile1 { -> F}
//## Uses: <unnamed>%5E4D91380145;totalscommand::FinancialSummaryFile2 { -> F}
//## Uses: <unnamed>%5E56C2FF02C5;totalscommand::FinancialDetailFile2 { -> F}
//## Uses: <unnamed>%5E56C30202EE;totalscommand::FinancialDetailFile1 { -> F}

class ExportFileFactory : public database::FileFactory  //## Inherits: <unnamed>%41E973F6038A
{
  //## begin ExportFileFactory%41E973D2035B.initialDeclarations preserve=yes
  //## end ExportFileFactory%41E973D2035B.initialDeclarations

  public:
    //## Constructors (generated)
      ExportFileFactory();

    //## Destructor (generated)
      virtual ~ExportFileFactory();


    //## Other Operations (specified)
      //## Operation: adjustDate%4F79C43A0397
      virtual void adjustDate (timer::Date& hDate);

      //## Operation: create%41E97F92003E
      virtual ExportFile* create (const ExportFile& hExportFile);

    // Additional Public Declarations
      //## begin ExportFileFactory%41E973D2035B.public preserve=yes
      //## end ExportFileFactory%41E973D2035B.public

  protected:
    // Additional Protected Declarations
      //## begin ExportFileFactory%41E973D2035B.protected preserve=yes
      //## end ExportFileFactory%41E973D2035B.protected

  private:
    // Additional Private Declarations
      //## begin ExportFileFactory%41E973D2035B.private preserve=yes
      //## end ExportFileFactory%41E973D2035B.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin ExportFileFactory%41E973D2035B.implementation preserve=yes
      //## end ExportFileFactory%41E973D2035B.implementation

};

//## begin ExportFileFactory%41E973D2035B.postscript preserve=yes
//## end ExportFileFactory%41E973D2035B.postscript

//## begin module%41EC3C9C037A.epilog preserve=yes
//## end module%41EC3C9C037A.epilog


#endif
