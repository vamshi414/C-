//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41B4878A033C.cm preserve=no
//	$Date:   Apr 27 2020 15:45:14  $ $Author:   e1009839  $
//	$Revision:   1.22  $
//## end module%41B4878A033C.cm

//## begin module%41B4878A033C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%41B4878A033C.cp

//## Module: CXOPDF00%41B4878A033C; Package specification
//## Subsystem: DF%41A351850261
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Df\CXODDF00.hpp

#ifndef CXOPDF00_h
#define CXOPDF00_h 1

//## begin module%41B4878A033C.additionalIncludes preserve=no
//## end module%41B4878A033C.additionalIncludes

//## begin module%41B4878A033C.includes preserve=yes
//## end module%41B4878A033C.includes

#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Processor;
} // namespace entitysegment

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class SelectStatement;
} // namespace reusable

//## Modelname: Transaction Research and Adjustments::Exception_CAT%3742E65B0185
namespace ems {
class EMSRulesEngine;
} // namespace ems

//## Modelname: Totals Management::TotalsCommand_CAT%3884FA670353
namespace totalscommand {
class Troller;
class FinancialSum;
} // namespace totalscommand

namespace entitysegment {
class SwitchBusinessDay;
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class NetworkFactory;
class ExceptionFactory;
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class DateTime;
} // namespace IF

namespace reusable {
class Transaction;
class Statement;
} // namespace reusable

namespace IF {
class Trace;
class Extract;
class Console;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MidnightAlarm;
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class FileFactory;
class ExportFile;
class CRTransactionTypeIndicator;
class DatabaseFactory;
class SwitchClock;
class DataControl;
class DataModel;
} // namespace database

//## Modelname: Reconciliation::NetworkReconciliation_CAT%5637978002B1
namespace networkreconciliation {
class TotalType;
} // namespace networkreconciliation

class ExportFileFactory;
//## Modelname: Data Distribution::PostingFile_CAT%41E951230177
namespace postingfile {
class PostingFileFactory;
class Reports;

} // namespace postingfile

//## begin module%41B4878A033C.declarations preserve=no
//## end module%41B4878A033C.declarations

//## begin module%41B4878A033C.additionalDeclarations preserve=yes
//## end module%41B4878A033C.additionalDeclarations


//## begin DataFormatter%41B47F0003B9.preface preserve=yes
//## end DataFormatter%41B47F0003B9.preface

//## Class: DataFormatter%41B47F0003B9
//	<body>
//	<title>CG
//	<h1>DF
//	<h2>AB
//	<!-- DataFormatter : General-->
//	<h3>System Flow
//	<p>
//	The DataNavigator server provides export files to your
//	back office systems and external endpoints.
//	The File Formatter service produces the following result
//	sets:
//	<ul>
//	<li>ATM Balancing Summary
//	<li>ATM Deposit Activity
//	<li>ATM Electronic Journal
//	<li>ATM General Ledger Posting
//	<li>Bank Of America Exception Export
//	<li>Billing Feed
//	<li><a href="Card Association Reconciliation
//	Worksheet.html">Card Association Reconciliation
//	Worksheet</a>
//	<li><a href="Card Association Balancing
//	Worksheet.html">Card Association Balancing Worksheet</a>
//	<li>EMS Document Bulk Print
//	<li>Exception Item Accounting
//	<li>Financial Business Day Detail
//	<li>Financial Business Day Summary
//	<li><a href="Interchange Comparison
//	Worksheet.html">Interchange Comparison Worksheet</a>
//	<li><a href="Interchange Profitability
//	Worksheet.html">Interchange Profitability Worksheet</a>
//	<li>Mastercard SAFE
//	<li>Merchant Accounting Export
//	<li><a href="Merchant Reconciliation
//	Worksheet.html">Merchant Reconciliation Worksheet</a>
//	<li>MIS Totals
//	<li>Pulse Exception Export
//	<li>Totals by Interchange
//	<li>VISA VROL Bulk SI Upload
//	</ul>
//	<p>
//	The File Formatter service (<i>ca</i>DF01) retrieves
//	data from the transaction, totals and exception tables
//	and generates formatted result sets in the Data
//	Distribution tables (DX_DATA_CONTROL and DX_DATA_
//	<i>yyyymmdd</i>).
//	These result sets are then copied to physical datasets
//	by the File Distributor service (<i>ca</i>DT01).
//	<p>
//	<img src=CXOCDF00.gif>
//	</p>
//	</body>
//	<body>
//	<title>OG
//	<h1>DF
//	<h2>AB
//	<h3>System Flow
//	<p>
//	The DataNavigator server provides export files to
//	external systems and endpoints.
//	</p>
//	<img src=CXOODF00.gif>
//	</p>
//	</body>
//## Category: Data Distribution::DataFormatter_CAT (DF)%41A35057001F
//## Subsystem: DF%41A351850261
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%41B49F920213;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%41B49F9402AF;IF::Message { -> F}
//## Uses: <unnamed>%41B49F970109;timer::MidnightAlarm { -> F}
//## Uses: <unnamed>%41B49F9A029F;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%41DAC9FB02FD;database::ExportFile { -> F}
//## Uses: <unnamed>%41DAD73B0203;monitor::UseCase { -> F}
//## Uses: <unnamed>%41DAE3A103D8;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%41DAF160002E;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%41EC427F033C;database::FileFactory { -> F}
//## Uses: <unnamed>%41EC42A500BB;ExportFileFactory { -> F}
//## Uses: <unnamed>%422CC019036B;reusable::Statement { -> F}
//## Uses: <unnamed>%422CC047005D;IF::DateTime { -> F}
//## Uses: <unnamed>%42418C6701C5;IF::Trace { -> F}
//## Uses: <unnamed>%444540600203;ems::EMSRulesEngine { -> F}
//## Uses: <unnamed>%4446517F005D;IF::Extract { -> F}
//## Uses: <unnamed>%4446518E0138;reusable::Transaction { -> F}
//## Uses: <unnamed>%4480560D02DE;database::SwitchClock { -> F}
//## Uses: <unnamed>%49621A9202FD;IF::Console { -> F}
//## Uses: <unnamed>%4B6335320377;dnplatform::NetworkFactory { -> F}
//## Uses: <unnamed>%4B63353500A9;dnplatform::ExceptionFactory { -> F}
//## Uses: <unnamed>%4F69FC06028E;postingfile::PostingFileFactory { -> F}
//## Uses: <unnamed>%5C1A45C803C4;entitysegment::SwitchBusinessDay { -> F}
//## Uses: <unnamed>%5C1A45EA0014;entitysegment::Customer { -> F}
//## Uses: <unnamed>%5C1A46040103;database::CRTransactionTypeIndicator { -> F}
//## Uses: <unnamed>%5C1A46310004;database::DataControl { -> F}
//## Uses: <unnamed>%5C1A46470333;database::DataModel { -> F}
//## Uses: <unnamed>%5C1A467601F4;networkreconciliation::TotalType { -> F}
//## Uses: <unnamed>%5E94D9BD02A7;entitysegment::Processor { -> F}
//## Uses: <unnamed>%5E94DA020270;postingfile::Reports { -> F}
//## Uses: <unnamed>%5E94DA1D0019;totalscommand::FinancialSum { -> F}

class DataFormatter : public process::Application  //## Inherits: <unnamed>%41B47F6C0251
{
  //## begin DataFormatter%41B47F0003B9.initialDeclarations preserve=yes
  //## end DataFormatter%41B47F0003B9.initialDeclarations

  public:
    //## Constructors (generated)
      DataFormatter();

    //## Destructor (generated)
      virtual ~DataFormatter();


    //## Other Operations (specified)
      //## Operation: initialize%41B49F2D003E
      virtual int initialize ();

      //## Operation: update%41B49F2D004E
      virtual void update (Subject* pSubject);

      //## Operation: trigger%496215CA0383
      bool trigger (int iDX_FILE_ID);

      //## Operation: putOnHold%496215F90307
      bool putOnHold (int iDX_FILE_ID);

    // Additional Public Declarations
      //## begin DataFormatter%41B47F0003B9.public preserve=yes
      //## end DataFormatter%41B47F0003B9.public

  protected:

    //## Other Operations (specified)
      //## Operation: onResume%450850870213
      virtual int onResume (Message& hMessage);

      //## Operation: onReset%4962158C01BD
      virtual int onReset (Message& hMessage);

    // Additional Protected Declarations
      //## begin DataFormatter%41B47F0003B9.protected preserve=yes
      //## end DataFormatter%41B47F0003B9.protected

  private:

    //## Other Operations (specified)
      //## Operation: cleanUp%422CBF5F0000
      void cleanUp ();

      //## Operation: process%4242CF660128
      void process ();

      //## Operation: updateProgress%422CBB09007D
      bool updateProgress (int iDX_FILE_ID, const char* pszDX_STATE, const string& strTSTAMP_FORMATTED);

    // Additional Private Declarations
      //## begin DataFormatter%41B47F0003B9.private preserve=yes
      //## end DataFormatter%41B47F0003B9.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: DATE_RECON%423604C40203
      //## begin DataFormatter::DATE_RECON%423604C40203.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strDATE_RECON;
      //## end DataFormatter::DATE_RECON%423604C40203.attr

      //## Attribute: DX_FILE_GROUP%42BFCA7600AB
      //## begin DataFormatter::DX_FILE_GROUP%42BFCA7600AB.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strDX_FILE_GROUP;
      //## end DataFormatter::DX_FILE_GROUP%42BFCA7600AB.attr

      //## Attribute: DX_FILE_ID%4236049F01E4
      //## begin DataFormatter::DX_FILE_ID%4236049F01E4.attr preserve=no  private: int {U} 0
      int m_iDX_FILE_ID;
      //## end DataFormatter::DX_FILE_ID%4236049F01E4.attr

      //## Attribute: DX_FILE_TYPE%42AE79360000
      //## begin DataFormatter::DX_FILE_TYPE%42AE79360000.attr preserve=no  private: reusable::string {U} 
      reusable::string m_strDX_FILE_TYPE;
      //## end DataFormatter::DX_FILE_TYPE%42AE79360000.attr

      //## Attribute: ExportFile%422DFEE202EE
      //## begin DataFormatter::ExportFile%422DFEE202EE.attr preserve=no  private: database::ExportFile* {U} 0
      database::ExportFile* m_pExportFile;
      //## end DataFormatter::ExportFile%422DFEE202EE.attr

      //## Attribute: EXPORT_RETRY_COUNT%422CC14F01F4
      //## begin DataFormatter::EXPORT_RETRY_COUNT%422CC14F01F4.attr preserve=no  private: int {U} 0
      int m_lEXPORT_RETRY_COUNT;
      //## end DataFormatter::EXPORT_RETRY_COUNT%422CC14F01F4.attr

    // Data Members for Associations

      //## Association: Data Distribution::DataFormatter_CAT (DF)::<unnamed>%4242F14002CE
      //## Role: DataFormatter::<m_hQuery>%4242F14101E4
      //## begin DataFormatter::<m_hQuery>%4242F14101E4.role preserve=no  public: reusable::Query { -> 2VHgN}
      reusable::Query m_hQuery[2];
      //## end DataFormatter::<m_hQuery>%4242F14101E4.role

      //## Association: Data Distribution::DataFormatter_CAT (DF)::<unnamed>%48E1638F0213
      //## Role: DataFormatter::<m_pTroller>%48E16390004E
      //## begin DataFormatter::<m_pTroller>%48E16390004E.role preserve=no  public: totalscommand::Troller { -> RFHgN}
      totalscommand::Troller *m_pTroller;
      //## end DataFormatter::<m_pTroller>%48E16390004E.role

    // Additional Implementation Declarations
      //## begin DataFormatter%41B47F0003B9.implementation preserve=yes
      string m_strSCHED_FREQUENCY;
      //## end DataFormatter%41B47F0003B9.implementation
};

//## begin DataFormatter%41B47F0003B9.postscript preserve=yes
//## end DataFormatter%41B47F0003B9.postscript

//## begin module%41B4878A033C.epilog preserve=yes
//## end module%41B4878A033C.epilog


#endif
