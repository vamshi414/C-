//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%41EC3CA300DA.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%41EC3CA300DA.cm

//## begin module%41EC3CA300DA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%41EC3CA300DA.cp

//## Module: CXODDF01%41EC3CA300DA; Package body
//## Subsystem: DF%41A351850261
//## Source file: C:\Repos\DataNavigatorServer\Windows\Build\Dn\Server\Application\Df\CXOSDF01.cpp

//## begin module%41EC3CA300DA.additionalIncludes preserve=no
//## end module%41EC3CA300DA.additionalIncludes

//## begin module%41EC3CA300DA.includes preserve=yes
#include "CXODMG48.hpp"
#include "CXODMG55.hpp"
#include "CXODMG49.hpp"
#include "CXODNR61.hpp"
#include "CXODNR62.hpp"
#include "CXODNR64.hpp"
#include "CXODNR65.hpp"
#include "CXODMG50.hpp"
#include "CXODMG52.hpp"
#include "CXODMG53.hpp"
#include "CXODMG54.hpp"
#include "CXODNR67.hpp"
#include "CXODPF42.hpp"
#include "CXODMG56.hpp"
#include "CXODTC91.hpp"
#include "CXODMG60.hpp"
#include "CXODMG61.hpp"
#include "CXODMG62.hpp"
#include "CXODMG63.hpp"
#include "CXODMG64.hpp"
#include "CXODSE16.hpp"
#include "CXODME87.hpp"
#include "CXODME88.hpp"
#include "CXODME89.hpp"
#include "CXODMG65.hpp"
#include "CXODMG67.hpp"
#include "CXODMG68.hpp"
#include "CXODRF95.hpp"
#include "CXODMG69.hpp"
//## end module%41EC3CA300DA.includes

#ifndef CXOSMC19_h
#include "CXODMC19.hpp"
#endif
#ifndef CXOSMC25_h
#include "CXODMC25.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSPF17_h
#include "CXODPF17.hpp"
#endif
#ifndef CXOSMG01_h
#include "CXODMG01.hpp"
#endif
#ifndef CXOSMG05_h
#include "CXODMG05.hpp"
#endif
#ifndef CXOSMG06_h
#include "CXODMG06.hpp"
#endif
#ifndef CXOSTC24_h
#include "CXODTC24.hpp"
#endif
#ifndef CXOSMG17_h
#include "CXODMG17.hpp"
#endif
#ifndef CXOSMG07_h
#include "CXODMG07.hpp"
#endif
#ifndef CXOSMG08_h
#include "CXODMG08.hpp"
#endif
#ifndef CXOSMG09_h
#include "CXODMG09.hpp"
#endif
#ifndef CXOSMG13_h
#include "CXODMG13.hpp"
#endif
#ifndef CXOSTC31_h
#include "CXODTC31.hpp"
#endif
#ifndef CXOSMG10_h
#include "CXODMG10.hpp"
#endif
#ifndef CXOSMG11_h
#include "CXODMG11.hpp"
#endif
#ifndef CXOSMG12_h
#include "CXODMG12.hpp"
#endif
#ifndef CXOSMG18_h
#include "CXODMG18.hpp"
#endif
#ifndef CXOSTC33_h
#include "CXODTC33.hpp"
#endif
#ifndef CXOSEX56_h
#include "CXODEX56.hpp"
#endif
#ifndef CXOSVE10_h
#include "CXODVE10.hpp"
#endif
#ifndef CXOSTC42_h
#include "CXODTC42.hpp"
#endif
#ifndef CXOSME03_h
#include "CXODME03.hpp"
#endif
#ifndef CXOSMG21_h
#include "CXODMG21.hpp"
#endif
#ifndef CXOSMG23_h
#include "CXODMG23.hpp"
#endif
#ifndef CXOSMG22_h
#include "CXODMG22.hpp"
#endif
#ifndef CXOSME06_h
#include "CXODME06.hpp"
#endif
#ifndef CXOSMG24_h
#include "CXODMG24.hpp"
#endif
#ifndef CXOSMG25_h
#include "CXODMG25.hpp"
#endif
#ifndef CXOSMC27_h
#include "CXODMC27.hpp"
#endif
#ifndef CXOSPE01_h
#include "CXODPE01.hpp"
#endif
#ifndef CXOSRF14_h
#include "CXODRF14.hpp"
#endif
#ifndef CXOSTC47_h
#include "CXODTC47.hpp"
#endif
#ifndef CXOSMG26_h
#include "CXODMG26.hpp"
#endif
#ifndef CXOSGE47_h
#include "CXODGE47.hpp"
#endif
#ifndef CXOSGE48_h
#include "CXODGE48.hpp"
#endif
#ifndef CXOSEX60_h
#include "CXODEX60.hpp"
#endif
#ifndef CXOSMC28_h
#include "CXODMC28.hpp"
#endif
#ifndef CXOSTC49_h
#include "CXODTC49.hpp"
#endif
#ifndef CXOSTC53_h
#include "CXODTC53.hpp"
#endif
#ifndef CXOSEX63_h
#include "CXODEX63.hpp"
#endif
#ifndef CXOSEX65_h
#include "CXODEX65.hpp"
#endif
#ifndef CXOSPF28_h
#include "CXODPF28.hpp"
#endif
#ifndef CXOSPF04_h
#include "CXODPF04.hpp"
#endif
#ifndef CXOSEF01_h
#include "CXODEF01.hpp"
#endif
#ifndef CXOSMG27_h
#include "CXODMG27.hpp"
#endif
#ifndef CXOSME15_h
#include "CXODME15.hpp"
#endif
#ifndef CXOSMG29_h
#include "CXODMG29.hpp"
#endif
#ifndef CXOSME22_h
#include "CXODME22.hpp"
#endif
#ifndef CXOSEF03_h
#include "CXODEF03.hpp"
#endif
#ifndef CXOSMG31_h
#include "CXODMG31.hpp"
#endif
#ifndef CXOSMG32_h
#include "CXODMG32.hpp"
#endif
#ifndef CXOSTM14_h
#include "CXODTM14.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSZE03_h
#include "CXODZE03.hpp"
#endif
#ifndef CXOSMG28_h
#include "CXODMG28.hpp"
#endif
#ifndef CXOSRA05_h
#include "CXODRA05.hpp"
#endif
#ifndef CXOSRC18_h
#include "CXODRC18.hpp"
#endif
#ifndef CXOSNE02_h
#include "CXODNE02.hpp"
#endif
#ifndef CXOSEF04_h
#include "CXODEF04.hpp"
#endif
#ifndef CXOSRF53_h
#include "CXODRF53.hpp"
#endif
#ifndef CXOSMG19_h
#include "CXODMG19.hpp"
#endif
#ifndef CXOSNR21_h
#include "CXODNR21.hpp"
#endif
#ifndef CXOSNR25_h
#include "CXODNR25.hpp"
#endif
#ifndef CXOSNR22_h
#include "CXODNR22.hpp"
#endif
#ifndef CXOSNR27_h
#include "CXODNR27.hpp"
#endif
#ifndef CXOSTC62_h
#include "CXODTC62.hpp"
#endif
#ifndef CXOSTC74_h
#include "CXODTC74.hpp"
#endif
#ifndef CXOSTC75_h
#include "CXODTC75.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSEF06_h
#include "CXODEF06.hpp"
#endif
#ifndef CXOSTC64_h
#include "CXODTC64.hpp"
#endif
#ifndef CXOSTC78_h
#include "CXODTC78.hpp"
#endif
#ifndef CXOSTC79_h
#include "CXODTC79.hpp"
#endif
#ifndef CXOSTC80_h
#include "CXODTC80.hpp"
#endif
#ifndef CXOSTC82_h
#include "CXODTC82.hpp"
#endif
#ifndef CXOSTC83_h
#include "CXODTC83.hpp"
#endif
#ifndef CXOSTC87_h
#include "CXODTC87.hpp"
#endif
#ifndef CXOSTC86_h
#include "CXODTC86.hpp"
#endif
#ifndef CXOSTC89_h
#include "CXODTC89.hpp"
#endif
#ifndef CXOSNR57_h
#include "CXODNR57.hpp"
#endif
#ifndef CXOSNR23_h
#include "CXODNR23.hpp"
#endif
#ifndef CXOSNR15_h
#include "CXODNR15.hpp"
#endif
#ifndef CXOSNR20_h
#include "CXODNR20.hpp"
#endif
#ifndef CXOSMG33_h
#include "CXODMG33.hpp"
#endif
#ifndef CXOSTC61_h
#include "CXODTC61.hpp"
#endif
#ifndef CXOSTC88_h
#include "CXODTC88.hpp"
#endif
#ifndef CXODMG44_h
#include "CXODMG44.hpp"
#endif
#ifndef CXOSNR37_h
#include "CXODNR37.hpp"
#endif
#ifndef CXOSNR38_h
#include "CXODNR38.hpp"
#endif
#ifndef CXOSMG42_h
#include "CXODMG42.hpp"
#endif
#ifndef CXOSTC81_h
#include "CXODTC81.hpp"
#endif
#ifndef CXOSNR13_h
#include "CXODNR13.hpp"
#endif
#ifndef CXODMG45_h
#include "CXODMG45.hpp"
#endif
#ifndef CXOSMG47_h
#include "CXODMG47.hpp"
#endif
#ifndef CXOSMG46_h
#include "CXODMG46.hpp"
#endif
#ifndef CXOSNR35_h
#include "CXODNR35.hpp"
#endif
#ifndef CXODMG41_h
#include "CXODMG41.hpp"
#endif
#ifndef CXOSMG38_h
#include "CXODMG38.hpp"
#endif
#ifndef CXOSBA04_h
#include "CXODBA04.hpp"
#endif
#ifndef CXOSPF33_h
#include "CXODPF33.hpp"
#endif
#ifndef CXOSBA07_h
#include "CXODBA07.hpp"
#endif
#ifndef CXOSMG40_h
#include "CXODMG40.hpp"
#endif
#ifndef CXOSNR14_h
#include "CXODNR14.hpp"
#endif
#ifndef CXOSEF05_h
#include "CXODEF05.hpp"
#endif
#ifndef CXOSEF07_h
#include "CXODEF07.hpp"
#endif
#ifndef CXOSEX10_h
#include "CXODEX10.hpp"
#endif
#ifndef CXOSEF08_h
#include "CXODEF08.hpp"
#endif
#ifndef CXOSSE10_h
#include "CXODSE10.hpp"
#endif
#ifndef CXOSEF09_h
#include "CXODEF09.hpp"
#endif
#ifndef CXODDF01_h
#include "CXODDF01.hpp"
#endif


//## begin module%41EC3CA300DA.declarations preserve=no
//## end module%41EC3CA300DA.declarations

//## begin module%41EC3CA300DA.additionalDeclarations preserve=yes
//## end module%41EC3CA300DA.additionalDeclarations


// Class ExportFileFactory

ExportFileFactory::ExportFileFactory()
  //## begin ExportFileFactory::ExportFileFactory%41E973D2035B_const.hasinit preserve=no
  //## end ExportFileFactory::ExportFileFactory%41E973D2035B_const.hasinit
  //## begin ExportFileFactory::ExportFileFactory%41E973D2035B_const.initialization preserve=yes
  //## end ExportFileFactory::ExportFileFactory%41E973D2035B_const.initialization
{
  //## begin ExportFileFactory::ExportFileFactory%41E973D2035B_const.body preserve=yes
   memcpy(m_sID,"DF01",4);
   struct hExportFileAttributes fileDefs[] =
   { //DX_FILE_TYPE, SCHED_FREQ, WALL/SWITCH CLOCK,CUTOFF/ABSOLUTE,ADJUST DATE,TASK,FileClass for switch statement
      {"ATMBAL",'D','S','C','N',"DF",0},
      {"ATMDEP",'N','S','C','N',"DF",1},
      {"ECPOST",'D','W','C','N',"DF",2},
      {"MIS",   'N','S','C','N',"DF",3},
      {"MIC",   'N','S','C','N',"DF",4},
      {"MIUMND",'M','S','C','N',"DF",5},
      {"MIUYND",'M','S','C','N',"DF",5},
      {"MIUMNC",'M','S','C','N',"DF",5},
      {"MIUYNC",'M','S','C','N',"DF",5},
      {"MIUMNB",'M','S','C','N',"DF",5},
      {"MIUYNB",'M','S','C','N',"DF",5},
      {"EBAMEX",'D','W','C','N',"DF",6},
      {"MIUMCA",'M','S','C','N',"DF",7},
      {"MIUYCA",'M','S','C','N',"DF",7},
      {"MIUMCP",'M','S','C','N',"DF",8},
      {"MIUYCP",'M','S','C','N',"DF",8},
      {"MIUMDP",'M','S','C','N',"DF",8},
      {"MIUYDP",'M','S','C','N',"DF",8},
      {"MIUMCT",'M','S','C','N',"DF",9},
      {"MIUMDT",'M','S','C','N',"DF",9},
      {"EMCER", 'D','W','C','N',"DF",10},
      {"EMCEE", 'D','W','C','N',"DF",10},
      {"MIUMAV",'M','S','C','N',"DF",11},
      {"MIUYAV",'M','S','C','N',"DF",11},
      {"MIUMPS",'M','S','C','N',"DF",12},
      {"MIUYPS",'M','S','C','N',"DF",12},
      {"FINDET",'D','S','C','Y',"DF",13},
      {"FINXPP",'D','S','C','Y',"DF",14},
      {"FINXIP",'D','S','C','Y',"DF",14},
      {"FINXDP",'D','S','C','Y',"DF",14},
      {"FINXII",'D','S','C','Y',"DF",14},
      {"FINXPG",'D','S','C','Y',"DF",14},
      {"FINXIG",'D','S','C','Y',"DF",14},
      {"FINYPP",'D','S','C','Y',"DF",14},
      {"FINYIP",'D','S','C','Y',"DF",14},
      {"FINYDP",'D','S','C','Y',"DF",14},
      {"FINYII",'D','S','C','Y',"DF",14},
      {"FINYPG",'D','S','C','Y',"DF",14},
      {"FINYIG",'D','S','C','Y',"DF",14},
      {"FINXMI",'D','S','C','Y',"DF",14},
      {"FINXMP",'D','S','C','Y',"DF",14},
      {"FINXMG",'D','S','C','Y',"DF",14},
      {"FINYMI",'D','S','C','Y',"DF",14},
      {"FINYMP",'D','S','C','Y',"DF",14},
      {"FINYMG",'D','S','C','Y',"DF",14},
      {"MIUMCI",'M','S','C','N',"DF",15},
      {"MIUYCI",'M','S','C','N',"DF",15},
      {"MIUMID",'M','S','C','N',"DF",16},
      {"MIUYID",'M','S','C','N',"DF",16},
      {"MIUMEX",'M','S','C','N',"DF",18},
      {"MIUYEX",'M','S','C','N',"DF",18},
      {"LDSP",  'D','S','C','N',"DF",19},
      {"MIUMCB",'M','S','C','N',"DF",20},
      {"MIUYCB",'M','S','C','N',"DF",20},
      {"EFEMCI",'D','W','C','Y',"DF",22},
      {"EFEMCC",'D','W','C','Y',"DF",22},
      {"EFEMPD",'D','W','C','Y',"DF",22},
      {"EFCMCI",'D','W','C','Y',"DF",22},
      {"EFCMCC",'D','W','C','Y',"DF",22},
      {"EFCMPD",'D','W','C','Y',"DF",22},
      {"FEEMAI",'M','S','C','N',"DF",23},
      {"ADPOST",'D','S','C','N',"DF",25},
      {"EVEXC", 'D','W','C','N',"DF",27}, //COOP
      {"EVEXG", 'D','W','C','N',"DF",27}, //GTWY
      {"EVEXM", 'D','W','C','N',"DF",27}, //MCDP
      {"FINMCP",'D','S','C','Y',"DF",28},
      {"FINMPI",'D','S','C','Y',"DF",28},
      {"FINMIM",'D','S','C','Y',"DF",28},
      {"FINMIT",'D','S','C','Y',"DF",28},
      {"FINMMT",'D','S','C','Y',"DF",28},
      {"FINTCP",'D','S','C','Y',"DF",28},
      {"FINTPI",'D','S','C','Y',"DF",28},
      {"FINTIM",'D','S','C','Y',"DF",28},
      {"FINTIT",'D','S','C','Y',"DF",28},
      {"FINTMT",'D','S','C','Y',"DF",28},
      {"FINTCI",'D','S','C','Y',"DF",28},
      {"FINTCM",'D','S','C','Y',"DF",28},
      {"FINTPM",'D','S','C','Y',"DF",28},
      {"FINDEP",'D','S','C','Y',"DF",29},
      {"FINDEI",'D','S','C','Y',"DF",29},
      {"FINDEM",'D','S','C','Y',"DF",29},
      {"FINDTP",'D','S','C','Y',"DF",29},
      {"FINDTI",'D','S','C','Y',"DF",29},
      {"FINDTM",'D','S','C','Y',"DF",29},
      {"ZRTERM",'D','S','C','N',"DF",30},
      {"MILMFB",'M','S','C','N',"DF",31},
      {"MILDFB",'D','S','C','N',"DF",31},
      {"MXIDFO",'D','S','C','Y',"DF",32},
      {"MXIMFO",'M','S','C','N',"DF",32},
      {"MXIDFI",'D','S','C','Y',"DF",32},
      {"MXIMFI",'M','S','C','N',"DF",32},
      {"MXIDFA",'D','S','C','Y',"DF",33},
      {"MXIMFA",'M','S','C','N',"DF",33},
      {"MXIDFS",'D','S','C','Y',"DF",34},
      {"MXIMFS",'M','S','C','N',"DF",34},
      {"EMEMCI",'D','W','C','Y',"DF",35},
      {"EMEMCC",'D','W','C','Y',"DF",35},
      {"EMEMPD",'D','W','C','Y',"DF",35},
      {"CM2ARE",'D','S','C','N',"DF",36},
      {"CM3AIU",'N','S','C','N',"DF",37},
      {"CM3AAU",'N','S','C','N',"DF",37},
      {"CM3OTU",'N','S','C','N',"DF",37},
      {"CM3OFU",'N','S','C','N',"DF",37},
      {"CM3ITU",'N','S','C','N',"DF",37},
      {"CM3IFU",'N','S','C','N',"DF",37},
      {"ATMDPE",'N','S','C','N',"DF",38},
      {"ATMDPR",'D','S','A','N',"DF",39},
      {"MXIMFU",'M','S','C','N',"DF",40},
      {"EPEPUL",'D','W','C','N',"DF",41},
      {"MXIC1O",'D','S','C','Y',"DF",42},
      {"MXIC2O",'D','S','C','Y',"DF",42},
      {"MXIC1I",'D','S','C','Y',"DF",42},
      {"MXIC2I",'D','S','C','Y',"DF",42},
      {"FINXLM",'D','S','C','Y',"DF",43},
      {"CM4ADJ",'N','S','C','N',"DF",44},
      {"MXIDFU",'D','S','C','Y',"DF",45},
      {"ATMEJ", 'D','S','A','N',"DF",46},
      {"FINEEP",'D','S','C','Y',"DF",47},
      {"FINEEI",'D','S','C','Y',"DF",47},
      {"MXIDFM",'D','S','C','Y',"DF",48},
      {"BULK",  'D','W','C','N',"DF",49},
      {"EMSACT",'D','W','C','N',"DF",50},
      {"VRBUA5",'D','W','C','N',"DF",51},
      {"VRRUA5",'D','W','C','N',"DF",52},
      {"ATMDPS",'D','S','A','N',"DF",53},
      {"ATMGLI",'D','S','C','N',"DF",54},
      {"ATMGLT",'N','S','C','N',"DF",55},
      {"EMSFRV",'D','W','C','N',"DF",56},
      {"EMSFRM",'D','W','C','N',"DF",57},
      {"ECHIST",'D','W','C','Y',"EM",58},
      {"APMRPT",'D','S','C','N',"DF",59},
      {"PPDBLL",'M','W','C','N',"DF",60},
      {"MXIDFT",'D','S','C','Y',"DF",61},
      {"MXIMFT",'M','S','C','N',"DF",61},
      {"IPMOUT",'D','W','C','N',"DF",62},
      {"AUDENT",'N','W','C','N',"DF",63},
      {"ZAPACT",'D','W','C','N',"DF",64},
      {"MXIMTC",'M','S','C','N',"DF",65},
      {"MCPEXP",'D','W','C','Y',"DF",66},
      {"PPDEXC",'M','W','C','N',"DF",67},
      {"MXIDSF",'D','S','C','Y',"DF",68},
      {"MXIMSF",'M','S','C','N',"DF",68},
      {"FEEBLL",'M','W','C','N',"DF",69},
      {"NYCEXP",'D','W','A','N',"DF",70},
      {"CTRPTY",'D','W','A','N',"DF",71},
      {"MCBBLL",'M','W','C','N',"DF",72},
      {"FTAIIP",'D','S','C','Y',"DF",73},
      {"FTAMIP",'D','S','C','Y',"DF",73},
      {"RCNAMX",'D','W','C','N',"DF",74},
      {"RCNDBT",'D','W','C','N',"DF",74},
      {"RCNDIS",'D','W','C','N',"DF",74},
      {"RCNEHB",'D','W','C','N',"DF",74},
      {"RCNMCI",'D','W','C','N',"DF",74},
      {"RCNVNT",'D','W','C','N',"DF",74},
      {"RCNSUS",'D','W','C','N',"DF",74},
      {"MERALL",'D','S','C','N',"DF",75},
      {"MERAMX",'D','S','C','N',"DF",75},
      {"MERDBT",'D','S','C','N',"DF",75},
      {"MERDIS",'D','S','C','N',"DF",75},
      {"MERMCI",'D','S','C','N',"DF",75},
      {"MERVNT",'D','S','C','N',"DF",75},
      {"BALAMX",'D','W','C','N',"DF",76},
      {"BALDBT",'D','W','C','N',"DF",76},
      {"BALDIS",'D','W','C','N',"DF",76},
      {"BALEHB",'D','W','C','N',"DF",76},
      {"BALMCI",'D','W','C','N',"DF",76},
      {"BALVNT",'D','W','C','N',"DF",76},
      {"BALSUS",'D','W','C','N',"DF",76},
      {"INTAMX",'D','W','C','N',"DF",77},
      {"INTDIS",'D','W','C','N',"DF",77},
      {"INTMCI",'D','W','C','N',"DF",77},
      {"INTVNT",'D','W','C','N',"DF",77},
      {"IPAAMX",'D','W','C','N',"DF",77},
      {"IPADIS",'D','W','C','N',"DF",77},
      {"IPAMCI",'D','W','C','N',"DF",77},
      {"IPAVNT",'D','W','C','N',"DF",77},
      {"DISARI",'D','S','C','N',"DF",78},
      {"VNTSMS",'D','S','C','N',"DF",79},
      {"MCI884",'D','S','C','N',"DF",80},
      {"VSS130",'D','S','C','N',"DF",81},
      {"VSS900",'D','S','C','N',"DF",82},
      {"MERCTL",'D','S','C','N',"DF",83},
      {"MERREV",'D','S','C','N',"DF",84},
      {"FEEAMX",'D','W','C','N',"DF",85},
      {"FEEDIS",'D','W','C','N',"DF",85},
      {"FEEMCI",'D','W','C','N',"DF",85},
      {"FEEVNT",'D','W','C','N',"DF",85},
      {"DSPAMX",'D','W','C','N',"DF",86},
      {"DSPDIS",'D','W','C','N',"DF",86},
      {"DSPMCI",'D','W','C','N',"DF",86},
      {"DSPVNT",'D','W','C','N',"DF",86},
      {"MEROPN",'D','S','C','N',"DF",87},
      {"TIBILL",'M','W','C','N',"DF",88},
      {"FINMBL",'M','S','C','N',"DF",89},
      {"EMSMBL",'M','S','C','N',"DF",90},
      {"FINDTR",'D','S','C','N',"DF",91},
      {"TRMFIA",'D','S','C','Y',"DF",92},
      {"CRDFIA",'D','S','C','Y',"DF",93},
      {"TFATM1",'D','S','C','Y',"DF",94},
      {"TRMBAL",'D','S','C','Y',"DF",95},
      {"ASXRPT",'D','S','C','Y',"DF",96},
      {"QMRVNI",'M','S','C','N',"DF",97},
      {"QMIVNI",'M','S','C','N',"DF",97},
      {"QM0VNT",'M','S','C','N',"DF",97},
      {"QM1VNI",'M','S','C','N',"DF",97},
      {"QM2VNI",'M','S','C','N',"DF",97},
      {"QMRVDI",'M','S','C','N',"DF",97},
      {"QM1VDI",'M','S','C','N',"DF",97},
      {"QM2VDI",'M','S','C','N',"DF",97},
      {"QMRVPI",'M','S','C','N',"DF",97},
      {"QM1VPI",'M','S','C','N',"DF",97},
      {"QM2VPI",'M','S','C','N',"DF",97},
      {"QM4VNT",'M','S','C','N',"DF",97},
      {"QM3VNI",'M','S','C','N',"DF",97},
      {"QM3VDI",'M','S','C','N',"DF",97},
      {"QM3VPI",'M','S','C','N',"DF",97},
      {"QMRVAI",'M','S','C','N',"DF",97},
      {"QMIVAI",'M','S','C','N',"DF",97},
      {"QM1VAI",'M','S','C','N',"DF",97},
      {"QMRMCA",'M','S','C','N',"DF",98},
      {"QMIMCA",'M','S','C','N',"DF",98},
      {"QM1MCA",'M','S','C','N',"DF",98},
      {"QMRMDA",'M','S','C','N',"DF",98},
      {"QMIMDA",'M','S','C','N',"DF",98},
      {"QM1MDA",'M','S','C','N',"DF",98},
      {"QMRMAA",'M','S','C','N',"DF",98},
      {"QMIMAA",'M','S','C','N',"DF",98},
      {"QM1MAA",'M','S','C','N',"DF",98},
      {"QM3MCA",'M','S','C','N',"DF",98},
      {"QM3MDA",'M','S','C','N',"DF",98},
      {"QMRMCI",'M','S','C','N',"DF",99},
      {"QMIMCI",'M','S','C','N',"DF",99},
      {"QM0MCI",'M','S','C','N',"DF",99},
      {"QM1MCI",'M','S','C','N',"DF",99},
      {"QMRMDI",'M','S','C','N',"DF",99},
      {"QM1MDI",'M','S','C','N',"DF",99},
      {"QMRMPI",'M','S','C','N',"DF",99},
      {"QM1MPI",'M','S','C','N',"DF",99},
      {"QM4MCI",'M','S','C','N',"DF",99},
      {"QM3MCI",'M','S','C','N',"DF",99},
      {"QM3MDI",'M','S','C','N',"DF",99},
      {"QM3MPI",'M','S','C','N',"DF",99},
      {"QMRCRI",'M','S','C','N',"DF",100},
      {"QMICRI",'M','S','C','N',"DF",100},
      {"QM1CRI",'M','S','C','N',"DF",100},
      {"QMRMSI",'M','S','C','N',"DF",101},
      {"QMIMSI",'M','S','C','N',"DF",101},
      {"QM1MSI",'M','S','C','N',"DF",101},
      {"QMRMSA",'M','S','C','N',"DF",102},
      {"QMIMSA",'M','S','C','N',"DF",102},
      {"QM1MSA",'M','S','C','N',"DF",102},
      {"QMRCRA",'M','S','C','N',"DF",103},
      {"QMICRA",'M','S','C','N',"DF",103},
      {"QM1CRA",'M','S','C','N',"DF",103},
      {"QM2CRA",'M','S','C','N',"DF",103},
      {"ATMCFC",'D','S','C','Y',"DF",104},
      {"QMRILK",'M','S','C','N',"DF",105},
      {"QMIILK",'M','S','C','N',"DF",105},
      {"QM1ILK",'M','S','C','N',"DF",105},
      {"QMRPLS",'M','S','C','N',"DF",106},
      {"QMIPLS",'M','S','C','N',"DF",106},
      {"QM1PLS",'M','S','C','N',"DF",106},
      {"QM3PLS",'M','S','C','N',"DF",106},
      {"QMRVNA",'M','S','C','N',"DF",110},
      {"QMIVNA",'M','S','C','N',"DF",110},
      {"QM1VNA",'M','S','C','N',"DF",110},
      {"QM2VNA",'M','S','C','N',"DF",110},
      {"GLPEHB",'D','W','C','N',"DF",107},
      {"GLPMCI",'D','W','C','N',"DF",107},
      {"GLPVNT",'D','W','C','N',"DF",107},
      {"GL1EHB",'D','W','C','N',"DF",108},
      {"GL2EHB",'D','W','C','N',"DF",109},
      {"ACCTNG",'D','W','A','Y',"DF",111},
      {"SAPMBL",'M','S','C','N',"DF",112},
      {"BILMIS",'M','S','C','N',"DF",113},
      {"BIIMIS",'M','S','C','N',"DF",113},
      {"VSS110",'D','S','C','N',"DF",114},
      {"VSS120",'D','S','C','N',"DF",115},
      {"VNTBII",'D','S','C','N',"DF",116},
      {"ESESTR",'D','W','A','N',"DF",117},
      {"ESECPP",'D','W','A','N',"DF",117},
      {"ESECPY",'D','W','A','N',"DF",117},
      {"EFESTR",'D','W','A','N',"DF",117},
      {"EFECPP",'D','W','A','N',"DF",117},
      {"EFECPY",'D','W','A','N',"DF",117},
      {"QMRPLI",'M','S','C','N',"DF",118},
      {"QMIPLI",'M','S','C','N',"DF",118},
      {"QM2PLI",'M','S','C','N',"DF",118},
      {"ARFMAC",'D','S','C','N',"DF",119},
      {"COFMBR",'M','S','C','N',"DF",120},
      {"COIMBR",'M','S','C','N',"DF",120},
      {"FINCOF",'D','S','C','N',"DF",121},
      {"SCMDEL",'M','S','C','Y',"DF",122},
      {"FEEBLL",'D','W','A','N',"DF",123},
      {"UAEFEE",'D','W','A','N',"DF",124},
      {"FINHRS",'M','S','C','N',"DF",125},
      {"FINHRR",'M','S','C','N',"DF",126},
      {"DSPNET",'D','W','C','N',"DF",127},
      {"EXPNET",'D','W','C','N',"DF",128},
      {"AUTHMR",'M','S','C','N',"DF",129},
      {"MCISAR",'D','S','C','N',"DF",130},
      {"MCISCR",'D','S','C','N',"DF",131},
      {"MCCSCR",'D','S','C','N',"DF",131},
      {"ESISTR",'D','W','A','N',"DF",132},
      {"ESICPP",'D','W','A','N',"DF",132},
      {"ESICPY",'D','W','A','N',"DF",132},
      {"CBEMCI",'D','S','C','N',"DF",133},
      {"CHCLMF",'M','S','C','N',"DF",134},
      {"AUEXPR",'D','S','C','N',"DF",135},
      {"FINIFD",'M','W','C','N',"DF",136},
      {"DLRFEE",'M','W','C','N',"DF",137},
      {"STPRPT",'D','S','C','N',"DF",138},
      {"ZZZZZZ",'Z','Z','Z','Z',"ZZ",9999} // <==== leave this as last entry
   };
   int iIndex = 0;
   while(memcmp(fileDefs[iIndex].sDX_FILE_TYPE,"ZZZZZZ",6) != 0)
   {
      m_hFileDictionary[string(fileDefs[iIndex].sDX_FILE_TYPE)] = fileDefs[iIndex];
      iIndex++;
   }
   createInLists(); //m_strDaily,m_strMonthly,m_strClockFiles[]
   setDX_STATE("FW");
   BarTime::instance()->attach(this);
  //## end ExportFileFactory::ExportFileFactory%41E973D2035B_const.body
}


ExportFileFactory::~ExportFileFactory()
{
  //## begin ExportFileFactory::~ExportFileFactory%41E973D2035B_dest.body preserve=yes
   BarTime::instance()->detach(this);
  //## end ExportFileFactory::~ExportFileFactory%41E973D2035B_dest.body
}



//## Other Operations (implementation)
void ExportFileFactory::adjustDate (timer::Date& hDate)
{
  //## begin ExportFileFactory::adjustDate%4F79C43A0397.body preserve=yes
   if (m_strDX_FILE_TYPE[0].length() >= 6
      && (m_strDX_FILE_TYPE[0].substr(3,3) == "MCC"
      || m_strDX_FILE_TYPE[0].substr(3,3) == "MCI"
      || m_strDX_FILE_TYPE[0].substr(3, 3) == "MPD"))
   {
      if (hDate.asString("%A") == "Saturday"
         && (Extract::instance()->getCustomCode() != "DGMC"
         || (m_strDX_FILE_TYPE[0] != "EMEMCI")
         && m_strDX_FILE_TYPE[0] != "EFEMCI"))
      {
         hDate += 1; // bump to next day (Sunday)
         m_strDATE_RECON[0] = hDate.asString("%Y%m%d");
      }
      return;
   }
   FileFactory::adjustDate(hDate);
  //## end ExportFileFactory::adjustDate%4F79C43A0397.body
}

ExportFile* ExportFileFactory::create (const ExportFile& hExportFile)
{
  //## begin ExportFileFactory::create%41E97F92003E.body preserve=yes
   string strDX_FILE_TYPE(hExportFile.getDX_FILE_TYPE());
   if ((strDX_FILE_TYPE.length() > 3)
      && ((strDX_FILE_TYPE.substr(0,3) == "MIS") || (strDX_FILE_TYPE.substr(0,3) == "MIC")))
      strDX_FILE_TYPE.erase(3);
   map<string,struct hExportFileAttributes,less<string> >::iterator q = m_hFileDictionary.find(strDX_FILE_TYPE);
   if (q == m_hFileDictionary.end())
      return 0;
   ExportFile* pExportFile = 0;
   switch ((*q).second.iFileClass)
   {
      case 0:      //"ATMBAL"
         pExportFile = new managementcommand::BalanceSheetFile();
         break;
      case 1:      //"ATMDEP"
         pExportFile = new managementcommand::DepositExport();
         break;
      case 2:      //"ECPOST"
         pExportFile = new postingfile::ExceptionActivityFile();
         break;
      case 3:      //"MIS"
         pExportFile = new managementinformation::ManagementTotals();
         break;
      case 4:      //"MIC"
         pExportFile = new managementinformation::ChannelTransactions();
         break;
      case 5:      //"MIUMND","MIUYND","MIUMNC","MIUYNC","MIUMNB","MIUYNB"
        pExportFile = new managementinformation::NetworkSales();
         break;
      case 6:      //"EBAMEX"
         pExportFile = new bamsprocessing::BAMSExport();
         break;
      case 7:      //"MIUMCA", "MIUYCA"
         pExportFile = new managementinformation::CardActivity();
         break;
      case 8:      //"MIUMCP","MIUYCP","MIUMDP","MIUYDP"
         pExportFile = new managementinformation::PaymentRange();
         break;
      case 9:      //"MIUMCT","MIUMDT"
         pExportFile = new managementinformation::CardBrand();
         break;
      case 10:     //"EMCER","EMCEE"
         pExportFile = new bamsprocessing::ChesapeakeExport();
         break;
      case 11:     //"MIUMAV","MIUYAV"
         pExportFile = new managementinformation::AVSReport();
         break;
      case 12:     //"MIUMPS","MIUYPS"
         pExportFile = new managementinformation::PaymentSummary();
         break;
      case 13:     //"FINDET"
         if (entitysegment::Customer::instance()->getTotalsVersion() == 1)
            pExportFile = new totalscommand::FinancialDetailFile1();
         else
            pExportFile = new totalscommand::FinancialDetailFile2();
         break;
      case 14:     //"FINXPP", ...
         if (entitysegment::Customer::instance()->getTotalsVersion() == 1)
            pExportFile = new totalscommand::ActivityByInterchangeFile1();
         else
            pExportFile = new totalscommand::ActivityByInterchangeFile2();
         break;
      case 15:     //"MIUMCI","MIUYCI"
         pExportFile = new managementinformation::InterchangeFeeReport();
         break;
      case 16:     //"MIUMID","MIUYID"
         pExportFile = new managementinformation::InterchangeDowngradeReport();
         break;
      case 17:     //"FINXIP","FINXDP"
         pExportFile = new totalscommand::ActivityByInterchangeFile();
         break;
      case 18:     //"MIUMEX","MIUYEX"
         pExportFile = new managementinformation::ExceptionReport();
         break;
      case 19:     //"LDSP"
         pExportFile = new totalscommand::LinkDetailSettlementPosition();
         break;
      case 20:     //"MIUMCB","MIUYCB"
         pExportFile = new managementinformation::ChargebackReport();
         break;
      case 21:     //"FINXII","FINXPG","FINXIG"
         pExportFile = new totalscommand::ActivityByInterchangeFile();
         break;
      case 22:     //"EFEMCI","EFEMCC","EFEMPD","EFCMCI","EFCMCC","EFCMPD"
         pExportFile = new mastercardexception::SAFEExportFile();
         break;
      case 23:     //"FEEMAI"
         pExportFile = new totalscommand::MonthlyFeeFile();
         break;
      case 24:     //"FINYPP","FINYIP","FINYDP","FINYII","FINYPG","FINYIG"
         pExportFile = new totalscommand::ActivityByInterchangeFile();
         break;
      case 25:     //"ADPOST"
         pExportFile = new ems::AdjustmentPosting();
         break;
      case 26:     //"FINXMI","FINXMP","FINXMG","FINYMI","FINYMP","FINYMG"
         pExportFile = new totalscommand::ActivityByInterchangeFile();
         break;
      case 27:     //"EVEXC"(COOP),"EVEXG"(GTWY),"EVEXM"(MCDP)
         pExportFile = new visaexception::VisaExceptionExport();
         break;
      case 28:     //"FINMCP","FINMPI","FINMIM","FINMIT","FINMMT"
         if (entitysegment::Customer::instance()->getTotalsVersion() == 1)
            pExportFile = new totalscommand::FinancialSummaryFile1();
         else
            pExportFile = new totalscommand::FinancialSummaryFile2();
         break;
      case 29:     //"FINDEP","FINDEI","FINDEM"
         if (entitysegment::Customer::instance()->getTotalsVersion() == 1)
            pExportFile = new totalscommand::FinancialDetailFile1();
         else
            pExportFile = new totalscommand::FinancialDetailFile2();
         break;
      case 30:     //"ZRTERM"
         pExportFile = new totalscommand::ZeroTerminalActivityFile();
         break;
      case 31:     //"MILMFB","MILDFB"
         pExportFile = new managementinformation::FeeBilling();
         break;
      case 32:     //"MXIDFO","MXIMFO","MXIDFI","MXIMFI"
         pExportFile = new managementinformation::InterchangeTransferFee();
         break;
      case 33:     //"MXIDFA","MXIMFA"
         pExportFile = new managementinformation::ATMInterchangeFee();
         break;
      case 34:     //"MXIDFS","MXIMFS"
         if (Extract::instance()->getCustomCode() == "LCPL")
            pExportFile = new managementinformation::LCPLSwitchFeeReport();
         else
            pExportFile = new managementinformation::SwitchFeeReport();
         break;
      case 35:     //"EMEMCI","EMEMCC","EMEMPD"
         pExportFile = new mastercardexception::MasterCardExceptionExport();
         break;
      case 36:     //"CM2ARE"
         pExportFile = new managementinformation::CombinedReconciliationReport();
         break;
      case 37:     //"CM3AIU","CM3AAU","CM3OTU","CM3OFU","CM3ITU","CM3IFU"
         pExportFile = new managementinformation::UnmatchedReport();
         break;
      case 38:     //"ATMDPE"
         pExportFile = new managementcommand::DepositExport();
         break;
      case 39:     //"ATMDPR"
         pExportFile = new managementcommand::CheckDepositExport();
         break;
      case 40:     //"MXIMFU"
         pExportFile = new managementinformation::SwitchFeeReport();
         break;
      case 41:     //"EPEPUL"
         pExportFile = new pulseexception::PulseExport();
         break;
      case 42:     //"MXIC1O","MXIC2O","MXIC1I","MXIC2I"
         pExportFile = new managementinformation::InterchangeTransferFee();
         break;
      case 43:     //"FINXLM"
         pExportFile = new totalscommand::LMDetailSettlementPosition();
         break;
      case 44:     //"CM4ADJ"
          pExportFile = new reconciliationfile::AutoAdjustment();
          break;
      case 45:     //"MXIDFU"
          pExportFile = new managementinformation::SwitchFeeReport();
          break;
      case 46:     //"ATMEJ"
         pExportFile = new managementinformation::ElectronicJournalExport();
         break;
      case 47:     //"FINEEP","FINEEI"
         if (entitysegment::Customer::instance()->getTotalsVersion() == 1)
            pExportFile = new totalscommand::FinancialDetailFile1();
         else
            pExportFile = new totalscommand::FinancialDetailFile2();
         break;
      case 48:     // "MXIDFM"
         pExportFile = new managementinformation::SwitchFeeReport();
         break;
      case 49:     // "BULK"
         pExportFile = new regionsapi::BulkPrintExportFile();
         break;
      case 50:     //"EMSACT"
         if (hExportFile.getNull() > -1)
            pExportFile = new postingfile::CaseReportFile();
         else
            pExportFile = new ems::CaseTransitionActivityFile();
         break;
      case 51:     //"VRBUA5"
         pExportFile = new genericexception::BulkSIUploadRequestBatchDescriptor();
         break;
      case 52:     //"VRRUA5"
         pExportFile = new genericexception::BulkSIUploadRequestPackage();
         break;
      case 53:     //"ATMDPS"
         pExportFile = new managementcommand::SunCoastDepositExport();
         break;
      case 54:     //"ATMGLI"
         pExportFile = new totalscommand::InstitutionGeneralLedgerFile();
         break;
      case 55:     //"ATMGLT"
         pExportFile = new totalscommand::ATMGeneralLedgerFile();
         break;
      case 56:     //"EMSFRV"
         pExportFile = new ems::VisaFraudActivityFile();
         break;
      case 57:     //"EMSFRM"
         pExportFile = new ems::MasterCardFraudActivityFile();
         break;
      case 58:     //"ECHIST"
         pExportFile = new CaseHistoryExport();
         break;
      case 59:     //"APMRPT"
         pExportFile = new repositorycommand::AuditMaintenanceActivity();
         break;
      case 60:     //"PPDBLL"
         pExportFile = new exceptionfile::PrepaidBillingFile();
         break;
      case 61:     //"MXIDFT","MXIMFT"
         pExportFile = new managementinformation::TransactionSummaryReport();
         break;
      case 62:     //"IPMOUT"
         pExportFile = new mastercardexception::IPMExceptionExport();
         break;
      case 63:     //"AUDENT"
         pExportFile = new managementinformation::AuditEventFile();
         break;
      case 64:     //"ZAPACT"
         pExportFile = new zapp::CaseZappActivityFile();
         break;
      case 65:     //"MXIMTC"
         pExportFile = new managementinformation::PaymentRangeByTranClass();
         break;
      case 66:     //"MCPEXP"
         pExportFile = new mastercardexception::MasterComProExport();
         break;
      case 67:     //"PPDEXC"
         pExportFile = new exceptionfile::PrepaidExceptionBillingFile();
         break;
      case 68:     //"MXIDSF","MXIMSF"
         pExportFile = new managementinformation::LCPLCombinedFeeReport();
         break;
      case 69:     //"FEEBILL
         pExportFile = new exceptionfile::Billing();
         break;
      case 70:     //"NYCEXP",
         pExportFile = new nyceexception::NYCEExport();
         break;
      case 71:     //"CTRPTY",
         pExportFile = new reconciliationfile::CounterParty();
         break;
     case 72:     //"MCBBLL"
         pExportFile = new exceptionfile::MCBSBillingFile();
         break;
      case 73:     //"FINRPT"
         pExportFile = new managementinformation::FinancialTotalsReport();
         break;
      case 74:     //"RCNAMX","RCNDIS","RCNMCI","RCNVNT","RCNEHB"
         pExportFile = new networkreconciliation::NetworkWorksheet();
         break;
      case 75:     //"RCNMER"
         pExportFile = new networkreconciliation::MerchantWorksheet();
         break;
      case 76:     //"BALAMX","BALDIS","BALMCI","BALVNT","BALEHB"
         pExportFile = new networkreconciliation::BalanceSheet();
         break;
      case 77:     //"INTDIS","INTMCI","INTVNT"
         pExportFile = new networkreconciliation::InterchangeWorksheet();
         break;
      case 78:     //"DISARI"
         pExportFile = new networkreconciliation::DiscoverExportFile();
         break;
      case 79:     //"VNTSMS"
         pExportFile = new networkreconciliation::VisaSMS601ExportFile();
         break;
      case 80:     //"MCI884"
         pExportFile = new networkreconciliation::MasterCardT884ExportFile();
         break;
      case 81:     //"VSS130"
         pExportFile = new networkreconciliation::VisaVSS130ExportFile();
         break;
      case 82:     //"VSS900"
         pExportFile = new networkreconciliation::VisaVSS900ExportFile();
         break;
      case 83:     //"MERCTL"
         pExportFile = new totalscommand::MerchantControlFile();
         break;
      case 84:     //"MERREV"
         pExportFile = new totalscommand::MerchantRevenue();
         break;
      case 85:     //"FEEDIS","FEEMCI","FEEVNT"
         pExportFile = new networkreconciliation::NetworkFeeWorksheet();
         break;
      case 86:     //"DSPDIS","DSPMCI","DSPVNT"
         pExportFile = new networkreconciliation::NetworkDisputeWorksheet();
         break;
      case 87:     //"MEROPN"
         pExportFile = new networkreconciliation::OpenItemWorksheet();
         break;
      case 88:     //"TIBILL"
         pExportFile = new exceptionfile::TIBillingFile();
         break;
      case 89:     //"FINMBL"
         pExportFile = new managementinformation::FinancialBillingFile();
         break;
      case 90:     //"EMSMBL"
         pExportFile = new exceptionfile::ExceptionBillingFile();
         break;
      case 91:     //"FINDTR"
         pExportFile = new totalscommand::DailyTotalsRecap();
         break;
      case 92:     //"TRMFIA"
         pExportFile = new totalscommand::TerminalForeignItemsAnalysis();
         break;
      case 93:     //"CRDFIA"
         pExportFile = new totalscommand::CardholderForeignItemsAnalysis();
         break;
      case 94:     //"TFATM1"
         pExportFile = new totalscommand::TransfundATMReport();
         break;
      case 95:     //"TRMBAL"
         pExportFile = new totalscommand::TerminalCashBalance();
         break;
      case 96:     //"ASXRPT"
         pExportFile = new totalscommand::AcquirerSurchargeActivityReport();
         break;
      case 97:     //"QMRVNI","QM1VNI","QM2VNI","QM3VNI","QM4VNI"
         pExportFile = new managementinformation::VisaQuarterlyReport();
         break;
      case 98:     //"QMRMCA","QM1MCA","QM2MCA","QMRMDA","QM1MDA","QM2MDA"
         pExportFile = new managementinformation::MastercardAcquiringReport();
         break;
      case 99:     //"QMRMCI","QM1MCI","QM2MCI"
         pExportFile = new managementinformation::MasterCardQuarterlyReport();
         break;
      case 100:    //"QMRCRI","QM1CRI"
         pExportFile = new managementinformation::CirrusIssuingQuarterlyReport();
         break;
      case 101:    //"QMRMSI","QM1MSI"
         pExportFile = new managementinformation::MaestroIssuingQuarterlyReport();
         break;
      case 102:    //"QMRMSA","QM1MSA"
         pExportFile = new managementinformation::MaestroAcquiringQuarterlyReport();
         break;
      case 103:    //"QMRCRA","QM1CRA","QM2CRA"
         pExportFile = new managementinformation::CirrusAcquiringQuarterlyReport();
         break;
      case 104:    //"ATMCFC"
         pExportFile = new totalscommand::ATMCashForecast();
         break;
      case 105:    //"QMRILK","QM1ILK"
         pExportFile = new managementinformation::InterlinkQuarterlyReport();
         break;
      case 106:    //"QMRPLS","QM1PLS"
         pExportFile = new managementinformation::PlusQuarterlyReport();
         break;
      case 107:    //"GLPEHB","GLPMCI","GLPVNT"
         pExportFile = new networkreconciliation::GeneralLedgerPost();
         break;
      case 108:    //"GL1EHB"
         pExportFile = new networkreconciliation::SecondaryGeneralLedgerPost();
         break;
      case 109:    //"GL2EHB"
         pExportFile = new networkreconciliation::CorrectiveGeneralLedgerPost();
         break;
      case 110:    //"QMRVNA","QM1VNA"
         pExportFile = new managementinformation::VisaAcquiringQuarterlyReport();
         break;
      case 111:    //"ACCTNG" 
         pExportFile = new ems::AccountFile();
         break;
      case 112:    //"SAPMBL"
         pExportFile = new managementinformation::SAPBillingFile();
         break;
      case 113:    //"BILMIS"
         pExportFile = new managementinformation::AIMSBillingItemSummaryReport();
         break;
      case 114:    //"VSS110"
         pExportFile = new networkreconciliation::VisaVSS110ExportFile();
         break;
      case 115:    //"VSS120"
         pExportFile = new networkreconciliation::VisaVSS120ExportFile();
         break;
      case 116:    //"VNTBII"
         pExportFile = new networkreconciliation::VisaBaseIIExportFile();
         break;
      case 117:    //"ESESTR" ,"ESECPP","ESECPY","EFESTR","EFECPP","EFECPY"
         pExportFile = new starexception::StarInterfaceActivityExport();
         break;
      case 118:    //"QMRPLI","QM2PLI"
         pExportFile = new managementinformation::PlusIssuingQuarterlyReport();
         break;
      case 119:    //"ARFMAC"
         pExportFile = new postingfile::ARFMACExportFile();
         break;
      case 120:    //"COFMBR"
         pExportFile = new managementinformation::COFMonthlyBillingReport();
         break;
      case 121:    //"FINCOF"
         pExportFile = new totalscommand::FinancialCostOfFunds();
         break;
      case 122:    //"SCMDEL"
         pExportFile = new managementinformation::ScoreCardMaintenanceFile();
         break;
      case 123:   //"FEEBLL"
         pExportFile = new exceptionfile::DisputeFeeBillingFile();
         break;
      case 124:   //"UAEFEE"
         pExportFile = new exceptionfile::CBUAEDisputeBillingFile();
         break;
      case 125://FINHRS
         pExportFile = new managementinformation::HourlyTransactionsFile();
          break;
      case 126://FINHRR
         pExportFile = new managementinformation::HourlyTransactionsReport();
          break;
      case 127://DSPNET
         pExportFile = new managementinformation::AdjustmentActivityFile();
         break;
      case 128://EXPNET
         pExportFile = new managementinformation::ExceptionActivityReport();
         break;
      case 129: //AUTHMR
         pExportFile = new managementinformation::AuthMaxMonthlyReport();
         break;
      case 130: //MCISAR
         pExportFile = new mastercardexception::MasterCardSAFEAuditReport();
         break;
      case 131: //"MCISCR" ,"MCCSCR" 
         pExportFile = new mastercardexception::MasterCardSAFEConfirmationReport();
         break;
      case 132:    //"ESISTR" ,"ESICPP","ESICPY"  - Exception Document upload for STR, CPP, CPY 
         pExportFile = new starexception::StarImageExport();
         break;
      case 133:    //CBEMCI
         pExportFile = new mastercardexception::SAFECardBaseFrdoutFile();
         break;
      case 134:    //CHCLMF
         pExportFile = new managementinformation::LoyaltyMonthlyFile();
         break;
      case 135:    //AUEXPR
         pExportFile = new reconciliationfile::AutoReconExceptionReport();
         break;
      case 136:
         pExportFile = new managementinformation::MonthlyIFDTrancationSmartBaseFile();
         break;
      case 137:
         pExportFile = new managementinformation::MonthlyDealerFeeSmartBaseFile();
         break;
      case 138:     //"STPRPT","STPFIL"
         pExportFile = new managementinformation::StopPaymentReport();
         break;
   }
   *pExportFile = hExportFile;
   return pExportFile;
  //## end ExportFileFactory::create%41E97F92003E.body
}

// Additional Declarations
  //## begin ExportFileFactory%41E973D2035B.declarations preserve=yes
  //## end ExportFileFactory%41E973D2035B.declarations

//## begin module%41EC3CA300DA.epilog preserve=yes
//## end module%41EC3CA300DA.epilog
