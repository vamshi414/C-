// Copyright (c) 1998 - 2009
// Fidelity National Information Services
// $Date:   Jul 06 2010 01:22:08  $ $Author:   D02684  $ $Revision:   1.12  $
#ifdef MVS
#pragma runopts(STACK(128K,128K,ANY,KEEP),TRAP(ON,NOSPIE))
#endif

#include "CXODIF11.hpp"
#include "CXODSI01.hpp"
#include "CXODBP01.hpp"
#include "CXODMN05.hpp"
#include "CXODDZ01.hpp"

#include "CXODPS06.hpp"
   pApplication = new SwitchInterface();
   pApplication->parseCommandLine(argc,argv);
   new dnplatform::DNPlatform();
   ((SwitchInterface*)pApplication)->setMessageProcessor(new B24MessageProcessor);
   int iRC = 0;
   {
      iRC = pApplication->initialize();
      UseCase hUseCase("BASE24","## BI01 START BI");
      if (iRC == -1)
         UseCase::setSuccess(false);
   }
   if (iRC == 0)
      pApplication->run();
#include "CXODPS07.hpp"
