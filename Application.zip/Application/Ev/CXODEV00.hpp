//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3DDE42EB033C.cm preserve=no
//	$Date:   Jan 31 2021 23:11:28  $ $Author:   e5614616  $ $Revision:   1.6  $
//## end module%3DDE42EB033C.cm

//## begin module%3DDE42EB033C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3DDE42EB033C.cp

//## Module: CXOPEV00%3DDE42EB033C; Package specification
//## Subsystem: EV%3DDE417A02EE
//## Source file: C:\Devel_11 month\ConnexPlatform\Server\Application\Ev\CXODEV00.hpp

#ifndef CXOPEV00_h
#define CXOPEV00_h 1

//## begin module%3DDE42EB033C.additionalIncludes preserve=no
//## end module%3DDE42EB033C.additionalIncludes

//## begin module%3DDE42EB033C.includes preserve=yes
//## end module%3DDE42EB033C.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class DateTime;
class Trace;
class Log;
class Console;
class CommandMessage;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Platform_CAT%4084313502DE
namespace platform {
class Platform;
} // namespace platform

class Calendar;

//## begin module%3DDE42EB033C.declarations preserve=no
//## end module%3DDE42EB033C.declarations

//## begin module%3DDE42EB033C.additionalDeclarations preserve=yes
//## end module%3DDE42EB033C.additionalDeclarations


//## begin EventManager%3DDE462C0000.preface preserve=yes
//## end EventManager%3DDE462C0000.preface

//## Class: EventManager%3DDE462C0000
//	<body>
//	<title>CG
//	<h1>EV
//	<h2>AB
//	<h3>System Flow
//	<p>
//	Any operator command supported by the DataNavigator
//	server can be scheduled for automatic execution by the
//	Event Manager service (EV).
//	</p>
//	<img src=CXOCEV00.gif>
//	<title>OG
//	<h1>EV
//	<h2>AB
//	<h3>System Flow
//	<p>
//	Any operator command supported by the DataNavigator
//	server can be scheduled for automatic execution by the
//	Event Manager service (EV).
//	</p>
//	<img src=CXOOEV00.gif>
//	</body>
//## Category: Connex Application::EventManager_CAT (EV)%3DDE3FFD031C
//## Subsystem: EV%3DDE417A02EE
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3DDE4BD100EA;IF::Console { -> F}
//## Uses: <unnamed>%3DDE4C6E00FA;database::Database { -> F}
//## Uses: <unnamed>%3DDE4C74009C;IF::DateTime { -> F}
//## Uses: <unnamed>%3DDE4C790399;IF::Trace { -> F}
//## Uses: <unnamed>%3DDE4C7F038A;monitor::UseCase { -> F}
//## Uses: <unnamed>%3DE2574703B9;IF::Message { -> F}
//## Uses: <unnamed>%3E3800AE00FA;IF::CommandMessage { -> F}
//## Uses: <unnamed>%40ABA10801B5;platform::Platform { -> F}
//## Uses: <unnamed>%44D2507102BF;IF::Log { -> F}
//## Uses: <unnamed>%472873B602CE;reusable::Query { -> F}

class DllExport EventManager : public process::Application  //## Inherits: <unnamed>%3DDE4A6D030D
{
  //## begin EventManager%3DDE462C0000.initialDeclarations preserve=yes
  //## end EventManager%3DDE462C0000.initialDeclarations

  public:
    //## Constructors (generated)
      EventManager();

    //## Destructor (generated)
      virtual ~EventManager();


    //## Other Operations (specified)
      //## Operation: initialize%3DDEACC90280
      int initialize ();

      //## Operation: update%3DDE66450203
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin EventManager%3DDE462C0000.public preserve=yes
      //## end EventManager%3DDE462C0000.public

  protected:

    //## Other Operations (specified)
      //## Operation: onRefresh%3DDE669C01E4
      virtual int onRefresh ();

    // Additional Protected Declarations
      //## begin EventManager%3DDE462C0000.protected preserve=yes
      //## end EventManager%3DDE462C0000.protected

  private:
    // Additional Private Declarations
      //## begin EventManager%3DDE462C0000.private preserve=yes
      //## end EventManager%3DDE462C0000.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Connex Application::EventManager_CAT (EV)::<unnamed>%4728944E0222
      //## Role: EventManager::<m_pCalendar>%4728944F0128
      //## begin EventManager::<m_pCalendar>%4728944F0128.role preserve=no  public: Calendar { -> RFHgN}
      Calendar *m_pCalendar;
      //## end EventManager::<m_pCalendar>%4728944F0128.role

    // Additional Implementation Declarations
      //## begin EventManager%3DDE462C0000.implementation preserve=yes
      //## end EventManager%3DDE462C0000.implementation

};

//## begin EventManager%3DDE462C0000.postscript preserve=yes
//## end EventManager%3DDE462C0000.postscript

//## begin module%3DDE42EB033C.epilog preserve=yes
//## end module%3DDE42EB033C.epilog


#endif
