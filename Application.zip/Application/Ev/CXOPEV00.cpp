//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3DDE42F3008C.cm preserve=no
//	$Date:   Feb 01 2021 00:14:32  $ $Author:   e5614616  $ $Revision:   1.19  $
//## end module%3DDE42F3008C.cm

//## begin module%3DDE42F3008C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3DDE42F3008C.cp

//## Module: CXOPEV00%3DDE42F3008C; Package body
//## Subsystem: EV%3DDE417A02EE
//## Source file: C:\Devel_11 month\ConnexPlatform\Server\Application\Ev\CXOPEV00.cpp

//## begin module%3DDE42F3008C.additionalIncludes preserve=no
//## end module%3DDE42F3008C.additionalIncludes

//## begin module%3DDE42F3008C.includes preserve=yes
#include "CXODIF11.hpp"
//## end module%3DDE42F3008C.includes

#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF42_h
#include "CXODIF42.hpp"
#endif
#ifndef CXOSPZ01_h
#include "CXODPZ01.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSRU11_h
#include "CXODRU11.hpp"
#endif
#ifndef CXOSEV02_h
#include "CXODEV02.hpp"
#endif
#ifndef CXOPEV00_h
#include "CXODEV00.hpp"
#endif


//## begin module%3DDE42F3008C.declarations preserve=no
//## end module%3DDE42F3008C.declarations

//## begin module%3DDE42F3008C.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new EventManager();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%3DDE42F3008C.additionalDeclarations


// Class EventManager 

EventManager::EventManager()
  //## begin EventManager::EventManager%3DDE462C0000_const.hasinit preserve=no
      : m_pCalendar(0)
  //## end EventManager::EventManager%3DDE462C0000_const.hasinit
  //## begin EventManager::EventManager%3DDE462C0000_const.initialization preserve=yes
  //## end EventManager::EventManager%3DDE462C0000_const.initialization
{
  //## begin EventManager::EventManager%3DDE462C0000_const.body preserve=yes
   memcpy(m_sID,"EV00",4);
  //## end EventManager::EventManager%3DDE462C0000_const.body
}


EventManager::~EventManager()
{
  //## begin EventManager::~EventManager%3DDE462C0000_dest.body preserve=yes
   Database::instance()->detach(this);
   delete m_pCalendar;
  //## end EventManager::~EventManager%3DDE462C0000_dest.body
}



//## Other Operations (implementation)
int EventManager::initialize ()
{
  //## begin EventManager::initialize%3DDEACC90280.body preserve=yes
   new platform::Platform();
   int i = Application::initialize();
   UseCase hUseCase("FD","## EV00 START EV");
   if ( i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   platform::Platform::instance()->createDatabaseFactory();
   m_pCalendar = new Calendar();
   Database::instance()->attach(this);
   Database::instance()->connect();
   return 0;
  //## end EventManager::initialize%3DDEACC90280.body
}

int EventManager::onRefresh ()
{
  //## begin EventManager::onRefresh%3DDE669C01E4.body preserve=yes
   m_pCalendar->load();
   return Application::onRefresh();
  //## end EventManager::onRefresh%3DDE669C01E4.body
}

void EventManager::update (Subject* pSubject)
{
  //## begin EventManager::update%3DDE66450203.body preserve=yes
   Application::update(pSubject);
  //## end EventManager::update%3DDE66450203.body
}

// Additional Declarations
  //## begin EventManager%3DDE462C0000.declarations preserve=yes
  //## end EventManager%3DDE462C0000.declarations

//## begin module%3DDE42F3008C.epilog preserve=yes
//## end module%3DDE42F3008C.epilog
