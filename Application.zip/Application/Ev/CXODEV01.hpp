//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3DDE4592029F.cm preserve=no
//	$Date:   Sep 25 2018 11:53:16  $ $Author:   e1009839  $ $Revision:   1.10  $
//## end module%3DDE4592029F.cm

//## begin module%3DDE4592029F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3DDE4592029F.cp

//## Module: CXOSEV01%3DDE4592029F; Package specification
//## Subsystem: EV%3DDE417A02EE
//## Source file: C:\bV02.9D.R001\Windows\Build\ConnexPlatform\Server\Application\Ev\CXODEV01.hpp

#ifndef CXOSEV01_h
#define CXOSEV01_h 1

//## begin module%3DDE4592029F.additionalIncludes preserve=no
//## end module%3DDE4592029F.additionalIncludes

//## begin module%3DDE4592029F.includes preserve=yes
#include <map>
//## end module%3DDE4592029F.includes

#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Statement;
class SelectStatement;
class Query;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Trace;
class Extract;
class Message;
class CommandMessage;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class Date;
class Clock;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class DatabaseFactory;

} // namespace database

//## begin module%3DDE4592029F.declarations preserve=no
//## end module%3DDE4592029F.declarations

//## begin module%3DDE4592029F.additionalDeclarations preserve=yes
//## end module%3DDE4592029F.additionalDeclarations


//## begin Event%3DDE468E034B.preface preserve=yes
//## end Event%3DDE468E034B.preface

//## Class: Event%3DDE468E034B; protected
//## Category: Connex Application::EventManager_CAT (EV)%3DDE3FFD031C
//## Subsystem: EV%3DDE417A02EE
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3DDE520900FA;database::Database { -> F}
//## Uses: <unnamed>%3DDE520B0251;database::DatabaseFactory { -> F}
//## Uses: <unnamed>%3DDE520E003E;monitor::UseCase { -> F}
//## Uses: <unnamed>%3DE24D99004E;timer::Clock { -> F}
//## Uses: <unnamed>%3DE24D9C004E;reusable::SelectStatement { -> F}
//## Uses: <unnamed>%3DE25708030D;IF::Message { -> F}
//## Uses: <unnamed>%3DE2965A0157;timer::Date { -> F}
//## Uses: <unnamed>%3DE29868009C;reusable::Statement { -> F}
//## Uses: <unnamed>%3E3800F20177;IF::CommandMessage { -> F}
//## Uses: <unnamed>%470BE7A7005D;IF::Extract { -> F}
//## Uses: <unnamed>%47277D540167;IF::Trace { -> F}
//## Uses: <unnamed>%472873090196;reusable::Query { -> F}

class DllExport Event : public reusable::Object  //## Inherits: <unnamed>%4728AAFC035B
{
  //## begin Event%3DDE468E034B.initialDeclarations preserve=yes
  //## end Event%3DDE468E034B.initialDeclarations

  public:
    //## Constructors (generated)
      Event();

      Event(const Event &right);

    //## Destructor (generated)
      virtual ~Event();

    //## Assignment Operation (generated)
      Event & operator=(const Event &right);


    //## Other Operations (specified)
      //## Operation: bind%47288D0D0271
      void bind (reusable::Query& hQuery);

      //## Operation: bind2%4728D9DE00CB
      void bind2 (reusable::Query& hQuery);

      //## Operation: execute%47289E2E0280
      bool execute ();

      //## Operation: getTSTAMP_NEXT%5B518DF90039
      const string& getTSTAMP_NEXT (int iIndex) const
      {
        //## begin Event::getTSTAMP_NEXT%5B518DF90039.body preserve=yes
         return m_strTSTAMP_NEXT[iIndex];
        //## end Event::getTSTAMP_NEXT%5B518DF90039.body
      }

      //## Operation: recover%4728DADE01E4
      bool recover ();

      //## Operation: reschedule%5BA8FA1D033B
      bool reschedule ();

      //## Operation: schedule%3DE27BF702AF
      bool schedule ();

      //## Operation: set%5BA8EA9A00B6
      void set (reusable::Table& hTable);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: COMMAND%3DDE86D2035B
      const string& getCOMMAND () const
      {
        //## begin Event::getCOMMAND%3DDE86D2035B.get preserve=no
        return m_strCOMMAND;
        //## end Event::getCOMMAND%3DDE86D2035B.get
      }


      //## Attribute: EVCLID%3DDE886702EE
      const string& getEVCLID () const
      {
        //## begin Event::getEVCLID%3DDE886702EE.get preserve=no
        return m_strEVCLID;
        //## end Event::getEVCLID%3DDE886702EE.get
      }

      void setEVCLID (const string& value)
      {
        //## begin Event::setEVCLID%3DDE886702EE.set preserve=no
        m_strEVCLID = value;
        //## end Event::setEVCLID%3DDE886702EE.set
      }


      //## Attribute: EVNTDAY%46FB6B1000DB
      const string& getEVNTDAY () const
      {
        //## begin Event::getEVNTDAY%46FB6B1000DB.get preserve=no
        return m_strEVNTDAY;
        //## end Event::getEVNTDAY%46FB6B1000DB.get
      }


      //## Attribute: EVNTTIME%3DDE85DF004E
      const string& getEVNTTIME () const
      {
        //## begin Event::getEVNTTIME%3DDE85DF004E.get preserve=no
        return m_strEVNTTIME;
        //## end Event::getEVNTTIME%3DDE85DF004E.get
      }


      //## Attribute: NETCMD%5A2B13600207
      const string& getNETCMD () const
      {
        //## begin Event::getNETCMD%5A2B13600207.get preserve=no
        return m_strNETCMD;
        //## end Event::getNETCMD%5A2B13600207.get
      }


      //## Attribute: NETCOPT1%5A2B139D0068
      const string& getNETCOPT1 () const
      {
        //## begin Event::getNETCOPT1%5A2B139D0068.get preserve=no
        return m_strNETCOPT1;
        //## end Event::getNETCOPT1%5A2B139D0068.get
      }


    // Additional Public Declarations
      //## begin Event%3DDE468E034B.public preserve=yes
      //## end Event%3DDE468E034B.public

  protected:
    // Additional Protected Declarations
      //## begin Event%3DDE468E034B.protected preserve=yes
      //## end Event%3DDE468E034B.protected

  private:
    // Additional Private Declarations
      //## begin Event%3DDE468E034B.private preserve=yes
      //## end Event%3DDE468E034B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: AUTOREC%3DDE864300DA
      //## begin Event::AUTOREC%3DDE864300DA.attr preserve=no  private: string {U} 
      string m_strAUTOREC;
      //## end Event::AUTOREC%3DDE864300DA.attr

      //## begin Event::COMMAND%3DDE86D2035B.attr preserve=no  public: string {V} 
      string m_strCOMMAND;
      //## end Event::COMMAND%3DDE86D2035B.attr

      //## begin Event::EVCLID%3DDE886702EE.attr preserve=no  public: string {V} 
      string m_strEVCLID;
      //## end Event::EVCLID%3DDE886702EE.attr

      //## begin Event::EVNTDAY%46FB6B1000DB.attr preserve=no  public: string {V} 
      string m_strEVNTDAY;
      //## end Event::EVNTDAY%46FB6B1000DB.attr

      //## begin Event::EVNTTIME%3DDE85DF004E.attr preserve=no  public: string {V} 
      string m_strEVNTTIME;
      //## end Event::EVNTTIME%3DDE85DF004E.attr

      //## begin Event::NETCMD%5A2B13600207.attr preserve=no  public: string {V} 
      string m_strNETCMD;
      //## end Event::NETCMD%5A2B13600207.attr

      //## begin Event::NETCOPT1%5A2B139D0068.attr preserve=no  public: string {V} 
      string m_strNETCOPT1;
      //## end Event::NETCOPT1%5A2B139D0068.attr

      //## Attribute: NETCOPT2%3DDE867B00DA
      //## begin Event::NETCOPT2%3DDE867B00DA.attr preserve=no  private: string {U} 
      string m_strNETCOPT2;
      //## end Event::NETCOPT2%3DDE867B00DA.attr

      //## Attribute: NETCOPT3%3E660B13002E
      //## begin Event::NETCOPT3%3E660B13002E.attr preserve=no  private: string {U} 
      string m_strNETCOPT3;
      //## end Event::NETCOPT3%3E660B13002E.attr

      //## Attribute: NETCOPT4%4F0D36DB02A6
      //## begin Event::NETCOPT4%4F0D36DB02A6.attr preserve=no  private: string {U} 
      string m_strNETCOPT4;
      //## end Event::NETCOPT4%4F0D36DB02A6.attr

      //## Attribute: NETCOPT5%4F0D36DC0333
      //## begin Event::NETCOPT5%4F0D36DC0333.attr preserve=no  private: string {U} 
      string m_strNETCOPT5;
      //## end Event::NETCOPT5%4F0D36DC0333.attr

      //## Attribute: NETCOPT6%4F0D36DE0229
      //## begin Event::NETCOPT6%4F0D36DE0229.attr preserve=no  private: string {U} 
      string m_strNETCOPT6;
      //## end Event::NETCOPT6%4F0D36DE0229.attr

      //## Attribute: NETCOPT7%4F0D36E000C2
      //## begin Event::NETCOPT7%4F0D36E000C2.attr preserve=no  private: string {U} 
      string m_strNETCOPT7;
      //## end Event::NETCOPT7%4F0D36E000C2.attr

      //## Attribute: NETCOPT8%4F0D36E10352
      //## begin Event::NETCOPT8%4F0D36E10352.attr preserve=no  private: string {U} 
      string m_strNETCOPT8;
      //## end Event::NETCOPT8%4F0D36E10352.attr

      //## Attribute: PROCID%3DDE865D0280
      //## begin Event::PROCID%3DDE865D0280.attr preserve=no  private: string {U} 
      string m_strPROCID;
      //## end Event::PROCID%3DDE865D0280.attr

      //## Attribute: TSTAMP_NEXT%3DDEB1F202DE
      //## begin Event::TSTAMP_NEXT%3DDEB1F202DE.attr preserve=no  public: string[2] {V} 
      string m_strTSTAMP_NEXT[2];
      //## end Event::TSTAMP_NEXT%3DDEB1F202DE.attr

    // Additional Implementation Declarations
      //## begin Event%3DDE468E034B.implementation preserve=yes
      //## end Event%3DDE468E034B.implementation

};

//## begin Event%3DDE468E034B.postscript preserve=yes
//## end Event%3DDE468E034B.postscript

//## begin module%3DDE4592029F.epilog preserve=yes
//## end module%3DDE4592029F.epilog


#endif
