//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64773DA50187.cm preserve=no
//## end module%64773DA50187.cm

//## begin module%64773DA50187.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64773DA50187.cp

//## Module: CXOPFF00%64773DA50187; Package specification
//## Subsystem: FF%64773D4C02C1
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\Dn\Server\Application\Ff\CXODFF00.hpp

#ifndef CXOPFF00_h
#define CXOPFF00_h 1

//## begin module%64773DA50187.additionalIncludes preserve=no
//## end module%64773DA50187.additionalIncludes

//## begin module%64773DA50187.includes preserve=yes
//## end module%64773DA50187.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif

//## Modelname: DataNavigator Foundation::DNPlatform_CAT%408511960157
namespace dnplatform {
class DNPlatform;
} // namespace dnplatform

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class GenericSegment;
} // namespace segment

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Timer_CAT%3451F2410231
namespace timer {
class MinuteTimer;
} // namespace timer

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
class ExportFile;
class FileFormatFactory;
} // namespace database

class FileFormatter;
//## Modelname: Data Distribution::LegacyFile_CAT%64BF1A7A002E
namespace legacyfile {
class ImportExportFile;

} // namespace legacyfile

//## begin module%64773DA50187.declarations preserve=no
//## end module%64773DA50187.declarations

//## begin module%64773DA50187.additionalDeclarations preserve=yes
//## end module%64773DA50187.additionalDeclarations


//## begin FileFormatter%64773BB20389.preface preserve=yes
//## end FileFormatter%64773BB20389.preface

//## Class: FileFormatter%64773BB20389
//## Category: Data Distribution::FileFormatter_CAT (FF)%64BF1831026B
//## Subsystem: FF%64773D4C02C1
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6478984B028F;segment::GenericSegment { -> F}
//## Uses: <unnamed>%64789C010088;database::Database { -> F}
//## Uses: <unnamed>%64789C03013F;database::FileFormatFactory { -> F}
//## Uses: <unnamed>%64789C0501B0;dnplatform::DNPlatform { -> F}
//## Uses: <unnamed>%64789C08010F;IF::Extract { -> F}
//## Uses: <unnamed>%64789C0B0019;monitor::UseCase { -> F}
//## Uses: <unnamed>%64789C0E0001;FileFormatter { -> F}
//## Uses: <unnamed>%64789C10011F;timer::MinuteTimer { -> F}
//## Uses: <unnamed>%64789EEF000E;database::ExportFile { -> F}
//## Uses: <unnamed>%6482338E0107;legacyfile::ImportExportFile { -> F}

class DllExport FileFormatter : public process::Application  //## Inherits: <unnamed>%64773BD6009B
{
  //## begin FileFormatter%64773BB20389.initialDeclarations preserve=yes
  //## end FileFormatter%64773BB20389.initialDeclarations

  public:
    //## Constructors (generated)
      FileFormatter();

    //## Destructor (generated)
      virtual ~FileFormatter();


    //## Other Operations (specified)
      //## Operation: initialize%64773C380374
      virtual int initialize ();

      //## Operation: onReset%64773C8103C4
      int onReset (Message& hMessage);

      //## Operation: update%64773C7302A6
      //	Interprets the inbound Message and calls:
      //
      //	   Application::onConfirm
      //	   Application::onMessage
      //	   Application::onNotify
      //	   Application::onQuiesce
      //	   Application::onRefresh
      //	   Application::onReset
      //	   Application::shutdown
      //	   Timer::elapsed
      //## Postconditions:
      //	<body>
      //	<title>CG
      //	<h1>FM
      //	<h2>FO
      //	<h3>Messages
      //	<p>
      //	Messages displayed by the DataNavigator services are
      //	saved in:
      //	<ul>
      //	<li><i>qualify</i>.CONSOLE_MSG
      //	</ul>
      //	</body>
      virtual void update (Subject* pSubject);

    // Additional Public Declarations
      //## begin FileFormatter%64773BB20389.public preserve=yes
      //## end FileFormatter%64773BB20389.public

  protected:
    // Additional Protected Declarations
      //## begin FileFormatter%64773BB20389.protected preserve=yes
      //## end FileFormatter%64773BB20389.protected

  private:
    // Additional Private Declarations
      //## begin FileFormatter%64773BB20389.private preserve=yes
      //## end FileFormatter%64773BB20389.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Class%64773CC40315
      //## begin FileFormatter::Class%64773CC40315.attr preserve=no  private: multimap<string,string,less<string> >  {U} 
      multimap<string,string,less<string> >  m_hClass;
      //## end FileFormatter::Class%64773CC40315.attr

      //## Attribute: ExportFile%64773D0200FD
      //## begin FileFormatter::ExportFile%64773D0200FD.attr preserve=no  private: database::ExportFile* {U} 
      database::ExportFile* m_pExportFile;
      //## end FileFormatter::ExportFile%64773D0200FD.attr

      //## Attribute: Value%64773CE50005
      //## begin FileFormatter::Value%64773CE50005.attr preserve=no  private: set<string> {U} 
      set<string> m_hValue;
      //## end FileFormatter::Value%64773CE50005.attr

    // Additional Implementation Declarations
      //## begin FileFormatter%64773BB20389.implementation preserve=yes
      //## end FileFormatter%64773BB20389.implementation

};

//## begin FileFormatter%64773BB20389.postscript preserve=yes
//## end FileFormatter%64773BB20389.postscript

//## begin module%64773DA50187.epilog preserve=yes
//## end module%64773DA50187.epilog


#endif
