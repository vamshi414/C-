//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%64773DA802F3.cm preserve=no
//## end module%64773DA802F3.cm

//## begin module%64773DA802F3.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%64773DA802F3.cp

//## Module: CXOPFF00%64773DA802F3; Package body
//## Subsystem: FF%64773D4C02C1
//## Source file: C:\Repos\Datanavigatorserver\Windows\Build\Dn\Server\Application\Ff\CXOPFF00.cpp

//## begin module%64773DA802F3.additionalIncludes preserve=no
//## end module%64773DA802F3.additionalIncludes

//## begin module%64773DA802F3.includes preserve=yes
//## end module%64773DA802F3.includes

#ifndef CXOSBS23_h
#include "CXODBS23.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB69_h
#include "CXODDB69.hpp"
#endif
#ifndef CXOSDZ01_h
#include "CXODDZ01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOPFF00_h
#include "CXODFF00.hpp"
#endif
#ifndef CXOSTM02_h
#include "CXODTM02.hpp"
#endif
#ifndef CXOSDB25_h
#include "CXODDB25.hpp"
#endif
#ifndef CXOSFI01_h
#include "CXODFI01.hpp"
#endif


//## begin module%64773DA802F3.declarations preserve=no
//## end module%64773DA802F3.declarations

//## begin module%64773DA802F3.additionalDeclarations preserve=yes
#include "CXODPS06.hpp"
   pApplication = new FileFormatter();
   pApplication->parseCommandLine(argc,argv);
   if (pApplication->initialize() == 0)
      pApplication->run();
#include "CXODPS07.hpp"
//## end module%64773DA802F3.additionalDeclarations


// Class FileFormatter 

FileFormatter::FileFormatter()
  //## begin FileFormatter::FileFormatter%64773BB20389_const.hasinit preserve=no
  //## end FileFormatter::FileFormatter%64773BB20389_const.hasinit
  //## begin FileFormatter::FileFormatter%64773BB20389_const.initialization preserve=yes
  //## end FileFormatter::FileFormatter%64773BB20389_const.initialization
{
  //## begin FileFormatter::FileFormatter%64773BB20389_const.body preserve=yes
   memcpy(m_sID, "FF00", 4);
  //## end FileFormatter::FileFormatter%64773BB20389_const.body
}


FileFormatter::~FileFormatter()
{
  //## begin FileFormatter::~FileFormatter%64773BB20389_dest.body preserve=yes
  //## end FileFormatter::~FileFormatter%64773BB20389_dest.body
}



//## Other Operations (implementation)
int FileFormatter::initialize ()
{
  //## begin FileFormatter::initialize%64773C380374.body preserve=yes
   new dnplatform::DNPlatform();
   int i = Application::initialize();
   UseCase hUseCase("DIST","## FF00 START FF");
   if (i == -1)
   {
      UseCase::setSuccess(false);
      return -1;
   }
   vector<string> hSpecValues;
   Extract::instance()->getSpec("FF00", hSpecValues);
   copy(hSpecValues.begin(), hSpecValues.end(), inserter(m_hValue, m_hValue.end()));
   platform::Platform::instance()->createDatabaseFactory();
   Database::instance()->connect();
   MinuteTimer::instance()->attach(this);
   legacyfile::ImportExportFile x; // to load FI DLL
   return 0;
  //## end FileFormatter::initialize%64773C380374.body
}

int FileFormatter::onReset (Message& hMessage)
{
  //## begin FileFormatter::onReset%64773C8103C4.body preserve=yes
   update(MinuteTimer::instance());   
   return 0;
  //## end FileFormatter::onReset%64773C8103C4.body
}

void FileFormatter::update (Subject* pSubject)
{
  //## begin FileFormatter::update%64773C7302A6.body preserve=yes
   if (pSubject == MinuteTimer::instance())
   {
      set<string>::iterator p;
      for (p = m_hValue.begin(); p != m_hValue.end(); ++p)
      {
         m_pExportFile = FileFormatFactory::instance()->create((*p));
         if (m_pExportFile != 0)
         {
            m_pExportFile->create();
            delete m_pExportFile;
            m_pExportFile = 0;
         }
      }
   }
   Application::update(pSubject);
  //## end FileFormatter::update%64773C7302A6.body
}

// Additional Declarations
  //## begin FileFormatter%64773BB20389.declarations preserve=yes
  //## end FileFormatter%64773BB20389.declarations

//## begin module%64773DA802F3.epilog preserve=yes
//## end module%64773DA802F3.epilog
