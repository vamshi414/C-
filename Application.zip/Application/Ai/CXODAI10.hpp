//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3C61388C00BB.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C61388C00BB.cm

//## begin module%3C61388C00BB.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3C61388C00BB.cp

//## Module: CXOSAI10%3C61388C00BB; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Pvcswork\Dn\Server\Application\Ai\CXODAI10.hpp

#ifndef CXOSAI10_h
#define CXOSAI10_h 1

//## begin module%3C61388C00BB.additionalIncludes preserve=no
//## end module%3C61388C00BB.additionalIncludes

//## begin module%3C61388C00BB.includes preserve=yes
// $Date:   Jan 31 2018 14:07:08  $ $Author:   e1009839  $ $Revision:   1.13  $
//## end module%3C61388C00BB.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialAdjustmentExtensionSegment;
class FinancialSettlementSegment;
class FinancialAdjustmentSegment;
class FinancialBaseSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Foundation::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
class DateTime;
} // namespace IF

class AdvantageMessageProcessor;

//## begin module%3C61388C00BB.declarations preserve=no
//## end module%3C61388C00BB.declarations

//## begin module%3C61388C00BB.additionalDeclarations preserve=yes
//## end module%3C61388C00BB.additionalDeclarations


//## begin AdvantageCirrusEx92Adjustment%3C61331503D8.preface preserve=yes
//## end AdvantageCirrusEx92Adjustment%3C61331503D8.preface

//## Class: AdvantageCirrusEx92Adjustment%3C61331503D8
//## Category: Platform \: Advantage::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3C63DF5201D4;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%3C63DF750242;IF::Message { -> F}
//## Uses: <unnamed>%3C63DF8303D8;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C63DF9A01B5;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3C63DFA702BF;IF::DateTime { -> F}
//## Uses: <unnamed>%3C63DFAE00AB;IF::CodeTable { -> F}
//## Uses: <unnamed>%3C63E04701E4;process::Application { -> F}
//## Uses: <unnamed>%3C63E1A80399;repositorysegment::FinancialBaseSegment { -> F}
//## Uses: <unnamed>%3C63E1CD0128;repositorysegment::FinancialSettlementSegment { -> F}
//## Uses: <unnamed>%3C63E1D00222;repositorysegment::FinancialAdjustmentSegment { -> F}
//## Uses: <unnamed>%3C63E1D301D4;repositorysegment::FinancialAdjustmentExtensionSegment { -> F}

class AdvantageCirrusEx92Adjustment : public AdvantageMessage  //## Inherits: <unnamed>%3C63D7F4032C
{
  //## begin AdvantageCirrusEx92Adjustment%3C61331503D8.initialDeclarations preserve=yes
  //## end AdvantageCirrusEx92Adjustment%3C61331503D8.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageCirrusEx92Adjustment();

    //## Destructor (generated)
      virtual ~AdvantageCirrusEx92Adjustment();


    //## Other Operations (specified)
      //## Operation: insert%3C63D7FA009C
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantageCirrusEx92Adjustment%3C61331503D8.public preserve=yes
      //## end AdvantageCirrusEx92Adjustment%3C61331503D8.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageCirrusEx92Adjustment%3C61331503D8.protected preserve=yes
      //## end AdvantageCirrusEx92Adjustment%3C61331503D8.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageCirrusEx92Adjustment%3C61331503D8.private preserve=yes
      //## end AdvantageCirrusEx92Adjustment%3C61331503D8.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin AdvantageCirrusEx92Adjustment%3C61331503D8.implementation preserve=yes
      //## end AdvantageCirrusEx92Adjustment%3C61331503D8.implementation

};

//## begin AdvantageCirrusEx92Adjustment%3C61331503D8.postscript preserve=yes
//## end AdvantageCirrusEx92Adjustment%3C61331503D8.postscript

//## begin module%3C61388C00BB.epilog preserve=yes
//## end module%3C61388C00BB.epilog


#endif
