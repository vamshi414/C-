//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3C613A0C033C.cm preserve=no
//	$Date:   Mar 20 2014 07:20:08  $ $Author:   e1009839  $
//	$Revision:   1.17  $
//## end module%3C613A0C033C.cm

//## begin module%3C613A0C033C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C613A0C033C.cp

//## Module: CXOSAI15%3C613A0C033C; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.3B.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI15.hpp

#ifndef CXOSAI15_h
#define CXOSAI15_h 1

//## begin module%3C613A0C033C.additionalIncludes preserve=no
//## end module%3C613A0C033C.additionalIncludes

//## begin module%3C613A0C033C.includes preserve=yes
//## end module%3C613A0C033C.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
#ifndef CXOSRS09_h
#include "CXODRS09.hpp"
#endif
#ifndef CXOSRS42_h
#include "CXODRS42.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class AdvantageMessageProcessor;
//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class DateTime;
class Extract;
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ListSegment;

} // namespace segment

//## begin module%3C613A0C033C.declarations preserve=no
//## end module%3C613A0C033C.declarations

//## begin module%3C613A0C033C.additionalDeclarations preserve=yes
//## end module%3C613A0C033C.additionalDeclarations


//## begin AdvantageTerminalAdvice%3C61340801A5.preface preserve=yes
//## end AdvantageTerminalAdvice%3C61340801A5.preface

//## Class: AdvantageTerminalAdvice%3C61340801A5
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3C63C57C003E;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C63C58D000F;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%3C63C59D0128;IF::Message { -> F}
//## Uses: <unnamed>%3C63C5D9005D;IF::Extract { -> F}
//## Uses: <unnamed>%3C63C5FC0280;IF::DateTime { -> F}
//## Uses: <unnamed>%3C63C61A009C;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3C63C642033C;IF::CodeTable { -> F}
//## Uses: <unnamed>%3C63C64F02EE;process::Application { -> F}
//## Uses: <unnamed>%4CA0686801D9;segment::ListSegment { -> F}

class AdvantageTerminalAdvice : public AdvantageMessage  //## Inherits: <unnamed>%3C6134170119
{
  //## begin AdvantageTerminalAdvice%3C61340801A5.initialDeclarations preserve=yes
  //## end AdvantageTerminalAdvice%3C61340801A5.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageTerminalAdvice();

    //## Destructor (generated)
      virtual ~AdvantageTerminalAdvice();


    //## Other Operations (specified)
      //## Operation: insert%3C61867900EA
      virtual bool insert (IF::Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantageTerminalAdvice%3C61340801A5.public preserve=yes
      //## end AdvantageTerminalAdvice%3C61340801A5.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageTerminalAdvice%3C61340801A5.protected preserve=yes
      //## end AdvantageTerminalAdvice%3C61340801A5.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageTerminalAdvice%3C61340801A5.private preserve=yes
      //## end AdvantageTerminalAdvice%3C61340801A5.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C61869201F4
      //## Role: AdvantageTerminalAdvice::<m_hCutoffSegment>%3C618693005D
      //## begin AdvantageTerminalAdvice::<m_hCutoffSegment>%3C618693005D.role preserve=no  public: repositorysegment::CutoffSegment { -> VHgN}
      repositorysegment::CutoffSegment m_hCutoffSegment;
      //## end AdvantageTerminalAdvice::<m_hCutoffSegment>%3C618693005D.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3D63E6B002CE
      //## Role: AdvantageTerminalAdvice::<m_hDeviceAdminSegment>%3D63E6B101C5
      //## begin AdvantageTerminalAdvice::<m_hDeviceAdminSegment>%3D63E6B101C5.role preserve=no  public: repositorysegment::DeviceAdminSegment { -> VHgN}
      repositorysegment::DeviceAdminSegment m_hDeviceAdminSegment;
      //## end AdvantageTerminalAdvice::<m_hDeviceAdminSegment>%3D63E6B101C5.role

    // Additional Implementation Declarations
      //## begin AdvantageTerminalAdvice%3C61340801A5.implementation preserve=yes
      //## end AdvantageTerminalAdvice%3C61340801A5.implementation

};

//## begin AdvantageTerminalAdvice%3C61340801A5.postscript preserve=yes
//## end AdvantageTerminalAdvice%3C61340801A5.postscript

//## begin module%3C613A0C033C.epilog preserve=yes
//## end module%3C613A0C033C.epilog


#endif
