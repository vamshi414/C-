//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%542AC7CE02C5.cm preserve=no
//	$Date:   Apr 09 2018 12:45:16  $ $Author:   e1009839  $
//	$Revision:   1.4  $
//## end module%542AC7CE02C5.cm

//## begin module%542AC7CE02C5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%542AC7CE02C5.cp

//## Module: CXOSAI22%542AC7CE02C5; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI22.cpp

//## begin module%542AC7CE02C5.additionalIncludes preserve=no
//## end module%542AC7CE02C5.additionalIncludes

//## begin module%542AC7CE02C5.includes preserve=yes
//## end module%542AC7CE02C5.includes

#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSDB49_h
#include "CXODDB49.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSRU37_h
#include "CXODRU37.hpp"
#endif
#ifndef CXOSRS88_h
#include "CXODRS88.hpp"
#endif
#ifndef CXOSRS89_h
#include "CXODRS89.hpp"
#endif
#ifndef CXOSAI22_h
#include "CXODAI22.hpp"
#endif


//## begin module%542AC7CE02C5.declarations preserve=no
//## end module%542AC7CE02C5.declarations

//## begin module%542AC7CE02C5.additionalDeclarations preserve=yes
//## end module%542AC7CE02C5.additionalDeclarations


// Class AdvantageMessage622 

AdvantageMessage622::AdvantageMessage622()
  //## begin AdvantageMessage622::AdvantageMessage622%5ABE89320138_const.hasinit preserve=no
      : m_pCheckDepositSegment(0),
        m_pFinancialDepositSegment(0)
  //## end AdvantageMessage622::AdvantageMessage622%5ABE89320138_const.hasinit
  //## begin AdvantageMessage622::AdvantageMessage622%5ABE89320138_const.initialization preserve=yes
   ,AdvantageMessage("0622","S318")
  //## end AdvantageMessage622::AdvantageMessage622%5ABE89320138_const.initialization
{
  //## begin AdvantageMessage622::AdvantageMessage622%5ABE89320138_const.body preserve=yes
   memcpy(m_sID,"AI22",4);
   m_pCheckDepositSegment=CheckDepositSegment::instance();
   m_pFinancialDepositSegment=FinancialDepositSegment::instance();
  //## end AdvantageMessage622::AdvantageMessage622%5ABE89320138_const.body
}


AdvantageMessage622::~AdvantageMessage622()
{
  //## begin AdvantageMessage622::~AdvantageMessage622%5ABE89320138_dest.body preserve=yes
  //## end AdvantageMessage622::~AdvantageMessage622%5ABE89320138_dest.body
}



//## Other Operations (implementation)
bool AdvantageMessage622::insert (Message& hMessage)
{
  //## begin AdvantageMessage622::insert%5ABE895403D9.body preserve=yes
   UseCase hUseCase("TANDEM","## AD30 READ 0622 BULK DEPOSIT",false);
   m_hAuditSegment.reset();
   m_pCheckDepositSegment->reset();
   m_pFinancialDepositSegment->reset();
   AdvantageMessage::insert(hMessage);
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   short siHdrMsgStepCode=ntohs(pV13AdvantageHeader->siHdrMsgStep);
   if (siHdrMsgStepCode != 10)
      return false;
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   hMsg622* pMsg622 = (hMsg622*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   int iLength = ntohs(pMsg622->siLength);
#ifdef MVS
   if (getAsciiInput())
   {
      CodeTable::translate(pMsg622->sMTI,pMsg622->sMilestone0-pMsg622->sMTI,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pMsg622->sRetrievalRefNo,((char*)(&pMsg622->siLength))-pMsg622->sRetrievalRefNo,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pMsg622->sNumChecks,iLength,CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!getAsciiInput())
   {
      CodeTable::translate(pMsg622->sMTI,pMsg622->sMilestone0-pMsg622->sMTI,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pMsg622->sRetrievalRefNo,((char*)(&pMsg622->siLength))-pMsg622->sRetrievalRefNo,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pMsg622->sNumChecks,iLength,CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   if (memcmp(pMsg622->sMTI,"1210",4) != 0)
      return false;
   char szNumChecks[sizeof(pMsg622->sNumChecks)+1];
   memcpy(szNumChecks,pMsg622->sNumChecks, sizeof(pMsg622->sNumChecks));
   szNumChecks[sizeof(pMsg622->sNumChecks)] = '\0';
   short siNumChecks(atoi(szNumChecks));
   if ((siNumChecks < 1) || (siNumChecks >30))
      return false;
   string strTSTAMP_TRANS(NonStopClock::getYYYYMMDDHHMMSShh(pMsg622->sMilestone0));
   m_pCheckDepositSegment->setTSTAMP_TRANS(strTSTAMP_TRANS.data(),16);
   m_pFinancialDepositSegment->setTSTAMP_TRANS(strTSTAMP_TRANS.data(),16);
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      m_pCheckDepositSegment->setTSTAMP_TRANS(strTemp.data(),16);
      m_pFinancialDepositSegment->setTSTAMP_TRANS(strTemp.data(),16);
   }
   char sPAN[28];
   memcpy (sPAN, pMsg622->sPAN, 28);
   if (Customer::instance()->getTest())
      memcpy(sPAN + 6,"999999",6);
   database::UniquenessKey::hash(sPAN,16);
   database::UniquenessKey::hash(pMsg622->sRetrievalRefNo,12);
   database::UniquenessKey::hash(pMsg622->sSysTraceAuditNo,6);
   short siUNIQUENESS_KEY=database::UniquenessKey::getHash();
   m_pCheckDepositSegment->setUNIQUENESS_KEY(siUNIQUENESS_KEY);
   m_pFinancialDepositSegment->setUNIQUENESS_KEY(siUNIQUENESS_KEY);
   m_pFinancialDepositSegment->setCHECKS_ACCEPTED(siNumChecks);
   vector<CheckDepositSegment> hDeposits;
   for (int i = 0;i < siNumChecks;i++)
   {
      CheckDepositSegment hDetail;
      hDetail.setSEQ_NO(i+1);
      hDetail.setAMT_CHECK(pMsg622->pCheck[i].sCheckReadAmt,8);
      hDetail.setAMT_USER(pMsg622->pCheck[i].sCheckUserAmt,8);
      hDetail.setMICR(string(pMsg622->pCheck[i].sMICR,64));
      hDeposits.push_back(hDetail);
   }
   char* p = psBuffer + 4;
   ListSegment hListSegment;
   hListSegment.write(&psBuffer);
   for (int i = 0;i < siNumChecks;i++)
   {
      m_pCheckDepositSegment->setSEQ_NO(i+1);
      m_pCheckDepositSegment->setAMT_CHECK(hDeposits[i].getAMT_CHECK());
      m_pCheckDepositSegment->setAMT_USER(hDeposits[i].getAMT_USER());
      m_pCheckDepositSegment->setMICR(hDeposits[i].getMICR().data(),hDeposits[i].getMICR().length());
      m_pCheckDepositSegment->write(&psBuffer);
   }
   hListSegment.update(p,siNumChecks,(psBuffer - p));
   m_pFinancialDepositSegment->write(&psBuffer);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageMessage622::insert%5ABE895403D9.body
}

// Additional Declarations
  //## begin AdvantageMessage622%5ABE89320138.declarations preserve=yes
  //## end AdvantageMessage622%5ABE89320138.declarations

//## begin module%542AC7CE02C5.epilog preserve=yes
//## end module%542AC7CE02C5.epilog
