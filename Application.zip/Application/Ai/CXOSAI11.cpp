//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3C6139010280.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C6139010280.cm

//## begin module%3C6139010280.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3C6139010280.cp

//## Module: CXOSAI11%3C6139010280; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Pvcswork\Dn\Server\Application\Ai\CXOSAI11.cpp

//## begin module%3C6139010280.additionalIncludes preserve=no
//## end module%3C6139010280.additionalIncludes

//## begin module%3C6139010280.includes preserve=yes
// $Date:   Jun 21 2017 08:47:34  $ $Author:   e1009839  $ $Revision:   1.48  $
#include "CXODIF03.hpp"
#include "CXODIF11.hpp"
#include "CXODNS29.hpp"
//## end module%3C6139010280.includes

#ifndef CXOSAI11_h
#include "CXODAI11.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSRS36_h
#include "CXODRS36.hpp"
#endif
#ifndef CXOSRS39_h
#include "CXODRS39.hpp"
#endif
#ifndef CXOSRS41_h
#include "CXODRS41.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif


//## begin module%3C6139010280.declarations preserve=no
//## end module%3C6139010280.declarations

//## begin module%3C6139010280.additionalDeclarations preserve=yes
//## end module%3C6139010280.additionalDeclarations


// Class AdvantageStdAdjustment


AdvantageStdAdjustment::AdvantageStdAdjustment()
  //## begin AdvantageStdAdjustment::AdvantageStdAdjustment%3C61334400AB_const.hasinit preserve=no
  //## end AdvantageStdAdjustment::AdvantageStdAdjustment%3C61334400AB_const.hasinit
  //## begin AdvantageStdAdjustment::AdvantageStdAdjustment%3C61334400AB_const.initialization preserve=yes
   : AdvantageMessage("0466","S200")
  //## end AdvantageStdAdjustment::AdvantageStdAdjustment%3C61334400AB_const.initialization
{
  //## begin AdvantageStdAdjustment::AdvantageStdAdjustment%3C61334400AB_const.body preserve=yes
   memcpy(m_sID,"AI11",4);
  //## end AdvantageStdAdjustment::AdvantageStdAdjustment%3C61334400AB_const.body
}


AdvantageStdAdjustment::~AdvantageStdAdjustment()
{
  //## begin AdvantageStdAdjustment::~AdvantageStdAdjustment%3C61334400AB_dest.body preserve=yes
  //## end AdvantageStdAdjustment::~AdvantageStdAdjustment%3C61334400AB_dest.body
}



//## Other Operations (implementation)
bool AdvantageStdAdjustment::insert (Message& hMessage)
{
  //## begin AdvantageStdAdjustment::insert%3C63D8150186.body preserve=yes
   hStdAdjustment* pAdjustment = (hStdAdjustment*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   char sTranId[4];
   memcpy(sTranId,pAdjustment->sTranId,4);
   char sUsageCode[2];
   memcpy(sUsageCode,pAdjustment->sUsageCode,2);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
     CodeTable::translate(sTranId,4,CodeTable::CX_ASCII_TO_EBCDIC);
     CodeTable::translate(sUsageCode,2,CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
     CodeTable::translate(sTranId,4,CodeTable::CX_EBCDIC_TO_ASCII);
     CodeTable::translate(sUsageCode,2,CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
//*  don't process Visa exceptions with the ICS integration
   if ((memcmp(sTranId,"X030",4) == 0) &&
      ((memcmp(sUsageCode,"08",2) == 0) || (memcmp(sUsageCode,"10",2) == 0)))
      return false;
   if (memcmp(sUsageCode,"08",2))
      return false;


   UseCase hUseCase("TANDEM","## AD21 READ 0466 EXCEPTION",false);
   FinancialBaseSegment* m_pFinancialBaseSegment = FinancialBaseSegment::instance();
   FinancialSettlementSegment* m_pFinancialSettlementSegment = FinancialSettlementSegment::instance();
   FinancialAdjustmentSegment* m_pFinancialAdjustmentSegment = FinancialAdjustmentSegment::instance();
   FinancialAdjustmentExtensionSegment* m_pFinancialAdjustmentExtensionSegment = FinancialAdjustmentExtensionSegment::instance();
   char sLocalDateTime16[17] = {"                "};
   char sMilesDateTime16[17] = {"                "};
   char sBlankDate[7] = {"      "};
   char sCentury[2];
   m_hAuditSegment.reset();
   m_pFinancialBaseSegment->reset();
   m_pFinancialSettlementSegment->reset();
   m_pFinancialAdjustmentSegment->reset();
   m_pFinancialAdjustmentExtensionSegment->reset();
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pAdjustment->sPan,
         (pAdjustment->sFiller1 - pAdjustment->sPan),
         CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sLocalDate,
         ((char*)&pAdjustment->lTranFee - pAdjustment->sLocalDate),
         CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sMilestone0Date,
         (pAdjustment->sFiller3 - pAdjustment->sMilestone0Date),
         CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sAdjReasonCode,
         (pAdjustment->sFiller4 - pAdjustment->sAdjReasonCode),
         CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pAdjustment->sPan,
         (pAdjustment->sFiller1 - pAdjustment->sPan),
         CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sLocalDate,
         ((char*)&pAdjustment->lTranFee - pAdjustment->sLocalDate),
         CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sMilestone0Date,
         (pAdjustment->sFiller3 - pAdjustment->sMilestone0Date),
         CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sAdjReasonCode,
         (pAdjustment->sFiller4 - pAdjustment->sAdjReasonCode),
         CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   m_pFinancialBaseSegment->setCED_BUILD_NO(ntohl(pV13AdvantageHeader->lCED_BUILD_NO));
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   m_pFinancialAdjustmentSegment->setTRACE_DATA_ADJ(pAdjustment->sTraceNum,23);
   m_pFinancialAdjustmentSegment->setREQ_ACQ_ISS_IND(&pAdjustment->cIssAcqType,1);
   DateTime::calcCentury(pAdjustment->sMilestone0Date,sCentury);
   memcpy(sMilesDateTime16,sCentury,2);
   memcpy(sMilesDateTime16+2,pAdjustment->sMilestone0Date,6);
   memcpy(sMilesDateTime16+8,pAdjustment->sMilestone0Time,8);
   if (pAdjustment->sMilestone0Time[6]==' ')
      memcpy(sMilesDateTime16+14,"00",2);
   m_pFinancialAdjustmentSegment->setTSTAMP_TRANS_ADJ(sMilesDateTime16,16);
   DateTime::calcCentury(pAdjustment->sLocalDate,sCentury);
   memcpy(sLocalDateTime16,sCentury,2);
   memcpy(sLocalDateTime16+2,pAdjustment->sLocalDate,6);
   memcpy(sLocalDateTime16+8,pAdjustment->sLocalTime,8);
   m_pFinancialAdjustmentSegment->setTSTAMP_LOCAL_ADJ(sLocalDateTime16,14);
   string strTSTAMP_TRANS(NonStopClock::getYYYYMMDDHHMMSShh(pV13AdvantageHeader->sFiller));
   m_pFinancialBaseSegment->setTSTAMP_TRANS(strTSTAMP_TRANS.data(),16);
   m_pFinancialAdjustmentSegment->setORIG_AMT_TRAN_ADJ(ntohl(pAdjustment->lAmtTran[0]),
      ntohl(pAdjustment->lAmtTran[1]));
   m_pFinancialBaseSegment->setAMT_TRAN(ntohl(pAdjustment->lCompAmt[0]),
      ntohl(pAdjustment->lCompAmt[1]));
   if (ntohl(pAdjustment->lAdjAmt1[0]) == 0
      && ntohl(pAdjustment->lAdjAmt1[1]) == 0)
       m_pFinancialBaseSegment->setAMT_RECON_NET(ntohl(pAdjustment->lAdjAmt2[0]),
          ntohl(pAdjustment->lAdjAmt2[1]));
   else
       m_pFinancialBaseSegment->setAMT_RECON_NET(ntohl(pAdjustment->lAdjAmt1[0]),
          ntohl(pAdjustment->lAdjAmt1[1]));
   if (memcmp(pAdjustment->sAdjLocalDate,sBlankDate,6))
   {
      DateTime::calcCentury(pAdjustment->sAdjLocalDate,sCentury);
      memcpy(sLocalDateTime16,sCentury,2);
      memcpy(sLocalDateTime16+2,pAdjustment->sAdjLocalDate,6);
      memcpy(sLocalDateTime16+8,pAdjustment->sAdjLocalTime,8);
   }
   m_pFinancialBaseSegment->setTSTAMP_LOCAL(sLocalDateTime16,14);
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      m_pFinancialBaseSegment->setTSTAMP_TRANS(strTemp.data(),16);
      m_pFinancialBaseSegment->setTSTAMP_LOCAL(strTemp.data(),14);
   }
   m_pFinancialBaseSegment->setPROC_ID_ACQ(pAdjustment->sAcqMem,6);
   m_pFinancialBaseSegment->setPROC_ID_ISS(pAdjustment->sFromProc,6);
   m_pFinancialBaseSegment->setACCT_ID_1(pAdjustment->sIdAcct,28);
   m_pFinancialBaseSegment->setCARD_ACPT_TERM_ID(pAdjustment->sIdAcptTerm,15);
   reformatInstId(pAdjustment->sIdInstAcq);
   m_pFinancialBaseSegment->setINST_ID_ACQ(m_sStdInstId,11);
   reformatInstId(pAdjustment->sIdInstFwd);
   m_pFinancialBaseSegment->setINST_ID_RECON_ACQ(m_sStdInstId,11);
   reformatInstId(pAdjustment->sIdInstRec);
   m_pFinancialBaseSegment->setINST_ID_ISS(m_sStdInstId,11);
   reformatInstId(pAdjustment->sIdInstSettle);
   m_pFinancialBaseSegment->setINST_ID_RECON_ISS(m_sStdInstId,11);

   //* The institution id fields in the exception messages contain Visa BIN values,
   //* not the institution values we would find in our CR tables.  The isSubscriber
   //* call is only going to look up at the customer level.
   if ((ConfigurationRepository::instance()->isSubscriber("",""))== "X")
   {
/*      Trace::put(__FILE__,__LINE__,"not keeping",-1);	*/
      return false;
   }
   else
   {
/*      Trace::put(__FILE__,__LINE__,"keeping",-1);	*/
/*      Trace::put(ConfigurationRepository::instance()->getSUBSCRIBER_IND().data(),ConfigurationRepository::instance()->getSUBSCRIBER_IND().length());	*/
      m_pFinancialBaseSegment->setSUBSCRIBER_IND(ConfigurationRepository::instance()->getSUBSCRIBER_IND().data(), 1);
   }
   if (Customer::instance()->getTest())
      memcpy(pAdjustment->sPan + 6,"999999",6);
   m_pFinancialBaseSegment->setPAN(pAdjustment->sPan,19);
   m_pFinancialBaseSegment->setREIMBURSEMENT_ATTR(&pAdjustment->cReimbAtribute,1);
   char sCardAcptNameLoc[84];
   memset(sCardAcptNameLoc,' ',sizeof(sCardAcptNameLoc));
   memcpy( sCardAcptNameLoc, pAdjustment->sTermAddr,28);
   sCardAcptNameLoc[28] = ' ';
   memcpy(sCardAcptNameLoc+29, pAdjustment->sTermCity,15);
   sCardAcptNameLoc[44] = ' ';
   memcpy(sCardAcptNameLoc+45, pAdjustment->sTermFiName,25);
   m_pFinancialBaseSegment->setCARD_ACPT_NAME_LOC(sCardAcptNameLoc,84);
   m_pFinancialBaseSegment->setCARD_ACPT_COUNTRY(pAdjustment->sTermCountry,2);
   m_pFinancialBaseSegment->setCARD_ACPT_REGION(pAdjustment->sTermState,2);
   m_pFinancialBaseSegment->setNET_TERM_ID(pAdjustment->sTermId,8);
   m_pFinancialBaseSegment->setRETRIEVAL_REF_NO(pAdjustment->sTermRef,8);
   m_pFinancialBaseSegment->setSYS_TRACE_AUDIT_NO(pAdjustment->sTermSeq,6);
   m_pFinancialBaseSegment->setMERCH_TYPE(pAdjustment->sNetwMerchType,4);
   m_pFinancialBaseSegment->setCOUNTRY_ACQ_INST(pAdjustment->sNetwAcqInstCntyCode,3);
   m_pFinancialBaseSegment->setCOUNTRY_ISS_INST(pAdjustment->sNetwIssInstCntyCode,3);
   m_pFinancialBaseSegment->setUNIQUENESS_KEY(m_siUniquenessKey);
   m_pFinancialBaseSegment->setACQ_PLAT_PROD_ID("A",1);
   m_pFinancialBaseSegment->setFIN_TYPE("080",3);
   m_pFinancialBaseSegment->setTRAN_DISPOSITION("1",1);
   m_pFinancialSettlementSegment->setREF_DATA_ACQ(pAdjustment->sAdjTraceNum,23);
   m_pFinancialSettlementSegment->setREF_DATA_ISS(pAdjustment->sAdjTraceNum,23);
   m_pFinancialSettlementSegment->setDATA_PRIV_ACQ(pAdjustment->sAddAcqData,50);
   m_pFinancialSettlementSegment->setDATA_PRIV_ISS(pAdjustment->sAddIssData,50);
   m_pFinancialSettlementSegment->setMTI(pAdjustment->sAdjMsgType,4);
   m_pFinancialSettlementSegment->setF_AMTn(ntohl(pAdjustment->lTranFee),0);
   m_pFinancialSettlementSegment->setF_AMT_RECON_NETn(ntohl(pAdjustment->lTranFee),0);
   if (memcmp(sTranId,"X030",4) == 0)
   {
      string strProcCode(pAdjustment->sProcessCode,6), strTranTypeId;
      if (ConfigurationRepository::instance()->translate("X_VISA_PROC_CODE",
         strProcCode, strTranTypeId, "FIN_LOCATOR", "TRAN_TYPE_ID", 0))
      {
         m_pFinancialBaseSegment->setTRAN_TYPE_ID(strTranTypeId.data(),strTranTypeId.length());
         m_pFinancialBaseSegment->setACCT_TYPES_ISS(strTranTypeId.substr(2,4).data(),4);
      }
      else
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_SET_ACCT_TYPES_ISS);
      string strReasonCode(pAdjustment->sAdjReasonCode,4), strMsgReasonCode;
      if (ConfigurationRepository::instance()->translate("X_VISA_ADJ_REASON",
         strReasonCode,strMsgReasonCode, "FIN_RECORD", "MSG_RESON_CODE_ACQ", 0))
         m_pFinancialBaseSegment->setMSG_RESON_CODE_ACQ(strMsgReasonCode.data(),strMsgReasonCode.length());
      char sExtensionData[400];
      memset(sExtensionData,' ',sizeof(sExtensionData));
      memcpy(sExtensionData,pAdjustment->sProcessCode,6);
      sExtensionData[6] = ' ';
      memcpy(sExtensionData+7,pAdjustment->sAdjReasonCode,4);
      sExtensionData[11] = ' ';
      memcpy(sExtensionData+12,pAdjustment->sNetwAcq,11);
      sExtensionData[23] = ' ';
      memcpy(sExtensionData+24,pAdjustment->sNetwIss,11);
      sExtensionData[35] = ' ';
      memcpy(sExtensionData+36,pAdjustment->sNetwReasonCode,4);
      sExtensionData[40] = ' ';
      memcpy(sExtensionData+41,pAdjustment->sPsRetReasonCodes,15);
      sExtensionData[56] = ' ';
      memcpy(sExtensionData+57,pAdjustment->sSupportInfo,255);
      m_pFinancialAdjustmentExtensionSegment->setEXTENSION_DATA_ADJ(sExtensionData,400);
   }
   else if (memcmp(pAdjustment->sTranId,"X041",4) == 0)
   {
      string strProcCode(pAdjustment->sProcessCode,4), strTranTypeId;
      if (ConfigurationRepository::instance()->translate("X_CIRR_PROC_CODE",
         strProcCode, strTranTypeId, "FIN_LOCATOR", "TRAN_TYPE_ID", 0))
      {
         m_pFinancialBaseSegment->setTRAN_TYPE_ID(strTranTypeId.data(),strTranTypeId.length());
         m_pFinancialBaseSegment->setACCT_TYPES_ISS(strTranTypeId.substr(2,4).data(),4);
      }
      string strReasonCode(pAdjustment->sProcessCode,2), strMsgReasonCode;
      if (ConfigurationRepository::instance()->translate("X_CIRR_ADJ_REASON",
         strReasonCode,strMsgReasonCode, "FIN_RECORD", "MSG_RESON_CODE_ACQ", 0))
         m_pFinancialBaseSegment->setMSG_RESON_CODE_ACQ(strMsgReasonCode.data(),strMsgReasonCode.length());
      char sExtensionData[400];
      memset(sExtensionData,' ',sizeof(sExtensionData));
      memcpy(sExtensionData,pAdjustment->sProcessCode,4);
      sExtensionData[4] = ' ';
      memcpy(sExtensionData+5,pAdjustment->sAdjReasonCode,2);
      sExtensionData[7] = ' ';
      memcpy(sExtensionData+8,pAdjustment->sNetwAcq,11);
      sExtensionData[19] = ' ';
      memcpy(sExtensionData+20,pAdjustment->sNetwIss,11);
      sExtensionData[31] = ' ';
      memcpy(sExtensionData+32,pAdjustment->sSupportInfo,255);
      m_pFinancialAdjustmentExtensionSegment->setEXTENSION_DATA_ADJ(sExtensionData,400);
   }
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   m_pFinancialBaseSegment->write(&psBuffer);
   m_pFinancialSettlementSegment->write(&psBuffer);
   m_pFinancialAdjustmentSegment->write(&psBuffer);
   m_pFinancialAdjustmentExtensionSegment->write(&psBuffer);
   ConfigurationRepository::instance()->write(&psBuffer,m_pFinancialBaseSegment->zTSTAMP_TRANS(),m_pFinancialBaseSegment->getUNIQUENESS_KEY());
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageStdAdjustment::insert%3C63D8150186.body
}

// Additional Declarations
  //## begin AdvantageStdAdjustment%3C61334400AB.declarations preserve=yes
  //## end AdvantageStdAdjustment%3C61334400AB.declarations

//## begin module%3C6139010280.epilog preserve=yes
//## end module%3C6139010280.epilog
