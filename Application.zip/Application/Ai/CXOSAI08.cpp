//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3C6137F401B5.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C6137F401B5.cm

//## begin module%3C6137F401B5.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3C6137F401B5.cp

//## Module: CXOSAI08%3C6137F401B5; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXOSAI08.cpp

//## begin module%3C6137F401B5.additionalIncludes preserve=no
//## end module%3C6137F401B5.additionalIncludes

//## begin module%3C6137F401B5.includes preserve=yes
// $Date:   Jun 21 2017 08:50:36  $ $Author:   e1009839  $ $Revision:   1.52  $
#include "CXODIF03.hpp"
#include "CXODIF11.hpp"
#include "CXODNS29.hpp"
//## end module%3C6137F401B5.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSRS41_h
#include "CXODRS41.hpp"
#endif
#ifndef CXOSRS39_h
#include "CXODRS39.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSRS38_h
#include "CXODRS38.hpp"
#endif
#ifndef CXOSRS37_h
#include "CXODRS37.hpp"
#endif
#ifndef CXOSRS36_h
#include "CXODRS36.hpp"
#endif
#ifndef CXOSRS40_h
#include "CXODRS40.hpp"
#endif
#ifndef CXOSAI08_h
#include "CXODAI08.hpp"
#endif


//## begin module%3C6137F401B5.declarations preserve=no
//## end module%3C6137F401B5.declarations

//## begin module%3C6137F401B5.additionalDeclarations preserve=yes
//## end module%3C6137F401B5.additionalDeclarations


// Class AdvantageSettledAdjustment 

AdvantageSettledAdjustment::AdvantageSettledAdjustment()
  //## begin AdvantageSettledAdjustment::AdvantageSettledAdjustment%3C6132A2005D_const.hasinit preserve=no
      : m_pFinancialAdjustmentSegment(0),
        m_pFinancialBaseSegment(0),
        m_pFinancialFeeSegment(0),
        m_pFinancialReversalSegment(0),
        m_pFinancialSettlementSegment(0),
        m_pFinancialUserSegment(0)
  //## end AdvantageSettledAdjustment::AdvantageSettledAdjustment%3C6132A2005D_const.hasinit
  //## begin AdvantageSettledAdjustment::AdvantageSettledAdjustment%3C6132A2005D_const.initialization preserve=yes
   ,AdvantageMessage("0410","S200")
  //## end AdvantageSettledAdjustment::AdvantageSettledAdjustment%3C6132A2005D_const.initialization
{
  //## begin AdvantageSettledAdjustment::AdvantageSettledAdjustment%3C6132A2005D_const.body preserve=yes
   memcpy(m_sID,"AI08",4);
   m_pFinancialAdjustmentSegment = FinancialAdjustmentSegment::instance();
   m_pFinancialAdjustmentExtensionSegment =
      FinancialAdjustmentExtensionSegment::instance();
   m_pFinancialBaseSegment = FinancialBaseSegment::instance();
   m_pFinancialFeeSegment = FinancialFeeSegment::instance();
   m_pFinancialReversalSegment = FinancialReversalSegment::instance();
   m_pFinancialSettlementSegment = FinancialSettlementSegment::instance();
   m_pFinancialUserSegment = FinancialUserSegment::instance();
  //## end AdvantageSettledAdjustment::AdvantageSettledAdjustment%3C6132A2005D_const.body
}


AdvantageSettledAdjustment::~AdvantageSettledAdjustment()
{
  //## begin AdvantageSettledAdjustment::~AdvantageSettledAdjustment%3C6132A2005D_dest.body preserve=yes
  //## end AdvantageSettledAdjustment::~AdvantageSettledAdjustment%3C6132A2005D_dest.body
}



//## Other Operations (implementation)
bool AdvantageSettledAdjustment::insert (Message& hMessage)
{
  //## begin AdvantageSettledAdjustment::insert%3C61894B01B5.body preserve=yes
   UseCase hUseCase("TANDEM","## AD18 READ 0410 SETTLED",false);
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   hAdjustment* pAdjustment = (hAdjustment*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   if (pAdjustment->cNetworkInd != 'S' && pAdjustment->cNetworkInd != ' ')
      return(false);
   m_hAuditSegment.reset();
   m_pFinancialBaseSegment->reset();
   m_pFinancialSettlementSegment->reset();
   m_pFinancialAdjustmentSegment->reset();
   m_pFinancialAdjustmentExtensionSegment->reset();
   m_siUniquenessKey += 1;
   if (m_siUniquenessKey > 1000)
   {
      m_siUniquenessKey = 1;
   }
   AdvantageMessage::insert(hMessage);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pAdjustment->sAdjTrace,
         ((char*)(&pAdjustment->lAmtTran[0]) -
         pAdjustment->sAdjTrace), CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(&pAdjustment->cNetworkInd,
         (pAdjustment->sExtArea - &pAdjustment->cNetworkInd +
         sizeof(pAdjustment->sExtArea)),
         CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pAdjustment->sAdjTrace,
         ((char*)(&pAdjustment->lAmtTran[0]) -
         pAdjustment->sAdjTrace), CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(&pAdjustment->cNetworkInd,
         (pAdjustment->sExtArea - &pAdjustment->cNetworkInd +
         sizeof(pAdjustment->sExtArea)),
         CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   if (AdvantageMessageProcessor::instance()->getVersion() == 130)
   {
      hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
      m_pFinancialBaseSegment->setCED_BUILD_NO(ntohl(pV13AdvantageHeader->lCED_BUILD_NO));
   }
   else
      m_pFinancialBaseSegment->setCED_BUILD_NO(0);
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   m_pFinancialAdjustmentSegment->setTRACE_DATA_ADJ(pAdjustment->sAdjTrace,23);
   m_pFinancialAdjustmentExtensionSegment->setEXTENSION_DATA_ADJ(pAdjustment->sExtArea,400);
   m_pFinancialAdjustmentSegment->setNET_IND_ADJ(&pAdjustment->cNetworkInd,1);
   reformatInstId(pAdjustment->sReqFrdaba);
   m_pFinancialAdjustmentSegment->setINST_ID_REQ_ADJ(m_sStdInstId,11);
   reformatInstId(pAdjustment->sRecFrdaba);
   m_pFinancialAdjustmentSegment->setINST_ID_REC_ADJ(m_sStdInstId,11);
   m_pFinancialAdjustmentSegment->setCNTRY_REQ_INST_ADJ(pAdjustment->sReqFICtry,3);
   m_pFinancialAdjustmentSegment->setCNTRY_REC_INST_ADJ(pAdjustment->sRecFICtry,3);
   m_pFinancialAdjustmentSegment->setREQ_ACQ_ISS_IND(&pAdjustment->cReqAcqIssInd,1);
   m_pFinancialAdjustmentSegment->setTSTAMP_TRANS_ADJ(NonStopClock::getYYYYMMDDHHMMSShh(pAdjustment->sTransmitTimestamp).data(),16);
   m_pFinancialAdjustmentSegment->setTSTAMP_LOCAL_ADJ(NonStopClock::getYYYYMMDDHHMMSShh(pAdjustment->sAdjDateTime).data(),14);
   string strTSTAMP_TRANS(NonStopClock::getYYYYMMDDHHMMSShh(pV13AdvantageHeader->sFiller));
   if (getTestDate().length() > 0)
   {
      //IString strTemp((char*)getTestDate().c_str());
      //strTemp += strTSTAMP_TRANS.substr(8);
   }
   m_pFinancialAdjustmentSegment->setORIG_AMT_TRAN_ADJ(ntohl(pAdjustment->lAmtTran[0]),ntohl(pAdjustment->lAmtTran[1]));
   m_pFinancialBaseSegment->setAMT_RECON_NET(ntohl(pAdjustment->lAmtTranReplace[0]),ntohl(pAdjustment->lAmtTranReplace[1]));
   m_pFinancialBaseSegment->setAMT_TRAN(ntohl(pAdjustment->lAmtCompReversal[0]),ntohl(pAdjustment->lAmtCompReversal[1]));
   m_pFinancialBaseSegment->setTSTAMP_TRANS(strTSTAMP_TRANS.data(),16);
   m_pFinancialBaseSegment->setTSTAMP_LOCAL(NonStopClock::getYYYYMMDDHHMMSShh(pAdjustment->sOrigTranTimestamp).data(),14);
   m_pFinancialBaseSegment->setACCT_ID_1(pAdjustment->sAcctID1,28);
   m_pFinancialBaseSegment->setACCT_ID_2(pAdjustment->sAcctID2,28);
   reformatInstId(pAdjustment->sIDInstAcq);
   m_pFinancialBaseSegment->setINST_ID_ACQ(m_sStdInstId,11);
   m_pFinancialBaseSegment->setCOUNTRY_ACQ_INST(pAdjustment->sAcqInstCtry,3);
   m_pFinancialBaseSegment->setNET_ID_ACQ(pAdjustment->sAcqNetworkID,3);
   m_pFinancialBaseSegment->setAPPROVAL_CODE(pAdjustment->sAuthIDResp,6);
   m_pFinancialBaseSegment->setCARD_ACPT_NAME_LOC(pAdjustment->sCardAcptNameLoc,83);
   m_pFinancialBaseSegment->setCARD_ACPT_COUNTRY(pAdjustment->sCardAcptCountry,3);
   m_pFinancialBaseSegment->setCARD_ACPT_PST_CODE(pAdjustment->sCardAcptPostalCode,10);
   m_pFinancialBaseSegment->setCARD_ACPT_REGION(pAdjustment->sCardAcptRegionID,3);
   m_pFinancialBaseSegment->setCARD_ACPT_TERM_ID(pAdjustment->sCardAcptTermID,15);
   m_pFinancialBaseSegment->setCARD_SEQ_NO(pAdjustment->sCardSeqNo,5);
   reformatInstId(pAdjustment->sInstIDRec);
   m_pFinancialBaseSegment->setINST_ID_ISS(m_sStdInstId,11);
   m_pFinancialBaseSegment->setCOUNTRY_ISS_INST(pAdjustment->sIssInstCtry,3);
   m_pFinancialBaseSegment->setNET_ID_ISS(pAdjustment->sIssNetworkID,3);
   if (Customer::instance()->getTest())
      memcpy(pAdjustment->sPan + 6,"999999",6);
   m_pFinancialBaseSegment->setPAN(pAdjustment->sPan,28);
   m_pFinancialBaseSegment->setRETRIEVAL_REF_NO(pAdjustment->sTermRef,12);
   m_pFinancialBaseSegment->setSYS_TRACE_AUDIT_NO(pAdjustment->sTraceNo,6);
   m_pFinancialBaseSegment->setUNIQUENESS_KEY(m_siUniquenessKey);
   m_pFinancialBaseSegment->setACT_CODE("000",3);
   m_pFinancialBaseSegment->setACQ_PLAT_PROD_ID("A",1);
   m_pFinancialBaseSegment->setFIN_TYPE("080",3);
   m_pFinancialBaseSegment->setTRAN_DISPOSITION("1",1);
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      m_pFinancialBaseSegment->setTSTAMP_TRANS(strTemp.data(),16);
      m_pFinancialBaseSegment->setTSTAMP_LOCAL(strTemp.data(),14);
   }
   string strProcCode(pAdjustment->sProcessCode,6), strTranTypeId;
   strProcCode.append(&pAdjustment->cMTIClass,1);
   strProcCode.append("   ");
   if (pAdjustment->cPreAuthInd == 'Y')
      strProcCode.append("1");
   else
      strProcCode.append("0");
   strProcCode.append("    ");
   if (ConfigurationRepository::instance()->translate("X_ADV_PROC_CODE",
      strProcCode, strTranTypeId, "FIN_LOCATOR", "TRAN_TYPE_ID", 0))
   {
      m_pFinancialBaseSegment->setTRAN_TYPE_ID(strTranTypeId.data(),strTranTypeId.length());
      m_pFinancialBaseSegment->setACCT_TYPES_ISS(strTranTypeId.substr(2,4).data(),4);
   }
   else
      ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_SET_ACCT_TYPES_ISS);
   m_pFinancialBaseSegment->setNET_TERM_ID(pAdjustment->sTermNo,8);
   reformatInstId(pAdjustment->sIDInstFwd);
   m_pFinancialBaseSegment->setINST_ID_RECON_ACQ(m_sStdInstId,11);
   m_pFinancialBaseSegment->setPROC_ID_ACQ(pAdjustment->sAcqMem,6);
   reformatInstId(pAdjustment->sInstIDSettle);
   m_pFinancialBaseSegment->setINST_ID_RECON_ISS(m_sStdInstId,11);
   m_pFinancialBaseSegment->setPROC_ID_ISS(pAdjustment->sIssProc,6);
   string strNetworkTermId(pAdjustment->sTermNo,sizeof(pAdjustment->sTermNo));
   if (ConfigurationRepository::instance()->translate("DEVICE",
      strNetworkTermId, m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B, "FIN_LOCATOR", "INST_ID_RECN_ACQ_B", 0))
   {
      string strRPT_LVL_ID(m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.substr(11));
      if (strRPT_LVL_ID.length() > 0)
         m_pFinancialBaseSegment->setRPT_LVL_ID_B(strRPT_LVL_ID.data(),strRPT_LVL_ID.length());
      m_pFinancialBaseSegment->setINST_ID_RECN_ACQ_B(m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.data(),11);
      string strProcIdAcq;
      if (ConfigurationRepository::instance()->translate("INSTITUTION",
         m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.substr(0,11), strProcIdAcq, "FIN_LOCATOR", "PROC_ID_ACQ_B", 0))
      {
         m_pFinancialBaseSegment->setPROC_ID_ACQ_B(strProcIdAcq.data(),strProcIdAcq.length());
         string strProcGrpIdAcq;
         if (ConfigurationRepository::instance()->translate("PROCESSOR",
            strProcIdAcq, strProcGrpIdAcq, "FIN_LOCATOR", "PROC_GRP_ID_ACQ_B", 0))
         {
            m_pFinancialBaseSegment->setPROC_GRP_ID_ACQ_B(strProcGrpIdAcq.data(),strProcGrpIdAcq.length());
         }
      }
      else
      {
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
      }
   }
   else
   {
      ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   }
   reformatInstId(pAdjustment->sInstIDSettle);
   string strInstIdReconIss(m_sStdInstId,11), strProcIdIss;
   if (ConfigurationRepository::instance()->translate("INSTITUTION",
      strInstIdReconIss, strProcIdIss, "FIN_LOCATOR", "PROC_ID_ISS_B", 0))
   {
      m_pFinancialBaseSegment->setPROC_ID_ISS_B(strProcIdIss.data(),strProcIdIss.length());
      string strProcGrpIdIss;
      if (ConfigurationRepository::instance()->translate("PROCESSOR",
         strProcIdIss, strProcGrpIdIss, "FIN_LOCATOR", "PROC_GRP_ID_ISS_B", 0))
         m_pFinancialBaseSegment->setPROC_GRP_ID_ISS_B(strProcGrpIdIss.data(),strProcGrpIdIss.length());
   }
   else
      ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ISS_DATA);

   string strInstRecnIssB;
   if (!ConfigurationRepository::instance()->mapItem("X_INST_ID_RECON",(string)m_pFinancialBaseSegment->zINST_ID_RECON_ISS(),(string)m_pFinancialBaseSegment->zINST_ID_ISS(),"I",strInstRecnIssB))
      strInstRecnIssB = m_pFinancialBaseSegment->zINST_ID_RECON_ISS();
   if ((ConfigurationRepository::instance()->isSubscriber(FinancialBaseSegment::instance()->zINST_ID_RECN_ACQ_B(),strInstRecnIssB))== "X")
   {
/*      Trace::put(__FILE__,__LINE__,"not keeping",-1);	*/
      return false;
   }
   else
   {
/*      Trace::put(__FILE__,__LINE__,"keeping",-1);	*/
/*      Trace::put(ConfigurationRepository::instance()->getSUBSCRIBER_IND().data(),ConfigurationRepository::instance()->getSUBSCRIBER_IND().length());	*/
      m_pFinancialBaseSegment->setSUBSCRIBER_IND(ConfigurationRepository::instance()->getSUBSCRIBER_IND().data(), 1);
   }

   m_pFinancialSettlementSegment->setACCT_QUAL_1(pAdjustment->sAcctQual1,3);
   m_pFinancialSettlementSegment->setACCT_QUAL_2(pAdjustment->sAcctQual2,3);
   m_pFinancialSettlementSegment->setREF_DATA_ACQ(pAdjustment->sAcqTraceNo,23);
   m_pFinancialSettlementSegment->setCRD_ACP_NAM_FMTFLG(&pAdjustment->cRegEInd,1);
   m_pFinancialSettlementSegment->setTERM_CLASS(pAdjustment->sTermClass,2);
   if (getTestDate().length() > 0)
   {
      //IString strTemp((char*)getTestDate().c_str());
      //strTemp += strTstampTrans.subString(9,8);
   }
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   m_pFinancialBaseSegment->write(&psBuffer);
   m_pFinancialSettlementSegment->write(&psBuffer);
   m_pFinancialAdjustmentSegment->write(&psBuffer);
   m_pFinancialAdjustmentExtensionSegment->write(&psBuffer);
   ConfigurationRepository::instance()->write(&psBuffer,m_pFinancialBaseSegment->zTSTAMP_TRANS(),m_pFinancialBaseSegment->getUNIQUENESS_KEY());
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageSettledAdjustment::insert%3C61894B01B5.body
}

// Additional Declarations
  //## begin AdvantageSettledAdjustment%3C6132A2005D.declarations preserve=yes
  //## end AdvantageSettledAdjustment%3C6132A2005D.declarations

//## begin module%3C6137F401B5.epilog preserve=yes
//## end module%3C6137F401B5.epilog
