//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A5426EC0290.cm preserve=no
//	$Date:   Apr 09 2018 12:06:02  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%5A5426EC0290.cm

//## begin module%5A5426EC0290.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A5426EC0290.cp

//## Module: CXOSAI35%5A5426EC0290; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI35.cpp

//## begin module%5A5426EC0290.additionalIncludes preserve=no
//## end module%5A5426EC0290.additionalIncludes

//## begin module%5A5426EC0290.includes preserve=yes
//## end module%5A5426EC0290.includes

#ifndef CXOSAI35_h
#include "CXODAI35.hpp"
#endif
//## begin module%5A5426EC0290.declarations preserve=no
//## end module%5A5426EC0290.declarations

//## begin module%5A5426EC0290.additionalDeclarations preserve=yes
//## end module%5A5426EC0290.additionalDeclarations


// Class AS2805Adjustment 

AS2805Adjustment::AS2805Adjustment()
  //## begin AS2805Adjustment::AS2805Adjustment%5A5426B602AA_const.hasinit preserve=no
  //## end AS2805Adjustment::AS2805Adjustment%5A5426B602AA_const.hasinit
  //## begin AS2805Adjustment::AS2805Adjustment%5A5426B602AA_const.initialization preserve=yes
  : AdvantageMessage("0466","S200")
  //## end AS2805Adjustment::AS2805Adjustment%5A5426B602AA_const.initialization
{
  //## begin AS2805Adjustment::AS2805Adjustment%5A5426B602AA_const.body preserve=yes
  //## end AS2805Adjustment::AS2805Adjustment%5A5426B602AA_const.body
}


AS2805Adjustment::~AS2805Adjustment()
{
  //## begin AS2805Adjustment::~AS2805Adjustment%5A5426B602AA_dest.body preserve=yes
  //## end AS2805Adjustment::~AS2805Adjustment%5A5426B602AA_dest.body
}



//## Other Operations (implementation)
bool AS2805Adjustment::insert (Message& hMessage)
{
  //## begin AS2805Adjustment::insert%5A5426D00238.body preserve=yes
   hAS2805Adjustment* p = (hAS2805Adjustment*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   if (memcmp(p->sTranId,"X044",4) != 0)
      return false;
   UseCase hUseCase("TANDEM","## AI35 READ 0466 EXCPTNS",false);
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   string strTSTAMP_TRANS("20            00");
   strTSTAMP_TRANS.replace(2,12,p->sTranDate,12);
   m_pTransaction->setTSTAMP_TRANS(strTSTAMP_TRANS);
   ::Template::instance()->map("AS2805EXCEPTION",(const char*)p);
   return deport(hMessage);
  //## end AS2805Adjustment::insert%5A5426D00238.body
}

// Additional Declarations
  //## begin AS2805Adjustment%5A5426B602AA.declarations preserve=yes
  //## end AS2805Adjustment%5A5426B602AA.declarations

//## begin module%5A5426EC0290.epilog preserve=yes
//## end module%5A5426EC0290.epilog
