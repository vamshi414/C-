//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C613A8D000F.cm preserve=no
//	$Date:   Feb 20 2021 13:44:08  $ $Author:   e1009839  $
//	$Revision:   1.40.1.4  $
//## end module%3C613A8D000F.cm

//## begin module%3C613A8D000F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C613A8D000F.cp

//## Module: CXOSAI17%3C613A8D000F; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI17.cpp

//## begin module%3C613A8D000F.additionalIncludes preserve=no
//## end module%3C613A8D000F.additionalIncludes

//## begin module%3C613A8D000F.includes preserve=yes
#include <algorithm>
#include "CXODAI23.hpp"
#include "CXODAI24.hpp"
//## end module%3C613A8D000F.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSIF02_h
#include "CXODIF02.hpp"
#endif
#ifndef CXOSDB01_h
#include "CXODDB01.hpp"
#endif
#ifndef CXOSDB19_h
#include "CXODDB19.hpp"
#endif
#ifndef CXOSSI01_h
#include "CXODSI01.hpp"
#endif
#ifndef CXOSSI05_h
#include "CXODSI05.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF15_h
#include "CXODIF15.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSRS05_h
#include "CXODRS05.hpp"
#endif
#ifndef CXOSAI25_h
#include "CXODAI25.hpp"
#endif
#ifndef CXOSAI27_h
#include "CXODAI27.hpp"
#endif
#ifndef CXOSAI28_h
#include "CXODAI28.hpp"
#endif
#ifndef CXOSAI42_h
#include "CXODAI42.hpp"
#endif
#ifndef CXOSAI41_h
#include "CXODAI41.hpp"
#endif
#ifndef CXOSAI43_h
#include "CXODAI43.hpp"
#endif
#ifndef CXOSAI40_h
#include "CXODAI40.hpp"
#endif
#ifndef CXOSAI36_h
#include "CXODAI36.hpp"
#endif
#ifndef CXOSAI37_h
#include "CXODAI37.hpp"
#endif
#ifndef CXOSAI29_h
#include "CXODAI29.hpp"
#endif
#ifndef CXOSAI39_h
#include "CXODAI39.hpp"
#endif
#ifndef CXOSAI38_h
#include "CXODAI38.hpp"
#endif
#ifndef CXOSAI44_h
#include "CXODAI44.hpp"
#endif
#ifndef CXOSAI02_h
#include "CXODAI02.hpp"
#endif
#ifndef CXOSAI09_h
#include "CXODAI09.hpp"
#endif
#ifndef CXOSAI08_h
#include "CXODAI08.hpp"
#endif
#ifndef CXOSAI05_h
#include "CXODAI05.hpp"
#endif
#ifndef CXOSAI04_h
#include "CXODAI04.hpp"
#endif
#ifndef CXOSAI03_h
#include "CXODAI03.hpp"
#endif
#ifndef CXOSAI14_h
#include "CXODAI14.hpp"
#endif
#ifndef CXOSAI15_h
#include "CXODAI15.hpp"
#endif
#ifndef CXOSAI16_h
#include "CXODAI16.hpp"
#endif
#ifndef CXOSAI06_h
#include "CXODAI06.hpp"
#endif
#ifndef CXOSAI07_h
#include "CXODAI07.hpp"
#endif
#ifndef CXOSAI19_h
#include "CXODAI19.hpp"
#endif
#ifndef CXOSAI22_h
#include "CXODAI22.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif


//## begin module%3C613A8D000F.declarations preserve=no
//## end module%3C613A8D000F.declarations

//## begin module%3C613A8D000F.additionalDeclarations preserve=yes
//## end module%3C613A8D000F.additionalDeclarations


// Class AdvantageMessageProcessor

//## begin AdvantageMessageProcessor::Instance%3C62D8C8037A.attr preserve=no  private: static AdvantageMessageProcessor* {V} 0
AdvantageMessageProcessor* AdvantageMessageProcessor::m_pInstance = 0;
//## end AdvantageMessageProcessor::Instance%3C62D8C8037A.attr

AdvantageMessageProcessor::AdvantageMessageProcessor()
  //## begin AdvantageMessageProcessor::AdvantageMessageProcessor%3C612F8D0119_const.hasinit preserve=no
      : m_bAsciiInput(true),
        m_lTranClassLength(0),
        m_lTranClassOffset(0),
        m_iVersion(130),
        m_pFinancial(0),
        m_pNetstatStatus(0),
        m_pNetstatDisplay(0),
        m_pAPAcctMaintenance(0),
        m_pAPCardMaintenance(0),
        m_pAPFraudMaintenance(0),
        m_pElectronicJournal(0),
        m_pException(0),
        m_pProcessorAdvice(0),
        m_pSettledAdjustment(0),
        m_pTerminalAdmin(0),
        m_pTerminalAdvice(0),
        m_pMessage622(0),
        m_pAdvantageFinancial(0),
        m_pAdvantageException(0),
        m_pAdvantageSettledAdjustment(0),
        m_pAdvantageAPAcctMaintenance(0),
        m_pAdvantageAPCardMaintenance(0),
        m_pAdvantageAPFraudMaintenance(0),
        m_pAdvantageProcessorAdvice(0),
        m_pAdvantageTerminalAdvice(0),
        m_pAdvantageTerminalAdmin(0),
        m_pAdvantageNetstatDisplay(0),
        m_pAdvantageNetstatStatus(0),
        m_pAdvantageElectronicJournal(0),
        m_pAdvantageMessage622(0)
  //## end AdvantageMessageProcessor::AdvantageMessageProcessor%3C612F8D0119_const.hasinit
  //## begin AdvantageMessageProcessor::AdvantageMessageProcessor%3C612F8D0119_const.initialization preserve=yes
  //## end AdvantageMessageProcessor::AdvantageMessageProcessor%3C612F8D0119_const.initialization
{
  //## begin AdvantageMessageProcessor::AdvantageMessageProcessor%3C612F8D0119_const.body preserve=yes
   memcpy(m_sID,"AI17",4);
   m_pInstance = this;
   AdvantageMessage::setTransaction(repositorysegment::Transaction::instance());
  //## end AdvantageMessageProcessor::AdvantageMessageProcessor%3C612F8D0119_const.body
}


AdvantageMessageProcessor::~AdvantageMessageProcessor()
{
  //## begin AdvantageMessageProcessor::~AdvantageMessageProcessor%3C612F8D0119_dest.body preserve=yes
   delete m_pFinancial;
   delete m_pException;
   delete m_pSettledAdjustment;
   delete m_pAPAcctMaintenance;
   delete m_pAPCardMaintenance;
   delete m_pAPFraudMaintenance;
   delete m_pProcessorAdvice;
   delete m_pTerminalAdvice;
   delete m_pTerminalAdmin;
   delete m_pNetstatDisplay;
   delete m_pNetstatStatus;
   delete m_pElectronicJournal;
   delete m_pMessage622;
   delete m_pAdvantageFinancial;
   delete m_pAdvantageException;
   delete m_pAdvantageSettledAdjustment;
   delete m_pAdvantageAPAcctMaintenance;
   delete m_pAdvantageAPCardMaintenance;
   delete m_pAdvantageAPFraudMaintenance;
   delete m_pAdvantageProcessorAdvice;
   delete m_pAdvantageTerminalAdvice;
   delete m_pAdvantageTerminalAdmin;
   delete m_pAdvantageNetstatDisplay;
   delete m_pAdvantageNetstatStatus;
   delete m_pAdvantageElectronicJournal;
   delete m_pAdvantageMessage622;
   delete m_pAdvantageMessage450Lcm;
   delete m_pAdvantageMessage600Lcm;
   //delete m_pInvalidAuthorization;
   m_pInstance = 0;
  //## end AdvantageMessageProcessor::~AdvantageMessageProcessor%3C612F8D0119_dest.body
}



//## Other Operations (implementation)
int AdvantageMessageProcessor::dispatch ()
{
  //## begin AdvantageMessageProcessor::dispatch%3C61A91B031C.body preserve=yes
   AdvantageMessage::setTestDate(getTestDate());
   hV13AdvantageHeader* pV13Header = (hV13AdvantageHeader*)Message::instance(Message::INBOUND)->data();
   m_bAsciiInput = true;
#ifdef MVS
   /* Check for the leading $ on the source and destination */
   if ((pV13Header->sHdrSource[0] == 0x5B) && (pV13Header->sHdrDestination[0] == 0x5B))
      m_bAsciiInput = false;
#endif
   AdvantageMessage::setAsciiInput(m_bAsciiInput);
   char pszMessageCode[PERCENTD];
   snprintf(pszMessageCode,sizeof(pszMessageCode),"%04d",ntohs(pV13Header->siHdrMsgCode));
   MessageList::iterator p;
   m_strMessageCode = pszMessageCode;
   p = m_hMessages.find(m_strMessageCode);
   if (p != m_hMessages.end())
   {
      AdvantageMessage* pMessage = (AdvantageMessage*)(*p).second;
      pMessage->setTstampHash(ntohl(pV13Header->lHdrTstamp2Hash));
      Message::instance(Message::INBOUND)->reset("AI LE ","S0012D");
      if (pMessage->insert(*Message::instance(Message::INBOUND)))
      {
         if (ConfigurationRepository::instance()->loadFailure())
            Hash::instance()->rejectBatch();
         else
         {
            string strQueueName;
            ((SwitchInterface*)Application::instance())->getLoadEngine(pMessage->getSegmentID(),strQueueName);
            if (Message::instance(Message::INBOUND)->send(strQueueName.c_str()))
            {
               ((SwitchInterface*)Application::instance())->dropLoadEngine(strQueueName);
               Hash::instance()->rejectBatch();
            }
            else
               Hash::instance()->incrementTranSentCnt();
         }
      }
      else
      {
         Hash::instance()->incrementDropTotal(ntohl(pV13Header->lHdrTstamp2Hash));
         string strMember("## AD27 DROP MSG CODE ");
         strMember += m_strMessageCode;
         UseCase hUseCase("TANDEM",strMember.c_str(),false);
      }
   }
   else
   {
      Hash::instance()->incrementDropTotal(ntohl(pV13Header->lHdrTstamp2Hash));
      string strMember("## AD27 DROP MSG CODE ");
      strMember += m_strMessageCode;
      UseCase hUseCase("TANDEM",strMember.c_str(),false);
   }
   if (Database::instance()->transactionState() == Database::COMMITREQUIRED)
      Database::instance()->commit();
   else
   if (Database::instance()->transactionState() == Database::ROLLBACKREQUIRED)
      Database::instance()->rollback();
   return 0;
  //## end AdvantageMessageProcessor::dispatch%3C61A91B031C.body
}

int AdvantageMessageProcessor::initialization ()
{
  //## begin AdvantageMessageProcessor::initialization%3C61A91D01F4.body preserve=yes
   if (Extract::instance()->getCustomCode() == "SECU")
      return initialization2();
   m_pAdvantageFinancial = new AdvantageFinancial();
   m_pAdvantageException = new AdvantageException();
   m_pAdvantageSettledAdjustment = new AdvantageSettledAdjustment();
   m_pAdvantageAPAcctMaintenance = new AdvantageAPAcctMaintenance();
   m_pAdvantageAPCardMaintenance = new AdvantageAPCardMaintenance();
   m_pAdvantageAPFraudMaintenance = new AdvantageAPFraudMaintenance();
   m_pAdvantageProcessorAdvice = new AdvantageProcessorAdvice();
   m_pAdvantageTerminalAdvice = new AdvantageTerminalAdvice();
   m_pAdvantageTerminalAdmin = new AdvantageTerminalAdmin();
   m_pAdvantageNetstatDisplay = new AdvantageNetstatDisplay();
   m_pAdvantageNetstatStatus = new AdvantageNetstatStatus();
   m_pAdvantageElectronicJournal = new AdvantageElectronicJournal();
   m_pAdvantageMessage622 = new AdvantageMessage622();
   m_pAdvantageMessage450Lcm = new AdvantageMessage450Lcm();
   m_pAdvantageMessage600Lcm = new AdvantageMessage600Lcm();
   //m_pInvalidAuthorization = new InvalidAuthorization();
   string strDropList;
   if (Extract::instance()->getSpec("DROPREC",strDropList))
      Buffer::parse(strDropList,"~",m_hDropList);
   string strRecord;
   Extract::instance()->getRecord("DUSER   ",strRecord);
   bool bLcmLoad = strRecord.find("LCMLOAD") != string::npos;
   if (!bLcmLoad)
   {
      m_hDropList.push_back("0450");
      m_hDropList.push_back("0600");
   }
   if ((m_pAdvantageAPCardMaintenance->getAD14Message() == true) && (find(m_hDropList.begin(), m_hDropList.end(),"0850") != m_hDropList.end()))
   {
	   m_hDropList.erase(find(m_hDropList.begin(),m_hDropList.end(),"0850"));
   }
   if((m_pAdvantageNetstatDisplay->getAD16Message() == true) && (find(m_hDropList.begin(), m_hDropList.end(),"1511") != m_hDropList.end()))
   {
	   m_hDropList.erase(find(m_hDropList.begin(),m_hDropList.end(),"1511"));
   }
   if((m_pAdvantageNetstatStatus->getAD17Message() == true) && (find(m_hDropList.begin(), m_hDropList.end(),"1521") != m_hDropList.end()))
   {
      m_hDropList.erase(find(m_hDropList.begin(),m_hDropList.end(),"1521"));
   }
#ifdef _WIN64
   addToMessageList(m_pAdvantageFinancial->getMessageCode(),(long long)m_pAdvantageFinancial);
   addToMessageList("0401",(long long)m_pAdvantageFinancial);
   addToMessageList("0482",(long long)m_pAdvantageFinancial);
   addToMessageList("0491",(long long)m_pAdvantageFinancial);
   addToMessageList(m_pAdvantageSettledAdjustment->getMessageCode(),(long long)m_pAdvantageSettledAdjustment);
   addToMessageList(m_pAdvantageException->getMessageCode(), (long long)m_pAdvantageException);
   addToMessageList(m_pAdvantageNetstatDisplay->getMessageCode(),(long long)m_pAdvantageNetstatDisplay);
   addToMessageList(m_pAdvantageNetstatStatus->getMessageCode(),(long long)m_pAdvantageNetstatStatus);
   addToMessageList(m_pAdvantageProcessorAdvice->getMessageCode(),(long long)m_pAdvantageProcessorAdvice);
   addToMessageList(m_pAdvantageTerminalAdvice->getMessageCode(),(long long)m_pAdvantageTerminalAdvice);
   addToMessageList(m_pAdvantageTerminalAdmin->getMessageCode(),(long long)m_pAdvantageTerminalAdmin);
   addToMessageList(m_pAdvantageElectronicJournal->getMessageCode(),(long long)m_pAdvantageElectronicJournal);
   addToMessageList(m_pAdvantageMessage622->getMessageCode(),(long long)m_pAdvantageMessage622);
   addToMessageList(m_pAdvantageMessage450Lcm->getMessageCode(),(long long)m_pAdvantageMessage450Lcm);
   addToMessageList(m_pAdvantageMessage600Lcm->getMessageCode(),(long long)m_pAdvantageMessage600Lcm);
   addToMessageList(m_pAdvantageAPFraudMaintenance->getMessageCode(),(long long)m_pAdvantageAPFraudMaintenance);
   addToMessageList(m_pAdvantageAPCardMaintenance->getMessageCode(),(long long)m_pAdvantageAPCardMaintenance);
   addToMessageList("0855",(long long)m_pAdvantageAPCardMaintenance);
   addToMessageList(m_pAdvantageAPAcctMaintenance->getMessageCode(),(long long)m_pAdvantageAPAcctMaintenance);
#else
   addToMessageList(m_pAdvantageFinancial->getMessageCode(),(long)m_pAdvantageFinancial);
   addToMessageList("0401",(long)m_pAdvantageFinancial);
   addToMessageList("0482",(long)m_pAdvantageFinancial);
   addToMessageList("0491",(long)m_pAdvantageFinancial);
   addToMessageList(m_pAdvantageSettledAdjustment->getMessageCode(),(long)m_pAdvantageSettledAdjustment);
   addToMessageList(m_pAdvantageException->getMessageCode(), (long)m_pAdvantageException);
   addToMessageList(m_pAdvantageNetstatDisplay->getMessageCode(),(long)m_pAdvantageNetstatDisplay);
   addToMessageList(m_pAdvantageNetstatStatus->getMessageCode(),(long)m_pAdvantageNetstatStatus);
   addToMessageList(m_pAdvantageProcessorAdvice->getMessageCode(),(long)m_pAdvantageProcessorAdvice);
   addToMessageList(m_pAdvantageTerminalAdvice->getMessageCode(),(long)m_pAdvantageTerminalAdvice);
   addToMessageList(m_pAdvantageTerminalAdmin->getMessageCode(),(long)m_pAdvantageTerminalAdmin);
   addToMessageList(m_pAdvantageElectronicJournal->getMessageCode(),(long)m_pAdvantageElectronicJournal);
   addToMessageList(m_pAdvantageMessage622->getMessageCode(),(long)m_pAdvantageMessage622);
   addToMessageList(m_pAdvantageMessage450Lcm->getMessageCode(),(long)m_pAdvantageMessage450Lcm);
   addToMessageList(m_pAdvantageMessage600Lcm->getMessageCode(),(long)m_pAdvantageMessage600Lcm);
   addToMessageList(m_pAdvantageAPFraudMaintenance->getMessageCode(),(long)m_pAdvantageAPFraudMaintenance);
   addToMessageList(m_pAdvantageAPCardMaintenance->getMessageCode(),(long)m_pAdvantageAPCardMaintenance);
   addToMessageList("0855",(long)m_pAdvantageAPCardMaintenance);
   addToMessageList(m_pAdvantageAPAcctMaintenance->getMessageCode(),(long)m_pAdvantageAPAcctMaintenance);
#endif
   //addToMessageList(m_pInvalidAuthorization->getMessageCode(),(long) m_pInvalidAuthorization);
   if (Extract::instance()->getLong("DUSER   ","TCOFFSET=",&m_lTranClassOffset))
      Extract::instance()->getLong("DUSER   ","TCLEN=",&m_lTranClassLength);
   return MessageProcessor::initialization();
  //## end AdvantageMessageProcessor::initialization%3C61A91D01F4.body
}

int AdvantageMessageProcessor::initialization2 ()
{
  //## begin AdvantageMessageProcessor::initialization2%5E6BA5C60208.body preserve=yes
   m_pFinancial = new Financial();
   m_pException = new Exception();
   m_pSettledAdjustment = new SettledAdjustment();
   m_pAPAcctMaintenance = new APAcctMaintenance();
   m_pAPCardMaintenance = new APCardMaintenance();
   m_pAPFraudMaintenance = new APFraudMaintenance();
   m_pProcessorAdvice = new ProcessorAdvice();
   m_pTerminalAdvice = new TerminalAdvice();
   m_pTerminalAdmin = new TerminalAdmin();
   m_pNetstatDisplay = new NetstatDisplay();
   m_pNetstatStatus = new NetstatStatus();
   m_pElectronicJournal = new ElectronicJournal();
   m_pMessage622 = new Message622();
   //m_pMessage450Lcm = new Message450Lcm();
   //m_pMessage600Lcm = new Message600Lcm();
   //m_pInvalidAuthorization = new InvalidAuthorization();
   string strDropList;
   if (Extract::instance()->getSpec("DROPREC",strDropList))
      Buffer::parse(strDropList,"~",m_hDropList);
   string strRecord;
   Extract::instance()->getRecord("DUSER   ",strRecord);
   bool bLcmLoad = strRecord.find("LCMLOAD") != string::npos;
   if (!bLcmLoad)
   {
      m_hDropList.push_back("0450");
      m_hDropList.push_back("0600");
   }
#ifdef _WIN64
   addToMessageList("0400",(long long)m_pFinancial);
   addToMessageList("0401",(long long)m_pFinancial);
   addToMessageList("0482",(long long)m_pFinancial);
   addToMessageList("0491",(long long)m_pFinancial);
   addToMessageList(m_pSettledAdjustment->getMessageCode(),(long long)m_pSettledAdjustment);
   addToMessageList(m_pException->getMessageCode(), (long long)m_pException);
   addToMessageList(m_pNetstatDisplay->getMessageCode(),(long long)m_pNetstatDisplay);
   addToMessageList(m_pNetstatStatus->getMessageCode(),(long long)m_pNetstatStatus);
   addToMessageList(m_pProcessorAdvice->getMessageCode(),(long long)m_pProcessorAdvice);
   addToMessageList(m_pTerminalAdvice->getMessageCode(),(long long)m_pTerminalAdvice);
   addToMessageList(m_pTerminalAdmin->getMessageCode(),(long long)m_pTerminalAdmin);
   addToMessageList(m_pElectronicJournal->getMessageCode(),(long long)m_pElectronicJournal);
   addToMessageList(m_pMessage622->getMessageCode(),(long long)m_pMessage622);
   //addToMessageList(m_pAdvantageMessage450Lcm->getMessageCode(),(long long)m_pAdvantageMessage450Lcm);
   //addToMessageList(m_pAdvantageMessage600Lcm->getMessageCode(),(long long)m_pAdvantageMessage600Lcm);
   addToMessageList(m_pAPFraudMaintenance->getMessageCode(),(long long)m_pAPFraudMaintenance);
   addToMessageList(m_pAPCardMaintenance->getMessageCode(),(long long)m_pAPCardMaintenance);
   addToMessageList("0855",(long long)m_pAPCardMaintenance);
   addToMessageList(m_pAPAcctMaintenance->getMessageCode(),(long long)m_pAPAcctMaintenance);
#else
   addToMessageList("0400",(long)m_pFinancial);
   addToMessageList("0401",(long)m_pFinancial);
   addToMessageList("0482",(long)m_pFinancial);
   addToMessageList("0491",(long)m_pFinancial);
   addToMessageList(m_pSettledAdjustment->getMessageCode(),(long)m_pSettledAdjustment);
   addToMessageList(m_pException->getMessageCode(), (long)m_pException);
   addToMessageList(m_pNetstatDisplay->getMessageCode(),(long)m_pNetstatDisplay);
   addToMessageList(m_pNetstatStatus->getMessageCode(),(long)m_pNetstatStatus);
   addToMessageList(m_pProcessorAdvice->getMessageCode(),(long)m_pProcessorAdvice);
   addToMessageList(m_pTerminalAdvice->getMessageCode(),(long)m_pTerminalAdvice);
   addToMessageList(m_pTerminalAdmin->getMessageCode(),(long)m_pTerminalAdmin);
   addToMessageList(m_pElectronicJournal->getMessageCode(),(long)m_pElectronicJournal);
   addToMessageList(m_pMessage622->getMessageCode(),(long)m_pMessage622);
   //addToMessageList(m_pAdvantageMessage450Lcm->getMessageCode(),(long)m_pAdvantageMessage450Lcm);
   //addToMessageList(m_pAdvantageMessage600Lcm->getMessageCode(),(long)m_pAdvantageMessage600Lcm);
   addToMessageList(m_pAPFraudMaintenance->getMessageCode(),(long)m_pAPFraudMaintenance);
   addToMessageList(m_pAPCardMaintenance->getMessageCode(),(long)m_pAPCardMaintenance);
   addToMessageList("0855",(long)m_pAPCardMaintenance);
   addToMessageList(m_pAPAcctMaintenance->getMessageCode(),(long)m_pAPAcctMaintenance);
#endif
   //addToMessageList(m_pInvalidAuthorization->getMessageCode(),(long)m_pInvalidAuthorization);
   if (Extract::instance()->getLong("DUSER   ","TCOFFSET=",&m_lTranClassOffset))
      Extract::instance()->getLong("DUSER   ","TCLEN=",&m_lTranClassLength);
   return MessageProcessor::initialization();
  //## end AdvantageMessageProcessor::initialization2%5E6BA5C60208.body
}

AdvantageMessageProcessor* AdvantageMessageProcessor::instance ()
{
  //## begin AdvantageMessageProcessor::instance%3C62D8AE0213.body preserve=yes
   return m_pInstance;
  //## end AdvantageMessageProcessor::instance%3C62D8AE0213.body
}

int AdvantageMessageProcessor::reset ()
{
  //## begin AdvantageMessageProcessor::reset%3C643CBC003E.body preserve=yes
   char szTestDate[9];
   memset(szTestDate,'\0',sizeof(szTestDate));
   size_t pos;
   string strContext((char*)Message::instance(Message::INBOUND)->context());

   if (strContext.find("TESTDATEOFF") != string::npos)
      setTestDate(szTestDate);
   else
   if ((pos = strContext.find("TESTDATE=")) != string::npos)
   {
      memcpy(szTestDate,strContext.data() + pos + 9,8);
      setTestDate(szTestDate);
      Console::display("ST276", szTestDate);
   }
   else
      ConfigurationRepository::instance()->reset();
   return 0;
  //## end AdvantageMessageProcessor::reset%3C643CBC003E.body
}

// Additional Declarations
  //## begin AdvantageMessageProcessor%3C612F8D0119.declarations preserve=yes
#ifdef _WIN64
void AdvantageMessageProcessor::addToMessageList (const string& strMessageCode, const long long lMessageClass)
#else
void AdvantageMessageProcessor::addToMessageList (const string& strMessageCode, const long lMessageClass)
#endif
{
   if (find(m_hDropList.begin(),m_hDropList.end(),strMessageCode) == m_hDropList.end())
      m_hMessages.insert(m_hMessages.begin(),MessageList::value_type(strMessageCode,lMessageClass));
}
  //## end AdvantageMessageProcessor%3C612F8D0119.declarations
//## begin module%3C613A8D000F.epilog preserve=yes
//## end module%3C613A8D000F.epilog
