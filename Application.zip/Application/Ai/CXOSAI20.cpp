//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52810B30009E.cm preserve=no
// $Date:   May 20 2020 11:45:16  $ $Author:   e1009510  $
// $Revision:   1.9  $
//## end module%52810B30009E.cm

//## begin module%52810B30009E.cp preserve=no
// Copyright (c) 1997 - 2012
// FIS
//## end module%52810B30009E.cp

//## Module: CXOSAI20%52810B30009E; Package body
//## Subsystem: AI%3597E7CC007A
// .
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXOSAI20.cpp

//## begin module%52810B30009E.additionalIncludes preserve=no
//## end module%52810B30009E.additionalIncludes

//## begin module%52810B30009E.includes preserve=yes
//## end module%52810B30009E.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRS93_h
#include "CXODRS93.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSAI20_h
#include "CXODAI20.hpp"
#endif


//## begin module%52810B30009E.declarations preserve=no
//## end module%52810B30009E.declarations

//## begin module%52810B30009E.additionalDeclarations preserve=yes
//## end module%52810B30009E.additionalDeclarations


// Class AdvantageAS2805Adjustment

AdvantageAS2805Adjustment::AdvantageAS2805Adjustment()
  //## begin AdvantageAS2805Adjustment::AdvantageAS2805Adjustment%5281097400C2_const.hasinit preserve=no
  //## end AdvantageAS2805Adjustment::AdvantageAS2805Adjustment%5281097400C2_const.hasinit
  //## begin AdvantageAS2805Adjustment::AdvantageAS2805Adjustment%5281097400C2_const.initialization preserve=yes
  : AdvantageMessage("0466","S200")
  //## end AdvantageAS2805Adjustment::AdvantageAS2805Adjustment%5281097400C2_const.initialization
{
  //## begin AdvantageAS2805Adjustment::AdvantageAS2805Adjustment%5281097400C2_const.body preserve=yes
   memcpy(m_sID,"AI20",4);
  //## end AdvantageAS2805Adjustment::AdvantageAS2805Adjustment%5281097400C2_const.body
}


AdvantageAS2805Adjustment::~AdvantageAS2805Adjustment()
{
  //## begin AdvantageAS2805Adjustment::~AdvantageAS2805Adjustment%5281097400C2_dest.body preserve=yes
  //## end AdvantageAS2805Adjustment::~AdvantageAS2805Adjustment%5281097400C2_dest.body
}



//## Other Operations (implementation)
bool AdvantageAS2805Adjustment::insert (Message& hMessage)
{
  //## begin AdvantageAS2805Adjustment::insert%528111DA0345.body preserve=yes
   FinancialExceptionSegment::instance()->reset();
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   hAS2805Adjustment* pAdjustment = (hAS2805Adjustment*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   char sTranId[4];
   memcpy(sTranId,pAdjustment->sTranId,4);
   char sLen[5] = {"    "};
   memcpy(sLen,pAdjustment->sLength,4);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(sTranId,4,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pV13AdvantageHeader->sHdrSource,sizeof(pV13AdvantageHeader->sHdrSource),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sTranDate,12,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sUsageCode,2,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sUserField1,2,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sUserField2,6,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(sLen,4,CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(sTranId,4,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pV13AdvantageHeader->sHdrSource,sizeof(pV13AdvantageHeader->sHdrSource),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sTranDate,12,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sUsageCode,2,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sUserField1,2,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sUserField2,6,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(sLen,4,CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   // This class will only handle 466 messages that have a tranid of x044 and were logged by STDAUS
   if (memcmp(sTranId,"X044",4) != 0)
      return false;
   UseCase hUseCase("TANDEM","## AD29 READ 0466 EXCPTNS",false);
   string strTSTAMP_TRANS("20");
   strTSTAMP_TRANS.append(pAdjustment->sTranDate,12);
   strTSTAMP_TRANS.append("00");
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      strTSTAMP_TRANS = strTemp;
   }
   FinancialExceptionSegment::instance()->setTSTAMP_TRANS(strTSTAMP_TRANS.data(),strTSTAMP_TRANS.length());
   FinancialExceptionSegment::instance()->setMSG_SOURCE(pV13AdvantageHeader->sHdrSource,sizeof(pV13AdvantageHeader->sHdrSource));
   char szTemp[PERCENTD];
   snprintf(szTemp,sizeof(szTemp),"%04d",ntohs(pV13AdvantageHeader->siHdrMsgCode));
   FinancialExceptionSegment::instance()->setMSG_CODE(szTemp,strlen(szTemp));
   snprintf(szTemp,sizeof(szTemp),"%02d",ntohs(pV13AdvantageHeader->siHdrMsgStep));
   FinancialExceptionSegment::instance()->setSTEP_CODE(szTemp,strlen(szTemp));
   FinancialExceptionSegment::instance()->setMSG_USAGE(pAdjustment->sUsageCode,sizeof(pAdjustment->sUsageCode));
   FinancialExceptionSegment::instance()->setUSER_FIELD1(pAdjustment->sUserField1,sizeof(pAdjustment->sUserField1));
   FinancialExceptionSegment::instance()->setUSER_FIELD2(pAdjustment->sUserField2,sizeof(pAdjustment->sUserField2));
   char szFirst[28] = {"TRAN_DATA_FMT              "};
   memcpy(szFirst + 15,szTemp,2);
   memcpy(szFirst + 17,pAdjustment->sUsageCode,sizeof(pAdjustment->sUsageCode));
   memcpy(szFirst + 19,pAdjustment->sUserField1,sizeof(pAdjustment->sUserField1));
   memcpy(szFirst + 21,pAdjustment->sUserField2,sizeof(pAdjustment->sUserField2));
   string strFirst;
   string strTRAN_DATA_FMT("00");
   for (int i = 0;i < 9;++i)
   {
      strFirst.assign(szFirst,27);
      switch (i)
      {
         case 0: // full match
            if (memcmp(szFirst + 21,"0000",4) == 0)
               memcpy(szFirst + 21,"0000  ",6);
            else
            if (memcmp(szFirst + 21,"ALSRJ",5) == 0)
               memcpy(szFirst + 21,"ALSRJ ",6);
            else
            if (szFirst[21] == 'E')
               memcpy(szFirst + 21,"E     ",6);
            else
            if (szFirst[21] == 'F')
               memcpy(szFirst + 21,"F     ",6);
            else
            if (szFirst[21] == 'T')
               memcpy(szFirst + 21,"T     ",6);
            else
            if (memcmp(szFirst + 21,"XX",2) == 0)
               memcpy(szFirst + 21,"XX    ",6);
            else
            if (memcmp(szFirst + 21,"DUP",3) == 0)
               memcpy(szFirst + 21,"DUP   ",6);
            else
            if (szFirst[21] == 'D')
               memcpy(szFirst + 21,"D     ",6);
            break;
         case 1: // partially masked user field 2
            break;
         case 2: // fully masked user field 2
            strFirst.replace(21,6,"      ",6);
            break;
         case 3: // masked step code and partially masked user field 2
            strFirst.replace(15,2,"  ",2);
            break;
         case 4: // masked usage code and partially masked user field 2
            strFirst.replace(17,2,"  ",2);
            break;
         case 5: // masked user field 1 and partially masked user field 2
            strFirst.replace(19,2,"  ",2);
            break;
         case 6: // masked step code and usage code and partially masked user field 2
            strFirst.replace(15,4,"    ",4);
            break;
         case 7: // masked step code and user field1 and partially masked user field 2
            strFirst.replace(15,2,"  ",2);
            strFirst.replace(19,2,"  ",2);
            break;
         case 8: // masked usage code and user field1 and partially masked user field 2
            strFirst.replace(17,4,"    ",4);
            break;
      }
      if (ConfigurationRepository::instance()->translate("X_GENERIC",strFirst,strTRAN_DATA_FMT,"","",-1,false))
         break;
   }
   FinancialExceptionSegment::instance()->setTRAN_DATA_FMT(strTRAN_DATA_FMT.data(),strTRAN_DATA_FMT.length());
   int iLen = atoi(sLen);
   if (strTRAN_DATA_FMT == "07" || strTRAN_DATA_FMT == "10")
   {
#ifdef MVS
      if (AdvantageMessageProcessor::instance()->getAsciiInput())
        CodeTable::translate(pAdjustment->sTranData,iLen,CodeTable::CX_ASCII_TO_EBCDIC);
#else
      if (!AdvantageMessageProcessor::instance()->getAsciiInput())
         CodeTable::translate(pAdjustment->sTranData,iLen,CodeTable::CX_EBCDIC_TO_ASCII);
#endif
   }
   if ((strTRAN_DATA_FMT != "05") && (strTRAN_DATA_FMT != "06"))
   {
      FinancialExceptionSegment::instance()->setSizeofTRAN_DATA(iLen);
      FinancialExceptionSegment::instance()->setTRAN_DATA(pAdjustment->sTranData,iLen);
   }
   strFirst.assign(pV13AdvantageHeader->sHdrSource,sizeof(pV13AdvantageHeader->sHdrSource));
   string strPROC_GRP_ID;
   ConfigurationRepository::instance()->translate("PROCESSORName",strFirst, strPROC_GRP_ID,"","",-1,false);
   FinancialExceptionSegment::instance()->setPROC_GRP_ID(strPROC_GRP_ID.data(),strPROC_GRP_ID.length());
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   FinancialExceptionSegment::instance()->write(&psBuffer);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageAS2805Adjustment::insert%528111DA0345.body
}

// Additional Declarations
  //## begin AdvantageAS2805Adjustment%5281097400C2.declarations preserve=yes
  //## end AdvantageAS2805Adjustment%5281097400C2.declarations

//## begin module%52810B30009E.epilog preserve=yes
//## end module%52810B30009E.epilog
