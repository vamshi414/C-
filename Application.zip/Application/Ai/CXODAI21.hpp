//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%528BC8A0001D.cm preserve=no
//	$Date:   Jan 31 2018 14:07:16  $ $Author:   e1009839  $
//	$Revision:   1.3  $
//## end module%528BC8A0001D.cm

//## begin module%528BC8A0001D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%528BC8A0001D.cp

//## Module: CXOSAI21%528BC8A0001D; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXODAI21.hpp

#ifndef CXOSAI21_h
#define CXOSAI21_h 1

//## begin module%528BC8A0001D.additionalIncludes preserve=no
//## end module%528BC8A0001D.additionalIncludes

//## begin module%528BC8A0001D.includes preserve=yes
//## end module%528BC8A0001D.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialExceptionSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class AdvantageMessageProcessor;
//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%528BC8A0001D.declarations preserve=no
//## end module%528BC8A0001D.declarations

//## begin module%528BC8A0001D.additionalDeclarations preserve=yes
//## end module%528BC8A0001D.additionalDeclarations


//## begin InvalidAuthorization%528BC83A0388.preface preserve=yes
//## end InvalidAuthorization%528BC83A0388.preface

//## Class: InvalidAuthorization%528BC83A0388
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%528CF0F50329;IF::Message { -> }
//## Uses: <unnamed>%528CF147014B;IF::CodeTable { -> F}
//## Uses: <unnamed>%528CF16C0099;monitor::UseCase { -> F}
//## Uses: <unnamed>%528CF18D0367;process::Application { -> F}
//## Uses: <unnamed>%528CF1CE030A;repositorysegment::FinancialExceptionSegment { -> F}
//## Uses: <unnamed>%528CF1FF01D8;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%54BE2D9B0397;configuration::ConfigurationRepository { -> F}

class DllExport InvalidAuthorization : public AdvantageMessage  //## Inherits: <unnamed>%528BC96902A8
{
  //## begin InvalidAuthorization%528BC83A0388.initialDeclarations preserve=yes
  //## end InvalidAuthorization%528BC83A0388.initialDeclarations

  public:
    //## Constructors (generated)
      InvalidAuthorization();

    //## Destructor (generated)
      virtual ~InvalidAuthorization();


    //## Other Operations (specified)
      //## Operation: insert%528BC9870103
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The eFunds Advantage Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin InvalidAuthorization%528BC83A0388.public preserve=yes
      //## end InvalidAuthorization%528BC83A0388.public

  protected:
    // Additional Protected Declarations
      //## begin InvalidAuthorization%528BC83A0388.protected preserve=yes
      //## end InvalidAuthorization%528BC83A0388.protected

  private:
    // Additional Private Declarations
      //## begin InvalidAuthorization%528BC83A0388.private preserve=yes
      //## end InvalidAuthorization%528BC83A0388.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin InvalidAuthorization%528BC83A0388.implementation preserve=yes
      //## end InvalidAuthorization%528BC83A0388.implementation

};

//## begin InvalidAuthorization%528BC83A0388.postscript preserve=yes
//## end InvalidAuthorization%528BC83A0388.postscript

//## begin module%528BC8A0001D.epilog preserve=yes
//## end module%528BC8A0001D.epilog


#endif
