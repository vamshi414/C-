//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C6135D601B5.cm preserve=no
//	$Date:   Oct 30 2019 08:54:00  $ $Author:   e1009839  $
//	$Revision:   1.25  $
//## end module%3C6135D601B5.cm

//## begin module%3C6135D601B5.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C6135D601B5.cp

//## Module: CXOSAI01%3C6135D601B5; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI01.cpp

//## begin module%3C6135D601B5.additionalIncludes preserve=no
//## end module%3C6135D601B5.additionalIncludes

//## begin module%3C6135D601B5.includes preserve=yes
#include "CXODIF11.hpp"
#include "CXODTM04.hpp"
//## end module%3C6135D601B5.includes

#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif


//## begin module%3C6135D601B5.declarations preserve=no
//## end module%3C6135D601B5.declarations

//## begin module%3C6135D601B5.additionalDeclarations preserve=yes
//## end module%3C6135D601B5.additionalDeclarations


// Class AdvantageMessage

//## begin AdvantageMessage::AsciiInput%5A54BAFF01B3.attr preserve=no  public: static bool {V} true
bool AdvantageMessage::m_bAsciiInput = true;
//## end AdvantageMessage::AsciiInput%5A54BAFF01B3.attr

//## begin AdvantageMessage::TestDate%5A54BC8B003B.attr preserve=no  public: static string {V}
string AdvantageMessage::m_strTestDate;
//## end AdvantageMessage::TestDate%5A54BC8B003B.attr

//## begin AdvantageMessage::TstampHash%3C61840B03D8.attr preserve=no  public: static unsigned int {VA} 0
unsigned int AdvantageMessage::m_lTstampHash = 0;
//## end AdvantageMessage::TstampHash%3C61840B03D8.attr

//## begin AdvantageMessage::<m_hAuditSegment>%3C61846400EA.role preserve=no  public: static repositorysegment::AuditSegment { -> VHgAN}
repositorysegment::AuditSegment AdvantageMessage::m_hAuditSegment;
//## end AdvantageMessage::<m_hAuditSegment>%3C61846400EA.role

//## begin AdvantageMessage::<m_pTransaction>%5A54C2A6017C.role preserve=no  public: static repositorysegment::Transaction { -> RHgAN}
repositorysegment::Transaction *AdvantageMessage::m_pTransaction = 0;
//## end AdvantageMessage::<m_pTransaction>%5A54C2A6017C.role

AdvantageMessage::AdvantageMessage()
  //## begin AdvantageMessage::AdvantageMessage%3C61312E031C_const.hasinit preserve=no
      : m_siUniquenessKey(0)
  //## end AdvantageMessage::AdvantageMessage%3C61312E031C_const.hasinit
  //## begin AdvantageMessage::AdvantageMessage%3C61312E031C_const.initialization preserve=yes
  //## end AdvantageMessage::AdvantageMessage%3C61312E031C_const.initialization
{
  //## begin AdvantageMessage::AdvantageMessage%3C61312E031C_const.body preserve=yes
  //## end AdvantageMessage::AdvantageMessage%3C61312E031C_const.body
}

AdvantageMessage::AdvantageMessage (const char* pszMessageCode, const char* pszSegmentID)
  //## begin AdvantageMessage::AdvantageMessage%3C628ED70000.hasinit preserve=no
      : m_siUniquenessKey(0)
  //## end AdvantageMessage::AdvantageMessage%3C628ED70000.hasinit
  //## begin AdvantageMessage::AdvantageMessage%3C628ED70000.initialization preserve=yes
   ,m_strMessageCode(pszMessageCode)
   ,m_strSegmentID(pszSegmentID)
  //## end AdvantageMessage::AdvantageMessage%3C628ED70000.initialization
{
  //## begin AdvantageMessage::AdvantageMessage%3C628ED70000.body preserve=yes
  //## end AdvantageMessage::AdvantageMessage%3C628ED70000.body
}


AdvantageMessage::~AdvantageMessage()
{
  //## begin AdvantageMessage::~AdvantageMessage%3C61312E031C_dest.body preserve=yes
  //## end AdvantageMessage::~AdvantageMessage%3C61312E031C_dest.body
}



//## Other Operations (implementation)
bool AdvantageMessage::deport (Message& hMessage)
{
  //## begin AdvantageMessage::deport%5A54BE9801BD.body preserve=yes
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name());
   char* psBuffer = hMessage.data();
   m_hAuditSegment.write(&psBuffer);
   m_pTransaction->deport(&psBuffer);
   ConfigurationRepository::instance()->write(&psBuffer,"2015113000000000",0); // ???
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   // !!! ((SwitchInterface*)Application::instance())->setRoute(strTSTAMP_TRANS.substr(12,4));
   hMessage.setDataLength(psBuffer - hMessage.data());
   m_hAuditSegment.reset();
   return true;
  //## end AdvantageMessage::deport%5A54BE9801BD.body
}

bool AdvantageMessage::insert (Message& hMessage)
{
  //## begin AdvantageMessage::insert%3C6183730186.body preserve=yes
   return false;
  //## end AdvantageMessage::insert%3C6183730186.body
}

void AdvantageMessage::reformatInstId (const char* psAdvgInstId)
{
  //## begin AdvantageMessage::reformatInstId%3C62DB840242.body preserve=yes
   memset(m_sStdInstId,' ',sizeof(m_sStdInstId));
   if (Customer::instance()->getCUST_CURRENCY_CODE() == "840"  &&
       memcmp(psAdvgInstId,"59",2) == 0  &&
       psAdvgInstId[10] != ' ')
      memcpy(m_sStdInstId,psAdvgInstId+2,9);
   else
      memcpy(m_sStdInstId,psAdvgInstId,11);
  //## end AdvantageMessage::reformatInstId%3C62DB840242.body
}

void AdvantageMessage::setTSTAMP_TRANS (const char* sNonStopClock)
{
  //## begin AdvantageMessage::setTSTAMP_TRANS%5A54C798036B.body preserve=yes
   string strTSTAMP_TRANS(NonStopClock::getYYYYMMDDHHMMSShh(sNonStopClock));
   if (!m_strTestDate.empty())
   {
      strTSTAMP_TRANS.replace(0,8,m_strTestDate);
      if (strTSTAMP_TRANS > Clock::instance()->getYYYYMMDDHHMMSSHN(true))
         strTSTAMP_TRANS.replace(8,2,Clock::instance()->getYYYYMMDDHHMMSSHN().data() + 8,2);
   }
   m_pTransaction->setTSTAMP_TRANS(strTSTAMP_TRANS);
  //## end AdvantageMessage::setTSTAMP_TRANS%5A54C798036B.body
}

// Additional Declarations
  //## begin AdvantageMessage%3C61312E031C.declarations preserve=yes
  //## end AdvantageMessage%3C61312E031C.declarations

//## begin module%3C6135D601B5.epilog preserve=yes
//## end module%3C6135D601B5.epilog
