//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A541E3D03DD.cm preserve=no
//	$Date:   May 20 2021 09:48:02  $ $Author:   E5350313  $
//	$Revision:   1.4  $
//## end module%5A541E3D03DD.cm

//## begin module%5A541E3D03DD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A541E3D03DD.cp

//## Module: CXOSAI31%5A541E3D03DD; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI31.cpp

//## begin module%5A541E3D03DD.additionalIncludes preserve=no
//## end module%5A541E3D03DD.additionalIncludes

//## begin module%5A541E3D03DD.includes preserve=yes
//## end module%5A541E3D03DD.includes

#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSAI31_h
#include "CXODAI31.hpp"
#endif


//## begin module%5A541E3D03DD.declarations preserve=no
//## end module%5A541E3D03DD.declarations

//## begin module%5A541E3D03DD.additionalDeclarations preserve=yes
//## end module%5A541E3D03DD.additionalDeclarations


// Class PlusAdjustment 

PlusAdjustment::PlusAdjustment()
  //## begin PlusAdjustment::PlusAdjustment%5A541E0003E6_const.hasinit preserve=no
  //## end PlusAdjustment::PlusAdjustment%5A541E0003E6_const.hasinit
  //## begin PlusAdjustment::PlusAdjustment%5A541E0003E6_const.initialization preserve=yes
   : AdvantageMessage("0466","S200")
  //## end PlusAdjustment::PlusAdjustment%5A541E0003E6_const.initialization
{
  //## begin PlusAdjustment::PlusAdjustment%5A541E0003E6_const.body preserve=yes
  //## end PlusAdjustment::PlusAdjustment%5A541E0003E6_const.body
}


PlusAdjustment::~PlusAdjustment()
{
  //## begin PlusAdjustment::~PlusAdjustment%5A541E0003E6_dest.body preserve=yes
  //## end PlusAdjustment::~PlusAdjustment%5A541E0003E6_dest.body
}



//## Other Operations (implementation)
bool PlusAdjustment::insert (Message& hMessage)
{
  //## begin PlusAdjustment::insert%5A541E1900C4.body preserve=yes
   hPlusAdjustment* p = (hPlusAdjustment*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   if (memcmp(p->sTranId,"X067",4) == 0
      && (memcmp(p->sMsgType,"0420",4) == 0
      || memcmp(p->sMsgType,"0422",4) == 0))
      ;
   else
      return false;
   UseCase hUseCase("TANDEM","## AI31 READ 0466 EXCEPTION",false);
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   char sTSTAMP_TRANS[17] = {"              00"};
   DateTime::calcCentury(p->sTranDate,sTSTAMP_TRANS);
   memcpy(sTSTAMP_TRANS + 2,p->sTranDate,6);
   memcpy(sTSTAMP_TRANS + 8,p->sTranTime,6);
   m_pTransaction->setTSTAMP_TRANS(sTSTAMP_TRANS);
   database::UniquenessKey::hash(p->sPan,16);
   database::UniquenessKey::hash(p->sCardAcptTermRef,8);
   database::UniquenessKey::hash(p->sSysTraceNo,6);
   m_pTransaction->setUNIQUENESS_KEY(database::UniquenessKey::getHash());
   memcpy(p->sTSTAMP_LOCAL_ADJ,sTSTAMP_TRANS,14);
   ::Template::instance()->map("PLUSADJUSTMENT",(const char*)p);
   return deport(hMessage);
  //## end PlusAdjustment::insert%5A541E1900C4.body
}

// Additional Declarations
  //## begin PlusAdjustment%5A541E0003E6.declarations preserve=yes
  //## end PlusAdjustment%5A541E0003E6.declarations

//## begin module%5A541E3D03DD.epilog preserve=yes
//## end module%5A541E3D03DD.epilog
