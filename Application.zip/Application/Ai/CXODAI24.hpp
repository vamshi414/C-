//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%57271D3B0209.cm preserve=no
//	$Date:   Jul 24 2018 10:43:38  $ $Author:   e1009610  $
//	$Revision:   1.3  $
//## end module%57271D3B0209.cm

//## begin module%57271D3B0209.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%57271D3B0209.cp

//## Module: CXOSAI24%57271D3B0209; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXODAI24.hpp

#ifndef CXOSAI24_h
#define CXOSAI24_h 1

//## begin module%57271D3B0209.additionalIncludes preserve=no
//## end module%57271D3B0209.additionalIncludes

//## begin module%57271D3B0209.includes preserve=yes
#include "CXODRU32.hpp"

struct hAdvantage450LCM
{
   char sMTI[4];
   char sFUNC_CODE[3];
   char sACT_CODE[3];
   char sMSG_REASON_CODE[4];
   char sTSTAMP_LOCAL[12];
   char sSYS_TRACE_AUDIT_NO[6];
   char sFILE_NAME[17];
   char sPAN[28];
   char sCARD_SEQ_NO[5];
   char sNET_ID_ISS[3];
   char sPROCESS_ID_ISS[6];
   char sPROC_ID_ISS[6];
   char sINST_ID_RECON_ISS[11];
   char cFILE_SELECT;
   char sINST_ID_ISS[11];
   char sCNTRY_PAN[3];
   char sORIG_NET_ID_ISS[3];
   char sORIG_PROCESS_ID_ISS[6];
   char sORIG_PROC_ID_ISS[6];
   char sORIG_INST_ID_ISS[11];
   char sCNX_NET_ID[4];
   char sPRINT_MASK_ID[8];
   char sTSTAMP_TRANS_RQST[10];
   char sUSER_ID[17];
   char sADDITIONAL_DATA[50];
   char sADL_RESP_DATA[44];
   char sTSTAMP_TRANS[6];          // do not xlate
   char sTRANSPORT_DATA[50];
   char sCARD_MAINT_ROUTING_ID[8];
   //short siProcessingFlag;
#ifdef _LITTLE_ENDIAN
   unsigned char bPrcFlagbit7 : 1;
   unsigned char bPrcFlagbit6 : 1;
   unsigned char bPrcFlagbit5 : 1;
   unsigned char bPrcFlagbit4 : 1;
   unsigned char bPrcFlagbit3 : 1;
   unsigned char bPrcFlagbit2 : 1;
   unsigned char bPrcFlagbit1 : 1;
   unsigned char bPrcFlagbit0 : 1;
   unsigned char bPrcFlagbit15 : 1;
   unsigned char bPrcFlagbit14 : 1;
   unsigned char bPrcFlagbit13 : 1;
   unsigned char bPrcFlagbit12 : 1;
   unsigned char bPrcFlagbit11 : 1;
   unsigned char bPrcFlagbit10 : 1;
   unsigned char bPrcFlagbit09 : 1;
   unsigned char bPrcFlagbit08 : 1;
#else
   unsigned char bPrcFlagbit0 : 1;
   unsigned char bPrcFlagbit1 : 1;
   unsigned char bPrcFlagbit2 : 1;
   unsigned char bPrcFlagbit3 : 1;
   unsigned char bPrcFlagbit4 : 1;
   unsigned char bPrcFlagbit5 : 1;
   unsigned char bPrcFlagbit6 : 1;
   unsigned char bPrcFlagbit7 : 1;
   unsigned char bPrcFlagbit8 : 1;
   unsigned char bPrcFlagbit9 : 1;
   unsigned char bPrcFlagbit10 : 1;
   unsigned char bPrcFlagbit11 : 1;
   unsigned char bPrcFlagbit12 : 1;
   unsigned char bPrcFlagbit13 : 1;
   unsigned char bPrcFlagbit14 : 1;
   unsigned char bPrcFlagbit15 : 1;
#endif
   char sTSAP_ID[8];
   int lTSAP_IDX;
   short siTSAP_MSG_SEQ_NO;
   char sDATE_ACTION[6];
   short siPMC_ERROR;
   int lPROC_QUEUE_ID;
   int lSS_QUEUE_ID;
   char sSECURITY_CODE[16];
   char sPROCESS_CODE[6];  
   char sDATE_EXP[4];
   char sDATE_SETTLE[4];
   char sINST_ID_ACQ[11];
   char sINST_ID_FWD[11];
   char sRESP_CODE[2];
   char sNET_TERM_ID[8];
   char sCARD_ACPT_ID[15];
   char sLEN_PAYMENT_TOKEN_DATA_OLD[3];
   char sPAYMENT_TOKEN_DATA_OLD[255];
   char sLEN_PAYMENT_TOKEN_DATA_ISO_OLD[3];
   char sPAYMENT_TOKEN_DATA_ISO_OLD[255];
   char sADL_DATA_PRIV_ACQ[255];
   char sLEN_PAYMENT_TOKEN_DATA[3];
   char sPAYMENT_TOKEN_DATA[999];
   char sLEN_PAYMENT_TOKEN_DATA_ISO[3];
   char sPAYMENT_TOKEN_DATA_ISO[999];
};
#include "CXODRU33.hpp"

//## end module%57271D3B0209.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class LifeCycleManagementSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class AdvantageMessageProcessor;
//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Mask;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class UniquenessKey;

} // namespace database

//## begin module%57271D3B0209.declarations preserve=no
//## end module%57271D3B0209.declarations

//## begin module%57271D3B0209.additionalDeclarations preserve=yes
//## end module%57271D3B0209.additionalDeclarations


//## begin AdvantageMessage450Lcm%57271CE60284.preface preserve=yes
//## end AdvantageMessage450Lcm%57271CE60284.preface

//## Class: AdvantageMessage450Lcm%57271CE60284
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%572721FF032D;IF::Message { -> F}
//## Uses: <unnamed>%5727224A01E6;monitor::UseCase { -> F}
//## Uses: <unnamed>%573547D50368;reusable::Mask { -> F}
//## Uses: <unnamed>%57354B6B0386;database::UniquenessKey { -> F}
//## Uses: <unnamed>%57354BD4014D;process::Application { -> F}
//## Uses: <unnamed>%57354C4D038E;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%57354C84021E;IF::CodeTable { -> F}
//## Uses: <unnamed>%574D63A400FE;repositorysegment::LifeCycleManagementSegment { -> F}
//## Uses: <unnamed>%5750436E01F8;configuration::ConfigurationRepository { -> F}

class DllExport AdvantageMessage450Lcm : public AdvantageMessage  //## Inherits: <unnamed>%57271E4F016F
{
  //## begin AdvantageMessage450Lcm%57271CE60284.initialDeclarations preserve=yes
  //## end AdvantageMessage450Lcm%57271CE60284.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageMessage450Lcm();

    //## Destructor (generated)
      virtual ~AdvantageMessage450Lcm();


    //## Other Operations (specified)
      //## Operation: insert%57271ED001C9
      virtual bool insert (IF::Message& hMessage);

      //## Operation: processFlags%574EB0C50195
      void processFlags (char* psFlags, char* pInFlags);

      //## Operation: translate%57273079037E
      void translate (char* pBuffer, int ilen);

    // Additional Public Declarations
      //## begin AdvantageMessage450Lcm%57271CE60284.public preserve=yes
      //## end AdvantageMessage450Lcm%57271CE60284.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageMessage450Lcm%57271CE60284.protected preserve=yes
      //## end AdvantageMessage450Lcm%57271CE60284.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageMessage450Lcm%57271CE60284.private preserve=yes
      //## end AdvantageMessage450Lcm%57271CE60284.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin AdvantageMessage450Lcm%57271CE60284.implementation preserve=yes
      bool m_bLCM_EXP_DATE;
      //## end AdvantageMessage450Lcm%57271CE60284.implementation

};

//## begin AdvantageMessage450Lcm%57271CE60284.postscript preserve=yes
//## end AdvantageMessage450Lcm%57271CE60284.postscript

//## begin module%57271D3B0209.epilog preserve=yes
//## end module%57271D3B0209.epilog


#endif
