//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EB2C49F0267.cm preserve=no
//   $Date:   May 08 2020 09:17:42  $ $Author:   e1009839  $
//   $Revision:   1.0  $
//## end module%5EB2C49F0267.cm

//## begin module%5EB2C49F0267.cp preserve=no
//   Copyright (c) 1997 - 2012
//   FIS
//## end module%5EB2C49F0267.cp

//## Module: CXOSAI48%5EB2C49F0267; Package body
//## Subsystem: AI%3597E7CC007A
//   .
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI48.cpp

//## begin module%5EB2C49F0267.additionalIncludes preserve=no
//## end module%5EB2C49F0267.additionalIncludes

//## begin module%5EB2C49F0267.includes preserve=yes
#include "CXODRS28.hpp"
//## end module%5EB2C49F0267.includes

#ifndef CXOSAI48_h
#include "CXODAI48.hpp"
#endif
//## begin module%5EB2C49F0267.declarations preserve=no
//## end module%5EB2C49F0267.declarations

//## begin module%5EB2C49F0267.additionalDeclarations preserve=yes
namespace
{
#define FIELDS301 15
struct hFraudMaintenance301* phFraudMaintenance301 = 0;
Fields hFraudMaintenance301_Fields[FIELDS301 + 1] =
{
   "t         ","",offsetof(hFraudMaintenance301,sUpdtTstamp),sizeof(phFraudMaintenance301->sUpdtTstamp),
   "t         ","",offsetof(hFraudMaintenance301,sMntTstamp),sizeof(phFraudMaintenance301->sMntTstamp),
   "a         ","",offsetof(hFraudMaintenance301,sRndmSeqNbr),sizeof(phFraudMaintenance301->sRndmSeqNbr),
   "a         ","",offsetof(hFraudMaintenance301,sCustSince),sizeof(phFraudMaintenance301->sCustSince),
   "a         ","",offsetof(hFraudMaintenance301,sAlrtEvntDate),sizeof(phFraudMaintenance301->sAlrtEvntDate),
   "a         ","",offsetof(hFraudMaintenance301,sAlrtEvntLtd),sizeof(phFraudMaintenance301->sAlrtEvntLtd),
   "t         ","",offsetof(hFraudMaintenance301,sSchdBlockDate),sizeof(phFraudMaintenance301->sSchdBlockDate),
   "a         ","",offsetof(hFraudMaintenance301,cSevLvl),sizeof(phFraudMaintenance301->cSevLvl),
   "a         ","",offsetof(hFraudMaintenance301,sAlrtEvntNum),sizeof(phFraudMaintenance301->sAlrtEvntNum),
   "o         ","",offsetof(hFraudMaintenance301,cFiller),sizeof(phFraudMaintenance301->cFiller),
   "a         ","",offsetof(hFraudMaintenance301,cVipIndicator),sizeof(phFraudMaintenance301->cVipIndicator),
   "a         ","",offsetof(hFraudMaintenance301,cTravelIndicator),sizeof(phFraudMaintenance301->cTravelIndicator),
   "a         ","",offsetof(hFraudMaintenance301,sTravelStartDate),sizeof(phFraudMaintenance301->sTravelStartDate),
   "a         ","",offsetof(hFraudMaintenance301,sTravelEndDate),sizeof(phFraudMaintenance301->sTravelEndDate),
   "o         ","",offsetof(hFraudMaintenance301,sFillerA),sizeof(phFraudMaintenance301->sFillerA),
   "~","",0,sizeof(hFraudMaintenance301),
};

#define FIELDS302 4
struct hFraudMaintenance302* phFraudMaintenance302 = 0;
Fields hFraudMaintenance302_Fields[FIELDS302 + 1] =
{
   "o         ","",offsetof(hFraudMaintenance302,sObsolete),sizeof(phFraudMaintenance302->sObsolete),
   "t         ","",offsetof(hFraudMaintenance302,sLastAddrChg),sizeof(phFraudMaintenance302->sLastAddrChg),
   "t         ","",offsetof(hFraudMaintenance302,sLastpinChg),sizeof(phFraudMaintenance302->sLastpinChg),
   "o         ","",offsetof(hFraudMaintenance302,sObsolete1),sizeof(phFraudMaintenance302->sObsolete1),
   "~","",0,sizeof(hFraudMaintenance302),
};

#define FIELDS303 7
struct hFraudMaintenance303* phFraudMaintenance303 = 0;
Fields hFraudMaintenance303_Fields[FIELDS303 + 1] =
{
   "a         ","",offsetof(hFraudMaintenance303,sWorkphone),sizeof(phFraudMaintenance303->sWorkphone),
   "a         ","",offsetof(hFraudMaintenance303,sDateOfBirth),sizeof(phFraudMaintenance303->sDateOfBirth),
   "a         ","",offsetof(hFraudMaintenance303,sSocSecNum),sizeof(phFraudMaintenance303->sSocSecNum),
   "a         ","",offsetof(hFraudMaintenance303,sMaidenName),sizeof(phFraudMaintenance303->sMaidenName),
   "a         ","",offsetof(hFraudMaintenance303,sUserValidation),sizeof(phFraudMaintenance303->sUserValidation),
   "a         ","",offsetof(hFraudMaintenance303,sMemberNum),sizeof(phFraudMaintenance303->sMemberNum),
   "o         ","",offsetof(hFraudMaintenance303,sFillerA),sizeof(phFraudMaintenance303->sFillerA),
   "~","",0,sizeof(hFraudMaintenance303),
};
}
//## end module%5EB2C49F0267.additionalDeclarations


// Class APFraudMaintenanceSegment

APFraudMaintenanceSegment::APFraudMaintenanceSegment()
  //## begin APFraudMaintenanceSegment::APFraudMaintenanceSegment%5EB2C326035B_const.hasinit preserve=no
  //## end APFraudMaintenanceSegment::APFraudMaintenanceSegment%5EB2C326035B_const.hasinit
  //## begin APFraudMaintenanceSegment::APFraudMaintenanceSegment%5EB2C326035B_const.initialization preserve=yes
  //## end APFraudMaintenanceSegment::APFraudMaintenanceSegment%5EB2C326035B_const.initialization
{
  //## begin APFraudMaintenanceSegment::APFraudMaintenanceSegment%5EB2C326035B_const.body preserve=yes
   memcpy(m_sID,"AI48",4);
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("FR01"),&hFraudMaintenance301_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("FR02"),&hFraudMaintenance302_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("FR03"),&hFraudMaintenance303_Fields[0]));
  //## end APFraudMaintenanceSegment::APFraudMaintenanceSegment%5EB2C326035B_const.body
}


APFraudMaintenanceSegment::~APFraudMaintenanceSegment()
{
  //## begin APFraudMaintenanceSegment::~APFraudMaintenanceSegment%5EB2C326035B_dest.body preserve=yes
  //## end APFraudMaintenanceSegment::~APFraudMaintenanceSegment%5EB2C326035B_dest.body
}


// Additional Declarations
  //## begin APFraudMaintenanceSegment%5EB2C326035B.declarations preserve=yes
  //## end APFraudMaintenanceSegment%5EB2C326035B.declarations

//## begin module%5EB2C49F0267.epilog preserve=yes
//## end module%5EB2C49F0267.epilog
