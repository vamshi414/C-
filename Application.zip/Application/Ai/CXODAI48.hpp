//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EB2C49C02C3.cm preserve=no
//	$Date:   May 08 2020 09:17:34  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5EB2C49C02C3.cm

//## begin module%5EB2C49C02C3.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5EB2C49C02C3.cp

//## Module: CXOSAI48%5EB2C49C02C3; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI48.hpp

#ifndef CXOSAI48_h
#define CXOSAI48_h 1

//## begin module%5EB2C49C02C3.additionalIncludes preserve=no
//## end module%5EB2C49C02C3.additionalIncludes

//## begin module%5EB2C49C02C3.includes preserve=yes
//## end module%5EB2C49C02C3.includes

#ifndef CXOSAI45_h
#include "CXODAI45.hpp"
#endif
//## begin module%5EB2C49C02C3.declarations preserve=no
//## end module%5EB2C49C02C3.declarations

//## begin module%5EB2C49C02C3.additionalDeclarations preserve=yes
//## end module%5EB2C49C02C3.additionalDeclarations


//## begin APFraudMaintenanceSegment%5EB2C326035B.preface preserve=yes
//## end APFraudMaintenanceSegment%5EB2C326035B.preface

//## Class: APFraudMaintenanceSegment%5EB2C326035B
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport APFraudMaintenanceSegment : public APSegment  //## Inherits: <unnamed>%5EB2C35E023D
{
  //## begin APFraudMaintenanceSegment%5EB2C326035B.initialDeclarations preserve=yes
  //## end APFraudMaintenanceSegment%5EB2C326035B.initialDeclarations

  public:
    //## Constructors (generated)
      APFraudMaintenanceSegment();

    //## Destructor (generated)
      virtual ~APFraudMaintenanceSegment();

    // Additional Public Declarations
      //## begin APFraudMaintenanceSegment%5EB2C326035B.public preserve=yes
      //## end APFraudMaintenanceSegment%5EB2C326035B.public

  protected:
    // Additional Protected Declarations
      //## begin APFraudMaintenanceSegment%5EB2C326035B.protected preserve=yes
      //## end APFraudMaintenanceSegment%5EB2C326035B.protected

  private:
    // Additional Private Declarations
      //## begin APFraudMaintenanceSegment%5EB2C326035B.private preserve=yes
      //## end APFraudMaintenanceSegment%5EB2C326035B.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin APFraudMaintenanceSegment%5EB2C326035B.implementation preserve=yes
      //## end APFraudMaintenanceSegment%5EB2C326035B.implementation

};

//## begin APFraudMaintenanceSegment%5EB2C326035B.postscript preserve=yes
//## end APFraudMaintenanceSegment%5EB2C326035B.postscript

//## begin module%5EB2C49C02C3.epilog preserve=yes
//## end module%5EB2C49C02C3.epilog


#endif
