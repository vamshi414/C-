//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C6137AB0280.cm preserve=no
//	$Date:   Dec 16 2020 11:23:06  $ $Author:   E5350313  $
//	$Revision:   1.56  $
//## end module%3C6137AB0280.cm

//## begin module%3C6137AB0280.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C6137AB0280.cp

//## Module: CXOSAI07%3C6137AB0280; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Dn_codes\V03.0A.R002\Dn\Server\Application\Ai\CXOSAI07.cpp

//## begin module%3C6137AB0280.additionalIncludes preserve=no
//## end module%3C6137AB0280.additionalIncludes

//## begin module%3C6137AB0280.includes preserve=yes
#include <sstream>
#include "CXODIF11.hpp"
#include "CXODIF16.hpp"
//## end module%3C6137AB0280.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSAI07_h
#include "CXODAI07.hpp"
#endif


//## begin module%3C6137AB0280.declarations preserve=no
//## end module%3C6137AB0280.declarations

//## begin module%3C6137AB0280.additionalDeclarations preserve=yes
//## end module%3C6137AB0280.additionalDeclarations


// Class AdvantageNetstatStatus

AdvantageNetstatStatus::AdvantageNetstatStatus()
  //## begin AdvantageNetstatStatus::AdvantageNetstatStatus%3C61326C03A9_const.hasinit preserve=no
      : m_bAD17Message(false)
  //## end AdvantageNetstatStatus::AdvantageNetstatStatus%3C61326C03A9_const.hasinit
  //## begin AdvantageNetstatStatus::AdvantageNetstatStatus%3C61326C03A9_const.initialization preserve=yes
  ,AdvantageMessage("1521","S907")
  //## end AdvantageNetstatStatus::AdvantageNetstatStatus%3C61326C03A9_const.initialization
{
  //## begin AdvantageNetstatStatus::AdvantageNetstatStatus%3C61326C03A9_const.body preserve=yes
   memcpy(m_sID,"AI07",4);
   string strTemp;
   Extract::instance()->getSpec("AD17", strTemp);
   if (strTemp.find("LOADAD17") != string::npos)
	   setAD17Message(true);
  //## end AdvantageNetstatStatus::AdvantageNetstatStatus%3C61326C03A9_const.body
}


AdvantageNetstatStatus::~AdvantageNetstatStatus()
{
  //## begin AdvantageNetstatStatus::~AdvantageNetstatStatus%3C61326C03A9_dest.body preserve=yes
  //## end AdvantageNetstatStatus::~AdvantageNetstatStatus%3C61326C03A9_dest.body
}



//## Other Operations (implementation)
bool AdvantageNetstatStatus::insert (Message& hMessage)
{
  //## begin AdvantageNetstatStatus::insert%3C618A110232.body preserve=yes
   UseCase hUseCase("TANDEM","## AD17 READ 1521 NETSTAT",false);
   *Message::instance(Message::OUTBOUND) = hMessage;
   hNetstatStatus* pNetstatStatus = (hNetstatStatus*)(Message::instance(Message::OUTBOUND)->data() + sizeof(hV13AdvantageHeader));
   if (ntohs(pNetstatStatus->siNumberMsgs) < 1)
      return false;
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)Message::instance(Message::OUTBOUND)->data();
   m_hEntityStatusSegment.reset();
   m_hAIMSBillingSegment.reset();
   m_hAuditSegment.reset();
   m_hListSegment.reset();
   AdvantageMessage::insert(hMessage);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pNetstatStatus->sMsgPrefix,sizeof(pNetstatStatus->sMsgPrefix),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pNetstatStatus->sMsgPrefix2nd,sizeof(pNetstatStatus->sMsgPrefix2nd),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pNetstatStatus->sSubject,sizeof(pNetstatStatus->sSubject),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pNetstatStatus->sOperatorID,sizeof(pNetstatStatus->sOperatorID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pNetstatStatus->sOriginProcess,((char*)(&pNetstatStatus->siParmCount) - pNetstatStatus->sOriginProcess),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pNetstatStatus->sParms,sizeof(pNetstatStatus->sParms),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pNetstatStatus->sStatusInfo,sizeof(pNetstatStatus->sStatusInfo),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pNetstatStatus->sIncidentDesc,sizeof(pNetstatStatus->sIncidentDesc),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pNetstatStatus->sContactType,sizeof(pNetstatStatus->sContactType),CodeTable::CX_ASCII_TO_EBCDIC);
      for (int m = 0;m < (ntohs(pNetstatStatus->siNumberMsgs));m++)
         CodeTable::translate(pNetstatStatus->MsgData[m].sText,sizeof(pNetstatStatus->MsgData[m].sText),CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pNetstatStatus->sMsgPrefix,sizeof(pNetstatStatus->sMsgPrefix),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pNetstatStatus->sMsgPrefix2nd,sizeof(pNetstatStatus->sMsgPrefix2nd),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pNetstatStatus->sSubject,sizeof(pNetstatStatus->sSubject),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pNetstatStatus->sOperatorID,sizeof(pNetstatStatus->sOperatorID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pNetstatStatus->sOriginProcess,((char*)(&pNetstatStatus->siParmCount) - pNetstatStatus->sOriginProcess),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pNetstatStatus->sParms,sizeof(pNetstatStatus->sParms),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pNetstatStatus->sStatusInfo,sizeof(pNetstatStatus->sStatusInfo),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pNetstatStatus->sIncidentDesc,sizeof(pNetstatStatus->sIncidentDesc),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pNetstatStatus->sContactType,sizeof(pNetstatStatus->sContactType),CodeTable::CX_EBCDIC_TO_ASCII);
      for (int m = 0;m < (ntohs(pNetstatStatus->siNumberMsgs));m++)
         CodeTable::translate(pNetstatStatus->MsgData[m].sText,sizeof(pNetstatStatus->MsgData[m].sText),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   char* pData2 = psBuffer + 4;
   m_hListSegment.write(&psBuffer);
   string strTSTAMP_TRANS(NonStopClock::getYYYYMMDDHHMMSShh(pNetstatStatus->sMsgTstamp));
   m_hEntityStatusSegment.setTSTAMP_TRANS(strTSTAMP_TRANS.data(),16);
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      m_hEntityStatusSegment.setTSTAMP_TRANS(strTemp.data(),16);
   }
   m_hEntityStatusSegment.setSUBJECT(pNetstatStatus->sSubject,8);
   double dSUBJECT_TYPE = (double)ntohs(pNetstatStatus->siSubjectType);
   if (dSUBJECT_TYPE < 0
      || dSUBJECT_TYPE > 9999)
      dSUBJECT_TYPE = 0;
   m_hEntityStatusSegment.setSUBJECT_TYPE(dSUBJECT_TYPE);
   if (AdvantageMessageProcessor::instance()->getVersion() == 130)
      m_hEntityStatusSegment.setCED_BUILD_NO(ntohl(pV13AdvantageHeader->lCED_BUILD_NO));
   m_hEntityStatusSegment.setMSG_NO((short)ntohs(pNetstatStatus->siMsgNumber));
   if (ntohs(pNetstatStatus->siSubjectType) == 60)
   {
      std::ostringstream oss;
      oss << setfill('0') << setw(5) << right << ntohs(pNetstatStatus->siAlertNumber);
      string strLowCashFlg;
      if (ConfigurationRepository::instance()->translate("X_DEV_LOW_CASH_FLG",string(oss.str().data(),oss.str().length()),strLowCashFlg,"","",0,false))
         m_hEntityStatusSegment.setLOW_CASH_FLG(strLowCashFlg.data(),1);
   }
   std::ostringstream oss;
   oss << setfill('0') << setw(4) << right << ntohs(pNetstatStatus->siAlertNumber);
   string strAlertNo(oss.str().data(),oss.str().length());
   m_hEntityStatusSegment.setALERT_NO(strAlertNo.data(),strAlertNo.length());
   string strSubjectState;
   int iCount = ntohs(pNetstatStatus->siNumberMsgs);
   for (int m = 0;m < ntohs(pNetstatStatus->siNumberMsgs);m++)
   {
      ++m_siUniquenessKey;
      if (m_siUniquenessKey > 1000)
         m_siUniquenessKey = 1;
      m_hEntityStatusSegment.setUNIQUENESS_KEY(m_siUniquenessKey);
      short siTempMsgLevel = ntohs(pNetstatStatus->MsgData[m].siMsgLevel) >= 0 &&
         ntohs(pNetstatStatus->MsgData[m].siMsgLevel) < 10000 ?
         ntohs(pNetstatStatus->MsgData[m].siMsgLevel) : 0;
      m_hEntityStatusSegment.setSEVERITY(siTempMsgLevel);
      m_hEntityStatusSegment.setSTATUS_TEXT(pNetstatStatus->MsgData[m].sText,70);
      if (strAlertNo == "0000")
      {
         string strBuffer((char*)m_hEntityStatusSegment.zSTATUS_TEXT(),6);
         size_t pos = strBuffer.find_last_not_of(' ');
         if (pos != string::npos)
            strBuffer.erase(pos + 1);
         pos = (strBuffer.find("-"));
         if (pos != string::npos)
            strBuffer.erase(pos,1);
         m_hEntityStatusSegment.setDEVICE_STATUS(strBuffer.data(),5);
      }
      else
      {
         m_hEntityStatusSegment.setDEVICE_STATUS(strAlertNo.data(),strAlertNo.length());
      }
      if (ConfigurationRepository::instance()->translate("X_GASPER_STATUS_CODE",
         string(m_hEntityStatusSegment.zDEVICE_STATUS()), strSubjectState,string(""),string(""),-1,0))
      {
         m_hEntityStatusSegment.setSUBJECT_STATE(strSubjectState.data(),strSubjectState.length());
      }
      else
         m_hEntityStatusSegment.setSUBJECT_STATE("\0",1);
	  if (getAD17Message() == false)
         m_hEntityStatusSegment.write(&psBuffer);
	  string strStatusText(m_hEntityStatusSegment.zSTATUS_TEXT());
	  transform(strStatusText.begin(),strStatusText.end(),strStatusText.begin(),::toupper);
	  if ((strStatusText.find("DH-041") != string::npos) && (strStatusText.find("INITIALIZE EPP COMPLETED SUCCESSFULLY") != string::npos))
	  {
		  m_hAIMSBillingSegment.setTSTAMP_TRANS(m_hEntityStatusSegment.zTSTAMP_TRANS(), 16);
		  m_hAIMSBillingSegment.setUNIQUENESS_KEY(m_siUniquenessKey);
		  m_pAdvantageMessageProcessor = AdvantageMessageProcessor::instance();
		  string strRecType = m_pAdvantageMessageProcessor->getMessageCode();
         if (!memcmp(strRecType.data(),"1521",4))
            strRecType.assign("1511");
		  m_hAIMSBillingSegment.setRECORD_TYPE(strRecType.data(),strRecType.length());
		  string strInstId;
		  if (ConfigurationRepository::instance()->translate("DEVICE",m_hEntityStatusSegment.zSUBJECT(),strInstId," "," ",-1,false))
		  {
			  string strINST_ID_RECN_ACQ_B = strInstId.substr(0,11);
			  size_t n = strINST_ID_RECN_ACQ_B.find_last_not_of(' ');
			  strINST_ID_RECN_ACQ_B.erase(n + 1);
			  m_hAIMSBillingSegment.setINST_ID(strINST_ID_RECN_ACQ_B.data(),strINST_ID_RECN_ACQ_B.length());
		  }
          m_hAIMSBillingSegment.setTERM_ID(m_hEntityStatusSegment.zSUBJECT(),8);
          m_hAIMSBillingSegment.setBUSINESS_KEY("");
		  m_hAIMSBillingSegment.write(&psBuffer);
		  iCount++;
	  }
   }
   m_hListSegment.update(pData2,iCount,psBuffer - pData2);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageNetstatStatus::insert%3C618A110232.body
}

// Additional Declarations
  //## begin AdvantageNetstatStatus%3C61326C03A9.declarations preserve=yes
  //## end AdvantageNetstatStatus%3C61326C03A9.declarations

//## begin module%3C6137AB0280.epilog preserve=yes
//## end module%3C6137AB0280.epilog
