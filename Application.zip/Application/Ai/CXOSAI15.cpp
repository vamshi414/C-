//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3C613A0E004E.cm preserve=no
//	$Date:   Jun 14 2019 16:08:44  $ $Author:   e1009839  $
//	$Revision:   1.54  $
//## end module%3C613A0E004E.cm

//## begin module%3C613A0E004E.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C613A0E004E.cp

//## Module: CXOSAI15%3C613A0E004E; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.3B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI15.cpp

//## begin module%3C613A0E004E.additionalIncludes preserve=no
//## end module%3C613A0E004E.additionalIncludes

//## begin module%3C613A0E004E.includes preserve=yes
#include "CXODIF11.hpp"
#include "CXODNS29.hpp"
#include "CXODRS01.hpp"
#include "CXODRS02.hpp"
//## end module%3C613A0E004E.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSAI15_h
#include "CXODAI15.hpp"
#endif


//## begin module%3C613A0E004E.declarations preserve=no
//## end module%3C613A0E004E.declarations

//## begin module%3C613A0E004E.additionalDeclarations preserve=yes
//## end module%3C613A0E004E.additionalDeclarations


// Class AdvantageTerminalAdvice

AdvantageTerminalAdvice::AdvantageTerminalAdvice()
  //## begin AdvantageTerminalAdvice::AdvantageTerminalAdvice%3C61340801A5_const.hasinit preserve=no
  //## end AdvantageTerminalAdvice::AdvantageTerminalAdvice%3C61340801A5_const.hasinit
  //## begin AdvantageTerminalAdvice::AdvantageTerminalAdvice%3C61340801A5_const.initialization preserve=yes
   : AdvantageMessage("0461","A001")
  //## end AdvantageTerminalAdvice::AdvantageTerminalAdvice%3C61340801A5_const.initialization
{
  //## begin AdvantageTerminalAdvice::AdvantageTerminalAdvice%3C61340801A5_const.body preserve=yes
   memcpy(m_sID,"AI15",4);
  //## end AdvantageTerminalAdvice::AdvantageTerminalAdvice%3C61340801A5_const.body
}


AdvantageTerminalAdvice::~AdvantageTerminalAdvice()
{
  //## begin AdvantageTerminalAdvice::~AdvantageTerminalAdvice%3C61340801A5_dest.body preserve=yes
  //## end AdvantageTerminalAdvice::~AdvantageTerminalAdvice%3C61340801A5_dest.body
}



//## Other Operations (implementation)
bool AdvantageTerminalAdvice::insert (IF::Message& hMessage)
{
  //## begin AdvantageTerminalAdvice::insert%3C61867900EA.body preserve=yes
   UseCase hUseCase("TANDEM","## AD25 READ 0461 TERM ADVICE",false);
   *Message::instance(Message::OUTBOUND) = *Message::instance(Message::INBOUND);
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)Message::instance(Message::OUTBOUND)->data();
   string strHdrTimestamp(NonStopClock::getYYYYMMDDHHMMSShh(pV13AdvantageHeader->sHdrTimestamp1));
   hTerminalAdvice* pTerminalAdvice = (hTerminalAdvice*)(Message::instance(Message::OUTBOUND)->data() + sizeof(hV13AdvantageHeader));
   m_hCutoffSegment.reset();
   m_hAuditSegment.reset();
   m_hDeviceAdminSegment.reset();
   m_siUniquenessKey += 1;
   if (m_siUniquenessKey > 1000)
      m_siUniquenessKey = 1;
   AdvantageMessage::insert(hMessage);
   int x = 0;
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pTerminalAdvice->sMTI,pTerminalAdvice->sTimestamp - pTerminalAdvice->sMTI,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pTerminalAdvice->sCardholder,sizeof(pTerminalAdvice->sCardholder),CodeTable::CX_ASCII_TO_EBCDIC);
      for (x = 0;x < pTerminalAdvice->siTypesInUse;x++)
      {
         CodeTable::translate(pTerminalAdvice->TotalsTypes[x].sFunction,8,CodeTable::CX_ASCII_TO_EBCDIC);
         CodeTable::translate(pTerminalAdvice->TotalsTypes[x].sAcqDate,8,CodeTable::CX_ASCII_TO_EBCDIC);
      }
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pTerminalAdvice->sMTI,pTerminalAdvice->sTimestamp - pTerminalAdvice->sMTI,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pTerminalAdvice->sCardholder,sizeof(pTerminalAdvice->sCardholder),CodeTable::CX_EBCDIC_TO_ASCII);
      for (x = 0;x < ntohs(pTerminalAdvice->siTypesInUse);x++)
      {
         CodeTable::translate(pTerminalAdvice->TotalsTypes[x].sFunction,8,CodeTable::CX_EBCDIC_TO_ASCII);
         CodeTable::translate(pTerminalAdvice->TotalsTypes[x].sAcqDate,8,CodeTable::CX_EBCDIC_TO_ASCII);
      }
   }
#endif
   bool bBusinessDateChange = false;
   bool b572 = false;
   for (int i = 0;i < 8;i++)
   {
      if (memcmp(pTerminalAdvice->TotalsTypes[i].sFunction,"589",3) == 0)
         bBusinessDateChange = true;
      else
      if (memcmp(pTerminalAdvice->TotalsTypes[i].sFunction,"572",3) == 0)
         b572 = true;
      else
      if (memcmp(pTerminalAdvice->TotalsTypes[i].sFunction,"ATM",3) == 0
         || memcmp(pTerminalAdvice->TotalsTypes[i].sFunction,"AUT",3) == 0
         || memcmp(pTerminalAdvice->TotalsTypes[i].sFunction,"RMT",3) == 0)
         m_hDeviceAdminSegment.setRECON_IND_ACQ(pTerminalAdvice->TotalsTypes[i].sFunction,3);
   }
   int iCOH = 320;
   int iWD = 101;
   Extract::instance()->getLong("DUSER   ","SC=",&iCOH);
   Extract::instance()->getLong("DUSER   ","WD=",&iWD);
   for (x = 0;x < ntohs(pTerminalAdvice->siTypesInUse);x++)
   {
      short iStart = ntohs(pTerminalAdvice->TotalsTypes[x].siStartBucket);
      short iEnd = iStart + ntohs(pTerminalAdvice->TotalsTypes[x].siBucketCnt);
      for (iStart;iStart < iEnd;iStart++)
      {
#ifdef MVS
         if (AdvantageMessageProcessor::instance()->getAsciiInput())
            CodeTable::translate(pTerminalAdvice->Buckets[iStart].sDescription,20,CodeTable::CX_ASCII_TO_EBCDIC);
#else
         if (!AdvantageMessageProcessor::instance()->getAsciiInput())
            CodeTable::translate(pTerminalAdvice->Buckets[iStart].sDescription,20,CodeTable::CX_EBCDIC_TO_ASCII);
#endif
         int iDescCode(ntohs(pTerminalAdvice->Buckets[iStart].siDescCode));
         if (iDescCode >= iCOH
            && iDescCode <= iCOH + 8)
         {
            short m = iDescCode - iCOH;
            if (m == 0)
            {
               m_hDeviceAdminSegment.setDEVICE_AMT(ntohl(pTerminalAdvice->Buckets[iStart].lAmt1),ntohl(pTerminalAdvice->Buckets[iStart].lAmt2));
               m_hDeviceAdminSegment.setDEVICE_CUR_TYPE(1);
               m_hDeviceAdminSegment.setDEVICE_CUR_TRAN(Customer::instance()->getCUST_CURRENCY_CODE().data(),Customer::instance()->getCUST_CURRENCY_CODE().length());
            }
            else
            {
               m_hDeviceAdminSegment.setCAN_ITEM_AMTn(ntohl(pTerminalAdvice->Buckets[iStart].lAmt1),ntohl(pTerminalAdvice->Buckets[iStart].lAmt2),m - 1);
               m_hDeviceAdminSegment.setCAN_ITEM_COUNTn(ntohl(pTerminalAdvice->Buckets[iStart].lCount),m - 1);
               if (m_hDeviceAdminSegment.getCAN_ITEM_COUNTn(m - 1) != 0)
                  m_hDeviceAdminSegment.setCAN_ITEM_VALUEn(m_hDeviceAdminSegment.getCAN_ITEM_AMTn(m - 1) / m_hDeviceAdminSegment.getCAN_ITEM_COUNTn(m - 1),m - 1);
               m_hDeviceAdminSegment.setCAN_CUR_CODEn(Customer::instance()->getCUST_CURRENCY_CODE().data(),Customer::instance()->getCUST_CURRENCY_CODE().length(),m - 1);
               m_hDeviceAdminSegment.setCAN_CUR_TYPEn(1,m - 1);
            }
         }
         else
         if (iDescCode >= iWD
            && iDescCode <= iWD + 2)
         {
            short m = iDescCode - iWD;
            m_hDeviceAdminSegment.setDEVICE_WD_AMT(ntohl(pTerminalAdvice->Buckets[iStart].lAmt1),ntohl(pTerminalAdvice->Buckets[iStart].lAmt2));
            m_hDeviceAdminSegment.setDEVICE_CUR_TYPE(1);
            m_hDeviceAdminSegment.setDEVICE_CUR_TRAN(Customer::instance()->getCUST_CURRENCY_CODE().data(),Customer::instance()->getCUST_CURRENCY_CODE().length());
         }
      }
   }
   if (b572)
      m_hDeviceAdminSegment.setFUNCTION_CODE("572",3);
   else
      m_hDeviceAdminSegment.setFUNCTION_CODE(pTerminalAdvice->TotalsTypes[0].sFunction,3);
   string strTSTAMP_END(NonStopClock::getYYYYMMDDHHMMSShh(pTerminalAdvice->TotalsTypes[0].sReqTimestamp));
   if (strTSTAMP_END == "2000000000000000")
      return false;
   m_hCutoffSegment.setTSTAMP_END(strTSTAMP_END.data(),16);
   m_hDeviceAdminSegment.setTSTAMP_TRANS(strTSTAMP_END.data(),16);
   bool b = true;
   for (int i = 0;i < 6;++i)
      if (!isdigit(pTerminalAdvice->TotalsTypes[0].sAcqDate[i]))
      {
         b = false;
         break;
      }
   if (!b)
   {
      m_hCutoffSegment.setDATE_RECON(strTSTAMP_END.data(),8);
      m_hDeviceAdminSegment.setDATE_RECON_ACQ(strTSTAMP_END.data(),8);
   }
   else
   {
      char sCentury[2];
      char sDate[8];
      DateTime::calcCentury(pTerminalAdvice->TotalsTypes[0].sAcqDate,sCentury);
      memcpy(sDate,sCentury,2);
      memcpy(sDate + 2,pTerminalAdvice->TotalsTypes[0].sAcqDate,6);
      m_hCutoffSegment.setDATE_RECON(sDate,8);
      m_hDeviceAdminSegment.setDATE_RECON_ACQ(sDate,8);
   }
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   m_hCutoffSegment.setENTITY_ID(pTerminalAdvice->sDevice,8);
   m_hCutoffSegment.setENTITY_TYPE("AT",2);
   m_hCutoffSegment.setCUTOFF_TYPE("99",2);
   m_hDeviceAdminSegment.setTOTALS_CLASS(pTerminalAdvice->sTotalsClass,2);
   m_hDeviceAdminSegment.setCLERK_ID(pTerminalAdvice->sClerk,28);
   m_hDeviceAdminSegment.setNET_TERM_ID(pTerminalAdvice->sDevice,8);
   string strNET_TERM_ID(pTerminalAdvice->sDevice,8);
   string m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B;
   string strDEFAULT_CUR_CODE;
   if (ConfigurationRepository::instance()->translate("DEVICE",strNET_TERM_ID,m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B,"DEV_ADMIN_LOCATOR","INST_ID_RECN_ACQ_B",0))
   {
      string strINST_ID_RECN_ACQ(m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.data(),11);
      m_hDeviceAdminSegment.setINST_ID_RECN_ACQ_B(strINST_ID_RECN_ACQ.data(),strINST_ID_RECN_ACQ.length());
      strDEFAULT_CUR_CODE.assign(ConfigurationRepository::instance()->getThird().data() + 13,3);
      if (strDEFAULT_CUR_CODE != (const char*)"   ")
      {
         m_hDeviceAdminSegment.setDEVICE_CUR_TRAN(strDEFAULT_CUR_CODE.data(),3);
         for (short m = 0; m <= 7;++m)
            m_hDeviceAdminSegment.setCAN_CUR_CODEn(strDEFAULT_CUR_CODE.data(),3,m);
      }
      string strPROC_ID_ACQ_B;
      if (ConfigurationRepository::instance()->translate("INSTITUTION",strINST_ID_RECN_ACQ,strPROC_ID_ACQ_B,"DEV_ADMIN_LOCATOR","PROC_ID_ACQ_B",0))
      {
         m_hDeviceAdminSegment.setPROC_ID_ACQ_B(strPROC_ID_ACQ_B.data(),strPROC_ID_ACQ_B.length());
         string PROC_GRP_ID_ACQ_B;
         if (ConfigurationRepository::instance()->translate("PROCESSOR",strPROC_ID_ACQ_B, PROC_GRP_ID_ACQ_B, "DEV_ADMIN_LOCATOR", "PROC_GRP_ID_ACQ_B", 0))
            m_hDeviceAdminSegment.setPROC_GRP_ID_ACQ_B(PROC_GRP_ID_ACQ_B.data(),PROC_GRP_ID_ACQ_B.length());
      }
      else
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   }
   else
      ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   if (Customer::instance()->getTest())
      memcpy(pTerminalAdvice->sCardholder + 6,"999999",6);
   m_hDeviceAdminSegment.setPAN(pTerminalAdvice->sCardholder,28);
   m_hDeviceAdminSegment.setMTI(pTerminalAdvice->sMTI,4);
   m_hDeviceAdminSegment.setUNIQUENESS_KEY(m_siUniquenessKey);
   m_hDeviceAdminSegment.setACQ_PLAT_PROD_ID("A",1);
   m_hDeviceAdminSegment.setACT_CODE("000",3);
   if (getTestDate().length() > 0)
   {
      strTSTAMP_END.replace(0,8,getTestDate().data(),8);
      m_hCutoffSegment.setTSTAMP_END(strTSTAMP_END.data(),16);
      m_hCutoffSegment.setDATE_RECON(strTSTAMP_END.data(),8);
      m_hDeviceAdminSegment.setTSTAMP_TRANS(strTSTAMP_END.data(),16);
      m_hDeviceAdminSegment.setDATE_RECON_ACQ(strTSTAMP_END.data(),8);
   }
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   string strTemp((char*)m_hDeviceAdminSegment.zTSTAMP_TRANS());
   if (strTemp == "0000000000000000")
      strTemp = strHdrTimestamp;
   m_hDeviceAdminSegment.setTSTAMP_TRANS(strTemp.data(),strTemp.length());
   char* p = psBuffer + 4;
   ListSegment hListSegment;
   hListSegment.write(&psBuffer);
   int iCount = 1;
   if (bBusinessDateChange)
   {
      m_hDeviceAdminSegment.write(&psBuffer);
      iCount = 2;
      m_hDeviceAdminSegment.setFUNCTION_CODE("589",3);
      m_siUniquenessKey += 1;
      if (m_siUniquenessKey > 1000)
         m_siUniquenessKey = 1;
      m_hDeviceAdminSegment.setUNIQUENESS_KEY(m_siUniquenessKey);
   }
   if ((memcmp(pTerminalAdvice->sMTI,"1510",4) == 0)
      && ((memcmp(pTerminalAdvice->TotalsTypes[0].sFunction,"572",3) == 0)
      || (memcmp(pTerminalAdvice->TotalsTypes[0].sFunction,"573",3) == 0)
      || (memcmp(pTerminalAdvice->TotalsTypes[0].sFunction,"589",3) == 0)
      || (memcmp(pTerminalAdvice->TotalsTypes[0].sFunction,"595",3) == 0)))
      m_hDeviceAdminSegment.write(&psBuffer);
   for (int i = 0;i < ntohs(pTerminalAdvice->siTypesInUse);i++)
   {
      ATMReceiptSegment hATMReceiptSegment;
      hATMReceiptSegment.setCLERK_ID(pTerminalAdvice->sClerk,28);
      hATMReceiptSegment.setCURRENCY_CODE(strDEFAULT_CUR_CODE.data(),strDEFAULT_CUR_CODE.length());
      hATMReceiptSegment.setDATE_RECON(m_hDeviceAdminSegment.zDATE_RECON_ACQ(),8);
      hATMReceiptSegment.setFUNC_CODE(pTerminalAdvice->TotalsTypes[i].sFunction,3);
      hATMReceiptSegment.setMTI("1510",4);
      hATMReceiptSegment.setNET_TERM_ID(strNET_TERM_ID.data(),strNET_TERM_ID.length());
      hATMReceiptSegment.setPAN(pTerminalAdvice->sCardholder,28);
      hATMReceiptSegment.setRECON_ID(pTerminalAdvice->TotalsTypes[i].sReconID,3);
      hATMReceiptSegment.setTOTALS_CLASS(pTerminalAdvice->sTotalsClass,2);
      hATMReceiptSegment.setTSTAMP_LOCAL(strTSTAMP_END.data(),14);
      hATMReceiptSegment.setTSTAMP_TRANS(m_hDeviceAdminSegment.zTSTAMP_TRANS(),16);
      hATMReceiptSegment.write(&psBuffer);
      ++iCount;
      short iStart = ntohs(pTerminalAdvice->TotalsTypes[i].siStartBucket);
      short iEnd = iStart + ntohs(pTerminalAdvice->TotalsTypes[i].siBucketCnt);
      int iSEQ_NO = 0;
      for (;iStart < iEnd;iStart++)
      {
         ATMReceiptEntrySegment hATMReceiptEntrySegment;
         hATMReceiptEntrySegment.setFUNC_CODE(pTerminalAdvice->TotalsTypes[i].sFunction,3);
         hATMReceiptEntrySegment.setLINE_AMOUNT(Segment::lltof(ntohl(pTerminalAdvice->Buckets[iStart].lAmt1),ntohl(pTerminalAdvice->Buckets[iStart].lAmt2)));
         hATMReceiptEntrySegment.setLINE_CODE(ntohs(pTerminalAdvice->Buckets[iStart].siDescCode));
         hATMReceiptEntrySegment.setLINE_COUNT(ntohl(pTerminalAdvice->Buckets[iStart].lCount));
         hATMReceiptEntrySegment.setLINE_DESCRIPTION(pTerminalAdvice->Buckets[iStart].sDescription,20);
         hATMReceiptEntrySegment.setNET_TERM_ID(strNET_TERM_ID.data(),strNET_TERM_ID.length());
         hATMReceiptEntrySegment.setSEQ_NO(++iSEQ_NO);
         hATMReceiptEntrySegment.setTSTAMP_LOCAL(strTSTAMP_END.data(),14);
         hATMReceiptEntrySegment.write(&psBuffer);
         ++iCount;
      }
   }
   hListSegment.update(p,iCount,(psBuffer - p));
   if (b572)
      m_hCutoffSegment.write(&psBuffer);
   ConfigurationRepository::instance()->write(&psBuffer,strTemp,m_hDeviceAdminSegment.getUNIQUENESS_KEY());
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageTerminalAdvice::insert%3C61867900EA.body
}

// Additional Declarations
  //## begin AdvantageTerminalAdvice%3C61340801A5.declarations preserve=yes
  //## end AdvantageTerminalAdvice%3C61340801A5.declarations

//## begin module%3C613A0E004E.epilog preserve=yes
//## end module%3C613A0E004E.epilog
