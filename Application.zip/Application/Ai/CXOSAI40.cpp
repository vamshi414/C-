//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A54336800FC.cm preserve=no
//	$Date:   May 15 2018 11:23:54  $ $Author:   e1009839  $
//	$Revision:   1.2  $
//## end module%5A54336800FC.cm

//## begin module%5A54336800FC.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A54336800FC.cp

//## Module: CXOSAI40%5A54336800FC; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI40.cpp

//## begin module%5A54336800FC.additionalIncludes preserve=no
//## end module%5A54336800FC.additionalIncludes

//## begin module%5A54336800FC.includes preserve=yes
//## end module%5A54336800FC.includes

#ifndef CXOSDB49_h
#include "CXODDB49.hpp"
#endif
#ifndef CXOSAI40_h
#include "CXODAI40.hpp"
#endif


//## begin module%5A54336800FC.declarations preserve=no
//## end module%5A54336800FC.declarations

//## begin module%5A54336800FC.additionalDeclarations preserve=yes
//## end module%5A54336800FC.additionalDeclarations


// Class ElectronicJournal 

ElectronicJournal::ElectronicJournal()
  //## begin ElectronicJournal::ElectronicJournal%5A542CDF0095_const.hasinit preserve=no
  //## end ElectronicJournal::ElectronicJournal%5A542CDF0095_const.hasinit
  //## begin ElectronicJournal::ElectronicJournal%5A542CDF0095_const.initialization preserve=yes
   : AdvantageMessage("0623","E001")
  //## end ElectronicJournal::ElectronicJournal%5A542CDF0095_const.initialization
{
  //## begin ElectronicJournal::ElectronicJournal%5A542CDF0095_const.body preserve=yes
  //## end ElectronicJournal::ElectronicJournal%5A542CDF0095_const.body
}


ElectronicJournal::~ElectronicJournal()
{
  //## begin ElectronicJournal::~ElectronicJournal%5A542CDF0095_dest.body preserve=yes
  //## end ElectronicJournal::~ElectronicJournal%5A542CDF0095_dest.body
}



//## Other Operations (implementation)
bool ElectronicJournal::insert (Message& hMessage)
{
  //## begin ElectronicJournal::insert%5A542D0100B4.body preserve=yes
   UseCase hUseCase("TANDEM","## AI40 READ 0623 ATM EJ",false,true);
   segEJ* p = (segEJ*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   setTSTAMP_TRANS(pV13AdvantageHeader->sFiller);
   database::UniquenessKey::hash(p->sNET_TERM_ID,8);
   m_pTransaction->setUNIQUENESS_KEY(database::UniquenessKey::getHash());
   ::Template::instance()->map("ELECTRONICJOURNAL",(const char*)p);
   return deport(hMessage);
  //## end ElectronicJournal::insert%5A542D0100B4.body
}

// Additional Declarations
  //## begin ElectronicJournal%5A542CDF0095.declarations preserve=yes
  //## end ElectronicJournal%5A542CDF0095.declarations

//## begin module%5A54336800FC.epilog preserve=yes
//## end module%5A54336800FC.epilog
