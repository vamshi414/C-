//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A541FFC0010.cm preserve=no
//	$Date:   31 Jan 2018 14:11:08  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5A541FFC0010.cm

//## begin module%5A541FFC0010.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A541FFC0010.cp

//## Module: CXOSAI32%5A541FFC0010; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI32.hpp

#ifndef CXOSAI32_h
#define CXOSAI32_h 1

//## begin module%5A541FFC0010.additionalIncludes preserve=no
//## end module%5A541FFC0010.additionalIncludes

//## begin module%5A541FFC0010.includes preserve=yes
//## end module%5A541FFC0010.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
//## begin module%5A541FFC0010.declarations preserve=no
//## end module%5A541FFC0010.declarations

//## begin module%5A541FFC0010.additionalDeclarations preserve=yes
//## end module%5A541FFC0010.additionalDeclarations


//## begin StdFee%5A541F080088.preface preserve=yes
//## end StdFee%5A541F080088.preface

//## Class: StdFee%5A541F080088
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport StdFee : public AdvantageMessage  //## Inherits: <unnamed>%5A541F1302D2
{
  //## begin StdFee%5A541F080088.initialDeclarations preserve=yes
  //## end StdFee%5A541F080088.initialDeclarations

  public:
    //## Constructors (generated)
      StdFee();

    //## Destructor (generated)
      virtual ~StdFee();


    //## Other Operations (specified)
      //## Operation: insert%5A541F200120
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin StdFee%5A541F080088.public preserve=yes
      //## end StdFee%5A541F080088.public

  protected:
    // Additional Protected Declarations
      //## begin StdFee%5A541F080088.protected preserve=yes
      //## end StdFee%5A541F080088.protected

  private:
    // Additional Private Declarations
      //## begin StdFee%5A541F080088.private preserve=yes
      //## end StdFee%5A541F080088.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin StdFee%5A541F080088.implementation preserve=yes
      //## end StdFee%5A541F080088.implementation

};

//## begin StdFee%5A541F080088.postscript preserve=yes
//## end StdFee%5A541F080088.postscript

//## begin module%5A541FFC0010.epilog preserve=yes
//## end module%5A541FFC0010.epilog


#endif
