//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5718DBAF026C.cm preserve=no
//	$Date:   Jul 24 2018 10:44:10  $ $Author:   e1009610  $
//	$Revision:   1.3  $
//## end module%5718DBAF026C.cm

//## begin module%5718DBAF026C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5718DBAF026C.cp

//## Module: CXOSAI23%5718DBAF026C; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXODAI23.hpp

#ifndef CXOSAI23_h
#define CXOSAI23_h 1

//## begin module%5718DBAF026C.additionalIncludes preserve=no
//## end module%5718DBAF026C.additionalIncludes

//## begin module%5718DBAF026C.includes preserve=yes
#include "CXODRU32.hpp"

struct hAdvantage600LCM
{
   char sMTI[4];                       
   char sPROCESS_CODE[6];                 
   char sPAN[28];                      
   char sCARD_SEQ_NO[5];               
   char sCNTRY_PAN[3];
   int lAMT_TRAN[2];
   int lAMT_RECON_ACQ[2];
   int lAMT_CARD_BILL[2];
   int lAMT_RECON_ISS[2];
   char sCUR_TRAN[3];
   char sCUR_RECON_ACQ[3];
   char sCUR_CARD_BILL[3];
   char sCUR_RECON_ISS[3];
   char cCNV_RCN_ACQ_DE_POS;
   char sCNV_RCN_ACQ_RATE[7];
   char cCNV_CARD_BILL_DE_POS;
   char sCNV_CARD_BILL_RATE[7];
   char cCNV_RCN_ISS_DE_POS;
   char sCNV_RCN_ISS_RATE[7];
   char sTSTAMP_TRANS_RQST[10];
   char sSYS_TRACE_AUDIT_NO[6];        
   char sDATE_EXP[4];
   char sAPPROVAL_CODE[6];
   char sCNTRY_INST_ACQ[3];
   char sINST_ID_ACQ[11];
   char sCNTRY_INST_FWD[3];
   char sINST_ID_FWD[11];
   char sCARD_ACPT_TERM_ID[15];
   char sCARD_ACPT_ID[15];       
   char sCARD_ACPT_NAME_LOC[84];
   char sCARD_ACPT_REGION[3];
   char sCARD_ACPT_COUNTRY[3];
   char sCARD_ACPT_PST_CODE[10];
   char sCARD_ACPT_COUNTY[3];
   char cIMS_TWIN;                     
   char sMERCH_TYPE[4];
   char sCARD_ACPT_REGION_NO[3];
   char sCARD_ACPT_COUNTRY_NO[3];
   char sFUNC_CODE[3];
   char sACT_CODE[3];
   char sTSTAMP_LOCAL[12];             
   char sRETRIEVAL_REF_NO[12];
   char sMSG_REASON_CODE[4];
   char sMSG_NO[4];
   char sMSG_NO_LAST[4];
   char sADL_RQST_ACCT_TYP0[2];
   char sADL_RQST_AMT_TYP0[2];
   char sADL_RQST_CUR_CODE0[3];
   char cFiller0;
   int lADL_RQST_AMT0[2];
   short siADL_RQST_ACCT_IDX0;
   char sADL_RQST_ACCT_TYP1[2];
   char sADL_RQST_AMT_TYP1[2];
   char sADL_RQST_CUR_CODE1[3];
   char cFiller1;
   int lADL_RQST_AMT1[2];
   short siADL_RQST_ACCT_IDX1;
   char sADL_RQST_ACCT_TYP2[2];
   char sADL_RQST_AMT_TYP2[2];
   char sADL_RQST_CUR_CODE2[3];
   char cFiller2;
   int lADL_RQST_AMT2[2];
   short siADL_RQST_ACCT_IDX2;
   char sADL_RQST_ACCT_TYP3[2];
   char sADL_RQST_AMT_TYP3[2];
   char sADL_RQST_CUR_CODE3[3];
   char cFiller3;
   int lADL_RQST_AMT3[2];
   short siADL_RQST_ACCT_IDX3;
   char sADL_RQST_ACCT_TYP4[2];
   char sADL_RQST_AMT_TYP4[2];
   char sADL_RQST_CUR_CODE4[3];
   char cFiller4;
   int lADL_RQST_AMT4[2];
   short siADL_RQST_ACCT_IDX4;
   char sADL_RQST_ACCT_TYP5[2];
   char sADL_RQST_AMT_TYP5[2];
   char sADL_RQST_CUR_CODE5[3];
   char cFiller5;
   int lADL_RQST_AMT5[2];
   short siADL_RQST_ACCT_IDX5;
   //ODE elements
   char sODE_MTI[4];
   char sODE_SYS_TRA_AUD_NO[6]; 
   char sODE_TSTAMP_LOCAL[12];
   char sODE_LEN_INST_ID_ACQ[2];
   char sODE_INST_ID_ACQ[11];
   char sODE_LEN_INST_ID_FWD[2];
   char sODE_INST_ID_FWD[11];
   char cFiller6;
   char sINST_ID_TRAN_DEST_IB[11];
   char sINST_ID_TRAN_DEST_OB[11];
   char sACCT_ID_1[28];
   char sTRAN_DESC[100];
   char cFiller7;
   short siDATA_PRIV_ACQ_FMT;
   char sDATA_PRIV_ACQ[100];
   short siDATA_PRIV_ISS_FMT;
   char sDATA_PRIV_ISS[100];
   char sADL_DATA_NATIONAL[100];
   char sADL_DATA_PRIV_ACQ[255];
   char sADL_DATA_PRIV_ISS[255];
   char cREF_DATA_ACQ_FMT;
   char sREF_DATA_ACQ[99];
   char cREF_DATA_ISS_FMT;
   char sREF_DATA_ISS[99];
   char sORIG_PROCESS_ID_ISS[6];
   char sORIG_PROC_ID_ISS[6];
   char sORIG_NET_ID_ISS[3];
   char sORIG_DATE_RECON_ISS[6];
   char sPROCESS_ID_RECV[6];
   char sPROC_ID_RECV[6];
   char sNET_ID_RECV[3];
   char sDATE_RECON_RECV[6];
#ifdef _LITTLE_ENDIAN
   unsigned char bPrcFlag0bit7 : 1;
   unsigned char bPrcFlag0bit6 : 1;
   unsigned char bPrcFlag0bit5 : 1;
   unsigned char bPrcFlag0bit4 : 1;
   unsigned char bPrcFlag0bit3 : 1;
   unsigned char bPrcFlag0bit2 : 1;
   unsigned char bPrcFlag0bit1 : 1;
   unsigned char bPrcFlag0bit0 : 1;
   unsigned char bPrcFlag0bit15 : 1;
   unsigned char bPrcFlag0bit14 : 1;
   unsigned char bPrcFlag0bit13 : 1;
   unsigned char bPrcFlag0bit12 : 1;
   unsigned char bPrcFlag0bit11 : 1;
   unsigned char bPrcFlag0bit10 : 1;
   unsigned char bPrcFlag0bit09 : 1;
   unsigned char bPrcFlag0bit08 : 1;
   unsigned char bPrcFlag1bit7 : 1;
   unsigned char bPrcFlag1bit6 : 1;
   unsigned char bPrcFlag1bit5 : 1;
   unsigned char bPrcFlag1bit4 : 1;
   unsigned char bPrcFlag1bit3 : 1;
   unsigned char bPrcFlag1bit2 : 1;
   unsigned char bPrcFlag1bit1 : 1;
   unsigned char bPrcFlag1bit0 : 1;
   unsigned char bPrcFlag1bit15 : 1;
   unsigned char bPrcFlag1bit14 : 1;
   unsigned char bPrcFlag1bit13 : 1;
   unsigned char bPrcFlag1bit12 : 1;
   unsigned char bPrcFlag1bit11 : 1;
   unsigned char bPrcFlag1bit10 : 1;
   unsigned char bPrcFlag1bit09 : 1;
   unsigned char bPrcFlag1bit08 : 1;
   unsigned char bPrcFlag2bit7 : 1;
   unsigned char bPrcFlag2bit6 : 1;
   unsigned char bPrcFlag2bit5 : 1;
   unsigned char bPrcFlag2bit4 : 1;
   unsigned char bPrcFlag2bit3 : 1;
   unsigned char bPrcFlag2bit2 : 1;
   unsigned char bPrcFlag2bit1 : 1;
   unsigned char bPrcFlag2bit0 : 1;
   unsigned char bPrcFlag2bit15 : 1;
   unsigned char bPrcFlag2bit14 : 1;
   unsigned char bPrcFlag2bit13 : 1;
   unsigned char bPrcFlag2bit12 : 1;
   unsigned char bPrcFlag2bit11 : 1;
   unsigned char bPrcFlag2bit10 : 1;
   unsigned char bPrcFlag2bit09 : 1;
   unsigned char bPrcFlag2bit08 : 1;
   unsigned char bPrcFlag3bit7 : 1;
   unsigned char bPrcFlag3bit6 : 1;
   unsigned char bPrcFlag3bit5 : 1;
   unsigned char bPrcFlag3bit4 : 1;
   unsigned char bPrcFlag3bit3 : 1;
   unsigned char bPrcFlag3bit2 : 1;
   unsigned char bPrcFlag3bit1 : 1;
   unsigned char bPrcFlag3bit0 : 1;
   unsigned char bPrcFlag3bit15 : 1;
   unsigned char bPrcFlag3bit14 : 1;
   unsigned char bPrcFlag3bit13 : 1;
   unsigned char bPrcFlag3bit12 : 1;
   unsigned char bPrcFlag3bit11 : 1;
   unsigned char bPrcFlag3bit10 : 1;
   unsigned char bPrcFlag3bit09 : 1;
   unsigned char bPrcFlag3bit08 : 1;
#else
   unsigned char bPrcFlag0bit0 : 1;
   unsigned char bPrcFlag0bit1 : 1;
   unsigned char bPrcFlag0bit2 : 1;
   unsigned char bPrcFlag0bit3 : 1;
   unsigned char bPrcFlag0bit4 : 1;
   unsigned char bPrcFlag0bit5 : 1;
   unsigned char bPrcFlag0bit6 : 1;
   unsigned char bPrcFlag0bit7 : 1;
   unsigned char bPrcFlag0bit8 : 1;
   unsigned char bPrcFlag0bit9 : 1;
   unsigned char bPrcFlag0bit10 : 1;
   unsigned char bPrcFlag0bit11 : 1;
   unsigned char bPrcFlag0bit12 : 1;
   unsigned char bPrcFlag0bit13 : 1;
   unsigned char bPrcFlag0bit14 : 1;
   unsigned char bPrcFlag0bit15 : 1;
   unsigned char bPrcFlag1bit0 : 1;
   unsigned char bPrcFlag1bit1 : 1;
   unsigned char bPrcFlag1bit2 : 1;
   unsigned char bPrcFlag1bit3 : 1;
   unsigned char bPrcFlag1bit4 : 1;
   unsigned char bPrcFlag1bit5 : 1;
   unsigned char bPrcFlag1bit6 : 1;
   unsigned char bPrcFlag1bit7 : 1;
   unsigned char bPrcFlag1bit8 : 1;
   unsigned char bPrcFlag1bit9 : 1;
   unsigned char bPrcFlag1bit10 : 1;
   unsigned char bPrcFlag1bit11 : 1;
   unsigned char bPrcFlag1bit12 : 1;
   unsigned char bPrcFlag1bit13 : 1;
   unsigned char bPrcFlag1bit14 : 1;
   unsigned char bPrcFlag1bit15 : 1;
   unsigned char bPrcFlag2bit0 : 1;
   unsigned char bPrcFlag2bit1 : 1;
   unsigned char bPrcFlag2bit2 : 1;
   unsigned char bPrcFlag2bit3 : 1;
   unsigned char bPrcFlag2bit4 : 1;
   unsigned char bPrcFlag2bit5 : 1;
   unsigned char bPrcFlag2bit6 : 1;
   unsigned char bPrcFlag2bit7 : 1;
   unsigned char bPrcFlag2bit8 : 1;
   unsigned char bPrcFlag2bit9 : 1;
   unsigned char bPrcFlag2bit10 : 1;
   unsigned char bPrcFlag2bit11 : 1;
   unsigned char bPrcFlag2bit12 : 1;
   unsigned char bPrcFlag2bit13 : 1;
   unsigned char bPrcFlag2bit14 : 1;
   unsigned char bPrcFlag2bit15 : 1;
   unsigned char bPrcFlag3bit0 : 1;
   unsigned char bPrcFlag3bit1 : 1;
   unsigned char bPrcFlag3bit2 : 1;
   unsigned char bPrcFlag3bit3 : 1;
   unsigned char bPrcFlag3bit4 : 1;
   unsigned char bPrcFlag3bit5 : 1;
   unsigned char bPrcFlag3bit6 : 1;
   unsigned char bPrcFlag3bit7 : 1;
   unsigned char bPrcFlag3bit8 : 1;
   unsigned char bPrcFlag3bit9 : 1;
   unsigned char bPrcFlag3bit10 : 1;
   unsigned char bPrcFlag3bit11 : 1;
   unsigned char bPrcFlag3bit12 : 1;
   unsigned char bPrcFlag3bit13 : 1;
   unsigned char bPrcFlag3bit14 : 1;
   unsigned char bPrcFlag3bit15 : 1;
#endif
   char sCIRC_ID[8];
   char sTSAP_ID[8];
   int lTSAP_IDX;
   short siTSAP_MSG_SEQ_NO;
   int lSS_QUEUE_ID;
   char sROUTE_LIST_ID[8];
   char sCOPT_ICHG_ID[8];
   short siPMC_ERROR;
   char sCNX_NET_ID[4];
   char sDATE_RECON_NET[6];
   char sTSTAMP_TRANS[6];
   short siFORMAT_RESULT;
   short siDATA_LEN;
   char sDATA[2];
   char sLEN_PAYMENT_TOKEN_DATA[3];
   char sPAYMENT_TOKEN_DATA[999];
};
#include "CXODRU33.hpp"

//## end module%5718DBAF026C.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class LifeCycleManagementSegment;
} // namespace repositorysegment

class AdvantageMessageProcessor;
//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Mask;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class UniquenessKey;

} // namespace database

//## begin module%5718DBAF026C.declarations preserve=no
//## end module%5718DBAF026C.declarations

//## begin module%5718DBAF026C.additionalDeclarations preserve=yes
//## end module%5718DBAF026C.additionalDeclarations


//## begin AdvantageMessage600Lcm%5718D07200E8.preface preserve=yes
//## end AdvantageMessage600Lcm%5718D07200E8.preface

//## Class: AdvantageMessage600Lcm%5718D07200E8
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%572722EF010F;IF::Message { -> F}
//## Uses: <unnamed>%572723360062;monitor::UseCase { -> F}
//## Uses: <unnamed>%572723600360;repositorysegment::LifeCycleManagementSegment { -> F}
//## Uses: <unnamed>%573547FC005A;reusable::Mask { -> F}
//## Uses: <unnamed>%57354B4E01B4;database::UniquenessKey { -> F}
//## Uses: <unnamed>%57354BB603C8;process::Application { -> F}
//## Uses: <unnamed>%57354C32024E;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%57354CA603B8;IF::CodeTable { -> F}

class DllExport AdvantageMessage600Lcm : public AdvantageMessage  //## Inherits: <unnamed>%5718DE7E001E
{
  //## begin AdvantageMessage600Lcm%5718D07200E8.initialDeclarations preserve=yes
  //## end AdvantageMessage600Lcm%5718D07200E8.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageMessage600Lcm();

    //## Destructor (generated)
      virtual ~AdvantageMessage600Lcm();


    //## Other Operations (specified)
      //## Operation: insert%5718DEFE024D
      virtual bool insert (IF::Message& hMessage);

      //## Operation: processFlags%574EAAC501A7
      void processFlags (char *psFlags, char* pInFlags);

      //## Operation: translate%57276A660041
      void translate (char* pBuffer, int ilen);

    // Additional Public Declarations
      //## begin AdvantageMessage600Lcm%5718D07200E8.public preserve=yes
      //## end AdvantageMessage600Lcm%5718D07200E8.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageMessage600Lcm%5718D07200E8.protected preserve=yes
      //## end AdvantageMessage600Lcm%5718D07200E8.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageMessage600Lcm%5718D07200E8.private preserve=yes
      //## end AdvantageMessage600Lcm%5718D07200E8.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin AdvantageMessage600Lcm%5718D07200E8.implementation preserve=yes
      bool m_bLCM_EXP_DATE;
      //## end AdvantageMessage600Lcm%5718D07200E8.implementation

};

//## begin AdvantageMessage600Lcm%5718D07200E8.postscript preserve=yes
//## end AdvantageMessage600Lcm%5718D07200E8.postscript

//## begin module%5718DBAF026C.epilog preserve=yes
//## end module%5718DBAF026C.epilog


#endif
