//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5ABE8E8D009C.cm preserve=no
//	$Date:   Apr 22 2019 07:54:04  $ $Author:   e1009839  $
//	$Revision:   1.6  $
//## end module%5ABE8E8D009C.cm

//## begin module%5ABE8E8D009C.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5ABE8E8D009C.cp

//## Module: CXOSAI44%5ABE8E8D009C; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI44.cpp

//## begin module%5ABE8E8D009C.additionalIncludes preserve=no
//## end module%5ABE8E8D009C.additionalIncludes

//## begin module%5ABE8E8D009C.includes preserve=yes
#include <algorithm>
#include "CXODRU34.hpp"
//## end module%5ABE8E8D009C.includes

#ifndef CXOSAI44_h
#include "CXODAI44.hpp"
#endif
//## begin module%5ABE8E8D009C.declarations preserve=no
//## end module%5ABE8E8D009C.declarations

//## begin module%5ABE8E8D009C.additionalDeclarations preserve=yes
//## end module%5ABE8E8D009C.additionalDeclarations


// Class Message622

Message622::Message622()
  //## begin Message622::Message622%5ABE8D30024A_const.hasinit preserve=no
  //## end Message622::Message622%5ABE8D30024A_const.hasinit
  //## begin Message622::Message622%5ABE8D30024A_const.initialization preserve=yes
   : AdvantageMessage("0622","S318")
  //## end Message622::Message622%5ABE8D30024A_const.initialization
{
  //## begin Message622::Message622%5ABE8D30024A_const.body preserve=yes
   memcpy(m_sID,"AI44",4);
  //## end Message622::Message622%5ABE8D30024A_const.body
}


Message622::~Message622()
{
  //## begin Message622::~Message622%5ABE8D30024A_dest.body preserve=yes
  //## end Message622::~Message622%5ABE8D30024A_dest.body
}



//## Other Operations (implementation)
bool Message622::insert (Message& hMessage)
{
  //## begin Message622::insert%5ABE8D470252.body preserve=yes
   UseCase hUseCase("TANDEM","## AI44 READ 0622 BULK DEPOSIT",false);
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)(hMessage.data());
   short iFoo = ntohs(pV13AdvantageHeader->siHdrMsgStep);
   if (ntohs(pV13AdvantageHeader->siHdrMsgStep) != 11)
      return false;
   hMsg622* p = (hMsg622*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   hCheck99* pCheck99 = (hCheck99*)(hMessage.data() + sizeof(hV13AdvantageHeader) + sizeof(hMsg622));
   char szTemp[3] = {"  "};
   memcpy(szTemp,p->sNumChecks,2);
   short n = atoi(szTemp);
   if (n < 1)
      return false;
   setTSTAMP_TRANS(p->sMilestone0);
   database::UniquenessKey::hash(p->sPAN,16);
   database::UniquenessKey::hash(p->sRetrievalRefNo,12);
   database::UniquenessKey::hash(p->sSysTraceAuditNo,6);
   char cTRAN_DISPOSITION = '1';
   database::UniquenessKey::hash(&cTRAN_DISPOSITION,1);
   m_pTransaction->setUNIQUENESS_KEY(database::UniquenessKey::getHash());
   p->cDEPOSIT_TYPE = 'Q';
   ::Template::instance()->map("CHECKDEPOSIT",(const char*)p);
   for (short m = 0;m < n;m++)
   {
      memset(pCheck99,' ',sizeof(struct hCheck99));
      pCheck99->siSEQ_NO = htons(m);
      string strMICR(p->pCheck[m].sMICR,64);
      transform(strMICR.begin(),strMICR.end(),strMICR.begin(),::toupper);
      vector<string> hTokens;
      if (Buffer::parse(strMICR,"CD",hTokens) > 2)
      {
         int iCheck = strMICR[0] == 'C' ? 0 : 2;
         int iRT = iCheck == 0 ? 1 : 0;
         int iAccount = iCheck == 0 ? 2 : 1;
         memcpy(pCheck99->sINST_ID_ISS,hTokens[iRT].data(),min(sizeof(pCheck99->sINST_ID_ISS),hTokens[iRT].length()));
         memcpy(pCheck99->sACCT_ID,hTokens[iAccount].data(),min(sizeof(pCheck99->sACCT_ID),hTokens[iAccount].length()));
         memcpy(pCheck99->sCHECK_NO,hTokens[iCheck].data(),min(sizeof(pCheck99->sCHECK_NO),hTokens[iCheck].length()));
      }
      ::Template::instance()->map("CHECK99",(const char*)pCheck99,-1,m);
      ::Template::instance()->map("CHECK",(const char*)&p->pCheck[m],-1,m);
   }
   return deport(hMessage);
  //## end Message622::insert%5ABE8D470252.body
}

// Additional Declarations
  //## begin Message622%5ABE8D30024A.declarations preserve=yes
  //## end Message622%5ABE8D30024A.declarations

//## begin module%5ABE8E8D009C.epilog preserve=yes
//## end module%5ABE8E8D009C.epilog
