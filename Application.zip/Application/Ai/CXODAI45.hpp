//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EB1CAE00391.cm preserve=no
//	$Date:   May 08 2020 09:17:26  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5EB1CAE00391.cm

//## begin module%5EB1CAE00391.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5EB1CAE00391.cp

//## Module: CXOSAI45%5EB1CAE00391; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI45.hpp

#ifndef CXOSAI45_h
#define CXOSAI45_h 1

//## begin module%5EB1CAE00391.additionalIncludes preserve=no
//## end module%5EB1CAE00391.additionalIncludes

//## begin module%5EB1CAE00391.includes preserve=yes
#include <map>
//## end module%5EB1CAE00391.includes

#ifndef CXOSBS02_h
#include "CXODBS02.hpp"
#endif
//## begin module%5EB1CAE00391.declarations preserve=no
//## end module%5EB1CAE00391.declarations

//## begin module%5EB1CAE00391.additionalDeclarations preserve=yes
//## end module%5EB1CAE00391.additionalDeclarations


//## begin APSegment%5EB1C9A503A0.preface preserve=yes
//## end APSegment%5EB1C9A503A0.preface

//## Class: APSegment%5EB1C9A503A0
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport APSegment : public segment::PersistentSegment  //## Inherits: <unnamed>%5EB1D32E00AD
{
  //## begin APSegment%5EB1C9A503A0.initialDeclarations preserve=yes
  //## end APSegment%5EB1C9A503A0.initialDeclarations

  public:
    //## Constructors (generated)
      APSegment();

    //## Destructor (generated)
      virtual ~APSegment();


    //## Other Operations (specified)
      //## Operation: reformat%5EB1D2A800BB
      bool reformat (const reusable::string& strRecType, char* psFrom, char* psOLD_VALUE, char* psNEW_VALUE, bool bAsciiInput);

    // Additional Public Declarations
      //## begin APSegment%5EB1C9A503A0.public preserve=yes
      //## end APSegment%5EB1C9A503A0.public

  protected:
    // Data Members for Class Attributes

      //## Attribute: Fields%5EB1CA4500BA
      //## begin APSegment::Fields%5EB1CA4500BA.attr preserve=no  protected: map<string,Fields*,less<string> > {VA} 
      map<string,Fields*,less<string> > m_hFields;
      //## end APSegment::Fields%5EB1CA4500BA.attr

    // Additional Protected Declarations
      //## begin APSegment%5EB1C9A503A0.protected preserve=yes
      //## end APSegment%5EB1C9A503A0.protected

  private:
    // Additional Private Declarations
      //## begin APSegment%5EB1C9A503A0.private preserve=yes
      //## end APSegment%5EB1C9A503A0.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin APSegment%5EB1C9A503A0.implementation preserve=yes
      //## end APSegment%5EB1C9A503A0.implementation

};

//## begin APSegment%5EB1C9A503A0.postscript preserve=yes
//## end APSegment%5EB1C9A503A0.postscript

//## begin module%5EB1CAE00391.epilog preserve=yes
//## end module%5EB1CAE00391.epilog


#endif
