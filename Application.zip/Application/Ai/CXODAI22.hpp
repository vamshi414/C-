//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%542AC7CB0367.cm preserve=no
//	$Date:   Dec 18 2014 15:03:20  $ $Author:   e1009510  $
//	$Revision:   1.0  $
//## end module%542AC7CB0367.cm

//## begin module%542AC7CB0367.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%542AC7CB0367.cp

//## Module: CXOSAI22%542AC7CB0367; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXODAI22.hpp

#ifndef CXOSAI22_h
#define CXOSAI22_h 1

//## begin module%542AC7CB0367.additionalIncludes preserve=no
//## end module%542AC7CB0367.additionalIncludes

//## begin module%542AC7CB0367.includes preserve=yes
//## end module%542AC7CB0367.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialDepositSegment;
class CheckDepositSegment;
} // namespace repositorysegment

class AdvantageMessageProcessor;
//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Mask;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class UniquenessKey;
} // namespace database

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ListSegment;

} // namespace segment

//## begin module%542AC7CB0367.declarations preserve=no
//## end module%542AC7CB0367.declarations

//## begin module%542AC7CB0367.additionalDeclarations preserve=yes
//## end module%542AC7CB0367.additionalDeclarations


//## begin AdvantageMessage622%542AC6D70315.preface preserve=yes
//## end AdvantageMessage622%542AC6D70315.preface

//## Class: AdvantageMessage622%542AC6D70315
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5450FE3C0217;monitor::UseCase { -> F}
//## Uses: <unnamed>%5450FE400073;IF::Message { -> F}
//## Uses: <unnamed>%5450FE8101CC;segment::ListSegment { -> F}
//## Uses: <unnamed>%5451019B026F;IF::CodeTable { -> F}
//## Uses: <unnamed>%545101BF0093;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%545101FC02B3;AdvantageMessage { -> F}
//## Uses: <unnamed>%5452513603E7;database::UniquenessKey { -> F}
//## Uses: <unnamed>%54576C0C02A7;reusable::Mask { -> F}
//## Uses: <unnamed>%546324BF0326;process::Application { -> F}
//## Uses: <unnamed>%5480280B0135;entitysegment::Customer { -> F}

class DllExport AdvantageMessage622 : public AdvantageMessage  //## Inherits: <unnamed>%543BABB1001E
{
  //## begin AdvantageMessage622%542AC6D70315.initialDeclarations preserve=yes
  //## end AdvantageMessage622%542AC6D70315.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageMessage622();

    //## Destructor (generated)
      virtual ~AdvantageMessage622();


    //## Other Operations (specified)
      //## Operation: insert%543BB7780208
      virtual bool insert (IF::Message& hMessage);

    //## Get and Set Operations for Associations (generated)

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%54520FCE013B
      //## Role: AdvantageMessage622::<m_pCheckDepositSegment>%54520FCE03A4
      repositorysegment::CheckDepositSegment * getCheckDepositSegment ()
      {
        //## begin AdvantageMessage622::getCheckDepositSegment%54520FCE03A4.get preserve=no
        return m_pCheckDepositSegment;
        //## end AdvantageMessage622::getCheckDepositSegment%54520FCE03A4.get
      }


      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%54537D890222
      //## Role: AdvantageMessage622::<m_pFinancialDepositSegment>%54537D8A021E
      repositorysegment::FinancialDepositSegment * getFinancialDepositSegment ()
      {
        //## begin AdvantageMessage622::getFinancialDepositSegment%54537D8A021E.get preserve=no
        return m_pFinancialDepositSegment;
        //## end AdvantageMessage622::getFinancialDepositSegment%54537D8A021E.get
      }


    // Additional Public Declarations
      //## begin AdvantageMessage622%542AC6D70315.public preserve=yes
      //## end AdvantageMessage622%542AC6D70315.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageMessage622%542AC6D70315.protected preserve=yes
      //## end AdvantageMessage622%542AC6D70315.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageMessage622%542AC6D70315.private preserve=yes
      //## end AdvantageMessage622%542AC6D70315.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%54520FCE013B
      //## begin AdvantageMessage622::<m_pCheckDepositSegment>%54520FCE03A4.role preserve=no  public: repositorysegment::CheckDepositSegment { -> RFHgN}
      repositorysegment::CheckDepositSegment *m_pCheckDepositSegment;
      //## end AdvantageMessage622::<m_pCheckDepositSegment>%54520FCE03A4.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%54537D890222
      //## begin AdvantageMessage622::<m_pFinancialDepositSegment>%54537D8A021E.role preserve=no  public: repositorysegment::FinancialDepositSegment { -> RFHgN}
      repositorysegment::FinancialDepositSegment *m_pFinancialDepositSegment;
      //## end AdvantageMessage622::<m_pFinancialDepositSegment>%54537D8A021E.role

    // Additional Implementation Declarations
      //## begin AdvantageMessage622%542AC6D70315.implementation preserve=yes
      //## end AdvantageMessage622%542AC6D70315.implementation

};

//## begin AdvantageMessage622%542AC6D70315.postscript preserve=yes
//## end AdvantageMessage622%542AC6D70315.postscript

//## begin module%542AC7CB0367.epilog preserve=yes
//## end module%542AC7CB0367.epilog


#endif
