//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C6136CE02DE.cm preserve=no
//	$Date:   Sep 07 2021 11:47:20  $ $Author:   e1034272  $
//	$Revision:   1.48  $
//## end module%3C6136CE02DE.cm

//## begin module%3C6136CE02DE.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C6136CE02DE.cp

//## Module: CXOSAI04%3C6136CE02DE; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Dn_codes\V03.0A.R002\Dn\Server\Application\Ai\CXOSAI04.cpp

//## begin module%3C6136CE02DE.additionalIncludes preserve=no
//## end module%3C6136CE02DE.additionalIncludes

//## begin module%3C6136CE02DE.includes preserve=yes
#include "CXODIF03.hpp"
#include "CXODIF11.hpp"
#include "CXODNS29.hpp"
#include "CXODRU37.hpp"
#include "CXODIF16.hpp"
//## end module%3C6136CE02DE.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSAI04_h
#include "CXODAI04.hpp"
#endif


//## begin module%3C6136CE02DE.declarations preserve=no
//## end module%3C6136CE02DE.declarations

//## begin module%3C6136CE02DE.additionalDeclarations preserve=yes
#define FIELDS100Old 11
struct hCardHolder100Old* phCardHolder100Old = 0;
Fields hCardHolder100Old_Fields[FIELDS100Old + 1] =
{
      "a         ","",offsetof(hCardHolder100Old,sIssFIId),sizeof(phCardHolder100Old->sIssFIId),
      "a         ","",offsetof(hCardHolder100Old,sStatus),sizeof(phCardHolder100Old->sStatus),
      "b         "," WD DP IQ PT PF TT TF PR 3P DF",offsetof(hCardHolder100Old,siCardAccess),sizeof(phCardHolder100Old->siCardAccess),
      "t         ","",offsetof(hCardHolder100Old,sLastUsedTstamp),sizeof(phCardHolder100Old->sLastUsedTstamp),
      "s         ","",offsetof(hCardHolder100Old,siPinFailCT),sizeof(phCardHolder100Old->siPinFailCT),
      "a         ","",offsetof(hCardHolder100Old,sLimitGroupID),sizeof(phCardHolder100Old->sLimitGroupID),
      "a         ","",offsetof(hCardHolder100Old,sFeeGroup),sizeof(phCardHolder100Old->sFeeGroup),
      "a         ","",offsetof(hCardHolder100Old,cCardAct),sizeof(phCardHolder100Old->cCardAct),
      "o         ","",offsetof(hCardHolder100Old,cCardInfoFiller),sizeof(phCardHolder100Old->cCardInfoFiller),
      "t         ","",offsetof(hCardHolder100Old,sUpdtTstamp),sizeof(phCardHolder100Old->sUpdtTstamp),
      "t         ","",offsetof(hCardHolder100Old,sMntTstamp),sizeof(phCardHolder100Old->sMntTstamp),
      "~","",0,sizeof(hCardHolder100Old),
};
#define FIELDS100New 11
struct hCardHolder100New* phCardHolder100New = 0;
Fields hCardHolder100New_Fields[FIELDS100New + 1] =
{
      "a         ","",offsetof(hCardHolder100New,sIssFIId),sizeof(phCardHolder100New->sIssFIId),
      "a         ","",offsetof(hCardHolder100New,sStatus),sizeof(phCardHolder100New->sStatus),
      "b         "," WD DP IQ PT PF TT TF PR 3P DF",offsetof(hCardHolder100New,siCardAccess),sizeof(phCardHolder100New->siCardAccess),
      "t         ","",offsetof(hCardHolder100New,sLastUsedTstamp),sizeof(phCardHolder100New->sLastUsedTstamp),
      "s         ","",offsetof(hCardHolder100New,siPinFailCT),sizeof(phCardHolder100New->siPinFailCT),
      "a         ","",offsetof(hCardHolder100New,sLimitGroupID),sizeof(phCardHolder100New->sLimitGroupID),
      "a         ","",offsetof(hCardHolder100New,sFeeGroup),sizeof(phCardHolder100New->sFeeGroup),
      "a         ","",offsetof(hCardHolder100New,cCardAct),sizeof(phCardHolder100New->cCardAct),
      "o         ","",offsetof(hCardHolder100New,cCardInfoFiller),sizeof(phCardHolder100New->cCardInfoFiller),
      "t         ","",offsetof(hCardHolder100New,sUpdtTstamp),sizeof(phCardHolder100New->sUpdtTstamp),
      "t         ","",offsetof(hCardHolder100New,sMntTstamp),sizeof(phCardHolder100New->sMntTstamp),
      "~","",0,sizeof(hCardHolder100New),
};
#define FIELDS101Old 3
struct hCardHolder101Old* phCardHolder101Old = 0;
Fields hCardHolder101Old_Fields[FIELDS101Old + 1] =
{
      "s         ","",offsetof(hCardHolder101Old,siPinAuthFlag),sizeof(phCardHolder101Old->siPinAuthFlag),
      "a         ","",offsetof(hCardHolder101Old,sPinAuthVal),sizeof(phCardHolder101Old->sPinAuthVal),
      "a         ","",offsetof(hCardHolder101Old,sTrk2DateYYMM),sizeof(phCardHolder101Old->sTrk2DateYYMM),
      "~","",0,sizeof(hCardHolder101Old),
};

#define FIELDS101New 3
struct hCardHolder101New* phCardHolder101New = 0;
Fields hCardHolder101New_Fields[FIELDS101New + 1] =
{
      "s         ","",offsetof(hCardHolder101New,siPinAuthFlag),sizeof(phCardHolder101New->siPinAuthFlag),
      "a         ","",offsetof(hCardHolder101New,sPinAuthVal),sizeof(phCardHolder101New->sPinAuthVal),
      "a         ","",offsetof(hCardHolder101New,sTrk2DateYYMM),sizeof(phCardHolder101New->sTrk2DateYYMM),
      "~","",0,sizeof(hCardHolder101New),
};

#define FIELDS102Old 10
struct hCardHolder102Old* phCardHolder102Old = 0;
Fields hCardHolder102Old_Fields[FIELDS102Old + 1] =
{
     "a         ","",offsetof(hCardHolder102Old,sAcctFIId),sizeof(phCardHolder102Old->sAcctFIId),
     "a         ","",offsetof(hCardHolder102Old,sAcctType),sizeof(phCardHolder102Old->sAcctType),
     "a         ","",offsetof(hCardHolder102Old,sAcctNo),sizeof(phCardHolder102Old->sAcctNo),
     "a         ","",offsetof(hCardHolder102Old,sAcctQual),sizeof(phCardHolder102Old->sAcctQual),
     "a         ","",offsetof(hCardHolder102Old,sOarSelType),sizeof(phCardHolder102Old->sOarSelType),
	  "a         ","",offsetof(hCardHolder102Old,sAcctDesc),sizeof(phCardHolder102Old->sAcctDesc),
	  "b         "," WD DP IQ PT PF TT TF PR 3P DF",offsetof(hCardHolder102Old,siAcctAccess),sizeof(phCardHolder102Old->siAcctAccess),
	  "a         ","",offsetof(hCardHolder102Old,cPrimaryInd),sizeof(phCardHolder102Old->cPrimaryInd),
	  "a         ","",offsetof(hCardHolder102Old,cFundingInd),sizeof(phCardHolder102Old->cFundingInd),
      "~","",0,sizeof(hCardHolder102Old),
};

#define FIELDS102New 10
struct hCardHolder102New* phCardHolder102New = 0;
Fields hCardHolder102New_Fields[FIELDS102New + 1] =
{
     "a         ","",offsetof(hCardHolder102Old,sAcctFIId),sizeof(phCardHolder102Old->sAcctFIId),
     "a         ","",offsetof(hCardHolder102Old,sAcctType),sizeof(phCardHolder102Old->sAcctType),
     "a         ","",offsetof(hCardHolder102Old,sAcctNo),sizeof(phCardHolder102Old->sAcctNo),
     "a         ","",offsetof(hCardHolder102New,sAcctQual),sizeof(phCardHolder102New->sAcctQual),
     "a         ","",offsetof(hCardHolder102New,sOarSelType),sizeof(phCardHolder102New->sOarSelType),
	  "a         ","",offsetof(hCardHolder102New,sAcctDesc),sizeof(phCardHolder102New->sAcctDesc),
	  "b         "," WD DP IQ PT PF TT TF PR 3P DF",offsetof(hCardHolder102New,siAcctAccess),sizeof(phCardHolder102New->siAcctAccess),
	  "a         ","",offsetof(hCardHolder102New,cPrimaryInd),sizeof(phCardHolder102New->cPrimaryInd),
	  "a         ","",offsetof(hCardHolder102New,cFundingInd),sizeof(phCardHolder102New->cFundingInd),
      "~","",0,sizeof(hCardHolder102New),
};

#define FIELDS103Old 6
struct hCardHolder103Old* phCardHolder103Old = 0;
Fields hCardHolder103Old_Fields[FIELDS103Old + 1] =
{
     "a         ","",offsetof(hCardHolder103Old,sLimitId),sizeof(phCardHolder103Old->sLimitId),
     "i         ","",offsetof(hCardHolder103Old,iLimitAmnt),sizeof(phCardHolder103Old->iLimitAmnt),
     "s         ","",offsetof(hCardHolder103Old,siLimitUses),sizeof(phCardHolder103Old->siLimitUses),
	  "i         ","",offsetof(hCardHolder103Old,iIncrAmnt),sizeof(phCardHolder103Old->iIncrAmnt),
	  "i         ","",offsetof(hCardHolder103Old,iMinAmnt),sizeof(phCardHolder103Old->iMinAmnt),
	  "s         ","",offsetof(hCardHolder103Old,siPercntDepAval),sizeof(phCardHolder103Old->siPercntDepAval),
      "~","",0,sizeof(hCardHolder103Old),
};

#define FIELDS103New 6
struct hCardHolder103New* phCardHolder103New = 0;
Fields hCardHolder103New_Fields[FIELDS103New + 1] =
{
     "a         ","",offsetof(hCardHolder103New,sLimitId),sizeof(phCardHolder103New->sLimitId),
     "i         ","",offsetof(hCardHolder103New,iLimitAmnt),sizeof(phCardHolder103New->iLimitAmnt),
     "s         ","",offsetof(hCardHolder103New,siLimitUses),sizeof(phCardHolder103New->siLimitUses),
	  "i         ","",offsetof(hCardHolder103New,iIncrAmnt),sizeof(phCardHolder103New->iIncrAmnt),
	  "i         ","",offsetof(hCardHolder103New,iMinAmnt),sizeof(phCardHolder103New->iMinAmnt),
	  "s         ","",offsetof(hCardHolder103New,siPercntDepAval),sizeof(phCardHolder103New->siPercntDepAval),
      "~","",0,sizeof(hCardHolder103New),
};

#define FIELDS104Old 4
struct hCardHolder104Old* phCardHolder104Old = 0;
Fields hCardHolder104Old_Fields[FIELDS104Old + 1] =
{
     "i         ","",offsetof(hCardHolder104Old,iAmnt),sizeof(phCardHolder104Old->iAmnt),
     "t         ","",offsetof(hCardHolder104Old,sExpTime),sizeof(phCardHolder104Old->sExpTime),
     "a         ","",offsetof(hCardHolder104Old,sMatchData),sizeof(phCardHolder104Old->sMatchData),
	  "a         ","",offsetof(hCardHolder104Old,sLimitId),sizeof(phCardHolder104Old->sLimitId),
	  "~","",0,sizeof(hCardHolder104Old),
};

#define FIELDS104New 4
struct hCardHolder104New* phCardHolder104New = 0;
Fields hCardHolder104New_Fields[FIELDS104New + 1] =
{
     "i         ","",offsetof(hCardHolder104New,iAmnt),sizeof(phCardHolder104New->iAmnt),
     "t         ","",offsetof(hCardHolder104New,sExpTime),sizeof(phCardHolder104New->sExpTime),
     "a         ","",offsetof(hCardHolder104New,sMatchData),sizeof(phCardHolder104New->sMatchData),
	  "a         ","",offsetof(hCardHolder104New,sLimitId),sizeof(phCardHolder104New->sLimitId),
	  "~","",0,sizeof(hCardHolder104New),
};


#define FIELDS105Old 4
struct hCardHolder105Old* phCardHolder105Old = 0;
Fields hCardHolder105Old_Fields[FIELDS105Old + 1] =
{
     "a         ","",offsetof(hCardHolder105Old,sFIID),sizeof(phCardHolder105Old->sFIID),
     "a         ","",offsetof(hCardHolder105Old,sAcctType),sizeof(phCardHolder105Old->sAcctType),
     "a         ","",offsetof(hCardHolder105Old,sAcctNo),sizeof(phCardHolder105Old->sAcctNo),
	  "a         ","",offsetof(hCardHolder105Old,sPaymentAcctID),sizeof(phCardHolder105Old->sPaymentAcctID),
	  "~","",0,sizeof(hCardHolder105Old),
};

#define FIELDS105New 4
struct hCardHolder105New* phCardHolder105New = 0;
Fields hCardHolder105New_Fields[FIELDS105New + 1] =
{
     "a         ","",offsetof(hCardHolder105New,sFIID),sizeof(phCardHolder105New->sFIID),
     "a         ","",offsetof(hCardHolder105New,sAcctType),sizeof(phCardHolder105New->sAcctType),
     "a         ","",offsetof(hCardHolder105New,sAcctNo),sizeof(phCardHolder105New->sAcctNo),
	  "a         ","",offsetof(hCardHolder105New,sPaymentAcctID),sizeof(phCardHolder105New->sPaymentAcctID),
	  "~","",0,sizeof(hCardHolder105New),
};
#define FIELDS106Old 1
struct hCardHolder106Old* phCardHolder106Old = 0;
Fields hCardHolder106Old_Fields[FIELDS106Old + 1] =
{
     "a         ","",offsetof(hCardHolder106Old,sGreetingName),sizeof(phCardHolder106Old->sGreetingName),
	  "~","",0,sizeof(hCardHolder106Old),
};

#define FIELDS106New 1
struct hCardHolder106New* phCardHolder106New = 0;
Fields hCardHolder106New_Fields[FIELDS106New + 1] =
{
     "a         ","",offsetof(hCardHolder106New,sGreetingName),sizeof(phCardHolder106New->sGreetingName),
	  "~","",0,sizeof(hCardHolder106New),
};

#define FIELDS107Old 4
struct hCardHolder107Old* phCardHolder107Old = 0;
Fields hCardHolder107Old_Fields[FIELDS107Old + 1] =
{
     "a         ","",offsetof(hCardHolder107Old,sLimitID),sizeof(phCardHolder107Old->sLimitID),
     "t         ","",offsetof(hCardHolder107Old,sBeginTstamp),sizeof(phCardHolder107Old->sBeginTstamp),
     "t         ","",offsetof(hCardHolder107Old,sEndTstamp),sizeof(phCardHolder107Old->sEndTstamp),
	  "o         ","",offsetof(hCardHolder107Old,sOvExpireFiller),sizeof(phCardHolder107Old->sOvExpireFiller),
	  "~","",0,sizeof(hCardHolder107Old),
};

#define FIELDS107New 4
struct hCardHolder107New* phCardHolder107New = 0;
Fields hCardHolder107New_Fields[FIELDS107New + 1] =
{
     "a         ","",offsetof(hCardHolder107New,sLimitID),sizeof(phCardHolder107New->sLimitID),
     "t         ","",offsetof(hCardHolder107New,sBeginTstamp),sizeof(phCardHolder107New->sBeginTstamp),
     "t         ","",offsetof(hCardHolder107New,sEndTstamp),sizeof(phCardHolder107New->sEndTstamp),
	  "o         ","",offsetof(hCardHolder107New,sOvExpireFiller),sizeof(phCardHolder107New->sOvExpireFiller),
	  "~","",0,sizeof(hCardHolder107New),
};

#define FIELDS108Old 7
struct hCardHolder108Old* phCardHolder108Old = 0;
Fields hCardHolder108Old_Fields[FIELDS108Old + 1] =
{
	  "a         ","",offsetof(hCardHolder108Old,sCoNameOne),sizeof(phCardHolder108Old->sCoNameOne),
	  "a         ","",offsetof(hCardHolder108Old,sCoNameTwo),sizeof(phCardHolder108Old->sCoNameTwo),
	  "a         ","",offsetof(hCardHolder108Old,sCoNameThree),sizeof(phCardHolder108Old->sCoNameThree),
	  "a         ","",offsetof(hCardHolder108Old,sCoAddressOne),sizeof(phCardHolder108Old->sCoAddressOne),
	  "a         ","",offsetof(hCardHolder108Old,sCoAddressTwo),sizeof(phCardHolder108Old->sCoAddressTwo),
	  "a         ","",offsetof(hCardHolder108Old,sCoZipCode),sizeof(phCardHolder108Old->sCoZipCode),
	  "o         ","",offsetof(hCardHolder108Old,cFiller),sizeof(phCardHolder108Old->cFiller),
	  "~","",0,sizeof(hCardHolder108Old),
};
#define FIELDS108New 7
struct hCardHolder108New* phCardHolder108New = 0;
Fields hCardHolder108New_Fields[FIELDS108New + 1] =
{
	  "a         ","",offsetof(hCardHolder108New,sCoNameOne),sizeof(phCardHolder108New->sCoNameOne),
	  "a         ","",offsetof(hCardHolder108New,sCoNameTwo),sizeof(phCardHolder108New->sCoNameTwo),
	  "a         ","",offsetof(hCardHolder108New,sCoNameThree),sizeof(phCardHolder108New->sCoNameThree),
	  "a         ","",offsetof(hCardHolder108New,sCoAddressOne),sizeof(phCardHolder108New->sCoAddressOne),
	  "a         ","",offsetof(hCardHolder108New,sCoAddressTwo),sizeof(phCardHolder108New->sCoAddressTwo),
	  "a         ","",offsetof(hCardHolder108New,sCoZipCode),sizeof(phCardHolder108New->sCoZipCode),
	  "o         ","",offsetof(hCardHolder108New,cFiller),sizeof(phCardHolder108New->cFiller),
	  "~","",0,sizeof(hCardHolder108New),
};

#define FIELDS109Old 5
struct hCardHolder109Old* phCardHolder109Old = 0;
Fields hCardHolder109Old_Fields[FIELDS109Old + 1] =
{
	 "a         ","",offsetof(hCardHolder109Old,sName),sizeof(phCardHolder109Old->sName),
	 "a         ","",offsetof(hCardHolder109Old,sIssueDtMMDDYY),sizeof(phCardHolder109Old->sIssueDtMMDDYY),
	 "a         ","",offsetof(hCardHolder109Old,sReIssueDtMMDDYY),sizeof(phCardHolder109Old->sReIssueDtMMDDYY),
	 "a         ","",offsetof(hCardHolder109Old,sCloseDtMMDDYY),sizeof(phCardHolder109Old->sCloseDtMMDDYY),
	 "a         ","",offsetof(hCardHolder109Old,sComments),sizeof(phCardHolder109Old->sComments),
	  "~","",0,sizeof(hCardHolder109Old),
};

#define FIELDS109New 5
struct hCardHolder109New* phCardHolder109New = 0;
Fields hCardHolder109New_Fields[FIELDS109New + 1] =
{
	 "a         ","",offsetof(hCardHolder109New,sName),sizeof(phCardHolder109New->sName),
	 "a         ","",offsetof(hCardHolder109New,sIssueDtMMDDYY),sizeof(phCardHolder109New->sIssueDtMMDDYY),
	 "a         ","",offsetof(hCardHolder109New,sReIssueDtMMDDYY),sizeof(phCardHolder109New->sReIssueDtMMDDYY),
	 "a         ","",offsetof(hCardHolder109New,sCloseDtMMDDYY),sizeof(phCardHolder109New->sCloseDtMMDDYY),
	 "a         ","",offsetof(hCardHolder109New,sComments),sizeof(phCardHolder109New->sComments),
	  "~","",0,sizeof(hCardHolder109New),
};

#define FIELDS110Old 4
struct hCardHolder110Old* phCardHolder110Old = 0;
Fields hCardHolder110Old_Fields[FIELDS110Old + 1] =
{
     "s         ","",offsetof(hCardHolder110Old,siConsecutiveRejects),sizeof(phCardHolder110Old->siConsecutiveRejects),
     "s         ","",offsetof(hCardHolder110Old,siPrevConsecutiveRejects),sizeof(phCardHolder110Old->siPrevConsecutiveRejects),
     "a         ","",offsetof(hCardHolder110Old,sCardType),sizeof(phCardHolder110Old->sCardType),
	 "o         ","",offsetof(hCardHolder110Old,sAddlCardFiller),sizeof(phCardHolder110Old->sAddlCardFiller),
	  "~","",0,sizeof(hCardHolder110Old),
};

#define FIELDS110New 4
struct hCardHolder110New* phCardHolder110New = 0;
Fields hCardHolder110New_Fields[FIELDS110New + 1] =
{
     "s         ","",offsetof(hCardHolder110New,siConsecutiveRejects),sizeof(phCardHolder110New->siConsecutiveRejects),
     "s         ","",offsetof(hCardHolder110New,siPrevConsecutiveRejects),sizeof(phCardHolder110New->siPrevConsecutiveRejects),
     "a         ","",offsetof(hCardHolder110New,sCardType),sizeof(phCardHolder110New->sCardType),
	 "o         ","",offsetof(hCardHolder110New,sAddlCardFiller),sizeof(phCardHolder110New->sAddlCardFiller),
	  "~","",0,sizeof(hCardHolder110New),
};
#define FIELDS112Old 5
struct hCardHolder112Old* phCardHolder112Old = 0;
Fields hCardHolder112Old_Fields[FIELDS112Old + 1] =
{
      "a         ","",offsetof(hCardHolder112Old,sAddress1),sizeof(phCardHolder112Old->sAddress1),
      "a         ","",offsetof(hCardHolder112Old,cCardCondFlag),sizeof(phCardHolder112Old->cCardCondFlag),
      "a         ","",offsetof(hCardHolder112Old,cAutoIssInd),sizeof(phCardHolder112Old->cAutoIssInd),
      "a         ","",offsetof(hCardHolder112Old,sLastMaintTstamp),sizeof(phCardHolder112Old->sLastMaintTstamp),
      "a         ","",offsetof(hCardHolder112Old,sComments),sizeof(phCardHolder112Old->sComments),
      "~","",0,sizeof(hCardHolder112Old),
};

#define FIELDS112New 5
struct hCardHolder112New* phCardHolder112New = 0;
Fields hCardHolder112New_Fields[FIELDS112New + 1] =
{
      "a         ","",offsetof(hCardHolder112New,sAddress1),sizeof(phCardHolder112New->sAddress1),
      "a         ","",offsetof(hCardHolder112New,cCardCondFlag),sizeof(phCardHolder112New->cCardCondFlag),
      "a         ","",offsetof(hCardHolder112New,cAutoIssInd),sizeof(phCardHolder112New->cAutoIssInd),
      "a         ","",offsetof(hCardHolder112New,sLastMaintTstamp),sizeof(phCardHolder112New->sLastMaintTstamp),
      "a         ","",offsetof(hCardHolder112New,sComments),sizeof(phCardHolder112New->sComments),
      "~","",0,sizeof(hCardHolder112New),
};

#define FIELDS113Old 13
struct hCardHolder113Old* phCardHolder113Old = 0;
Fields hCardHolder113Old_Fields[FIELDS113Old + 1] =
{
      "a         ","",offsetof(hCardHolder113Old,sMemberNum),sizeof(phCardHolder113Old->sMemberNum),
      "a         ","",offsetof(hCardHolder113Old,sCardName1),sizeof(phCardHolder113Old->sCardName1),
      "a         ","",offsetof(hCardHolder113Old,sCardName2),sizeof(phCardHolder113Old->sCardName2),
      "a         ","",offsetof(hCardHolder113Old,cCardName3),sizeof(phCardHolder113Old->cCardName3),
      "a         ","",offsetof(hCardHolder113Old,cCardOrdTypeFlag),sizeof(phCardHolder113Old->cCardOrdTypeFlag),
      "a         ","",offsetof(hCardHolder113Old,cCardStatFlag),sizeof(phCardHolder113Old->cCardStatFlag),
      "a         ","",offsetof(hCardHolder113Old,sCardStatTstamp),sizeof(phCardHolder113Old->sCardStatTstamp),
      "a         ","",offsetof(hCardHolder113Old,cLastIssFlag),sizeof(phCardHolder113Old->cLastIssFlag),
      "a         ","",offsetof(hCardHolder113Old,cCardReplacement),sizeof(phCardHolder113Old->cCardReplacement),
      "a         ","",offsetof(hCardHolder113Old,sDateIssTstamp),sizeof(phCardHolder113Old->sDateIssTstamp),
      "a         ","",offsetof(hCardHolder113Old,sLastIssTstamp),sizeof(phCardHolder113Old->sLastIssTstamp),
      "a         ","",offsetof(hCardHolder113Old,cPhotoId),sizeof(phCardHolder113Old->cPhotoId),
      "a         ","",offsetof(hCardHolder113Old,sCardCollectionCode),sizeof(phCardHolder113Old->sCardCollectionCode),
      "~","",0,sizeof(hCardHolder113Old),
};

#define FIELDS113New 13
struct hCardHolder113New* phCardHolder113New = 0;
Fields hCardHolder113New_Fields[FIELDS113New + 1] =
{
      "a         ","",offsetof(hCardHolder113New,sMemberNum),sizeof(phCardHolder113New->sMemberNum),
      "a         ","",offsetof(hCardHolder113New,sCardName1),sizeof(phCardHolder113New->sCardName1),
      "a         ","",offsetof(hCardHolder113New,sCardName2),sizeof(phCardHolder113New->sCardName2),
      "a         ","",offsetof(hCardHolder113New,cCardName3),sizeof(phCardHolder113New->cCardName3),
      "a         ","",offsetof(hCardHolder113New,cCardOrdTypeFlag),sizeof(phCardHolder113New->cCardOrdTypeFlag),
      "a         ","",offsetof(hCardHolder113New,cCardStatFlag),sizeof(phCardHolder113New->cCardStatFlag),
      "a         ","",offsetof(hCardHolder113New,sCardStatTstamp),sizeof(phCardHolder113New->sCardStatTstamp),
      "a         ","",offsetof(hCardHolder113New,cLastIssFlag),sizeof(phCardHolder113New->cLastIssFlag),
      "a         ","",offsetof(hCardHolder113New,cCardReplacement),sizeof(phCardHolder113New->cCardReplacement),
      "a         ","",offsetof(hCardHolder113New,sDateIssTstamp),sizeof(phCardHolder113New->sDateIssTstamp),
      "a         ","",offsetof(hCardHolder113New,sLastIssTstamp),sizeof(phCardHolder113New->sLastIssTstamp),
      "a         ","",offsetof(hCardHolder113New,cPhotoId),sizeof(phCardHolder113New->cPhotoId),
      "a         ","",offsetof(hCardHolder113New,sCardCollectionCode),sizeof(phCardHolder113New->sCardCollectionCode),
      "~","",0,sizeof(hCardHolder113New),
};

#define FIELDS114Old 9
struct hCardHolder114Old* phCardHolder114Old = 0;
Fields hCardHolder114Old_Fields[FIELDS114Old + 1] =
{
	  "a         ","",offsetof(hCardHolder114Old,sAddress1),sizeof(phCardHolder114Old->sAddress1),
	  "a         ","",offsetof(hCardHolder114Old,sAddress2),sizeof(phCardHolder114Old->sAddress2),
	  "a         ","",offsetof(hCardHolder114Old,sCity),sizeof(phCardHolder114Old->sCity),
	  "a         ","",offsetof(hCardHolder114Old,sState),sizeof(phCardHolder114Old->sState),
	  "a         ","",offsetof(hCardHolder114Old,sZipCode),sizeof(phCardHolder114Old->sZipCode),
	  "a         ","",offsetof(hCardHolder114Old,cCardConditionFlag),sizeof(phCardHolder114Old->cCardConditionFlag),
	  "a         ","",offsetof(hCardHolder114Old,cAutoIssuerInd),sizeof(phCardHolder114Old->cAutoIssuerInd),
	  "a         ","",offsetof(hCardHolder114Old,sLastMaintTStamp),sizeof(phCardHolder114Old->sLastMaintTStamp),
	  "a         ","",offsetof(hCardHolder114Old,sComments),sizeof(phCardHolder114Old->sComments),
	  "~","",0,sizeof(hCardHolder114Old),
};

#define FIELDS114New 9
struct hCardHolder114New* phCardHolder114New = 0;
Fields hCardHolder114New_Fields[FIELDS114New + 1] =
{
	  "a         ","",offsetof(hCardHolder114New,sAddress1),sizeof(phCardHolder114New->sAddress1),
	  "a         ","",offsetof(hCardHolder114New,sAddress2),sizeof(phCardHolder114New->sAddress2),
	  "a         ","",offsetof(hCardHolder114New,sCity),sizeof(phCardHolder114New->sCity),
	  "a         ","",offsetof(hCardHolder114New,sState),sizeof(phCardHolder114New->sState),
	  "a         ","",offsetof(hCardHolder114New,sZipCode),sizeof(phCardHolder114New->sZipCode),
	  "a         ","",offsetof(hCardHolder114New,cCardConditionFlag),sizeof(phCardHolder114New->cCardConditionFlag),
	  "a         ","",offsetof(hCardHolder114New,cAutoIssuerInd),sizeof(phCardHolder114New->cAutoIssuerInd),
	  "a         ","",offsetof(hCardHolder114New,sLastMaintTStamp),sizeof(phCardHolder114New->sLastMaintTStamp),
	  "a         ","",offsetof(hCardHolder114New,sComments),sizeof(phCardHolder114New->sComments),
	  "~","",0,sizeof(hCardHolder114New),
};

#define FIELDS115Old 11
struct hCardHolder115Old* phCardHolder115Old = 0;
Fields hCardHolder115Old_Fields[FIELDS115Old + 1] =
{
      "a         ","",offsetof(hCardHolder115Old,sSocialSecurityNum),sizeof(phCardHolder115Old->sSocialSecurityNum),
      "a         ","",offsetof(hCardHolder115Old,sMaidenName),sizeof(phCardHolder115Old->sMaidenName),
      "a         ","",offsetof(hCardHolder115Old,sHomePh),sizeof(phCardHolder115Old->sHomePh),
      "a         ","",offsetof(hCardHolder115Old,sWorkPh),sizeof(phCardHolder115Old->sWorkPh),
      "a         ","",offsetof(hCardHolder115Old,sUserValidation),sizeof(phCardHolder115Old->sUserValidation),
      "a         ","",offsetof(hCardHolder115Old,cVruCounter),sizeof(phCardHolder115Old->cVruCounter),
      "a         ","",offsetof(hCardHolder115Old,sDOB),sizeof(phCardHolder115Old->sDOB),
      "t         ","",offsetof(hCardHolder115Old,sActTstamp),sizeof(phCardHolder115Old->sActTstamp),
      "a         ","",offsetof(hCardHolder115Old,cActMethod),sizeof(phCardHolder115Old->cActMethod),
      "a         ","",offsetof(hCardHolder115Old,sPrevTrk2DateYYMM),sizeof(phCardHolder115Old->sPrevTrk2DateYYMM),
      "a         ","",offsetof(hCardHolder115Old,cPrevCardAct),sizeof(phCardHolder115Old->cPrevCardAct),
      "~","",0,sizeof(hCardHolder115Old),
};

#define FIELDS115New 11
struct hCardHolder115New* phCardHolder115New = 0;
Fields hCardHolder115New_Fields[FIELDS115New + 1] =
{
      "a         ","",offsetof(hCardHolder115New,sSocialSecurityNum),sizeof(phCardHolder115New->sSocialSecurityNum),
      "a         ","",offsetof(hCardHolder115New,sMaidenName),sizeof(phCardHolder115New->sMaidenName),
      "a         ","",offsetof(hCardHolder115New,sHomePh),sizeof(phCardHolder115New->sHomePh),
      "a         ","",offsetof(hCardHolder115New,sWorkPh),sizeof(phCardHolder115New->sWorkPh),
      "a         ","",offsetof(hCardHolder115New,sUserValidation),sizeof(phCardHolder115New->sUserValidation),
      "a         ","",offsetof(hCardHolder115New,cVruCounter),sizeof(phCardHolder115New->cVruCounter),
      "a         ","",offsetof(hCardHolder115New,sDOB),sizeof(phCardHolder115New->sDOB),
      "t         ","",offsetof(hCardHolder115New,sActTstamp),sizeof(phCardHolder115New->sActTstamp),
      "a         ","",offsetof(hCardHolder115New,cActMethod),sizeof(phCardHolder115New->cActMethod),
      "a         ","",offsetof(hCardHolder115New,sPrevTrk2DateYYMM),sizeof(phCardHolder115New->sPrevTrk2DateYYMM),
      "a         ","",offsetof(hCardHolder115New,cPrevCardAct),sizeof(phCardHolder115New->cPrevCardAct),
      "~","",0,sizeof(hCardHolder115New),
};

#define FIELDS116Old 7
struct hCardHolder116Old* phCardHolder116Old = 0;
Fields hCardHolder116Old_Fields[FIELDS116Old + 1] =
{
      "t         ","",offsetof(hCardHolder116Old,sInAuthLastChgd),sizeof(phCardHolder116Old->sInAuthLastChgd),
      "t         ","",offsetof(hCardHolder116Old,sDoNotDisturb),sizeof(phCardHolder116Old->sDoNotDisturb),
      "t         ","",offsetof(hCardHolder116Old,sCiStatusLastSet),sizeof(phCardHolder116Old->sCiStatusLastSet),
      "t         ","",offsetof(hCardHolder116Old,sCiStatusLastRemoved),sizeof(phCardHolder116Old->sCiStatusLastRemoved),
      "a         ","",offsetof(hCardHolder116Old,cCiStatusSetBy),sizeof(phCardHolder116Old->cCiStatusSetBy),
      "a         ","",offsetof(hCardHolder116Old,cCiStatusRemovedBy),sizeof(phCardHolder116Old->cCiStatusRemovedBy),
      "o         ","",offsetof(hCardHolder116Old,cObsolete),sizeof(phCardHolder116Old->cObsolete),
      "~","",0,sizeof(hCardHolder116Old),
};

#define FIELDS116New 7
struct hCardHolder116New* phCardHolder116New = 0;
Fields hCardHolder116New_Fields[FIELDS116New + 1] =
{
      "t         ","",offsetof(hCardHolder116New,sInAuthLastChgd),sizeof(phCardHolder116New->sInAuthLastChgd),
      "t         ","",offsetof(hCardHolder116New,sDoNotDisturb),sizeof(phCardHolder116New->sDoNotDisturb),
      "t         ","",offsetof(hCardHolder116New,sCiStatusLastSet),sizeof(phCardHolder116New->sCiStatusLastSet),
      "t         ","",offsetof(hCardHolder116New,sCiStatusLastRemoved),sizeof(phCardHolder116New->sCiStatusLastRemoved),
      "a         ","",offsetof(hCardHolder116New,cCiStatusSetBy),sizeof(phCardHolder116New->cCiStatusSetBy),
      "a         ","",offsetof(hCardHolder116New,cCiStatusRemovedBy),sizeof(phCardHolder116New->cCiStatusRemovedBy),
      "o         ","",offsetof(hCardHolder116New,cObsolete),sizeof(phCardHolder116New->cObsolete),
      "~","",0,sizeof(hCardHolder116New),
};
#define FIELDS117Old 49
struct hCardHolder117Old* phCardHolder117Old = 0;
Fields hCardHolder117Old_Fields[FIELDS117Old + 1] =
{
     "t         ","",offsetof(hCardHolder117Old,sLastManitTstamp),sizeof(phCardHolder117Old->sLastManitTstamp),
     "a         ","",offsetof(hCardHolder117Old,sCardStatus),sizeof(phCardHolder117Old->sCardStatus),
     "a         ","",offsetof(hCardHolder117Old,sPrevCardStatus),sizeof(phCardHolder117Old->sPrevCardStatus),
     "t         ","",offsetof(hCardHolder117Old,sLastCardStatTstamp),sizeof(phCardHolder117Old->sLastCardStatTstamp),
     "a         ","",offsetof(hCardHolder117Old,cConverted),sizeof(phCardHolder117Old->cConverted),
     "t         ","",offsetof(hCardHolder117Old,sConvertedTstamp),sizeof(phCardHolder117Old->sConvertedTstamp),
     "a         ","",offsetof(hCardHolder117Old,cActMeth),sizeof(phCardHolder117Old->cActMeth),
     "t         ","",offsetof(hCardHolder117Old,sActTstamp),sizeof(phCardHolder117Old->sActTstamp),
     "a         ","",offsetof(hCardHolder117Old,sPrevCardTrackII),sizeof(phCardHolder117Old->sPrevCardTrackII),
     "a         ","",offsetof(hCardHolder117Old,cPrevCardActFlag),sizeof(phCardHolder117Old->cPrevCardActFlag),
     "t         ","",offsetof(hCardHolder117Old,sLastPinChgTstamp),sizeof(phCardHolder117Old->sLastPinChgTstamp),
     "a         ","",offsetof(hCardHolder117Old,sLastPinOffset),sizeof(phCardHolder117Old->sLastPinOffset),
     "a         ","",offsetof(hCardHolder117Old,sMediaType),sizeof(phCardHolder117Old->sMediaType),
     "a         ","",offsetof(hCardHolder117Old,sServiceCode),sizeof(phCardHolder117Old->sServiceCode),
     "a         ","",offsetof(hCardHolder117Old,sCardProfile),sizeof(phCardHolder117Old->sCardProfile),
     "a         ","",offsetof(hCardHolder117Old,cAutoIssueInd),sizeof(phCardHolder117Old->cAutoIssueInd),
     "a         ","",offsetof(hCardHolder117Old,cCardAssociation),sizeof(phCardHolder117Old->cCardAssociation),
     "a         ","",offsetof(hCardHolder117Old,sCardType),sizeof(phCardHolder117Old->sCardType),
     "a         ","",offsetof(hCardHolder117Old,sCardSubType),sizeof(phCardHolder117Old->sCardSubType),
     "a         ","",offsetof(hCardHolder117Old,sCardCategory),sizeof(phCardHolder117Old->sCardCategory),
     "a         ","",offsetof(hCardHolder117Old,cCardCompanionMint),sizeof(phCardHolder117Old->cCardCompanionMint),
     "a         ","",offsetof(hCardHolder117Old,cCardCompanionMicro),sizeof(phCardHolder117Old->cCardCompanionMicro),
     "a         ","",offsetof(hCardHolder117Old,cCardCompanionMobile),sizeof(phCardHolder117Old->cCardCompanionMobile),
     "a         ","",offsetof(hCardHolder117Old,sCustomerSince),sizeof(phCardHolder117Old->sCustomerSince),
     "a         ","",offsetof(hCardHolder117Old,cVIPInd),sizeof(phCardHolder117Old->cVIPInd),
     "a         ","",offsetof(hCardHolder117Old,sEmbossedBusiness),sizeof(phCardHolder117Old->sEmbossedBusiness),
     "a         ","",offsetof(hCardHolder117Old,cContactPref),sizeof(phCardHolder117Old->cContactPref),
     "a         ","",offsetof(hCardHolder117Old,sCredLimitRef),sizeof(phCardHolder117Old->sCredLimitRef),
     "a         ","",offsetof(hCardHolder117Old,sCashLimitRef),sizeof(phCardHolder117Old->sCashLimitRef),
     "a         ","",offsetof(hCardHolder117Old,cPwrOfAttrnyFlag),sizeof(phCardHolder117Old->cPwrOfAttrnyFlag),
     "a         ","",offsetof(hCardHolder117Old,sPwrOfAttrnyName),sizeof(phCardHolder117Old->sPwrOfAttrnyName),
     "a         ","",offsetof(hCardHolder117Old,sBankBranchNo),sizeof(phCardHolder117Old->sBankBranchNo),
     "a         ","",offsetof(hCardHolder117Old,cVRUCntrCardAct),sizeof(phCardHolder117Old->cVRUCntrCardAct),
     "a         ","",offsetof(hCardHolder117Old,cVRUCntrPinChg),sizeof(phCardHolder117Old->cVRUCntrPinChg),
     "a         ","",offsetof(hCardHolder117Old,sAlertEventNo),sizeof(phCardHolder117Old->sAlertEventNo),
     "a         ","",offsetof(hCardHolder117Old,sAlertEventDate),sizeof(phCardHolder117Old->sAlertEventDate),
     "a         ","",offsetof(hCardHolder117Old,sAlertEventLTD),sizeof(phCardHolder117Old->sAlertEventLTD),
     "a         ","",offsetof(hCardHolder117Old,sSchdBlockDate),sizeof(phCardHolder117Old->sSchdBlockDate),
     "a         ","",offsetof(hCardHolder117Old,cSeverityLvl),sizeof(phCardHolder117Old->cSeverityLvl),
     "a         ","",offsetof(hCardHolder117Old,cTravelInd),sizeof(phCardHolder117Old->cTravelInd),
     "a         ","",offsetof(hCardHolder117Old,sTravelStartDate),sizeof(phCardHolder117Old->sTravelStartDate),
     "a         ","",offsetof(hCardHolder117Old,sTravelEndDate),sizeof(phCardHolder117Old->sTravelEndDate),
     "a         ","",offsetof(hCardHolder117Old,sAlertFlag1),sizeof(phCardHolder117Old->sAlertFlag1),
     "a         ","",offsetof(hCardHolder117Old,sAlertFlag2),sizeof(phCardHolder117Old->sAlertFlag2),
     "a         ","",offsetof(hCardHolder117Old,sAlertFlag3),sizeof(phCardHolder117Old->sAlertFlag3),
     "a         ","",offsetof(hCardHolder117Old,cVAUABUOptOutInd),sizeof(phCardHolder117Old->cVAUABUOptOutInd),
     "a         ","",offsetof(hCardHolder117Old,sAltCardType),sizeof(phCardHolder117Old->sAltCardType),
     "a         ","",offsetof(hCardHolder117Old,cLoyaltyOptOutFlag),sizeof(phCardHolder117Old->cLoyaltyOptOutFlag),
     "o         ","",offsetof(hCardHolder117Old,sFiller),sizeof(phCardHolder117Old->sFiller),
     "~","",0,sizeof(hCardHolder117New),
};

#define FIELDS117New 49
struct hCardHolder117New* phCardHolder117New = 0;
Fields hCardHolder117New_Fields[FIELDS117New + 1] =
{
     "t         ","",offsetof(hCardHolder117New,sLastManitTstamp),sizeof(phCardHolder117New->sLastManitTstamp),
     "a         ","",offsetof(hCardHolder117New,sCardStatus),sizeof(phCardHolder117New->sCardStatus),
     "a         ","",offsetof(hCardHolder117New,sPrevCardStatus),sizeof(phCardHolder117New->sPrevCardStatus),
     "t         ","",offsetof(hCardHolder117New,sLastCardStatTstamp),sizeof(phCardHolder117New->sLastCardStatTstamp),
     "a         ","",offsetof(hCardHolder117New,cConverted),sizeof(phCardHolder117New->cConverted),
     "t         ","",offsetof(hCardHolder117New,sConvertedTstamp),sizeof(phCardHolder117New->sConvertedTstamp),
     "a         ","",offsetof(hCardHolder117New,cActMeth),sizeof(phCardHolder117New->cActMeth),
     "t         ","",offsetof(hCardHolder117New,sActTstamp),sizeof(phCardHolder117New->sActTstamp),
     "a         ","",offsetof(hCardHolder117New,sPrevCardTrackII),sizeof(phCardHolder117New->sPrevCardTrackII),
     "a         ","",offsetof(hCardHolder117New,cPrevCardActFlag),sizeof(phCardHolder117New->cPrevCardActFlag),
     "t         ","",offsetof(hCardHolder117New,sLastPinChgTstamp),sizeof(phCardHolder117New->sLastPinChgTstamp),
     "a         ","",offsetof(hCardHolder117New,sLastPinOffset),sizeof(phCardHolder117New->sLastPinOffset),
     "a         ","",offsetof(hCardHolder117New,sMediaType),sizeof(phCardHolder117New->sMediaType),
     "a         ","",offsetof(hCardHolder117New,sServiceCode),sizeof(phCardHolder117New->sServiceCode),
     "a         ","",offsetof(hCardHolder117New,sCardProfile),sizeof(phCardHolder117New->sCardProfile),
     "a         ","",offsetof(hCardHolder117New,cAutoIssueInd),sizeof(phCardHolder117New->cAutoIssueInd),
     "a         ","",offsetof(hCardHolder117New,cCardAssociation),sizeof(phCardHolder117New->cCardAssociation),
     "a         ","",offsetof(hCardHolder117New,sCardType),sizeof(phCardHolder117New->sCardType),
     "a         ","",offsetof(hCardHolder117New,sCardSubType),sizeof(phCardHolder117New->sCardSubType),
     "a         ","",offsetof(hCardHolder117New,sCardCategory),sizeof(phCardHolder117New->sCardCategory),
     "a         ","",offsetof(hCardHolder117New,cCardCompanionMint),sizeof(phCardHolder117New->cCardCompanionMint),
     "a         ","",offsetof(hCardHolder117New,cCardCompanionMicro),sizeof(phCardHolder117New->cCardCompanionMicro),
     "a         ","",offsetof(hCardHolder117New,cCardCompanionMobile),sizeof(phCardHolder117New->cCardCompanionMobile),
     "a         ","",offsetof(hCardHolder117New,sCustomerSince),sizeof(phCardHolder117New->sCustomerSince),
     "a         ","",offsetof(hCardHolder117New,cVIPInd),sizeof(phCardHolder117New->cVIPInd),
     "a         ","",offsetof(hCardHolder117New,sEmbossedBusiness),sizeof(phCardHolder117New->sEmbossedBusiness),
     "a         ","",offsetof(hCardHolder117New,cContactPref),sizeof(phCardHolder117New->cContactPref),
     "a         ","",offsetof(hCardHolder117New,sCredLimitRef),sizeof(phCardHolder117New->sCredLimitRef),
     "a         ","",offsetof(hCardHolder117New,sCashLimitRef),sizeof(phCardHolder117New->sCashLimitRef),
     "a         ","",offsetof(hCardHolder117New,cPwrOfAttrnyFlag),sizeof(phCardHolder117New->cPwrOfAttrnyFlag),
     "a         ","",offsetof(hCardHolder117New,sPwrOfAttrnyName),sizeof(phCardHolder117New->sPwrOfAttrnyName),
     "a         ","",offsetof(hCardHolder117New,sBankBranchNo),sizeof(phCardHolder117New->sBankBranchNo),
     "a         ","",offsetof(hCardHolder117New,cVRUCntrCardAct),sizeof(phCardHolder117New->cVRUCntrCardAct),
     "a         ","",offsetof(hCardHolder117New,cVRUCntrPinChg),sizeof(phCardHolder117New->cVRUCntrPinChg),
     "a         ","",offsetof(hCardHolder117New,sAlertEventNo),sizeof(phCardHolder117New->sAlertEventNo),
     "a         ","",offsetof(hCardHolder117New,sAlertEventDate),sizeof(phCardHolder117New->sAlertEventDate),
     "a         ","",offsetof(hCardHolder117New,sAlertEventLTD),sizeof(phCardHolder117New->sAlertEventLTD),
     "a         ","",offsetof(hCardHolder117New,sSchdBlockDate),sizeof(phCardHolder117New->sSchdBlockDate),
     "a         ","",offsetof(hCardHolder117New,cSeverityLvl),sizeof(phCardHolder117New->cSeverityLvl),
     "a         ","",offsetof(hCardHolder117New,cTravelInd),sizeof(phCardHolder117New->cTravelInd),
     "a         ","",offsetof(hCardHolder117New,sTravelStartDate),sizeof(phCardHolder117New->sTravelStartDate),
     "a         ","",offsetof(hCardHolder117New,sTravelEndDate),sizeof(phCardHolder117New->sTravelEndDate),
     "a         ","",offsetof(hCardHolder117New,sAlertFlag1),sizeof(phCardHolder117New->sAlertFlag1),
     "a         ","",offsetof(hCardHolder117New,sAlertFlag2),sizeof(phCardHolder117New->sAlertFlag2),
     "a         ","",offsetof(hCardHolder117New,sAlertFlag3),sizeof(phCardHolder117New->sAlertFlag3),
     "a         ","",offsetof(hCardHolder117New,cVAUABUOptOutInd),sizeof(phCardHolder117New->cVAUABUOptOutInd),
     "a         ","",offsetof(hCardHolder117New,sAltCardType),sizeof(phCardHolder117New->sAltCardType),
     "a         ","",offsetof(hCardHolder117New,cLoyaltyOptOutFlag),sizeof(phCardHolder117New->cLoyaltyOptOutFlag),
     "o         ","",offsetof(hCardHolder117New,sFiller),sizeof(phCardHolder117New->sFiller),
     "~","",0,sizeof(hCardHolder117New),
};
#define FIELDS124Old 7
struct hCardHolder124Old* phCardHolder124Old = 0;
Fields hCardHolder124Old_Fields[FIELDS124Old + 1] =
{
     "a         ","",offsetof(hCardHolder124Old,cPinRequired),sizeof(phCardHolder124Old->cPinRequired),
     "a         ","",offsetof(hCardHolder124Old,cOdometerRequired),sizeof(phCardHolder124Old->cOdometerRequired),
     "a         ","",offsetof(hCardHolder124Old,cCategoryValid),sizeof(phCardHolder124Old->cCategoryValid),
     "~","",0,sizeof(hCardHolder124Old),
};

#define FIELDS124New 7
struct hCardHolder124New* phCardHolder124New = 0;
Fields hCardHolder124New_Fields[FIELDS124New + 1] =
{
     "a         ","",offsetof(hCardHolder124New,cPinRequired),sizeof(phCardHolder124New->cPinRequired),
     "a         ","",offsetof(hCardHolder124New,cOdometerRequired),sizeof(phCardHolder124New->cOdometerRequired),
     "a         ","",offsetof(hCardHolder124New,cCategoryValid),sizeof(phCardHolder124New->cCategoryValid),
     "~","",0,sizeof(hCardHolder124New),
};

#define FIELDS118Old 22
struct hCardHolder118Old* phCardHolder118Old = 0;
Fields hCardHolder118Old_Fields[FIELDS118Old + 1] =
{
     "s         ","",offsetof(hCardHolder118Old,siPartKey),sizeof(phCardHolder118Old->siPartKey),
     "a         ","",offsetof(hCardHolder118Old,sFI_ID),sizeof(phCardHolder118Old->sFI_ID),
     "a         ","",offsetof(hCardHolder118Old,sCardGroup),sizeof(phCardHolder118Old->sCardGroup),
     "a         ","",offsetof(hCardHolder118Old,sPan),sizeof(phCardHolder118Old->sPan),
     "a         ","",offsetof(hCardHolder118Old,sPlastic),sizeof(phCardHolder118Old->sPlastic),
     "a         ","",offsetof(hCardHolder118Old,sAcctType),sizeof(phCardHolder118Old->sAcctType),
     "a         ","",offsetof(hCardHolder118Old,sAcctNo),sizeof(phCardHolder118Old->sAcctNo),
     "t         ","",offsetof(hCardHolder118Old,sCreateTime),sizeof(phCardHolder118Old->sCreateTime),
     "a         ","",offsetof(hCardHolder118Old,sTranIdent),sizeof(phCardHolder118Old->sTranIdent),
     "a         ","",offsetof(hCardHolder118Old,sTermRef),sizeof(phCardHolder118Old->sTermRef),
     "a         ","",offsetof(hCardHolder118Old,cPreAuthInd),sizeof(phCardHolder118Old->cPreAuthInd),
     "a         ","",offsetof(hCardHolder118Old,sAcqDay),sizeof(phCardHolder118Old->sAcqDay),
     "a         ","",offsetof(hCardHolder118Old,sAuthNbr),sizeof(phCardHolder118Old->sAuthNbr),
     "a         ","",offsetof(hCardHolder118Old,sLimitID),sizeof(phCardHolder118Old->sLimitID),
     "a         ","",offsetof(hCardHolder118Old,cHoldType),sizeof(phCardHolder118Old->cHoldType),
     "t         ","",offsetof(hCardHolder118Old,sExpTime),sizeof(phCardHolder118Old->sExpTime),
     "a         ","",offsetof(hCardHolder118Old,sAmount),sizeof(phCardHolder118Old->sAmount),
     "a         ","",offsetof(hCardHolder118Old,sMerchName),sizeof(phCardHolder118Old->sMerchName),
     "a         ","",offsetof(hCardHolder118Old,cHoldStatus),sizeof(phCardHolder118Old->cHoldStatus),
     "a         ","",offsetof(hCardHolder118Old,sMerchCode),sizeof(phCardHolder118Old->sMerchCode),
     "a         ","",offsetof(hCardHolder118Old,sExpUserID),sizeof(phCardHolder118Old->sExpUserID),
     "t         ","",offsetof(hCardHolder118Old,sLastMaintTstamp),sizeof(phCardHolder118Old->sLastMaintTstamp),
     "~","",0,sizeof(hCardHolder118Old),
};
#define FIELDS118New 22
struct hCardHolder118New* phCardHolder118New = 0;
Fields hCardHolder118New_Fields[FIELDS118New + 1] =
{
     "s         ","",offsetof(hCardHolder118New,siPartKey),sizeof(phCardHolder118New->siPartKey),
     "a         ","",offsetof(hCardHolder118New,sFI_ID),sizeof(phCardHolder118New->sFI_ID),
     "a         ","",offsetof(hCardHolder118New,sCardGroup),sizeof(phCardHolder118Old->sCardGroup),
     "a         ","",offsetof(hCardHolder118New,sPan),sizeof(phCardHolder118New->sPan),
     "a         ","",offsetof(hCardHolder118New,sPlastic),sizeof(phCardHolder118New->sPlastic),
     "a         ","",offsetof(hCardHolder118New,sAcctType),sizeof(phCardHolder118New->sAcctType),
     "a         ","",offsetof(hCardHolder118New,sAcctNo),sizeof(phCardHolder118New->sAcctNo),
     "t         ","",offsetof(hCardHolder118New,sCreateTime),sizeof(phCardHolder118New->sCreateTime),
     "a         ","",offsetof(hCardHolder118New,sTranIdent),sizeof(phCardHolder118New->sTranIdent),
     "a         ","",offsetof(hCardHolder118New,sTermRef),sizeof(phCardHolder118New->sTermRef),
     "a         ","",offsetof(hCardHolder118New,cPreAuthInd),sizeof(phCardHolder118New->cPreAuthInd),
     "a         ","",offsetof(hCardHolder118New,sAcqDay),sizeof(phCardHolder118New->sAcqDay),
     "a         ","",offsetof(hCardHolder118New,sAuthNbr),sizeof(phCardHolder118New->sAuthNbr),
     "a         ","",offsetof(hCardHolder118New,sLimitID),sizeof(phCardHolder118New->sLimitID),
     "a         ","",offsetof(hCardHolder118New,cHoldType),sizeof(phCardHolder118New->cHoldType),
     "t         ","",offsetof(hCardHolder118New,sExpTime),sizeof(phCardHolder118New->sExpTime),
     "a         ","",offsetof(hCardHolder118New,sAmount),sizeof(phCardHolder118New->sAmount),
     "a         ","",offsetof(hCardHolder118New,sMerchName),sizeof(phCardHolder118New->sMerchName),
     "a         ","",offsetof(hCardHolder118New,cHoldStatus),sizeof(phCardHolder118New->cHoldStatus),
     "a         ","",offsetof(hCardHolder118New,sMerchCode),sizeof(phCardHolder118New->sMerchCode),
     "a         ","",offsetof(hCardHolder118New,sExpUserID),sizeof(phCardHolder118New->sExpUserID),
     "t         ","",offsetof(hCardHolder118New,sLastMaintTstamp),sizeof(phCardHolder118New->sLastMaintTstamp),
     "~","",0,sizeof(hCardHolder118New),
};

#define FIELDS119Old 27
struct hCardHolder119Old* phCardHolder119Old = 0;
Fields hCardHolder119Old_Fields[FIELDS119Old + 1] =
{
     "a         ","",offsetof(hCardHolder119Old,sStopID),sizeof(phCardHolder119Old->sStopID),
     "a         ","",offsetof(hCardHolder119Old,sLastMaintTstamp),sizeof(phCardHolder119Old->sLastMaintTstamp),
     "a         ","",offsetof(hCardHolder119Old,sStopLevel),sizeof(phCardHolder119Old->sStopLevel),
     "a         ","",offsetof(hCardHolder119Old,sStopType),sizeof(phCardHolder119Old->sStopType),
     "a         ","",offsetof(hCardHolder119Old,sStopReason),sizeof(phCardHolder119Old->sStopReason),
     "a         ","",offsetof(hCardHolder119Old,sStopStartDate),sizeof(phCardHolder119Old->sStopStartDate),
     "a         ","",offsetof(hCardHolder119Old,sStopEndDate),sizeof(phCardHolder119Old->sStopEndDate),
     "a         ","",offsetof(hCardHolder119Old,sTranAmount),sizeof(phCardHolder119Old->sTranAmount),
     "a         ","",offsetof(hCardHolder119Old,sAmountLow),sizeof(phCardHolder119Old->sAmountLow),
     "a         ","",offsetof(hCardHolder119Old,sAmountHigh),sizeof(phCardHolder119Old->sAmountHigh),
     "a         ","",offsetof(hCardHolder119Old,sStopRetrevialRefNo),sizeof(phCardHolder119Old->sStopRetrevialRefNo),
     "a         ","",offsetof(hCardHolder119Old,sStopIndex),sizeof(phCardHolder119Old->sStopIndex),
     "a         ","",offsetof(hCardHolder119Old,cVisaRestrictRIIND),sizeof(phCardHolder119Old->cVisaRestrictRIIND),
     "a         ","",offsetof(hCardHolder119Old,sStopCreatedTstamp),sizeof(phCardHolder119Old->sStopCreatedTstamp),
     "a         ","",offsetof(hCardHolder119Old,sStopPaymentFiller),sizeof(phCardHolder119Old->sStopPaymentFiller),
     "a         ","",offsetof(hCardHolder119Old,sOrigTranType),sizeof(phCardHolder119Old->sOrigTranType),
     "a         ","",offsetof(hCardHolder119Old,sOrigPaymentType),sizeof(phCardHolder119Old->sOrigPaymentType),
     "a         ","",offsetof(hCardHolder119Old,sOrigTranDate),sizeof(phCardHolder119Old->sOrigTranDate),
     "a         ","",offsetof(hCardHolder119Old,sOrigTranAmount),sizeof(phCardHolder119Old->sOrigTranAmount),
     "a         ","",offsetof(hCardHolder119Old,sOrigTranRRN),sizeof(phCardHolder119Old->sOrigTranRRN),
     "a         ","",offsetof(hCardHolder119Old,sMerchantName),sizeof(phCardHolder119Old->sMerchantName),
     "a         ","",offsetof(hCardHolder119Old,sMCC),sizeof(phCardHolder119Old->sMCC),
     "a         ","",offsetof(hCardHolder119Old,sPaymentFacID),sizeof(phCardHolder119Old->sPaymentFacID),
     "a         ","",offsetof(hCardHolder119Old,sSubMerchantID),sizeof(phCardHolder119Old->sSubMerchantID),
     "a         ","",offsetof(hCardHolder119Old,sCardAcptID),sizeof(phCardHolder119Old->sCardAcptID),
     "a         ","",offsetof(hCardHolder119Old,sMCAcqID),sizeof(phCardHolder119Old->sMCAcqID),
     "a         ","",offsetof(hCardHolder119Old,sOrigTranFiller),sizeof(phCardHolder119Old->sOrigTranFiller),
     "~", "", 0, sizeof(hCardHolder119Old),
};

#define FIELDS119New 27
struct hCardHolder119New* phCardHolder119New = 0;
Fields hCardHolder119New_Fields[FIELDS119New + 1] =
{
     "a         ","",offsetof(hCardHolder119New,sStopID),sizeof(phCardHolder119New->sStopID),
     "a         ","",offsetof(hCardHolder119New,sLastMaintTstamp),sizeof(phCardHolder119New->sLastMaintTstamp),
     "a         ","",offsetof(hCardHolder119New,sStopLevel),sizeof(phCardHolder119New->sStopLevel),
     "a         ","",offsetof(hCardHolder119New,sStopType),sizeof(phCardHolder119New->sStopType),
     "a         ","",offsetof(hCardHolder119New,sStopReason),sizeof(phCardHolder119New->sStopReason),
     "a         ","",offsetof(hCardHolder119New,sStopStartDate),sizeof(phCardHolder119New->sStopStartDate),
     "a         ","",offsetof(hCardHolder119New,sStopEndDate),sizeof(phCardHolder119New->sStopEndDate),
     "a         ","",offsetof(hCardHolder119New,sTranAmount),sizeof(phCardHolder119New->sTranAmount),
     "a         ","",offsetof(hCardHolder119New,sAmountLow),sizeof(phCardHolder119New->sAmountLow),
     "a         ","",offsetof(hCardHolder119New,sAmountHigh),sizeof(phCardHolder119New->sAmountHigh),
     "a         ","",offsetof(hCardHolder119New,sStopRetrevialRefNo),sizeof(phCardHolder119New->sStopRetrevialRefNo),
     "a         ","",offsetof(hCardHolder119New,sStopIndex),sizeof(phCardHolder119New->sStopIndex),
     "a         ","",offsetof(hCardHolder119New,cVisaRestrictRIIND),sizeof(phCardHolder119New->cVisaRestrictRIIND),
     "a         ","",offsetof(hCardHolder119New,sStopCreatedTstamp),sizeof(phCardHolder119New->sStopCreatedTstamp),
     "a         ","",offsetof(hCardHolder119New,sStopPaymentFiller),sizeof(phCardHolder119New->sStopPaymentFiller),
     "a         ","",offsetof(hCardHolder119New,sOrigTranType),sizeof(phCardHolder119New->sOrigTranType),
     "a         ","",offsetof(hCardHolder119New,sOrigPaymentType),sizeof(phCardHolder119New->sOrigPaymentType),
     "a         ","",offsetof(hCardHolder119New,sOrigTranDate),sizeof(phCardHolder119New->sOrigTranDate),
     "a         ","",offsetof(hCardHolder119New,sOrigTranAmount),sizeof(phCardHolder119New->sOrigTranAmount),
     "a         ","",offsetof(hCardHolder119New,sOrigTranRRN),sizeof(phCardHolder119New->sOrigTranRRN),
     "a         ","",offsetof(hCardHolder119New,sMerchantName),sizeof(phCardHolder119New->sMerchantName),
     "a         ","",offsetof(hCardHolder119New,sMCC),sizeof(phCardHolder119New->sMCC),
     "a         ","",offsetof(hCardHolder119New,sPaymentFacID),sizeof(phCardHolder119New->sPaymentFacID),
     "a         ","",offsetof(hCardHolder119New,sSubMerchantID),sizeof(phCardHolder119New->sSubMerchantID),
     "a         ","",offsetof(hCardHolder119New,sCardAcptID),sizeof(phCardHolder119New->sCardAcptID),
     "a         ","",offsetof(hCardHolder119New,sMCAcqID),sizeof(phCardHolder119New->sMCAcqID),
     "a         ","",offsetof(hCardHolder119New,sOrigTranFiller),sizeof(phCardHolder119New->sOrigTranFiller),
     "~", "", 0, sizeof(hCardHolder119New),
};
//## end module%3C6136CE02DE.additionalDeclarations


// Class AdvantageAPCardMaintenance 

AdvantageAPCardMaintenance::AdvantageAPCardMaintenance()
  //## begin AdvantageAPCardMaintenance::AdvantageAPCardMaintenance%3C6131EB002E_const.hasinit preserve=no
      : m_bAD14Message(false)
  //## end AdvantageAPCardMaintenance::AdvantageAPCardMaintenance%3C6131EB002E_const.hasinit
  //## begin AdvantageAPCardMaintenance::AdvantageAPCardMaintenance%3C6131EB002E_const.initialization preserve=yes
   ,AdvantageMessage("0850","F001")
  //## end AdvantageAPCardMaintenance::AdvantageAPCardMaintenance%3C6131EB002E_const.initialization
{
  //## begin AdvantageAPCardMaintenance::AdvantageAPCardMaintenance%3C6131EB002E_const.body preserve=yes
   memcpy(m_sID,"AI04",4);
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CH01"),make_pair(&hCardHolder100Old_Fields[0],&hCardHolder100New_Fields[0]))); //  (string("CH01"),make_pair(&hCardHolder100Old_Fields[0],&hCardHolder100New_Fields[0]));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CH02"),make_pair(&hCardHolder101Old_Fields[0],&hCardHolder101New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CH03"),make_pair(&hCardHolder102Old_Fields[0],&hCardHolder102New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CH04"),make_pair(&hCardHolder103Old_Fields[0],&hCardHolder103New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CH06"),make_pair(&hCardHolder104Old_Fields[0],&hCardHolder104New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CH08"),make_pair(&hCardHolder106Old_Fields[0],&hCardHolder106New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CH09"),make_pair(&hCardHolder107Old_Fields[0],&hCardHolder107New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CH14"),make_pair(&hCardHolder110Old_Fields[0],&hCardHolder110New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CH18"),make_pair(&hCardHolder112Old_Fields[0],&hCardHolder112New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CH19"),make_pair(&hCardHolder113Old_Fields[0],&hCardHolder113New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CH20"),make_pair(&hCardHolder114Old_Fields[0],&hCardHolder114New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CH22"),make_pair(&hCardHolder115Old_Fields[0],&hCardHolder115New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CH23"),make_pair(&hCardHolder116Old_Fields[0],&hCardHolder116New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CH24"),make_pair(&hCardHolder124Old_Fields[0],&hCardHolder124New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("CD01"),make_pair(&hCardHolder117Old_Fields[0],&hCardHolder117New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("AH01"),make_pair(&hCardHolder118Old_Fields[0],&hCardHolder118New_Fields[0])));
   m_hCardHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("SP01"),make_pair(&hCardHolder119Old_Fields[0],&hCardHolder119New_Fields[0])));
   string strTemp;
   Extract::instance()->getSpec("AD14",strTemp);
   if (strTemp.find("LOADAD14") != string::npos)
	   setAD14Message(true);
  //## end AdvantageAPCardMaintenance::AdvantageAPCardMaintenance%3C6131EB002E_const.body
}


AdvantageAPCardMaintenance::~AdvantageAPCardMaintenance()
{
  //## begin AdvantageAPCardMaintenance::~AdvantageAPCardMaintenance%3C6131EB002E_dest.body preserve=yes
  //## end AdvantageAPCardMaintenance::~AdvantageAPCardMaintenance%3C6131EB002E_dest.body
}



//## Other Operations (implementation)
bool AdvantageAPCardMaintenance::insert (Message& hMessage)
{
  //## begin AdvantageAPCardMaintenance::insert%3C618E9D005D.body preserve=yes
   m_hAuditMaintSegment.reset();
   m_hAIMSBillingSegment.reset();
   m_hAuditSegment.reset();
   m_hListSegment.reset();
   AdvantageMessage::insert(hMessage);
   m_pAdvantageMessageProcessor = AdvantageMessageProcessor::instance();
   if (m_pAdvantageMessageProcessor->getMessageCode() == "0855")
   {
      if (Extract::instance()->getCustomCode() == "FIS")
         UseCase hUseCase("TANDEM", "## AD15 READ 0855 AP CARD", false);
      else
         return false;
   }
   else
      UseCase hUseCase("TANDEM", "## AD14 READ 0850 AP CARD", false);
   hV13AdvantageHeader* pAdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   char* pStart = hMessage.data() + sizeof(hV13AdvantageHeader);
   hCardHolder* pCardHolder = (hCardHolder*)(pStart);
   hCardHolderKey* pCardHolderKey = (hCardHolderKey*)(pStart + sizeof(hCardHolder));
   hAcctHolderKey* pAcctHolderKey = (hAcctHolderKey*)(pStart + sizeof(hCardHolder));
   string strRecType(pCardHolder->sRecType, 4);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pCardHolder->sRecType,((char*)(&pCardHolder->siStepNo)-pCardHolder->sRecType),
      CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pCardHolder->sSourceId,(pCardHolder->sNegStatKey - pCardHolder->sSourceId + sizeof(pCardHolder->sNegStatKey)),
      CodeTable::CX_ASCII_TO_EBCDIC);
      if (strRecType == "AH01")
         CodeTable::translate(pAcctHolderKey->sFRDABA, (pAcctHolderKey->sAcctNo - pAcctHolderKey->sFRDABA), CodeTable::CX_ASCII_TO_EBCDIC);
      else
         CodeTable::translate(pCardHolderKey->sFRDABA, (pCardHolderKey->sPlasticNo - pCardHolderKey->sFRDABA), CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pCardHolder->sRecType,((char*)(&pCardHolder->siStepNo)-pCardHolder->sRecType),
      CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pCardHolder->sSourceId,(pCardHolder->sNegStatKey - pCardHolder->sSourceId + sizeof(pCardHolder->sNegStatKey)),
      CodeTable::CX_EBCDIC_TO_ASCII);
      if (strRecType == "AH01")
         CodeTable::translate(pAcctHolderKey->sFRDABA, (pAcctHolderKey->sAcctNo - pAcctHolderKey->sFRDABA), CodeTable::CX_EBCDIC_TO_ASCII);
      else
         CodeTable::translate(pCardHolderKey->sFRDABA, (pCardHolderKey->sPlasticNo - pCardHolderKey->sFRDABA), CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   m_hAuditMaintSegment.setRECORD_TYPE(pCardHolder->sRecType,4);
   string strPAN;
   char szBusinessKey[33];
   memset(szBusinessKey, ' ', sizeof(szBusinessKey));
   if (strRecType == "AH01")
   {
      if (pAcctHolderKey->sFRDABA[10] != ' ')
         m_hAuditMaintSegment.setINST_ID(pAcctHolderKey->sFRDABA + 1, 9);
      else
         m_hAuditMaintSegment.setINST_ID(pAcctHolderKey->sFRDABA, 9);
      memcpy(szBusinessKey, pAcctHolderKey->sAcctType,4);
      memcpy(szBusinessKey + 4, "~", 1);
      memcpy(szBusinessKey + 7, pAcctHolderKey->sAcctNo, 28);
      m_hAuditMaintSegment.setBUSINESS_KEY(szBusinessKey, 33);
   }
   else
   {
      if (pCardHolderKey->sFRDABA[10] != ' ')
         m_hAuditMaintSegment.setINST_ID(pCardHolderKey->sFRDABA + 1, 9);
      else
         m_hAuditMaintSegment.setINST_ID(pCardHolderKey->sFRDABA, 9);
      memcpy(szBusinessKey, pCardHolderKey->sCardGroup, 6);
      memcpy(szBusinessKey + 6, "~", 1);
      strPAN.assign(pCardHolderKey->sPan, 19);
      KeyRing::instance()->tokenize(pCardHolderKey->sPan, 19);
      memcpy(szBusinessKey + 7, pCardHolderKey->sPan, 19);
      m_hAuditMaintSegment.setBUSINESS_KEY(szBusinessKey, 26);
   }
   switch (ntohs(pCardHolder->siStepNo))
   {
   case 5:
      m_hAuditMaintSegment.setRECORD_ACTION("A",1);
      break;
   case 6:
      m_hAuditMaintSegment.setRECORD_ACTION("D",1);
      break;
   case 8:
      m_hAuditMaintSegment.setRECORD_ACTION("C",1);
      break;
   default:
      m_hAuditMaintSegment.setRECORD_ACTION("U",1);
      break;
   }
   m_hAuditMaintSegment.setSOURCE_ID(pCardHolder->sSourceId,16);
   m_hAuditMaintSegment.setTERM_ID(pCardHolder->sCrtTermIdent,16);
   
   char* pFormatOld = m_hAuditMaintSegment.zOLD_VALUE();
   char* pFormatNew = m_hAuditMaintSegment.zNEW_VALUE();
   int ilen = 0;
   map<string, pair<Fields*, Fields*>, less<string> >::iterator p = m_hCardHolder.find(strRecType);
   if (p != m_hCardHolder.end())
   {
      if (strRecType == "AH01")
      {
         m_hAuditMaintSegment.setField((*p).second.first, '~', pStart + sizeof(hCardHolder) + sizeof(hAcctHolderKey), ilen, &pFormatOld, AdvantageMessageProcessor::instance()->getAsciiInput());
         m_hAuditMaintSegment.setField((*p).second.second, '~', pStart + sizeof(hCardHolder) + sizeof(hAcctHolderKey) + ilen, ilen, &pFormatNew, AdvantageMessageProcessor::instance()->getAsciiInput());
      }
      else
      {
         m_hAuditMaintSegment.setField((*p).second.first, '~', pStart + sizeof(hCardHolder) + sizeof(hCardHolderKey), ilen, &pFormatOld, AdvantageMessageProcessor::instance()->getAsciiInput());
         m_hAuditMaintSegment.setField((*p).second.second, '~', pStart + sizeof(hCardHolder) + sizeof(hCardHolderKey) + ilen, ilen, &pFormatNew, AdvantageMessageProcessor::instance()->getAsciiInput());
      }
   }
   else
      return false;
   char sDateTime16[17] = { "                " };
   char sCentury[2];
   DateTime::calcCentury(pCardHolder->sTimeStamp, sCentury);
   memcpy(sDateTime16, sCentury, 2);
   memcpy(sDateTime16 + 2, pCardHolder->sTimeStamp, 14);
   string strTSTAMP_TRANS(sDateTime16, 16);
   m_hAuditMaintSegment.setTSTAMP_TRANS(strTSTAMP_TRANS.data(), strTSTAMP_TRANS.length());
   if (getTestDate().length())
   {
	   string strTemp(getTestDate());
	   strTemp += strTSTAMP_TRANS.substr(8);
	   m_hAuditMaintSegment.setTSTAMP_TRANS(strTemp.data(), 16);
   }
   unsigned short j = 0;
   int i = 0;
   for (i = 0; i < strlen(pFormatOld); i++)
	   j = 33 * j + m_hAuditMaintSegment.zOLD_VALUE()[i];
   for (i = 0; i < strlen(pFormatNew); i++)
	   j = 33 * j + m_hAuditMaintSegment.zNEW_VALUE()[i];
   if (j > 32767)
	   j -= 32768;
   if (strRecType == "SP01" && strstr(m_hAuditMaintSegment.zOLD_VALUE(),"FAILURE-LOG"))
      return false;
   m_hAuditMaintSegment.setUNIQUENESS_KEY((int)j);
   bool bCardAct = false;
   string strSourceId(m_hAuditMaintSegment.zSOURCE_ID(), 16);
   if ((*p).first == "CH01" || (*p).first == "CH02" || (*p).first == "SP01")
   {
      if ((*p).first == "CH01")
      {
         m_hAIMSBillingSegment.setPresence(true);
         char* phCardHolder100Old = pStart + sizeof(hCardHolder) + sizeof(hCardHolderKey);
         hCardHolder100Old* cardHolder100Old = (hCardHolder100Old*)(phCardHolder100Old);
         char* phCardHolder100New = phCardHolder100Old + sizeof(hCardHolder100Old);
         hCardHolder100New* cardHolder100New = (hCardHolder100New*)(phCardHolder100New);
         if (cardHolder100Old->cCardAct == 'N' && cardHolder100New->cCardAct == 'Y')
            bCardAct = true;
      }
      else if ((*p).first == "SP01")
         m_hAIMSBillingSegment.setPresence(true);
      else
      {
         char* phCardHolder101Old = pStart + sizeof(hCardHolder) + sizeof(hCardHolderKey);
         hCardHolder101Old* cardHolder101Old = (hCardHolder101Old*)(phCardHolder101Old);
         char* phCardHolder101New = pStart + sizeof(hCardHolder) + sizeof(hCardHolderKey) + sizeof(hCardHolder101Old);
         hCardHolder101New* cardHolder101New = (hCardHolder101New*)(phCardHolder101New);
         if (cardHolder101Old->sPinAuthVal != cardHolder101New->sPinAuthVal)
            m_hAIMSBillingSegment.setPresence(true);
      }
   }
   hMessage.reset("AI LE ", "S0002D");
   char* psBuffer = hMessage.data();
   m_lTstampHash = ntohl(pAdvantageHeader->lHdrTstamp2Hash);
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   int iCount = 0;
   char* pData2 = psBuffer + 4;
   m_hListSegment.write(&psBuffer);
   m_hAuditMaintSegment.write(&psBuffer);
   iCount++;
   if (m_hAIMSBillingSegment.presence())
   {
      m_hAIMSBillingSegment.setTSTAMP_TRANS(m_hAuditMaintSegment.zTSTAMP_TRANS(), 16);
      m_hAIMSBillingSegment.setUNIQUENESS_KEY((int)j);
      m_hAIMSBillingSegment.setINST_ID(m_hAuditMaintSegment.zINST_ID(), 11);
      m_hAIMSBillingSegment.setTERM_ID("");
      m_hAIMSBillingSegment.setBIN(strPAN.data(), 6);
      m_hAIMSBillingSegment.setBUSINESS_KEY(m_hAuditMaintSegment.zBUSINESS_KEY(), 26);
      if ((*p).first == "CH02")
      {
         if (strSourceId.find("VRU") != string::npos)
         {
            m_hAIMSBillingSegment.setRECORD_TYPE("CH2V", 4);
            m_hAIMSBillingSegment.write(&psBuffer);
            iCount++;
         }
         else if (strSourceId.find("ONLINE") != string::npos)
         {
            m_hAIMSBillingSegment.setRECORD_TYPE(m_hAuditMaintSegment.zRECORD_TYPE(), 8);
         m_hAIMSBillingSegment.write(&psBuffer);
         iCount++;
         }
      }
      else if ((*p).first == "SP01")
      {
         m_hAIMSBillingSegment.setRECORD_TYPE("SP01",4);
         m_hAIMSBillingSegment.write(&psBuffer);
         iCount++;
      }
      else
      {
         if (bCardAct == true)
         {
            if (strSourceId.find("VRU") != string::npos)
            {
               m_hAIMSBillingSegment.setRECORD_TYPE("CH1V", 4);
               m_hAIMSBillingSegment.write(&psBuffer);
               iCount++;
            }
            m_hAIMSBillingSegment.setRECORD_TYPE("CH01", 4);
            m_hAIMSBillingSegment.write(&psBuffer);
            iCount++;
         }
         if (strSourceId.find("BATCH") == string::npos
            && m_hAuditMaintSegment.zRECORD_ACTION()[0] == 'A')
         {
            m_hAIMSBillingSegment.setRECORD_TYPE("CH1I", 4);
            m_hAIMSBillingSegment.write(&psBuffer);
            iCount++;
         }
         if ((m_hAuditMaintSegment.zRECORD_ACTION()[0] == 'C'
            || m_hAuditMaintSegment.zRECORD_ACTION()[0] == 'A')
            && (strSourceId[0] == 'E'
               || strSourceId[0] == 'e'
               || strSourceId.find("BATCH") != string::npos
               || memcmp(strSourceId.data(), "LC", 2) == 0
               || memcmp(strSourceId.data(), "lc", 2) == 0))
         {
            if (m_hAuditMaintSegment.zRECORD_ACTION()[0] == 'A')
            {
               if (strSourceId.find("BATCH") != string::npos)
               {
                  m_hAIMSBillingSegment.setRECORD_TYPE("CH1L", 4);
                  m_hAIMSBillingSegment.write(&psBuffer);
                  iCount++;
               }
               else
               {
                  size_t n = strSourceId.substr(1).find_first_not_of("0123456789");
                  if (n >= 7)
                  {
                     m_hAIMSBillingSegment.setRECORD_TYPE("CH1S", 4);
                     m_hAIMSBillingSegment.write(&psBuffer);
                     iCount++;
                  }
               }
            }
            else
            {
               if (strSourceId.find("BATCH") != string::npos)
               {
                  m_hAIMSBillingSegment.setRECORD_TYPE("CH1C", 4);
                  m_hAIMSBillingSegment.write(&psBuffer);
                  iCount++;
               }
               else
               {
                  size_t n = strSourceId.substr(1).find_first_not_of("0123456789");
                  if (n >= 7)
                  {
                     m_hAIMSBillingSegment.setRECORD_TYPE("CH1F", 4);
                     m_hAIMSBillingSegment.write(&psBuffer);
                     iCount++;
                  }
               }
            }
         }
         if (strSourceId.find("BATCH") != string::npos)
            m_hAIMSBillingSegment.setRECORD_TYPE("CH1E", 4);
         else
            m_hAIMSBillingSegment.setRECORD_TYPE("CH1W", 4);
         m_hAIMSBillingSegment.write(&psBuffer);
         iCount++;
      }
   }
   m_hListSegment.update(pData2, iCount, psBuffer - pData2);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageAPCardMaintenance::insert%3C618E9D005D.body
}

// Additional Declarations
  //## begin AdvantageAPCardMaintenance%3C6131EB002E.declarations preserve=yes
  //## end AdvantageAPCardMaintenance%3C6131EB002E.declarations

//## begin module%3C6136CE02DE.epilog preserve=yes
//## end module%3C6136CE02DE.epilog
