//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3C6139C8001F.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C6139C8001F.cm

//## begin module%3C6139C8001F.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3C6139C8001F.cp

//## Module: CXOSAI14%3C6139C8001F; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Pvcswork\Dn\Server\Application\Ai\CXOSAI14.cpp

//## begin module%3C6139C8001F.additionalIncludes preserve=no
//## end module%3C6139C8001F.additionalIncludes

//## begin module%3C6139C8001F.includes preserve=yes
// $Date:   Jun 21 2017 08:43:50  $ $Author:   e1009839  $ $Revision:   1.23  $
#include "CXODIF11.hpp"
//## end module%3C6139C8001F.includes

#ifndef CXOSAI14_h
#include "CXODAI14.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif


//## begin module%3C6139C8001F.declarations preserve=no
//## end module%3C6139C8001F.declarations

//## begin module%3C6139C8001F.additionalDeclarations preserve=yes
//## end module%3C6139C8001F.additionalDeclarations


// Class AdvantageProcessorAdvice



AdvantageProcessorAdvice::AdvantageProcessorAdvice()
  //## begin AdvantageProcessorAdvice::AdvantageProcessorAdvice%3C6133E800AB_const.hasinit preserve=no
  //## end AdvantageProcessorAdvice::AdvantageProcessorAdvice%3C6133E800AB_const.hasinit
  //## begin AdvantageProcessorAdvice::AdvantageProcessorAdvice%3C6133E800AB_const.initialization preserve=yes
   : AdvantageMessage("0462","S907")
  //## end AdvantageProcessorAdvice::AdvantageProcessorAdvice%3C6133E800AB_const.initialization
{
  //## begin AdvantageProcessorAdvice::AdvantageProcessorAdvice%3C6133E800AB_const.body preserve=yes
   memcpy(m_sID,"AI14",4);
  //## end AdvantageProcessorAdvice::AdvantageProcessorAdvice%3C6133E800AB_const.body
}


AdvantageProcessorAdvice::~AdvantageProcessorAdvice()
{
  //## begin AdvantageProcessorAdvice::~AdvantageProcessorAdvice%3C6133E800AB_dest.body preserve=yes
  //## end AdvantageProcessorAdvice::~AdvantageProcessorAdvice%3C6133E800AB_dest.body
}



//## Other Operations (implementation)
bool AdvantageProcessorAdvice::insert (Message& hMessage)
{
  //## begin AdvantageProcessorAdvice::insert%3C6188390251.body preserve=yes
   UseCase hUseCase("TANDEM","## AD24 READ 0462 PROC ADVICE",false);
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   hProcessorAdvice* pProcessorAdvice = (hProcessorAdvice*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   if (((memcmp(pProcessorAdvice->sTranType,"00",2) != 0) &&
        (memcmp(pProcessorAdvice->sTranType,"01",2) != 0) &&
        (memcmp(pProcessorAdvice->sTranType,"02",2) != 0) &&
        (memcmp(pProcessorAdvice->sTranType,"03",2) != 0) &&
        (memcmp(pProcessorAdvice->sTranType,"04",2) != 0) &&
        (memcmp(pProcessorAdvice->sTranType,"05",2) != 0) &&
        (memcmp(pProcessorAdvice->sTranType,"06",2) != 0) &&
        (memcmp(pProcessorAdvice->sTranType,"07",2) != 0) &&
        (memcmp(pProcessorAdvice->sTranType,"08",2) != 0) &&
        (memcmp(pProcessorAdvice->sTranType,"09",2) != 0) &&
        (memcmp(pProcessorAdvice->sTranType,"99",2) != 0))
      || (ntohs(pV13AdvantageHeader->siHdrMsgStep) != 1))
      return false;
   m_hCutoffSegment.reset();
   m_hAuditSegment.reset();
   m_siUniquenessKey += 1;
   char sBlankProc[7] = {"      "};
   char sBlankTerm[9] = {"        "};
   if (m_siUniquenessKey > 1000)
      m_siUniquenessKey = 1;
   AdvantageMessage::insert(hMessage);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pProcessorAdvice->sTranCode,
        (pProcessorAdvice->sProc - pProcessorAdvice->sTranCode +
         sizeof(pProcessorAdvice->sProc)),
         CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pProcessorAdvice->sTranCode,
        (pProcessorAdvice->sProc - pProcessorAdvice->sTranCode +
         sizeof(pProcessorAdvice->sProc)),
         CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   if (memcmp(pProcessorAdvice->sTerminal,sBlankTerm,8) == 0)
   {
     m_hCutoffSegment.setENTITY_ID(pProcessorAdvice->sProc,6);
     m_hCutoffSegment.setENTITY_TYPE("*P",2);
   }
   else
   {
     m_hCutoffSegment.setENTITY_ID(pProcessorAdvice->sTerminal,8);
     m_hCutoffSegment.setENTITY_TYPE("AT",2);
   }
   m_hCutoffSegment.setCUTOFF_TYPE(pProcessorAdvice->sTranType,2);
   string strTSTAMP_END(NonStopClock::getYYYYMMDDHHMMSShh(pProcessorAdvice->sTimestamp));
   m_hCutoffSegment.setTSTAMP_END(strTSTAMP_END.data(),16);
   m_hCutoffSegment.setDATE_RECON(strTSTAMP_END.data(),8);
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_END.substr(8);
      m_hCutoffSegment.setTSTAMP_END(strTemp.data(),16);
      m_hCutoffSegment.setDATE_RECON(strTemp.data(),8);
   }
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   m_hCutoffSegment.write(&psBuffer);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageProcessorAdvice::insert%3C6188390251.body
}

// Additional Declarations
  //## begin AdvantageProcessorAdvice%3C6133E800AB.declarations preserve=yes
  //## end AdvantageProcessorAdvice%3C6133E800AB.declarations

//## begin module%3C6139C8001F.epilog preserve=yes
//## end module%3C6139C8001F.epilog
