//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A5433E70061.cm preserve=no
//	$Date:   May 08 2020 09:13:24  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%5A5433E70061.cm

//## begin module%5A5433E70061.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A5433E70061.cp

//## Module: CXOSAI41%5A5433E70061; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI41.hpp

#ifndef CXOSAI41_h
#define CXOSAI41_h 1

//## begin module%5A5433E70061.additionalIncludes preserve=no
//## end module%5A5433E70061.additionalIncludes

//## begin module%5A5433E70061.includes preserve=yes
//## end module%5A5433E70061.includes

#ifndef CXOSAI46_h
#include "CXODAI46.hpp"
#endif
#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class KeyRing;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class DateTime;

} // namespace IF

//## begin module%5A5433E70061.declarations preserve=no
//## end module%5A5433E70061.declarations

//## begin module%5A5433E70061.additionalDeclarations preserve=yes
//## end module%5A5433E70061.additionalDeclarations


//## begin APCardMaintenance%5A542E8B00D7.preface preserve=yes
//## end APCardMaintenance%5A542E8B00D7.preface

//## Class: APCardMaintenance%5A542E8B00D7
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5A56923C03C3;IF::DateTime { -> F}
//## Uses: <unnamed>%5EB1BFD101A2;reusable::KeyRing { -> F}

class DllExport APCardMaintenance : public AdvantageMessage  //## Inherits: <unnamed>%5A542E9701B4
{
  //## begin APCardMaintenance%5A542E8B00D7.initialDeclarations preserve=yes
  //## end APCardMaintenance%5A542E8B00D7.initialDeclarations

  public:
    //## Constructors (generated)
      APCardMaintenance();

    //## Destructor (generated)
      virtual ~APCardMaintenance();


    //## Other Operations (specified)
      //## Operation: insert%5A542EA30001
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin APCardMaintenance%5A542E8B00D7.public preserve=yes
      //## end APCardMaintenance%5A542E8B00D7.public

  protected:
    // Additional Protected Declarations
      //## begin APCardMaintenance%5A542E8B00D7.protected preserve=yes
      //## end APCardMaintenance%5A542E8B00D7.protected

  private:
    // Additional Private Declarations
      //## begin APCardMaintenance%5A542E8B00D7.private preserve=yes
      //## end APCardMaintenance%5A542E8B00D7.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5EB1D9BF0183
      //## Role: APCardMaintenance::<m_hAPCardMaintenanceSegment>%5EB1D9C0006E
      //## begin APCardMaintenance::<m_hAPCardMaintenanceSegment>%5EB1D9C0006E.role preserve=no  public: APCardMaintenanceSegment { -> VHgN}
      APCardMaintenanceSegment m_hAPCardMaintenanceSegment;
      //## end APCardMaintenance::<m_hAPCardMaintenanceSegment>%5EB1D9C0006E.role

    // Additional Implementation Declarations
      //## begin APCardMaintenance%5A542E8B00D7.implementation preserve=yes
      //## end APCardMaintenance%5A542E8B00D7.implementation

};

//## begin APCardMaintenance%5A542E8B00D7.postscript preserve=yes
//## end APCardMaintenance%5A542E8B00D7.postscript

//## begin module%5A5433E70061.epilog preserve=yes
//## end module%5A5433E70061.epilog


#endif
