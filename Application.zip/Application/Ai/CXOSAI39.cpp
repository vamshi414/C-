//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A54330200D1.cm preserve=no
//	$Date:   May 20 2021 09:54:48  $ $Author:   E5350313  $
//	$Revision:   1.6  $
//## end module%5A54330200D1.cm

//## begin module%5A54330200D1.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A54330200D1.cp

//## Module: CXOSAI39%5A54330200D1; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI39.cpp

//## begin module%5A54330200D1.additionalIncludes preserve=no
//## end module%5A54330200D1.additionalIncludes

//## begin module%5A54330200D1.includes preserve=yes
//## end module%5A54330200D1.includes

#ifndef CXOSAI39_h
#include "CXODAI39.hpp"
#endif
//## begin module%5A54330200D1.declarations preserve=no
//## end module%5A54330200D1.declarations

//## begin module%5A54330200D1.additionalDeclarations preserve=yes
//## end module%5A54330200D1.additionalDeclarations


// Class TerminalAdmin

TerminalAdmin::TerminalAdmin()
  //## begin TerminalAdmin::TerminalAdmin%5A542C930030_const.hasinit preserve=no
  //## end TerminalAdmin::TerminalAdmin%5A542C930030_const.hasinit
  //## begin TerminalAdmin::TerminalAdmin%5A542C930030_const.initialization preserve=yes
   : AdvantageMessage("0483","A001")
  //## end TerminalAdmin::TerminalAdmin%5A542C930030_const.initialization
{
  //## begin TerminalAdmin::TerminalAdmin%5A542C930030_const.body preserve=yes
   memcpy(m_sID,"AI39",4);
  //## end TerminalAdmin::TerminalAdmin%5A542C930030_const.body
}


TerminalAdmin::~TerminalAdmin()
{
  //## begin TerminalAdmin::~TerminalAdmin%5A542C930030_dest.body preserve=yes
  //## end TerminalAdmin::~TerminalAdmin%5A542C930030_dest.body
}



//## Other Operations (implementation)
bool TerminalAdmin::insert (Message& hMessage)
{
  //## begin TerminalAdmin::insert%5A542CA9039D.body preserve=yes
   UseCase hUseCase("TANDEM","## AI39 READ 0483 TERM ADMIN",false);
   hTerminalAdmin* p = (hTerminalAdmin*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   memset(&p->cACQ_PLAT_PROD_ID,' ',&p->cEnd - &p->cACQ_PLAT_PROD_ID);
   setTSTAMP_TRANS(p->sTimestamp);
   database::UniquenessKey::hash(p->sPAN,16);
   database::UniquenessKey::hash(p->sRetrievalRefNo,12);
   database::UniquenessKey::hash(p->sSysTraceAuditNo,6);
   m_pTransaction->setUNIQUENESS_KEY(database::UniquenessKey::getHash());
   p->cACQ_PLAT_PROD_ID = 'A';
   memcpy(p->sTSTAMP_LOCAL,"20",2);
   memcpy(p->sTSTAMP_LOCAL + 2,p->sDateLocalYYMMDD,12);
   string strFirst(p->sNetTermID,8);
   string strSecond;
   if (ConfigurationRepository::instance()->translate("DEVICE",strFirst,strSecond,"DEV_ADMIN_LOCATOR","INST_ID_RECN_ACQ_B",0))
   {
      strFirst.assign(strSecond.data(),11);
      memcpy(p->sINST_ID_RECN_ACQ_B,strSecond.data(),11);
      if (memcmp(p->sDeviceCurTran,"   ",3) == 0)
         memcpy(p->sDeviceCurTran,ConfigurationRepository::instance()->getThird().data() + 13,3);
      if (ConfigurationRepository::instance()->translate("INSTITUTION",strFirst,strSecond,"DEV_ADMIN_LOCATOR","PROC_ID_ACQ_B",0))
      {
         memcpy(p->sPROC_ID_ACQ_B,strSecond.data(),strSecond.length());
         if (ConfigurationRepository::instance()->translate("PROCESSOR",strSecond,strFirst,"DEV_ADMIN_LOCATOR","PROC_GRP_ID_ACQ_B",0))
            memcpy(p->sPROC_GRP_ID_ACQ_B,strFirst.data(),strFirst.length());
      }
      else
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   }
   else
      ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   memcpy(p->sDATE_RECON_ACQ,"20",2);
   memcpy(p->sDATE_RECON_ACQ + 2,p->sDateReconAcq,6);
   sprintf(p->sBRANCH_ID_ACQ,"%011hd",ntohs(p->iBranchIDAcq));
   if (ntohs(p->iDeviceCurType) == 0)
      p->iDeviceCurType = htons(1);
   ::Template::instance()->map("TERMINALADMIN",(const char*)p);
   char sType[9] = {"01234567"};
   string strToken1("TERMINALCANISTER ");
   for (int i = 0;i <= 7;++i)
   {
      strToken1[16] = sType[i];
      ::Template::instance()->map(strToken1,(const char*)(&p->pCan[i]));
   }
   string strToken2("TERMINALFLAG ");
   for (int i = 0;i <= 3;++i)
   {
      strToken2[12] = sType[i + 1];
      ::Template::instance()->map(strToken2,(const char*)(&p->pFlag[i]));
   }
   return deport(hMessage);
  //## end TerminalAdmin::insert%5A542CA9039D.body
}

// Additional Declarations
  //## begin TerminalAdmin%5A542C930030.declarations preserve=yes
  //## end TerminalAdmin%5A542C930030.declarations

//## begin module%5A54330200D1.epilog preserve=yes
//## end module%5A54330200D1.epilog
