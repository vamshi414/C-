//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3C613A5100AB.cm preserve=no
//    %X% %Q% %Z% %W%
//## end module%3C613A5100AB.cm

//## begin module%3C613A5100AB.cp preserve=no
//  Copyright (c) 1998 - 2004
//  eFunds Corporation
//## end module%3C613A5100AB.cp

//## Module: CXOSAI16%3C613A5100AB; Package body
//## Subsystem: AI%3597E7CC007A
//  .
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXOSAI16.cpp

//## begin module%3C613A5100AB.additionalIncludes preserve=no
//## end module%3C613A5100AB.additionalIncludes

//## begin module%3C613A5100AB.includes preserve=yes
// $Date:   Jan 31 2018 14:07:20  $ $Author:   e1009839  $ $Revision:   1.32  $
#include <stdio.h>
#include "CXODIF11.hpp"
#include "CXODNS29.hpp"
//## end module%3C613A5100AB.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSAI16_h
#include "CXODAI16.hpp"
#endif


//## begin module%3C613A5100AB.declarations preserve=no
//## end module%3C613A5100AB.declarations

//## begin module%3C613A5100AB.additionalDeclarations preserve=yes
//## end module%3C613A5100AB.additionalDeclarations


// Class AdvantageTerminalAdmin

AdvantageTerminalAdmin::AdvantageTerminalAdmin()
  //## begin AdvantageTerminalAdmin::AdvantageTerminalAdmin%3C61342403C8_const.hasinit preserve=no
  //## end AdvantageTerminalAdmin::AdvantageTerminalAdmin%3C61342403C8_const.hasinit
  //## begin AdvantageTerminalAdmin::AdvantageTerminalAdmin%3C61342403C8_const.initialization preserve=yes
   : AdvantageMessage("0483","A001")
  //## end AdvantageTerminalAdmin::AdvantageTerminalAdmin%3C61342403C8_const.initialization
{
  //## begin AdvantageTerminalAdmin::AdvantageTerminalAdmin%3C61342403C8_const.body preserve=yes
   memcpy(m_sID,"AI16",4);
  //## end AdvantageTerminalAdmin::AdvantageTerminalAdmin%3C61342403C8_const.body
}


AdvantageTerminalAdmin::~AdvantageTerminalAdmin()
{
  //## begin AdvantageTerminalAdmin::~AdvantageTerminalAdmin%3C61342403C8_dest.body preserve=yes
  //## end AdvantageTerminalAdmin::~AdvantageTerminalAdmin%3C61342403C8_dest.body
}



//## Other Operations (implementation)
bool AdvantageTerminalAdmin::insert (Message& hMessage)
{
  //## begin AdvantageTerminalAdmin::insert%3C6183BD0399.body preserve=yes
   UseCase hUseCase("TANDEM","## AD26 READ 0483 TERM ADMIN",false);
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   string strHdrTimestamp(NonStopClock::getYYYYMMDDHHMMSShh(pV13AdvantageHeader->sHdrTimestamp1));
   hTerminalAdmin* pTerminalAdmin = (hTerminalAdmin*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   m_hDeviceAdminSegment.reset();
   m_hAuditSegment.reset();
   char sMTI[5] = {"    "};
   char sDate8[9] = {"        "};
   char sDateTime14[15] = {"              "};
   char sCentury[2];
   m_siUniquenessKey += 1;
   if (m_siUniquenessKey > 1000)
      m_siUniquenessKey = 1;
   AdvantageMessage::insert(hMessage);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pTerminalAdmin->sMTI,
         (pTerminalAdmin->sFiller1 - pTerminalAdmin->sMTI +
         sizeof(pTerminalAdmin->sFiller1)),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pTerminalAdmin->sPAN,
         (pTerminalAdmin->sFiller2 - pTerminalAdmin->sPAN +
         sizeof(pTerminalAdmin->sFiller2)),CodeTable::CX_ASCII_TO_EBCDIC);
     for(int i = 0;i < 8;i++)
     {
        CodeTable::translate(pTerminalAdmin->pCan[i].sCanCurCoden,3,CodeTable::CX_ASCII_TO_EBCDIC);
     }
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pTerminalAdmin->sMTI,
         (pTerminalAdmin->sFiller1 - pTerminalAdmin->sMTI +
         sizeof(pTerminalAdmin->sFiller1)),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pTerminalAdmin->sPAN,
         (pTerminalAdmin->sFiller2 - pTerminalAdmin->sPAN +
         sizeof(pTerminalAdmin->sFiller2)),CodeTable::CX_EBCDIC_TO_ASCII);
     for(int i = 0;i < 8;i++)
     {
        CodeTable::translate(pTerminalAdmin->pCan[i].sCanCurCoden,3,CodeTable::CX_EBCDIC_TO_ASCII);
     }
   }
#endif
   if (AdvantageMessageProcessor::instance()->getVersion() == 130)
   {
      hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
      m_hDeviceAdminSegment.setCED_BUILD_NO(ntohl(pV13AdvantageHeader->lCED_BUILD_NO));
   }
   else
      m_hDeviceAdminSegment.setCED_BUILD_NO(0);

   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   string strTSTAMP_TRANS(NonStopClock::getYYYYMMDDHHMMSShh(pTerminalAdmin->sTimestamp));
   if (strTSTAMP_TRANS == "2000000000000000")
      return false;
   m_hDeviceAdminSegment.setTSTAMP_TRANS(strTSTAMP_TRANS.data(),16);

   m_hDeviceAdminSegment.setMTI(pTerminalAdmin->sMTI,4);
   m_hDeviceAdminSegment.setFUNCTION_CODE(pTerminalAdmin->sFunctionCode,3);
   m_hDeviceAdminSegment.setACT_CODE(pTerminalAdmin->sActCode,3);
   m_hDeviceAdminSegment.setMSG_RESON_CODE_ACQ(pTerminalAdmin->sMsgResonCodeAcq,4);
   m_hDeviceAdminSegment.setRETRIEVAL_REF_NO(pTerminalAdmin->sRetrievalRefNo,12);
   m_hDeviceAdminSegment.setSYS_TRACE_AUDIT_NO(pTerminalAdmin->sSysTraceAuditNo,6);

   m_hDeviceAdminSegment.setCARD_ACPT_TERM_ID(pTerminalAdmin->sCardAcptTermID,15);
   m_hDeviceAdminSegment.setCARD_ACPT_ID(pTerminalAdmin->sCardAcptID,15);
   m_hDeviceAdminSegment.setCRD_ACP_NAM_FMTFLG(&pTerminalAdmin->cCrdAcpNamFmtflg,1);
   m_hDeviceAdminSegment.setCARD_ACPT_NAME_LOC(pTerminalAdmin->sCardAcptNameLoc,83);
   m_hDeviceAdminSegment.setCARD_ACPT_REGION(pTerminalAdmin->sCardAcptRegion,3);
   m_hDeviceAdminSegment.setCARD_ACPT_COUNTRY(pTerminalAdmin->sCardAcptCountry,3);
   m_hDeviceAdminSegment.setCARD_ACPT_PST_CODE(pTerminalAdmin->sCardAcptPstCode,10);
   m_hDeviceAdminSegment.setCARD_ACPT_COUNTY(pTerminalAdmin->sCardAcptCounty,3);
   m_hDeviceAdminSegment.setCARD_ACPT_BUS_CODE(pTerminalAdmin->sCardAcptBusCode,4);

   m_hDeviceAdminSegment.setMERCH_TYPE(pTerminalAdmin->sMerchType,4);
   m_hDeviceAdminSegment.setCLERK_ID(pTerminalAdmin->sClerkID,28);
   m_hDeviceAdminSegment.setNET_TERM_ID(pTerminalAdmin->sNetTermID,8);
   string strNetworkTermId(pTerminalAdmin->sNetTermID,8);
   string strDEFAULT_CUR_CODE;

   if (ConfigurationRepository::instance()->translate("DEVICE",
      strNetworkTermId, m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B, "DEV_ADMIN_LOCATOR", "INST_ID_RECN_ACQ_B", 0))
   {
      string strInstIdReconAcq(m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.data(),11);
      string strTemp(m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.substr(11));
      m_hDeviceAdminSegment.setINST_ID_RECN_ACQ_B(strInstIdReconAcq.data(),strInstIdReconAcq.length());
      strDEFAULT_CUR_CODE.assign(ConfigurationRepository::instance()->getThird().data() + 13,3);
      string strProcIdAcq;
      if (ConfigurationRepository::instance()->translate("INSTITUTION",
         strInstIdReconAcq, strProcIdAcq, "DEV_ADMIN_LOCATOR", "PROC_ID_ACQ_B", 0))
      {
         m_hDeviceAdminSegment.setPROC_ID_ACQ_B(strProcIdAcq.data(),strProcIdAcq.length());
         string strProcGrpIdAcq;
         if (ConfigurationRepository::instance()->translate("PROCESSOR",
            strProcIdAcq, strProcGrpIdAcq, "DEV_ADMIN_LOCATOR", "PROC_GRP_ID_ACQ_B", 0))
         {
            m_hDeviceAdminSegment.setPROC_GRP_ID_ACQ_B(strProcGrpIdAcq.data(),strProcGrpIdAcq.length());
         }
      }
      else
      {
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
      }
   }
   else
   {
      ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   }
   if ((ConfigurationRepository::instance()->isSubscriber(m_hDeviceAdminSegment.zINST_ID_RECN_ACQ_B(),""))== "X")
   {
/*      Trace::put(__FILE__,__LINE__,"not keeping",-1); */
      return false;
   }
   else
   {
/*      Trace::put(__FILE__,__LINE__,"keeping",-1); */
/*      Trace::put(ConfigurationRepository::instance()->getSUBSCRIBER_IND().data(),ConfigurationRepository::instance()->getSUBSCRIBER_IND().length());*/
      m_hDeviceAdminSegment.setSUBSCRIBER_IND(ConfigurationRepository::instance()->getSUBSCRIBER_IND().data(), 1);
   }

   DateTime::calcCentury(pTerminalAdmin->sDateReconAcq,sCentury);
   memcpy( sDate8, sCentury,2);
   memcpy( sDate8+2, pTerminalAdmin->sDateReconAcq,6);
   m_hDeviceAdminSegment.setDATE_RECON_ACQ(sDate8,8);
   DateTime::calcCentury(pTerminalAdmin->sDateLocalYYMMDD,sCentury);
   memcpy( sDateTime14, sCentury,2);
   memcpy( sDateTime14+2, pTerminalAdmin->sDateLocalYYMMDD,6);
   memcpy( sDateTime14+8, pTerminalAdmin->sTimeLocalHRMNSC,6);
   m_hDeviceAdminSegment.setTSTAMP_LOCAL(sDateTime14,14);
   m_hDeviceAdminSegment.setCOUNTRY_ACQ_INST(pTerminalAdmin->sCountryAcqInst,3);
   reformatInstId(pTerminalAdmin->sInstIDAcq);
   m_hDeviceAdminSegment.setINST_ID_ACQ(m_sStdInstId,11);
   m_hDeviceAdminSegment.setNET_ID_ACQ(pTerminalAdmin->sNetIDAcq,3);
   m_hDeviceAdminSegment.setRECON_IND_ACQ(pTerminalAdmin->sReconIndAcq,3);
   reformatInstId(pTerminalAdmin->sInstIDReconAcq);
   m_hDeviceAdminSegment.setINST_ID_RECON_ACQ(m_sStdInstId,11);
   m_hDeviceAdminSegment.setPROC_ID_ACQ(pTerminalAdmin->sProcIDAcq,6);
   char szTemp[12];
   sprintf(szTemp,"%11hd",ntohs(pTerminalAdmin->iBranchIDAcq));
   m_hDeviceAdminSegment.setBRANCH_ID_ACQ(szTemp,11);
   if (Customer::instance()->getTest())
      memcpy(pTerminalAdmin->sPAN + 6,"999999",6);
   m_hDeviceAdminSegment.setPAN(pTerminalAdmin->sPAN,28);
   m_hDeviceAdminSegment.setTERM_CLASS(pTerminalAdmin->sTermClass,2);
   m_hDeviceAdminSegment.setREQUEST_DATE(pTerminalAdmin->sRequestDate,4);
   m_hDeviceAdminSegment.setREQUEST_TIME(pTerminalAdmin->sRequestTime,6);

   m_hDeviceAdminSegment.setDEVICE_CUR_TRAN(pTerminalAdmin->sDeviceCurTran,3);
   if ( (m_hDeviceAdminSegment.getDEVICE_CUR_TRAN() == (const char*)"   ") && (strDEFAULT_CUR_CODE.length() > 0))
      m_hDeviceAdminSegment.setDEVICE_CUR_TRAN(strDEFAULT_CUR_CODE);
   else
      m_hDeviceAdminSegment.setDEVICE_CUR_TRAN(Customer::instance()->getCUST_CURRENCY_CODE().data(),Customer::instance()->getCUST_CURRENCY_CODE().length());
   m_hDeviceAdminSegment.setDEVICE_CUR_TYPE(ntohs(pTerminalAdmin->iDeviceCurType));
   if (m_hDeviceAdminSegment.getDEVICE_CUR_TYPE() == 0)
      m_hDeviceAdminSegment.setDEVICE_CUR_TYPE(1);
   double dAmt = Segment::lltof(ntohl(pTerminalAdmin->lDeviceAmt[0]),ntohl(pTerminalAdmin->lDeviceAmt[1]));
   m_hDeviceAdminSegment.setDEVICE_AMT(dAmt);
   for (int j = 0;j < 8;j++)
   {
      m_hDeviceAdminSegment.setCAN_CUR_CODEn(pTerminalAdmin->pCan[j].sCanCurCoden,3,j);
      if (memcmp(m_hDeviceAdminSegment.zCAN_CUR_CODEn(j),"   ",3) == 0)
      {
         if (strDEFAULT_CUR_CODE.length() >= 3)
            m_hDeviceAdminSegment.setCAN_CUR_CODEn(strDEFAULT_CUR_CODE.data(),3,j);
         else
            m_hDeviceAdminSegment.setCAN_CUR_CODEn(Customer::instance()->getCUST_CURRENCY_CODE().data(),Customer::instance()->getCUST_CURRENCY_CODE().length(),j);
      }
      m_hDeviceAdminSegment.setCAN_CUR_TYPEn(ntohs(pTerminalAdmin->pCan[j].iCanCurTypen),j);
      if (m_hDeviceAdminSegment.getCAN_CUR_TYPEn(j) == 0)
         m_hDeviceAdminSegment.setCAN_CUR_TYPEn(1,j);
      m_hDeviceAdminSegment.setCAN_ITEM_VALUEn(ntohl(pTerminalAdmin->pCan[j].lCanItemValuen),j);
      m_hDeviceAdminSegment.setCAN_ITEM_COUNTn(ntohl(pTerminalAdmin->pCan[j].lCanItemCountn),j);
      dAmt = Segment::lltof(ntohl(pTerminalAdmin->pCan[j].lCanItemAmtn[0]),ntohl(pTerminalAdmin->pCan[j].lCanItemAmtn[1]));
      m_hDeviceAdminSegment.setCAN_ITEM_AMTn(dAmt,j);
   }
   for(int k = 0; k<=3; k++)
   {
      m_hDeviceAdminSegment.setPROC_FLGSn(pTerminalAdmin->pFlag[k].sProcFlgsn,2,k);
   }
   m_hDeviceAdminSegment.setUNIQUENESS_KEY(m_siUniquenessKey);
   m_hDeviceAdminSegment.setACQ_PLAT_PROD_ID("A",1);
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      m_hDeviceAdminSegment.setTSTAMP_TRANS(strTemp.data(),16);
      m_hDeviceAdminSegment.setDATE_RECON_ACQ(strTemp.data(),8);
   }
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   string strTemp((char*) m_hDeviceAdminSegment.zTSTAMP_TRANS());
   if (strTemp == "0000000000000000")
       strTemp = strHdrTimestamp;
   m_hDeviceAdminSegment.setTSTAMP_TRANS(strTemp.data(),strTemp.length());
   m_hDeviceAdminSegment.write(&psBuffer);
   ConfigurationRepository::instance()->write(&psBuffer,strTemp,m_hDeviceAdminSegment.getUNIQUENESS_KEY());
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageTerminalAdmin::insert%3C6183BD0399.body
}

// Additional Declarations
  //## begin AdvantageTerminalAdmin%3C61342403C8.declarations preserve=yes
  //## end AdvantageTerminalAdmin%3C61342403C8.declarations

//## begin module%3C613A5100AB.epilog preserve=yes
//## end module%3C613A5100AB.epilog
