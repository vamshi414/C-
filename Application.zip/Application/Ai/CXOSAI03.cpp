//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3C613685035B.cm preserve=no
//	$Date:   Jun 21 2017 08:57:52  $ $Author:   e1009839  $
//	$Revision:   1.35  $
//## end module%3C613685035B.cm

//## begin module%3C613685035B.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%3C613685035B.cp

//## Module: CXOSAI03%3C613685035B; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXOSAI03.cpp

//## begin module%3C613685035B.additionalIncludes preserve=no
//## end module%3C613685035B.additionalIncludes

//## begin module%3C613685035B.includes preserve=yes
// $Date:   Jun 21 2017 08:57:52  $ $Author:   e1009839  $ $Revision:   1.35  $
#include "CXODIF03.hpp"
#include "CXODIF11.hpp"
#include "CXODNS29.hpp"
#include "CXODRU37.hpp"
//## end module%3C613685035B.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSAI03_h
#include "CXODAI03.hpp"
#endif


//## begin module%3C613685035B.declarations preserve=no
//## end module%3C613685035B.declarations

//## begin module%3C613685035B.additionalDeclarations preserve=yes
#define FIELDS301Old 15
struct hFraudMaintenance301Old* phFraudMaintenance301Old = 0;
Fields hFraudMaintenance301Old_Fields[FIELDS301Old + 1] =
{
     "t         ","",offsetof(hFraudMaintenance301Old,sUpdtTstamp),sizeof(phFraudMaintenance301Old->sUpdtTstamp),
	  "t         ","",offsetof(hFraudMaintenance301Old,sMntTstamp),sizeof(phFraudMaintenance301Old->sMntTstamp),
	  "a         ","",offsetof(hFraudMaintenance301Old,sRndmSeqNbr),sizeof(phFraudMaintenance301Old->sRndmSeqNbr),
	  "a         ","",offsetof(hFraudMaintenance301Old,sCustSince),sizeof(phFraudMaintenance301Old->sCustSince),
	  "a         ","",offsetof(hFraudMaintenance301Old,sAlrtEvntDate),sizeof(phFraudMaintenance301Old->sAlrtEvntDate),
	  "a         ","",offsetof(hFraudMaintenance301Old,sAlrtEvntLtd),sizeof(phFraudMaintenance301Old->sAlrtEvntLtd),
	  "t         ","",offsetof(hFraudMaintenance301Old,sSchdBlockDate),sizeof(phFraudMaintenance301Old->sSchdBlockDate),
	  "a         ","",offsetof(hFraudMaintenance301Old,cSevLvl),sizeof(phFraudMaintenance301Old->cSevLvl),
	  "a         ","",offsetof(hFraudMaintenance301Old,sAlrtEvntNum),sizeof(phFraudMaintenance301Old->sAlrtEvntNum),
	  "o         ","",offsetof(hFraudMaintenance301Old,cFiller),sizeof(phFraudMaintenance301Old->cFiller),
	  "a         ","",offsetof(hFraudMaintenance301Old,cVipIndicator),sizeof(phFraudMaintenance301Old->cVipIndicator),
	  "a         ","",offsetof(hFraudMaintenance301Old,cTravelIndicator),sizeof(phFraudMaintenance301Old->cTravelIndicator),
	  "a         ","",offsetof(hFraudMaintenance301Old,sTravelStartDate),sizeof(phFraudMaintenance301Old->sTravelStartDate),
	  "a         ","",offsetof(hFraudMaintenance301Old,sTravelEndDate),sizeof(phFraudMaintenance301Old->sTravelEndDate),
	  "o         ","",offsetof(hFraudMaintenance301Old,sFillerA),sizeof(phFraudMaintenance301Old->sFillerA),
	  "~","",0,sizeof(hFraudMaintenance301Old),
};
#define FIELDS301New 15
struct hFraudMaintenance301New* phFraudMaintenance301New = 0;
Fields hFraudMaintenance301New_Fields[FIELDS301New + 1] =
{
     "t         ","",offsetof(hFraudMaintenance301New,sUpdtTstamp),sizeof(phFraudMaintenance301New->sUpdtTstamp),
	  "t         ","",offsetof(hFraudMaintenance301New,sMntTstamp),sizeof(phFraudMaintenance301New->sMntTstamp),
	  "a         ","",offsetof(hFraudMaintenance301New,sRndmSeqNbr),sizeof(phFraudMaintenance301New->sRndmSeqNbr),
	  "a         ","",offsetof(hFraudMaintenance301New,sCustSince),sizeof(phFraudMaintenance301New->sCustSince),
	  "a         ","",offsetof(hFraudMaintenance301New,sAlrtEvntDate),sizeof(phFraudMaintenance301New->sAlrtEvntDate),
	  "a         ","",offsetof(hFraudMaintenance301New,sAlrtEvntLtd),sizeof(phFraudMaintenance301New->sAlrtEvntLtd),
	  "t         ","",offsetof(hFraudMaintenance301New,sSchdBlockDate),sizeof(phFraudMaintenance301New->sSchdBlockDate),
	  "a         ","",offsetof(hFraudMaintenance301New,cSevLvl),sizeof(phFraudMaintenance301New->cSevLvl),
	  "a         ","",offsetof(hFraudMaintenance301New,sAlrtEvntNum),sizeof(phFraudMaintenance301New->sAlrtEvntNum),
	  "o         ","",offsetof(hFraudMaintenance301New,cFiller),sizeof(phFraudMaintenance301New->cFiller),
	  "a         ","",offsetof(hFraudMaintenance301New,cVipIndicator),sizeof(phFraudMaintenance301New->cVipIndicator),
	  "a         ","",offsetof(hFraudMaintenance301New,cTravelIndicator),sizeof(phFraudMaintenance301New->cTravelIndicator),
	  "a         ","",offsetof(hFraudMaintenance301New,sTravelStartDate),sizeof(phFraudMaintenance301New->sTravelStartDate),
	  "a         ","",offsetof(hFraudMaintenance301New,sTravelEndDate),sizeof(phFraudMaintenance301New->sTravelEndDate),
	  "o         ","",offsetof(hFraudMaintenance301New,sFillerA),sizeof(phFraudMaintenance301New->sFillerA),
      "~","",0,sizeof(hFraudMaintenance301New),
};
#define FIELDS302Old 4
struct hFraudMaintenance302Old* phFraudMaintenance302Old = 0;
Fields hFraudMaintenance302Old_Fields[FIELDS302Old + 1] =
{
     "o         ","",offsetof(hFraudMaintenance302Old,sObsolete),sizeof(phFraudMaintenance302Old->sObsolete),
	  "t         ","",offsetof(hFraudMaintenance302Old,sLastAddrChg),sizeof(phFraudMaintenance302Old->sLastAddrChg),
	  "t         ","",offsetof(hFraudMaintenance302Old,sLastpinChg),sizeof(phFraudMaintenance302Old->sLastpinChg),
	  "o         ","",offsetof(hFraudMaintenance302Old,sObsolete1),sizeof(phFraudMaintenance302Old->sObsolete1),
	  "~","",0,sizeof(hFraudMaintenance302Old),
};
#define FIELDS302New 22
struct hFraudMaintenance302New* phFraudMaintenance302New = 0;
Fields hFraudMaintenance302New_Fields[FIELDS302New + 1] =
{
     "o         ","",offsetof(hFraudMaintenance302New,sObsolete),sizeof(phFraudMaintenance302New->sObsolete),
	  "t         ","",offsetof(hFraudMaintenance302New,sLastAddrChg),sizeof(phFraudMaintenance302New->sLastAddrChg),
	  "t         ","",offsetof(hFraudMaintenance302New,sLastpinChg),sizeof(phFraudMaintenance302New->sLastpinChg),
	  "o         ","",offsetof(hFraudMaintenance302New,sObsolete1),sizeof(phFraudMaintenance302New->sObsolete1),
	  "~","",0,sizeof(hFraudMaintenance302New),
};
#define FIELDS303Old 7
struct hFraudMaintenance303Old* phFraudMaintenance303Old = 0;
Fields hFraudMaintenance303Old_Fields[FIELDS303Old + 1] =
{
     "a         ","",offsetof(hFraudMaintenance303Old,sWorkphone),sizeof(phFraudMaintenance303Old->sWorkphone),
	  "a         ","",offsetof(hFraudMaintenance303Old,sDateOfBirth),sizeof(phFraudMaintenance303Old->sDateOfBirth),
	  "a         ","",offsetof(hFraudMaintenance303Old,sSocSecNum),sizeof(phFraudMaintenance303Old->sSocSecNum),
	  "a         ","",offsetof(hFraudMaintenance303Old,sMaidenName),sizeof(phFraudMaintenance303Old->sMaidenName),
	  "a         ","",offsetof(hFraudMaintenance303Old,sUserValidation),sizeof(phFraudMaintenance303Old->sUserValidation),
	  "a         ","",offsetof(hFraudMaintenance303Old,sMemberNum),sizeof(phFraudMaintenance303Old->sMemberNum),
	  "o         ","",offsetof(hFraudMaintenance303Old,sFillerA),sizeof(phFraudMaintenance303Old->sFillerA),
      "~","",0,sizeof(hFraudMaintenance303Old),
};
#define FIELDS303New 7
struct hFraudMaintenance303New* phFraudMaintenance303New = 0;
Fields hFraudMaintenance303New_Fields[FIELDS303New + 1] =
{
     "a         ","",offsetof(hFraudMaintenance303New,sWorkphone),sizeof(phFraudMaintenance303New->sWorkphone),
	  "a         ","",offsetof(hFraudMaintenance303New,sDateOfBirth),sizeof(phFraudMaintenance303New->sDateOfBirth),
	  "a         ","",offsetof(hFraudMaintenance303New,sSocSecNum),sizeof(phFraudMaintenance303New->sSocSecNum),
	  "a         ","",offsetof(hFraudMaintenance303New,sMaidenName),sizeof(phFraudMaintenance303New->sMaidenName),
	  "a         ","",offsetof(hFraudMaintenance303New,sUserValidation),sizeof(phFraudMaintenance303New->sUserValidation),
	  "a         ","",offsetof(hFraudMaintenance303New,sMemberNum),sizeof(phFraudMaintenance303New->sMemberNum),
	  "o         ","",offsetof(hFraudMaintenance303New,sFillerA),sizeof(phFraudMaintenance303New->sFillerA),
      "~","",0,sizeof(hFraudMaintenance303New),
};

#define FIELDS304Old 3
struct hFraudMaintenance304Old* phFraudMaintenance304Old = 0;
Fields hFraudMaintenance304Old_Fields[FIELDS304Old + 1] =
{
     "t         ","",offsetof(hFraudMaintenance304Old,sCaseChgd),sizeof(phFraudMaintenance304Old->sCaseChgd),
	  "a         ","",offsetof(hFraudMaintenance304Old,sCaseText),sizeof(phFraudMaintenance304Old->sCaseText),
	  "o         ","",offsetof(hFraudMaintenance304Old,sFiller),sizeof(phFraudMaintenance304Old->sFiller),
	  "~","",0,sizeof(hFraudMaintenance304Old),
};
#define FIELDS304New 3
struct hFraudMaintenance304New* phFraudMaintenance304New = 0;
Fields hFraudMaintenance304New_Fields[FIELDS304New + 1] =
{
     "t         ","",offsetof(hFraudMaintenance304New,sCaseChgd),sizeof(phFraudMaintenance304New->sCaseChgd),
	  "a         ","",offsetof(hFraudMaintenance304New,sCaseText),sizeof(phFraudMaintenance304New->sCaseText),
	  "o         ","",offsetof(hFraudMaintenance304New,sFiller),sizeof(phFraudMaintenance304New->sFiller),
      "~","",0,sizeof(hFraudMaintenance304New),
};

//## end module%3C613685035B.additionalDeclarations


// Class AdvantageAPFraudMaintenance

AdvantageAPFraudMaintenance::AdvantageAPFraudMaintenance()
  //## begin AdvantageAPFraudMaintenance::AdvantageAPFraudMaintenance%3C6131B30203_const.hasinit preserve=no
  //## end AdvantageAPFraudMaintenance::AdvantageAPFraudMaintenance%3C6131B30203_const.hasinit
  //## begin AdvantageAPFraudMaintenance::AdvantageAPFraudMaintenance%3C6131B30203_const.initialization preserve=yes
   : AdvantageMessage("0880","F001")
  //## end AdvantageAPFraudMaintenance::AdvantageAPFraudMaintenance%3C6131B30203_const.initialization
{
  //## begin AdvantageAPFraudMaintenance::AdvantageAPFraudMaintenance%3C6131B30203_const.body preserve=yes
   memcpy(m_sID,"AI03",4);
   m_hFraudMaintenance.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("FR01"),make_pair(&hFraudMaintenance301Old_Fields[0],&hFraudMaintenance301New_Fields[0])));
   m_hFraudMaintenance.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("FR02"),make_pair(&hFraudMaintenance302Old_Fields[0],&hFraudMaintenance302New_Fields[0])));
   m_hFraudMaintenance.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("FR03"),make_pair(&hFraudMaintenance303Old_Fields[0],&hFraudMaintenance303New_Fields[0])));

  //## end AdvantageAPFraudMaintenance::AdvantageAPFraudMaintenance%3C6131B30203_const.body
}


AdvantageAPFraudMaintenance::~AdvantageAPFraudMaintenance()
{
  //## begin AdvantageAPFraudMaintenance::~AdvantageAPFraudMaintenance%3C6131B30203_dest.body preserve=yes
  //## end AdvantageAPFraudMaintenance::~AdvantageAPFraudMaintenance%3C6131B30203_dest.body
}



//## Other Operations (implementation)
bool AdvantageAPFraudMaintenance::insert (IF::Message& hMessage)
{
  //## begin AdvantageAPFraudMaintenance::insert%3C618F2B00CB.body preserve=yes
   UseCase hUseCase("TANDEM","## AD13 READ 0880 FRAUD MAINT",false);
   m_hAuditMaintSegment.reset();
   m_hAuditSegment.reset();
   AdvantageMessage::insert(hMessage);
   hV13AdvantageHeader* pAdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   char* pStart = hMessage.data() + sizeof(hV13AdvantageHeader);
   hFraudMaintenance* pFraudMaintenance = (hFraudMaintenance*)(pStart);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pFraudMaintenance->sRecType,((char*)(&pFraudMaintenance->siStepNo)-pFraudMaintenance->sRecType),
      CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pFraudMaintenance->sSourceId,(pFraudMaintenance->sPlasticNo - pFraudMaintenance->sSourceId + sizeof(pFraudMaintenance->sPlasticNo)),
      CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pFraudMaintenance->sRecType,((char*)(&pFraudMaintenance->siStepNo)-pFraudMaintenance->sRecType),
      CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pFraudMaintenance->sSourceId,(pFraudMaintenance->sPlasticNo - pFraudMaintenance->sSourceId + sizeof(pFraudMaintenance->sPlasticNo)),
      CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   m_hAuditMaintSegment.setRECORD_TYPE(pFraudMaintenance->sRecType,4);
   if(pFraudMaintenance->sFRDABA[10] != ' ')
      m_hAuditMaintSegment.setINST_ID(pFraudMaintenance->sFRDABA+1,9);
   else
      m_hAuditMaintSegment.setINST_ID(pFraudMaintenance->sFRDABA,9);
   char szBusinessKey[26];
   memcpy(szBusinessKey,pFraudMaintenance->sCardGroup,6);
   memcpy(szBusinessKey+6,"~",1);
   KeyRing::instance()->tokenize(pFraudMaintenance->sPan,19);
   memcpy(szBusinessKey+7,pFraudMaintenance->sPan,19);
   m_hAuditMaintSegment.setBUSINESS_KEY(szBusinessKey,26);
   switch (ntohs(pFraudMaintenance->siStepNo))
   {
   case 5:
      m_hAuditMaintSegment.setRECORD_ACTION("A",1);
      break;
   case 6:
      m_hAuditMaintSegment.setRECORD_ACTION("D",1);
      break;
   case 8:
      m_hAuditMaintSegment.setRECORD_ACTION("C",1);
      break;
   default:
      m_hAuditMaintSegment.setRECORD_ACTION("U",1);
      break;
   }
   m_hAuditMaintSegment.setSOURCE_ID(pFraudMaintenance->sSourceId,16);
   m_hAuditMaintSegment.setTERM_ID(pFraudMaintenance->sCrtTermIdent,16);
   char* pFormatOld = m_hAuditMaintSegment.zOLD_VALUE();
   char* pFormatNew = m_hAuditMaintSegment.zNEW_VALUE();
   int ilen = 0;
   string strRecType(pFraudMaintenance->sRecType,4);
   map<string,pair<Fields*,Fields*>,less<string> >::iterator p = m_hFraudMaintenance.find(strRecType);
   if(p != m_hFraudMaintenance.end())
   {
      m_hAuditMaintSegment.setField((*p).second.first,'~',pStart + sizeof(hFraudMaintenance),ilen,&pFormatOld,AdvantageMessageProcessor::instance()->getAsciiInput());
      m_hAuditMaintSegment.setField((*p).second.second,'~',pStart + sizeof(hFraudMaintenance)+ ilen,ilen,&pFormatNew,AdvantageMessageProcessor::instance()->getAsciiInput());
   }
   char sDateTime16[17] = {"                "};
   char sCentury[2];
   DateTime::calcCentury(pFraudMaintenance->sTimeStamp,sCentury);
   memcpy(sDateTime16,sCentury,2);
   memcpy(sDateTime16+2,pFraudMaintenance->sTimeStamp,14);
   string strTSTAMP_TRANS(sDateTime16,16);
   m_hAuditMaintSegment.setTSTAMP_TRANS(strTSTAMP_TRANS.data(),strTSTAMP_TRANS.length());
   if (getTestDate().length())
   {
      string strTemp(getTestDate());
      strTemp +=strTSTAMP_TRANS.substr(8);
      m_hAuditMaintSegment.setTSTAMP_TRANS(strTemp.data(),16);
   }
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_lTstampHash = ntohl(pAdvantageHeader->lHdrTstamp2Hash);
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   m_hAuditMaintSegment.write(&psBuffer);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageAPFraudMaintenance::insert%3C618F2B00CB.body
}

// Additional Declarations
  //## begin AdvantageAPFraudMaintenance%3C6131B30203.declarations preserve=yes
  //## end AdvantageAPFraudMaintenance%3C6131B30203.declarations

//## begin module%3C613685035B.epilog preserve=yes
//## end module%3C613685035B.epilog
