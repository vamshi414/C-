//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6214E83000F4.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%6214E83000F4.cm

//## begin module%6214E83000F4.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%6214E83000F4.cp

//## Module: CXOSAI51%6214E83000F4; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Ai\CXODAI51.hpp

#ifndef CXOSAI51_h
#define CXOSAI51_h 1

//## begin module%6214E83000F4.additionalIncludes preserve=no
//## end module%6214E83000F4.additionalIncludes

//## begin module%6214E83000F4.includes preserve=yes
//## end module%6214E83000F4.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialExceptionSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class AdvantageMessageProcessor;
//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
} // namespace IF

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%6214E83000F4.declarations preserve=no
//## end module%6214E83000F4.declarations

//## begin module%6214E83000F4.additionalDeclarations preserve=yes
//## end module%6214E83000F4.additionalDeclarations


//## begin Advantage0466Exception%6214DD650112.preface preserve=yes
//## end Advantage0466Exception%6214DD650112.preface

//## Class: Advantage0466Exception%6214DD650112
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%6214E2CD002B;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%6214E3020378;repositorysegment::FinancialExceptionSegment { -> F}
//## Uses: <unnamed>%6214E34B0273;monitor::UseCase { -> F}
//## Uses: <unnamed>%6214E3790337;process::Application { -> F}
//## Uses: <unnamed>%6214E399002D;IF::CodeTable { -> F}
//## Uses: <unnamed>%6214E3F4002B;IF::Message { -> F}
//## Uses: <unnamed>%6214E41A0065;AdvantageMessageProcessor { -> F}

class DllExport Advantage0466Exception : public AdvantageMessage  //## Inherits: <unnamed>%6214DD980359
{
  //## begin Advantage0466Exception%6214DD650112.initialDeclarations preserve=yes
  //## end Advantage0466Exception%6214DD650112.initialDeclarations

  public:
    //## Constructors (generated)
      Advantage0466Exception();

    //## Destructor (generated)
      virtual ~Advantage0466Exception();


    //## Other Operations (specified)
      //## Operation: insert%6214E4D10046
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin Advantage0466Exception%6214DD650112.public preserve=yes
      //## end Advantage0466Exception%6214DD650112.public

  protected:
    // Additional Protected Declarations
      //## begin Advantage0466Exception%6214DD650112.protected preserve=yes
      //## end Advantage0466Exception%6214DD650112.protected

  private:
    // Additional Private Declarations
      //## begin Advantage0466Exception%6214DD650112.private preserve=yes
      //## end Advantage0466Exception%6214DD650112.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin Advantage0466Exception%6214DD650112.implementation preserve=yes
      //## end Advantage0466Exception%6214DD650112.implementation

};

//## begin Advantage0466Exception%6214DD650112.postscript preserve=yes
//## end Advantage0466Exception%6214DD650112.postscript

//## begin module%6214E83000F4.epilog preserve=yes
//## end module%6214E83000F4.epilog


#endif
