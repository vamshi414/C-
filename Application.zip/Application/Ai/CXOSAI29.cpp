//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A53E1BF010B.cm preserve=no
//	$Date:   May 20 2021 09:45:22  $ $Author:   E5350313  $
//	$Revision:   1.3  $
//## end module%5A53E1BF010B.cm

//## begin module%5A53E1BF010B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A53E1BF010B.cp

//## Module: CXOSAI29%5A53E1BF010B; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI29.cpp

//## begin module%5A53E1BF010B.additionalIncludes preserve=no
//## end module%5A53E1BF010B.additionalIncludes

//## begin module%5A53E1BF010B.includes preserve=yes
//## end module%5A53E1BF010B.includes

#ifndef CXOSAI29_h
#include "CXODAI29.hpp"
#endif
//## begin module%5A53E1BF010B.declarations preserve=no
//## end module%5A53E1BF010B.declarations

//## begin module%5A53E1BF010B.additionalDeclarations preserve=yes
//## end module%5A53E1BF010B.additionalDeclarations


// Class SettledAdjustment 

SettledAdjustment::SettledAdjustment()
  //## begin SettledAdjustment::SettledAdjustment%5A53DC6E0156_const.hasinit preserve=no
  //## end SettledAdjustment::SettledAdjustment%5A53DC6E0156_const.hasinit
  //## begin SettledAdjustment::SettledAdjustment%5A53DC6E0156_const.initialization preserve=yes
   : AdvantageMessage("0410","S200")
  //## end SettledAdjustment::SettledAdjustment%5A53DC6E0156_const.initialization
{
  //## begin SettledAdjustment::SettledAdjustment%5A53DC6E0156_const.body preserve=yes
  //## end SettledAdjustment::SettledAdjustment%5A53DC6E0156_const.body
}


SettledAdjustment::~SettledAdjustment()
{
  //## begin SettledAdjustment::~SettledAdjustment%5A53DC6E0156_dest.body preserve=yes
  //## end SettledAdjustment::~SettledAdjustment%5A53DC6E0156_dest.body
}



//## Other Operations (implementation)
bool SettledAdjustment::insert (Message& hMessage)
{
  //## begin SettledAdjustment::insert%5A53E1760302.body preserve=yes
   UseCase hUseCase("TANDEM","## AI29 READ 0410 SETTLED",false);
   hAdjustment* p = (hAdjustment*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   setTSTAMP_TRANS(pV13AdvantageHeader->sFiller);
   database::UniquenessKey::hash(p->sPan,16);
   database::UniquenessKey::hash(p->sTermRef,12);
   database::UniquenessKey::hash(p->sTraceNo,6);
   m_pTransaction->setUNIQUENESS_KEY(database::UniquenessKey::getHash());
   ::Template::instance()->map("SETTLEDADJUSTMENT",(const char*)p);
   return deport(hMessage);
  //## end SettledAdjustment::insert%5A53E1760302.body
}

// Additional Declarations
  //## begin SettledAdjustment%5A53DC6E0156.declarations preserve=yes
  //## end SettledAdjustment%5A53DC6E0156.declarations

//## begin module%5A53E1BF010B.epilog preserve=yes
//## end module%5A53E1BF010B.epilog
