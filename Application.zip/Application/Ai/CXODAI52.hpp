strNET_TERM_ID.assign(m_pFinancialBaseSegment->zCARD_ACPT_TERM_ID(),8);
m_pFinancialBaseSegment->setNET_TERM_ID(strNET_TERM_ID.data(),8);
m_pFinancialBaseSegment->setRPT_LVL_ID_B(pFinancialSeg1->sCardAcptId,15);
reformatInstId(pFinancialSeg1->sRptInstIdIssr);
string strINST_ID_RECON_ISS(m_sStdInstId, 11);
string strNETWORK_ID;
if (ConfigurationRepository::instance()->translate("NET_ID_CODE", strINST_ID_RECON_ISS, strNETWORK_ID, "", "", -1, false))
   m_pFinancialBaseSegment->setNET_ID_ISS(strNETWORK_ID.data(), strNETWORK_ID.length());
string strSecond;
string strTSTAMP_LOCAL(pFinancialSeg1->sTimeLocalHRMNSC, 6);
strTSTAMP_LOCAL.resize(8, '0');
Date hDate(Date::today());
if (ConfigurationRepository::instance()->translate("MRCHSTLTIME", m_pFinancialBaseSegment->zRPT_LVL_ID_B(), strSecond, "", "", -1, false))
   m_pFinancialUserSegment->setDATE_ACTION((strTSTAMP_LOCAL >= strSecond ? (hDate + 1).asString("%Y%m%d").c_str() : hDate.asString("%Y%m%d").c_str()), 8);
if (strChannel == "CBACNP")
{
   if (ConfigurationRepository::instance()->translate("REPORTING_LVL", m_pFinancialBaseSegment->zRPT_LVL_ID_B(), strSecond, "FIN_LOCATOR", "RPT_LVL_ID"))
   {
      string strINST_ID_RECON_ACQ_B(ConfigurationRepository::instance()->getThird());
      m_pFinancialBaseSegment->setINST_ID_RECN_ACQ_B(strINST_ID_RECON_ACQ_B.data(), strINST_ID_RECON_ACQ_B.length());
      string strPROC_ID_ACQ_B;
      if (ConfigurationRepository::instance()->translate("INSTITUTION", strINST_ID_RECON_ACQ_B, strPROC_ID_ACQ_B, "FIN_LOCATOR", "PROC_ID_ACQ_B", 0))
      {
         m_pFinancialBaseSegment->setPROC_ID_ACQ_B(strPROC_ID_ACQ_B.data(), strPROC_ID_ACQ_B.length());
         string strPROC_GRP_ID_ACQ_B;
         if (ConfigurationRepository::instance()->translate("PROCESSOR", strPROC_ID_ACQ_B, strPROC_GRP_ID_ACQ_B, "FIN_LOCATOR", "PROC_GRP_ID_ACQ_B", 0))
            m_pFinancialBaseSegment->setPROC_GRP_ID_ACQ_B(strPROC_GRP_ID_ACQ_B.data(), strPROC_GRP_ID_ACQ_B.length());
      }
      else
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   }
   else
   {
      EvidenceSegment hEvidenceSegment;
      hEvidenceSegment.setSUSPECT_TABLE("REPORTING_LVL");
      hEvidenceSegment.setPROBLEM_TABLE("FIN_LOCATOR");
      hEvidenceSegment.setPROBLEM_COLUMN("RPT_LVL_ID");
      string strSOURCE_VALUE(string(m_pFinancialBaseSegment->zRPT_LVL_ID_B(), 15).c_str());
      hEvidenceSegment.setSOURCE_VALUE(strSOURCE_VALUE.c_str());
      hEvidenceSegment.setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
      ConfigurationRepository::instance()->addEvidenceSegment(hEvidenceSegment);
   }

   string strINST_ID_ISS(m_pFinancialBaseSegment->zINST_ID_ISS());
   string strINST_ID_RECN_ISS_B;
   if (ConfigurationRepository::instance()->mapItem("X_INST_ID_RECON", strINST_ID_RECON_ISS, strINST_ID_ISS, "I", strINST_ID_RECN_ISS_B))
   {
      string strPROC_ID_ISS_B;
      if (ConfigurationRepository::instance()->translate("INSTITUTION", strINST_ID_RECN_ISS_B, strPROC_ID_ISS_B, "FIN_LOCATOR", "PROC_ID_ISS_B", 0, false)
         && strPROC_ID_ISS_B == "EFTPOS" && m_pFinancialBaseSegment->zFUNC_CODE()[0] == '1')
         {
            m_pFinancialBaseSegment->setFUNC_CODE("200", 3);
            m_cClass = '2';
         }
   }
}