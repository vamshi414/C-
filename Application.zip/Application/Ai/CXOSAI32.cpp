//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A541FFD01DF.cm preserve=no
//	$Date:   May 20 2021 09:49:24  $ $Author:   E5350313  $
//	$Revision:   1.3  $
//## end module%5A541FFD01DF.cm

//## begin module%5A541FFD01DF.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A541FFD01DF.cp

//## Module: CXOSAI32%5A541FFD01DF; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI32.cpp

//## begin module%5A541FFD01DF.additionalIncludes preserve=no
//## end module%5A541FFD01DF.additionalIncludes

//## begin module%5A541FFD01DF.includes preserve=yes
//## end module%5A541FFD01DF.includes

#ifndef CXOSAI32_h
#include "CXODAI32.hpp"
#endif
//## begin module%5A541FFD01DF.declarations preserve=no
//## end module%5A541FFD01DF.declarations

//## begin module%5A541FFD01DF.additionalDeclarations preserve=yes
//## end module%5A541FFD01DF.additionalDeclarations


// Class StdFee 

StdFee::StdFee()
  //## begin StdFee::StdFee%5A541F080088_const.hasinit preserve=no
  //## end StdFee::StdFee%5A541F080088_const.hasinit
  //## begin StdFee::StdFee%5A541F080088_const.initialization preserve=yes
   : AdvantageMessage("0466","S200")
  //## end StdFee::StdFee%5A541F080088_const.initialization
{
  //## begin StdFee::StdFee%5A541F080088_const.body preserve=yes
  //## end StdFee::StdFee%5A541F080088_const.body
}


StdFee::~StdFee()
{
  //## begin StdFee::~StdFee%5A541F080088_dest.body preserve=yes
  //## end StdFee::~StdFee%5A541F080088_dest.body
}



//## Other Operations (implementation)
bool StdFee::insert (Message& hMessage)
{
  //## begin StdFee::insert%5A541F200120.body preserve=yes
   hFee* p = (hFee*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   if (memcmp(p->sUsageCode,"09",2))
      return false;
   UseCase hUseCase("TANDEM","## AI32 READ 0466 EXCEPTION",false);
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   setTSTAMP_TRANS(pV13AdvantageHeader->sFiller);
   database::UniquenessKey::hash(p->sPan,16);
   database::UniquenessKey::hash(p->sRetrievalRefNo,12);
   database::UniquenessKey::hash(p->sTraceNo,6);
   m_pTransaction->setUNIQUENESS_KEY(database::UniquenessKey::getHash());
   ::Template::instance()->map("STANDARDFEE",(const char*)p);
   return deport(hMessage);
  //## end StdFee::insert%5A541F200120.body
}

// Additional Declarations
  //## begin StdFee%5A541F080088.declarations preserve=yes
  //## end StdFee%5A541F080088.declarations

//## begin module%5A541FFD01DF.epilog preserve=yes
//## end module%5A541FFD01DF.epilog
