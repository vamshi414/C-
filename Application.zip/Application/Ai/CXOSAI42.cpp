//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A5434A8019F.cm preserve=no
//	$Date:   Oct 20 2020 06:38:26  $ $Author:   e3023547  $
//	$Revision:   1.4  $
//## end module%5A5434A8019F.cm

//## begin module%5A5434A8019F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A5434A8019F.cp

//## Module: CXOSAI42%5A5434A8019F; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI42.cpp

//## begin module%5A5434A8019F.additionalIncludes preserve=no
//## end module%5A5434A8019F.additionalIncludes

//## begin module%5A5434A8019F.includes preserve=yes
//## end module%5A5434A8019F.includes

#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSAI42_h
#include "CXODAI42.hpp"
#endif


//## begin module%5A5434A8019F.declarations preserve=no
//## end module%5A5434A8019F.declarations

//## begin module%5A5434A8019F.additionalDeclarations preserve=yes
//## end module%5A5434A8019F.additionalDeclarations


// Class APAcctMaintenance

APAcctMaintenance::APAcctMaintenance()
  //## begin APAcctMaintenance::APAcctMaintenance%5A542ED702DF_const.hasinit preserve=no
  //## end APAcctMaintenance::APAcctMaintenance%5A542ED702DF_const.hasinit
  //## begin APAcctMaintenance::APAcctMaintenance%5A542ED702DF_const.initialization preserve=yes
   : AdvantageMessage("0860","F001")
  //## end APAcctMaintenance::APAcctMaintenance%5A542ED702DF_const.initialization
{
  //## begin APAcctMaintenance::APAcctMaintenance%5A542ED702DF_const.body preserve=yes
   memcpy(m_sID,"AI42",4);
  //## end APAcctMaintenance::APAcctMaintenance%5A542ED702DF_const.body
}


APAcctMaintenance::~APAcctMaintenance()
{
  //## begin APAcctMaintenance::~APAcctMaintenance%5A542ED702DF_dest.body preserve=yes
  //## end APAcctMaintenance::~APAcctMaintenance%5A542ED702DF_dest.body
}



//## Other Operations (implementation)
bool APAcctMaintenance::insert (Message& hMessage)
{
  //## begin APAcctMaintenance::insert%5A542EF1002B.body preserve=yes
   UseCase hUseCase("TANDEM","## AI42 READ 0860 AP ACCOUNT",false);
   new_hAccountHolder* p = (new_hAccountHolder*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   memset((char*)p + 4096,'\0',4096);
   char sTSTAMP_TRANS[17] = {"                "};
   DateTime::calcCentury(p->sTimeStamp,sTSTAMP_TRANS);
   memcpy(sTSTAMP_TRANS + 2,p->sTimeStamp,14);
   m_pTransaction->setTSTAMP_TRANS(sTSTAMP_TRANS);
   int i = 0;
   if (p->sFRDABA[10] != ' ')
      i = 1;
   memcpy(p->sINST_ID,p->sFRDABA + i,9);
   memcpy(p->sBUSINESS_KEY,p->sAcctType,4);
   p->sBUSINESS_KEY[4] = '~';
   KeyRing::instance()->tokenize(p->sAcctNo, 28);
   memcpy(p->sBUSINESS_KEY + 5,p->sAcctNo,19);
   switch (ntohs(p->siStepNo))
   {
      case 5:
         p->cRECORD_ACTION = 'A';
         break;
      case 6:
         p->cRECORD_ACTION = 'D';
         break;
      case 8:
         p->cRECORD_ACTION = 'C';
         break;
      default:
         p->cRECORD_ACTION = 'U';
   }
   m_hAPAcctMaintenanceSegment.reformat(string(p->sRecType,4),(char*)p + 98,p->sOLD_VALUE,p->sNEW_VALUE,true);
   unsigned short j = 0;
   i = 0;
   int k = strlen(p->sOLD_VALUE);
   for (i = 0;i < k;i++)
	   j = 33 * j + p->sOLD_VALUE[i];
   k = strlen(p->sNEW_VALUE);
   for (i = 0;i < k;i++)
	   j = 33 * j + p->sNEW_VALUE[i];
   if (j > 32767)
	   j -= 32768;
   m_pTransaction->setUNIQUENESS_KEY((int)j);
    ::Template::instance()->map("ACCOUNTMAINT",(const char*)p);
   return deport(hMessage);
  //## end APAcctMaintenance::insert%5A542EF1002B.body
}

// Additional Declarations
  //## begin APAcctMaintenance%5A542ED702DF.declarations preserve=yes
  //## end APAcctMaintenance%5A542ED702DF.declarations

//## begin module%5A5434A8019F.epilog preserve=yes
//## end module%5A5434A8019F.epilog
