//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5ABE8E8B0247.cm preserve=no
//	$Date:   Apr 17 2018 13:16:44  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5ABE8E8B0247.cm

//## begin module%5ABE8E8B0247.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5ABE8E8B0247.cp

//## Module: CXOSAI44%5ABE8E8B0247; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI44.hpp

#ifndef CXOSAI44_h
#define CXOSAI44_h 1

//## begin module%5ABE8E8B0247.additionalIncludes preserve=no
//## end module%5ABE8E8B0247.additionalIncludes

//## begin module%5ABE8E8B0247.includes preserve=yes
//## end module%5ABE8E8B0247.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
//## begin module%5ABE8E8B0247.declarations preserve=no
//## end module%5ABE8E8B0247.declarations

//## begin module%5ABE8E8B0247.additionalDeclarations preserve=yes
//## end module%5ABE8E8B0247.additionalDeclarations


//## begin Message622%5ABE8D30024A.preface preserve=yes
//## end Message622%5ABE8D30024A.preface

//## Class: Message622%5ABE8D30024A
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport Message622 : public AdvantageMessage  //## Inherits: <unnamed>%5ABE8D400280
{
  //## begin Message622%5ABE8D30024A.initialDeclarations preserve=yes
  //## end Message622%5ABE8D30024A.initialDeclarations

  public:
    //## Constructors (generated)
      Message622();

    //## Destructor (generated)
      virtual ~Message622();


    //## Other Operations (specified)
      //## Operation: insert%5ABE8D470252
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin Message622%5ABE8D30024A.public preserve=yes
      //## end Message622%5ABE8D30024A.public

  protected:
    // Additional Protected Declarations
      //## begin Message622%5ABE8D30024A.protected preserve=yes
      //## end Message622%5ABE8D30024A.protected

  private:
    // Additional Private Declarations
      //## begin Message622%5ABE8D30024A.private preserve=yes
      //## end Message622%5ABE8D30024A.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin Message622%5ABE8D30024A.implementation preserve=yes
      //## end Message622%5ABE8D30024A.implementation

};

//## begin Message622%5ABE8D30024A.postscript preserve=yes
//## end Message622%5ABE8D30024A.postscript

//## begin module%5ABE8E8B0247.epilog preserve=yes
//## end module%5ABE8E8B0247.epilog


#endif
