//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A5434A60328.cm preserve=no
//	$Date:   May 08 2020 09:13:26  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%5A5434A60328.cm

//## begin module%5A5434A60328.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A5434A60328.cp

//## Module: CXOSAI42%5A5434A60328; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI42.hpp

#ifndef CXOSAI42_h
#define CXOSAI42_h 1

//## begin module%5A5434A60328.additionalIncludes preserve=no
//## end module%5A5434A60328.additionalIncludes

//## begin module%5A5434A60328.includes preserve=yes
//## end module%5A5434A60328.includes

#ifndef CXOSAI47_h
#include "CXODAI47.hpp"
#endif
#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class KeyRing;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class DateTime;

} // namespace IF

//## begin module%5A5434A60328.declarations preserve=no
//## end module%5A5434A60328.declarations

//## begin module%5A5434A60328.additionalDeclarations preserve=yes
//## end module%5A5434A60328.additionalDeclarations


//## begin APAcctMaintenance%5A542ED702DF.preface preserve=yes
//## end APAcctMaintenance%5A542ED702DF.preface

//## Class: APAcctMaintenance%5A542ED702DF
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5A56903B019A;IF::DateTime { -> F}
//## Uses: <unnamed>%5EB37C720135;reusable::KeyRing { -> F}

class DllExport APAcctMaintenance : public AdvantageMessage  //## Inherits: <unnamed>%5A542EE300AF
{
  //## begin APAcctMaintenance%5A542ED702DF.initialDeclarations preserve=yes
  //## end APAcctMaintenance%5A542ED702DF.initialDeclarations

  public:
    //## Constructors (generated)
      APAcctMaintenance();

    //## Destructor (generated)
      virtual ~APAcctMaintenance();


    //## Other Operations (specified)
      //## Operation: insert%5A542EF1002B
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin APAcctMaintenance%5A542ED702DF.public preserve=yes
      //## end APAcctMaintenance%5A542ED702DF.public

  protected:
    // Additional Protected Declarations
      //## begin APAcctMaintenance%5A542ED702DF.protected preserve=yes
      //## end APAcctMaintenance%5A542ED702DF.protected

  private:
    // Additional Private Declarations
      //## begin APAcctMaintenance%5A542ED702DF.private preserve=yes
      //## end APAcctMaintenance%5A542ED702DF.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5EB2CCF6018F
      //## Role: APAcctMaintenance::<m_hAPAcctMaintenanceSegment>%5EB2CCF70032
      //## begin APAcctMaintenance::<m_hAPAcctMaintenanceSegment>%5EB2CCF70032.role preserve=no  public: APAcctMaintenanceSegment { -> VHgN}
      APAcctMaintenanceSegment m_hAPAcctMaintenanceSegment;
      //## end APAcctMaintenance::<m_hAPAcctMaintenanceSegment>%5EB2CCF70032.role

    // Additional Implementation Declarations
      //## begin APAcctMaintenance%5A542ED702DF.implementation preserve=yes
      //## end APAcctMaintenance%5A542ED702DF.implementation

};

//## begin APAcctMaintenance%5A542ED702DF.postscript preserve=yes
//## end APAcctMaintenance%5A542ED702DF.postscript

//## begin module%5A5434A60328.epilog preserve=yes
//## end module%5A5434A60328.epilog


#endif
