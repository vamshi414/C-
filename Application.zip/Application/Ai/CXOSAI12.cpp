//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3C6139410280.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C6139410280.cm

//## begin module%3C6139410280.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3C6139410280.cp

//## Module: CXOSAI12%3C6139410280; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Pvcswork\Dn\Server\Application\Ai\CXOSAI12.cpp

//## begin module%3C6139410280.additionalIncludes preserve=no
//## end module%3C6139410280.additionalIncludes

//## begin module%3C6139410280.includes preserve=yes
// $Date:   Jun 21 2017 08:46:34  $ $Author:   e1009839  $ $Revision:   1.48  $
#include "CXODIF03.hpp"
#include "CXODIF11.hpp"
#include "CXODIF16.hpp"
#include "CXODNS29.hpp"
//## end module%3C6139410280.includes

#ifndef CXOSAI12_h
#include "CXODAI12.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSRS36_h
#include "CXODRS36.hpp"
#endif
#ifndef CXOSRS39_h
#include "CXODRS39.hpp"
#endif
#ifndef CXOSRS41_h
#include "CXODRS41.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif


//## begin module%3C6139410280.declarations preserve=no
//## end module%3C6139410280.declarations

//## begin module%3C6139410280.additionalDeclarations preserve=yes
//## end module%3C6139410280.additionalDeclarations


// Class AdvantagePlusAdjustment


AdvantagePlusAdjustment::AdvantagePlusAdjustment()
  //## begin AdvantagePlusAdjustment::AdvantagePlusAdjustment%3C6133A80148_const.hasinit preserve=no
  //## end AdvantagePlusAdjustment::AdvantagePlusAdjustment%3C6133A80148_const.hasinit
  //## begin AdvantagePlusAdjustment::AdvantagePlusAdjustment%3C6133A80148_const.initialization preserve=yes
   : AdvantageMessage("0466","S200")
  //## end AdvantagePlusAdjustment::AdvantagePlusAdjustment%3C6133A80148_const.initialization
{
  //## begin AdvantagePlusAdjustment::AdvantagePlusAdjustment%3C6133A80148_const.body preserve=yes
   memcpy(m_sID,"AI12",4);
  //## end AdvantagePlusAdjustment::AdvantagePlusAdjustment%3C6133A80148_const.body
}


AdvantagePlusAdjustment::~AdvantagePlusAdjustment()
{
  //## begin AdvantagePlusAdjustment::~AdvantagePlusAdjustment%3C6133A80148_dest.body preserve=yes
  //## end AdvantagePlusAdjustment::~AdvantagePlusAdjustment%3C6133A80148_dest.body
}



//## Other Operations (implementation)
bool AdvantagePlusAdjustment::insert (Message& hMessage)
{
  //## begin AdvantagePlusAdjustment::insert%3C63D82E03D8.body preserve=yes
   hPlusAdjustment* pAdjustment = (hPlusAdjustment*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   char sTranId[4];
   memcpy(sTranId,pAdjustment->sTranId,4);
   char sMsgType[4];
   memcpy(sMsgType,pAdjustment->sMsgType,4);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
     CodeTable::translate(sTranId,4,CodeTable::CX_ASCII_TO_EBCDIC);
     CodeTable::translate(sMsgType,4,CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
     CodeTable::translate(sTranId,4,CodeTable::CX_EBCDIC_TO_ASCII);
     CodeTable::translate(sMsgType,4,CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   if ((memcmp(sTranId,"X067",4) == 0) &&
      ((memcmp(sMsgType,"0420",4) == 0) || (memcmp(sMsgType,"0422",4) == 0)))
       ;
       else
   return false;
   UseCase hUseCase("TANDEM","## AD22 READ 0466 EXCEPTION",false);
   FinancialBaseSegment* m_pFinancialBaseSegment = FinancialBaseSegment::instance();
   FinancialSettlementSegment* m_pFinancialSettlementSegment = FinancialSettlementSegment::instance();
   FinancialAdjustmentSegment* m_pFinancialAdjustmentSegment = FinancialAdjustmentSegment::instance();
   FinancialAdjustmentExtensionSegment* m_pFinancialAdjustmentExtensionSegment = FinancialAdjustmentExtensionSegment::instance();
   char sDateTime16[17] = {"                "};
   char sBlankExtdPan[28];
   m_hAuditSegment.reset();
   m_pFinancialBaseSegment->reset();
   m_pFinancialSettlementSegment->reset();
   m_pFinancialAdjustmentSegment->reset();
   m_pFinancialAdjustmentExtensionSegment->reset();
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pAdjustment->sTranDate,(pAdjustment->sUsageCode - pAdjustment->sTranDate),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sMsgType,
        (pAdjustment->sMsgAuthenCode - pAdjustment->sMsgType +
         sizeof(pAdjustment->sMsgAuthenCode)),CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pAdjustment->sTranDate,(pAdjustment->sUsageCode - pAdjustment->sTranDate),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sMsgType,
        (pAdjustment->sMsgAuthenCode - pAdjustment->sMsgType +
         sizeof(pAdjustment->sMsgAuthenCode)),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   m_pFinancialBaseSegment->setCED_BUILD_NO(ntohl(pV13AdvantageHeader->lCED_BUILD_NO));
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   m_pFinancialAdjustmentSegment->setTRACE_DATA_ADJ(pAdjustment->sOdeSysTrace,6);
   char sExtensionData[60];
   memset(sExtensionData,' ',sizeof(sExtensionData));
   memcpy(sExtensionData,pAdjustment->sProcessCode,6);
   sExtensionData[6] = ' ';
   memcpy(sExtensionData+7,pAdjustment->sCorrReasonCode,12);
   sExtensionData[19] = ' ';
   memcpy(sExtensionData+20,pAdjustment->sRetrievalRefNo,12);
   sExtensionData[32] = ' ';
   memcpy(sExtensionData+33,pAdjustment->sAcqInstCountry,3);
   sExtensionData[36] = ' ';
   memcpy(sExtensionData+37,pAdjustment->sDestInstId,11);
   sExtensionData[48] = ' ';
   memcpy(sExtensionData+49,pAdjustment->sOrgInstId,11);
   m_pFinancialAdjustmentExtensionSegment->setEXTENSION_DATA_ADJ(sExtensionData,60);
   memcpy(sDateTime16+4,pAdjustment->sTransDate,4);
   memcpy(sDateTime16+8,pAdjustment->sTransTime,6);
   memcpy(sDateTime16+14,"00",2);
   m_pFinancialAdjustmentSegment->setTSTAMP_TRANS_ADJ(sDateTime16,16);
   char sCentury[2];
   DateTime::calcCentury(pAdjustment->sTranDate,sCentury);
   memcpy(sDateTime16,sCentury,2);
   memcpy(sDateTime16+2,pAdjustment->sTranDate,6);
   memcpy(sDateTime16+8,pAdjustment->sTranTime,6);
   memcpy(sDateTime16+14,"00",2);
   m_pFinancialAdjustmentSegment->setTSTAMP_LOCAL_ADJ(sDateTime16,14);
   m_pFinancialBaseSegment->setTSTAMP_TRANS(sDateTime16,16);
   m_pFinancialBaseSegment->setCARD_ACPT_NAME_LOC(pAdjustment->sCardAcptTermDesc,40);
   m_pFinancialBaseSegment->setCARD_ACPT_TERM_ID(pAdjustment->sCardAcptTermId,15);
   m_pFinancialBaseSegment->setRETRIEVAL_REF_NO(pAdjustment->sCardAcptTermRef,8);
   m_pFinancialBaseSegment->setINST_ID_RECON_ACQ(pAdjustment->sFwdInstId,11);
   m_pFinancialBaseSegment->setINST_ID_RECON_ISS(pAdjustment->sOdeDestInstId,11);

   //* The institution id fields in the exception messages contain Plus PMC values,
   //* not the institution values we would find in our CR tables.  The isSubscriber
   //* call is only going to look up at the customer level.
   if ((ConfigurationRepository::instance()->isSubscriber("",""))== "X")
   {
/*      Trace::put(__FILE__,__LINE__,"not keeping",-1);	*/
      return false;
   }
   else
   {
/*      Trace::put(__FILE__,__LINE__,"keeping",-1);	*/
/*      Trace::put(ConfigurationRepository::instance()->getSUBSCRIBER_IND().data(),ConfigurationRepository::instance()->getSUBSCRIBER_IND().length());	*/
      m_pFinancialBaseSegment->setSUBSCRIBER_IND(ConfigurationRepository::instance()->getSUBSCRIBER_IND().data(), 1);
   }

   m_pFinancialBaseSegment->setMERCH_TYPE(pAdjustment->sMerchType,4);
   memset(sBlankExtdPan,' ',sizeof(sBlankExtdPan));
   if (!memcmp(sBlankExtdPan,pAdjustment->sPanExtd,28))
   {
      if (Customer::instance()->getTest())
         memcpy(pAdjustment->sPan + 6,"999999",6);
      m_pFinancialBaseSegment->setPAN(pAdjustment->sPan,19);
   }
   else
   {
      m_pFinancialBaseSegment->setACCT_ID_1(pAdjustment->sPanExtd,28);
      if (Customer::instance()->getTest())
         memcpy(pAdjustment->sPanExtd + 6,"999999",6);
      m_pFinancialBaseSegment->setPAN(pAdjustment->sPanExtd,28);
   }
   m_pFinancialBaseSegment->setINST_ID_ISS(pAdjustment->sRecInstId,11);
   m_pFinancialBaseSegment->setSYS_TRACE_AUDIT_NO(pAdjustment->sSysTraceNo,6);
   m_pFinancialBaseSegment->setCUR_RECON_NET(pAdjustment->sCurrCodeSettle,3);
   m_pFinancialBaseSegment->setUNIQUENESS_KEY(m_siUniquenessKey);
   m_pFinancialBaseSegment->setACQ_PLAT_PROD_ID("A",1);
   m_pFinancialBaseSegment->setFIN_TYPE("080",3);
   m_pFinancialBaseSegment->setTRAN_DISPOSITION("1",1);
   string strProcCode(pAdjustment->sProcessCode,6),strTranTypeId;
   if (ConfigurationRepository::instance()->translate("X_PLUS_PROC_CODE",strProcCode,strTranTypeId,"FIN_LOCATOR","TRAN_TYPE_ID", 0))
   {
      m_pFinancialBaseSegment->setTRAN_TYPE_ID(strTranTypeId.data(),strTranTypeId.length());
      m_pFinancialBaseSegment->setACCT_TYPES_ISS(strTranTypeId.substr(2,4).data(),4);
   }
   else
      ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_SET_ACCT_TYPES_ISS);
   string strReasonCode(pAdjustment->sCorrReasonCode,4), strMsgReasonCode;
   if (ConfigurationRepository::instance()->translate("X_PLUS_CRCT_REASON",
      strReasonCode,strMsgReasonCode, "FIN_RECORD", "MSG_RESON_CODE_ACQ", 0));
      m_pFinancialBaseSegment->setMSG_RESON_CODE_ACQ(strMsgReasonCode.data(),strMsgReasonCode.length());
   char sCardAcptNameLoc[84];
   memset(sCardAcptNameLoc,' ',sizeof(sCardAcptNameLoc));
   memcpy(sCardAcptNameLoc, pAdjustment->sCardAcptTermId,15);
   memcpy(sCardAcptNameLoc+26, pAdjustment->sCardAcptTermDesc,23);
   memcpy(sCardAcptNameLoc+55, pAdjustment->sCardAcptTermDesc+23,13);
   m_pFinancialBaseSegment->setCARD_ACPT_NAME_LOC(sCardAcptNameLoc,84);
   m_pFinancialBaseSegment->setCARD_ACPT_REGION(pAdjustment->sCardAcptTermDesc+36,2);
   m_pFinancialBaseSegment->setCARD_ACPT_COUNTRY(pAdjustment->sCardAcptTermDesc+38,2);
   if (getTestDate().length() > 0)
   {
      IString strTstampTrans(sDateTime16);
      IString strTemp((char*)getTestDate().c_str());
      strTemp += strTstampTrans.subString(9,8);
      m_pFinancialBaseSegment->setTSTAMP_TRANS(strTemp,16);
      m_pFinancialBaseSegment->setTSTAMP_LOCAL(strTemp,14);
   }
   string strRecord;
   Extract::instance()->getRecord("DUSER   ",strRecord);
   if (strRecord.find("DATE_EXP") != string::npos)
      m_pFinancialSettlementSegment->setDATE_EXP(pAdjustment->sExpDate,4);
   char sDataPriv[43];
   memset(sDataPriv,' ',sizeof(sDataPriv));
   memcpy(sDataPriv,pAdjustment->sOdeTranDateTime,10);
   sDataPriv[10]=' ';
   memcpy(sDataPriv+11,pAdjustment->sPsiRefInfo,32);
   m_pFinancialSettlementSegment->setDATA_PRIV_ACQ(sDataPriv,43);
   m_pFinancialSettlementSegment->setDATA_PRIV_ISS(sDataPriv,43);
   m_pFinancialSettlementSegment->setF_AMTn(pAdjustment->sReplAmtTFee,8,0);
   m_pFinancialSettlementSegment->setF_AMT_RECON_NETn(pAdjustment->sReplAmtTFee,8,0);
   m_pFinancialSettlementSegment->setCNV_RCN_NET_DE_POS(&pAdjustment->cConvRateSettleDecPos,1);
   m_pFinancialSettlementSegment->setCNV_RCN_NET_RATE(pAdjustment->sConvRateSettle,7);
   m_pFinancialAdjustmentSegment->setORIG_AMT_TRAN_ADJ(pAdjustment->sAmtTran,12);
   m_pFinancialBaseSegment->setAMT_RECON_NET(pAdjustment->sReplAmtSettle,12);
   m_pFinancialBaseSegment->setAMT_TRAN(pAdjustment->sAmtSettle,12);
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   m_pFinancialBaseSegment->write(&psBuffer);
   m_pFinancialSettlementSegment->write(&psBuffer);
   m_pFinancialAdjustmentSegment->write(&psBuffer);
   m_pFinancialAdjustmentExtensionSegment->write(&psBuffer);
   ConfigurationRepository::instance()->write(&psBuffer,m_pFinancialBaseSegment->zTSTAMP_TRANS(),m_pFinancialBaseSegment->getUNIQUENESS_KEY());
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantagePlusAdjustment::insert%3C63D82E03D8.body
}

// Additional Declarations
  //## begin AdvantagePlusAdjustment%3C6133A80148.declarations preserve=yes
  //## end AdvantagePlusAdjustment%3C6133A80148.declarations

//## begin module%3C6139410280.epilog preserve=yes
//## end module%3C6139410280.epilog
