//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5718DBB5018D.cm preserve=no
//	$Date:   Jul 25 2018 14:48:44  $ $Author:   e1009610  $
//	$Revision:   1.7  $
//## end module%5718DBB5018D.cm

//## begin module%5718DBB5018D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5718DBB5018D.cp

//## Module: CXOSAI23%5718DBB5018D; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXOSAI23.cpp

//## begin module%5718DBB5018D.additionalIncludes preserve=no
//## end module%5718DBB5018D.additionalIncludes

//## begin module%5718DBB5018D.includes preserve=yes
//## end module%5718DBB5018D.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRSA0_h
#include "CXODRSA0.hpp"
#endif
#ifndef CXOSRU37_h
#include "CXODRU37.hpp"
#endif
#ifndef CXOSDB49_h
#include "CXODDB49.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSAI23_h
#include "CXODAI23.hpp"
#endif


//## begin module%5718DBB5018D.declarations preserve=no
//## end module%5718DBB5018D.declarations

//## begin module%5718DBB5018D.additionalDeclarations preserve=yes
#include "CXODIF16.hpp"
//## end module%5718DBB5018D.additionalDeclarations


// Class AdvantageMessage600Lcm 

AdvantageMessage600Lcm::AdvantageMessage600Lcm()
  //## begin AdvantageMessage600Lcm::AdvantageMessage600Lcm%5718D07200E8_const.hasinit preserve=no
  //## end AdvantageMessage600Lcm::AdvantageMessage600Lcm%5718D07200E8_const.hasinit
  //## begin AdvantageMessage600Lcm::AdvantageMessage600Lcm%5718D07200E8_const.initialization preserve=yes
  : AdvantageMessage("0600","S600"),
    m_bLCM_EXP_DATE(false)
  //## end AdvantageMessage600Lcm::AdvantageMessage600Lcm%5718D07200E8_const.initialization
{
  //## begin AdvantageMessage600Lcm::AdvantageMessage600Lcm%5718D07200E8_const.body preserve=yes
   memcpy(m_sID,"AI23",4);
   string strRecord;
   Extract::instance()->getRecord("DUSER   ",strRecord);
   m_bLCM_EXP_DATE = strRecord.find("LCM_EXP_DATE") != string::npos;
  //## end AdvantageMessage600Lcm::AdvantageMessage600Lcm%5718D07200E8_const.body
}


AdvantageMessage600Lcm::~AdvantageMessage600Lcm()
{
  //## begin AdvantageMessage600Lcm::~AdvantageMessage600Lcm%5718D07200E8_dest.body preserve=yes
  //## end AdvantageMessage600Lcm::~AdvantageMessage600Lcm%5718D07200E8_dest.body
}



//## Other Operations (implementation)
bool AdvantageMessage600Lcm::insert (IF::Message& hMessage)
{
  //## begin AdvantageMessage600Lcm::insert%5718DEFE024D.body preserve=yes
   LifeCycleManagementSegment::instance()->reset();

   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   hAdvantage600LCM* pAdvantage600LCM = (hAdvantage600LCM*)(hMessage.data() + sizeof(hV13AdvantageHeader));

   translate(pAdvantage600LCM->sMTI,((char *)(&pAdvantage600LCM->lAMT_TRAN) - pAdvantage600LCM->sMTI));
   translate(pAdvantage600LCM->sCUR_TRAN,((char *)(&pAdvantage600LCM->lADL_RQST_AMT0) - pAdvantage600LCM->sCUR_TRAN));
   translate(pAdvantage600LCM->sADL_RQST_ACCT_TYP1,((char *)(&pAdvantage600LCM->lADL_RQST_AMT1) - pAdvantage600LCM->sADL_RQST_ACCT_TYP1));
   translate(pAdvantage600LCM->sADL_RQST_ACCT_TYP2,((char *)(&pAdvantage600LCM->lADL_RQST_AMT2) - pAdvantage600LCM->sADL_RQST_ACCT_TYP2));
   translate(pAdvantage600LCM->sADL_RQST_ACCT_TYP3,((char *)(&pAdvantage600LCM->lADL_RQST_AMT3) - pAdvantage600LCM->sADL_RQST_ACCT_TYP3));
   translate(pAdvantage600LCM->sADL_RQST_ACCT_TYP4,((char *)(&pAdvantage600LCM->lADL_RQST_AMT4) - pAdvantage600LCM->sADL_RQST_ACCT_TYP4));
   translate(pAdvantage600LCM->sADL_RQST_ACCT_TYP5,((char *)(&pAdvantage600LCM->lADL_RQST_AMT5) - pAdvantage600LCM->sADL_RQST_ACCT_TYP5));
   translate(pAdvantage600LCM->sODE_MTI,((char *)(&pAdvantage600LCM->siDATA_PRIV_ACQ_FMT) - pAdvantage600LCM->sODE_MTI));
   translate(pAdvantage600LCM->sDATA_PRIV_ACQ,((char *)(&pAdvantage600LCM->siDATA_PRIV_ISS_FMT) - pAdvantage600LCM->sDATA_PRIV_ACQ));
   translate(pAdvantage600LCM->sDATA_PRIV_ISS,(pAdvantage600LCM->sDATE_RECON_RECV - pAdvantage600LCM->sDATA_PRIV_ISS) + 6);
   translate(pAdvantage600LCM->sCIRC_ID,((char *)(&pAdvantage600LCM->lTSAP_IDX) - pAdvantage600LCM->sCIRC_ID));
   translate(pAdvantage600LCM->sROUTE_LIST_ID,((char *)(&pAdvantage600LCM->siPMC_ERROR) - pAdvantage600LCM->sROUTE_LIST_ID));
   translate(pAdvantage600LCM->sCNX_NET_ID,((pAdvantage600LCM->sTSTAMP_TRANS) - pAdvantage600LCM->sCNX_NET_ID));
   translate(pAdvantage600LCM->sDATA,((pAdvantage600LCM->sPAYMENT_TOKEN_DATA) - pAdvantage600LCM->sDATA) + 999);

   UseCase hUseCase("TANDEM","## AD31 READ 0600 LCMS",false);
   string strMSG_CODE("0600");
   LifeCycleManagementSegment::instance()->setMSG_CODE(strMSG_CODE.data(),strMSG_CODE.length());
   LifeCycleManagementSegment::instance()->setMTI(pAdvantage600LCM->sMTI,4);
   LifeCycleManagementSegment::instance()->setPROCESS_CODE(pAdvantage600LCM->sPROCESS_CODE,6);
   LifeCycleManagementSegment::instance()->setPAN(pAdvantage600LCM->sPAN,28);
   LifeCycleManagementSegment::instance()->setCARD_SEQ_NO(pAdvantage600LCM->sCARD_SEQ_NO,5);
   LifeCycleManagementSegment::instance()->setCNTRY_PAN(pAdvantage600LCM->sCNTRY_PAN,3);
   LifeCycleManagementSegment::instance()->setAMT_TRAN(ntohl(pAdvantage600LCM->lAMT_TRAN[0]),ntohl(pAdvantage600LCM->lAMT_TRAN[1]));
   LifeCycleManagementSegment::instance()->setAMT_RECON_ACQ(ntohl(pAdvantage600LCM->lAMT_RECON_ACQ[0]),ntohl(pAdvantage600LCM->lAMT_RECON_ACQ[1]));
   LifeCycleManagementSegment::instance()->setAMT_CARD_BILL(ntohl(pAdvantage600LCM->lAMT_CARD_BILL[0]),ntohl(pAdvantage600LCM->lAMT_CARD_BILL[1]));
   LifeCycleManagementSegment::instance()->setAMT_RECON_ISS(ntohl(pAdvantage600LCM->lAMT_RECON_ISS[0]),ntohl(pAdvantage600LCM->lAMT_RECON_ISS[1]));
   LifeCycleManagementSegment::instance()->setCUR_TRAN(pAdvantage600LCM->sCUR_TRAN,3);
   LifeCycleManagementSegment::instance()->setCUR_RECON_ACQ(pAdvantage600LCM->sCUR_RECON_ACQ,3);
   LifeCycleManagementSegment::instance()->setCUR_CARD_BILL(pAdvantage600LCM->sCUR_CARD_BILL,3);
   LifeCycleManagementSegment::instance()->setCUR_RECON_ISS(pAdvantage600LCM->sCUR_RECON_ISS,3);
   LifeCycleManagementSegment::instance()->setCNV_RCN_ACQ_DE_POS(&pAdvantage600LCM->cCNV_RCN_ACQ_DE_POS,1);
   LifeCycleManagementSegment::instance()->setCNV_RCN_ACQ_RATE(pAdvantage600LCM->sCNV_RCN_ACQ_RATE,7);
   LifeCycleManagementSegment::instance()->setCNV_CARD_BILL_DE_POS(&pAdvantage600LCM->cCNV_CARD_BILL_DE_POS,1);
   LifeCycleManagementSegment::instance()->setCNV_CARD_BILL_RATE(pAdvantage600LCM->sCNV_CARD_BILL_RATE,7);
   LifeCycleManagementSegment::instance()->setCNV_RCN_ISS_DE_POS(&pAdvantage600LCM->cCNV_RCN_ISS_DE_POS,1);
   LifeCycleManagementSegment::instance()->setCNV_RCN_ISS_RATE(pAdvantage600LCM->sCNV_RCN_ISS_RATE,7);
   LifeCycleManagementSegment::instance()->setTSTAMP_TRANS_RQST(pAdvantage600LCM->sTSTAMP_TRANS_RQST,10);
   LifeCycleManagementSegment::instance()->setSYS_TRACE_AUDIT_NO(pAdvantage600LCM->sSYS_TRACE_AUDIT_NO,6);
   if (m_bLCM_EXP_DATE)
      LifeCycleManagementSegment::instance()->setDATE_EXP(pAdvantage600LCM->sDATE_EXP,4);
   LifeCycleManagementSegment::instance()->setAPPROVAL_CODE(pAdvantage600LCM->sAPPROVAL_CODE,6);
   LifeCycleManagementSegment::instance()->setCNTRY_INST_ACQ(pAdvantage600LCM->sCNTRY_INST_ACQ,3);
   LifeCycleManagementSegment::instance()->setINST_ID_ACQ(pAdvantage600LCM->sINST_ID_ACQ,11);
   LifeCycleManagementSegment::instance()->setCNTRY_INST_FWD(pAdvantage600LCM->sCNTRY_INST_FWD,3);
   LifeCycleManagementSegment::instance()->setINST_ID_FWD(pAdvantage600LCM->sINST_ID_FWD,11);
   LifeCycleManagementSegment::instance()->setCARD_ACPT_TERM_ID(pAdvantage600LCM->sCARD_ACPT_TERM_ID,15);
   LifeCycleManagementSegment::instance()->setCARD_ACPT_ID(pAdvantage600LCM->sCARD_ACPT_ID,15);
   LifeCycleManagementSegment::instance()->setCARD_ACPT_NAME_LOC(pAdvantage600LCM->sCARD_ACPT_NAME_LOC,84);
   LifeCycleManagementSegment::instance()->setCARD_ACPT_REGION(pAdvantage600LCM->sCARD_ACPT_REGION,3);
   LifeCycleManagementSegment::instance()->setCARD_ACPT_COUNTRY(pAdvantage600LCM->sCARD_ACPT_COUNTRY,3);
   LifeCycleManagementSegment::instance()->setCARD_ACPT_PST_CODE(pAdvantage600LCM->sCARD_ACPT_PST_CODE,10);
   LifeCycleManagementSegment::instance()->setCARD_ACPT_COUNTY(pAdvantage600LCM->sCARD_ACPT_COUNTY,3);
   LifeCycleManagementSegment::instance()->setIMS_TWIN(&pAdvantage600LCM->cIMS_TWIN,1);
   LifeCycleManagementSegment::instance()->setMERCH_TYPE(pAdvantage600LCM->sMERCH_TYPE,4);
   LifeCycleManagementSegment::instance()->setCARD_ACPT_REGION_NO(pAdvantage600LCM->sCARD_ACPT_REGION_NO,3);
   LifeCycleManagementSegment::instance()->setCARD_ACPT_COUNTRY_NO(pAdvantage600LCM->sCARD_ACPT_COUNTRY_NO,3);
   LifeCycleManagementSegment::instance()->setFUNC_CODE(pAdvantage600LCM->sFUNC_CODE,3);
   LifeCycleManagementSegment::instance()->setACT_CODE(pAdvantage600LCM->sACT_CODE,3);
   if (pAdvantage600LCM->sTSTAMP_LOCAL[0] != ' ')
   {
      char sDateTime14[15] = {"20            "};
      memcpy(sDateTime14+2, pAdvantage600LCM->sTSTAMP_LOCAL,12);
      LifeCycleManagementSegment::instance()->setTSTAMP_LOCAL(sDateTime14,14);
   }
   LifeCycleManagementSegment::instance()->setRETRIEVAL_REF_NO(pAdvantage600LCM->sRETRIEVAL_REF_NO,12);
   LifeCycleManagementSegment::instance()->setMSG_REASON_CODE(pAdvantage600LCM->sMSG_REASON_CODE,4);
   LifeCycleManagementSegment::instance()->setMSG_NO(pAdvantage600LCM->sMSG_NO,4);
   LifeCycleManagementSegment::instance()->setMSG_NO_LAST(pAdvantage600LCM->sMSG_NO_LAST,4);
   LifeCycleManagementSegment::instance()->setADL_RQST_ACCT_TYP0(pAdvantage600LCM->sADL_RQST_ACCT_TYP0,2);
   LifeCycleManagementSegment::instance()->setADL_RQST_AMT_TYP0(pAdvantage600LCM->sADL_RQST_AMT_TYP0,2);
   LifeCycleManagementSegment::instance()->setADL_RQST_CUR_CODE0(pAdvantage600LCM->sADL_RQST_CUR_CODE0,3);
   LifeCycleManagementSegment::instance()->setADL_RQST_AMT0(ntohl(pAdvantage600LCM->lADL_RQST_AMT0[0]),ntohl(pAdvantage600LCM->lADL_RQST_AMT0[1]));
   LifeCycleManagementSegment::instance()->setADL_RQST_ACCT_IDX0(ntohs(pAdvantage600LCM->siADL_RQST_ACCT_IDX0));
   LifeCycleManagementSegment::instance()->setADL_RQST_ACCT_TYP1(pAdvantage600LCM->sADL_RQST_ACCT_TYP1,2);
   LifeCycleManagementSegment::instance()->setADL_RQST_AMT_TYP1(pAdvantage600LCM->sADL_RQST_AMT_TYP1,2);
   LifeCycleManagementSegment::instance()->setADL_RQST_CUR_CODE1(pAdvantage600LCM->sADL_RQST_CUR_CODE1,3);
   LifeCycleManagementSegment::instance()->setADL_RQST_AMT1(ntohl(pAdvantage600LCM->lADL_RQST_AMT1[0]),ntohl(pAdvantage600LCM->lADL_RQST_AMT1[1]));
   LifeCycleManagementSegment::instance()->setADL_RQST_ACCT_IDX1(ntohs(pAdvantage600LCM->siADL_RQST_ACCT_IDX1));
   LifeCycleManagementSegment::instance()->setADL_RQST_ACCT_TYP2(pAdvantage600LCM->sADL_RQST_ACCT_TYP2,2);
   LifeCycleManagementSegment::instance()->setADL_RQST_AMT_TYP2(pAdvantage600LCM->sADL_RQST_AMT_TYP2,2);
   LifeCycleManagementSegment::instance()->setADL_RQST_CUR_CODE2(pAdvantage600LCM->sADL_RQST_CUR_CODE2,3);
   LifeCycleManagementSegment::instance()->setADL_RQST_AMT2(ntohl(pAdvantage600LCM->lADL_RQST_AMT2[0]),ntohl(pAdvantage600LCM->lADL_RQST_AMT2[1]));
   LifeCycleManagementSegment::instance()->setADL_RQST_ACCT_IDX2(ntohs(pAdvantage600LCM->siADL_RQST_ACCT_IDX2));
   LifeCycleManagementSegment::instance()->setADL_RQST_ACCT_TYP3(pAdvantage600LCM->sADL_RQST_ACCT_TYP3,2);
   LifeCycleManagementSegment::instance()->setADL_RQST_AMT_TYP3(pAdvantage600LCM->sADL_RQST_AMT_TYP3,2);
   LifeCycleManagementSegment::instance()->setADL_RQST_CUR_CODE3(pAdvantage600LCM->sADL_RQST_CUR_CODE3,3);
   LifeCycleManagementSegment::instance()->setADL_RQST_AMT3(ntohl(pAdvantage600LCM->lADL_RQST_AMT3[0]),ntohl(pAdvantage600LCM->lADL_RQST_AMT3[1]));
   LifeCycleManagementSegment::instance()->setADL_RQST_ACCT_IDX3(ntohs(pAdvantage600LCM->siADL_RQST_ACCT_IDX3));
   LifeCycleManagementSegment::instance()->setADL_RQST_ACCT_TYP4(pAdvantage600LCM->sADL_RQST_ACCT_TYP4,2);
   LifeCycleManagementSegment::instance()->setADL_RQST_AMT_TYP4(pAdvantage600LCM->sADL_RQST_AMT_TYP4,2);
   LifeCycleManagementSegment::instance()->setADL_RQST_CUR_CODE4(pAdvantage600LCM->sADL_RQST_CUR_CODE4,3);
   LifeCycleManagementSegment::instance()->setADL_RQST_AMT4(ntohl(pAdvantage600LCM->lADL_RQST_AMT4[0]),ntohl(pAdvantage600LCM->lADL_RQST_AMT4[1]));
   LifeCycleManagementSegment::instance()->setADL_RQST_ACCT_IDX4(ntohs(pAdvantage600LCM->siADL_RQST_ACCT_IDX4));
   LifeCycleManagementSegment::instance()->setADL_RQST_ACCT_TYP5(pAdvantage600LCM->sADL_RQST_ACCT_TYP5,2);
   LifeCycleManagementSegment::instance()->setADL_RQST_AMT_TYP5(pAdvantage600LCM->sADL_RQST_AMT_TYP5,2);
   LifeCycleManagementSegment::instance()->setADL_RQST_CUR_CODE5(pAdvantage600LCM->sADL_RQST_CUR_CODE5,3);
   LifeCycleManagementSegment::instance()->setADL_RQST_AMT5(ntohl(pAdvantage600LCM->lADL_RQST_AMT5[0]),ntohl(pAdvantage600LCM->lADL_RQST_AMT5[1]));
   LifeCycleManagementSegment::instance()->setADL_RQST_ACCT_IDX5(ntohs(pAdvantage600LCM->siADL_RQST_ACCT_IDX5));
   LifeCycleManagementSegment::instance()->setODE_MTI(pAdvantage600LCM->sODE_MTI,4);
   LifeCycleManagementSegment::instance()->setODE_SYS_TRA_AUD_NO(pAdvantage600LCM->sODE_SYS_TRA_AUD_NO,6);
   LifeCycleManagementSegment::instance()->setODE_TSTAMP_LOCAL(pAdvantage600LCM->sODE_TSTAMP_LOCAL,12);
   LifeCycleManagementSegment::instance()->setODE_LEN_INST_ID_ACQ(pAdvantage600LCM->sODE_LEN_INST_ID_ACQ,2);
   LifeCycleManagementSegment::instance()->setODE_INST_ID_ACQ(pAdvantage600LCM->sODE_INST_ID_ACQ,11);
   LifeCycleManagementSegment::instance()->setODE_LEN_INST_ID_FWD(pAdvantage600LCM->sODE_LEN_INST_ID_FWD,2);
   LifeCycleManagementSegment::instance()->setODE_INST_ID_FWD(pAdvantage600LCM->sODE_INST_ID_FWD,11);
   LifeCycleManagementSegment::instance()->setINST_ID_TRAN_DEST_IB(pAdvantage600LCM->sINST_ID_TRAN_DEST_IB,11);
   LifeCycleManagementSegment::instance()->setINST_ID_TRAN_DEST_OB(pAdvantage600LCM->sINST_ID_TRAN_DEST_OB,11);
   LifeCycleManagementSegment::instance()->setACCT_ID_1(pAdvantage600LCM->sACCT_ID_1,28);
   LifeCycleManagementSegment::instance()->setTRAN_DESC(pAdvantage600LCM->sTRAN_DESC,100);
   LifeCycleManagementSegment::instance()->setDATA_PRIV_ACQ_FMT(ntohs(pAdvantage600LCM->siDATA_PRIV_ACQ_FMT));
   LifeCycleManagementSegment::instance()->setDATA_PRIV_ACQ(pAdvantage600LCM->sDATA_PRIV_ACQ,100);
   LifeCycleManagementSegment::instance()->setDATA_PRIV_ISS_FMT(ntohs(pAdvantage600LCM->siDATA_PRIV_ISS_FMT));
   LifeCycleManagementSegment::instance()->setDATA_PRIV_ISS(pAdvantage600LCM->sDATA_PRIV_ISS,100);
   LifeCycleManagementSegment::instance()->setADL_DATA_NATIONAL(pAdvantage600LCM->sADL_DATA_NATIONAL,100);
   LifeCycleManagementSegment::instance()->setADL_DATA_PRIV_ACQ(pAdvantage600LCM->sADL_DATA_PRIV_ACQ,255);
   LifeCycleManagementSegment::instance()->setADL_DATA_PRIV_ISS(pAdvantage600LCM->sADL_DATA_PRIV_ACQ,255);
   LifeCycleManagementSegment::instance()->setREF_DATA_ACQ_FMT(&pAdvantage600LCM->cREF_DATA_ACQ_FMT,1);
   LifeCycleManagementSegment::instance()->setREF_DATA_ACQ(pAdvantage600LCM->sREF_DATA_ACQ,99);
   LifeCycleManagementSegment::instance()->setREF_DATA_ISS_FMT(&pAdvantage600LCM->cREF_DATA_ISS_FMT,1);
   LifeCycleManagementSegment::instance()->setREF_DATA_ISS(pAdvantage600LCM->sREF_DATA_ISS,99);
   LifeCycleManagementSegment::instance()->setORIG_PROCESS_ID_ISS(pAdvantage600LCM->sORIG_PROCESS_ID_ISS,6);
   LifeCycleManagementSegment::instance()->setORIG_PROC_ID_ISS(pAdvantage600LCM->sORIG_PROC_ID_ISS,6);
   LifeCycleManagementSegment::instance()->setORIG_NET_ID_ISS(pAdvantage600LCM->sORIG_NET_ID_ISS,3);
   LifeCycleManagementSegment::instance()->setORIG_DATE_RECON_ISS(pAdvantage600LCM->sORIG_DATE_RECON_ISS,6);
   LifeCycleManagementSegment::instance()->setPROCESS_ID_RECV(pAdvantage600LCM->sPROCESS_ID_RECV,6);
   LifeCycleManagementSegment::instance()->setPROC_ID_RECV(pAdvantage600LCM->sPROC_ID_RECV,6);
   LifeCycleManagementSegment::instance()->setNET_ID_RECV(pAdvantage600LCM->sNET_ID_RECV,3);
   LifeCycleManagementSegment::instance()->setDATE_RECON_RECV(pAdvantage600LCM->sDATE_RECON_RECV,6);
   LifeCycleManagementSegment::instance()->setLEN_PAYMENT_TOKEN_DATA(pAdvantage600LCM->sLEN_PAYMENT_TOKEN_DATA,3);
   LifeCycleManagementSegment::instance()->setPAYMENT_TOKEN_DATA(pAdvantage600LCM->sPAYMENT_TOKEN_DATA,999);

   char sFlags16[17] = {"NNNNNNNNNNNNNNNN"};
   processFlags(sFlags16, pAdvantage600LCM->sDATE_RECON_RECV+6);
   LifeCycleManagementSegment::instance()->setPROC_FLGS1(sFlags16,16); 
   processFlags(sFlags16, pAdvantage600LCM->sDATE_RECON_RECV+8);
   LifeCycleManagementSegment::instance()->setPROC_FLGS2(sFlags16,16); 
   processFlags(sFlags16, pAdvantage600LCM->sDATE_RECON_RECV+10);
   LifeCycleManagementSegment::instance()->setPROC_FLGS3(sFlags16,16); 
   processFlags(sFlags16, pAdvantage600LCM->sDATE_RECON_RECV+12);
   LifeCycleManagementSegment::instance()->setPROC_FLGS4(sFlags16,16); 

   LifeCycleManagementSegment::instance()->setCIRC_ID(pAdvantage600LCM->sCIRC_ID,8);
   LifeCycleManagementSegment::instance()->setTSAP_ID(pAdvantage600LCM->sTSAP_ID,8);
   LifeCycleManagementSegment::instance()->setTSAP_IDX(ntohl(pAdvantage600LCM->lTSAP_IDX));
   LifeCycleManagementSegment::instance()->setTSAP_MSG_SEQ_NO(ntohs(pAdvantage600LCM->siTSAP_MSG_SEQ_NO));
   LifeCycleManagementSegment::instance()->setSS_QUEUE_ID(ntohl(pAdvantage600LCM->lSS_QUEUE_ID));
   LifeCycleManagementSegment::instance()->setROUTE_LIST_ID(pAdvantage600LCM->sROUTE_LIST_ID,8);
   LifeCycleManagementSegment::instance()->setCOPT_ICHG_ID(pAdvantage600LCM->sCOPT_ICHG_ID,8);
   LifeCycleManagementSegment::instance()->setPMC_ERROR(ntohs(pAdvantage600LCM->siPMC_ERROR));
   LifeCycleManagementSegment::instance()->setCNX_NET_ID(pAdvantage600LCM->sCNX_NET_ID,4);
   LifeCycleManagementSegment::instance()->setDATE_RECON_NET(pAdvantage600LCM->sDATE_RECON_NET,8);
   string strTSTAMP_TRANS(NonStopClock::getYYYYMMDDHHMMSShh(pAdvantage600LCM->sTSTAMP_TRANS));
   LifeCycleManagementSegment::instance()->setTSTAMP_TRANS(strTSTAMP_TRANS.data(),16);
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      LifeCycleManagementSegment::instance()->setTSTAMP_TRANS(strTemp.data(),16);
      LifeCycleManagementSegment::instance()->setTSTAMP_LOCAL(strTemp.data(),14);
   }
   LifeCycleManagementSegment::instance()->setFORMAT_RESULT(ntohs(pAdvantage600LCM->siFORMAT_RESULT));
   database::UniquenessKey::hash(LifeCycleManagementSegment::instance()->zPAN(),16);
   database::UniquenessKey::hash(LifeCycleManagementSegment::instance()->zSYS_TRACE_AUDIT_NO(),6);
   database::UniquenessKey::hash(LifeCycleManagementSegment::instance()->zTSTAMP_LOCAL(),14);
   database::UniquenessKey::hash(LifeCycleManagementSegment::instance()->zRETRIEVAL_REF_NO(),12);
   database::UniquenessKey::hash(LifeCycleManagementSegment::instance()->zPROCESS_CODE(),6);
   LifeCycleManagementSegment::instance()->setUNIQUENESS_KEY(database::UniquenessKey::getHash());

   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   LifeCycleManagementSegment::instance()->write(&psBuffer);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   LifeCycleManagementSegment::instance()->wipe("PAN");
   return true;
  //## end AdvantageMessage600Lcm::insert%5718DEFE024D.body
}

void AdvantageMessage600Lcm::processFlags (char *psFlags, char* pInFlags)
{
  //## begin AdvantageMessage600Lcm::processFlags%574EAAC501A7.body preserve=yes
#include "CXODRU32.hpp"
struct hFlags
{
#ifdef _LITTLE_ENDIAN
   unsigned bFlag7 : 1;
   unsigned bFlag6 : 1;
   unsigned bFlag5 : 1;
   unsigned bFlag4 : 1;
   unsigned bFlag3 : 1;
   unsigned bFlag2 : 1;
   unsigned bFlag1 : 1;
   unsigned bFlag0 : 1;
   unsigned bFlag15 : 1;
   unsigned bFlag14 : 1;
   unsigned bFlag13 : 1;
   unsigned bFlag12 : 1;
   unsigned bFlag11 : 1;
   unsigned bFlag10 : 1;
   unsigned bFlag9 : 1;
   unsigned bFlag8 : 1;
#else
   unsigned bFlag0 : 1;
   unsigned bFlag1 : 1;
   unsigned bFlag2 : 1;
   unsigned bFlag3 : 1;
   unsigned bFlag4 : 1;
   unsigned bFlag5 : 1;
   unsigned bFlag6 : 1;
   unsigned bFlag7 : 1;
   unsigned bFlag8 : 1;
   unsigned bFlag9 : 1;
   unsigned bFlag10 : 1;
   unsigned bFlag11 : 1;
   unsigned bFlag12 : 1;
   unsigned bFlag13 : 1;
   unsigned bFlag14 : 1;
   unsigned bFlag15 : 1;
#endif
};
#include "CXODRU33.hpp"

   memset(psFlags,'N',16);
   hFlags* pFlags = (hFlags*)pInFlags;
   if (pFlags->bFlag0)
      psFlags[0] = 'Y';
   if (pFlags->bFlag1)
      psFlags[1] = 'Y';
   if (pFlags->bFlag2)
      psFlags[2] = 'Y';
   if (pFlags->bFlag3)
      psFlags[3] = 'Y';
   if (pFlags->bFlag4)
      psFlags[4] = 'Y';
   if (pFlags->bFlag5)
      psFlags[5] = 'Y';
   if (pFlags->bFlag6)
      psFlags[6] = 'Y';
   if (pFlags->bFlag7)
      psFlags[7] = 'Y';

   if (pFlags->bFlag8)
      psFlags[8] = 'Y';
   if (pFlags->bFlag9)
      psFlags[9] = 'Y';
   if (pFlags->bFlag10)
      psFlags[10] = 'Y';
   if (pFlags->bFlag11)
      psFlags[11] = 'Y';
   if (pFlags->bFlag12)
      psFlags[12] = 'Y';
   if (pFlags->bFlag13)
      psFlags[13] = 'Y';
   if (pFlags->bFlag14)
      psFlags[14] = 'Y';
   if (pFlags->bFlag15)
      psFlags[15] = 'Y';
  //## end AdvantageMessage600Lcm::processFlags%574EAAC501A7.body
}

void AdvantageMessage600Lcm::translate (char* pBuffer, int ilen)
{
  //## begin AdvantageMessage600Lcm::translate%57276A660041.body preserve=yes
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
      CodeTable::translate(pBuffer,ilen,CodeTable::CX_ASCII_TO_EBCDIC);
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
      CodeTable::translate(pBuffer,ilen,CodeTable::CX_EBCDIC_TO_ASCII);
#endif
  //## end AdvantageMessage600Lcm::translate%57276A660041.body
}

// Additional Declarations
  //## begin AdvantageMessage600Lcm%5718D07200E8.declarations preserve=yes
  //## end AdvantageMessage600Lcm%5718D07200E8.declarations

//## begin module%5718DBB5018D.epilog preserve=yes
//## end module%5718DBB5018D.epilog
