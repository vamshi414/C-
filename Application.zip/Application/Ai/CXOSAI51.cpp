//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%6214E82B024F.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%6214E82B024F.cm

//## begin module%6214E82B024F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%6214E82B024F.cp

//## Module: CXOSAI51%6214E82B024F; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Ai\CXOSAI51.cpp

//## begin module%6214E82B024F.additionalIncludes preserve=no
//## end module%6214E82B024F.additionalIncludes

//## begin module%6214E82B024F.includes preserve=yes
//## end module%6214E82B024F.includes

#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSRS93_h
#include "CXODRS93.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSAI51_h
#include "CXODAI51.hpp"
#endif


//## begin module%6214E82B024F.declarations preserve=no
//## end module%6214E82B024F.declarations

//## begin module%6214E82B024F.additionalDeclarations preserve=yes
//## end module%6214E82B024F.additionalDeclarations


// Class Advantage0466Exception 

Advantage0466Exception::Advantage0466Exception()
  //## begin Advantage0466Exception::Advantage0466Exception%6214DD650112_const.hasinit preserve=no
  //## end Advantage0466Exception::Advantage0466Exception%6214DD650112_const.hasinit
  //## begin Advantage0466Exception::Advantage0466Exception%6214DD650112_const.initialization preserve=yes
  : AdvantageMessage("0466","S200")
  //## end Advantage0466Exception::Advantage0466Exception%6214DD650112_const.initialization
{
  //## begin Advantage0466Exception::Advantage0466Exception%6214DD650112_const.body preserve=yes
   memcpy(m_sID,"AI51",4);
  //## end Advantage0466Exception::Advantage0466Exception%6214DD650112_const.body
}


Advantage0466Exception::~Advantage0466Exception()
{
  //## begin Advantage0466Exception::~Advantage0466Exception%6214DD650112_dest.body preserve=yes
  //## end Advantage0466Exception::~Advantage0466Exception%6214DD650112_dest.body
}



//## Other Operations (implementation)
bool Advantage0466Exception::insert (Message& hMessage)
{
  //## begin Advantage0466Exception::insert%6214E4D10046.body preserve=yes
   FinancialExceptionSegment::instance()->reset();
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   hAS2805Adjustment* pAdjustment = (hAS2805Adjustment*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   char sTranId[4];
   memcpy(sTranId, pAdjustment->sTranId, 4);
   char sLen[5] = { "    " };
   memcpy(sLen, pAdjustment->sLength, 4);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(sTranId, 4, CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pV13AdvantageHeader->sHdrSource, sizeof(pV13AdvantageHeader->sHdrSource), CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sTranDate, 12, CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sUsageCode, 2, CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sUserField1, 2, CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sUserField2, 6, CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(sLen, 4, CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(sTranId, 4, CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pV13AdvantageHeader->sHdrSource, sizeof(pV13AdvantageHeader->sHdrSource), CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sTranDate, 12, CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sUsageCode, 2, CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sUserField1, 2, CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sUserField2, 6, CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(sLen, 4, CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   // This class will only handle 466 messages that have a tranid of x044,x048,x051,x057,x106
   if (memcmp(sTranId, "X044", 4) != 0
      && memcmp(sTranId, "X048", 4) != 0
      && memcmp(sTranId, "X051", 4) != 0
      && memcmp(sTranId, "X057", 4) != 0
      && memcmp(sTranId, "X106", 4) != 0)
      return false;
   UseCase hUseCase("TANDEM", "## AD29 READ 0466 EXCPTNS", false);
   string strTSTAMP_TRANS("20");
   strTSTAMP_TRANS.append(pAdjustment->sTranDate, 12);
   strTSTAMP_TRANS.append("00");
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      strTSTAMP_TRANS = strTemp;
   }
   FinancialExceptionSegment::instance()->setTSTAMP_TRANS(strTSTAMP_TRANS.data(), strTSTAMP_TRANS.length());
   FinancialExceptionSegment::instance()->setMSG_SOURCE(pV13AdvantageHeader->sHdrSource, sizeof(pV13AdvantageHeader->sHdrSource));
   char szTemp[PERCENTD];
   snprintf(szTemp, sizeof(szTemp), "%04d", ntohs(pV13AdvantageHeader->siHdrMsgCode));
   FinancialExceptionSegment::instance()->setMSG_CODE(szTemp, strlen(szTemp));
   snprintf(szTemp, sizeof(szTemp), "%02d", ntohs(pV13AdvantageHeader->siHdrMsgStep));
   FinancialExceptionSegment::instance()->setSTEP_CODE(szTemp, strlen(szTemp));
   FinancialExceptionSegment::instance()->setMSG_USAGE(pAdjustment->sUsageCode, sizeof(pAdjustment->sUsageCode));
   FinancialExceptionSegment::instance()->setUSER_FIELD1(pAdjustment->sUserField1, sizeof(pAdjustment->sUserField1));
   FinancialExceptionSegment::instance()->setUSER_FIELD2(pAdjustment->sUserField2, sizeof(pAdjustment->sUserField2));
   FinancialExceptionSegment::instance()->setTRAN_DATA_FMT(" ");
   FinancialExceptionSegment::instance()->setPROC_GRP_ID(" ");
   FinancialExceptionSegment::instance()->setTRAN_DATA(sTranId,sizeof(sTranId));
   hMessage.reset("AI LE ", "S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   FinancialExceptionSegment::instance()->write(&psBuffer);
   memcpy(psBuffer, "Z999", 4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end Advantage0466Exception::insert%6214E4D10046.body
}

// Additional Declarations
  //## begin Advantage0466Exception%6214DD650112.declarations preserve=yes
  //## end Advantage0466Exception%6214DD650112.declarations

//## begin module%6214E82B024F.epilog preserve=yes
//## end module%6214E82B024F.epilog
