//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3C613A4F03D8.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C613A4F03D8.cm

//## begin module%3C613A4F03D8.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3C613A4F03D8.cp

//## Module: CXOSAI16%3C613A4F03D8; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXODAI16.hpp

#ifndef CXOSAI16_h
#define CXOSAI16_h 1

//## begin module%3C613A4F03D8.additionalIncludes preserve=no
//## end module%3C613A4F03D8.additionalIncludes

//## begin module%3C613A4F03D8.includes preserve=yes
// $Date:   Jul 24 2009 09:20:26  $ $Author:   D02405  $ $Revision:   1.12  $
//## end module%3C613A4F03D8.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
#ifndef CXOSRS42_h
#include "CXODRS42.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Foundation::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
class DateTime;
} // namespace IF

class AdvantageMessageProcessor;

//## begin module%3C613A4F03D8.declarations preserve=no
//## end module%3C613A4F03D8.declarations

//## begin module%3C613A4F03D8.additionalDeclarations preserve=yes
//## end module%3C613A4F03D8.additionalDeclarations


//## begin AdvantageTerminalAdmin%3C61342403C8.preface preserve=yes
//## end AdvantageTerminalAdmin%3C61342403C8.preface

//## Class: AdvantageTerminalAdmin%3C61342403C8
//## Category: Platform \: Advantage::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3C63C718033C;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C63C72C02AF;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%3C63C74100DA;IF::Message { -> F}
//## Uses: <unnamed>%3C63C752002E;IF::DateTime { -> F}
//## Uses: <unnamed>%3C63C76200BB;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3C63C7980222;IF::CodeTable { -> F}
//## Uses: <unnamed>%3C63C7A001C5;process::Application { -> F}

class AdvantageTerminalAdmin : public AdvantageMessage  //## Inherits: <unnamed>%3C61343302FD
{
  //## begin AdvantageTerminalAdmin%3C61342403C8.initialDeclarations preserve=yes
  //## end AdvantageTerminalAdmin%3C61342403C8.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageTerminalAdmin();

    //## Destructor (generated)
      virtual ~AdvantageTerminalAdmin();


    //## Other Operations (specified)
      //## Operation: insert%3C6183BD0399
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantageTerminalAdmin%3C61342403C8.public preserve=yes
      //## end AdvantageTerminalAdmin%3C61342403C8.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageTerminalAdmin%3C61342403C8.protected preserve=yes
      //## end AdvantageTerminalAdmin%3C61342403C8.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageTerminalAdmin%3C61342403C8.private preserve=yes
      //## end AdvantageTerminalAdmin%3C61342403C8.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: INST_ID_RECN_ACQ_BandRPT_LVL_ID_B%3E201A3D02AF
      //## begin AdvantageTerminalAdmin::INST_ID_RECN_ACQ_BandRPT_LVL_ID_B%3E201A3D02AF.attr preserve=no  private: string {V} 
      string m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B;
      //## end AdvantageTerminalAdmin::INST_ID_RECN_ACQ_BandRPT_LVL_ID_B%3E201A3D02AF.attr

    // Data Members for Associations

      //## Association: Platform \: Advantage::AcquirerInterface_CAT::<unnamed>%3D63E6E50261
      //## Role: AdvantageTerminalAdmin::<m_hDeviceAdminSegment>%3D63E6E7009C
      //## begin AdvantageTerminalAdmin::<m_hDeviceAdminSegment>%3D63E6E7009C.role preserve=no  public: repositorysegment::DeviceAdminSegment { -> VHgN}
      repositorysegment::DeviceAdminSegment m_hDeviceAdminSegment;
      //## end AdvantageTerminalAdmin::<m_hDeviceAdminSegment>%3D63E6E7009C.role

    // Additional Implementation Declarations
      //## begin AdvantageTerminalAdmin%3C61342403C8.implementation preserve=yes
      //## end AdvantageTerminalAdmin%3C61342403C8.implementation

};

//## begin AdvantageTerminalAdmin%3C61342403C8.postscript preserve=yes
//## end AdvantageTerminalAdmin%3C61342403C8.postscript

//## begin module%3C613A4F03D8.epilog preserve=yes
//## end module%3C613A4F03D8.epilog


#endif
