//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%57271D3D026B.cm preserve=no
//	$Date:   Jul 25 2018 14:49:54  $ $Author:   e1009610  $
//	$Revision:   1.7  $
//## end module%57271D3D026B.cm

//## begin module%57271D3D026B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%57271D3D026B.cp

//## Module: CXOSAI24%57271D3D026B; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXOSAI24.cpp

//## begin module%57271D3D026B.additionalIncludes preserve=no
//## end module%57271D3D026B.additionalIncludes

//## begin module%57271D3D026B.includes preserve=yes
//## end module%57271D3D026B.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSRU37_h
#include "CXODRU37.hpp"
#endif
#ifndef CXOSDB49_h
#include "CXODDB49.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSRSA0_h
#include "CXODRSA0.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSAI24_h
#include "CXODAI24.hpp"
#endif


//## begin module%57271D3D026B.declarations preserve=no
//## end module%57271D3D026B.declarations

//## begin module%57271D3D026B.additionalDeclarations preserve=yes
#include "CXODIF16.hpp"
//## end module%57271D3D026B.additionalDeclarations


// Class AdvantageMessage450Lcm

AdvantageMessage450Lcm::AdvantageMessage450Lcm()
  //## begin AdvantageMessage450Lcm::AdvantageMessage450Lcm%57271CE60284_const.hasinit preserve=no
  //## end AdvantageMessage450Lcm::AdvantageMessage450Lcm%57271CE60284_const.hasinit
  //## begin AdvantageMessage450Lcm::AdvantageMessage450Lcm%57271CE60284_const.initialization preserve=yes
  : AdvantageMessage("0450","S450"),
    m_bLCM_EXP_DATE(false)
  //## end AdvantageMessage450Lcm::AdvantageMessage450Lcm%57271CE60284_const.initialization
{
  //## begin AdvantageMessage450Lcm::AdvantageMessage450Lcm%57271CE60284_const.body preserve=yes
   memcpy(m_sID,"AI24",4);
   string strRecord;
   Extract::instance()->getRecord("DUSER   ",strRecord);
   m_bLCM_EXP_DATE = strRecord.find("LCM_EXP_DATE") != string::npos;

  //## end AdvantageMessage450Lcm::AdvantageMessage450Lcm%57271CE60284_const.body
}


AdvantageMessage450Lcm::~AdvantageMessage450Lcm()
{
  //## begin AdvantageMessage450Lcm::~AdvantageMessage450Lcm%57271CE60284_dest.body preserve=yes
  //## end AdvantageMessage450Lcm::~AdvantageMessage450Lcm%57271CE60284_dest.body
}



//## Other Operations (implementation)
bool AdvantageMessage450Lcm::insert (IF::Message& hMessage)
{
  //## begin AdvantageMessage450Lcm::insert%57271ED001C9.body preserve=yes
   LifeCycleManagementSegment::instance()->reset();
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   hAdvantage450LCM* pAdvantage450LCM = (hAdvantage450LCM*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   translate(pAdvantage450LCM->sMTI,(pAdvantage450LCM->sTSTAMP_TRANS - pAdvantage450LCM->sMTI));
   translate(pAdvantage450LCM->sTRANSPORT_DATA,(pAdvantage450LCM->sCARD_MAINT_ROUTING_ID - pAdvantage450LCM->sTRANSPORT_DATA) + 8);
   translate(pAdvantage450LCM->sTSAP_ID,((char *)(&pAdvantage450LCM->lTSAP_IDX) - pAdvantage450LCM->sTSAP_ID));
   translate(pAdvantage450LCM->sDATE_ACTION,((char *)(&pAdvantage450LCM->siPMC_ERROR) - pAdvantage450LCM->sDATE_ACTION));
   translate(pAdvantage450LCM->sSECURITY_CODE,(pAdvantage450LCM->sPAYMENT_TOKEN_DATA_ISO - pAdvantage450LCM->sSECURITY_CODE) + 999);
   UseCase hUseCase("TANDEM","## AD32 READ 0450 LCMS",false);
   string strMSG_CODE("0450");
   LifeCycleManagementSegment::instance()->setMSG_CODE(strMSG_CODE.data(),strMSG_CODE.length());
   LifeCycleManagementSegment::instance()->setMTI(pAdvantage450LCM->sMTI,4);
   LifeCycleManagementSegment::instance()->setFUNC_CODE(pAdvantage450LCM->sFUNC_CODE,3);
   LifeCycleManagementSegment::instance()->setACT_CODE(pAdvantage450LCM->sACT_CODE,3);
   LifeCycleManagementSegment::instance()->setMSG_REASON_CODE(pAdvantage450LCM->sMSG_REASON_CODE,4);
   if (pAdvantage450LCM->sTSTAMP_LOCAL[0] != ' ')
   {
      char sDateTime14[15] = {"20            "};
      memcpy(sDateTime14+2, pAdvantage450LCM->sTSTAMP_LOCAL,12);
      LifeCycleManagementSegment::instance()->setTSTAMP_LOCAL(sDateTime14,14);
   }
   LifeCycleManagementSegment::instance()->setSYS_TRACE_AUDIT_NO(pAdvantage450LCM->sSYS_TRACE_AUDIT_NO,6);
   LifeCycleManagementSegment::instance()->setFILE_NAME(pAdvantage450LCM->sFILE_NAME,17);
   LifeCycleManagementSegment::instance()->setPAN(pAdvantage450LCM->sPAN,28);
   LifeCycleManagementSegment::instance()->setCARD_SEQ_NO(pAdvantage450LCM->sCARD_SEQ_NO,5);
   LifeCycleManagementSegment::instance()->setNET_ID_ISS(pAdvantage450LCM->sNET_ID_ISS,3);
   LifeCycleManagementSegment::instance()->setPROCESS_ID_ISS(pAdvantage450LCM->sPROCESS_ID_ISS,6);
   LifeCycleManagementSegment::instance()->setPROC_ID_ISS(pAdvantage450LCM->sPROC_ID_ISS,6);
   LifeCycleManagementSegment::instance()->setINST_ID_RECON_ISS(pAdvantage450LCM->sINST_ID_RECON_ISS,11);
   LifeCycleManagementSegment::instance()->setFILE_SELECT(&pAdvantage450LCM->cFILE_SELECT,1);
   LifeCycleManagementSegment::instance()->setINST_ID_ISS(pAdvantage450LCM->sINST_ID_ISS,11);
   LifeCycleManagementSegment::instance()->setINST_ID_ACQ(pAdvantage450LCM->sINST_ID_ACQ,11);
   LifeCycleManagementSegment::instance()->setINST_ID_FWD(pAdvantage450LCM->sINST_ID_FWD,11);

   if (memcmp(LifeCycleManagementSegment::instance()->zINST_ID_ISS(),"           ",11) != 0)
   {
      string strINST_ID_RECN_ISS_B;
      if (ConfigurationRepository::instance()->mapItem("X_INST_ID_RECON",(string)LifeCycleManagementSegment::instance()->zINST_ID_RECON_ISS(),(string)LifeCycleManagementSegment::instance()->zINST_ID_ISS(),"I",strINST_ID_RECN_ISS_B))
      {
         if (strINST_ID_RECN_ISS_B == "INST_ID_***")
         {
            strINST_ID_RECN_ISS_B.assign(LifeCycleManagementSegment::instance()->zINST_ID_ISS());
            size_t pos = strINST_ID_RECN_ISS_B.find_first_of(" ");
            if (pos != string::npos)
               strINST_ID_RECN_ISS_B.erase(pos);
            if (strINST_ID_RECN_ISS_B.length() == 6)
               strINST_ID_RECN_ISS_B.append("001");
         }
      }
      else
         strINST_ID_RECN_ISS_B.assign(LifeCycleManagementSegment::instance()->zINST_ID_RECON_ISS(),11);
      LifeCycleManagementSegment::instance()->setINST_ID_RECN_ISS_B(strINST_ID_RECN_ISS_B.data(),strINST_ID_RECN_ISS_B.length());

      string strPROC_ID_ISS_B;
      if (ConfigurationRepository::instance()->translate("INSTITUTION",strINST_ID_RECN_ISS_B,strPROC_ID_ISS_B,"FIN_PROVISION","PROC_ID_ISS_B",0,0))
      {
         LifeCycleManagementSegment::instance()->setPROC_ID_ISS_B(strPROC_ID_ISS_B.data(),strPROC_ID_ISS_B.length());
         string strPROC_GRP_ID_ISS_B;
         if (ConfigurationRepository::instance()->translate("PROCESSOR",strPROC_ID_ISS_B,strPROC_GRP_ID_ISS_B,"FIN_PROVISION","PROC_GRP_ID_ISS_B",0,0))
            LifeCycleManagementSegment::instance()->setPROC_GRP_ID_ISS_B(strPROC_GRP_ID_ISS_B.data(),strPROC_GRP_ID_ISS_B.length());
      }
   }

   if (memcmp(LifeCycleManagementSegment::instance()->zINST_ID_ACQ(),"           ",11) != 0)
   {
      string strINST_ID_RECN_ACQ_B;
      string strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B;
      string strNET_TERM_ID(pAdvantage450LCM->sNET_TERM_ID,8);
      LifeCycleManagementSegment::instance()->setINST_ID_RECON_ACQ(pAdvantage450LCM->sINST_ID_ACQ,11);
      bool bOverride = ConfigurationRepository::instance()->mapItem("X_INST_ID_RECON",(string)LifeCycleManagementSegment::instance()->zINST_ID_RECON_ACQ(),(string)LifeCycleManagementSegment::instance()->zINST_ID_ACQ(),"A",strINST_ID_RECN_ACQ_B);
      if (bOverride && strINST_ID_RECN_ACQ_B == "INST_ID_***")
      {
         strINST_ID_RECN_ACQ_B.assign(LifeCycleManagementSegment::instance()->zINST_ID_ACQ());
         size_t pos = strINST_ID_RECN_ACQ_B.find_first_of(" ");
         if (pos != string::npos)
            strINST_ID_RECN_ACQ_B.erase(pos);
         if (strINST_ID_RECN_ACQ_B.length() == 6)
            strINST_ID_RECN_ACQ_B.append("001");
         LifeCycleManagementSegment::instance()->setINST_ID_RECN_ACQ_B(strINST_ID_RECN_ACQ_B.data(),strINST_ID_RECN_ACQ_B.length());
      }

      if (ConfigurationRepository::instance()->translate("DEVICE",strNET_TERM_ID,strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B,"FIN_PROVISION","INST_ID_RECN_ACQ_B",0,0))
      {
         if (strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.length() > 0)
         {
            strINST_ID_RECN_ACQ_B.assign(strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.data(),11);
            if (strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.length() > 11)
               LifeCycleManagementSegment::instance()->setRPT_LVL_ID_B(strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.data() + 11,strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.length() - 11);
         }
         LifeCycleManagementSegment::instance()->setINST_ID_RECN_ACQ_B(strINST_ID_RECN_ACQ_B.data(),strINST_ID_RECN_ACQ_B.length());
         string strPROC_ID_ACQ_B;
         if (ConfigurationRepository::instance()->translate("INSTITUTION",strINST_ID_RECN_ACQ_B,strPROC_ID_ACQ_B,"FIN_PROVISION","PROC_ID_ACQ_B",0,0))
         {
            LifeCycleManagementSegment::instance()->setPROC_ID_ACQ_B(strPROC_ID_ACQ_B.data(),strPROC_ID_ACQ_B.length());
            string strPROC_GRP_ID_ACQ_B;
            if (ConfigurationRepository::instance()->translate("PROCESSOR",strPROC_ID_ACQ_B,strPROC_GRP_ID_ACQ_B,"FIN_PROVISION","PROC_GRP_ID_ACQ_B",0,0))
               LifeCycleManagementSegment::instance()->setPROC_GRP_ID_ACQ_B(strPROC_GRP_ID_ACQ_B.data(),strPROC_GRP_ID_ACQ_B.length());
         }
      }
   }

   LifeCycleManagementSegment::instance()->setCNTRY_PAN(pAdvantage450LCM->sCNTRY_PAN,3);
   LifeCycleManagementSegment::instance()->setORIG_NET_ID_ISS(pAdvantage450LCM->sORIG_NET_ID_ISS,3);
   LifeCycleManagementSegment::instance()->setORIG_PROCESS_ID_ISS(pAdvantage450LCM->sORIG_PROCESS_ID_ISS,6);
   LifeCycleManagementSegment::instance()->setORIG_PROC_ID_ISS(pAdvantage450LCM->sORIG_PROC_ID_ISS,6);
   LifeCycleManagementSegment::instance()->setORIG_INST_ID_ISS(pAdvantage450LCM->sORIG_INST_ID_ISS,11);
   LifeCycleManagementSegment::instance()->setCNX_NET_ID(pAdvantage450LCM->sCNX_NET_ID,4);
   LifeCycleManagementSegment::instance()->setPRINT_MASK_ID(pAdvantage450LCM->sPRINT_MASK_ID,8);
   LifeCycleManagementSegment::instance()->setTSTAMP_TRANS_RQST(pAdvantage450LCM->sTSTAMP_TRANS_RQST,10);
   LifeCycleManagementSegment::instance()->setUSER_ID(pAdvantage450LCM->sUSER_ID,17);
   LifeCycleManagementSegment::instance()->setADDITIONAL_DATA(pAdvantage450LCM->sADDITIONAL_DATA,50);
   LifeCycleManagementSegment::instance()->setADL_RESP_DATA(pAdvantage450LCM->sADL_RESP_DATA,44);
   string strTSTAMP_TRANS(NonStopClock::getYYYYMMDDHHMMSShh(pAdvantage450LCM->sTSTAMP_TRANS));
   LifeCycleManagementSegment::instance()->setTSTAMP_TRANS(strTSTAMP_TRANS.data(),16);
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      LifeCycleManagementSegment::instance()->setTSTAMP_TRANS(strTemp.data(),16);
      LifeCycleManagementSegment::instance()->setTSTAMP_LOCAL(strTemp.data(),14);
   }
   LifeCycleManagementSegment::instance()->setTRANSPORT_DATA(pAdvantage450LCM->sTRANSPORT_DATA,50);
   LifeCycleManagementSegment::instance()->setCARD_MAINT_ROUTING_ID(pAdvantage450LCM->sCARD_MAINT_ROUTING_ID,8);
   char sFlags16[17] = {"NNNNNNNNNNNNNNNN"};
   processFlags(sFlags16, pAdvantage450LCM->sCARD_MAINT_ROUTING_ID+8);
   LifeCycleManagementSegment::instance()->setPROC_FLGS1(sFlags16,16);
   LifeCycleManagementSegment::instance()->setTSAP_ID(pAdvantage450LCM->sTSAP_ID,8);
   LifeCycleManagementSegment::instance()->setTSAP_IDX(ntohl(pAdvantage450LCM->lTSAP_IDX));
   LifeCycleManagementSegment::instance()->setTSAP_MSG_SEQ_NO(ntohs(pAdvantage450LCM->siTSAP_MSG_SEQ_NO));
   char sDateTime8[9] = {"20      "};
   memcpy(sDateTime8+2, pAdvantage450LCM->sDATE_ACTION,6);
   LifeCycleManagementSegment::instance()->setDATE_ACTION(sDateTime8,8);
   LifeCycleManagementSegment::instance()->setPMC_ERROR(ntohs(pAdvantage450LCM->siPMC_ERROR));
   LifeCycleManagementSegment::instance()->setPROC_QUEUE_ID(ntohl(pAdvantage450LCM->lPROC_QUEUE_ID));
   LifeCycleManagementSegment::instance()->setSS_QUEUE_ID(ntohl(pAdvantage450LCM->lSS_QUEUE_ID));
   LifeCycleManagementSegment::instance()->setSECURITY_CODE(pAdvantage450LCM->sSECURITY_CODE,16);
   LifeCycleManagementSegment::instance()->setPROCESS_CODE(pAdvantage450LCM->sPROCESS_CODE,6);
   if (m_bLCM_EXP_DATE)
      LifeCycleManagementSegment::instance()->setDATE_EXP(pAdvantage450LCM->sDATE_EXP,4);
   char sDateTime6[7] = {"20    "};
   memcpy(sDateTime6+2, pAdvantage450LCM->sDATE_SETTLE,4);
   LifeCycleManagementSegment::instance()->setDATE_SETTLE(sDateTime6,6);
   LifeCycleManagementSegment::instance()->setRESP_CODE(pAdvantage450LCM->sRESP_CODE,2);
   LifeCycleManagementSegment::instance()->setNET_TERM_ID(pAdvantage450LCM->sNET_TERM_ID,8);
   LifeCycleManagementSegment::instance()->setCARD_ACPT_ID(pAdvantage450LCM->sCARD_ACPT_ID,15);
   LifeCycleManagementSegment::instance()->setLEN_PAYMENT_TOKEN_DATA(pAdvantage450LCM->sLEN_PAYMENT_TOKEN_DATA,3);
   LifeCycleManagementSegment::instance()->setPAYMENT_TOKEN_DATA(pAdvantage450LCM->sPAYMENT_TOKEN_DATA,999);
   LifeCycleManagementSegment::instance()->setLEN_PAYMENT_TOKEN_DATA_ISO(pAdvantage450LCM->sLEN_PAYMENT_TOKEN_DATA_ISO,3);
   LifeCycleManagementSegment::instance()->setPAYMENT_TOKEN_DATA_ISO(pAdvantage450LCM->sPAYMENT_TOKEN_DATA_ISO,999);
   LifeCycleManagementSegment::instance()->setADL_DATA_PRIV_ACQ(pAdvantage450LCM->sADL_DATA_PRIV_ACQ,255);
   database::UniquenessKey::hash(LifeCycleManagementSegment::instance()->zPAN(),16);
   database::UniquenessKey::hash(LifeCycleManagementSegment::instance()->zSYS_TRACE_AUDIT_NO(),6);
   database::UniquenessKey::hash(LifeCycleManagementSegment::instance()->zTSTAMP_LOCAL(),14);
   database::UniquenessKey::hash(LifeCycleManagementSegment::instance()->zRETRIEVAL_REF_NO(),12);
   database::UniquenessKey::hash(LifeCycleManagementSegment::instance()->zPROCESS_CODE(),6);
   LifeCycleManagementSegment::instance()->setUNIQUENESS_KEY(database::UniquenessKey::getHash());

   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   LifeCycleManagementSegment::instance()->write(&psBuffer);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   LifeCycleManagementSegment::instance()->wipe("PAN");
   return true;
  //## end AdvantageMessage450Lcm::insert%57271ED001C9.body
}

void AdvantageMessage450Lcm::processFlags (char* psFlags, char* pInFlags)
{
  //## begin AdvantageMessage450Lcm::processFlags%574EB0C50195.body preserve=yes
#include "CXODRU32.hpp"
struct hFlags
{
#ifdef _LITTLE_ENDIAN
   unsigned bFlag7 : 1;
   unsigned bFlag6 : 1;
   unsigned bFlag5 : 1;
   unsigned bFlag4 : 1;
   unsigned bFlag3 : 1;
   unsigned bFlag2 : 1;
   unsigned bFlag1 : 1;
   unsigned bFlag0 : 1;
   unsigned bFlag15 : 1;
   unsigned bFlag14 : 1;
   unsigned bFlag13 : 1;
   unsigned bFlag12 : 1;
   unsigned bFlag11 : 1;
   unsigned bFlag10 : 1;
   unsigned bFlag9 : 1;
   unsigned bFlag8 : 1;
#else
   unsigned bFlag0 : 1;
   unsigned bFlag1 : 1;
   unsigned bFlag2 : 1;
   unsigned bFlag3 : 1;
   unsigned bFlag4 : 1;
   unsigned bFlag5 : 1;
   unsigned bFlag6 : 1;
   unsigned bFlag7 : 1;
   unsigned bFlag8 : 1;
   unsigned bFlag9 : 1;
   unsigned bFlag10 : 1;
   unsigned bFlag11 : 1;
   unsigned bFlag12 : 1;
   unsigned bFlag13 : 1;
   unsigned bFlag14 : 1;
   unsigned bFlag15 : 1;
#endif
};
#include "CXODRU33.hpp"

   memset(psFlags,'N',16);
   hFlags* pFlags = (hFlags*)pInFlags;
   if (pFlags->bFlag0)
      psFlags[0] = 'Y';
   if (pFlags->bFlag1)
      psFlags[1] = 'Y';
   if (pFlags->bFlag2)
      psFlags[2] = 'Y';
   if (pFlags->bFlag3)
      psFlags[3] = 'Y';
   if (pFlags->bFlag4)
      psFlags[4] = 'Y';
   if (pFlags->bFlag5)
      psFlags[5] = 'Y';
   if (pFlags->bFlag6)
      psFlags[6] = 'Y';
   if (pFlags->bFlag7)
      psFlags[7] = 'Y';

   if (pFlags->bFlag8)
      psFlags[8] = 'Y';
   if (pFlags->bFlag9)
      psFlags[9] = 'Y';
   if (pFlags->bFlag10)
      psFlags[10] = 'Y';
   if (pFlags->bFlag11)
      psFlags[11] = 'Y';
   if (pFlags->bFlag12)
      psFlags[12] = 'Y';
   if (pFlags->bFlag13)
      psFlags[13] = 'Y';
   if (pFlags->bFlag14)
      psFlags[14] = 'Y';
   if (pFlags->bFlag15)
      psFlags[15] = 'Y';
  //## end AdvantageMessage450Lcm::processFlags%574EB0C50195.body
}

void AdvantageMessage450Lcm::translate (char* pBuffer, int ilen)
{
  //## begin AdvantageMessage450Lcm::translate%57273079037E.body preserve=yes
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
      CodeTable::translate(pBuffer,ilen,CodeTable::CX_ASCII_TO_EBCDIC);
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
      CodeTable::translate(pBuffer,ilen,CodeTable::CX_EBCDIC_TO_ASCII);
#endif
  //## end AdvantageMessage450Lcm::translate%57273079037E.body
}

// Additional Declarations
  //## begin AdvantageMessage450Lcm%57271CE60284.declarations preserve=yes
  //## end AdvantageMessage450Lcm%57271CE60284.declarations

//## begin module%57271D3D026B.epilog preserve=yes
//## end module%57271D3D026B.epilog
