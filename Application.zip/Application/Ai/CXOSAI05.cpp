//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3C61371B0261.cm preserve=no
//	$Date:   Apr 20 2020 14:40:38  $ $Author:   e1032996  $
//	$Revision:   1.36  $
//## end module%3C61371B0261.cm

//## begin module%3C61371B0261.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%3C61371B0261.cp

//## Module: CXOSAI05%3C61371B0261; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXOSAI05.cpp

//## begin module%3C61371B0261.additionalIncludes preserve=no
//## end module%3C61371B0261.additionalIncludes

//## begin module%3C61371B0261.includes preserve=yes
// $Date:   Apr 20 2020 14:40:38  $ $Author:   e1032996  $ $Revision:   1.36  $
#include "CXODIF03.hpp"
#include "CXODIF11.hpp"
//## end module%3C61371B0261.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSAI05_h
#include "CXODAI05.hpp"
#endif


//## begin module%3C61371B0261.declarations preserve=no
//## end module%3C61371B0261.declarations

//## begin module%3C61371B0261.additionalDeclarations preserve=yes
#define FIELDS200Old 12
struct hAccountHolder200Old* phAccountHolder200Old = 0;
Fields hAccountHolder200Old_Fields[FIELDS200Old + 1] =
{
      "i         ","",offsetof(hAccountHolder200Old,iLedBalI),sizeof(phAccountHolder200Old->iLedBalI),
      "i         ","",offsetof(hAccountHolder200Old,iAvalBalI),sizeof(phAccountHolder200Old->iAvalBalI),
      "i         ","",offsetof(hAccountHolder200Old,iCreditLineAmtI),sizeof(phAccountHolder200Old->iCreditLineAmtI),
      "i         ","",offsetof(hAccountHolder200Old,iUnpDbAmt),sizeof(phAccountHolder200Old->iUnpDbAmt),
      "i         ","",offsetof(hAccountHolder200Old,UnpCrAmt),sizeof(phAccountHolder200Old->UnpCrAmt),
      "i         ","",offsetof(hAccountHolder200Old,UnpAvalCrAmt),sizeof(phAccountHolder200Old->UnpAvalCrAmt),
      "t         ","",offsetof(hAccountHolder200Old,sLastTranTstamp),sizeof(phAccountHolder200Old->sLastTranTstamp),
      "a         ","",offsetof(hAccountHolder200Old,sAcctStatus),sizeof(phAccountHolder200Old->sAcctStatus),
      "b         "," WD DP IQ PT PF TT TF PR 3P DF",offsetof(hAccountHolder200Old,siAcctAccess),sizeof(phAccountHolder200Old->siAcctAccess),
	   "i         ","",offsetof(hAccountHolder200Old,iOdAmt),sizeof(phAccountHolder200Old->iOdAmt),
	   "t         ","",offsetof(hAccountHolder200Old,sUpdtTstamp),sizeof(phAccountHolder200Old->sUpdtTstamp),
	   "t         ","",offsetof(hAccountHolder200Old,sMntTstamp),sizeof(phAccountHolder200Old->sMntTstamp),
      "~","",0,sizeof(hAccountHolder200Old),
};
#define FIELDS200New 12
struct hAccountHolder200New* phAccountHolder200New = 0;
Fields hAccountHolder200New_Fields[FIELDS200New + 1] =
{
      "i         ","",offsetof(hAccountHolder200New,iLedBalI),sizeof(phAccountHolder200New->iLedBalI),
      "i         ","",offsetof(hAccountHolder200New,iAvalBalI),sizeof(phAccountHolder200New->iAvalBalI),
      "i         ","",offsetof(hAccountHolder200New,iCreditLineAmtI),sizeof(phAccountHolder200New->iCreditLineAmtI),
      "i         ","",offsetof(hAccountHolder200New,iUnpDbAmt),sizeof(phAccountHolder200New->iUnpDbAmt),
      "i         ","",offsetof(hAccountHolder200New,UnpCrAmt),sizeof(phAccountHolder200New->UnpCrAmt),
      "i         ","",offsetof(hAccountHolder200New,UnpAvalCrAmt),sizeof(phAccountHolder200New->UnpAvalCrAmt),
      "t         ","",offsetof(hAccountHolder200New,sLastTranTstamp),sizeof(phAccountHolder200New->sLastTranTstamp),
      "a         ","",offsetof(hAccountHolder200New,sAcctStatus),sizeof(phAccountHolder200New->sAcctStatus),
      "b         "," WD DP IQ PT PF TT TF PR 3P DF",offsetof(hAccountHolder200New,siAcctAccess),sizeof(phAccountHolder200New->siAcctAccess),
	   "i         ","",offsetof(hAccountHolder200New,iOdAmt),sizeof(phAccountHolder200New->iOdAmt),
	   "t         ","",offsetof(hAccountHolder200New,sUpdtTstamp),sizeof(phAccountHolder200New->sUpdtTstamp),
	   "t         ","",offsetof(hAccountHolder200New,sMntTstamp),sizeof(phAccountHolder200New->sMntTstamp),
      "~","",0,sizeof(hAccountHolder200New),
};
#define FIELDS201Old 3

struct hAccountHolder201Old* phAccountHolder201Old = 0;
Fields hAccountHolder201Old_Fields[FIELDS201Old + 1] =
{
      "a         ","",offsetof(hAccountHolder201Old,sFiId),sizeof(phAccountHolder201Old->sFiId),
      "a         ","",offsetof(hAccountHolder201Old,sAcctType),sizeof(phAccountHolder201Old->sAcctType),
      "a         ","",offsetof(hAccountHolder201Old,sAcctNo),sizeof(phAccountHolder201Old->sAcctNo),
      "~","",0,sizeof(hAccountHolder201Old),
};
#define FIELDS201New 3
struct hAccountHolder201New* phAccountHolder201New = 0;
Fields hAccountHolder201New_Fields[FIELDS201New + 1] =
{
      "a         ","",offsetof(hAccountHolder201New,sFiId),sizeof(phAccountHolder201New->sFiId),
      "a         ","",offsetof(hAccountHolder201New,sAcctType),sizeof(phAccountHolder201New->sAcctType),
      "a         ","",offsetof(hAccountHolder201New,sAcctNo),sizeof(phAccountHolder201New->sAcctNo),
      "~","",0,sizeof(hAccountHolder201New),
};

#define FIELDS202Old 3
struct hAccountHolder202Old* phAccountHolder202Old = 0;
Fields hAccountHolder202Old_Fields[FIELDS202Old + 1] =
{
      "i         ","",offsetof(hAccountHolder202Old,iAmount),sizeof(phAccountHolder202Old->iAmount),
      "t         ","",offsetof(hAccountHolder202Old,sExpTime),sizeof(phAccountHolder202Old->sExpTime),
      "a         ","",offsetof(hAccountHolder202Old,sMatchData),sizeof(phAccountHolder202Old->sMatchData),
      "~","",0,sizeof(hAccountHolder202Old),
};
#define FIELDS202New 3
struct hAccountHolder202New* phAccountHolder202New = 0;
Fields hAccountHolder202New_Fields[FIELDS202New + 1] =
{
      "i         ","",offsetof(hAccountHolder202New,iAmount),sizeof(phAccountHolder202New->iAmount),
      "t         ","",offsetof(hAccountHolder202New,sExpTime),sizeof(phAccountHolder202New->sExpTime),
      "a         ","",offsetof(hAccountHolder202New,sMatchData),sizeof(phAccountHolder202New->sMatchData),
      "~","",0,sizeof(hAccountHolder202New),
};
#define FIELDS203Old 1
struct hAccountHolder203Old* phAccountHolder203Old = 0;
Fields hAccountHolder203Old_Fields[FIELDS203Old + 1] =
{
      "a         ","",offsetof(hAccountHolder203Old,sAccessGroupId),sizeof(phAccountHolder203Old->sAccessGroupId),
      "~","",0,sizeof(hAccountHolder203Old),
};
#define FIELDS203New 1
struct hAccountHolder203New* phAccountHolder203New = 0;
Fields hAccountHolder203New_Fields[FIELDS203New + 1] =
{
      "a         ","",offsetof(hAccountHolder203New,sAccessGroupId),sizeof(phAccountHolder203New->sAccessGroupId),
      "~","",0,sizeof(hAccountHolder203New),
};
#define FIELDS204Old 6
struct hAccountHolder204Old* phAccountHolder204Old = 0;
Fields hAccountHolder204Old_Fields[FIELDS204Old + 1] =
{
      "a         ","",offsetof(hAccountHolder204Old,sMatchData),sizeof(phAccountHolder204Old->sMatchData),
      "a         ","",offsetof(hAccountHolder204Old,sMerchantName),sizeof(phAccountHolder204Old->sMerchantName),
      "a         ","",offsetof(hAccountHolder204Old,sHoldStatus),sizeof(phAccountHolder204Old->sHoldStatus),
	   "a         ","",offsetof(hAccountHolder204Old,sMerchantCode),sizeof(phAccountHolder204Old->sMerchantCode),
      "a         ","",offsetof(hAccountHolder204Old,sCreateTime),sizeof(phAccountHolder204Old->sCreateTime),
      "a         ","",offsetof(hAccountHolder204Old,sExprUserId),sizeof(phAccountHolder204Old->sExprUserId),
      "~","",0,sizeof(hAccountHolder204Old),
};
#define FIELDS204New 6
struct hAccountHolder204New* phAccountHolder204New = 0;
Fields hAccountHolder204New_Fields[FIELDS204New + 1] =
{
      "a         ","",offsetof(hAccountHolder204New,sMatchData),sizeof(phAccountHolder204New->sMatchData),
      "a         ","",offsetof(hAccountHolder204New,sMerchantName),sizeof(phAccountHolder204New->sMerchantName),
      "a         ","",offsetof(hAccountHolder204New,sHoldStatus),sizeof(phAccountHolder204New->sHoldStatus),
	   "a         ","",offsetof(hAccountHolder204New,sMerchantCode),sizeof(phAccountHolder204New->sMerchantCode),
      "a         ","",offsetof(hAccountHolder204New,sCreateTime),sizeof(phAccountHolder204New->sCreateTime),
      "a         ","",offsetof(hAccountHolder204New,sExprUserId),sizeof(phAccountHolder204New->sExprUserId),
      "~","",0,sizeof(hAccountHolder204New),
};
#define FIELDS205Old 1
struct hAccountHolder205Old* phAccountHolder205Old = 0;
Fields hAccountHolder205Old_Fields[FIELDS205Old + 1] =
{
      "a         ","",offsetof(hAccountHolder205Old,sBalUpdtDate),sizeof(phAccountHolder205Old->sBalUpdtDate),
      "~","",0,sizeof(hAccountHolder205Old),
};
#define FIELDS205New 1
struct hAccountHolder205New* phAccountHolder205New = 0;
Fields hAccountHolder205New_Fields[FIELDS205New + 1] =
{
      "a         ","",offsetof(hAccountHolder205New,sBalUpdtDate),sizeof(phAccountHolder205New->sBalUpdtDate),
      "~","",0,sizeof(hAccountHolder205New),
};

//## end module%3C61371B0261.additionalDeclarations


// Class AdvantageAPAcctMaintenance

AdvantageAPAcctMaintenance::AdvantageAPAcctMaintenance()
  //## begin AdvantageAPAcctMaintenance::AdvantageAPAcctMaintenance%3C61321B0213_const.hasinit preserve=no
  //## end AdvantageAPAcctMaintenance::AdvantageAPAcctMaintenance%3C61321B0213_const.hasinit
  //## begin AdvantageAPAcctMaintenance::AdvantageAPAcctMaintenance%3C61321B0213_const.initialization preserve=yes
   : AdvantageMessage("0860","F001")
  //## end AdvantageAPAcctMaintenance::AdvantageAPAcctMaintenance%3C61321B0213_const.initialization
{
  //## begin AdvantageAPAcctMaintenance::AdvantageAPAcctMaintenance%3C61321B0213_const.body preserve=yes
   memcpy(m_sID,"AI05",4);
   m_hAccountHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("AD01"),make_pair(&hAccountHolder200Old_Fields[0],&hAccountHolder200New_Fields[0])));
   m_hAccountHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("AD02"),make_pair(&hAccountHolder201Old_Fields[0],&hAccountHolder201New_Fields[0])));
   m_hAccountHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("AD03"),make_pair(&hAccountHolder202Old_Fields[0],&hAccountHolder202New_Fields[0])));
   m_hAccountHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("AD06"),make_pair(&hAccountHolder204Old_Fields[0],&hAccountHolder204New_Fields[0])));
   m_hAccountHolder.insert(map<string,pair<Fields*,Fields*>,less<string> >::value_type(string("AD08"),make_pair(&hAccountHolder205Old_Fields[0],&hAccountHolder205New_Fields[0])));
   //## end AdvantageAPAcctMaintenance::AdvantageAPAcctMaintenance%3C61321B0213_const.body
}


AdvantageAPAcctMaintenance::~AdvantageAPAcctMaintenance()
{
  //## begin AdvantageAPAcctMaintenance::~AdvantageAPAcctMaintenance%3C61321B0213_dest.body preserve=yes
  //## end AdvantageAPAcctMaintenance::~AdvantageAPAcctMaintenance%3C61321B0213_dest.body
}



//## Other Operations (implementation)
bool AdvantageAPAcctMaintenance::insert (IF::Message& hMessage)
{
  //## begin AdvantageAPAcctMaintenance::insert%3C618DFC02AF.body preserve=yes
   UseCase hUseCase("TANDEM","## AD15 READ 0860 AP ACCOUNT",false);
   m_hAuditMaintSegment.reset();
   m_hAuditSegment.reset();
   AdvantageMessage::insert(hMessage);
   hV13AdvantageHeader* pAdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   char* pStart = hMessage.data() + sizeof(hV13AdvantageHeader);
   hAccountHolder* pAccountHolder = (hAccountHolder*)(pStart);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pAccountHolder->sRecType,((char*)(&pAccountHolder->siStepNo)-pAccountHolder->sRecType),
      CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAccountHolder->sSourceId,(pAccountHolder->sAcctNo - pAccountHolder->sSourceId + sizeof(pAccountHolder->sAcctNo)),
      CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pAccountHolder->sRecType,((char*)(&pAccountHolder->siStepNo)-pAccountHolder->sRecType),
      CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAccountHolder->sSourceId,(pAccountHolder->sAcctNo - pAccountHolder->sSourceId + sizeof(pAccountHolder->sAcctNo)),
      CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   m_hAuditMaintSegment.setRECORD_TYPE(pAccountHolder->sRecType,4);
   if(pAccountHolder->sFRDABA[10] != ' ')
	   m_hAuditMaintSegment.setINST_ID(pAccountHolder->sFRDABA+1,9);
   else
      m_hAuditMaintSegment.setINST_ID(pAccountHolder->sFRDABA,9);
   char szBusinessKey[34];
   memcpy(szBusinessKey,pAccountHolder->sAcctType,4);
   memcpy(szBusinessKey+4,"~",1);
   KeyRing::instance()->tokenize(pAccountHolder->sAcctNo,28);
   memcpy(szBusinessKey+5,pAccountHolder->sAcctNo,28);
   m_hAuditMaintSegment.setBUSINESS_KEY(szBusinessKey,33);
   switch (ntohs(pAccountHolder->siStepNo))
   {
   case 5:
      m_hAuditMaintSegment.setRECORD_ACTION("A",1);
      break;
   case 6:
      m_hAuditMaintSegment.setRECORD_ACTION("D",1);
      break;
   case 8:
      m_hAuditMaintSegment.setRECORD_ACTION("C",1);
      break;
   default:
      m_hAuditMaintSegment.setRECORD_ACTION("U",1);
      break;
   }
   m_hAuditMaintSegment.setSOURCE_ID(pAccountHolder->sSourceId,16);
   m_hAuditMaintSegment.setTERM_ID(pAccountHolder->sCrtTermIdent,16);
   char* pFormatOld = m_hAuditMaintSegment.zOLD_VALUE();
   char* pFormatNew = m_hAuditMaintSegment.zNEW_VALUE();
   int ilen = 0;
   string strRecType(pAccountHolder->sRecType,4);
   map<string,pair<Fields*,Fields*>,less<string> >::iterator p = m_hAccountHolder.find(strRecType);
   if(p != m_hAccountHolder.end())
   {
      m_hAuditMaintSegment.setField((*p).second.first,'~',pStart + sizeof(hAccountHolder),ilen,&pFormatOld,AdvantageMessageProcessor::instance()->getAsciiInput());
      m_hAuditMaintSegment.setField((*p).second.second,'~',pStart + sizeof(hAccountHolder)+ ilen,ilen,&pFormatNew,AdvantageMessageProcessor::instance()->getAsciiInput());
   }
   char sDateTime16[17] = {"                "};
   char sCentury[2];
   DateTime::calcCentury(pAccountHolder->sTimeStamp,sCentury);
   memcpy(sDateTime16,sCentury,2);
   memcpy(sDateTime16+2,pAccountHolder->sTimeStamp,14);
   string strTSTAMP_TRANS(sDateTime16,16);
   m_hAuditMaintSegment.setTSTAMP_TRANS(strTSTAMP_TRANS.data(),strTSTAMP_TRANS.length());
   if (getTestDate().length())
   {
      string strTemp(getTestDate());
      strTemp +=strTSTAMP_TRANS.substr(8);
      m_hAuditMaintSegment.setTSTAMP_TRANS(strTemp.data(),16);
   }
   unsigned short j = 0;
   int i = 0;
   for (i = 0; i < strlen(pFormatOld); i++)
	   j = 33 * j + m_hAuditMaintSegment.zOLD_VALUE()[i];
   for (i = 0; i < strlen(pFormatNew); i++)
	   j = 33 * j + m_hAuditMaintSegment.zNEW_VALUE()[i];
   if (j > 32767)
	   j -= 32768;
   m_hAuditMaintSegment.setUNIQUENESS_KEY((int)j);

   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_lTstampHash = ntohl(pAdvantageHeader->lHdrTstamp2Hash);
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   m_hAuditMaintSegment.write(&psBuffer);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageAPAcctMaintenance::insert%3C618DFC02AF.body
}

// Additional Declarations
  //## begin AdvantageAPAcctMaintenance%3C61321B0213.declarations preserve=yes
  //## end AdvantageAPAcctMaintenance%3C61321B0213.declarations

//## begin module%3C61371B0261.epilog preserve=yes
//## end module%3C61371B0261.epilog
