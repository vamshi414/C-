//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3C613684029F.cm preserve=no
//	$Date:   Jan 31 2018 14:07:04  $ $Author:   e1009839  $
//	$Revision:   1.13  $
//## end module%3C613684029F.cm

//## begin module%3C613684029F.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%3C613684029F.cp

//## Module: CXOSAI03%3C613684029F; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXODAI03.hpp

#ifndef CXOSAI03_h
#define CXOSAI03_h 1

//## begin module%3C613684029F.additionalIncludes preserve=no
//## end module%3C613684029F.additionalIncludes

//## begin module%3C613684029F.includes preserve=yes
// $Date:   Jan 31 2018 14:07:04  $ $Author:   e1009839  $ $Revision:   1.13  $
//## end module%3C613684029F.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
#ifndef CXOSRS84_h
#include "CXODRS84.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class AdvantageMessageProcessor;
//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class KeyRing;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
class DateTime;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%3C613684029F.declarations preserve=no
//## end module%3C613684029F.declarations

//## begin module%3C613684029F.additionalDeclarations preserve=yes
//## end module%3C613684029F.additionalDeclarations


//## begin AdvantageAPFraudMaintenance%3C6131B30203.preface preserve=yes
//## end AdvantageAPFraudMaintenance%3C6131B30203.preface

//## Class: AdvantageAPFraudMaintenance%3C6131B30203
//## Category: Platform \: FIS Advantage::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3C62F1CE01B5;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C62F34300CB;process::Application { -> F}
//## Uses: <unnamed>%3C62F34E006D;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%3C62F371007D;IF::Message { -> F}
//## Uses: <unnamed>%3C62F3840128;IF::DateTime { -> F}
//## Uses: <unnamed>%3C62F39B007D;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3C62F4990203;IF::CodeTable { -> F}
//## Uses: <unnamed>%4FF49D890037;reusable::KeyRing { -> F}

class AdvantageAPFraudMaintenance : public AdvantageMessage  //## Inherits: <unnamed>%3C6131D60213
{
  //## begin AdvantageAPFraudMaintenance%3C6131B30203.initialDeclarations preserve=yes
  //## end AdvantageAPFraudMaintenance%3C6131B30203.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageAPFraudMaintenance();

    //## Destructor (generated)
      virtual ~AdvantageAPFraudMaintenance();


    //## Other Operations (specified)
      //## Operation: insert%3C618F2B00CB
      virtual bool insert (IF::Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantageAPFraudMaintenance%3C6131B30203.public preserve=yes
      //## end AdvantageAPFraudMaintenance%3C6131B30203.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageAPFraudMaintenance%3C6131B30203.protected preserve=yes
      //## end AdvantageAPFraudMaintenance%3C6131B30203.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageAPFraudMaintenance%3C6131B30203.private preserve=yes
      //## end AdvantageAPFraudMaintenance%3C6131B30203.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: FIS Advantage::AcquirerInterface_CAT::<unnamed>%4FDB7675030E
      //## Role: AdvantageAPFraudMaintenance::<m_hAuditMaintSegment>%4FDB76770157
      //## begin AdvantageAPFraudMaintenance::<m_hAuditMaintSegment>%4FDB76770157.role preserve=no  public: repositorysegment::AuditMaintSegment { -> VHgN}
      repositorysegment::AuditMaintSegment m_hAuditMaintSegment;
      //## end AdvantageAPFraudMaintenance::<m_hAuditMaintSegment>%4FDB76770157.role

    // Additional Implementation Declarations
      //## begin AdvantageAPFraudMaintenance%3C6131B30203.implementation preserve=yes
	  	  map<string,pair<Fields*,Fields*>,less<string> > m_hFraudMaintenance;
      //## end AdvantageAPFraudMaintenance%3C6131B30203.implementation
};

//## begin AdvantageAPFraudMaintenance%3C6131B30203.postscript preserve=yes
//## end AdvantageAPFraudMaintenance%3C6131B30203.postscript

//## begin module%3C613684029F.epilog preserve=yes
//## end module%3C613684029F.epilog


#endif
