//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%3C61371A01E4.cm preserve=no
//	$Date:   May 08 2020 13:31:30  $ $Author:   e1032996  $
//	$Revision:   1.14  $
//## end module%3C61371A01E4.cm

//## begin module%3C61371A01E4.cp preserve=no
//	Copyright (c) 1998 - 2010
//	FIS
//## end module%3C61371A01E4.cp

//## Module: CXOSAI05%3C61371A01E4; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXODAI05.hpp

#ifndef CXOSAI05_h
#define CXOSAI05_h 1

//## begin module%3C61371A01E4.additionalIncludes preserve=no
//## end module%3C61371A01E4.additionalIncludes

//## begin module%3C61371A01E4.includes preserve=yes
// $Date:   May 08 2020 13:31:30  $ $Author:   e1032996  $ $Revision:   1.14  $
//## end module%3C61371A01E4.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
#ifndef CXOSRS84_h
#include "CXODRS84.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class AdvantageMessageProcessor;
//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class KeyRing;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
class DateTime;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%3C61371A01E4.declarations preserve=no
//## end module%3C61371A01E4.declarations

//## begin module%3C61371A01E4.additionalDeclarations preserve=yes
struct hAccountHolder
{
   char sRecType[2];  
   char sSegType[2];   
   short siStepNo;
   char sSourceId[16];
   char sCrtTermIdent[16];
   char sTimeStamp[14];
   char sNegStatKey[6];
   char sFRDABA[10];
   char sAcctType[4]; 
   char sAcctNo[28];
};
struct hAccountHolder200Old
{
   int iLedBalI;
   int iAvalBalI;
   int iCreditLineAmtI;
   int iUnpDbAmt;
   int UnpCrAmt;
   int UnpAvalCrAmt;
   char sLastTranTstamp[8];
   char sAcctStatus[2];
   short siAcctAccess;
   int iOdAmt;
   char sUpdtTstamp[8];
   char sMntTstamp[8];
   
};
struct hAccountHolder200New
{
   int iLedBalI;
   int iAvalBalI;
   int iCreditLineAmtI;
   int iUnpDbAmt;
   int UnpCrAmt;
   int UnpAvalCrAmt;
   char sLastTranTstamp[8];
   char sAcctStatus[2];
   short siAcctAccess;
   int iOdAmt;
   char sUpdtTstamp[8];
   char sMntTstamp[8];
 };
struct hAccountHolder201Old
{
   char sFiId[10]; 
   char sAcctType[4];
   char sAcctNo[28];
};
struct hAccountHolder201New
{
   char sFiId[10]; 
   char sAcctType[4];
   char sAcctNo[28];
};
struct hAccountHolder202Old
{
   int iAmount;
   char sExpTime[8];
   char sMatchData[36];
};
struct hAccountHolder202New
{
   int iAmount;
   char sExpTime[8];
   char sMatchData[36];
};

struct hAccountHolder203Old
{
   char sAccessGroupId[6];
};
struct hAccountHolder203New
{
   char sAccessGroupId[6];
};
struct hAccountHolder204Old
{  
   char sMatchData[36];
   char sMerchantName[25];
   char sHoldStatus;
   char sMerchantCode[4];
   char sCreateTime[8];
   char sExprUserId[32];   
};
struct hAccountHolder204New
{  
   char sMatchData[36];
   char sMerchantName[25];
   char sHoldStatus;
   char sMerchantCode[4];
   char sCreateTime[8];
   char sExprUserId[32];};

struct hAccountHolder205Old
{
   char sBalUpdtDate[8];
};
struct hAccountHolder205New
{
   char sBalUpdtDate[8];    
};
//## end module%3C61371A01E4.additionalDeclarations


//## begin AdvantageAPAcctMaintenance%3C61321B0213.preface preserve=yes
//## end AdvantageAPAcctMaintenance%3C61321B0213.preface

//## Class: AdvantageAPAcctMaintenance%3C61321B0213
//## Category: Platform \: FIS Advantage::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3C62F9B400BB;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C62F9E50290;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%3C62FA0D005D;IF::Message { -> F}
//## Uses: <unnamed>%3C62FA1D002E;IF::DateTime { -> F}
//## Uses: <unnamed>%3C62FA2C0290;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3C62FA580167;IF::CodeTable { -> F}
//## Uses: <unnamed>%3C62FA9501A5;process::Application { -> F}
//## Uses: <unnamed>%4FF49D1C0391;reusable::KeyRing { -> F}

class AdvantageAPAcctMaintenance : public AdvantageMessage  //## Inherits: <unnamed>%3C61323503A9
{
  //## begin AdvantageAPAcctMaintenance%3C61321B0213.initialDeclarations preserve=yes
  //## end AdvantageAPAcctMaintenance%3C61321B0213.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageAPAcctMaintenance();

    //## Destructor (generated)
      virtual ~AdvantageAPAcctMaintenance();


    //## Other Operations (specified)
      //## Operation: insert%3C618DFC02AF
      virtual bool insert (IF::Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantageAPAcctMaintenance%3C61321B0213.public preserve=yes
      //## end AdvantageAPAcctMaintenance%3C61321B0213.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageAPAcctMaintenance%3C61321B0213.protected preserve=yes
      //## end AdvantageAPAcctMaintenance%3C61321B0213.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageAPAcctMaintenance%3C61321B0213.private preserve=yes
      //## end AdvantageAPAcctMaintenance%3C61321B0213.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: FIS Advantage::AcquirerInterface_CAT::<unnamed>%4FDB74CC03BD
      //## Role: AdvantageAPAcctMaintenance::<m_hAuditMaintSegment>%4FDB74CE0116
      //## begin AdvantageAPAcctMaintenance::<m_hAuditMaintSegment>%4FDB74CE0116.role preserve=no  public: repositorysegment::AuditMaintSegment { -> VHgN}
      repositorysegment::AuditMaintSegment m_hAuditMaintSegment;
      //## end AdvantageAPAcctMaintenance::<m_hAuditMaintSegment>%4FDB74CE0116.role

    // Additional Implementation Declarations
      //## begin AdvantageAPAcctMaintenance%3C61321B0213.implementation preserve=yes
	  map<string,pair<Fields*,Fields*>,less<string> > m_hAccountHolder;
      //## end AdvantageAPAcctMaintenance%3C61321B0213.implementation
};

//## begin AdvantageAPAcctMaintenance%3C61321B0213.postscript preserve=yes
//## end AdvantageAPAcctMaintenance%3C61321B0213.postscript

//## begin module%3C61371A01E4.epilog preserve=yes
//## end module%3C61371A01E4.epilog


#endif
