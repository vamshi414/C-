//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A54281A03C2.cm preserve=no
//	$Date:   31 Jan 2018 14:11:12  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5A54281A03C2.cm

//## begin module%5A54281A03C2.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A54281A03C2.cp

//## Module: CXOSAI36%5A54281A03C2; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI36.hpp

#ifndef CXOSAI36_h
#define CXOSAI36_h 1

//## begin module%5A54281A03C2.additionalIncludes preserve=no
//## end module%5A54281A03C2.additionalIncludes

//## begin module%5A54281A03C2.includes preserve=yes
//## end module%5A54281A03C2.includes

#ifndef CXOSAI35_h
#include "CXODAI35.hpp"
#endif
#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
#ifndef CXOSAI33_h
#include "CXODAI33.hpp"
#endif
#ifndef CXOSAI32_h
#include "CXODAI32.hpp"
#endif
#ifndef CXOSAI31_h
#include "CXODAI31.hpp"
#endif
#ifndef CXOSAI30_h
#include "CXODAI30.hpp"
#endif
//## begin module%5A54281A03C2.declarations preserve=no
//## end module%5A54281A03C2.declarations

//## begin module%5A54281A03C2.additionalDeclarations preserve=yes
//## end module%5A54281A03C2.additionalDeclarations


//## begin Exception%5A54261703CA.preface preserve=yes
//## end Exception%5A54261703CA.preface

//## Class: Exception%5A54261703CA
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport Exception : public AdvantageMessage  //## Inherits: <unnamed>%5A542629030D
{
  //## begin Exception%5A54261703CA.initialDeclarations preserve=yes
  //## end Exception%5A54261703CA.initialDeclarations

  public:
    //## Constructors (generated)
      Exception();

    //## Destructor (generated)
      virtual ~Exception();


    //## Other Operations (specified)
      //## Operation: insert%5A54262E02CE
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin Exception%5A54261703CA.public preserve=yes
      //## end Exception%5A54261703CA.public

  protected:
    // Additional Protected Declarations
      //## begin Exception%5A54261703CA.protected preserve=yes
      //## end Exception%5A54261703CA.protected

  private:
    // Additional Private Declarations
      //## begin Exception%5A54261703CA.private preserve=yes
      //## end Exception%5A54261703CA.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5A54266502FD
      //## Role: Exception::<m_hCirrusEx92Adjustment>%5A5426670229
      //## begin Exception::<m_hCirrusEx92Adjustment>%5A5426670229.role preserve=no  public: CirrusEx92Adjustment { -> VHgN}
      CirrusEx92Adjustment m_hCirrusEx92Adjustment;
      //## end Exception::<m_hCirrusEx92Adjustment>%5A5426670229.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5A54266D01C8
      //## Role: Exception::<m_hStdAdjustment>%5A54266E0151
      //## begin Exception::<m_hStdAdjustment>%5A54266E0151.role preserve=no  public: StdAdjustment { -> VHgN}
      StdAdjustment m_hStdAdjustment;
      //## end Exception::<m_hStdAdjustment>%5A54266E0151.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5A542674022E
      //## Role: Exception::<m_hPlusAdjustment>%5A5426750368
      //## begin Exception::<m_hPlusAdjustment>%5A5426750368.role preserve=no  public: PlusAdjustment { -> VHgN}
      PlusAdjustment m_hPlusAdjustment;
      //## end Exception::<m_hPlusAdjustment>%5A5426750368.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5A54268A0305
      //## Role: Exception::<m_hStdFee>%5A54268B0257
      //## begin Exception::<m_hStdFee>%5A54268B0257.role preserve=no  public: StdFee { -> VHgN}
      StdFee m_hStdFee;
      //## end Exception::<m_hStdFee>%5A54268B0257.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5A5427A001A2
      //## Role: Exception::<m_hAS2805Adjustment>%5A5427A003C8
      //## begin Exception::<m_hAS2805Adjustment>%5A5427A003C8.role preserve=no  public: AS2805Adjustment { -> VHgN}
      AS2805Adjustment m_hAS2805Adjustment;
      //## end Exception::<m_hAS2805Adjustment>%5A5427A003C8.role

    // Additional Implementation Declarations
      //## begin Exception%5A54261703CA.implementation preserve=yes
      //## end Exception%5A54261703CA.implementation

};

//## begin Exception%5A54261703CA.postscript preserve=yes
//## end Exception%5A54261703CA.postscript

//## begin module%5A54281A03C2.epilog preserve=yes
//## end module%5A54281A03C2.epilog


#endif
