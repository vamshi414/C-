//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A54281C0172.cm preserve=no
//	$Date:   Apr 09 2018 12:05:22  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%5A54281C0172.cm

//## begin module%5A54281C0172.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A54281C0172.cp

//## Module: CXOSAI36%5A54281C0172; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI36.cpp

//## begin module%5A54281C0172.additionalIncludes preserve=no
//## end module%5A54281C0172.additionalIncludes

//## begin module%5A54281C0172.includes preserve=yes
//## end module%5A54281C0172.includes

#ifndef CXOSAI36_h
#include "CXODAI36.hpp"
#endif
//## begin module%5A54281C0172.declarations preserve=no
//## end module%5A54281C0172.declarations

//## begin module%5A54281C0172.additionalDeclarations preserve=yes
//## end module%5A54281C0172.additionalDeclarations


// Class Exception 

Exception::Exception()
  //## begin Exception::Exception%5A54261703CA_const.hasinit preserve=no
  //## end Exception::Exception%5A54261703CA_const.hasinit
  //## begin Exception::Exception%5A54261703CA_const.initialization preserve=yes
   : AdvantageMessage("0466","S200")
  //## end Exception::Exception%5A54261703CA_const.initialization
{
  //## begin Exception::Exception%5A54261703CA_const.body preserve=yes
  //## end Exception::Exception%5A54261703CA_const.body
}


Exception::~Exception()
{
  //## begin Exception::~Exception%5A54261703CA_dest.body preserve=yes
  //## end Exception::~Exception%5A54261703CA_dest.body
}



//## Other Operations (implementation)
bool Exception::insert (Message& hMessage)
{
  //## begin Exception::insert%5A54262E02CE.body preserve=yes
   UseCase hUseCase("TANDEM","## AI36 READ 0466 EXCEPTION",false);
   setSegmentID("S200");
   if (m_hCirrusEx92Adjustment.insert(hMessage))
      return true;
   if (m_hStdAdjustment.insert(hMessage))
      return true;
   if (m_hPlusAdjustment.insert(hMessage))
      return true;
   if (m_hAS2805Adjustment.insert(hMessage))
      return true;
   return m_hStdFee.insert(hMessage);
  //## end Exception::insert%5A54262E02CE.body
}

// Additional Declarations
  //## begin Exception%5A54261703CA.declarations preserve=yes
  //## end Exception%5A54261703CA.declarations

//## begin module%5A54281C0172.epilog preserve=yes
//## end module%5A54281C0172.epilog
