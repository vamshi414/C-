//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C613641038A.cm preserve=no
//## end module%3C613641038A.cm

//## begin module%3C613641038A.cp preserve=no
//	Copyright (c) 1997 - 2022
//	FIS
//## end module%3C613641038A.cp

//## Module: CXOSAI02%3C613641038A; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Ai\CXODAI02.hpp

#ifndef CXOSAI02_h
#define CXOSAI02_h 1

//## begin module%3C613641038A.additionalIncludes preserve=no
//## end module%3C613641038A.additionalIncludes

//## begin module%3C613641038A.includes preserve=yes
// $Date:   Nov 20 2020 22:58:54  $ $Author:   e3028298  $ $Revision:   1.43  $
//## end module%3C613641038A.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialBaseSegment;
class FinancialAdjustmentSegment;
class FinancialUserSegment;
class FinancialSettlementSegment;
class FinancialReversalSegment;
class FinancialFeeSegment;
class IntegratedCircuitCardSegment;
class FinancialAdjustmentExtensionSegment;
class MultipleRouteSegment;
class FraudBlockSegment;
class FinancialPaymentSegment;
class PulseSegment;
class FinancialMCDPSegment;
class FinancialAPSegment;
class Segment24;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::SwitchInterface_CAT%358EB6E20186
namespace switchinterface {
class SwitchInterface;
} // namespace switchinterface

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class AdvantageMessageProcessor;
//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Token;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
class DateTime;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class ListSegment;

} // namespace segment

//## begin module%3C613641038A.declarations preserve=no
//## end module%3C613641038A.declarations

//## begin module%3C613641038A.additionalDeclarations preserve=yes
namespace repositorysegment {
	class FinancialPNBSegment;
	class CashDepositSegment;
}
//## end module%3C613641038A.additionalDeclarations


//## begin AdvantageFinancial%3C6131880148.preface preserve=yes
//## end AdvantageFinancial%3C6131880148.preface

//## Class: AdvantageFinancial%3C6131880148
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3C6293F803D8;IF::Extract { -> F}
//## Uses: <unnamed>%3C62941000AB;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C62D4A502CE;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3C62D5B602BF;IF::Message { -> F}
//## Uses: <unnamed>%3C62D6C10399;IF::CodeTable { -> F}
//## Uses: <unnamed>%3C62D7510232;IF::DateTime { -> F}
//## Uses: <unnamed>%3C62DB190138;process::Application { -> F}
//## Uses: <unnamed>%3CB5885400EA;switchinterface::SwitchInterface { -> F}
//## Uses: <unnamed>%4635721103A8;repositorysegment::IntegratedCircuitCardSegment { -> F}
//## Uses: <unnamed>%4C0CC4DC03B0;repositorysegment::FraudBlockSegment { -> F}
//## Uses: <unnamed>%4C0CC4EF0064;segment::ListSegment { -> F}
//## Uses: <unnamed>%4DDFC04501CA;repositorysegment::MultipleRouteSegment { -> F}
//## Uses: <unnamed>%52F2B0070248;reusable::Token { -> F}

class AdvantageFinancial : public AdvantageMessage  //## Inherits: <unnamed>%3C6131A0002E
{
  //## begin AdvantageFinancial%3C6131880148.initialDeclarations preserve=yes
  //## end AdvantageFinancial%3C6131880148.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageFinancial();

    //## Destructor (generated)
      virtual ~AdvantageFinancial();


    //## Other Operations (specified)
      //## Operation: insert%3C618FB601D4
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantageFinancial%3C6131880148.public preserve=yes
      //## end AdvantageFinancial%3C6131880148.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageFinancial%3C6131880148.protected preserve=yes
      //## end AdvantageFinancial%3C6131880148.protected

  private:

    //## Other Operations (specified)
      //## Operation: convertAmt%3C6195B6032C
      double convertAmt (double dAmount, char cDecPos, char* sRate);

      //## Operation: convertAmt%5AB10083008E
      int convertAmt (int lAmount, char cDecPos, char* sRate);

      //## Operation: convertBitMap%3D66A0AD03B9
      void convertBitMap (const char cCharBit, char* psBits);

      //## Operation: hexToChar%46356FCF02D3
      reusable::string hexToChar (char* pBuffer, int ilen);

      //## Operation: isAVS2%3C6195C90251
      bool isAVS2 ();

      //## Operation: isCVC2_CVV2%3C6195D103B9
      bool isCVC2_CVV2 ();

      //## Operation: mapSegment1%3C618FEE009C
      void mapSegment1 (hFinancialSeg1* pFinancialSeg1);

      //## Operation: mapSegment2%3C619041030D
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>MS
      //	<!-- AdvantageFinancial::mapSegment2 : Preconditions -->
      //	<!-- release V01.9B.R001 -->
      //	<h3>Track 2
      //	<p>
      //	The DataNavigator data model for the financial
      //	transaction includes Bit 35 - Track 2 data.
      //	This data element is no longer stored by default as PCI
      //	dictates it not be saved subsequent to authorization.
      //	<p>
      //	To populate FIN_RECORD<i>yyyymm</i>.TRACK_2_DATA, add
      //	the value TRACK2 to the FIS Advantage Transaction
      //	Interface task(s) (i.e. <i>ca</i>AI1, <i>ca</i>AI2,
      //	...)  user data.
      //	<p>
      //	Use the CR Client to change the User Data.  It is on the
      //	Detail : General tab in the Task definition.
      //	<!-- /release -->
      //	</body>
      void mapSegment2 (hFinancialSeg2* pFinancialSeg2);

      //## Operation: mapSegment3%3C6190430148
      void mapSegment3 (hFinancialSeg3* pFinancialSeg3);

      //## Operation: mapSegment4%3C6190430261
      void mapSegment4 (hFinancialSeg4* pFinancialSeg4);

      //## Operation: mapSegment5%3C619043036B
      void mapSegment5 (hFinancialSeg5* pFinancialSeg5);

      //## Operation: mapSegment6%3C619044008C
      void mapSegment6 (hFinancialSeg6* pFinancialSeg6);

      //## Operation: mapSegment7%3C6190440186
      void mapSegment7 (hFinancialSeg7* pFinancialSeg7);

      //## Operation: mapSegment8%3C619044029F
      void mapSegment8 (hFinancialSeg8* pFinancialSeg8);

      //## Operation: mapSegment9%3C61904403A9
      void mapSegment9 (hFinancialSeg9* pFinancialSeg9);

      //## Operation: mapSegment10%3C61904500CB
      void mapSegment10 (hFinancialSeg10* pFinancialSeg10);

      //## Operation: mapSegment11%3C61904501F4
      void mapSegment11 (hFinancialSeg11* pFinancialSeg11);

      //## Operation: mapSegment12%3C61904502FD
      void mapSegment12 (hFinancialSeg12* pFinancialSeg12);

      //## Operation: mapSegment13%3C619046001F
      void mapSegment13 (hFinancialSeg13* pFinancialSeg13);

      //## Operation: mapSegment14%3C6190460138
      void mapSegment14 (hFinancialSeg14* pFinancialSeg14);

      //## Operation: mapSegment15%3C6190460242
      void mapSegment15 (hFinancialSeg15* pFinancialSeg15, char* sTranDesc);

      //## Operation: mapSegment16%3C619046035B
      void mapSegment16 (hFinancialSeg16* pFinancialSeg16);

      //## Operation: mapSegment17%3C619047008C
      void mapSegment17 (hFinancialSeg17* pFinancialSeg17);

      //## Operation: mapSegment18%3C61904701A5
      void mapSegment18 (hFinancialSeg18* pFinancialSeg18, char* sRevMTI);

      //## Operation: mapSegment19%3C61904702CE
      void mapSegment19 (hFinancialSeg19* pFinancialSeg19);

      //## Operation: mapSegment20%3C619048003E
      void mapSegment20 (hFinancialSeg20* pFinancialSeg20);

      //## Operation: mapSegment21%3C6190480196
      void mapSegment21 (hFinancialSeg21* pFinancialSeg21);

      //## Operation: mapSegment22%3C61904802FD
      void mapSegment22 (hFinancialSeg22* pFinancialSeg22);

      //## Operation: mapSegment23%3C619049009C
      void mapSegment23 (hFinancialSeg23* pFinancialSeg23);

      //## Operation: mapSegment24%46356F2C0032
      void mapSegment24 (hFinancialSeg24* pFinancialSeg24);

      //## Operation: translate%4635701F01A4
      void translate (char* pBuffer, int ilen);

    // Additional Private Declarations
      //## begin AdvantageFinancial%3C6131880148.private preserve=yes
      //## end AdvantageFinancial%3C6131880148.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: AddEvidence%4B966A1E016F
      //## begin AdvantageFinancial::AddEvidence%4B966A1E016F.attr preserve=no  private: bool {V} true
      bool m_bAddEvidence;
      //## end AdvantageFinancial::AddEvidence%4B966A1E016F.attr

      //## Attribute: AsciiInput%3C62CB080148
      //## begin AdvantageFinancial::AsciiInput%3C62CB080148.attr preserve=no  private: bool {V} false
      bool m_bAsciiInput;
      //## end AdvantageFinancial::AsciiInput%3C62CB080148.attr

      //## Attribute: AuthByAltRoute%3C6294CC00AB
      //## begin AdvantageFinancial::AuthByAltRoute%3C6294CC00AB.attr preserve=no  private: bool {V} false
      bool m_bAuthByAltRoute;
      //## end AdvantageFinancial::AuthByAltRoute%3C6294CC00AB.attr

      //## Attribute: BufferStartp%3C62CBC6029F
      //## begin AdvantageFinancial::BufferStartp%3C62CBC6029F.attr preserve=no  private: int {V} 0
      int m_iBufferStartp;
      //## end AdvantageFinancial::BufferStartp%3C62CBC6029F.attr

      //## Attribute: Century%3C62D78D003E
      //## begin AdvantageFinancial::Century%3C62D78D003E.attr preserve=no  private: char[2] {V} 
      char m_sCentury[2];
      //## end AdvantageFinancial::Century%3C62D78D003E.attr

      //## Attribute: Class%3C62D64F033C
      //## begin AdvantageFinancial::Class%3C62D64F033C.attr preserve=no  private: char {V} ' ' 
      char m_cClass;
      //## end AdvantageFinancial::Class%3C62D64F033C.attr

      //## Attribute: CVV_CVC3%47907142025B
      //## begin AdvantageFinancial::CVV_CVC3%47907142025B.attr preserve=no  private: bool {V} false
      bool m_bCVV_CVC3;
      //## end AdvantageFinancial::CVV_CVC3%47907142025B.attr

      //## Attribute: ExchgFlag%3C62D7C7034B
      //## begin AdvantageFinancial::ExchgFlag%3C62D7C7034B.attr preserve=no  private: char[2] {V} 
      char m_sExchgFlag[2];
      //## end AdvantageFinancial::ExchgFlag%3C62D7C7034B.attr

      //## Attribute: ExpirationDate%4910A6FF0251
      //## begin AdvantageFinancial::ExpirationDate%4910A6FF0251.attr preserve=no  private: bool {V} false
      bool m_bExpirationDate;
      //## end AdvantageFinancial::ExpirationDate%4910A6FF0251.attr

      //## Attribute: INST_ID_RECN_ACQ_BandRPT_LVL_ID_B%3E200FC903D8
      //## begin AdvantageFinancial::INST_ID_RECN_ACQ_BandRPT_LVL_ID_B%3E200FC903D8.attr preserve=no  private: string {V} 
      string m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B;
      //## end AdvantageFinancial::INST_ID_RECN_ACQ_BandRPT_LVL_ID_B%3E200FC903D8.attr

      //## Attribute: LinkOption%4630BA370186
      //## begin AdvantageFinancial::LinkOption%4630BA370186.attr preserve=no  private: int {V} -1
      int m_iLinkOption;
      //## end AdvantageFinancial::LinkOption%4630BA370186.attr

      //## Attribute: NetTermId%48DB55450211
      //## begin AdvantageFinancial::NetTermId%48DB55450211.attr preserve=no  private: map<string,string,less<string> > {U} 
      map<string,string,less<string> > m_hNetTermId;
      //## end AdvantageFinancial::NetTermId%48DB55450211.attr

      //## Attribute: NetworkDecPos%3C62D7E1038A
      //## begin AdvantageFinancial::NetworkDecPos%3C62D7E1038A.attr preserve=no  private: char {V} ' ' 
      char m_cNetworkDecPos;
      //## end AdvantageFinancial::NetworkDecPos%3C62D7E1038A.attr

      //## Attribute: NetworkRate%3C62F102003E
      //## begin AdvantageFinancial::NetworkRate%3C62F102003E.attr preserve=no  private: char[8] {V} 
      char m_sNetworkRate[8];
      //## end AdvantageFinancial::NetworkRate%3C62F102003E.attr

      //## Attribute: PreAuthFlag%47D7BF6A001C
      //## begin AdvantageFinancial::PreAuthFlag%47D7BF6A001C.attr preserve=no  private: char {V} ' ' 
      char m_cPreAuthFlag;
      //## end AdvantageFinancial::PreAuthFlag%47D7BF6A001C.attr

      //## Attribute: PreauthInd%3C62D6950399
      //## begin AdvantageFinancial::PreauthInd%3C62D6950399.attr preserve=no  private: char {V} ' ' 
      char m_cPreauthInd;
      //## end AdvantageFinancial::PreauthInd%3C62D6950399.attr

      //## Attribute: Reversal%3C62C6F703B9
      //## begin AdvantageFinancial::Reversal%3C62C6F703B9.attr preserve=no  private: bool {V} false
      bool m_bReversal;
      //## end AdvantageFinancial::Reversal%3C62C6F703B9.attr

      //## Attribute: Segment%3C62CC3602FD
      //## begin AdvantageFinancial::Segment%3C62CC3602FD.attr preserve=no  private: char* {V} 0
      char* m_pSegment;
      //## end AdvantageFinancial::Segment%3C62CC3602FD.attr

      //## Attribute: Seg24Tokens%66003CD5036A
      //## begin AdvantageFinancial::Seg24Tokens%66003CD5036A.attr preserve=no  private: set<int> {U} 
      set<int> m_hSeg24Tokens;
      //## end AdvantageFinancial::Seg24Tokens%66003CD5036A.attr

      //## Attribute: TokenExpirationDate%569CDB370305
      //## begin AdvantageFinancial::TokenExpirationDate%569CDB370305.attr preserve=no  private: bool {U} false
      bool m_bTokenExpirationDate;
      //## end AdvantageFinancial::TokenExpirationDate%569CDB370305.attr

      //## Attribute: TokenMap%52F2B05B0230
      //## begin AdvantageFinancial::TokenMap%52F2B05B0230.attr preserve=no  private: map<string,string,less<string> > {U} 
      map<string,string,less<string> > m_hTokenMap;
      //## end AdvantageFinancial::TokenMap%52F2B05B0230.attr

      //## Attribute: Track2%485811F3008C
      //## begin AdvantageFinancial::Track2%485811F3008C.attr preserve=no  private: bool {V} false
      bool m_bTrack2;
      //## end AdvantageFinancial::Track2%485811F3008C.attr

    // Data Members for Associations

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C62CA5503C8
      //## Role: AdvantageFinancial::<m_pFinancialAdjustmentExtensionSegment>%3C62CA560251
      //## begin AdvantageFinancial::<m_pFinancialAdjustmentExtensionSegment>%3C62CA560251.role preserve=no  public: repositorysegment::FinancialAdjustmentExtensionSegment { -> RFHgN}
      repositorysegment::FinancialAdjustmentExtensionSegment *m_pFinancialAdjustmentExtensionSegment;
      //## end AdvantageFinancial::<m_pFinancialAdjustmentExtensionSegment>%3C62CA560251.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C62CA5901E4
      //## Role: AdvantageFinancial::<m_pFinancialAdjustmentSegment>%3C62CA5A0119
      //## begin AdvantageFinancial::<m_pFinancialAdjustmentSegment>%3C62CA5A0119.role preserve=no  public: repositorysegment::FinancialAdjustmentSegment { -> RFHgN}
      repositorysegment::FinancialAdjustmentSegment *m_pFinancialAdjustmentSegment;
      //## end AdvantageFinancial::<m_pFinancialAdjustmentSegment>%3C62CA5A0119.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C62CA5C0186
      //## Role: AdvantageFinancial::<m_pFinancialBaseSegment>%3C62CA5D009C
      //## begin AdvantageFinancial::<m_pFinancialBaseSegment>%3C62CA5D009C.role preserve=no  public: repositorysegment::FinancialBaseSegment { -> RFHgN}
      repositorysegment::FinancialBaseSegment *m_pFinancialBaseSegment;
      //## end AdvantageFinancial::<m_pFinancialBaseSegment>%3C62CA5D009C.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C62CA5F0222
      //## Role: AdvantageFinancial::<m_pFinancialFeeSegment>%3C62CA60003E
      //## begin AdvantageFinancial::<m_pFinancialFeeSegment>%3C62CA60003E.role preserve=no  public: repositorysegment::FinancialFeeSegment { -> RFHgN}
      repositorysegment::FinancialFeeSegment *m_pFinancialFeeSegment;
      //## end AdvantageFinancial::<m_pFinancialFeeSegment>%3C62CA60003E.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C62CA6200FA
      //## Role: AdvantageFinancial::<m_pFinancialReversalSegment>%3C62CA62031C
      //## begin AdvantageFinancial::<m_pFinancialReversalSegment>%3C62CA62031C.role preserve=no  public: repositorysegment::FinancialReversalSegment { -> RFHgN}
      repositorysegment::FinancialReversalSegment *m_pFinancialReversalSegment;
      //## end AdvantageFinancial::<m_pFinancialReversalSegment>%3C62CA62031C.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C62CA64031C
      //## Role: AdvantageFinancial::<m_pFinancialSettlementSegment>%3C62CA6501C5
      //## begin AdvantageFinancial::<m_pFinancialSettlementSegment>%3C62CA6501C5.role preserve=no  public: repositorysegment::FinancialSettlementSegment { -> RFHgN}
      repositorysegment::FinancialSettlementSegment *m_pFinancialSettlementSegment;
      //## end AdvantageFinancial::<m_pFinancialSettlementSegment>%3C62CA6501C5.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C62CA6702EE
      //## Role: AdvantageFinancial::<m_pFinancialUserSegment>%3C62CA6801F4
      //## begin AdvantageFinancial::<m_pFinancialUserSegment>%3C62CA6801F4.role preserve=no  public: repositorysegment::FinancialUserSegment { -> RFHgN}
      repositorysegment::FinancialUserSegment *m_pFinancialUserSegment;
      //## end AdvantageFinancial::<m_pFinancialUserSegment>%3C62CA6801F4.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C62D95B00CB
      //## Role: AdvantageFinancial::<m_pAdvantageMessageProcessor>%3C62D95C0196
      //## begin AdvantageFinancial::<m_pAdvantageMessageProcessor>%3C62D95C0196.role preserve=no  public: AdvantageMessageProcessor { -> RFHgN}
      AdvantageMessageProcessor *m_pAdvantageMessageProcessor;
      //## end AdvantageFinancial::<m_pAdvantageMessageProcessor>%3C62D95C0196.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%4635CB0B0315
      //## Role: AdvantageFinancial::<m_pIntegratedCircuitCardSegment>%4635CB0D0102
      //## begin AdvantageFinancial::<m_pIntegratedCircuitCardSegment>%4635CB0D0102.role preserve=no  public: repositorysegment::IntegratedCircuitCardSegment { -> RFHgN}
      repositorysegment::IntegratedCircuitCardSegment *m_pIntegratedCircuitCardSegment;
      //## end AdvantageFinancial::<m_pIntegratedCircuitCardSegment>%4635CB0D0102.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%4DDFE346003C
      //## Role: AdvantageFinancial::<m_pMultipleRouteSegment>%4DDFE34601F8
      //## begin AdvantageFinancial::<m_pMultipleRouteSegment>%4DDFE34601F8.role preserve=no  public: repositorysegment::MultipleRouteSegment { -> RFHgN}
      repositorysegment::MultipleRouteSegment *m_pMultipleRouteSegment;
      //## end AdvantageFinancial::<m_pMultipleRouteSegment>%4DDFE34601F8.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%52E058CA0285
      //## Role: AdvantageFinancial::<m_pPulseSegment>%52E058CB03BD
      //## begin AdvantageFinancial::<m_pPulseSegment>%52E058CB03BD.role preserve=no  public: repositorysegment::PulseSegment { -> RFHgN}
      repositorysegment::PulseSegment *m_pPulseSegment;
      //## end AdvantageFinancial::<m_pPulseSegment>%52E058CB03BD.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5A0D42D0029F
      //## Role: AdvantageFinancial::<m_pFinancialMCDPSegment>%5A0D42D201A6
      //## begin AdvantageFinancial::<m_pFinancialMCDPSegment>%5A0D42D201A6.role preserve=no  public: repositorysegment::FinancialMCDPSegment { -> RFHgN}
      repositorysegment::FinancialMCDPSegment *m_pFinancialMCDPSegment;
      //## end AdvantageFinancial::<m_pFinancialMCDPSegment>%5A0D42D201A6.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%6413FB6E0390
      //## Role: AdvantageFinancial::<m_pSegment24>%6413FB730386
      //## begin AdvantageFinancial::<m_pSegment24>%6413FB730386.role preserve=no  public: repositorysegment::Segment24 { -> RFHgN}
      repositorysegment::Segment24 *m_pSegment24;
      //## end AdvantageFinancial::<m_pSegment24>%6413FB730386.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%6413FCD5009E
      //## Role: AdvantageFinancial::<m_pFinancialPaymentSegment>%6413FCD60347
      //## begin AdvantageFinancial::<m_pFinancialPaymentSegment>%6413FCD60347.role preserve=no  public: repositorysegment::FinancialPaymentSegment { -> RFHgN}
      repositorysegment::FinancialPaymentSegment *m_pFinancialPaymentSegment;
      //## end AdvantageFinancial::<m_pFinancialPaymentSegment>%6413FCD60347.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%644105F000F6
      //## Role: AdvantageFinancial::<m_pFinancialAPSegment>%644105F10168
      //## begin AdvantageFinancial::<m_pFinancialAPSegment>%644105F10168.role preserve=no  public: repositorysegment::FinancialAPSegment { -> RFHgN}
      repositorysegment::FinancialAPSegment *m_pFinancialAPSegment;
      //## end AdvantageFinancial::<m_pFinancialAPSegment>%644105F10168.role

    // Additional Implementation Declarations
      //## begin AdvantageFinancial%3C6131880148.implementation preserve=yes
	vector<FraudBlockSegment> m_hFraudBlockSegment;
	repositorysegment::FinancialPNBSegment *m_pFinancialPNBSegment;
	string m_strCodeLevel;
	vector<CashDepositSegment> m_hCashDepositSegment;
      //## end AdvantageFinancial%3C6131880148.implementation
};

//## begin AdvantageFinancial%3C6131880148.postscript preserve=yes
//## end AdvantageFinancial%3C6131880148.postscript

//## begin module%3C613641038A.epilog preserve=yes
//## end module%3C613641038A.epilog


#endif
