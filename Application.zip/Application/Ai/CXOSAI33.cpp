//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A5423620283.cm preserve=no
//	$Date:   May 20 2021 09:50:48  $ $Author:   E5350313  $
//	$Revision:   1.3  $
//## end module%5A5423620283.cm

//## begin module%5A5423620283.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A5423620283.cp

//## Module: CXOSAI33%5A5423620283; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI33.cpp

//## begin module%5A5423620283.additionalIncludes preserve=no
//## end module%5A5423620283.additionalIncludes

//## begin module%5A5423620283.includes preserve=yes
//## end module%5A5423620283.includes

#ifndef CXOSAI33_h
#include "CXODAI33.hpp"
#endif
//## begin module%5A5423620283.declarations preserve=no
//## end module%5A5423620283.declarations

//## begin module%5A5423620283.additionalDeclarations preserve=yes
//## end module%5A5423620283.additionalDeclarations


// Class CirrusEx92Adjustment 

CirrusEx92Adjustment::CirrusEx92Adjustment()
  //## begin CirrusEx92Adjustment::CirrusEx92Adjustment%5A542326027D_const.hasinit preserve=no
  //## end CirrusEx92Adjustment::CirrusEx92Adjustment%5A542326027D_const.hasinit
  //## begin CirrusEx92Adjustment::CirrusEx92Adjustment%5A542326027D_const.initialization preserve=yes
   : AdvantageMessage("0466","S200")
  //## end CirrusEx92Adjustment::CirrusEx92Adjustment%5A542326027D_const.initialization
{
  //## begin CirrusEx92Adjustment::CirrusEx92Adjustment%5A542326027D_const.body preserve=yes
  //## end CirrusEx92Adjustment::CirrusEx92Adjustment%5A542326027D_const.body
}


CirrusEx92Adjustment::~CirrusEx92Adjustment()
{
  //## begin CirrusEx92Adjustment::~CirrusEx92Adjustment%5A542326027D_dest.body preserve=yes
  //## end CirrusEx92Adjustment::~CirrusEx92Adjustment%5A542326027D_dest.body
}



//## Other Operations (implementation)
bool CirrusEx92Adjustment::insert (Message& hMessage)
{
  //## begin CirrusEx92Adjustment::insert%5A5423410085.body preserve=yes
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   hCirrusEx92Adj* p = (hCirrusEx92Adj*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   if (memcmp(p->sTranId,"X077",4) == 0
      && (memcmp(p->sMsgType,"1400",4) == 0
      || memcmp(p->sMsgType,"1420",4) == 0))
      ;
   else
      return false;
   UseCase hUseCase("TANDEM","## AI33 READ 0466 EXCEPTION",false);
   setTSTAMP_TRANS(pV13AdvantageHeader->sFiller);
   database::UniquenessKey::hash(p->sPan,16);
   database::UniquenessKey::hash(p->sRetrievalRefNo,12);
   database::UniquenessKey::hash(p->sTraceNo,6);
   m_pTransaction->setUNIQUENESS_KEY(database::UniquenessKey::getHash());
   memcpy(p->sINST_ID_ACQ,p->sAcqInstId,10);
   memset(p->sCARD_ACPT_NAME_LOC,' ',sizeof(p->sCARD_ACPT_NAME_LOC));
   memcpy(p->sCARD_ACPT_NAME_LOC,p->sAcqNameRegE,15);
   memcpy(p->sCARD_ACPT_NAME_LOC + 26,p->sAcqNameRegE + 16,25);
   memcpy(p->sCARD_ACPT_NAME_LOC + 55,p->sAtmLocCity,16);
   if (strncmp(p->sAtmLocCity + 16," ",1) == 0)
      memcpy(p->sCARD_ACPT_REGION,p->sAtmLocCity + 17,2);
   else
      memcpy(p->sCARD_ACPT_COUNTRY,p->sAtmLocCity + 16,3);
   memcpy(p->sINST_ID_ISS,p->sCardInstId,10);
   if (Customer::instance()->getTest())
      memcpy(p->sPan + 6,"999999",6);
   char szTemp[13];
   memcpy(szTemp,p->sAdjAmtDr,10);
   szTemp[10] = '\0';
   if (atof(szTemp) == 0)
      memcpy(p->sAdjAmtDr,p->sAdjAmtCr,10);
   char sTempCompCode[2];
   if (memcmp(p->sMsgType,"1400",4) == 0)
      memcpy(sTempCompCode,&p->sAcctNoCompCode1[1],2);
   else
      memcpy(sTempCompCode,&p->sCompCode[1],2);
   memcpy(szTemp,p->sOrigAmt,12);
   szTemp[12] = '\0';
   if (atof(szTemp) == 0)
   {
      if (memcmp(p->sResponseCode,"78",2) == 0
         || memcmp(p->sResponseCode,"79",2) == 0
         || memcmp(p->sResponseCode,"80",2) == 0
         || memcmp(p->sResponseCode,"81",2) == 0)
      {
         if (memcmp(sTempCompCode,"00",2) == 0)
            memcpy(p->sACT_CODE,"000",3);
         else
            memcpy(p->sACT_CODE,"400",3);
      }
      else
         memcpy(p->sACT_CODE,"100",3);
   }
   else
   {
      if (memcmp(p->sResponseCode,"01",2) == 0)
         memcpy(p->sACT_CODE,"000",3);
      else
         memcpy(p->sACT_CODE,"100",3);
   }
   p->cACQ_PLAT_PROD_ID = 'A';
   memcpy(p->sFIN_TYPE,"080",3);
   p->cTRAN_DISPOSITION = '1';
   string strFirst(p->sProcCode,4);
   string strSecond;
   if (ConfigurationRepository::instance()->translate("X_CIRR_PROC_CODE",strFirst,strSecond,"FIN_LOCATOR","TRAN_TYPE_ID",0))
   {
      memcpy(p->sTRAN_TYPE_ID,strSecond.data(),strSecond.length());
      memcpy(p->sACCT_TYPES_ISS,strSecond.data() + 2,4);
   }
   else
      ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_SET_ACCT_TYPES_ISS);
   strFirst.assign(p->sRevReason,2);
   if (ConfigurationRepository::instance()->translate("X_CIRR_ADJ_REASON",strFirst,strSecond,"FIN_RECORD","MSG_RESON_CODE_ACQ",0))
      memcpy(p->sMSG_RESON_CODE_ACQ,strSecond.data(),strSecond.length());
   memcpy(p->sEXTENSION_DATA_ADJ,p->sProcCode,4);
   p->sEXTENSION_DATA_ADJ[4] = ' ';
   memcpy(p->sEXTENSION_DATA_ADJ + 5,p->sRevReason,2);
   p->sEXTENSION_DATA_ADJ[7] = ' ';
   memcpy(p->sEXTENSION_DATA_ADJ + 8,p->sTraceNo,6);
   p->sEXTENSION_DATA_ADJ[14] = ' ';
   memcpy(p->sEXTENSION_DATA_ADJ + 15,p->sTranAmtUSD,9);
   p->sEXTENSION_DATA_ADJ[24] = ' ';
   memcpy(p->sEXTENSION_DATA_ADJ + 25,p->sResponseCode,15);
   ::Template::instance()->map("V13HEADER",(const char*)pV13AdvantageHeader);
   ::Template::instance()->map("CIRRUSADJUSTMENT",(const char*)p);
   return deport(hMessage);
  //## end CirrusEx92Adjustment::insert%5A5423410085.body
}

// Additional Declarations
  //## begin CirrusEx92Adjustment%5A542326027D.declarations preserve=yes
  //## end CirrusEx92Adjustment%5A542326027D.declarations

//## begin module%5A5423620283.epilog preserve=yes
//## end module%5A5423620283.epilog
