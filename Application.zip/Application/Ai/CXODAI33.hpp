//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A5423610083.cm preserve=no
//	$Date:   31 Jan 2018 14:11:08  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5A5423610083.cm

//## begin module%5A5423610083.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A5423610083.cp

//## Module: CXOSAI33%5A5423610083; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI33.hpp

#ifndef CXOSAI33_h
#define CXOSAI33_h 1

//## begin module%5A5423610083.additionalIncludes preserve=no
//## end module%5A5423610083.additionalIncludes

//## begin module%5A5423610083.includes preserve=yes
//## end module%5A5423610083.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
//## begin module%5A5423610083.declarations preserve=no
//## end module%5A5423610083.declarations

//## begin module%5A5423610083.additionalDeclarations preserve=yes
//## end module%5A5423610083.additionalDeclarations


//## begin CirrusEx92Adjustment%5A542326027D.preface preserve=yes
//## end CirrusEx92Adjustment%5A542326027D.preface

//## Class: CirrusEx92Adjustment%5A542326027D
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport CirrusEx92Adjustment : public AdvantageMessage  //## Inherits: <unnamed>%5A54233C016B
{
  //## begin CirrusEx92Adjustment%5A542326027D.initialDeclarations preserve=yes
  //## end CirrusEx92Adjustment%5A542326027D.initialDeclarations

  public:
    //## Constructors (generated)
      CirrusEx92Adjustment();

    //## Destructor (generated)
      virtual ~CirrusEx92Adjustment();


    //## Other Operations (specified)
      //## Operation: insert%5A5423410085
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin CirrusEx92Adjustment%5A542326027D.public preserve=yes
      //## end CirrusEx92Adjustment%5A542326027D.public

  protected:
    // Additional Protected Declarations
      //## begin CirrusEx92Adjustment%5A542326027D.protected preserve=yes
      //## end CirrusEx92Adjustment%5A542326027D.protected

  private:
    // Additional Private Declarations
      //## begin CirrusEx92Adjustment%5A542326027D.private preserve=yes
      //## end CirrusEx92Adjustment%5A542326027D.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin CirrusEx92Adjustment%5A542326027D.implementation preserve=yes
      //## end CirrusEx92Adjustment%5A542326027D.implementation

};

//## begin CirrusEx92Adjustment%5A542326027D.postscript preserve=yes
//## end CirrusEx92Adjustment%5A542326027D.postscript

//## begin module%5A5423610083.epilog preserve=yes
//## end module%5A5423610083.epilog


#endif
