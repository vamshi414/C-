//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EB2C43201DD.cm preserve=no
//	$Date:   May 08 2020 09:17:32  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5EB2C43201DD.cm

//## begin module%5EB2C43201DD.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5EB2C43201DD.cp

//## Module: CXOSAI47%5EB2C43201DD; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI47.hpp

#ifndef CXOSAI47_h
#define CXOSAI47_h 1

//## begin module%5EB2C43201DD.additionalIncludes preserve=no
//## end module%5EB2C43201DD.additionalIncludes

//## begin module%5EB2C43201DD.includes preserve=yes
//## end module%5EB2C43201DD.includes

#ifndef CXOSAI45_h
#include "CXODAI45.hpp"
#endif
//## begin module%5EB2C43201DD.declarations preserve=no
//## end module%5EB2C43201DD.declarations

//## begin module%5EB2C43201DD.additionalDeclarations preserve=yes
//## end module%5EB2C43201DD.additionalDeclarations


//## begin APAcctMaintenanceSegment%5EB2C2E200B2.preface preserve=yes
//## end APAcctMaintenanceSegment%5EB2C2E200B2.preface

//## Class: APAcctMaintenanceSegment%5EB2C2E200B2
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport APAcctMaintenanceSegment : public APSegment  //## Inherits: <unnamed>%5EB2C30401F2
{
  //## begin APAcctMaintenanceSegment%5EB2C2E200B2.initialDeclarations preserve=yes
  //## end APAcctMaintenanceSegment%5EB2C2E200B2.initialDeclarations

  public:
    //## Constructors (generated)
      APAcctMaintenanceSegment();

    //## Destructor (generated)
      virtual ~APAcctMaintenanceSegment();

    // Additional Public Declarations
      //## begin APAcctMaintenanceSegment%5EB2C2E200B2.public preserve=yes
      //## end APAcctMaintenanceSegment%5EB2C2E200B2.public

  protected:
    // Additional Protected Declarations
      //## begin APAcctMaintenanceSegment%5EB2C2E200B2.protected preserve=yes
      //## end APAcctMaintenanceSegment%5EB2C2E200B2.protected

  private:
    // Additional Private Declarations
      //## begin APAcctMaintenanceSegment%5EB2C2E200B2.private preserve=yes
      //## end APAcctMaintenanceSegment%5EB2C2E200B2.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin APAcctMaintenanceSegment%5EB2C2E200B2.implementation preserve=yes
      //## end APAcctMaintenanceSegment%5EB2C2E200B2.implementation

};

//## begin APAcctMaintenanceSegment%5EB2C2E200B2.postscript preserve=yes
//## end APAcctMaintenanceSegment%5EB2C2E200B2.postscript

//## begin module%5EB2C43201DD.epilog preserve=yes
//## end module%5EB2C43201DD.epilog


#endif
