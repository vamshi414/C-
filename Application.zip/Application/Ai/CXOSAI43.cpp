//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A5435040192.cm preserve=no
//	$Date:   May 08 2020 09:13:32  $ $Author:   e1009839  $
//	$Revision:   1.3  $
//## end module%5A5435040192.cm

//## begin module%5A5435040192.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A5435040192.cp

//## Module: CXOSAI43%5A5435040192; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI43.cpp

//## begin module%5A5435040192.additionalIncludes preserve=no
//## end module%5A5435040192.additionalIncludes

//## begin module%5A5435040192.includes preserve=yes
//## end module%5A5435040192.includes

#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSAI43_h
#include "CXODAI43.hpp"
#endif


//## begin module%5A5435040192.declarations preserve=no
//## end module%5A5435040192.declarations

//## begin module%5A5435040192.additionalDeclarations preserve=yes
//## end module%5A5435040192.additionalDeclarations


// Class APFraudMaintenance

APFraudMaintenance::APFraudMaintenance()
  //## begin APFraudMaintenance::APFraudMaintenance%5A542F1A0357_const.hasinit preserve=no
  //## end APFraudMaintenance::APFraudMaintenance%5A542F1A0357_const.hasinit
  //## begin APFraudMaintenance::APFraudMaintenance%5A542F1A0357_const.initialization preserve=yes
   : AdvantageMessage("0880","F001")
  //## end APFraudMaintenance::APFraudMaintenance%5A542F1A0357_const.initialization
{
  //## begin APFraudMaintenance::APFraudMaintenance%5A542F1A0357_const.body preserve=yes
   memcpy(m_sID,"AI43",4);
  //## end APFraudMaintenance::APFraudMaintenance%5A542F1A0357_const.body
}


APFraudMaintenance::~APFraudMaintenance()
{
  //## begin APFraudMaintenance::~APFraudMaintenance%5A542F1A0357_dest.body preserve=yes
  //## end APFraudMaintenance::~APFraudMaintenance%5A542F1A0357_dest.body
}



//## Other Operations (implementation)
bool APFraudMaintenance::insert (Message& hMessage)
{
  //## begin APFraudMaintenance::insert%5A5430E601CB.body preserve=yes
   UseCase hUseCase("TANDEM","## AI43 READ 0880 FRAUD MAINT",false);
   hFraudMaintenance* p = (hFraudMaintenance*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   memset((char*)p + 4096,'\0',4096);
   char sTSTAMP_TRANS[17] = {"                "};
   DateTime::calcCentury(p->sTimeStamp,sTSTAMP_TRANS);
   memcpy(sTSTAMP_TRANS + 2,p->sTimeStamp,14);
   m_pTransaction->setTSTAMP_TRANS(sTSTAMP_TRANS);
   int i = 0;
   if (p->sFRDABA[10] != ' ')
      i = 1;
   memcpy(p->sINST_ID,p->sFRDABA + i,9);
   memcpy(p->sBUSINESS_KEY,p->sCardGroup,6);
   p->sBUSINESS_KEY[6] = '~';
   KeyRing::instance()->tokenize(p->sPan,19);
   memcpy(p->sBUSINESS_KEY + 7,p->sPan,19);
   switch (ntohs(p->siStepNo))
   {
      case 5:
         p->cRECORD_ACTION = 'A';
         break;
      case 6:
         p->cRECORD_ACTION = 'D';
         break;
      case 8:
         p->cRECORD_ACTION = 'C';
         break;
      default:
         p->cRECORD_ACTION = 'U';
   }
   m_hAPFraudMaintenanceSegment.reformat(string(p->sRecType,4),(char*)p + 98,p->sOLD_VALUE,p->sNEW_VALUE,true);
   unsigned short j = 0;
   i = 0;
   int k = strlen(p->sOLD_VALUE);
   for (i = 0;i < k;i++)
	   j = 33 * j + p->sOLD_VALUE[i];
   k = strlen(p->sNEW_VALUE);
   for (i = 0;i < k;i++)
	   j = 33 * j + p->sNEW_VALUE[i];
   if (j > 32767)
	   j -= 32768;
   m_pTransaction->setUNIQUENESS_KEY((int)j);
   ::Template::instance()->map("FRAUDMAINT",(const char*)p);
   return deport(hMessage);
  //## end APFraudMaintenance::insert%5A5430E601CB.body
}

// Additional Declarations
  //## begin APFraudMaintenance%5A542F1A0357.declarations preserve=yes
  //## end APFraudMaintenance%5A542F1A0357.declarations

//## begin module%5A5435040192.epilog preserve=yes
//## end module%5A5435040192.epilog
