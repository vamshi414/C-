//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C61375D029F.cm preserve=no
//	$Date:   Dec 16 2020 11:22:10  $ $Author:   E5350313  $
//	$Revision:   1.53  $
//## end module%3C61375D029F.cm

//## begin module%3C61375D029F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C61375D029F.cp

//## Module: CXOSAI06%3C61375D029F; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Dn_codes\V03.0A.R002\Dn\Server\Application\Ai\CXOSAI06.cpp

//## begin module%3C61375D029F.additionalIncludes preserve=no
//## end module%3C61375D029F.additionalIncludes

//## begin module%3C61375D029F.includes preserve=yes
// $Date:   Dec 16 2020 11:22:10  $ $Author:   E5350313  $ $Revision:   1.53  $
#include <stdio.h>
#include "CXODIF03.hpp"
#include "CXODIF11.hpp"
#include "CXODIF16.hpp"
//## end module%3C61375D029F.includes

#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSAI06_h
#include "CXODAI06.hpp"
#endif


//## begin module%3C61375D029F.declarations preserve=no
//## end module%3C61375D029F.declarations

//## begin module%3C61375D029F.additionalDeclarations preserve=yes
//## end module%3C61375D029F.additionalDeclarations


// Class AdvantageNetstatDisplay 

AdvantageNetstatDisplay::AdvantageNetstatDisplay()
  //## begin AdvantageNetstatDisplay::AdvantageNetstatDisplay%3C61324602DE_const.hasinit preserve=no
      : m_bAD16Message(false)
  //## end AdvantageNetstatDisplay::AdvantageNetstatDisplay%3C61324602DE_const.hasinit
  //## begin AdvantageNetstatDisplay::AdvantageNetstatDisplay%3C61324602DE_const.initialization preserve=yes
   ,AdvantageMessage("1511","S907")
  //## end AdvantageNetstatDisplay::AdvantageNetstatDisplay%3C61324602DE_const.initialization
{
  //## begin AdvantageNetstatDisplay::AdvantageNetstatDisplay%3C61324602DE_const.body preserve=yes
   memcpy(m_sID,"AI06",4);
   string strTemp;
   Extract::instance()->getSpec("AD16",strTemp);
   if (strTemp.find("LOADAD16") != string::npos)
      setAD16Message(true);
  //## end AdvantageNetstatDisplay::AdvantageNetstatDisplay%3C61324602DE_const.body
}


AdvantageNetstatDisplay::~AdvantageNetstatDisplay()
{
  //## begin AdvantageNetstatDisplay::~AdvantageNetstatDisplay%3C61324602DE_dest.body preserve=yes
  //## end AdvantageNetstatDisplay::~AdvantageNetstatDisplay%3C61324602DE_dest.body
}



//## Other Operations (implementation)
bool AdvantageNetstatDisplay::insert (Message& hMessage)
{
  //## begin AdvantageNetstatDisplay::insert%3C618D7501D4.body preserve=yes
   UseCase hUseCase("TANDEM","## AD16 READ 1511 NETSTAT",false);
   *Message::instance(Message::OUTBOUND) = hMessage;
   hNetstatDisplay* pNetstatDisplay = (hNetstatDisplay*)(Message::instance(Message::OUTBOUND)->data() + sizeof(hV13AdvantageHeader));
   if (ntohs(pNetstatDisplay->siNumberMsgs) < 1)
      return false;
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)Message::instance(Message::OUTBOUND)->data();
   m_hEntityStatusSegment.reset();
   m_hAIMSBillingSegment.reset();
   m_hAuditSegment.reset();
   m_hListSegment.reset();
   AdvantageMessage::insert(hMessage);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pNetstatDisplay->sMsgPrefix,sizeof(pNetstatDisplay->sMsgPrefix),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pNetstatDisplay->sMsgPrefix2nd,sizeof(pNetstatDisplay->sMsgPrefix2nd),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pNetstatDisplay->sSubject,sizeof(pNetstatDisplay->sSubject),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pNetstatDisplay->sOperatorID,sizeof(pNetstatDisplay->sOperatorID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pNetstatDisplay->sOriginProcess,((char*)(&pNetstatDisplay->siParmCount) - pNetstatDisplay->sOriginProcess),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pNetstatDisplay->sParms,sizeof(pNetstatDisplay->sParms),CodeTable::CX_ASCII_TO_EBCDIC);
      for (int m = 0;m < (ntohs(pNetstatDisplay->siNumberMsgs));m++)
         CodeTable::translate(pNetstatDisplay->MsgData[m].sText,sizeof(pNetstatDisplay->MsgData[m].sText),CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pNetstatDisplay->sMsgPrefix,sizeof(pNetstatDisplay->sMsgPrefix),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pNetstatDisplay->sMsgPrefix2nd,sizeof(pNetstatDisplay->sMsgPrefix2nd),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pNetstatDisplay->sSubject,sizeof(pNetstatDisplay->sSubject),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pNetstatDisplay->sOperatorID,sizeof(pNetstatDisplay->sOperatorID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pNetstatDisplay->sOriginProcess,((char*)(&pNetstatDisplay->siParmCount) - pNetstatDisplay->sOriginProcess),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pNetstatDisplay->sParms,sizeof(pNetstatDisplay->sParms),CodeTable::CX_EBCDIC_TO_ASCII);
      for (int m = 0;m < (ntohs(pNetstatDisplay->siNumberMsgs));m++)
         CodeTable::translate(pNetstatDisplay->MsgData[m].sText,sizeof(pNetstatDisplay->MsgData[m].sText),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   char* pData2 = psBuffer + 4;
   m_hListSegment.write(&psBuffer);
   string strTSTAMP_TRANS(NonStopClock::getYYYYMMDDHHMMSShh(pNetstatDisplay->sMsgTstamp));
   m_hEntityStatusSegment.setTSTAMP_TRANS(strTSTAMP_TRANS.data(),16);
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      m_hEntityStatusSegment.setTSTAMP_TRANS(strTemp.data(),16);
   }
   m_hEntityStatusSegment.setSUBJECT(pNetstatDisplay->sSubject,8);
   double dSUBJECT_TYPE = (double)ntohs(pNetstatDisplay->siSubjectType);
   if (dSUBJECT_TYPE < 0
      || dSUBJECT_TYPE > 9999)
      dSUBJECT_TYPE = 0;
   m_hEntityStatusSegment.setSUBJECT_TYPE(dSUBJECT_TYPE);
   m_hEntityStatusSegment.setCED_BUILD_NO(ntohl(pV13AdvantageHeader->lCED_BUILD_NO));
   m_hEntityStatusSegment.setMSG_NO((short)ntohs(pNetstatDisplay->siMsgNumber));
   string strSubjectState;
   int iCount = ntohs(pNetstatDisplay->siNumberMsgs);
   for (int m = 0;m < ntohs(pNetstatDisplay->siNumberMsgs);m++)
   {
      ++m_siUniquenessKey;
      if (m_siUniquenessKey > 1000)
         m_siUniquenessKey = 1;
      m_hEntityStatusSegment.setUNIQUENESS_KEY(m_siUniquenessKey);
      short siTempMsgLevel = (ntohs(pNetstatDisplay->MsgData[m].siMsgLevel) >= 0 &&
         ntohs(pNetstatDisplay->MsgData[m].siMsgLevel) < 10000 ?
         ntohs(pNetstatDisplay->MsgData[m].siMsgLevel) : 0);
      m_hEntityStatusSegment.setSEVERITY(siTempMsgLevel);
      m_hEntityStatusSegment.setSTATUS_TEXT(pNetstatDisplay->MsgData[m].sText,70);
      string strBuffer((char*)m_hEntityStatusSegment.zSTATUS_TEXT(),6);
      size_t pos = strBuffer.find_last_not_of(' ');
      if (pos != string::npos)
         strBuffer.erase(pos + 1);
      pos = (strBuffer.find("-"));
      if (pos != string::npos)
         strBuffer.erase(pos,1);
      m_hEntityStatusSegment.setDEVICE_STATUS(strBuffer.data(),5);
      if (ConfigurationRepository::instance()->translate("X_GASPER_STATUS_CODE",
         string(m_hEntityStatusSegment.zDEVICE_STATUS()),strSubjectState,string(""),string(""),-1,0))
      {
         m_hEntityStatusSegment.setSUBJECT_STATE(strSubjectState.data(),strSubjectState.length());
      }
      else
         m_hEntityStatusSegment.setSUBJECT_STATE("\0",1);
      if(getAD16Message() == false)
         m_hEntityStatusSegment.write(&psBuffer);
      string strStatusText(m_hEntityStatusSegment.zSTATUS_TEXT());
      transform(strStatusText.begin(), strStatusText.end(),strStatusText.begin(),::toupper);
      if ((strStatusText.find("DH-041") != string::npos) && (strStatusText.find("INITIALIZE EPP COMPLETED SUCCESSFULLY") != string::npos))
      {
         m_hAIMSBillingSegment.setTSTAMP_TRANS(m_hEntityStatusSegment.zTSTAMP_TRANS(),16);
         m_hAIMSBillingSegment.setUNIQUENESS_KEY(m_siUniquenessKey);
         m_pAdvantageMessageProcessor = AdvantageMessageProcessor::instance();
         string strRecType = m_pAdvantageMessageProcessor->getMessageCode();
         m_hAIMSBillingSegment.setRECORD_TYPE(strRecType.data(),strRecType.length());
         string strInstId;
         if (ConfigurationRepository::instance()->translate("DEVICE",m_hEntityStatusSegment.zSUBJECT(),strInstId," "," ",-1,false))
         {
            string strINST_ID_RECN_ACQ_B = strInstId.substr(0,11);
            size_t n = strINST_ID_RECN_ACQ_B.find_last_not_of(' ');
            strINST_ID_RECN_ACQ_B.erase(n + 1);
            m_hAIMSBillingSegment.setINST_ID(strINST_ID_RECN_ACQ_B.data(),strINST_ID_RECN_ACQ_B.length());
         }
         m_hAIMSBillingSegment.setTERM_ID(m_hEntityStatusSegment.zSUBJECT(),8);
         m_hAIMSBillingSegment.setBUSINESS_KEY("");
         m_hAIMSBillingSegment.write(&psBuffer);
         iCount++;
      }
   }
   m_hListSegment.update(pData2,iCount,psBuffer - pData2);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageNetstatDisplay::insert%3C618D7501D4.body
}

// Additional Declarations
  //## begin AdvantageNetstatDisplay%3C61324602DE.declarations preserve=yes
  //## end AdvantageNetstatDisplay%3C61324602DE.declarations

//## begin module%3C61375D029F.epilog preserve=yes
//## end module%3C61375D029F.epilog
