//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A52540D00FF.cm preserve=no
//	$Date:   31 Jan 2018 14:11:04  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5A52540D00FF.cm

//## begin module%5A52540D00FF.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A52540D00FF.cp

//## Module: CXOSAI28%5A52540D00FF; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI28.hpp

#ifndef CXOSAI28_h
#define CXOSAI28_h 1

//## begin module%5A52540D00FF.additionalIncludes preserve=no
//## end module%5A52540D00FF.additionalIncludes

//## begin module%5A52540D00FF.includes preserve=yes
//## end module%5A52540D00FF.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
//## begin module%5A52540D00FF.declarations preserve=no
//## end module%5A52540D00FF.declarations

//## begin module%5A52540D00FF.additionalDeclarations preserve=yes
//## end module%5A52540D00FF.additionalDeclarations


//## begin NetstatDisplay%5A52529E00F7.preface preserve=yes
//## end NetstatDisplay%5A52529E00F7.preface

//## Class: NetstatDisplay%5A52529E00F7
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport NetstatDisplay : public AdvantageMessage  //## Inherits: <unnamed>%5A5252E80206
{
  //## begin NetstatDisplay%5A52529E00F7.initialDeclarations preserve=yes
  //## end NetstatDisplay%5A52529E00F7.initialDeclarations

  public:
    //## Constructors (generated)
      NetstatDisplay();

    //## Destructor (generated)
      virtual ~NetstatDisplay();


    //## Other Operations (specified)
      //## Operation: insert%5A52530D00FD
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin NetstatDisplay%5A52529E00F7.public preserve=yes
      //## end NetstatDisplay%5A52529E00F7.public

  protected:
    // Additional Protected Declarations
      //## begin NetstatDisplay%5A52529E00F7.protected preserve=yes
      //## end NetstatDisplay%5A52529E00F7.protected

  private:
    // Additional Private Declarations
      //## begin NetstatDisplay%5A52529E00F7.private preserve=yes
      //## end NetstatDisplay%5A52529E00F7.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin NetstatDisplay%5A52529E00F7.implementation preserve=yes
      //## end NetstatDisplay%5A52529E00F7.implementation

};

//## begin NetstatDisplay%5A52529E00F7.postscript preserve=yes
//## end NetstatDisplay%5A52529E00F7.postscript

//## begin module%5A52540D00FF.epilog preserve=yes
//## end module%5A52540D00FF.epilog


#endif
