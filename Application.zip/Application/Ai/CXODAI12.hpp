//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3C61394001A5.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C61394001A5.cm

//## begin module%3C61394001A5.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3C61394001A5.cp

//## Module: CXOSAI12%3C61394001A5; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Pvcswork\Dn\Server\Application\Ai\CXODAI12.hpp

#ifndef CXOSAI12_h
#define CXOSAI12_h 1

//## begin module%3C61394001A5.additionalIncludes preserve=no
//## end module%3C61394001A5.additionalIncludes

//## begin module%3C61394001A5.includes preserve=yes
// $Date:   Jan 31 2018 14:07:10  $ $Author:   e1009839  $ $Revision:   1.13  $
//## end module%3C61394001A5.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialAdjustmentExtensionSegment;
class FinancialSettlementSegment;
class FinancialAdjustmentSegment;
class FinancialBaseSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Foundation::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
class DateTime;
} // namespace IF

class AdvantageMessageProcessor;

//## begin module%3C61394001A5.declarations preserve=no
//## end module%3C61394001A5.declarations

//## begin module%3C61394001A5.additionalDeclarations preserve=yes
//## end module%3C61394001A5.additionalDeclarations


//## begin AdvantagePlusAdjustment%3C6133A80148.preface preserve=yes
//## end AdvantagePlusAdjustment%3C6133A80148.preface

//## Class: AdvantagePlusAdjustment%3C6133A80148
//## Category: Platform \: Advantage::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3C63E6E80232;IF::Message { -> F}
//## Uses: <unnamed>%3C63E6EC005D;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C63E75E0109;process::Application { -> F}
//## Uses: <unnamed>%3C63E761008C;IF::CodeTable { -> F}
//## Uses: <unnamed>%3C63E764006D;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3C63E768009C;IF::DateTime { -> F}
//## Uses: <unnamed>%3C63E76B0251;repositorysegment::FinancialAdjustmentExtensionSegment { -> F}
//## Uses: <unnamed>%3C63E77C0242;repositorysegment::FinancialAdjustmentSegment { -> F}
//## Uses: <unnamed>%3C63E780009C;repositorysegment::FinancialBaseSegment { -> F}
//## Uses: <unnamed>%3C63E78303D8;repositorysegment::FinancialSettlementSegment { -> F}
//## Uses: <unnamed>%3C63E7BA000F;AdvantageMessageProcessor { -> F}

class AdvantagePlusAdjustment : public AdvantageMessage  //## Inherits: <unnamed>%3C63D82A0222
{
  //## begin AdvantagePlusAdjustment%3C6133A80148.initialDeclarations preserve=yes
  //## end AdvantagePlusAdjustment%3C6133A80148.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantagePlusAdjustment();

    //## Destructor (generated)
      virtual ~AdvantagePlusAdjustment();


    //## Other Operations (specified)
      //## Operation: insert%3C63D82E03D8
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantagePlusAdjustment%3C6133A80148.public preserve=yes
      //## end AdvantagePlusAdjustment%3C6133A80148.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantagePlusAdjustment%3C6133A80148.protected preserve=yes
      //## end AdvantagePlusAdjustment%3C6133A80148.protected

  private:
    // Additional Private Declarations
      //## begin AdvantagePlusAdjustment%3C6133A80148.private preserve=yes
      //## end AdvantagePlusAdjustment%3C6133A80148.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin AdvantagePlusAdjustment%3C6133A80148.implementation preserve=yes
      //## end AdvantagePlusAdjustment%3C6133A80148.implementation

};

//## begin AdvantagePlusAdjustment%3C6133A80148.postscript preserve=yes
//## end AdvantagePlusAdjustment%3C6133A80148.postscript

//## begin module%3C61394001A5.epilog preserve=yes
//## end module%3C61394001A5.epilog


#endif
