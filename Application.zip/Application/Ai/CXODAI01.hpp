//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C6135D500AB.cm preserve=no
//	$Date:   May 27 2020 15:01:38  $ $Author:   e5579974  $
//	$Revision:   1.29  $
//## end module%3C6135D500AB.cm

//## begin module%3C6135D500AB.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C6135D500AB.cp

//## Module: CXOSAI01%3C6135D500AB; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI01.hpp

#ifndef CXOSAI01_h
#define CXOSAI01_h 1

//## begin module%3C6135D500AB.additionalIncludes preserve=no
//## end module%3C6135D500AB.additionalIncludes

//## begin module%3C6135D500AB.includes preserve=yes
#ifdef _WIN32
#include <winsock.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#ifndef CXOSRS28_h
#include "CXODRS28.hpp"
#endif
#include <map>
//## end module%3C6135D500AB.includes

#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSRU05_h
#include "CXODRU05.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSDB49_h
#include "CXODDB49.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSTM10_h
#include "CXODTM10.hpp"
#endif
#ifndef CXOSAI26_h
#include "CXODAI26.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSRS05_h
#include "CXODRS05.hpp"
#endif
#ifndef CXOSRS10_h
#include "CXODRS10.hpp"
#endif
#ifndef CXOSSI01_h
#include "CXODSI01.hpp"
#endif

class AdvantageMessageProcessor;

//## begin module%3C6135D500AB.declarations preserve=no
//## end module%3C6135D500AB.declarations

//## begin module%3C6135D500AB.additionalDeclarations preserve=yes
//## end module%3C6135D500AB.additionalDeclarations


//## begin AdvantageMessage%3C61312E031C.preface preserve=yes
//## end AdvantageMessage%3C61312E031C.preface

//## Class: AdvantageMessage%3C61312E031C
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3C628A4A0290;IF::Message { -> }
//## Uses: <unnamed>%3C73DBAA003E;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%3E075E0900CB;timer::NonStopClock { -> }
//## Uses: <unnamed>%50C76BD501EE;entitysegment::Customer { -> }
//## Uses: <unnamed>%5A53DD0D0124;monitor::UseCase { -> }
//## Uses: <unnamed>%5A53DD13031C;switchinterface::SwitchInterface { -> }
//## Uses: <unnamed>%5A53DD1502E4;Template { -> }
//## Uses: <unnamed>%5ABD4A0C0157;configuration::ConfigurationRepository { -> }
//## Uses: <unnamed>%5ABE2E9C01C9;database::UniquenessKey { -> }
//## Uses: <unnamed>%5ABE3585005C;IF::CodeTable { -> }

class AdvantageMessage : public reusable::Object  //## Inherits: <unnamed>%3C61315E02EE
{
  //## begin AdvantageMessage%3C61312E031C.initialDeclarations preserve=yes
  //## end AdvantageMessage%3C61312E031C.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageMessage();

    //## Constructors (specified)
      //## Operation: AdvantageMessage%3C628ED70000
      AdvantageMessage (const char* pszMessageCode, const char* pszSegmentID);

    //## Destructor (generated)
      virtual ~AdvantageMessage();


    //## Other Operations (specified)
      //## Operation: deport%5A54BE9801BD
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool deport (Message& hMessage);

      //## Operation: insert%3C6183730186
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

      //## Operation: reformatInstId%3C62DB840242
      void reformatInstId (const char* psAdvgInstId);

      //## Operation: setTSTAMP_TRANS%5A54C798036B
      void setTSTAMP_TRANS (const char* sNonStopClock);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: AsciiInput%5A54BAFF01B3
      static const bool& getAsciiInput ()
      {
        //## begin AdvantageMessage::getAsciiInput%5A54BAFF01B3.get preserve=no
        return m_bAsciiInput;
        //## end AdvantageMessage::getAsciiInput%5A54BAFF01B3.get
      }

      static void setAsciiInput (const bool& value)
      {
        //## begin AdvantageMessage::setAsciiInput%5A54BAFF01B3.set preserve=no
        m_bAsciiInput = value;
        //## end AdvantageMessage::setAsciiInput%5A54BAFF01B3.set
      }


      //## Attribute: MessageCode%3C628EA30280
      const string& getMessageCode () const
      {
        //## begin AdvantageMessage::getMessageCode%3C628EA30280.get preserve=no
        return m_strMessageCode;
        //## end AdvantageMessage::getMessageCode%3C628EA30280.get
      }


      //## Attribute: SegmentID%3C628EAB0196
      const string& getSegmentID () const
      {
        //## begin AdvantageMessage::getSegmentID%3C628EAB0196.get preserve=no
        return m_strSegmentID;
        //## end AdvantageMessage::getSegmentID%3C628EAB0196.get
      }


      //## Attribute: TestDate%5A54BC8B003B
      static const string& getTestDate ()
      {
        //## begin AdvantageMessage::getTestDate%5A54BC8B003B.get preserve=no
        return m_strTestDate;
        //## end AdvantageMessage::getTestDate%5A54BC8B003B.get
      }

      static void setTestDate (const string& value)
      {
        //## begin AdvantageMessage::setTestDate%5A54BC8B003B.set preserve=no
        m_strTestDate = value;
        //## end AdvantageMessage::setTestDate%5A54BC8B003B.set
      }


      //## Attribute: TstampHash%3C61840B03D8
      static const unsigned int getTstampHash ()
      {
        //## begin AdvantageMessage::getTstampHash%3C61840B03D8.get preserve=no
        return m_lTstampHash;
        //## end AdvantageMessage::getTstampHash%3C61840B03D8.get
      }

      static void setTstampHash (unsigned int value)
      {
        //## begin AdvantageMessage::setTstampHash%3C61840B03D8.set preserve=no
        m_lTstampHash = value;
        //## end AdvantageMessage::setTstampHash%3C61840B03D8.set
      }


    //## Get and Set Operations for Associations (generated)

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5A54C2A50252
      //## Role: AdvantageMessage::<m_pTransaction>%5A54C2A6017C
      static void setTransaction (repositorysegment::Transaction * value)
      {
        //## begin AdvantageMessage::setTransaction%5A54C2A6017C.set preserve=no
        m_pTransaction = value;
        //## end AdvantageMessage::setTransaction%5A54C2A6017C.set
      }


    // Data Members for Class Attributes

      //## begin AdvantageMessage::TstampHash%3C61840B03D8.attr preserve=no  public: static unsigned int {VA} 0
      static unsigned int m_lTstampHash;
      //## end AdvantageMessage::TstampHash%3C61840B03D8.attr

    // Data Members for Associations

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C6184630261
      //## Role: AdvantageMessage::<m_hAuditSegment>%3C61846400EA
      //## begin AdvantageMessage::<m_hAuditSegment>%3C61846400EA.role preserve=no  public: static repositorysegment::AuditSegment { -> VHgAN}
      static repositorysegment::AuditSegment m_hAuditSegment;
      //## end AdvantageMessage::<m_hAuditSegment>%3C61846400EA.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5A54C2A50252
      //## begin AdvantageMessage::<m_pTransaction>%5A54C2A6017C.role preserve=no  public: static repositorysegment::Transaction { -> RHgAN}
      static repositorysegment::Transaction *m_pTransaction;
      //## end AdvantageMessage::<m_pTransaction>%5A54C2A6017C.role

    // Additional Public Declarations
      //## begin AdvantageMessage%3C61312E031C.public preserve=yes
      void setSegmentID (const string& value)
      {
         m_strSegmentID = value;
      }
      //## end AdvantageMessage%3C61312E031C.public
  protected:
    // Data Members for Class Attributes

      //## begin AdvantageMessage::AsciiInput%5A54BAFF01B3.attr preserve=no  public: static bool {V} true
      static bool m_bAsciiInput;
      //## end AdvantageMessage::AsciiInput%5A54BAFF01B3.attr

      //## Attribute: StdInstId%3C62DB5402EE
      //## begin AdvantageMessage::StdInstId%3C62DB5402EE.attr preserve=no  protected: char[11] {VA} 
      char m_sStdInstId[11];
      //## end AdvantageMessage::StdInstId%3C62DB5402EE.attr

      //## Attribute: UniquenessKey%3C6184340167
      //## begin AdvantageMessage::UniquenessKey%3C6184340167.attr preserve=no  protected: short {VA} 0
      short m_siUniquenessKey;
      //## end AdvantageMessage::UniquenessKey%3C6184340167.attr

    // Additional Protected Declarations
      //## begin AdvantageMessage%3C61312E031C.protected preserve=yes
      //## end AdvantageMessage%3C61312E031C.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageMessage%3C61312E031C.private preserve=yes
      //## end AdvantageMessage%3C61312E031C.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin AdvantageMessage::MessageCode%3C628EA30280.attr preserve=no  public: string {V} 
      string m_strMessageCode;
      //## end AdvantageMessage::MessageCode%3C628EA30280.attr

      //## begin AdvantageMessage::SegmentID%3C628EAB0196.attr preserve=no  public: string {V} 
      string m_strSegmentID;
      //## end AdvantageMessage::SegmentID%3C628EAB0196.attr

      //## begin AdvantageMessage::TestDate%5A54BC8B003B.attr preserve=no  public: static string {V} 
      static string m_strTestDate;
      //## end AdvantageMessage::TestDate%5A54BC8B003B.attr

    // Additional Implementation Declarations
      //## begin AdvantageMessage%3C61312E031C.implementation preserve=yes
      //## end AdvantageMessage%3C61312E031C.implementation

};

//## begin AdvantageMessage%3C61312E031C.postscript preserve=yes
//## end AdvantageMessage%3C61312E031C.postscript

//## begin module%3C6135D500AB.epilog preserve=yes
//## end module%3C6135D500AB.epilog


#endif
