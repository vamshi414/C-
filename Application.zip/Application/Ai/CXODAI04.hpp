//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C6136CD0251.cm preserve=no
//	$Date:   Dec 18 2020 01:29:02  $ $Author:   E5350313  $
//	$Revision:   1.16  $
//## end module%3C6136CD0251.cm

//## begin module%3C6136CD0251.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C6136CD0251.cp

//## Module: CXOSAI04%3C6136CD0251; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Dn_codes\V03.1A.R011\Dn\Server\Application\Ai\CXODAI04.hpp

#ifndef CXOSAI04_h
#define CXOSAI04_h 1

//## begin module%3C6136CD0251.additionalIncludes preserve=no
//## end module%3C6136CD0251.additionalIncludes

//## begin module%3C6136CD0251.includes preserve=yes
// $Date:   Dec 18 2020 01:29:02  $ $Author:   E5350313  $ $Revision:   1.16  $
//## end module%3C6136CD0251.includes

#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
#ifndef CXOSRS84_h
#include "CXODRS84.hpp"
#endif
#ifndef CXOSRSA7_h
#include "CXODRSA7.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class AdvantageMessageProcessor;
//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class DateTime;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class KeyRing;
} // namespace reusable

namespace IF {
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%3C6136CD0251.declarations preserve=no
//## end module%3C6136CD0251.declarations

//## begin module%3C6136CD0251.additionalDeclarations preserve=yes
struct hCardHolder
{
   char sRecType[2];                   // 0000
   char sSegType[2];                   // 0002
   short siStepNo;                     // 0004
   char sSourceId[16];                 // 0006
   char sCrtTermIdent[16];             // 0022
   char sTimeStamp[14];                // 0038
   char sNegStatKey[6];                // 0052
                                       // 0058
};

struct hCardHolderKey
{
   char sFRDABA[10];                   // 0000
   char sCardGroup[6];                 // 0010
   char sPan[19];                      // 0016
   char sPlasticNo[5];                 // 0035
                                       // 0040
};

struct hAcctHolderKey
{
   char sFRDABA[10];                   // 0000
   char sAcctType[4];                  // 0010
   char sAcctNo[28];                   // 0014
};                                     // 0042

struct hCardHolder100Old
{
   char sIssFIId[10];                  // 0000
   char sStatus[2];                    // 0010
   short siCardAccess;                 // 0012
   char sLastUsedTstamp[8];            // 0014
   short siPinFailCT;                  // 0022
   char sLimitGroupID[6];              // 0024
   char sFeeGroup[6];                  // 0030
   char cCardAct;                      // 0036
   char cCardInfoFiller;               // 0037
   char sUpdtTstamp[8];                // 0038
   char sMntTstamp[8];                 // 0046
                                       // 0054
};
struct hCardHolder100New
{
   char sIssFIId[10];                  // 0000
   char sStatus[2];                    // 0010
   short siCardAccess;                 // 0012
   char sLastUsedTstamp[8];            // 0014
   short siPinFailCT;                  // 0022
   char sLimitGroupID[6];              // 0024
   char sFeeGroup[6];                  // 0030
   char cCardAct;                      // 0036
   char cCardInfoFiller;               // 0037
   char sUpdtTstamp[8];                // 0038
   char sMntTstamp[8];                 // 0046
                                       // 0054 
};
struct hCardHolder101Old
{
   short siPinAuthFlag;                // 0000
   char sPinAuthVal[16];               // 0002
   char sTrk2DateYYMM[4];              // 0018
                                       // 0022      
};
struct hCardHolder101New
{
   short siPinAuthFlag;                // 0000
   char sPinAuthVal[16];               // 0002
   char sTrk2DateYYMM[4];              // 0018
                                       // 0022          
                                   
};
struct hCardHolder102Old
{
   char sAcctFIId[10];                 // 0000
   char sAcctType[4];                  // 0010
   char sAcctNo[28];                   // 0014
   char sAcctQual[3];                  // 0042
   char sOarSelType[3];                // 0045
   char sAcctDesc[20];                 // 0048
   short siAcctAccess;                 // 0068
   char cPrimaryInd;                   // 0070
   char cFundingInd;                   // 0071
                                       // 0072
};
struct hCardHolder102New
{
   char sAcctFIId[10];                 // 0000
   char sAcctType[4];                  // 0010
   char sAcctNo[28];                   // 0014
   char sAcctQual[3];                  // 0042
   char sOarSelType[3];                // 0045
   char sAcctDesc[20];                 // 0048
   short siAcctAccess;                 // 0068
   char cPrimaryInd;                   // 0070
   char cFundingInd;                   // 0071
                                       // 0072                                  
};

struct hCardHolder103Old
{
   char sLimitId[6];                   // 0000
   int iLimitAmnt;                     // 0006
   short siLimitUses;                  // 0010
   int iIncrAmnt;                      // 0012
   int iMinAmnt;                       // 0016
   short siPercntDepAval;              // 0020
                                       // 0022
};
struct hCardHolder103New
{
   char sLimitId[6];                   // 0000
   int iLimitAmnt;                     // 0006
   short siLimitUses;                  // 0010
   int iIncrAmnt;                      // 0012
   int iMinAmnt;                       // 0016
   short siPercntDepAval;              // 0020
                                       // 0022                                 
};
struct hCardHolder104Old
{  
   int iAmnt;                          // 0000
   char sExpTime[8];                   // 0004
   char sMatchData[36];                // 0012
   char sLimitId[6];                   // 0048
                                       // 0054
};
struct hCardHolder104New
{ 
   int iAmnt;                          // 0000
   char sExpTime[8];                   // 0004
   char sMatchData[36];                // 0012
   char sLimitId[6];                   // 0048
                                       // 0054                                            
};

struct hCardHolder105Old
{
   char sFIID[10];                     // 0000
   char sAcctType[4];                  // 0010
   char sAcctNo[28];                   // 0014
   char sPaymentAcctID[28];            // 0042
                                       // 0070
};
struct hCardHolder105New
{
   char sFIID[10];                     // 0000
   char sAcctType[4];                  // 0010
   char sAcctNo[28];                   // 0014
   char sPaymentAcctID[28];            // 0042
                                       // 0070       
};
struct hCardHolder106Old
{
   char sGreetingName[20];             // 0000
                                       // 0020         
};
struct hCardHolder106New
{
   char sGreetingName[20];             // 0000
                                       // 0020
};
struct hCardHolder107Old
{
   char sLimitID[6];                   // 0000
   char sBeginTstamp[8];               // 0006
   char sEndTstamp[8];                 // 0014
   char sOvExpireFiller[26];           // 0022
                                       // 0048
};
struct hCardHolder107New
{
   char sLimitID[6];                   // 0000
   char sBeginTstamp[8];               // 0006
   char sEndTstamp[8];                 // 0014
   char sOvExpireFiller[26];           // 0022
                                       // 0048                                  
};
struct hCardHolder108Old
{
	char sCoNameOne[26];                // 0000
	char sCoNameTwo[26];                // 0026
	char sCoNameThree[26];              // 0052
	char sCoAddressOne[30];             // 0078
	char sCoAddressTwo[30];             // 0108
	char sCoZipCode[9];                 // 0138
	char cFiller;                       // 0147
										// 0148
};
struct hCardHolder108New
{
	char sCoNameOne[26];                // 0000
	char sCoNameTwo[26];                // 0026
	char sCoNameThree[26];              // 0052
	char sCoAddressOne[30];             // 0078
	char sCoAddressTwo[30];             // 0108
	char sCoZipCode[9];                 // 0138
	char cFiller;                       // 0147
										// 0148
};
struct hCardHolder109Old
{
	char sName[20];                     // 0000
	char sIssueDtMMDDYY[6];             // 0020
	char sReIssueDtMMDDYY[6];           // 0026
	char sCloseDtMMDDYY[6];             // 0032
	char sComments[20];                 // 0038
										// 0058                                  
};
struct hCardHolder109New
{
	char sName[20];                     // 0000
	char sIssueDtMMDDYY[6];             // 0020
	char sReIssueDtMMDDYY[6];           // 0026
	char sCloseDtMMDDYY[6];             // 0032
	char sComments[20];                 // 0038
										// 0058                                  
};
struct hCardHolder110Old
{
   short siConsecutiveRejects;         // 0000
   short siPrevConsecutiveRejects;     // 0002
   char sCardType[2];                  // 0004
   char sAddlCardFiller[44];           // 0006
                                       // 0050
};
struct hCardHolder110New
{
   short siConsecutiveRejects;         // 0000
   short siPrevConsecutiveRejects;     // 0002
   char sCardType[2];                  // 0004
   char sAddlCardFiller[44];           // 0006
                                       // 0050
};
struct hCardHolder112Old
{
   char sAddress1[90];                    // 0000
   char cCardCondFlag;                    // 0090
   char cAutoIssInd;                      // 0091
   char sLastMaintTstamp[14];             // 0092
   char sComments[30];                    // 0106
                                          // 0136
};
struct hCardHolder112New
{
   char sAddress1[90];                    // 0000
   char cCardCondFlag;                    // 0090
   char cAutoIssInd;                      // 0091
   char sLastMaintTstamp[14];             // 0092
   char sComments[30];                    // 0106
                                          // 0136
};
struct hCardHolder113Old
{
   char sMemberNum[2];                    // 0000
   char sCardName1[12];                   // 0002
   char sCardName2[17];                   // 0014
   char cCardName3;                       // 0031
   char cCardOrdTypeFlag;                 // 0032
   char cCardStatFlag;                    // 0033
   char sCardStatTstamp[8];               // 0034
   char cLastIssFlag;                     // 0042
   char cCardReplacement;                 // 0043
   char sDateIssTstamp[8];                // 0044
   char sLastIssTstamp[8];                // 0052
   char cPhotoId;                         // 0060
   char sCardCollectionCode[3];           // 0061
                                          // 0064
};
struct hCardHolder113New
{
   char sMemberNum[2];                   // 0000
   char sCardName1[12];                  // 0002
   char sCardName2[17];                  // 0014
   char cCardName3;                      // 0031
   char cCardOrdTypeFlag;                // 0032
   char cCardStatFlag;                   // 0033
   char sCardStatTstamp[8];              // 0034
   char cLastIssFlag;                    // 0042
   char cCardReplacement;                // 0043
   char sDateIssTstamp[8];               // 0044
   char sLastIssTstamp[8];               // 0052
   char cPhotoId;                        // 0060
   char sCardCollectionCode[3];          // 0061
                                         // 0064
};
struct hCardHolder114Old
{
	char sAddress1[30];                   // 0000
	char sAddress2[30];                   // 0030
	char sCity[19];                       // 0060
	char sState[2];                       // 0079
	char sZipCode[9];                     // 0081
	char cCardConditionFlag;              // 0090
	char cAutoIssuerInd;                  // 0091
	char sLastMaintTStamp[14];            // 0092
	char sComments[30];                   // 0106
										  // 0136
};
struct hCardHolder114New
{
	char sAddress1[30];                   // 0000
	char sAddress2[30];                   // 0030
	char sCity[19];                       // 0060
	char sState[2];                       // 0079
	char sZipCode[9];                     // 0081
	char cCardConditionFlag;              // 0090
	char cAutoIssuerInd;                  // 0091
	char sLastMaintTStamp[14];            // 0092
	char sComments[30];                   // 0106
										  // 0136
};
struct hCardHolder115Old
{
   char sSocialSecurityNum[9];            // 0000
   char sMaidenName[17];                  // 0009
   char sHomePh[10];                      // 0026
   char sWorkPh[10];                      // 0036
   char sUserValidation[25];              // 0046
   char cVruCounter;                      // 0071
   char sDOB[8];                          // 0072
   char sActTstamp[8];                    // 0080
   char cActMethod;                       // 0088
   char sPrevTrk2DateYYMM[4];             // 0089
   char cPrevCardAct;                     // 0093
                                          // 0094
};
struct hCardHolder115New
{
   char sSocialSecurityNum[9];            // 0000
   char sMaidenName[17];                  // 0009
   char sHomePh[10];                      // 0026
   char sWorkPh[10];                      // 0036
   char sUserValidation[25];              // 0046
   char cVruCounter;                      // 0071
   char sDOB[8];                          // 0072
   char sActTstamp[8];                    // 0080
   char cActMethod;                       // 0088
   char sPrevTrk2DateYYMM[4];             // 0089
   char cPrevCardAct;                     // 0093
                                          // 0094
};
struct hCardHolder116Old
{
   char sInAuthLastChgd[8];               // 0000
   char sDoNotDisturb[8];                 // 0008
   char sCiStatusLastSet[8];              // 0016
   char sCiStatusLastRemoved[8];          // 0024
   char cCiStatusSetBy;                   // 0032
   char cCiStatusRemovedBy;               // 0033
   char cObsolete[20];                    // 0034   
};
struct hCardHolder116New
{
   char sInAuthLastChgd[8];               // 0000
   char sDoNotDisturb[8];                 // 0008
   char sCiStatusLastSet[8];              // 0016
   char sCiStatusLastRemoved[8];          // 0024
   char cCiStatusSetBy;                   // 0032
   char cCiStatusRemovedBy;               // 0033
   char cObsolete[20];                    // 0034
};
struct hCardHolder117Old
{
   char sLastManitTstamp[26];             // 0000
   char sCardStatus[2];                   // 0026
   char sPrevCardStatus[2];               // 0028
   char sLastCardStatTstamp[26];          // 0030
   char cConverted;                       // 0056
   char sConvertedTstamp[26];             // 0057
   char cActMeth;                         // 0083
   char sActTstamp[26];                   // 0084
   char sPrevCardTrackII[4];              // 0110
   char cPrevCardActFlag;                 // 0114
   char sLastPinChgTstamp[26];            // 0115
   char sLastPinOffset[16];               // 0141
   char sMediaType[2];                    // 0157
   char sServiceCode[3];                  // 0159
   char sCardProfile[12];                 // 0162
   char cAutoIssueInd;                    // 0174
   char cCardAssociation;                 // 0175
   char sCardType[2];                     // 0176
   char sCardSubType[2];                  // 0178
   char sCardCategory[2];                 // 0180
   char cCardCompanionMint;               // 0182
   char cCardCompanionMicro;              // 0183
   char cCardCompanionMobile;             // 0184
   char sCustomerSince[10];               // 0185
   char cVIPInd;                          // 0195
   char sEmbossedBusiness[26];            // 0196
   char cContactPref;                     // 0222
   char sCredLimitRef[9];                 // 0223
   char sCashLimitRef[9];                 // 0232
   char cPwrOfAttrnyFlag;                 // 0241
   char sPwrOfAttrnyName[40];             // 0242
   char sBankBranchNo[7];                 // 0282
   char cVRUCntrCardAct;                  // 0289
   char cVRUCntrPinChg;                   // 0300
   char sAlertEventNo[25];                // 0301
   char sAlertEventDate[10];              // 0326
   char sAlertEventLTD[2];                // 0336
   char sSchdBlockDate[26];               // 0338
   char cSeverityLvl;                     // 0364
   char cTravelInd;                       // 0365
   char sTravelStartDate[10];             // 0366
   char sTravelEndDate[10];               // 0376
   char sAlertFlag1[3];                   // 0386
   char sAlertFlag2[3];                   // 0389
   char sAlertFlag3[3];                   // 0392
   char cVAUABUOptOutInd;                 // 0395
   char sAltCardType[2];                  // 0396
   char cLoyaltyOptOutFlag;               // 0398
   char sFiller[197];                     // 0399
};                                        // 0596
struct hCardHolder117New
{
   char sLastManitTstamp[26];             // 0000
   char sCardStatus[2];                   // 0026
   char sPrevCardStatus[2];               // 0028
   char sLastCardStatTstamp[26];          // 0030
   char cConverted;                       // 0056
   char sConvertedTstamp[26];             // 0057
   char cActMeth;                         // 0083
   char sActTstamp[26];                   // 0084
   char sPrevCardTrackII[4];              // 0110
   char cPrevCardActFlag;                 // 0114
   char sLastPinChgTstamp[26];            // 0115
   char sLastPinOffset[16];               // 0141
   char sMediaType[2];                    // 0157
   char sServiceCode[3];                  // 0159
   char sCardProfile[12];                 // 0162
   char cAutoIssueInd;                    // 0174
   char cCardAssociation;                 // 0175
   char sCardType[2];                     // 0176
   char sCardSubType[2];                  // 0178
   char sCardCategory[2];                 // 0180
   char cCardCompanionMint;               // 0182
   char cCardCompanionMicro;              // 0183
   char cCardCompanionMobile;             // 0184
   char sCustomerSince[10];               // 0185
   char cVIPInd;                          // 0195
   char sEmbossedBusiness[26];            // 0196
   char cContactPref;                     // 0222
   char sCredLimitRef[9];                 // 0223
   char sCashLimitRef[9];                 // 0232
   char cPwrOfAttrnyFlag;                 // 0241
   char sPwrOfAttrnyName[40];             // 0242
   char sBankBranchNo[7];                 // 0282
   char cVRUCntrCardAct;                  // 0289
   char cVRUCntrPinChg;                   // 0300
   char sAlertEventNo[25];                // 0301
   char sAlertEventDate[10];              // 0326
   char sAlertEventLTD[2];                // 0336
   char sSchdBlockDate[26];               // 0338
   char cSeverityLvl;                     // 0364
   char cTravelInd;                       // 0365
   char sTravelStartDate[10];             // 0366
   char sTravelEndDate[10];               // 0376
   char sAlertFlag1[3];                   // 0386
   char sAlertFlag2[3];                   // 0389
   char sAlertFlag3[3];                   // 0392
   char cVAUABUOptOutInd;                 // 0395
   char sAltCardType[2];                  // 0396
   char cLoyaltyOptOutFlag;               // 0398
   char sFiller[197];                     // 0399
};                                        // 0596
struct hCardHolder124Old
{
	char cPinRequired;                     // 0000
	char cOdometerRequired;                // 0001
	char cCategoryValid;                   // 0002
										   // 0003
};
struct hCardHolder124New
{
	char cPinRequired;                     // 0000
	char cOdometerRequired;                // 0001
	char cCategoryValid;                   // 0002
										   // 0003
};

struct hCardHolder118Old
{
   short siPartKey;
   char sFI_ID[10];
   char sCardGroup[6];
   char sPan[19];
   char sPlastic[5];
   char sAcctType[4];
   char sAcctNo[28];
   char sCreateTime[26];
   char sTranIdent[16];
   char sTermRef[12];
   char cPreAuthInd;
   char sAcqDay[2];
   char sAuthNbr[6];
   char sLimitID[6];
   char cHoldType;
   char sExpTime[26];
   char sAmount[12];
   char sMerchName[25];
   char cHoldStatus;
   char sMerchCode[4];
   char sExpUserID[32];
   char sLastMaintTstamp[26];
};
struct hCardHolder118New
{
   short siPartKey;
   char sFI_ID[10];
   char sCardGroup[6];
   char sPan[19];
   char sPlastic[5];
   char sAcctType[4];
   char sAcctNo[28];
   char sCreateTime[26];
   char sTranIdent[16];
   char sTermRef[12];
   char cPreAuthInd;
   char sAcqDay[2];
   char sAuthNbr[6];
   char sLimitID[6];
   char cHoldType;
   char sExpTime[26];
   char sAmount[12];
   char sMerchName[25];
   char cHoldStatus;
   char sMerchCode[4];
   char sExpUserID[32];
   char sLastMaintTstamp[26];
};

struct hCardHolder119Old
{
   char sStopID[19];
   char sLastMaintTstamp[26];
   char sStopLevel[3];
   char sStopType[2];
   char sStopReason[2];
   char sStopStartDate[10];
   char sStopEndDate[10];
   char sTranAmount[12];
   char sAmountLow[12];
   char sAmountHigh[12];
   char sStopRetrevialRefNo[12];
   char sStopIndex[12];
   char cVisaRestrictRIIND;
   char sStopCreatedTstamp[26];
   char sStopPaymentFiller[225];
   char sOrigTranType[3];
   char sOrigPaymentType[10];
   char sOrigTranDate[8];
   char sOrigTranAmount[12];
   char sOrigTranRRN[12];
   char sMerchantName[25];
   char sMCC[4];
   char sPaymentFacID[11];
   char sSubMerchantID[15];
   char sCardAcptID[15];
   char sMCAcqID[6];
   char sOrigTranFiller[100];
};

struct hCardHolder119New
{
   char sStopID[19];
   char sLastMaintTstamp[26];
   char sStopLevel[3];
   char sStopType[2];
   char sStopReason[2];
   char sStopStartDate[10];
   char sStopEndDate[10];
   char sTranAmount[12];
   char sAmountLow[12];
   char sAmountHigh[12];
   char sStopRetrevialRefNo[12];
   char sStopIndex[12];
   char cVisaRestrictRIIND;
   char sStopCreatedTstamp[26];
   char sStopPaymentFiller[225];
   char sOrigTranType[3];
   char sOrigPaymentType[10];
   char sOrigTranDate[8];
   char sOrigTranAmount[12];
   char sOrigTranRRN[12];
   char sMerchantName[25];
   char sMCC[4];
   char sPaymentFacID[11];
   char sSubMerchantID[15];
   char sCardAcptID[15];
   char sMCAcqID[6];
   char sOrigTranFiller[100];
};
//## end module%3C6136CD0251.additionalDeclarations


//## begin AdvantageAPCardMaintenance%3C6131EB002E.preface preserve=yes
//## end AdvantageAPCardMaintenance%3C6131EB002E.preface

//## Class: AdvantageAPCardMaintenance%3C6131EB002E
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3C62F542038A;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C62F578002E;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%3C62F58D032C;IF::Message { -> F}
//## Uses: <unnamed>%3C62F59E03C8;IF::DateTime { -> F}
//## Uses: <unnamed>%3C62F5B2002E;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3C62F5C802CE;process::Application { -> F}
//## Uses: <unnamed>%3C62F903004E;IF::CodeTable { -> F}
//## Uses: <unnamed>%4FF49C6402EB;reusable::KeyRing { -> F}

class AdvantageAPCardMaintenance : public AdvantageMessage  //## Inherits: <unnamed>%3C6132080213
{
  //## begin AdvantageAPCardMaintenance%3C6131EB002E.initialDeclarations preserve=yes
  //## end AdvantageAPCardMaintenance%3C6131EB002E.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageAPCardMaintenance();

    //## Destructor (generated)
      virtual ~AdvantageAPCardMaintenance();


    //## Other Operations (specified)
      //## Operation: insert%3C618E9D005D
      virtual bool insert (Message& hMessage);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: AD14Message%5C6C1BD1007A
      const bool& getAD14Message () const
      {
        //## begin AdvantageAPCardMaintenance::getAD14Message%5C6C1BD1007A.get preserve=no
        return m_bAD14Message;
        //## end AdvantageAPCardMaintenance::getAD14Message%5C6C1BD1007A.get
      }

      void setAD14Message (const bool& value)
      {
        //## begin AdvantageAPCardMaintenance::setAD14Message%5C6C1BD1007A.set preserve=no
        m_bAD14Message = value;
        //## end AdvantageAPCardMaintenance::setAD14Message%5C6C1BD1007A.set
      }


    // Additional Public Declarations
      //## begin AdvantageAPCardMaintenance%3C6131EB002E.public preserve=yes
     // bool addComma (Fields* ppszFields,char* pBuffer,char** pFormatted,int* ilen,string &strDelimiter);
      //## end AdvantageAPCardMaintenance%3C6131EB002E.public
  protected:
    // Additional Protected Declarations
      //## begin AdvantageAPCardMaintenance%3C6131EB002E.protected preserve=yes
      //## end AdvantageAPCardMaintenance%3C6131EB002E.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageAPCardMaintenance%3C6131EB002E.private preserve=yes
      //## end AdvantageAPCardMaintenance%3C6131EB002E.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin AdvantageAPCardMaintenance::AD14Message%5C6C1BD1007A.attr preserve=no  public: bool {V} false
      bool m_bAD14Message;
      //## end AdvantageAPCardMaintenance::AD14Message%5C6C1BD1007A.attr

    // Data Members for Associations

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%4F982506039E
      //## Role: AdvantageAPCardMaintenance::<m_hAuditMaintSegment>%4F982507038E
      //## begin AdvantageAPCardMaintenance::<m_hAuditMaintSegment>%4F982507038E.role preserve=no  public: repositorysegment::AuditMaintSegment { -> VHgN}
      repositorysegment::AuditMaintSegment m_hAuditMaintSegment;
      //## end AdvantageAPCardMaintenance::<m_hAuditMaintSegment>%4F982507038E.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5C6A8B360222
      //## Role: AdvantageAPCardMaintenance::<m_hAIMSBillingSegment>%5C6A8B3702F3
      //## begin AdvantageAPCardMaintenance::<m_hAIMSBillingSegment>%5C6A8B3702F3.role preserve=no  public: repositorysegment::AIMSBillingSegment { -> VHgN}
      repositorysegment::AIMSBillingSegment m_hAIMSBillingSegment;
      //## end AdvantageAPCardMaintenance::<m_hAIMSBillingSegment>%5C6A8B3702F3.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5FDB77360226
      //## Role: AdvantageAPCardMaintenance::<m_hListSegment>%5FDB77380056
      //## begin AdvantageAPCardMaintenance::<m_hListSegment>%5FDB77380056.role preserve=no  public: segment::ListSegment { -> VHgN}
      segment::ListSegment m_hListSegment;
      //## end AdvantageAPCardMaintenance::<m_hListSegment>%5FDB77380056.role

    // Additional Implementation Declarations
      //## begin AdvantageAPCardMaintenance%3C6131EB002E.implementation preserve=yes
      map<string,pair<Fields*,Fields*>,less<string> > m_hCardHolder;
      AdvantageMessageProcessor* m_pAdvantageMessageProcessor;
      //## end AdvantageAPCardMaintenance%3C6131EB002E.implementation
};

//## begin AdvantageAPCardMaintenance%3C6131EB002E.postscript preserve=yes
//## end AdvantageAPCardMaintenance%3C6131EB002E.postscript

//## begin module%3C6136CD0251.epilog preserve=yes
//## end module%3C6136CD0251.epilog


#endif
