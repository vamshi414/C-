//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EB1CFA20278.cm preserve=no
//   $Date:   Oct 22 2020 14:14:48  $ $Author:   e3023547  $
//   $Revision:   1.1  $
//## end module%5EB1CFA20278.cm

//## begin module%5EB1CFA20278.cp preserve=no
//   Copyright (c) 1997 - 2012
//   FIS
//## end module%5EB1CFA20278.cp

//## Module: CXOSAI46%5EB1CFA20278; Package body
//## Subsystem: AI%3597E7CC007A
//   .
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI46.cpp

//## begin module%5EB1CFA20278.additionalIncludes preserve=no
//## end module%5EB1CFA20278.additionalIncludes

//## begin module%5EB1CFA20278.includes preserve=yes
#include "CXODRS28.hpp"
//## end module%5EB1CFA20278.includes

#ifndef CXOSAI46_h
#include "CXODAI46.hpp"
#endif
//## begin module%5EB1CFA20278.declarations preserve=no
//## end module%5EB1CFA20278.declarations

//## begin module%5EB1CFA20278.additionalDeclarations preserve=yes
namespace
{
#define FIELDS100 11
struct new_hCardHolder100* phCardHolder100 = 0;
Fields hCardHolder100_Fields[FIELDS100 + 1] =
{
   "a         ","",offsetof(new_hCardHolder100,sIssFIId),sizeof(phCardHolder100->sIssFIId),
   "a         ","",offsetof(new_hCardHolder100,sStatus),sizeof(phCardHolder100->sStatus),
   "b         "," WD DP IQ PT PF TT TF PR 3P DF",offsetof(new_hCardHolder100,siCardAccess),sizeof(phCardHolder100->siCardAccess),
   "t         ","",offsetof(new_hCardHolder100,sLastUsedTstamp),sizeof(phCardHolder100->sLastUsedTstamp),
   "s         ","",offsetof(new_hCardHolder100,siPinFailCT),sizeof(phCardHolder100->siPinFailCT),
   "a         ","",offsetof(new_hCardHolder100,sLimitGroupID),sizeof(phCardHolder100->sLimitGroupID),
   "a         ","",offsetof(new_hCardHolder100,sFeeGroup),sizeof(phCardHolder100->sFeeGroup),
   "a         ","",offsetof(new_hCardHolder100,cCardAct),sizeof(phCardHolder100->cCardAct),
   "o         ","",offsetof(new_hCardHolder100,cCardInfoFiller),sizeof(phCardHolder100->cCardInfoFiller),
   "t         ","",offsetof(new_hCardHolder100,sUpdtTstamp),sizeof(phCardHolder100->sUpdtTstamp),
   "t         ","",offsetof(new_hCardHolder100,sMntTstamp),sizeof(phCardHolder100->sMntTstamp),
   "~","",0,sizeof(new_hCardHolder100),
};

#define FIELDS101 3
struct new_hCardHolder101* phCardHolder101 = 0;
Fields hCardHolder101_Fields[FIELDS101 + 1] =
{
   "s         ","",offsetof(new_hCardHolder101,siPinAuthFlag),sizeof(phCardHolder101->siPinAuthFlag),
   "a         ","",offsetof(new_hCardHolder101,sPinAuthVal),sizeof(phCardHolder101->sPinAuthVal),
   "a         ","",offsetof(new_hCardHolder101,sTrk2DateYYMM),sizeof(phCardHolder101->sTrk2DateYYMM),
   "~","",0,sizeof(new_hCardHolder101),
};

#define FIELDS102 10
struct new_hCardHolder102* phCardHolder102 = 0;
Fields hCardHolder102_Fields[FIELDS102 + 1] =
{
   "a         ","",offsetof(new_hCardHolder102,sAcctFIId),sizeof(phCardHolder102->sAcctFIId),
   "a         ","",offsetof(new_hCardHolder102,sAcctType),sizeof(phCardHolder102->sAcctType),
   "a         ","",offsetof(new_hCardHolder102,sAcctNo),sizeof(phCardHolder102->sAcctNo),
   "a         ","",offsetof(new_hCardHolder102,sAcctQual),sizeof(phCardHolder102->sAcctQual),
   "a         ","",offsetof(new_hCardHolder102,sOarSelType),sizeof(phCardHolder102->sOarSelType),
   "a         ","",offsetof(new_hCardHolder102,sAcctDesc),sizeof(phCardHolder102->sAcctDesc),
   "b         "," WD DP IQ PT PF TT TF PR 3P DF",offsetof(new_hCardHolder102,siAcctAccess),sizeof(phCardHolder102->siAcctAccess),
   "a         ","",offsetof(new_hCardHolder102,cPrimaryInd),sizeof(phCardHolder102->cPrimaryInd),
   "a         ","",offsetof(new_hCardHolder102,cFundingInd),sizeof(phCardHolder102->cFundingInd),
   "~","",0,sizeof(new_hCardHolder102),
};

#define FIELDS103 6
struct new_hCardHolder103* phCardHolder103 = 0;
Fields hCardHolder103_Fields[FIELDS103 + 1] =
{
   "a         ","",offsetof(new_hCardHolder103,sLimitId),sizeof(phCardHolder103->sLimitId),
   "i         ","",offsetof(new_hCardHolder103,iLimitAmnt),sizeof(phCardHolder103->iLimitAmnt),
   "s         ","",offsetof(new_hCardHolder103,siLimitUses),sizeof(phCardHolder103->siLimitUses),
   "i         ","",offsetof(new_hCardHolder103,iIncrAmnt),sizeof(phCardHolder103->iIncrAmnt),
   "i         ","",offsetof(new_hCardHolder103,iMinAmnt),sizeof(phCardHolder103->iMinAmnt),
   "s         ","",offsetof(new_hCardHolder103,siPercntDepAval),sizeof(phCardHolder103->siPercntDepAval),
   "~","",0,sizeof(new_hCardHolder103),
};

#define FIELDS104 4
struct new_hCardHolder104* phCardHolder104 = 0;
Fields hCardHolder104_Fields[FIELDS104 + 1] =
{
   "i         ","",offsetof(new_hCardHolder104,iAmnt),sizeof(phCardHolder104->iAmnt),
   "t         ","",offsetof(new_hCardHolder104,sExpTime),sizeof(phCardHolder104->sExpTime),
   "a         ","",offsetof(new_hCardHolder104,sMatchData),sizeof(phCardHolder104->sMatchData),
   "a         ","",offsetof(new_hCardHolder104,sLimitId),sizeof(phCardHolder104->sLimitId),
   "~","",0,sizeof(new_hCardHolder104),
};

#define FIELDS105 4
struct new_hCardHolder105* phCardHolder105 = 0;
Fields hCardHolder105_Fields[FIELDS105 + 1] =
{
   "a         ","",offsetof(new_hCardHolder105,sFIID),sizeof(phCardHolder105->sFIID),
   "a         ","",offsetof(new_hCardHolder105,sAcctType),sizeof(phCardHolder105->sAcctType),
   "a         ","",offsetof(new_hCardHolder105,sAcctNo),sizeof(phCardHolder105->sAcctNo),
   "a         ","",offsetof(new_hCardHolder105,sPaymentAcctID),sizeof(phCardHolder105->sPaymentAcctID),
   "~","",0,sizeof(new_hCardHolder105),
};

#define FIELDS106 1
struct new_hCardHolder106* phCardHolder106 = 0;
Fields hCardHolder106_Fields[FIELDS106 + 1] =
{
   "a         ","",offsetof(new_hCardHolder106,sGreetingName),sizeof(phCardHolder106->sGreetingName),
   "~","",0,sizeof(new_hCardHolder106),
};

#define FIELDS107 4
struct new_hCardHolder107* phCardHolder107 = 0;
Fields hCardHolder107_Fields[FIELDS107 + 1] =
{
   "a         ","",offsetof(new_hCardHolder107,sLimitID),sizeof(phCardHolder107->sLimitID),
   "t         ","",offsetof(new_hCardHolder107,sBeginTstamp),sizeof(phCardHolder107->sBeginTstamp),
   "t         ","",offsetof(new_hCardHolder107,sEndTstamp),sizeof(phCardHolder107->sEndTstamp),
   "o         ","",offsetof(new_hCardHolder107,sOvExpireFiller),sizeof(phCardHolder107->sOvExpireFiller),
   "~","",0,sizeof(new_hCardHolder107),
};

#define FIELDS108 7
struct new_hCardHolder108* phCardHolder108 = 0;
Fields hCardHolder108_Fields[FIELDS108 + 1] =
{
   "a         ","",offsetof(new_hCardHolder108,sCoNameOne),sizeof(phCardHolder108->sCoNameOne),
   "a         ","",offsetof(new_hCardHolder108,sCoNameTwo),sizeof(phCardHolder108->sCoNameTwo),
   "a         ","",offsetof(new_hCardHolder108,sCoNameThree),sizeof(phCardHolder108->sCoNameThree),
   "a         ","",offsetof(new_hCardHolder108,sCoAddressOne),sizeof(phCardHolder108->sCoAddressOne),
   "a         ","",offsetof(new_hCardHolder108,sCoAddressTwo),sizeof(phCardHolder108->sCoAddressTwo),
   "a         ","",offsetof(new_hCardHolder108,sCoZipCode),sizeof(phCardHolder108->sCoZipCode),
   "o         ","",offsetof(new_hCardHolder108,cFiller),sizeof(phCardHolder108->cFiller),
   "~","",0,sizeof(new_hCardHolder108),
};

#define FIELDS109 5
struct new_hCardHolder109* phCardHolder109 = 0;
Fields hCardHolder109_Fields[FIELDS109 + 1] =
{
   "a         ","",offsetof(new_hCardHolder109,sName),sizeof(phCardHolder109->sName),
   "a         ","",offsetof(new_hCardHolder109,sIssueDtMMDDYY),sizeof(phCardHolder109->sIssueDtMMDDYY),
   "a         ","",offsetof(new_hCardHolder109,sReIssueDtMMDDYY),sizeof(phCardHolder109->sReIssueDtMMDDYY),
   "a         ","",offsetof(new_hCardHolder109,sCloseDtMMDDYY),sizeof(phCardHolder109->sCloseDtMMDDYY),
   "a         ","",offsetof(new_hCardHolder109,sComments),sizeof(phCardHolder109->sComments),
   "~","",0,sizeof(new_hCardHolder109),
};

#define FIELDS110 4
struct new_hCardHolder110* phCardHolder110 = 0;
Fields hCardHolder110_Fields[FIELDS110 + 1] =
{
   "s         ","",offsetof(new_hCardHolder110,siConsecutiveRejects),sizeof(phCardHolder110->siConsecutiveRejects),
   "s         ","",offsetof(new_hCardHolder110,siPrevConsecutiveRejects),sizeof(phCardHolder110->siPrevConsecutiveRejects),
   "a         ","",offsetof(new_hCardHolder110,sCardType),sizeof(phCardHolder110->sCardType),
   "o         ","",offsetof(new_hCardHolder110,sAddlCardFiller),sizeof(phCardHolder110->sAddlCardFiller),
   "~","",0,sizeof(new_hCardHolder110),
};

#define FIELDS112 5
struct new_hCardHolder112* phCardHolder112 = 0;
Fields hCardHolder112_Fields[FIELDS112 + 1] =
{
   "a         ","",offsetof(new_hCardHolder112,sAddress1),sizeof(phCardHolder112->sAddress1),
   "a         ","",offsetof(new_hCardHolder112,cCardCondFlag),sizeof(phCardHolder112->cCardCondFlag),
   "a         ","",offsetof(new_hCardHolder112,cAutoIssInd),sizeof(phCardHolder112->cAutoIssInd),
   "a         ","",offsetof(new_hCardHolder112,sLastMaintTstamp),sizeof(phCardHolder112->sLastMaintTstamp),
   "a         ","",offsetof(new_hCardHolder112,sComments),sizeof(phCardHolder112->sComments),
   "~","",0,sizeof(new_hCardHolder112),
};

#define FIELDS113 13
struct new_hCardHolder113* phCardHolder113 = 0;
Fields hCardHolder113_Fields[FIELDS113 + 1] =
{
   "a         ","",offsetof(new_hCardHolder113,sMemberNum),sizeof(phCardHolder113->sMemberNum),
   "a         ","",offsetof(new_hCardHolder113,sCardName1),sizeof(phCardHolder113->sCardName1),
   "a         ","",offsetof(new_hCardHolder113,sCardName2),sizeof(phCardHolder113->sCardName2),
   "a         ","",offsetof(new_hCardHolder113,cCardName3),sizeof(phCardHolder113->cCardName3),
   "a         ","",offsetof(new_hCardHolder113,cCardOrdTypeFlag),sizeof(phCardHolder113->cCardOrdTypeFlag),
   "a         ","",offsetof(new_hCardHolder113,cCardStatFlag),sizeof(phCardHolder113->cCardStatFlag),
   "a         ","",offsetof(new_hCardHolder113,sCardStatTstamp),sizeof(phCardHolder113->sCardStatTstamp),
   "a         ","",offsetof(new_hCardHolder113,cLastIssFlag),sizeof(phCardHolder113->cLastIssFlag),
   "a         ","",offsetof(new_hCardHolder113,cCardReplacement),sizeof(phCardHolder113->cCardReplacement),
   "a         ","",offsetof(new_hCardHolder113,sDateIssTstamp),sizeof(phCardHolder113->sDateIssTstamp),
   "a         ","",offsetof(new_hCardHolder113,sLastIssTstamp),sizeof(phCardHolder113->sLastIssTstamp),
   "a         ","",offsetof(new_hCardHolder113,cPhotoId),sizeof(phCardHolder113->cPhotoId),
   "a         ","",offsetof(new_hCardHolder113,sCardCollectionCode),sizeof(phCardHolder113->sCardCollectionCode),
   "~","",0,sizeof(new_hCardHolder113),
};

#define FIELDS114 9
struct new_hCardHolder114* phCardHolder114 = 0;
Fields hCardHolder114_Fields[FIELDS114 + 1] =
{
   "a         ","",offsetof(new_hCardHolder114,cSex),sizeof(phCardHolder114->cSex),
   "a         ","",offsetof(new_hCardHolder114,sDOB),sizeof(phCardHolder114->sDOB),
   "a         ","",offsetof(new_hCardHolder114,cMaritalStatus),sizeof(phCardHolder114->cMaritalStatus),
   "a         ","",offsetof(new_hCardHolder114,cEducationLevel),sizeof(phCardHolder114->cEducationLevel),
   "a         ","",offsetof(new_hCardHolder114,sIncomeRange),sizeof(phCardHolder114->sIncomeRange),
   "a         ","",offsetof(new_hCardHolder114,sFamilySize),sizeof(phCardHolder114->sFamilySize),
   "a         ","",offsetof(new_hCardHolder114,sDistance),sizeof(phCardHolder114->sDistance),
   "a         ","",offsetof(new_hCardHolder114,cResidenceType),sizeof(phCardHolder114->cResidenceType),
   "a         ","",offsetof(new_hCardHolder114,cEmploymentType),sizeof(phCardHolder114->cEmploymentType),
   "~","",0,sizeof(new_hCardHolder114),
};

#define FIELDS115 11
struct new_hCardHolder115* phCardHolder115 = 0;
Fields hCardHolder115_Fields[FIELDS115 + 1] =
{
   "a         ","",offsetof(new_hCardHolder115,sSocialSecurityNum),sizeof(phCardHolder115->sSocialSecurityNum),
   "a         ","",offsetof(new_hCardHolder115,sMaidenName),sizeof(phCardHolder115->sMaidenName),
   "a         ","",offsetof(new_hCardHolder115,sHomePh),sizeof(phCardHolder115->sHomePh),
   "a         ","",offsetof(new_hCardHolder115,sWorkPh),sizeof(phCardHolder115->sWorkPh),
   "a         ","",offsetof(new_hCardHolder115,sUserValidation),sizeof(phCardHolder115->sUserValidation),
   "a         ","",offsetof(new_hCardHolder115,cVruCounter),sizeof(phCardHolder115->cVruCounter),
   "a         ","",offsetof(new_hCardHolder115,sDOB),sizeof(phCardHolder115->sDOB),
   "t         ","",offsetof(new_hCardHolder115,sActTstamp),sizeof(phCardHolder115->sActTstamp),
   "a         ","",offsetof(new_hCardHolder115,cActMethod),sizeof(phCardHolder115->cActMethod),
   "a         ","",offsetof(new_hCardHolder115,sPrevTrk2DateYYMM),sizeof(phCardHolder115->sPrevTrk2DateYYMM),
   "a         ","",offsetof(new_hCardHolder115,cPrevCardAct),sizeof(phCardHolder115->cPrevCardAct),
   "~","",0,sizeof(new_hCardHolder115),
};

#define FIELDS116 7
struct new_hCardHolder116* phCardHolder116 = 0;
Fields hCardHolder116_Fields[FIELDS116 + 1] =
{
   "t         ","",offsetof(new_hCardHolder116,sInAuthLastChgd),sizeof(phCardHolder116->sInAuthLastChgd),
   "t         ","",offsetof(new_hCardHolder116,sDoNotDisturb),sizeof(phCardHolder116->sDoNotDisturb),
   "t         ","",offsetof(new_hCardHolder116,sCiStatusLastSet),sizeof(phCardHolder116->sCiStatusLastSet),
   "t         ","",offsetof(new_hCardHolder116,sCiStatusLastRemoved),sizeof(phCardHolder116->sCiStatusLastRemoved),
   "a         ","",offsetof(new_hCardHolder116,cCiStatusSetBy),sizeof(phCardHolder116->cCiStatusSetBy),
   "a         ","",offsetof(new_hCardHolder116,cCiStatusRemovedBy),sizeof(phCardHolder116->cCiStatusRemovedBy),
   "o         ","",offsetof(new_hCardHolder116,cObsolete),sizeof(phCardHolder116->cObsolete),
   "~","",0,sizeof(new_hCardHolder116),
};
}
//## end module%5EB1CFA20278.additionalDeclarations


// Class APCardMaintenanceSegment

APCardMaintenanceSegment::APCardMaintenanceSegment()
  //## begin APCardMaintenanceSegment::APCardMaintenanceSegment%5EB1CF5B0370_const.hasinit preserve=no
  //## end APCardMaintenanceSegment::APCardMaintenanceSegment%5EB1CF5B0370_const.hasinit
  //## begin APCardMaintenanceSegment::APCardMaintenanceSegment%5EB1CF5B0370_const.initialization preserve=yes
  //## end APCardMaintenanceSegment::APCardMaintenanceSegment%5EB1CF5B0370_const.initialization
{
  //## begin APCardMaintenanceSegment::APCardMaintenanceSegment%5EB1CF5B0370_const.body preserve=yes
   memcpy(m_sID,"AI46",4);
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("CH01"),&hCardHolder100_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("CH02"),&hCardHolder101_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("CH03"),&hCardHolder102_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("CH04"),&hCardHolder103_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("CH06"),&hCardHolder104_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("CH08"),&hCardHolder106_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("CH09"),&hCardHolder107_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("CH14"),&hCardHolder110_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("CH18"),&hCardHolder112_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("CH19"),&hCardHolder113_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("CH22"),&hCardHolder115_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("CH23"),&hCardHolder116_Fields[0]));
  //## end APCardMaintenanceSegment::APCardMaintenanceSegment%5EB1CF5B0370_const.body
}


APCardMaintenanceSegment::~APCardMaintenanceSegment()
{
  //## begin APCardMaintenanceSegment::~APCardMaintenanceSegment%5EB1CF5B0370_dest.body preserve=yes
  //## end APCardMaintenanceSegment::~APCardMaintenanceSegment%5EB1CF5B0370_dest.body
}


// Additional Declarations
  //## begin APCardMaintenanceSegment%5EB1CF5B0370.declarations preserve=yes
  //## end APCardMaintenanceSegment%5EB1CF5B0370.declarations

//## begin module%5EB1CFA20278.epilog preserve=yes
//## end module%5EB1CFA20278.epilog
