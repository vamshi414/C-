//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C613842001F.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%3C613842001F.cm

//## begin module%3C613842001F.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C613842001F.cp

//## Module: CXOSAI09%3C613842001F; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Ai\CXODAI09.hpp

#ifndef CXOSAI09_h
#define CXOSAI09_h 1

//## begin module%3C613842001F.additionalIncludes preserve=no
//## end module%3C613842001F.additionalIncludes

//## begin module%3C613842001F.includes preserve=yes
// $Date:   Dec 02 2013 10:50:10  $ $Author:   e1024360  $ $Revision:   1.9  $
//## end module%3C613842001F.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
#ifndef CXOSAI51_h
#include "CXODAI51.hpp"
#endif
#ifndef CXOSAI20_h
#include "CXODAI20.hpp"
#endif
#ifndef CXOSAI13_h
#include "CXODAI13.hpp"
#endif
#ifndef CXOSAI12_h
#include "CXODAI12.hpp"
#endif
#ifndef CXOSAI11_h
#include "CXODAI11.hpp"
#endif
#ifndef CXOSAI10_h
#include "CXODAI10.hpp"
#endif

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
} // namespace IF

class AdvantageMessageProcessor;
//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

namespace IF {
class Extract;

} // namespace IF

//## begin module%3C613842001F.declarations preserve=no
//## end module%3C613842001F.declarations

//## begin module%3C613842001F.additionalDeclarations preserve=yes
//## end module%3C613842001F.additionalDeclarations


//## begin AdvantageException%3C6132D702FD.preface preserve=yes
//## end AdvantageException%3C6132D702FD.preface

//## Class: AdvantageException%3C6132D702FD
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3C63DA520261;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C63DA9B0222;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%52867F470080;IF::Message { -> F}
//## Uses: <unnamed>%6222DF2D01EE;IF::Extract { -> F}

class AdvantageException : public AdvantageMessage  //## Inherits: <unnamed>%3C6132E70177
{
  //## begin AdvantageException%3C6132D702FD.initialDeclarations preserve=yes
  //## end AdvantageException%3C6132D702FD.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageException();

    //## Destructor (generated)
      virtual ~AdvantageException();


    //## Other Operations (specified)
      //## Operation: insert%3C61B5BF03D8
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantageException%3C6132D702FD.public preserve=yes
      //## end AdvantageException%3C6132D702FD.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageException%3C6132D702FD.protected preserve=yes
      //## end AdvantageException%3C6132D702FD.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageException%3C6132D702FD.private preserve=yes
      //## end AdvantageException%3C6132D702FD.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C63D97F005D
      //## Role: AdvantageException::<m_hAdvantageCirrusEx92Adjustment>%3C63D97F02EE
      //## begin AdvantageException::<m_hAdvantageCirrusEx92Adjustment>%3C63D97F02EE.role preserve=no  public: AdvantageCirrusEx92Adjustment { -> VHgN}
      AdvantageCirrusEx92Adjustment m_hAdvantageCirrusEx92Adjustment;
      //## end AdvantageException::<m_hAdvantageCirrusEx92Adjustment>%3C63D97F02EE.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C63D982003E
      //## Role: AdvantageException::<m_hAdvantagePlusAdjustment>%3C63D98203A9
      //## begin AdvantageException::<m_hAdvantagePlusAdjustment>%3C63D98203A9.role preserve=no  public: AdvantagePlusAdjustment { -> VHgN}
      AdvantagePlusAdjustment m_hAdvantagePlusAdjustment;
      //## end AdvantageException::<m_hAdvantagePlusAdjustment>%3C63D98203A9.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C63D985001F
      //## Role: AdvantageException::<m_hAdvantageStdAdjustment>%3C63D985034B
      //## begin AdvantageException::<m_hAdvantageStdAdjustment>%3C63D985034B.role preserve=no  public: AdvantageStdAdjustment { -> VHgN}
      AdvantageStdAdjustment m_hAdvantageStdAdjustment;
      //## end AdvantageException::<m_hAdvantageStdAdjustment>%3C63D985034B.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C63D98800CB
      //## Role: AdvantageException::<m_hAdvantageStdFee>%3C63D988034B
      //## begin AdvantageException::<m_hAdvantageStdFee>%3C63D988034B.role preserve=no  public: AdvantageStdFee { -> VHgN}
      AdvantageStdFee m_hAdvantageStdFee;
      //## end AdvantageException::<m_hAdvantageStdFee>%3C63D988034B.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%52867D9E03D4
      //## Role: AdvantageException::<m_hAdvantageAS2805Adjustment>%52867D9F0371
      //## begin AdvantageException::<m_hAdvantageAS2805Adjustment>%52867D9F0371.role preserve=no  public: AdvantageAS2805Adjustment { -> VHgN}
      AdvantageAS2805Adjustment m_hAdvantageAS2805Adjustment;
      //## end AdvantageException::<m_hAdvantageAS2805Adjustment>%52867D9F0371.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%621CC6620157
      //## Role: AdvantageException::<m_hAdvantage0466Exception>%621CC66400C9
      //## begin AdvantageException::<m_hAdvantage0466Exception>%621CC66400C9.role preserve=no  public: Advantage0466Exception { -> VHgN}
      Advantage0466Exception m_hAdvantage0466Exception;
      //## end AdvantageException::<m_hAdvantage0466Exception>%621CC66400C9.role

    // Additional Implementation Declarations
      //## begin AdvantageException%3C6132D702FD.implementation preserve=yes
      //## end AdvantageException%3C6132D702FD.implementation

};

//## begin AdvantageException%3C6132D702FD.postscript preserve=yes
//## end AdvantageException%3C6132D702FD.postscript

//## begin module%3C613842001F.epilog preserve=yes
//## end module%3C613842001F.epilog


#endif
