//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3C6139000177.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C6139000177.cm

//## begin module%3C6139000177.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3C6139000177.cp

//## Module: CXOSAI11%3C6139000177; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Pvcswork\Dn\Server\Application\Ai\CXODAI11.hpp

#ifndef CXOSAI11_h
#define CXOSAI11_h 1

//## begin module%3C6139000177.additionalIncludes preserve=no
//## end module%3C6139000177.additionalIncludes

//## begin module%3C6139000177.includes preserve=yes
// $Date:   Jan 31 2018 14:07:08  $ $Author:   e1009839  $ $Revision:   1.13  $
//## end module%3C6139000177.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialAdjustmentExtensionSegment;
class FinancialSettlementSegment;
class FinancialAdjustmentSegment;
class FinancialBaseSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Foundation::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
class DateTime;
} // namespace IF

class AdvantageMessageProcessor;

//## begin module%3C6139000177.declarations preserve=no
//## end module%3C6139000177.declarations

//## begin module%3C6139000177.additionalDeclarations preserve=yes
//## end module%3C6139000177.additionalDeclarations


//## begin AdvantageStdAdjustment%3C61334400AB.preface preserve=yes
//## end AdvantageStdAdjustment%3C61334400AB.preface

//## Class: AdvantageStdAdjustment%3C61334400AB
//## Category: Platform \: Advantage::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3C63E3F40242;IF::Message { -> F}
//## Uses: <unnamed>%3C63E45402AF;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C63E4850232;repositorysegment::FinancialAdjustmentExtensionSegment { -> F}
//## Uses: <unnamed>%3C63E489007D;repositorysegment::FinancialAdjustmentSegment { -> F}
//## Uses: <unnamed>%3C63E4970138;repositorysegment::FinancialBaseSegment { -> F}
//## Uses: <unnamed>%3C63E49B0213;repositorysegment::FinancialSettlementSegment { -> F}
//## Uses: <unnamed>%3C63E4B000DA;IF::DateTime { -> F}
//## Uses: <unnamed>%3C63E4C0030D;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3C63E51303A9;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%3C63E542034B;IF::CodeTable { -> F}
//## Uses: <unnamed>%3C63E62E0196;process::Application { -> F}

class AdvantageStdAdjustment : public AdvantageMessage  //## Inherits: <unnamed>%3C63D8110271
{
  //## begin AdvantageStdAdjustment%3C61334400AB.initialDeclarations preserve=yes
  //## end AdvantageStdAdjustment%3C61334400AB.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageStdAdjustment();

    //## Destructor (generated)
      virtual ~AdvantageStdAdjustment();


    //## Other Operations (specified)
      //## Operation: insert%3C63D8150186
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantageStdAdjustment%3C61334400AB.public preserve=yes
      //## end AdvantageStdAdjustment%3C61334400AB.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageStdAdjustment%3C61334400AB.protected preserve=yes
      //## end AdvantageStdAdjustment%3C61334400AB.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageStdAdjustment%3C61334400AB.private preserve=yes
      //## end AdvantageStdAdjustment%3C61334400AB.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin AdvantageStdAdjustment%3C61334400AB.implementation preserve=yes
      //## end AdvantageStdAdjustment%3C61334400AB.implementation

};

//## begin AdvantageStdAdjustment%3C61334400AB.postscript preserve=yes
//## end AdvantageStdAdjustment%3C61334400AB.postscript

//## begin module%3C6139000177.epilog preserve=yes
//## end module%3C6139000177.epilog


#endif
