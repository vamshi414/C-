//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A5253B40175.cm preserve=no
//	$Date:   May 01 2020 08:38:38  $ $Author:   e1009839  $
//	$Revision:   1.3  $
//## end module%5A5253B40175.cm

//## begin module%5A5253B40175.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A5253B40175.cp

//## Module: CXOSAI27%5A5253B40175; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI27.cpp

//## begin module%5A5253B40175.additionalIncludes preserve=no
//## end module%5A5253B40175.additionalIncludes

//## begin module%5A5253B40175.includes preserve=yes
#include <sstream>
//## end module%5A5253B40175.includes

#ifndef CXOSAI27_h
#include "CXODAI27.hpp"
#endif
//## begin module%5A5253B40175.declarations preserve=no
//## end module%5A5253B40175.declarations

//## begin module%5A5253B40175.additionalDeclarations preserve=yes
//## end module%5A5253B40175.additionalDeclarations


// Class NetstatStatus

NetstatStatus::NetstatStatus()
  //## begin NetstatStatus::NetstatStatus%5A52528B02FB_const.hasinit preserve=no
  //## end NetstatStatus::NetstatStatus%5A52528B02FB_const.hasinit
  //## begin NetstatStatus::NetstatStatus%5A52528B02FB_const.initialization preserve=yes
   : AdvantageMessage("1521","S907")
  //## end NetstatStatus::NetstatStatus%5A52528B02FB_const.initialization
{
  //## begin NetstatStatus::NetstatStatus%5A52528B02FB_const.body preserve=yes
   memcpy(m_sID,"AI27",4);
  //## end NetstatStatus::NetstatStatus%5A52528B02FB_const.body
}


NetstatStatus::~NetstatStatus()
{
  //## begin NetstatStatus::~NetstatStatus%5A52528B02FB_dest.body preserve=yes
  //## end NetstatStatus::~NetstatStatus%5A52528B02FB_dest.body
}



//## Other Operations (implementation)
bool NetstatStatus::insert (Message& hMessage)
{
  //## begin NetstatStatus::insert%5A52535901AE.body preserve=yes
   UseCase hUseCase("TANDEM","## AI27 READ 1521 NETSTAT",false);
   hNetstatStatus* p = (hNetstatStatus*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   if (ntohs(p->siNumberMsgs) < 1)
      return false;
#ifdef MVS
   if (getAsciiInput())
   {
      CodeTable::translate(p->sMsgPrefix,sizeof(p->sMsgPrefix),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(p->sMsgPrefix2nd,sizeof(p->sMsgPrefix2nd),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(p->sSubject,sizeof(p->sSubject),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(p->sOperatorID,sizeof(p->sOperatorID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(p->sOriginProcess,((char*)(&p->siParmCount) - p->sOriginProcess),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(p->sParms,sizeof(p->sParms),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(p->sStatusInfo,sizeof(p->sStatusInfo),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(p->sIncidentDesc,sizeof(p->sIncidentDesc),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(p->sContactType,sizeof(p->sContactType),CodeTable::CX_ASCII_TO_EBCDIC);
      for (int m = 0;m < (ntohs(p->siNumberMsgs));m++)
         CodeTable::translate(p->MsgData[m].sText,sizeof(p->MsgData[m].sText),CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!getAsciiInput())
   {
      CodeTable::translate(p->sMsgPrefix,sizeof(p->sMsgPrefix),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(p->sMsgPrefix2nd,sizeof(p->sMsgPrefix2nd),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(p->sSubject,sizeof(p->sSubject),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(p->sOperatorID,sizeof(p->sOperatorID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(p->sOriginProcess,((char*)(&p->siParmCount) - p->sOriginProcess),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(p->sParms,sizeof(p->sParms),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(p->sStatusInfo,sizeof(p->sStatusInfo),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(p->sIncidentDesc,sizeof(p->sIncidentDesc),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(p->sContactType,sizeof(p->sContactType),CodeTable::CX_EBCDIC_TO_ASCII);
      for (int m = 0;m < (ntohs(p->siNumberMsgs));m++)
         CodeTable::translate(p->MsgData[m].sText,sizeof(p->MsgData[m].sText),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   setTSTAMP_TRANS(p->sMsgTstamp);
   database::UniquenessKey::hash(p->sSubject,8);
   database::UniquenessKey::hash((const char*)&p->siAlertNumber,2);
   m_pTransaction->setUNIQUENESS_KEY(database::UniquenessKey::getHash());
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   short siFoo = ntohs(p->siSubjectType);
   if (ntohs(p->siSubjectType) < 0
      || ntohs(p->siSubjectType) > 9999)
      p->siSubjectType = 0;
   memset((void*)&p->lCED_BUILD_NO,' ',1024);
   p->lCED_BUILD_NO = pV13AdvantageHeader->lCED_BUILD_NO;
   p->siSUBJECT_TYPE = 0;
   p->siLAST_UNIQUENES_KEY = 0;
   string strSecond;
   if (ntohs(p->siSubjectType) == 60)
   {
      std::ostringstream oss;
      oss << setfill('0') << setw(5) << right << ntohs(p->siAlertNumber);
      if (ConfigurationRepository::instance()->translate("X_DEV_LOW_CASH_FLG",string(oss.str().data(),oss.str().length()),strSecond,"","",0,false))
         p->cLOW_CASH_FLG1 = strSecond[0];
   }
   std::ostringstream oss;
   oss << setfill('0') << setw(4) << right << ntohs(p->siAlertNumber) << " ";
   string strAlertNo(oss.str().data(),oss.str().length());
   memcpy(p->sALERT_NO,strAlertNo.data(),(min(size_t(5),strAlertNo.length())));
   for (short m = 0;m < ntohs(p->siNumberMsgs);m++)
   {
      short siMsgLevel = ntohs(p->MsgData[m].siMsgLevel) >= 0
         && ntohs(p->MsgData[m].siMsgLevel) < 10000 ? ntohs(p->MsgData[m].siMsgLevel) : 0;
      p->MsgData[m].siMsgLevel = htons(siMsgLevel);
      if (strAlertNo == "0000 ")
      {
         string strDEVICE_STATUS(p->MsgData[m].sText,6);
         rtrim(strDEVICE_STATUS);
         strDEVICE_STATUS.erase(std::remove(strDEVICE_STATUS.begin(),strDEVICE_STATUS.end(),'-'),strDEVICE_STATUS.end());
         strDEVICE_STATUS.resize(5,' ');
         memcpy(p->sDEVICE_STATUS,strDEVICE_STATUS.data(),5);
      }
      else
         memcpy(p->sDEVICE_STATUS,strAlertNo.data(),(min(size_t(5),strAlertNo.length())));
      if (ConfigurationRepository::instance()->translate("X_GASPER_STATUS_CODE",string(p->sDEVICE_STATUS,5),strSecond,string(""),string(""),-1,false))
      {
         p->cSUBJECT_STATE1 = strSecond[0];
         memcpy(p->sSUBJECT,p->sSubject,8);
         p->siSUBJECT_TYPE = p->siSubjectType;
         memcpy(p->sLAST_TSTAMP_TRANS,m_pTransaction->getTSTAMP_TRANS().data(),16);
         p->siLAST_UNIQUENES_KEY = htons((short)atoi(m_pTransaction->getUNIQUENESS_KEY().c_str()));
         p->cSUBJECT_STATE2 = strSecond[0];
         std::ostringstream oss;
         if (ntohs(p->siAlertNumber) > 0)
            oss << setfill('0') << setw(4) << right << ntohs(p->siAlertNumber) << " ";
         else
            oss << ntohs(p->siMsgNumber);
         memcpy(p->sSTATE_REASON,oss.str().data(),min(size_t(5),oss.str().length()));
         p->cLOW_CASH_FLG2 = p->cLOW_CASH_FLG1;
         ::Template::instance()->map("NETSTATSTATUSSTATE",(const char*)p,-1,m);
      }
      else
         p->cSUBJECT_STATE1 = ' ';
      ::Template::instance()->map("NETSTATSTATUS",(const char*)p,-1,m);
      ::Template::instance()->map("NETSTATSTATUSDATA",(const char*)&p->MsgData[m],-1,m);
      UseCase::addItem();
   }
   return deport(hMessage);
  //## end NetstatStatus::insert%5A52535901AE.body
}

// Additional Declarations
  //## begin NetstatStatus%5A52528B02FB.declarations preserve=yes
  //## end NetstatStatus%5A52528B02FB.declarations

//## begin module%5A5253B40175.epilog preserve=yes
//## end module%5A5253B40175.epilog
