//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3C6139C602CE.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C6139C602CE.cm

//## begin module%3C6139C602CE.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3C6139C602CE.cp

//## Module: CXOSAI14%3C6139C602CE; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Pvcswork\Dn\Server\Application\Ai\CXODAI14.hpp

#ifndef CXOSAI14_h
#define CXOSAI14_h 1

//## begin module%3C6139C602CE.additionalIncludes preserve=no
//## end module%3C6139C602CE.additionalIncludes

//## begin module%3C6139C602CE.includes preserve=yes
// $Date:   Jan 31 2018 14:07:12  $ $Author:   e1009839  $ $Revision:   1.9  $
//## end module%3C6139C602CE.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
#ifndef CXOSRS09_h
#include "CXODRS09.hpp"
#endif

//## Modelname: Connex Foundation::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
class DateTime;
} // namespace IF

class AdvantageMessageProcessor;

//## begin module%3C6139C602CE.declarations preserve=no
//## end module%3C6139C602CE.declarations

//## begin module%3C6139C602CE.additionalDeclarations preserve=yes
//## end module%3C6139C602CE.additionalDeclarations


//## begin AdvantageProcessorAdvice%3C6133E800AB.preface preserve=yes
//## end AdvantageProcessorAdvice%3C6133E800AB.preface

//## Class: AdvantageProcessorAdvice%3C6133E800AB
//## Category: Platform \: Advantage::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3C63026D00EA;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C63027A002E;IF::Message { -> F}
//## Uses: <unnamed>%3C6302A3004E;IF::DateTime { -> F}
//## Uses: <unnamed>%3C6303CE0213;process::Application { -> F}
//## Uses: <unnamed>%3C63C379005D;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%3C63C412036B;IF::CodeTable { -> F}

class AdvantageProcessorAdvice : public AdvantageMessage  //## Inherits: <unnamed>%3C6133F900EA
{
  //## begin AdvantageProcessorAdvice%3C6133E800AB.initialDeclarations preserve=yes
  //## end AdvantageProcessorAdvice%3C6133E800AB.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageProcessorAdvice();

    //## Destructor (generated)
      virtual ~AdvantageProcessorAdvice();


    //## Other Operations (specified)
      //## Operation: insert%3C6188390251
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantageProcessorAdvice%3C6133E800AB.public preserve=yes
      //## end AdvantageProcessorAdvice%3C6133E800AB.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageProcessorAdvice%3C6133E800AB.protected preserve=yes
      //## end AdvantageProcessorAdvice%3C6133E800AB.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageProcessorAdvice%3C6133E800AB.private preserve=yes
      //## end AdvantageProcessorAdvice%3C6133E800AB.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: Advantage::AcquirerInterface_CAT::<unnamed>%3C61881C0203
      //## Role: AdvantageProcessorAdvice::<m_hCutoffSegment>%3C61881D0222
      //## begin AdvantageProcessorAdvice::<m_hCutoffSegment>%3C61881D0222.role preserve=no  public: repositorysegment::CutoffSegment { -> VHgN}
      repositorysegment::CutoffSegment m_hCutoffSegment;
      //## end AdvantageProcessorAdvice::<m_hCutoffSegment>%3C61881D0222.role

    // Additional Implementation Declarations
      //## begin AdvantageProcessorAdvice%3C6133E800AB.implementation preserve=yes
      //## end AdvantageProcessorAdvice%3C6133E800AB.implementation

};

//## begin AdvantageProcessorAdvice%3C6133E800AB.postscript preserve=yes
//## end AdvantageProcessorAdvice%3C6133E800AB.postscript

//## begin module%3C6139C602CE.epilog preserve=yes
//## end module%3C6139C602CE.epilog


#endif
