//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%52810B2E01AE.cm preserve=no
//	$Date:   Jan 31 2018 14:07:14  $ $Author:   e1009839  $
//	$Revision:   1.2  $
//## end module%52810B2E01AE.cm

//## begin module%52810B2E01AE.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%52810B2E01AE.cp

//## Module: CXOSAI20%52810B2E01AE; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXODAI20.hpp

#ifndef CXOSAI20_h
#define CXOSAI20_h 1

//## begin module%52810B2E01AE.additionalIncludes preserve=no
//## end module%52810B2E01AE.additionalIncludes

//## begin module%52810B2E01AE.includes preserve=yes
//## end module%52810B2E01AE.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialExceptionSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class AdvantageMessageProcessor;
//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%52810B2E01AE.declarations preserve=no
//## end module%52810B2E01AE.declarations

//## begin module%52810B2E01AE.additionalDeclarations preserve=yes
//## end module%52810B2E01AE.additionalDeclarations


//## begin AdvantageAS2805Adjustment%5281097400C2.preface preserve=yes
//## end AdvantageAS2805Adjustment%5281097400C2.preface

//## Class: AdvantageAS2805Adjustment%5281097400C2
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%528120580125;IF::Message { -> F}
//## Uses: <unnamed>%5286876601C9;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%5286879E0194;IF::CodeTable { -> F}
//## Uses: <unnamed>%528687BE0225;process::Application { -> F}
//## Uses: <unnamed>%528687EE00EF;monitor::UseCase { -> F}
//## Uses: <unnamed>%5286881F0009;repositorysegment::FinancialExceptionSegment { -> F}
//## Uses: <unnamed>%54BE2CA401E2;configuration::ConfigurationRepository { -> F}

class DllExport AdvantageAS2805Adjustment : public AdvantageMessage  //## Inherits: <unnamed>%5281113C0373
{
  //## begin AdvantageAS2805Adjustment%5281097400C2.initialDeclarations preserve=yes
  //## end AdvantageAS2805Adjustment%5281097400C2.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageAS2805Adjustment();

    //## Destructor (generated)
      virtual ~AdvantageAS2805Adjustment();


    //## Other Operations (specified)
      //## Operation: insert%528111DA0345
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The eFunds Advantage Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantageAS2805Adjustment%5281097400C2.public preserve=yes
      //## end AdvantageAS2805Adjustment%5281097400C2.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageAS2805Adjustment%5281097400C2.protected preserve=yes
      //## end AdvantageAS2805Adjustment%5281097400C2.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageAS2805Adjustment%5281097400C2.private preserve=yes
      //## end AdvantageAS2805Adjustment%5281097400C2.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin AdvantageAS2805Adjustment%5281097400C2.implementation preserve=yes
      //## end AdvantageAS2805Adjustment%5281097400C2.implementation

};

//## begin AdvantageAS2805Adjustment%5281097400C2.postscript preserve=yes
//## end AdvantageAS2805Adjustment%5281097400C2.postscript

//## begin module%52810B2E01AE.epilog preserve=yes
//## end module%52810B2E01AE.epilog


#endif
