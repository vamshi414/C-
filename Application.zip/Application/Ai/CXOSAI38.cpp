//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A54326B0164.cm preserve=no
//	$Date:   May 20 2021 09:53:50  $ $Author:   E5350313  $
//	$Revision:   1.6  $
//## end module%5A54326B0164.cm

//## begin module%5A54326B0164.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A54326B0164.cp

//## Module: CXOSAI38%5A54326B0164; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI38.cpp

//## begin module%5A54326B0164.additionalIncludes preserve=no
//## end module%5A54326B0164.additionalIncludes

//## begin module%5A54326B0164.includes preserve=yes
#include "CXODIF16.hpp"
//## end module%5A54326B0164.includes

#ifndef CXOSAI38_h
#include "CXODAI38.hpp"
#endif
//## begin module%5A54326B0164.declarations preserve=no
//## end module%5A54326B0164.declarations

//## begin module%5A54326B0164.additionalDeclarations preserve=yes
//## end module%5A54326B0164.additionalDeclarations


// Class TerminalAdvice

TerminalAdvice::TerminalAdvice()
  //## begin TerminalAdvice::TerminalAdvice%5A542C4F004D_const.hasinit preserve=no
  //## end TerminalAdvice::TerminalAdvice%5A542C4F004D_const.hasinit
  //## begin TerminalAdvice::TerminalAdvice%5A542C4F004D_const.initialization preserve=yes
   : AdvantageMessage("0461","A001")
  //## end TerminalAdvice::TerminalAdvice%5A542C4F004D_const.initialization
{
  //## begin TerminalAdvice::TerminalAdvice%5A542C4F004D_const.body preserve=yes
   memcpy(m_sID,"AI38",4);
  //## end TerminalAdvice::TerminalAdvice%5A542C4F004D_const.body
}


TerminalAdvice::~TerminalAdvice()
{
  //## begin TerminalAdvice::~TerminalAdvice%5A542C4F004D_dest.body preserve=yes
  //## end TerminalAdvice::~TerminalAdvice%5A542C4F004D_dest.body
}



//## Other Operations (implementation)
bool TerminalAdvice::insert (Message& hMessage)
{
  //## begin TerminalAdvice::insert%5A542C640395.body preserve=yes
   UseCase hUseCase("TANDEM","## AI38 READ 0461 TERM ADVICE",false);
   hTerminalAdvice* p = (hTerminalAdvice*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   memset(&p->cACQ_PLAT_PROD_ID,' ',&p->cEnd - &p->cACQ_PLAT_PROD_ID);
   memset(&p->iDEVICE_AMT[0],'\0',36);
   setTSTAMP_TRANS(p->TotalsTypes[0].sReqTimestamp);
   database::UniquenessKey::hash(p->sCardholder,16);
   database::UniquenessKey::hash(p->sDevice,8);
   m_pTransaction->setUNIQUENESS_KEY(database::UniquenessKey::getHash());
   p->cACQ_PLAT_PROD_ID = 'A';
   memcpy(p->sACT_CODE,"000",3);
   memcpy(p->sTSTAMP_LOCAL,m_pTransaction->getTSTAMP_TRANS().data(),14);
   bool bBusinessDateChange = false;
   bool b572 = false;
   for (int i = 0;i < ntohs(p->siTypesInUse);i++)
   {
      if (memcmp(p->TotalsTypes[i].sFunction,"589",3) == 0)
         bBusinessDateChange = true;
      else
      if (memcmp(p->TotalsTypes[i].sFunction,"572",3) == 0)
         b572 = true;
   }
   int iCOH = 320;
   int iWD = 101;
   Extract::instance()->getLong("DUSER   ","SC=",&iCOH);
   Extract::instance()->getLong("DUSER   ","WD=",&iWD);
   for (int x = 0;x < ntohs(p->siTypesInUse);x++)
   {
      short iStart = ntohs(p->TotalsTypes[x].siStartBucket);
      short iEnd = iStart + ntohs(p->TotalsTypes[x].siBucketCnt);
      for (iStart;iStart < iEnd;iStart++)
      {
#ifdef MVS
         if (getAsciiInput())
            CodeTable::translate(p->Buckets[iStart].sDescription,20,CodeTable::CX_ASCII_TO_EBCDIC);
#else
         if (!getAsciiInput())
            CodeTable::translate(p->Buckets[iStart].sDescription,20,CodeTable::CX_EBCDIC_TO_ASCII);
#endif
         int iDescCode(ntohs(p->Buckets[iStart].siDescCode));
         if (iDescCode >= iCOH
            && iDescCode <= iCOH + 8)
         {
            short m = iDescCode - iCOH;
            if (m == 0)
            {
               p->iDEVICE_AMT[0] = p->Buckets[iStart].lAmt1;
               p->iDEVICE_AMT[1] = p->Buckets[iStart].lAmt2;
               p->siDEVICE_CUR_TYPE = htons(1);
               memcpy(p->sDEVICE_CUR_TRAN,Customer::instance()->getCUST_CURRENCY_CODE().data(),Customer::instance()->getCUST_CURRENCY_CODE().length());
            }
            else
            {
               p->iCAN_ITEM_AMT0[0] = p->Buckets[iStart].lAmt1;
               p->iCAN_ITEM_AMT0[1] = p->Buckets[iStart].lAmt2;
               p->iCAN_ITEM_COUNT0 = p->Buckets[iStart].lCount;
               if (p->iCAN_ITEM_COUNT0 != 0)
                  p->iCAN_ITEM_VALUE0 = p->iCAN_ITEM_AMT0[1] / p->iCAN_ITEM_COUNT0;
               memcpy(p->sCAN_CUR_CODE0,Customer::instance()->getCUST_CURRENCY_CODE().data(),Customer::instance()->getCUST_CURRENCY_CODE().length());
               p->siCAN_CUR_TYPE0 = htons(1);
            }
         }
         else
         if (iDescCode >= iWD
            && iDescCode <= iWD + 2)
         {
            short m = iDescCode - iWD;
            p->iDEVICE_WD_AMT[0] = p->Buckets[iStart].lAmt1;
            p->iDEVICE_WD_AMT[1] = p->Buckets[iStart].lAmt2;
            p->siDEVICE_CUR_TYPE = htons(1);
            memcpy(p->sDEVICE_CUR_TRAN,Customer::instance()->getCUST_CURRENCY_CODE().data(),Customer::instance()->getCUST_CURRENCY_CODE().length());
         }
      }
   }
   memcpy(p->sFUNCTION_CODE,p->TotalsTypes[0].sFunction,3);
   string strFirst(p->sDevice,8);
   string strSecond;
   if (ConfigurationRepository::instance()->translate("DEVICE",strFirst,strSecond,"DEV_ADMIN_LOCATOR","INST_ID_RECN_ACQ_B",0))
   {
      strFirst.assign(strSecond.data(),11);
      memcpy(p->sINST_ID_RECN_ACQ_B,strSecond.data(),11);
      if (ConfigurationRepository::instance()->translate("INSTITUTION",strFirst,strSecond,"DEV_ADMIN_LOCATOR","PROC_ID_ACQ_B",0))
      {
         memcpy(p->sPROC_ID_ACQ_B,strSecond.data(),strSecond.length());
         if (ConfigurationRepository::instance()->translate("PROCESSOR",strSecond,strFirst,"DEV_ADMIN_LOCATOR","PROC_GRP_ID_ACQ_B",0))
            memcpy(p->sPROC_GRP_ID_ACQ_B,strFirst.data(),strFirst.length());
      }
      else
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   }
   else
      ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   ::Template::instance()->map("TERMINALADVICE",(const char*)p);
   if (!memcmp(p->sFUNCTION_CODE,"572",3))
   {
      memcpy(p->sENTITY_ID,p->sDevice,8);
      memcpy(p->sENTITY_TYPE,"AT",2);
      memcpy(p->sTSTAMP_END,m_pTransaction->getTSTAMP_TRANS().data(),16);
      memcpy(p->sCUTOFF_TYPE,"99",2);
      memcpy(p->sDATE_RECON,m_pTransaction->getTSTAMP_TRANS().data(),8);
      ::Template::instance()->map("ENTITYCUTOFF",(const char*)p);
   }
   short j = 0;
   for (int i = 0;i < ntohs(p->siTypesInUse);i++)
   {
      ::Template::instance()->map("ATMRECEIPT",(const char*)p,-1,i);
      short iStart = ntohs(p->TotalsTypes[i].siStartBucket);
      short iEnd = iStart + ntohs(p->TotalsTypes[i].siBucketCnt);
      short iSEQ_NO = 0;
      for (;iStart < iEnd;iStart++)
      {
         p->siSEQ_NO = ntohs(++iSEQ_NO);
         ::Template::instance()->map("ATMFUNCTION",(const char*)&p->TotalsTypes[i],-1,i);
         ::Template::instance()->map("ATMENTRYKEY1",(const char*)p,-1,j);
         ::Template::instance()->map("ATMENTRYKEY2",(const char*)&p->TotalsTypes[i],-1,j);
         ::Template::instance()->map("ATMENTRY",(const char*)&p->Buckets[iStart],-1,j);
         ++j;
      }
   }
   return deport(hMessage);
  //## end TerminalAdvice::insert%5A542C640395.body
}

// Additional Declarations
  //## begin TerminalAdvice%5A542C4F004D.declarations preserve=yes
  //## end TerminalAdvice%5A542C4F004D.declarations

//## begin module%5A54326B0164.epilog preserve=yes
//## end module%5A54326B0164.epilog
