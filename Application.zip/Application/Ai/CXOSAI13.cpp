//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3C61397F0213.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C61397F0213.cm

//## begin module%3C61397F0213.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3C61397F0213.cp

//## Module: CXOSAI13%3C61397F0213; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Pvcswork\Dn\Server\Application\Ai\CXOSAI13.cpp

//## begin module%3C61397F0213.additionalIncludes preserve=no
//## end module%3C61397F0213.additionalIncludes

//## begin module%3C61397F0213.includes preserve=yes
// $Date:   Jun 21 2017 08:45:16  $ $Author:   e1009839  $ $Revision:   1.37  $
#include "CXODIF03.hpp"
#include "CXODIF11.hpp"
#include "CXODNS29.hpp"
//## end module%3C61397F0213.includes

#ifndef CXOSAI13_h
#include "CXODAI13.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSRS38_h
#include "CXODRS38.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif


//## begin module%3C61397F0213.declarations preserve=no
//## end module%3C61397F0213.declarations

//## begin module%3C61397F0213.additionalDeclarations preserve=yes
//## end module%3C61397F0213.additionalDeclarations


// Class AdvantageStdFee 


AdvantageStdFee::AdvantageStdFee()
  //## begin AdvantageStdFee::AdvantageStdFee%3C6133C800BB_const.hasinit preserve=no
  //## end AdvantageStdFee::AdvantageStdFee%3C6133C800BB_const.hasinit
  //## begin AdvantageStdFee::AdvantageStdFee%3C6133C800BB_const.initialization preserve=yes
   : AdvantageMessage("0466","S200")
  //## end AdvantageStdFee::AdvantageStdFee%3C6133C800BB_const.initialization
{
  //## begin AdvantageStdFee::AdvantageStdFee%3C6133C800BB_const.body preserve=yes
   memcpy(m_sID,"AI13",4);
  //## end AdvantageStdFee::AdvantageStdFee%3C6133C800BB_const.body
}


AdvantageStdFee::~AdvantageStdFee()
{
  //## begin AdvantageStdFee::~AdvantageStdFee%3C6133C800BB_dest.body preserve=yes
  //## end AdvantageStdFee::~AdvantageStdFee%3C6133C800BB_dest.body
}



//## Other Operations (implementation)
bool AdvantageStdFee::insert (Message& hMessage)
{
  //## begin AdvantageStdFee::insert%3C63D85D0109.body preserve=yes
   hFee* pFee = (hFee*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   char sUsageCode[2];
   memcpy(sUsageCode,pFee->sUsageCode,2);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
     CodeTable::translate(sUsageCode,2,CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
     CodeTable::translate(sUsageCode,2,CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   if (memcmp(sUsageCode,"09",2))
      return false;
   UseCase hUseCase("TANDEM","## AD23 READ 0466 EXCEPTION",false);
   FinancialBaseSegment* m_pFinancialBaseSegment = FinancialBaseSegment::instance();
   FinancialFeeSegment* m_pFinancialFeeSegment = FinancialFeeSegment::instance();
   char sBlankExtdPan[28];
   m_hAuditSegment.reset();
   m_pFinancialBaseSegment->reset();
   m_pFinancialFeeSegment->reset();
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pFee->sPan,
         (pFee->sFiller1 - pFee->sPan), CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pFee->sTransmitDate,
         (pFee->sNetwIdCode - pFee->sTransmitDate +
         sizeof(pFee->sNetwIdCode)), CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pFee->sPan,
         (pFee->sFiller1 - pFee->sPan), CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pFee->sTransmitDate,
         (pFee->sNetwIdCode - pFee->sTransmitDate +
         sizeof(pFee->sNetwIdCode)), CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   m_pFinancialBaseSegment->setCED_BUILD_NO(ntohl(pV13AdvantageHeader->lCED_BUILD_NO));
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   m_pFinancialBaseSegment->setAMT_TRAN(ntohl(pFee->lAmtTran[0]),ntohl(pFee->lAmtTran[1]));
   m_pFinancialBaseSegment->setCARD_SEQ_NO(pFee->sCardSeqNo,3);
   m_pFinancialBaseSegment->setCOUNTRY_ISS_INST(pFee->sCntyCodePanExtd,3);
   m_pFinancialBaseSegment->setCUR_TRAN(pFee->sCurrCodeTran,3);
   m_pFinancialBaseSegment->setINST_ID_ACQ(pFee->sInstIdAcq,11);
   m_pFinancialBaseSegment->setINST_ID_RECON_ACQ(pFee->sInstIdFwd,11);

   //* The institution id fields in the exception messages contain Visa BIN values,
   //* not the institution values we woudl find in our CR tables.  The isSubscriber
   //* call is only going to look up at the customer level.
   if ((ConfigurationRepository::instance()->isSubscriber("",""))== "X")
   {
/*      Trace::put(__FILE__,__LINE__,"not keeping",-1);	*/
      return false;
   }
   else
   {
/*      Trace::put(__FILE__,__LINE__,"keeping",-1);	*/
/*      Trace::put(ConfigurationRepository::instance()->getSUBSCRIBER_IND().data(),ConfigurationRepository::instance()->getSUBSCRIBER_IND().length());	*/
      m_pFinancialBaseSegment->setSUBSCRIBER_IND(ConfigurationRepository::instance()->getSUBSCRIBER_IND().data(), 1);
   }

   m_pFinancialBaseSegment->setRETRIEVAL_REF_NO(pFee->sRetrievalRefNo,12);
   m_pFinancialBaseSegment->setSYS_TRACE_AUDIT_NO(pFee->sTraceNo,6);
   string strTSTAMP_TRANS(NonStopClock::getYYYYMMDDHHMMSShh(pV13AdvantageHeader->sFiller));
   m_pFinancialBaseSegment->setTSTAMP_TRANS(strTSTAMP_TRANS.data(),16);
   memset(sBlankExtdPan,' ',sizeof(sBlankExtdPan));
   if (!memcmp(sBlankExtdPan,pFee->sPanExtd,28))
   {
      if (Customer::instance()->getTest())
         memcpy(pFee->sPan + 6,"999999",6);
      m_pFinancialBaseSegment->setPAN(pFee->sPan,19);
   }
   else
   {
      if (Customer::instance()->getTest())
         memcpy(pFee->sPanExtd + 6,"999999",6);
      m_pFinancialBaseSegment->setPAN(pFee->sPanExtd,28);
   }
   m_pFinancialBaseSegment->setUNIQUENESS_KEY(m_siUniquenessKey);
   m_pFinancialBaseSegment->setACQ_PLAT_PROD_ID("A",1);
   m_pFinancialBaseSegment->setFIN_TYPE("090",3);
   m_pFinancialBaseSegment->setTRAN_DISPOSITION("1",1);
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      m_pFinancialBaseSegment->setTSTAMP_TRANS(strTemp.data(),16);
   }
   m_pFinancialFeeSegment->setADTL_DATA_FEE(pFee->sAdditionalData,254);
   m_pFinancialFeeSegment->setISS_ACQ_TYPE_FEE(&pFee->cIssAcqType,1);
   m_pFinancialFeeSegment->setNET_UNIQUE_DAT_FEE(pFee->sNetwUniqueData,80);
//      m_hFeeSegment.setTRAN_ID(pFee->sTranId,4);
//      m_hFeeSegment.setMSG_TYPE(pFee->sMsgCode,4);
//      m_hFeeSegment.setREASON_CODE(pFee->sReasonCodeSwitch,4);
//      m_hFeeSegment.setRESP_CODE(pFee->x,sRespCode);
//      m_hFeeSegment.setPROCESS_CODE(pFee->sProcessCode,6);

   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   m_pFinancialBaseSegment->write(&psBuffer);
   m_pFinancialFeeSegment->write(&psBuffer);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageStdFee::insert%3C63D85D0109.body
}

// Additional Declarations
  //## begin AdvantageStdFee%3C6133C800BB.declarations preserve=yes
  //## end AdvantageStdFee%3C6133C800BB.declarations

//## begin module%3C61397F0213.epilog preserve=yes
//## end module%3C61397F0213.epilog
