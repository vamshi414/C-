//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3C6137F30138.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C6137F30138.cm

//## begin module%3C6137F30138.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3C6137F30138.cp

//## Module: CXOSAI08%3C6137F30138; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXODAI08.hpp

#ifndef CXOSAI08_h
#define CXOSAI08_h 1

//## begin module%3C6137F30138.additionalIncludes preserve=no
//## end module%3C6137F30138.additionalIncludes

//## begin module%3C6137F30138.includes preserve=yes
// $Date:   Jan 31 2018 14:07:06  $ $Author:   e1009839  $ $Revision:   1.13  $
//## end module%3C6137F30138.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialAdjustmentExtensionSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Foundation::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
class DateTime;
} // namespace IF

class AdvantageMessageProcessor;
namespace repositorysegment {
class FinancialSettlementSegment;
class FinancialReversalSegment;
class FinancialFeeSegment;
class FinancialAdjustmentSegment;
class FinancialBaseSegment;
class FinancialUserSegment;

} // namespace repositorysegment

//## begin module%3C6137F30138.declarations preserve=no
//## end module%3C6137F30138.declarations

//## begin module%3C6137F30138.additionalDeclarations preserve=yes
//## end module%3C6137F30138.additionalDeclarations


//## begin AdvantageSettledAdjustment%3C6132A2005D.preface preserve=yes
//## end AdvantageSettledAdjustment%3C6132A2005D.preface

//## Class: AdvantageSettledAdjustment%3C6132A2005D
//## Category: Platform \: Advantage::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3C62FC82001F;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C62FC8F0399;IF::Message { -> F}
//## Uses: <unnamed>%3C62FE84006D;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%3C62FE970232;IF::DateTime { -> F}
//## Uses: <unnamed>%3C62FE9D02CE;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3C62FEAE02DE;process::Application { -> F}
//## Uses: <unnamed>%3C62FEF1038A;IF::CodeTable { -> F}

class AdvantageSettledAdjustment : public AdvantageMessage  //## Inherits: <unnamed>%3C6132BD03D8
{
  //## begin AdvantageSettledAdjustment%3C6132A2005D.initialDeclarations preserve=yes
  //## end AdvantageSettledAdjustment%3C6132A2005D.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageSettledAdjustment();

    //## Destructor (generated)
      virtual ~AdvantageSettledAdjustment();


    //## Other Operations (specified)
      //## Operation: insert%3C61894B01B5
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantageSettledAdjustment%3C6132A2005D.public preserve=yes
      //## end AdvantageSettledAdjustment%3C6132A2005D.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageSettledAdjustment%3C6132A2005D.protected preserve=yes
      //## end AdvantageSettledAdjustment%3C6132A2005D.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageSettledAdjustment%3C6132A2005D.private preserve=yes
      //## end AdvantageSettledAdjustment%3C6132A2005D.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: INST_ID_RECN_ACQ_BandRPT_LVL_ID_B%3E201A02006D
      //## begin AdvantageSettledAdjustment::INST_ID_RECN_ACQ_BandRPT_LVL_ID_B%3E201A02006D.attr preserve=no  private: string {V} 
      string m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B;
      //## end AdvantageSettledAdjustment::INST_ID_RECN_ACQ_BandRPT_LVL_ID_B%3E201A02006D.attr

    // Data Members for Associations

      //## Association: Platform \: Advantage::AcquirerInterface_CAT::<unnamed>%3C62FD72033C
      //## Role: AdvantageSettledAdjustment::<m_pFinancialAdjustmentExtensionSegment>%3C62FD730242
      //## begin AdvantageSettledAdjustment::<m_pFinancialAdjustmentExtensionSegment>%3C62FD730242.role preserve=no  public: repositorysegment::FinancialAdjustmentExtensionSegment { -> RFHgN}
      repositorysegment::FinancialAdjustmentExtensionSegment *m_pFinancialAdjustmentExtensionSegment;
      //## end AdvantageSettledAdjustment::<m_pFinancialAdjustmentExtensionSegment>%3C62FD730242.role

      //## Association: Platform \: Advantage::AcquirerInterface_CAT::<unnamed>%3C62FD750251
      //## Role: AdvantageSettledAdjustment::<m_pFinancialAdjustmentSegment>%3C62FD760138
      //## begin AdvantageSettledAdjustment::<m_pFinancialAdjustmentSegment>%3C62FD760138.role preserve=no  public: repositorysegment::FinancialAdjustmentSegment { -> RFHgN}
      repositorysegment::FinancialAdjustmentSegment *m_pFinancialAdjustmentSegment;
      //## end AdvantageSettledAdjustment::<m_pFinancialAdjustmentSegment>%3C62FD760138.role

      //## Association: Platform \: Advantage::AcquirerInterface_CAT::<unnamed>%3C62FD7703C8
      //## Role: AdvantageSettledAdjustment::<m_pFinancialBaseSegment>%3C62FD7803A9
      //## begin AdvantageSettledAdjustment::<m_pFinancialBaseSegment>%3C62FD7803A9.role preserve=no  public: repositorysegment::FinancialBaseSegment { -> RFHgN}
      repositorysegment::FinancialBaseSegment *m_pFinancialBaseSegment;
      //## end AdvantageSettledAdjustment::<m_pFinancialBaseSegment>%3C62FD7803A9.role

      //## Association: Platform \: Advantage::AcquirerInterface_CAT::<unnamed>%3C62FD7A03A9
      //## Role: AdvantageSettledAdjustment::<m_pFinancialFeeSegment>%3C62FD7C01D4
      //## begin AdvantageSettledAdjustment::<m_pFinancialFeeSegment>%3C62FD7C01D4.role preserve=no  public: repositorysegment::FinancialFeeSegment { -> RFHgN}
      repositorysegment::FinancialFeeSegment *m_pFinancialFeeSegment;
      //## end AdvantageSettledAdjustment::<m_pFinancialFeeSegment>%3C62FD7C01D4.role

      //## Association: Platform \: Advantage::AcquirerInterface_CAT::<unnamed>%3C62FD7F0186
      //## Role: AdvantageSettledAdjustment::<m_pFinancialReversalSegment>%3C62FD8102AF
      //## begin AdvantageSettledAdjustment::<m_pFinancialReversalSegment>%3C62FD8102AF.role preserve=no  public: repositorysegment::FinancialReversalSegment { -> RFHgN}
      repositorysegment::FinancialReversalSegment *m_pFinancialReversalSegment;
      //## end AdvantageSettledAdjustment::<m_pFinancialReversalSegment>%3C62FD8102AF.role

      //## Association: Platform \: Advantage::AcquirerInterface_CAT::<unnamed>%3C62FD8401D4
      //## Role: AdvantageSettledAdjustment::<m_pFinancialSettlementSegment>%3C62FD8700BB
      //## begin AdvantageSettledAdjustment::<m_pFinancialSettlementSegment>%3C62FD8700BB.role preserve=no  public: repositorysegment::FinancialSettlementSegment { -> RFHgN}
      repositorysegment::FinancialSettlementSegment *m_pFinancialSettlementSegment;
      //## end AdvantageSettledAdjustment::<m_pFinancialSettlementSegment>%3C62FD8700BB.role

      //## Association: Platform \: Advantage::AcquirerInterface_CAT::<unnamed>%3C62FD8B0242
      //## Role: AdvantageSettledAdjustment::<m_pFinancialUserSegment>%3C62FD8F033C
      //## begin AdvantageSettledAdjustment::<m_pFinancialUserSegment>%3C62FD8F033C.role preserve=no  public: repositorysegment::FinancialUserSegment { -> RFHgN}
      repositorysegment::FinancialUserSegment *m_pFinancialUserSegment;
      //## end AdvantageSettledAdjustment::<m_pFinancialUserSegment>%3C62FD8F033C.role

    // Additional Implementation Declarations
      //## begin AdvantageSettledAdjustment%3C6132A2005D.implementation preserve=yes
      //## end AdvantageSettledAdjustment%3C6132A2005D.implementation

};

//## begin AdvantageSettledAdjustment%3C6132A2005D.postscript preserve=yes
//## end AdvantageSettledAdjustment%3C6132A2005D.postscript

//## begin module%3C6137F30138.epilog preserve=yes
//## end module%3C6137F30138.epilog


#endif
