//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3C61388D0157.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C61388D0157.cm

//## begin module%3C61388D0157.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3C61388D0157.cp

//## Module: CXOSAI10%3C61388D0157; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Pvcswork\Dn\Server\Application\Ai\CXOSAI10.cpp

//## begin module%3C61388D0157.additionalIncludes preserve=no
//## end module%3C61388D0157.additionalIncludes

//## begin module%3C61388D0157.includes preserve=yes
// $Date:   Apr 09 2018 12:49:24  $ $Author:   e1009839  $ $Revision:   1.46  $
#include "CXODIF11.hpp"
#include "CXODNS29.hpp"
//## end module%3C61388D0157.includes

#ifndef CXOSAI10_h
#include "CXODAI10.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRS13_h
#include "CXODRS13.hpp"
#endif
#ifndef CXOSRS36_h
#include "CXODRS36.hpp"
#endif
#ifndef CXOSRS39_h
#include "CXODRS39.hpp"
#endif
#ifndef CXOSRS41_h
#include "CXODRS41.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif


//## begin module%3C61388D0157.declarations preserve=no
//## end module%3C61388D0157.declarations

//## begin module%3C61388D0157.additionalDeclarations preserve=yes
//## end module%3C61388D0157.additionalDeclarations


// Class AdvantageCirrusEx92Adjustment


AdvantageCirrusEx92Adjustment::AdvantageCirrusEx92Adjustment()
  //## begin AdvantageCirrusEx92Adjustment::AdvantageCirrusEx92Adjustment%3C61331503D8_const.hasinit preserve=no
  //## end AdvantageCirrusEx92Adjustment::AdvantageCirrusEx92Adjustment%3C61331503D8_const.hasinit
  //## begin AdvantageCirrusEx92Adjustment::AdvantageCirrusEx92Adjustment%3C61331503D8_const.initialization preserve=yes
   : AdvantageMessage("0466","S200")
  //## end AdvantageCirrusEx92Adjustment::AdvantageCirrusEx92Adjustment%3C61331503D8_const.initialization
{
  //## begin AdvantageCirrusEx92Adjustment::AdvantageCirrusEx92Adjustment%3C61331503D8_const.body preserve=yes
   memcpy(m_sID,"AI10",4);
  //## end AdvantageCirrusEx92Adjustment::AdvantageCirrusEx92Adjustment%3C61331503D8_const.body
}


AdvantageCirrusEx92Adjustment::~AdvantageCirrusEx92Adjustment()
{
  //## begin AdvantageCirrusEx92Adjustment::~AdvantageCirrusEx92Adjustment%3C61331503D8_dest.body preserve=yes
  //## end AdvantageCirrusEx92Adjustment::~AdvantageCirrusEx92Adjustment%3C61331503D8_dest.body
}



//## Other Operations (implementation)
bool AdvantageCirrusEx92Adjustment::insert (Message& hMessage)
{
  //## begin AdvantageCirrusEx92Adjustment::insert%3C63D7FA009C.body preserve=yes
   hCirrusEx92Adj* pAdjustment = (hCirrusEx92Adj*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   char sTranId[4];
   memcpy(sTranId,pAdjustment->sTranId,4);
   char sMsgType[4];
   memcpy(sMsgType,pAdjustment->sMsgType,4);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
     CodeTable::translate(sTranId,4,CodeTable::CX_ASCII_TO_EBCDIC);
     CodeTable::translate(sMsgType,4,CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
     CodeTable::translate(sTranId,4,CodeTable::CX_EBCDIC_TO_ASCII);
     CodeTable::translate(sMsgType,4,CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   if ((memcmp(sTranId,"X077",4) == 0) &&
      ((memcmp(sMsgType,"1400",4) == 0) || (memcmp(sMsgType,"1420",4) == 0)))
       ;
   else
      return false;
   UseCase hUseCase("TANDEM","## AD20 READ 0466 EXCEPTION",false);
   FinancialBaseSegment* m_pFinancialBaseSegment = FinancialBaseSegment::instance();
   FinancialSettlementSegment* m_pFinancialSettlementSegment = FinancialSettlementSegment::instance();
   FinancialAdjustmentSegment* m_pFinancialAdjustmentSegment = FinancialAdjustmentSegment::instance();
   FinancialAdjustmentExtensionSegment* m_pFinancialAdjustmentExtensionSegment = FinancialAdjustmentExtensionSegment::instance();
   m_hAuditSegment.reset();
   m_pFinancialBaseSegment->reset();
   m_pFinancialSettlementSegment->reset();
   m_pFinancialAdjustmentSegment->reset();
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
      CodeTable::translate(pAdjustment->sBitMap,((char*)(&pAdjustment->cFiller2) - pAdjustment->sBitMap), CodeTable::CX_ASCII_TO_EBCDIC);
#endif
   if (memcmp(sMsgType,"1420",4) == 0)
   {
      m_pFinancialBaseSegment->setACCT_ID_1(pAdjustment->sAcctNoCompCode1,21);
      m_pFinancialBaseSegment->setACCT_ID_2(pAdjustment->sAcctNoCompCode2,21);
   }
   m_pFinancialBaseSegment->setCED_BUILD_NO(ntohl(pV13AdvantageHeader->lCED_BUILD_NO));
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   m_pFinancialBaseSegment->setINST_ID_ACQ(pAdjustment->sAcqInstId,10);
   m_pFinancialBaseSegment->setINST_ID_RECON_ACQ(pAdjustment->sAcqInstId,10);
   char sCardAcptNameLoc[84];
   memset(sCardAcptNameLoc,' ',sizeof(sCardAcptNameLoc));
   memcpy(sCardAcptNameLoc,pAdjustment->sAcqNameRegE,15);
   memcpy(sCardAcptNameLoc+26, pAdjustment->sAcqNameRegE+16,25);
   memcpy(sCardAcptNameLoc+55, pAdjustment->sAtmLocCity,16);
   m_pFinancialBaseSegment->setCARD_ACPT_NAME_LOC(sCardAcptNameLoc,84);
   if (strncmp (pAdjustment->sAtmLocCity+16," ",1) == 0)
      m_pFinancialBaseSegment->setCARD_ACPT_REGION(pAdjustment->sAtmLocCity+17,2);
   else
      m_pFinancialBaseSegment->setCARD_ACPT_COUNTRY(pAdjustment->sAtmLocCity+16,3);
   m_pFinancialBaseSegment->setINST_ID_ISS(pAdjustment->sCardInstId,10);
   m_pFinancialBaseSegment->setINST_ID_RECON_ISS(pAdjustment->sCardInstId,10);
   m_pFinancialBaseSegment->setCUR_RECON_NET(pAdjustment->sCurrencyCode,3);
   m_pFinancialBaseSegment->setMERCH_TYPE(pAdjustment->sMerchantType,4);
   short siPanLength=19;
   short siPanOffset=0;
   while (pAdjustment->sPan[siPanOffset]=='0')
   {
      siPanOffset++;
      siPanLength--;
   }
   if (Customer::instance()->getTest())
      memcpy(pAdjustment->sPan + siPanOffset + 6,"999999",6);
   m_pFinancialBaseSegment->setPAN(pAdjustment->sPan+siPanOffset,siPanLength);
   m_pFinancialBaseSegment->setRETRIEVAL_REF_NO(pAdjustment->sRetrievalRefNo,12);
   m_pFinancialBaseSegment->setCARD_ACPT_TERM_ID(pAdjustment->sTerminalId,10);
   IString hTemp(pAdjustment->sAdjAmtDr,
      sizeof(pAdjustment->sAdjAmtDr));
   if (atof(hTemp))
      m_pFinancialBaseSegment->setAMT_RECON_NET(pAdjustment->sAdjAmtDr,10);
   else
      m_pFinancialBaseSegment->setAMT_RECON_NET(pAdjustment->sAdjAmtCr,10);
   m_pFinancialBaseSegment->setAMT_TRAN(pAdjustment->sNewAmt,12);
   m_pFinancialAdjustmentSegment->setORIG_AMT_TRAN_ADJ(pAdjustment->sOrigAmt,12);
   char sTempCompCode[2];
   if (memcmp(pAdjustment->sMsgType,"1400",4) == 0)
      memcpy(sTempCompCode,&pAdjustment->sAcctNoCompCode1[1],2);
   else
      memcpy(sTempCompCode,&pAdjustment->sCompCode[1],2);
   IString strOrigAmt(pAdjustment->sOrigAmt,sizeof(pAdjustment->sOrigAmt));
   if (!atof(strOrigAmt))
   {
      if ((memcmp(pAdjustment->sResponseCode,"78",2)) == 0 ||
          (memcmp(pAdjustment->sResponseCode,"79",2)) == 0 ||
          (memcmp(pAdjustment->sResponseCode,"80",2)) == 0 ||
          (memcmp(pAdjustment->sResponseCode,"81",2)) == 0)
      {
         if ((memcmp(sTempCompCode,"00",2)) == 0)
            m_pFinancialBaseSegment->setACT_CODE("000",3);
         else
            m_pFinancialBaseSegment->setACT_CODE("400",3);
      }
      else
         m_pFinancialBaseSegment->setACT_CODE("100",3);
   }
   else
   {
      if ((memcmp(pAdjustment->sResponseCode,"01",2)) == 0)
         m_pFinancialBaseSegment->setACT_CODE("000",3);
      else
         m_pFinancialBaseSegment->setACT_CODE("100",3);
   }
   m_pFinancialBaseSegment->setUNIQUENESS_KEY(m_siUniquenessKey);
   m_pFinancialBaseSegment->setACQ_PLAT_PROD_ID("A",1);
   m_pFinancialBaseSegment->setFIN_TYPE("080",3);
   m_pFinancialBaseSegment->setTRAN_DISPOSITION("1",1);
   m_pFinancialSettlementSegment->setCNV_RCN_NET_DE_POS(&pAdjustment->cConversionDecPos,1);
   m_pFinancialSettlementSegment->setCNV_RCN_NET_RATE(pAdjustment->sConversionRate,7);
   m_pFinancialSettlementSegment->setMTI(sMsgType,4);
   m_pFinancialAdjustmentSegment->setTRACE_DATA_ADJ(pAdjustment->sSwitchSerialNo,23);
   string strProcCode(pAdjustment->sProcCode,4), strTranTypeId;
   if (ConfigurationRepository::instance()->translate("X_CIRR_PROC_CODE",
      strProcCode, strTranTypeId, "FIN_LOCATOR", "TRAN_TYPE_ID", 0))
   {
      m_pFinancialBaseSegment->setTRAN_TYPE_ID(strTranTypeId.data(),strTranTypeId.length());
      m_pFinancialBaseSegment->setACCT_TYPES_ISS(strTranTypeId.substr(2,4).data(),4);
   }
   else
      ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_SET_ACCT_TYPES_ISS);
   string strReasonCode(pAdjustment->sRevReason,2), strMsgReasonCode;
   if (ConfigurationRepository::instance()->translate("X_CIRR_ADJ_REASON",
      strReasonCode,strMsgReasonCode, "FIN_RECORD", "MSG_RESON_CODE_ACQ", 0))
      m_pFinancialBaseSegment->setMSG_RESON_CODE_ACQ(strMsgReasonCode.data(),strMsgReasonCode.length());
   char sExtensionData[40];
   memset(sExtensionData,' ',sizeof(sExtensionData));
   memcpy(sExtensionData,pAdjustment->sProcCode,4);
   sExtensionData[4] = ' ';
   memcpy(sExtensionData+5,pAdjustment->sRevReason,2);
   sExtensionData[7] = ' ';
   memcpy(sExtensionData+8,pAdjustment->sTraceNo,6);
   sExtensionData[14] = ' ';
   memcpy(sExtensionData+15,pAdjustment->sTranAmtUSD,9);
   sExtensionData[24] = ' ';
   memcpy(sExtensionData+25,pAdjustment->sResponseCode,15);
   m_pFinancialAdjustmentExtensionSegment->setEXTENSION_DATA_ADJ(sExtensionData,40);
   char sDateTime16[17] = {"                "};
   char sCentury[2];
   DateTime::calcCentury(&pAdjustment->sCurrentDate[4],sCentury);
   memcpy(sDateTime16,sCentury,2);
   memcpy(sDateTime16+2,&pAdjustment->sCurrentDate[4],2);
   memcpy(sDateTime16+4,pAdjustment->sCurrentDate,2);
   memcpy(sDateTime16+6,&pAdjustment->sCurrentDate[2],2);
   memcpy(sDateTime16+8,pAdjustment->sCurrentTime,6);
   memcpy(sDateTime16+14,"00",2);
   m_pFinancialAdjustmentSegment->setTSTAMP_TRANS_ADJ(sDateTime16,16);
   DateTime::calcCentury(&pAdjustment->sReceiptDate[4],sCentury);
   memcpy(sDateTime16,sCentury,2);
   memcpy(sDateTime16+2,&pAdjustment->sReceiptDate[4],2);
   memcpy(sDateTime16+4,pAdjustment->sReceiptDate,2);
   memcpy(sDateTime16+6,&pAdjustment->sReceiptDate[2],2);
   memcpy(sDateTime16+8,pAdjustment->sReceiptTime,6);
   m_pFinancialAdjustmentSegment->setTSTAMP_LOCAL_ADJ(sDateTime16,14);
   string strTSTAMP_TRANS(NonStopClock::getYYYYMMDDHHMMSShh(pV13AdvantageHeader->sFiller));
   m_pFinancialBaseSegment->setTSTAMP_TRANS(strTSTAMP_TRANS.data(),16);
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      m_pFinancialBaseSegment->setTSTAMP_TRANS(strTemp.data(),16);
      m_pFinancialBaseSegment->setTSTAMP_LOCAL(strTemp.data(),14);
   }
   m_pFinancialSettlementSegment->setREF_DATA_ACQ(pAdjustment->sOrigData,36);
   m_pFinancialSettlementSegment->setREF_DATA_ISS(pAdjustment->sOrigData,36);
   m_pFinancialSettlementSegment->setF_AMTn(pAdjustment->sNiFinFee,7,0);
   m_pFinancialSettlementSegment->setF_TYPEn("01",2,0);
   m_pFinancialSettlementSegment->setF_AMTn(pAdjustment->sNiNonFinFee,4,1);
   m_pFinancialSettlementSegment->setF_TYPEn("01",2,1);
   m_pFinancialSettlementSegment->setF_AMTn(pAdjustment->sSfIssFee,4,2);
   m_pFinancialSettlementSegment->setF_TYPEn("01",2,2);
   m_pFinancialSettlementSegment->setF_AMTn(pAdjustment->sSfAcqFee,4,3);
   m_pFinancialSettlementSegment->setF_TYPEn("01",2,3);
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   m_pFinancialBaseSegment->write(&psBuffer);
   m_pFinancialSettlementSegment->write(&psBuffer);
   m_pFinancialAdjustmentSegment->write(&psBuffer);
   m_pFinancialAdjustmentExtensionSegment->write(&psBuffer);
   ConfigurationRepository::instance()->write(&psBuffer,m_pFinancialBaseSegment->zTSTAMP_TRANS(),m_pFinancialBaseSegment->getUNIQUENESS_KEY());
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageCirrusEx92Adjustment::insert%3C63D7FA009C.body
}

// Additional Declarations
  //## begin AdvantageCirrusEx92Adjustment%3C61331503D8.declarations preserve=yes
  //## end AdvantageCirrusEx92Adjustment%3C61331503D8.declarations

//## begin module%3C61388D0157.epilog preserve=yes
//## end module%3C61388D0157.epilog
