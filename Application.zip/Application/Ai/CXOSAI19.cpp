//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%46652D640231.cm preserve=no
//	$Date:   Jun 21 2017 08:36:54  $ $Author:   e1009839  $
//	$Revision:   1.31  $
//## end module%46652D640231.cm

//## begin module%46652D640231.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%46652D640231.cp

//## Module: CXOSAI19%46652D640231; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXOSAI19.cpp

//## begin module%46652D640231.additionalIncludes preserve=no
//## end module%46652D640231.additionalIncludes

//## begin module%46652D640231.includes preserve=yes
//## end module%46652D640231.includes

#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSAI19_h
#include "CXODAI19.hpp"
#endif


//## begin module%46652D640231.declarations preserve=no
//## end module%46652D640231.declarations

//## begin module%46652D640231.additionalDeclarations preserve=yes
//## end module%46652D640231.additionalDeclarations


// Class AdvantageElectronicJournal

AdvantageElectronicJournal::AdvantageElectronicJournal()
  //## begin AdvantageElectronicJournal::AdvantageElectronicJournal%466CF0E00150_const.hasinit preserve=no
  //## end AdvantageElectronicJournal::AdvantageElectronicJournal%466CF0E00150_const.hasinit
  //## begin AdvantageElectronicJournal::AdvantageElectronicJournal%466CF0E00150_const.initialization preserve=yes
   : AdvantageMessage("0623","E001")
  //## end AdvantageElectronicJournal::AdvantageElectronicJournal%466CF0E00150_const.initialization
{
  //## begin AdvantageElectronicJournal::AdvantageElectronicJournal%466CF0E00150_const.body preserve=yes
   memcpy(m_sID,"AI19",4);
  //## end AdvantageElectronicJournal::AdvantageElectronicJournal%466CF0E00150_const.body
}


AdvantageElectronicJournal::~AdvantageElectronicJournal()
{
  //## begin AdvantageElectronicJournal::~AdvantageElectronicJournal%466CF0E00150_dest.body preserve=yes
  //## end AdvantageElectronicJournal::~AdvantageElectronicJournal%466CF0E00150_dest.body
}



//## Other Operations (implementation)
bool AdvantageElectronicJournal::insert (IF::Message& hMessage)
{
  //## begin AdvantageElectronicJournal::insert%466E8A1B02A4.body preserve=yes
   UseCase hUseCase("TANDEM","## AD28 READ 0623 ATM EJ",false,true);
   m_hElectronicJournalSegment.reset();
   m_hAuditSegment.reset();
   AdvantageMessage::insert(hMessage);
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   segEJ* pEJ = (segEJ*)(hMessage.data() + sizeof(hV13AdvantageHeader));
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pEJ->sNET_TERM_ID,24,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pEJ->sJOURNAL_TEXT,pEJ->siSizeofJOURNAL_TEXT,CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(pEJ->sNET_TERM_ID,24,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pEJ->sJOURNAL_TEXT,pEJ->siSizeofJOURNAL_TEXT,CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   string strTSTAMP_TRANS(NonStopClock::getYYYYMMDDHHMMSShh(pV13AdvantageHeader->sFiller));
   m_hElectronicJournalSegment.setTSTAMP_TRANS(strTSTAMP_TRANS.data(),16);
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      m_hElectronicJournalSegment.setTSTAMP_TRANS(strTemp.data(),16);      
   }
   m_hElectronicJournalSegment.setNET_TERM_ID(pEJ->sNET_TERM_ID,sizeof(pEJ->sNET_TERM_ID));
   m_hElectronicJournalSegment.setVENDOR_MODEL(pEJ->sVENDOR_MODEL,sizeof(pEJ->sVENDOR_MODEL));
   m_hElectronicJournalSegment.setEMULATION_MODEL(pEJ->sEMULATION_MODEL,sizeof(pEJ->sEMULATION_MODEL));
   m_hElectronicJournalSegment.setJOURNAL_TEXT(pEJ->sJOURNAL_TEXT,min((size_t)3072,(size_t)ntohs(pEJ->siSizeofJOURNAL_TEXT)));
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(ntohl(pV13AdvantageHeader->lHdrTstamp2Hash));
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   m_hElectronicJournalSegment.write(&psBuffer);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageElectronicJournal::insert%466E8A1B02A4.body
}

// Additional Declarations
  //## begin AdvantageElectronicJournal%466CF0E00150.declarations preserve=yes
  //## end AdvantageElectronicJournal%466CF0E00150.declarations

//## begin module%46652D640231.epilog preserve=yes
//## end module%46652D640231.epilog
