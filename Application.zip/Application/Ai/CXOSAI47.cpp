//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EB2C435008F.cm preserve=no
//   $Date:   Oct 20 2020 06:37:00  $ $Author:   e3023547  $
//   $Revision:   1.1  $
//## end module%5EB2C435008F.cm

//## begin module%5EB2C435008F.cp preserve=no
//   Copyright (c) 1997 - 2012
//   FIS
//## end module%5EB2C435008F.cp

//## Module: CXOSAI47%5EB2C435008F; Package body
//## Subsystem: AI%3597E7CC007A
//   .
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI47.cpp

//## begin module%5EB2C435008F.additionalIncludes preserve=no
//## end module%5EB2C435008F.additionalIncludes

//## begin module%5EB2C435008F.includes preserve=yes
#include "CXODRS28.hpp"
//## end module%5EB2C435008F.includes

#ifndef CXOSAI47_h
#include "CXODAI47.hpp"
#endif
//## begin module%5EB2C435008F.declarations preserve=no
//## end module%5EB2C435008F.declarations

//## begin module%5EB2C435008F.additionalDeclarations preserve=yes
namespace
{
#define FIELDS200 12
struct new_hAccountHolder200* phAccountHolder200 = 0;
Fields hAccountHolder200_Fields[FIELDS200 + 1] =
{
   "i         ","",offsetof(new_hAccountHolder200,iLedBalI),sizeof(phAccountHolder200->iLedBalI),
   "i         ","",offsetof(new_hAccountHolder200,iAvalBalI),sizeof(phAccountHolder200->iAvalBalI),
   "i         ","",offsetof(new_hAccountHolder200,iCreditLineAmtI),sizeof(phAccountHolder200->iCreditLineAmtI),
   "i         ","",offsetof(new_hAccountHolder200,iUnpDbAmt),sizeof(phAccountHolder200->iUnpDbAmt),
   "i         ","",offsetof(new_hAccountHolder200,UnpCrAmt),sizeof(phAccountHolder200->UnpCrAmt),
   "i         ","",offsetof(new_hAccountHolder200,UnpAvalCrAmt),sizeof(phAccountHolder200->UnpAvalCrAmt),
   "t         ","",offsetof(new_hAccountHolder200,sLastTranTstamp),sizeof(phAccountHolder200->sLastTranTstamp),
   "a         ","",offsetof(new_hAccountHolder200,sAcctStatus),sizeof(phAccountHolder200->sAcctStatus),
   "b         "," WD DP IQ PT PF TT TF PR 3P DF",offsetof(new_hAccountHolder200,siAcctAccess),sizeof(phAccountHolder200->siAcctAccess),
   "i         ","",offsetof(new_hAccountHolder200,iOdAmt),sizeof(phAccountHolder200->iOdAmt),
   "t         ","",offsetof(new_hAccountHolder200,sUpdtTstamp),sizeof(phAccountHolder200->sUpdtTstamp),
   "t         ","",offsetof(new_hAccountHolder200,sMntTstamp),sizeof(phAccountHolder200->sMntTstamp),
   "~","",0,sizeof(new_hAccountHolder200),
};

#define FIELDS201 3
struct new_hAccountHolder201* phAccountHolder201 = 0;
Fields hAccountHolder201_Fields[FIELDS201 + 1] =
{
   "a         ","",offsetof(new_hAccountHolder201,sFiId),sizeof(phAccountHolder201->sFiId),
   "a         ","",offsetof(new_hAccountHolder201,sAcctType),sizeof(phAccountHolder201->sAcctType),
   "a         ","",offsetof(new_hAccountHolder201,sAcctNo),sizeof(phAccountHolder201->sAcctNo),
   "~","",0,sizeof(new_hAccountHolder201),
};

#define FIELDS202 3
struct new_hAccountHolder202* phAccountHolder202 = 0;
Fields hAccountHolder202_Fields[FIELDS202 + 1] =
{
   "i         ","",offsetof(new_hAccountHolder202,iAmount),sizeof(phAccountHolder202->iAmount),
   "t         ","",offsetof(new_hAccountHolder202,sExpTime),sizeof(phAccountHolder202->sExpTime),
   "a         ","",offsetof(new_hAccountHolder202,sMatchData),sizeof(phAccountHolder202->sMatchData),
   "~","",0,sizeof(new_hAccountHolder202),
};
}
//## end module%5EB2C435008F.additionalDeclarations


// Class APAcctMaintenanceSegment

APAcctMaintenanceSegment::APAcctMaintenanceSegment()
  //## begin APAcctMaintenanceSegment::APAcctMaintenanceSegment%5EB2C2E200B2_const.hasinit preserve=no
  //## end APAcctMaintenanceSegment::APAcctMaintenanceSegment%5EB2C2E200B2_const.hasinit
  //## begin APAcctMaintenanceSegment::APAcctMaintenanceSegment%5EB2C2E200B2_const.initialization preserve=yes
  //## end APAcctMaintenanceSegment::APAcctMaintenanceSegment%5EB2C2E200B2_const.initialization
{
  //## begin APAcctMaintenanceSegment::APAcctMaintenanceSegment%5EB2C2E200B2_const.body preserve=yes
   memcpy(m_sID,"AI47",4);
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("AD01"),&hAccountHolder200_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("AD02"),&hAccountHolder201_Fields[0]));
   m_hFields.insert(map<string,Fields*,less<string> >::value_type(string("AD03"),&hAccountHolder202_Fields[0]));
  //## end APAcctMaintenanceSegment::APAcctMaintenanceSegment%5EB2C2E200B2_const.body
}


APAcctMaintenanceSegment::~APAcctMaintenanceSegment()
{
  //## begin APAcctMaintenanceSegment::~APAcctMaintenanceSegment%5EB2C2E200B2_dest.body preserve=yes
  //## end APAcctMaintenanceSegment::~APAcctMaintenanceSegment%5EB2C2E200B2_dest.body
}


// Additional Declarations
  //## begin APAcctMaintenanceSegment%5EB2C2E200B2.declarations preserve=yes
  //## end APAcctMaintenanceSegment%5EB2C2E200B2.declarations

//## begin module%5EB2C435008F.epilog preserve=yes
//## end module%5EB2C435008F.epilog
