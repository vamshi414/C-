//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3F1D566C0138.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3F1D566C0138.cm

//## begin module%3F1D566C0138.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3F1D566C0138.cp

//## Module: CXOSAI18%3F1D566C0138; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXODAI18.hpp

#ifndef CXOSAI18_h
#define CXOSAI18_h 1

//## begin module%3F1D566C0138.additionalIncludes preserve=no
//## end module%3F1D566C0138.additionalIncludes

//## begin module%3F1D566C0138.includes preserve=yes
// $Date:   Jan 31 2018 14:07:14  $ $Author:   e1009839  $ $Revision:   1.2  $
//## end module%3F1D566C0138.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

class AdvantageMessageProcessor;
//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%3F1D566C0138.declarations preserve=no
//## end module%3F1D566C0138.declarations

//## begin module%3F1D566C0138.additionalDeclarations preserve=yes
//## end module%3F1D566C0138.additionalDeclarations


//## begin AdvantageVisaException%3F1D56A20109.preface preserve=yes
//## end AdvantageVisaException%3F1D56A20109.preface

//## Class: AdvantageVisaException%3F1D56A20109
//## Category: Platform \: Advantage::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3F1D58080261;IF::Message { -> F}
//## Uses: <unnamed>%3F1D839C0399;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%3F1D83B5008C;monitor::UseCase { -> F}
//## Uses: <unnamed>%3F1D83DD0261;process::Application { -> F}
//## Uses: <unnamed>%3F1EBDA500CB;IF::CodeTable { -> F}

class DllExport AdvantageVisaException : public AdvantageMessage  //## Inherits: <unnamed>%3F1D57BA031C
{
  //## begin AdvantageVisaException%3F1D56A20109.initialDeclarations preserve=yes
  //## end AdvantageVisaException%3F1D56A20109.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageVisaException();

    //## Destructor (generated)
      virtual ~AdvantageVisaException();


    //## Other Operations (specified)
      //## Operation: insert%3F1D57EA0213
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantageVisaException%3F1D56A20109.public preserve=yes
      //## end AdvantageVisaException%3F1D56A20109.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageVisaException%3F1D56A20109.protected preserve=yes
      //## end AdvantageVisaException%3F1D56A20109.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageVisaException%3F1D56A20109.private preserve=yes
      //## end AdvantageVisaException%3F1D56A20109.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin AdvantageVisaException%3F1D56A20109.implementation preserve=yes
      //## end AdvantageVisaException%3F1D56A20109.implementation

};

//## begin AdvantageVisaException%3F1D56A20109.postscript preserve=yes
//## end AdvantageVisaException%3F1D56A20109.postscript

//## begin module%3F1D566C0138.epilog preserve=yes
//## end module%3F1D566C0138.epilog


#endif
