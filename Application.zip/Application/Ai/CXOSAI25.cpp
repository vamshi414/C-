//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A50EF1D0226.cm preserve=no
//	$Date:   Nov 27 2019 14:14:58  $ $Author:   e1009839  $
//	$Revision:   1.12  $
//## end module%5A50EF1D0226.cm

//## begin module%5A50EF1D0226.cp preserve=no
//	Copyright (c) 1997 - 2018
//	FIS
//## end module%5A50EF1D0226.cp

//## Module: CXOSAI25%5A50EF1D0226; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI25.cpp

//## begin module%5A50EF1D0226.additionalIncludes preserve=no
//## end module%5A50EF1D0226.additionalIncludes

//## begin module%5A50EF1D0226.includes preserve=yes
#include "CXODCF01.hpp"
#include "CXODIF04.hpp"
#include "CXODIF08.hpp"
#include "CXODTM06.hpp"
#include "CXODRS62.hpp"
#include "CXODRS66.hpp"
#include "CXODIF03.hpp"
#include "CXODDB16.hpp"
//## end module%5A50EF1D0226.includes

#ifndef CXOSRU47_h
#include "CXODRU47.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSRU37_h
#include "CXODRU37.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSNS29_h
#include "CXODNS29.hpp"
#endif
#ifndef CXOSDB49_h
#include "CXODDB49.hpp"
#endif
#ifndef CXOSAI25_h
#include "CXODAI25.hpp"
#endif


//## begin module%5A50EF1D0226.declarations preserve=no
//## end module%5A50EF1D0226.declarations

//## begin module%5A50EF1D0226.additionalDeclarations preserve=yes
//## end module%5A50EF1D0226.additionalDeclarations


// Class Financial

Financial::Financial()
  //## begin Financial::Financial%5A50EEA30372_const.hasinit preserve=no
      : m_bAddEvidence(false),
        m_bAuthByAltRoute(false),
        m_iBufferStartp(0),
        m_cClass(' ' ),
        m_bExpirationDate(false),
        m_iLinkOption(0),
        m_cNetworkDecPos(' ' ),
        m_cPreAuthFlag(' ' ),
        m_cPreauthInd(' ' ),
        m_bReversal(false),
        m_pSegment(0),
        m_pSegment99(0),
        m_bTokenExpirationDate(false),
        m_bTrack2(false)
  //## end Financial::Financial%5A50EEA30372_const.hasinit
  //## begin Financial::Financial%5A50EEA30372_const.initialization preserve=yes
   ,AdvantageMessage("0400","S200")
  //## end Financial::Financial%5A50EEA30372_const.initialization
{
  //## begin Financial::Financial%5A50EEA30372_const.body preserve=yes
   memcpy(m_sID,"AI25",4);
   string strRecord;
   Extract::instance()->getRecord("DUSER   ",strRecord);
   m_bExpirationDate = strRecord.find("DATE_EXP") != string::npos;
   m_iLinkOption = strRecord.find("LINK") != string::npos ? 1 : 0;
   m_bTokenExpirationDate = strRecord.find("TOKEN_EXP_DATE") != string::npos;
   m_bTrack2 = strRecord.find("TRACK2") != string::npos;
  //## end Financial::Financial%5A50EEA30372_const.body
}


Financial::~Financial()
{
  //## begin Financial::~Financial%5A50EEA30372_dest.body preserve=yes
  //## end Financial::~Financial%5A50EEA30372_dest.body
}



//## Other Operations (implementation)
int Financial::convertAmt (int lAmount, char cDecPos, char* sRate)
{
  //## begin Financial::convertAmt%3C6195C2002E.body preserve=yes
   return (int)convertAmt((double)lAmount,cDecPos,sRate);
  //## end Financial::convertAmt%3C6195C2002E.body
}

double Financial::convertAmt (double dAmount, char cDecPos, char* sRate)
{
  //## begin Financial::convertAmt%5AB1008F009E.body preserve=yes
   double dRate = atof(sRate);
   if (dRate == 1
      && cDecPos == '0')
      return dAmount;
   double dConvertedAmt = 0;
   switch (cDecPos)
   {
      case '0':
         dConvertedAmt = (dAmount * dRate);
         break;
      case '1':
         dConvertedAmt = (dAmount * dRate) * .1;
         break;
      case '2':
         dConvertedAmt = (dAmount * dRate) * .01;
         break;
      case '3':
         dConvertedAmt = (dAmount * dRate) * .001;
         break;
      case '4':
         dConvertedAmt = (dAmount * dRate) * .0001;
         break;
      case '5':
         dConvertedAmt = (dAmount * dRate) * .00001;
         break;
      case '6':
         dConvertedAmt = (dAmount * dRate) * .000001;
         break;
      case '7':
         dConvertedAmt = (dAmount * dRate) * .0000001;
         break;
      case '8':
         dConvertedAmt = (dAmount * dRate) * .00000001;
         break;
      case '9':
         dConvertedAmt = (dAmount * dRate) * .000000001;
         break;
      default:
         dConvertedAmt = dAmount;
   }
   if (dConvertedAmt > 0)
      dConvertedAmt += .5;
   else
   if (dConvertedAmt < 0)
      dConvertedAmt -= .5;
   char szTemp[PERCENTF];
   sprintf(szTemp,"%f",dConvertedAmt);
   char* p = strchr(szTemp,'.');
   if (p)
      *p = '\0';
   dConvertedAmt = atof(szTemp);
   return dConvertedAmt;
  //## end Financial::convertAmt%5AB1008F009E.body
}

void Financial::convertBitMap (const char cCharBit, char* psBits)
{
  //## begin Financial::convertBitMap%5AB12B0402E0.body preserve=yes
   char sBits[65] = {"0000000100100011010001010110011110001001101010111100110111101111"};
   char pszHex [17] = {"0123456789ABCDEF"};
   char* p = strchr(pszHex,cCharBit);
   if (!p)
      memcpy(psBits,sBits,4);
   else
      memcpy(psBits,sBits + ((p-pszHex) * 4),4);
  //## end Financial::convertBitMap%5AB12B0402E0.body
}

bool Financial::insert (Message& hMessage)
{
  //## begin Financial::insert%5A50EEE402BE.body preserve=yes
   UseCase hUseCase("TANDEM","## AI25 READ 0400 FINANCIAL",false);
   m_pSegment99 = (hSegment99*)(hMessage.data() + 16384);
   memset((void*)m_pSegment99,' ',sizeof(struct hSegment99));
   m_pSegment99->lAMT_TRAN[0] = 0;
   m_pSegment99->lAMT_TRAN[1] = 0;
   m_pSegment99->siUNIQUENESS_KEY = 0;
   m_pSegment99->dAMT_RECON_NET1 = 0;
   m_pSegment99->dAMT_RECON_NET2 = 0;
   m_pSegment99->sTIME_AT_AP = 0;
   m_pSegment99->sTIME_AT_ISS = 0;
   m_pSegment99->sTIME_AT_RESP_QUE = 0;
   m_pSegment99->sTIME_AT_RESP_SWTCH = 0;
   m_pSegment99->sTIME_AT_RQST_QUE = 0;
   m_pSegment99->sTIME_AT_RQST_SWTCH = 0;
   m_pSegment99->siREF_DATA_ACQ_FMT = 0;
   m_pSegment99->lAmtReconAcqr[0] = 0;
   m_pSegment99->lAmtReconAcqr[1] = 0;
   m_pSegment99->lAmtReconIssr[0] = 0;
   m_pSegment99->lAmtReconIssr[1] = 0;
   m_pSegment99->siREF_DATA_ISS_FMT = 0;
   m_pSegment99->dO_AMT_RECON_NET = 0;
   m_pSegment99->cCVV_CVC_RESULT = 'N';
   m_pSegment = hMessage.data();
   hV13AdvantageHeader* pAdvantageHeader = (hV13AdvantageHeader*)m_pSegment;
   if (AdvantageMessageProcessor::instance()->getMessageCode() == "0482"
      && ntohs(pAdvantageHeader->siHdrMsgStep) != 9014)
      return false;
   hFinancialSeg1* p = (hFinancialSeg1*)(m_pSegment += sizeof(hV13AdvantageHeader));
   setTSTAMP_TRANS(p->sMilestone0);
   ::Template::instance()->map("V13HEADER",(const char*)hMessage.data());
   mapSegment1(p);
   m_pSegment += sizeof(hFinancialSeg1);
   if (p->bSeg2)
   {
      mapSegment2((hFinancialSeg2*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg2);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg2);
   if (p->bSeg3)
   {
      mapSegment3((hFinancialSeg3*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg3);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg3);
   if (p->bSeg4)
   {
      mapSegment4((hFinancialSeg4*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg4);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg4);
   if (p->bSeg5)
   {
      mapSegment5((hFinancialSeg5*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg5);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg5);
   if (p->bSeg6)
   {
      mapSegment6((hFinancialSeg6*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg6);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg6);
   if (p->bSeg7)
   {
      mapSegment7((hFinancialSeg7*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg7);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg7);
   if (p->bSeg8)
   {
      mapSegment8((hFinancialSeg8*)m_pSegment,p);
      m_pSegment += sizeof(hFinancialSeg8);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg8);
   if (p->bSeg9)
   {
      mapSegment9((hFinancialSeg9*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg9);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg9);
   if (p->bSeg10)
   {
      mapSegment10((hFinancialSeg10*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg10);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg10);
   if (p->bSeg11)
   {
      mapSegment11((hFinancialSeg11*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg11);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg11);
   if (p->bSeg12)
   {
      mapSegment12((hFinancialSeg12*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg12);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg12);
   if (p->bSeg13)
   {
      mapSegment13((hFinancialSeg13*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg13);
   }
   else
   {
      mapSegment13(0);
      if (!m_bAsciiInput)
         m_pSegment += sizeof(hFinancialSeg13);
   }
   if (p->bSeg14)
   {
      mapSegment14((hFinancialSeg14*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg14);
   }
   else
   {
      mapSegment14(0);
      if (!m_bAsciiInput)
         m_pSegment += sizeof(hFinancialSeg14);
   }
   if (p->bSeg15)
   {
      mapSegment15((hFinancialSeg15*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg15);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg15);
   if (p->bSeg16)
   {
      mapSegment16((hFinancialSeg16*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg16);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg16);
   if (p->bSeg17)
   {
      mapSegment17((hFinancialSeg17*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg17);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg17);
   if (p->bSeg18)
   {
      mapSegment18((hFinancialSeg18*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg18);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg18);
   if (p->bSeg19)
   {
      mapSegment19((hFinancialSeg19*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg19);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg19);
   if (p->bSeg20)
   {
      mapSegment20((hFinancialSeg20*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg20);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg20);
   if (p->bSeg21)
   {
      mapSegment21((hFinancialSeg21*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg21);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg21);
   if (p->bSeg22)
   {
      mapSegment22((hFinancialSeg22*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg22);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg22);
   if (p->bSeg23)
   {
      mapSegment23((hFinancialSeg23*)m_pSegment);
      m_pSegment += sizeof(hFinancialSeg23);
   }
   else
   if (!m_bAsciiInput)
      m_pSegment += sizeof(hFinancialSeg23);
   if (p->bSeg24)
      mapSegment24((hFinancialSeg24*)m_pSegment);
   mapSegment99(p);
   return deport(hMessage);
  //## end Financial::insert%5A50EEE402BE.body
}

void Financial::mapSegment1 (hFinancialSeg1* p)
{
  //## begin Financial::mapSegment1%5A5140CA012F.body preserve=yes
   translate(&p->sMTI[0],((char *)(&p->siRptInstAcqrBranch) - &p->sMTI[0]));
   translate(p->sPan,((char*)(&p->siRouteToAP) - p->sPan));
   translate(p->sAltProcId,((char *)(&p->siAltRouteToAP) - p->sAltProcId));
   translate(p->sAcctType1,((char *)(&p->siCurrType) - p->sAcctType1));
   translate(p->sCurrTran,((char *)(&p->lAmtTran) - p->sCurrTran));
   if (AdvantageMessageProcessor::instance()->getMessageCode() == "0491")
   {
      memcpy(m_pSegment99->sFIN_TYPE,"900",3);
      m_bAddEvidence = false;
   }
   else
   {
      hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)Message::instance(Message::INBOUND)->data();
      char sSearchValue[9];
      sprintf(sSearchValue,"%04d%04d",ntohs(pV13AdvantageHeader->siHdrMsgCode),ntohs(pV13AdvantageHeader->siHdrMsgStep));
      string strFirst(sSearchValue);
      string strFIN_TYPE;
      if (ConfigurationRepository::instance()->translate("X_ADV_MSG_CODE",strFirst,strFIN_TYPE,"FIN_LOCATOR","FIN_TYPE",0))
         memcpy(m_pSegment99->sFIN_TYPE,strFIN_TYPE.data(),strFIN_TYPE.length());
      m_bAddEvidence = true;
   }
   memcpy(m_pSegment99->sACT_CODE,p->sActionCode,3);
   memcpy(m_pSegment99->sFUNC_CODE,p->sFuncCode,3);
   memcpy(m_pSegment99->sACCT_ID_1,p->sAcctId1,28);
   memcpy(m_pSegment99->sMERCH_TYPE,p->sMerchType,4);
   memcpy(m_pSegment99->sPAN_PREFIX,p->sPan,6);
   m_pSegment99->cCARD_CAPT_FLG = 'N';
   if (p->sPan[3] != ' ')
   {
      char* pSpace = p->sPan + 27;
      while (*pSpace == ' ')
      {
         --pSpace;
      }
      memcpy(m_pSegment99->sPAN_SUFFIX,pSpace - 3,4);
   }
   if (Customer::instance()->getTest())
      memcpy(p->sPan + 6,"999999",6);
   m_pSegment99->lAMT_TRAN[0] = p->lAmtTran[0];
   m_pSegment99->lAMT_TRAN[1] = p->lAmtTran[1];
   string strNET_TERM_ID(p->sNetworkTermId,8);
   reformatInstId(p->sInstIdAcqr);
   memcpy(p->sInstIdAcqr,m_sStdInstId,11);
   reformatInstId(p->sInstIdIssr);
   memcpy(p->sInstIdIssr,m_sStdInstId,11);
   reformatInstId(p->sRptInstIdAcqr);
   memcpy(p->sRptInstIdAcqr,m_sStdInstId,11);
   string sInstId(m_sStdInstId);
   string strOverrideAcqInst;
   bool bOverride = ConfigurationRepository::instance()->mapItem("X_INST_ID_RECON",sInstId,(string)p->sRptInstIdAcqr,"A",strOverrideAcqInst);
   if (bOverride
      && strOverrideAcqInst == "INST_ID_***")
   {
      strOverrideAcqInst.assign(p->sInstIdAcqr,11);
      size_t pos = strOverrideAcqInst.find_first_of(" ");
      if (pos != string::npos)
         strOverrideAcqInst.erase(pos);
      if (strOverrideAcqInst.length() == 6)
         strOverrideAcqInst.append("001");
   }
   if (ConfigurationRepository::instance()->translate("DEVICE",strNET_TERM_ID,m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B,"FIN_LOCATOR","INST_ID_RECN_ACQ_B",0,m_bAddEvidence))
   {
      string strInstIdReconAcq;
      if (m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.length() > 0)
      {
         strInstIdReconAcq.assign(m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.data(),11);
         if (m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.length() > 11)
            memcpy(m_pSegment99->sRPT_LVL_ID_B,m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.data() + 11,m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B.length() - 11);
      }
      if (bOverride)
         memcpy(m_pSegment99->sINST_ID_RECN_ACQ_B,strOverrideAcqInst.data(),strOverrideAcqInst.length());
      else
         memcpy(m_pSegment99->sINST_ID_RECN_ACQ_B,strInstIdReconAcq.data(),strInstIdReconAcq.length());
      string strProcIdAcq;
      if (ConfigurationRepository::instance()->translate("INSTITUTION",(string)m_pSegment99->sINST_ID_RECN_ACQ_B,strProcIdAcq,"FIN_LOCATOR","PROC_ID_ACQ_B",0,m_bAddEvidence))
      {
         memcpy(m_pSegment99->sPROC_ID_ACQ_B,strProcIdAcq.data(),strProcIdAcq.length());
         string strProcGrpIdAcq;
         if (ConfigurationRepository::instance()->translate("PROCESSOR",strProcIdAcq,strProcGrpIdAcq,"FIN_LOCATOR","PROC_GRP_ID_ACQ_B",0,m_bAddEvidence))
            memcpy(m_pSegment99->sPROC_GRP_ID_ACQ_B,strProcGrpIdAcq.data(),strProcGrpIdAcq.length());
      }
      else
      if (m_bAddEvidence)
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   }
   else
   if (m_bAddEvidence)
   {
      string strSOURCE_VALUE(strNET_TERM_ID);
      strSOURCE_VALUE.resize(8,' ');
      strSOURCE_VALUE.append(m_pSegment99->sINST_ID_RECN_ACQ_B,11);
      strSOURCE_VALUE.resize(19,' ');
      strSOURCE_VALUE.append(p->sInstIdAcqr);
      ConfigurationRepository::instance()->getEvidenceSegment().setSOURCE_VALUE(strSOURCE_VALUE);
      ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ACQ_DATA);
   }
   memcpy(m_pSegment99->sDATE_RECON_NET,"20",2);
   memcpy(m_pSegment99->sDATE_RECON_NET + 2,p->sDateReconNetworkYYMMDD,6);
   if ((p->sDateReconAcqrYYMMDD[0] == ' ') || (memcmp(p->sDateReconAcqrYYMMDD,"000000",6) == 0))
      memcpy(m_pSegment99->sDATE_RECON_ACQ,m_pSegment99->sDATE_RECON_NET,8);
   else
   {
      memcpy(m_pSegment99->sDATE_RECON_ACQ,"20",2);
      memcpy(m_pSegment99->sDATE_RECON_ACQ + 2,p->sDateReconAcqrYYMMDD,6);
   }
   if (Extract::instance()->getCustomCode() == "EFTPOS")
      memcpy(m_pSegment99->sDATE_RECON_ISS,m_pSegment99->sDATE_RECON_ACQ,8);
   else
   if (p->sDateReconIssrYYMMDD[0] == ' ')
      memcpy(m_pSegment99->sDATE_RECON_ISS,m_pSegment99->sDATE_RECON_NET,8);
   else
   {
      memcpy(m_pSegment99->sDATE_RECON_ISS,"20",2);
      memcpy(m_pSegment99->sDATE_RECON_ISS + 2,p->sDateReconIssrYYMMDD,6);
   }
   memcpy(m_pSegment99->sTSTAMP_LOCAL,"20",2);
   memcpy(m_pSegment99->sTSTAMP_LOCAL + 2,p->sDateLocalYYMMDD,6);
   memcpy(m_pSegment99->sTSTAMP_LOCAL + 8,p->sTimeLocalHRMNSC,6);
   if (m_bAuthByAltRoute)
   {
      memcpy(p->sRptInstIdIssr,p->sAltRptInstIdIssr,11);
      memcpy(p->sMsgReasonCodeIssr,p->sAltMsgReasonCodeIssr,4);
      memcpy(p->sNetworkIdIssr,p->sAltNetworkIdIssr,3);
      memcpy(p->sProcId,p->sAltProcId,6);
   }
   reformatInstId(p->sRptInstIdIssr);
   if (memcmp(m_sStdInstId,"           ",11) != 0)
   {
      memcpy(p->sRptInstIdIssr,m_sStdInstId,11);
      string strINST_ID_RECN_ISS_B;
      if (ConfigurationRepository::instance()->mapItem("X_INST_ID_RECON",(string)p->sRptInstIdIssr,(string)p->sInstIdIssr,"I",strINST_ID_RECN_ISS_B))
      {
         if (strINST_ID_RECN_ISS_B == "INST_ID_***")
         {
            strINST_ID_RECN_ISS_B.assign(p->sInstIdIssr);
            size_t pos = strINST_ID_RECN_ISS_B.find_first_of(" ");
            if (pos != string::npos)
               strINST_ID_RECN_ISS_B.erase(pos);
            if (strINST_ID_RECN_ISS_B.length() == 6)
               strINST_ID_RECN_ISS_B.append("001");
         }
      }
      else
         strINST_ID_RECN_ISS_B.assign(p->sRptInstIdIssr,11);
      memcpy(m_pSegment99->sINST_ID_RECN_ISS_B,strINST_ID_RECN_ISS_B.data(),strINST_ID_RECN_ISS_B.length());
      string strPROC_ID_ISS_B;
      if (ConfigurationRepository::instance()->translate("INSTITUTION",strINST_ID_RECN_ISS_B,strPROC_ID_ISS_B,"FIN_LOCATOR","PROC_ID_ISS_B",0,m_bAddEvidence))
      {
         memcpy(m_pSegment99->sPROC_ID_ISS_B,strPROC_ID_ISS_B.data(),strPROC_ID_ISS_B.length());
         string strPROC_GRP_ID_ISS_B;
         if (ConfigurationRepository::instance()->translate("PROCESSOR",strPROC_ID_ISS_B,strPROC_GRP_ID_ISS_B,"FIN_LOCATOR","PROC_GRP_ID_ISS_B",0,m_bAddEvidence))
            memcpy(m_pSegment99->sPROC_GRP_ID_ISS_B,strPROC_GRP_ID_ISS_B.data(),strPROC_GRP_ID_ISS_B.length());
      }
      else
      if (m_bAddEvidence)
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_PROPOGATE_ISS_DATA);
   }
/* !!!   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      m_pFinancialBaseSegment->setTSTAMP_TRANS(strTemp.data(),16);
      m_pFinancialBaseSegment->setTSTAMP_LOCAL(strTemp.data(),14);
      string strCutOff(getTestDate());
      strCutOff += Customer::instance()->getCUTOFF_TIME();
      if(strTemp < strCutOff)
      {
         m_pFinancialUserSegment->setDATE_RECON_NET(getTestDate().data(),8);
         m_pFinancialBaseSegment->setDATE_RECON_ACQ(getTestDate().data(),8);
         m_pFinancialSettlementSegment->setDATE_RECON_ISS(getTestDate().data(),8);
      }
      else
      {
         Date hDate(getTestDate().c_str());
         hDate += 1;
         strCutOff = hDate.asString("%Y%m%d");
         m_pFinancialUserSegment->setDATE_RECON_NET(strCutOff.data(),8);
         m_pFinancialBaseSegment->setDATE_RECON_ACQ(strCutOff.data(),8);
         m_pFinancialSettlementSegment->setDATE_RECON_ISS(strCutOff.data(),8);
      }
   } */
   if (!(p->bPrcFlag1bit9)
      && !(p->bPrcFlag1bit10))
      m_cPreauthInd = '0';
   else
   if (p->bPrcFlag1bit9)
      m_cPreauthInd = '1';
   else
      m_cPreauthInd = '2';
   m_bReversal = (p->sMTI[1] == '4');
   char szActionCode[4] = {"   "};
   memcpy(szActionCode,p->sActionCode,3);
   if (p->sMTI[1] == '4')
   {
      m_pSegment99->cTRAN_DISPOSITION1 = '3';
      m_pSegment99->cTRAN_DISPOSITION2 = '3';
      m_pSegment99->lAMT_TRAN[0] = p->lOrigAmtTran[0];
      m_pSegment99->lAMT_TRAN[1] = p->lOrigAmtTran[1];
      if (atoi(szActionCode) > 400)    // implies rejected reversal
      {
         m_pSegment99->cTRAN_DISPOSITION1 = '2';
         m_pSegment99->cTRAN_DISPOSITION2 = '2';
      }
   }
   else
   if ((isalpha(szActionCode[0])) || (isalpha(szActionCode[1])) || (isalpha(szActionCode[2])) || (atoi(szActionCode) > 99))
   {
      m_pSegment99->cTRAN_DISPOSITION1 = '2';
      m_pSegment99->cTRAN_DISPOSITION2 = '2';
      m_pSegment99->lAMT_TRAN[0] = p->lOrigAmtTran[0];
      m_pSegment99->lAMT_TRAN[1] = p->lOrigAmtTran[1];
   }
   else
   {
      m_pSegment99->cTRAN_DISPOSITION1 = '1';
      m_pSegment99->cTRAN_DISPOSITION2 = '1';
   }
   database::UniquenessKey::hash(p->sPan,16);
   database::UniquenessKey::hash(p->sRetrievalRefNo,12);
   database::UniquenessKey::hash(p->sSystemTraceAuditNo,6);
   database::UniquenessKey::hash(&m_pSegment99->cTRAN_DISPOSITION1,1);
   m_pTransaction->setUNIQUENESS_KEY(database::UniquenessKey::getHash());
   m_pSegment99->cACQ_PLAT_PROD_ID = 'A';
   if (AdvantageMessageProcessor::instance()->getTranClassLength() != 0)
   {
      string strTemp;
      string strTranClass;
      strTemp.assign(((char*)m_pSegment - m_iBufferStartp) + (AdvantageMessageProcessor::instance()->getTranClassOffset() - 1),AdvantageMessageProcessor::instance()->getTranClassLength());
      if (ConfigurationRepository::instance()->translate("X_TO_TRAN_CLASS",strTemp,strTranClass,"FIN_LOCATOR","TRAN_CLASS",0,m_bAddEvidence))
         memcpy(m_pSegment99->sTRAN_CLASS,strTranClass.data(),strTranClass.length());
   }
   m_cNetworkDecPos = p->cConvReconNetworkDecPos;
   memcpy(m_sNetworkRate,p->sConvReconNetworkRate,7);
   m_sNetworkRate[7] = '\0';
   if (memcmp(p->sCardAcptId,"               ",15) == 0)
      memcpy(p->sCardAcptId,"BLANK",5);
   if (!m_bExpirationDate)
      memset(p->sDateExpYYMM,' ',4);
   m_cClass = p->sMTI[1];
   string strReturnValue;
   string strCardCategory(p->sCardCategory,sizeof(p->sCardCategory));
   if (ConfigurationRepository::instance()->translate("X_ADV_CARD_TYPE",strCardCategory,strReturnValue,"FIN_RECORD","CARD_TYPE",0,m_bAddEvidence))
      m_pSegment99->cCARD_TYPE = strReturnValue[0];
   string strCardLogoId(p->sCardLogoId,sizeof(p->sCardLogoId));
   if (ConfigurationRepository::instance()->translate("X_ADV_CARD_LOGO",strCardLogoId,strReturnValue,"FIN_RECORD","CARD_OWNER",0,m_bAddEvidence))
      memcpy(m_pSegment99->sCARD_OWNER,strReturnValue.data(),strReturnValue.length());
   m_pSegment99->cDRAFT_CAPTURE_FLG = p->bPrcFlag3bit0 ? 'Y' : 'N';
   m_pSegment99->cHOST_RECV_FLG = p->bPrcFlag3bit3 ? 'Y' : 'N';
   m_pSegment99->cHOST_SENT_FLG = p->bPrcFlag3bit4 ? 'Y' : 'N';
   m_pSegment99->cOAR_RQST_FLG = (p->bPrcFlag3bit1 || p->bPrcFlag3bit2) ? 'Y' : 'N';
   memcpy(m_pSegment99->sCUR_RECON_NET,p->sCurrReconNetwork,3);
   if (p->bPrcFlag1bit1 && p->bPrcFlag1bit2)
      m_pSegment99->cEXCHG_MASTER = 'B';
   else
   if (p->bPrcFlag1bit1
      && !(p->bPrcFlag1bit2))
      m_pSegment99->cEXCHG_MASTER = 'A';
   else
   if (!(p->bPrcFlag1bit1)
      && p->bPrcFlag1bit2)
      m_pSegment99->cEXCHG_MASTER = 'I';
   else
      m_pSegment99->cEXCHG_MASTER = ' ';
   if (p->bPrcFlag3bit7)
      m_pSegment99->cAP_FLG = ntohs(p->siAltRouteToAP > 0) ? 'Y' : 'N';
   else
      m_pSegment99->cAP_FLG = ntohs(p->siRouteToAP) > 0 ? 'Y' : 'N';
   m_bAuthByAltRoute = (p->bPrcFlag3bit7) ? true : false;
   short m = 0;
   if (p->bPrcFlag0bit10)
      m += 4;
   if (p->bPrcFlag0bit11)
      m += 2;
   if (p->bPrcFlag0bit12)
      m += 1;
   if (m == 4 || m == 5)
      m_pSegment99->cEXCHG_SETL = 'A';
   else
   if (m == 1)
      m_pSegment99->cEXCHG_SETL = 'N';
   else
      m_pSegment99->cEXCHG_SETL = 'I';
   if (m_pSegment99->cEXCHG_SETL == 'I' && p->bSeg14)
      ;
   else
   if (m_pSegment99->cEXCHG_SETL == 'A' && p->bSeg13)
      ;
   else
   if ((m_pSegment99->cEXCHG_SETL == 'I'
      || m_pSegment99->cEXCHG_SETL == 'A')
      && memcmp(p->sNetworkIdAcqr,"MCI",3) == 0
      && p->sFuncCode[0] != '1')
   {
      memcpy(m_pSegment99->sCUR_RECON_NET,p->sCurrTran,3);
      m_pSegment99->dAMT_RECON_NET1 = Segment::lltof(ntohl(p->lAmtTran[0]),ntohl(p->lAmtTran[1]));
   }
   else
   {
      double dAmtTran = Segment::lltof(ntohl(p->lAmtTran[0]),ntohl(p->lAmtTran[1]));
      m_pSegment99->dAMT_RECON_NET1 = convertAmt(dAmtTran,p->cConvReconNetworkDecPos,m_sNetworkRate);
      if (m_pSegment99->dAMT_RECON_NET1 == dAmtTran)
         memcpy(m_pSegment99->sCUR_RECON_NET,p->sCurrTran,3);
   }
   char sDateTime0[17] = {"                "};
   char sDateTime1[17] = {"                "};
   char sDateTime2[17] = {"                "};
   char sDateTime3[17] = {"                "};
   char sDateTime4[17] = {"                "};
   char sDateTime6[17] = {"                "};
   char sDateTime9[17] = {"                "};
   char sDateTime10[17] = {"                "};
   char sAllZerosDateTime[17] = {"0000000000000000"};
   memcpy(sDateTime0,NonStopClock::getYYYYMMDDHHMMSShh(p->sMilestone0).data(),16);
   memcpy(sDateTime1,NonStopClock::getYYYYMMDDHHMMSShh(p->sMilestone1).data(),16);
   memcpy(sDateTime2,NonStopClock::getYYYYMMDDHHMMSShh(p->sMilestone2).data(),16);
   memcpy(sDateTime3,NonStopClock::getYYYYMMDDHHMMSShh(p->sMilestone3).data(),16);
   memcpy(sDateTime4,NonStopClock::getYYYYMMDDHHMMSShh(p->sMilestone4).data(),16);
   memcpy(sDateTime6,NonStopClock::getYYYYMMDDHHMMSShh(p->sMilestone6).data(),16);
   memcpy(sDateTime9,NonStopClock::getYYYYMMDDHHMMSShh(p->sMilestone9).data(),16);
   memcpy(sDateTime10,NonStopClock::getYYYYMMDDHHMMSShh(p->sMilestone10).data(),16);
   if (!memcmp(sDateTime6,sAllZerosDateTime,16))
      memcpy(sDateTime6,sDateTime1,16);
   if (!memcmp(sDateTime4,sAllZerosDateTime,16))
      memcpy(sDateTime4,sDateTime3,16);
   if ((atof(sDateTime6)) < (atof(sDateTime0)))
      memcpy(sDateTime6,sDateTime0,16);
   if ((atof(sDateTime4)) < (atof(sDateTime2)))
     memcpy(sDateTime4,sDateTime2,16);
   if (!memcmp(sDateTime9,sAllZerosDateTime,16)
      || !memcmp(sDateTime10,sAllZerosDateTime,16))
      m_pSegment99->sTIME_AT_AP = 0;
   else
   {
      DateTime hDateTime9;
      DateTime hDateTime10;
      hDateTime9.setDateTime(sDateTime9);
      hDateTime10.setDateTime(sDateTime10);
      m_pSegment99->sTIME_AT_AP = htons((short)hDateTime10.calcQueueTime(hDateTime9));
   }
   if (!memcmp(sDateTime2,sAllZerosDateTime,16)
      || !memcmp(sDateTime1,sAllZerosDateTime,16))
   {
      m_pSegment99->sTIME_AT_ISS = 0;
   }
   else
   {
      DateTime hDateTime1;
      DateTime hDateTime2;
      hDateTime1.setDateTime(sDateTime1);
      hDateTime2.setDateTime(sDateTime2);
      m_pSegment99->sTIME_AT_ISS = htons((short)hDateTime2.calcQueueTime(hDateTime1));
   }
   if (!memcmp(sDateTime1,sAllZerosDateTime,16)
      || !memcmp(sDateTime6,sAllZerosDateTime,16))
   {
      m_pSegment99->sTIME_AT_RESP_QUE = 0;
   }
   else
   {
      DateTime hDateTime6;
      DateTime hDateTime1;
      hDateTime6.setDateTime(sDateTime6);
      hDateTime1.setDateTime(sDateTime1);
      m_pSegment99->sTIME_AT_RESP_QUE = htons((short)hDateTime1.calcQueueTime(hDateTime6));
   }
   if (!memcmp(sDateTime2,sAllZerosDateTime,16)
      || !memcmp(sDateTime4,sAllZerosDateTime,16))
   {
      m_pSegment99->sTIME_AT_RESP_SWTCH = 0;
   }
   else
   {
      DateTime hDateTime2;
      DateTime hDateTime4;
      hDateTime2.setDateTime(sDateTime2);
      hDateTime4.setDateTime(sDateTime4);
      m_pSegment99->sTIME_AT_RESP_SWTCH = htons((short)hDateTime4.calcQueueTime(hDateTime2));
   }
   if (!memcmp(sDateTime3,sAllZerosDateTime,16)
      || !memcmp(sDateTime4,sAllZerosDateTime,16))
   {
      m_pSegment99->sTIME_AT_RQST_QUE = 0;
   }
   else
   {
      DateTime hDateTime4;
      DateTime hDateTime3;
      hDateTime4.setDateTime(sDateTime4);
      hDateTime3.setDateTime(sDateTime3);
      m_pSegment99->sTIME_AT_RQST_QUE = htons((short)hDateTime3.calcQueueTime(hDateTime4));
   }
   if (!memcmp(sDateTime4,sAllZerosDateTime,16)
      || !memcmp(sDateTime0,sAllZerosDateTime,16))
   {
      m_pSegment99->sTIME_AT_RQST_SWTCH = 0;
   }
   else
   {
      DateTime hDateTime0;
      DateTime hDateTime4;
      hDateTime0.setDateTime(sDateTime0);
      hDateTime4.setDateTime(sDateTime4);
      m_pSegment99->sTIME_AT_RQST_SWTCH = htons((short)hDateTime4.calcQueueTime(hDateTime0));
   }
   // Segment 1 to USER OPTION table mappings
   if (m_bAuthByAltRoute)
      memcpy(p->sSponsorBankId,p->sAltSponsorBankId,11);
   memcpy(m_pSegment99->sProcFlag1,(char*)p->sCurrCardBill + 55,8);
   memcpy(m_pSegment99->sProcBillFlag1,(char*)p->sCurrCardBill + 63,8);
   m_pSegment99->cALT_ROUTE_FLG = (p->bPrcFlag3bit7) ? 'Y' : 'N';
   m_pSegment99->cDEPOSIT_ONLY_FLG = (p->bPrcFlag2bit0) ? 'Y' : 'N';
   m_pSegment99->cTRAN_FROM_ACCT_FLG = (p->bPrcFlag0bit9) ? 'Y' : 'N';
   m_pSegment99->cTRAN_TO_ACCT_FLG = (p->bPrcFlag0bit9) ? 'Y' : 'N';
   memcpy(m_pSegment99->sTSTAMP_REV_CREATED,(NonStopClock::getYYYYMMDDHHMMSShh(p->sMilestone5)).data(),16);
   if ((m_pSegment99->cEXCHG_SETL == 'I'
      && p->bSeg14)
      || (m_pSegment99->cEXCHG_SETL == 'A'
      && p->bSeg13))
   ;
   else
   {
      double dAmtTran = Segment::lltof(ntohl(p->lOrigAmtTran[0]),ntohl(p->lOrigAmtTran[1]));
      m_pSegment99->dO_AMT_RECON_NET = convertAmt(dAmtTran,p->cConvReconNetworkDecPos,m_sNetworkRate);
   }
   m_pSegment99->dAMT_RECON_NET2 = m_pSegment99->dAMT_RECON_NET1;
   //map Field 7 for ILK/Visa/Plus transactions
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += m_pTransaction->getTSTAMP_TRANS().substr(8);
      memcpy(m_pSegment99->sTSTAMP_LOCAL,strTemp.data(),14);
      string strCutOff(getTestDate());
      strCutOff += Customer::instance()->getCUTOFF_TIME();
      if(strTemp < strCutOff)
      {
         memcpy(m_pSegment99->sDATE_RECON_NET,getTestDate().data(),8);
         memcpy(m_pSegment99->sDATE_RECON_ACQ,getTestDate().data(),8);
         memcpy(m_pSegment99->sDATE_RECON_ISS,getTestDate().data(),8);
      }
      else
      {
         Date hDate(getTestDate().c_str());
         hDate += 1;
         strCutOff = hDate.asString("%Y%m%d");
         memcpy(m_pSegment99->sDATE_RECON_NET,strCutOff.data(),8);
         memcpy(m_pSegment99->sDATE_RECON_ACQ,strCutOff.data(),8);
         memcpy(m_pSegment99->sDATE_RECON_ISS,strCutOff.data(),8);
      }
   }
   memcpy(m_pSegment99->sTSTAMP_LOCAL_ADJ,m_pSegment99->sTSTAMP_LOCAL,4);
   memcpy(m_pSegment99->sTSTAMP_LOCAL_ADJ + 4,p->sDateTransRqstMMDD,4);
   memcpy(m_pSegment99->sTSTAMP_LOCAL_ADJ + 8,p->sTimeTransRqstHRMNSC,6);
   ::Template::instance()->map("SEGMENT1",(const char*)p) ;
  //## end Financial::mapSegment1%5A5140CA012F.body
}

void Financial::mapSegment2 (hFinancialSeg2* p)
{
  //## begin Financial::mapSegment2%5A5140CA0146.body preserve=yes
   translate(p->sControllerId,((char*)(&p->siStandinOpt) - p->sControllerId));
   translate(p->sStandinLimits,sizeof(p->sStandinLimits));
   translate(p->sOnlineFeeGrp,sizeof(p->sOnlineFeeGrp));
   translate(p->sSegmentLogOptAcqr,(&p->cFiller6 - p->sSegmentLogOptAcqr));
   if (memcmp(p->sDateActYYMMDD,"      ",6))
   {
      memcpy(m_pSegment99->sDATE_ACTION,"20",2);
      memcpy(m_pSegment99->sDATE_ACTION + 2,p->sDateActYYMMDD,6);
   }
   if (m_bTrack2)
   {
      if (p->cTrack32Ind == '2')
         memcpy(m_pSegment99->sTRACK_2_DATA,p->sTrack32Data,37);
      else
      {
         if (p->cTrack12Ind == '2')
            memcpy(m_pSegment99->sTRACK_2_DATA,p->sTrack12Data,37);
         else
         {
            if (p->cTrack12Ind == '1')
               memcpy(m_pSegment99->sTRACK_2_DATA,p->sTrack12Data,40);
         }
      }
   }
   ::Template::instance()->map("SEGMENT2",(const char*)p);
  //## end Financial::mapSegment2%5A5140CA0146.body
}

void Financial::mapSegment3 (hFinancialSeg3* p)
{
  //## begin Financial::mapSegment3%5A5140CA014F.body preserve=yes
   if (ntohs(p->siCnxDataFormatAcqr == 7))
   {
      ::Template::instance()->map("SEGMENT3LINK",(const char*)p);
      hFinancialSeg3Link* r = (hFinancialSeg3Link*)p;
      memset(r->sBitmap,' ',sizeof(r->sBitmap));
   }
   ::Template::instance()->map("SEGMENT3",(const char*)p);
  //## end Financial::mapSegment3%5A5140CA014F.body
}

void Financial::mapSegment4 (hFinancialSeg4* p)
{
  //## begin Financial::mapSegment4%5A5140CA0157.body preserve=yes
   ::Template::instance()->map("SEGMENT4",(const char*)p);
  //## end Financial::mapSegment4%5A5140CA0157.body
}

void Financial::mapSegment5 (hFinancialSeg5* p)
{
  //## begin Financial::mapSegment5%5A5140CA015F.body preserve=yes
   char sType[7] = {"012345"};
   string strToken("SEGMENT5DATA ");
   for (int i = 0;i <= 5;++i)
   {
      strToken[12] = sType[i];
      ::Template::instance()->map(strToken,(const char*)(&p->hEntry5[i]));
   }
  //## end Financial::mapSegment5%5A5140CA015F.body
}

void Financial::mapSegment6 (hFinancialSeg6* p)
{
  //## begin Financial::mapSegment6%5A5140CA0167.body preserve=yes
   ::Template::instance()->map("SEGMENT6",(const char*)p);
  //## end Financial::mapSegment6%5A5140CA0167.body
}

void Financial::mapSegment7 (hFinancialSeg7* p)
{
  //## begin Financial::mapSegment7%5A52A34D02AE.body preserve=yes
   ::Template::instance()->map("SEGMENT7",(const char*)p);
  //## end Financial::mapSegment7%5A52A34D02AE.body
}

void Financial::mapSegment8 (hFinancialSeg8* p, hFinancialSeg1* p1)
{
  //## begin Financial::mapSegment8%5A52A34E0217.body preserve=yes
   ::Template::instance()->map("SEGMENT8",(const char*)p);
   if (memcmp(p->sTranUniqDataFormat,"AV",2) == 0
      || memcmp(p->sTranUniqDataFormat,"AR",2) == 0
      || memcmp(p->sTranUniqDataFormat,"CV",2) == 0
      || memcmp(p->sTranUniqDataFormat,"CR",2) == 0)
   {
      if (p->sTranUniqDataInfo[31] != ' ')
         m_pSegment99->cCVV2_CVC2_RESULT = p->sTranUniqDataInfo[31];
      else
      if (p->sTranUniqDataInfo[30] != ' ')
         m_pSegment99->cCVV2_CVC2_RESULT = p->sTranUniqDataInfo[30];
      else
         m_pSegment99->cCVV2_CVC2_RESULT = ' ';
   }
   if ((memcmp(p->sTranUniqDataFormat,"AV",2) == 0
      || memcmp(p->sTranUniqDataFormat,"AR",2) == 0
      || memcmp(p->sTranUniqDataFormat,"CV",2) == 0
      || memcmp(p->sTranUniqDataFormat,"CR",2) == 0
      || memcmp(p->sTranUniqDataFormat,"VR",2) == 0)
      && p->sTranUniqDataInfo[38] != ' ')
      m_pSegment99->cCAVV_RESULT = p->sTranUniqDataInfo[38];
   if (p->sTranUniqDataInfo[43] != ' '
      || p->sTranUniqDataInfo[44] != ' ')
      m_pSegment99->cCVV_CVC_RESULT = 'N';
   else
   if (p1->bPrcFlag0bit5)
      m_pSegment99->cCVV_CVC_RESULT = 'F';
   else
   if (p1->bPrcFlag0bit2)
      m_pSegment99->cCVV_CVC_RESULT = 'P';
  //## end Financial::mapSegment8%5A52A34E0217.body
}

void Financial::mapSegment9 (hFinancialSeg9* p)
{
  //## begin Financial::mapSegment9%5A52A34F001A.body preserve=yes
   char sType[7] = {"012345"};
   string strToken("SEGMENT9DATA ");
   for (int i = 0;i <= 5;++i)
   {
      strToken[12] = sType[i];
      ::Template::instance()->map(strToken,(const char*)(&p->Seg9Sub[i]));
   }
  //## end Financial::mapSegment9%5A52A34F001A.body
}

void Financial::mapSegment10 (hFinancialSeg10* p)
{
  //## begin Financial::mapSegment10%5A52A34F016E.body preserve=yes
   char sType[9] = {"01234567"};
   string strToken("SEGMENT10  ");
   for (int i = 0;i <= 7;++i)
   {
      strToken[10] = sType[i];
      strToken[9] = 'A';
      ::Template::instance()->map(strToken,(const char*)&p->hA[i]);
      strToken[9] = 'B';
      ::Template::instance()->map(strToken,(const char*)&p->hB[i]);
      strToken[9] = 'C';
      ::Template::instance()->map(strToken,(const char*)&p->hC[i]);
   }
  //## end Financial::mapSegment10%5A52A34F016E.body
}

void Financial::mapSegment11 (hFinancialSeg11* p)
{
  //## begin Financial::mapSegment11%5A52A3700334.body preserve=yes
   translate(&p->cRefDataFormatAcqr,sizeof(hFinancialSeg11));
   if (p->cRefDataFormatAcqr == 'V')
      m_pSegment99->siREF_DATA_ACQ_FMT = htons(31);
   else
   {
      char szTemp[2] = {" "};
      szTemp[0] = p->cRefDataFormatAcqr;
      m_pSegment99->siREF_DATA_ACQ_FMT = htons((short)atoi(szTemp));
   }
   ::Template::instance()->map("SEGMENT11",(const char*)p);
  //## end Financial::mapSegment11%5A52A3700334.body
}

void Financial::mapSegment12 (hFinancialSeg12* p)
{
  //## begin Financial::mapSegment12%5A52A37203AC.body preserve=yes
   translate(&p->cRefDataFormatIssr,sizeof(hFinancialSeg12));
   char szTemp[2] = {" "};
   szTemp[0] = p->cRefDataFormatIssr;
   m_pSegment99->siREF_DATA_ISS_FMT = htons((short)atoi(szTemp));
   ::Template::instance()->map("SEGMENT12",(const char*)p);
  //## end Financial::mapSegment12%5A52A37203AC.body
}

void Financial::mapSegment13 (hFinancialSeg13* p)
{
  //## begin Financial::mapSegment13%5A52A37301B8.body preserve=yes
   repositorysegment::Transaction* t = repositorysegment::Transaction::instance();
   if (!p)
   {
      if (m_pSegment99->cTRAN_DISPOSITION1 != '2')
      {
         m_pSegment99->lAmtReconAcqr[0] = m_pSegment99->lAMT_TRAN[0];
         m_pSegment99->lAmtReconAcqr[1] = m_pSegment99->lAMT_TRAN[1];
         m_pSegment99->sCNV_RCN_ACQ_RATE[0] = '1';
         string strCUR_TRAN;
         t->get("FIN_RECORDYYYYMM","CUR_TRAN",strCUR_TRAN);
         memcpy(m_pSegment99->sCUR_RECON_ACQ,strCUR_TRAN.data(),strCUR_TRAN.length());
      }
      return;
   }
   m_pSegment99->lAmtReconAcqr[0] = p->lAmtReconAcqr[0];
   m_pSegment99->lAmtReconAcqr[1] = p->lAmtReconAcqr[1];
   memcpy(m_pSegment99->sCNV_RCN_ACQ_RATE,p->sReconAcqrRate,7);
   memcpy(m_pSegment99->sCUR_RECON_ACQ,p->sCurrReconAcqr,3);
   ::Template::instance()->map("SEGMENT13",(const char*)p);
   if (m_pSegment99->cEXCHG_SETL == 'A'
      || memcmp(m_pSegment99->sCUR_RECON_ACQ,m_pSegment99->sCUR_RECON_NET,3) == 0)
   {
      ::Template::instance()->map("SEGMENT13NET",(const char*)p);
      string strAMT_RECON_NET;
      t->get("FIN_RECORDYYYYMM","AMT_RECON_NET",strAMT_RECON_NET);
      if (!strAMT_RECON_NET.empty())
      {
         m_pSegment99->dAMT_RECON_NET1 = atof(strAMT_RECON_NET.c_str());
         m_pSegment99->dAMT_RECON_NET2 = m_pSegment99->dAMT_RECON_NET1;
      }
   }
  //## end Financial::mapSegment13%5A52A37301B8.body
}

void Financial::mapSegment14 (hFinancialSeg14* p)
{
  //## begin Financial::mapSegment14%5A52A3730351.body preserve=yes
   repositorysegment::Transaction* t = repositorysegment::Transaction::instance();
   if (!p)
   {
      if (m_pSegment99->cTRAN_DISPOSITION1 != '2')
      {
         m_pSegment99->lAmtReconIssr[0] = m_pSegment99->lAMT_TRAN[0];
         m_pSegment99->lAmtReconIssr[1] = m_pSegment99->lAMT_TRAN[1];
         m_pSegment99->sCNV_RCN_ISS_RATE[0] = '1';
         string strCUR_TRAN;
         t->get("FIN_RECORDYYYYMM","CUR_TRAN",strCUR_TRAN);
         memcpy(m_pSegment99->sCUR_RECON_ISS,strCUR_TRAN.data(),3);
      }
      return;
   }
   if (m_bAuthByAltRoute)
   {
      ::Template::instance()->map("SEGMENT14ALT",(const char*)p);
      if (m_pSegment99->cEXCHG_SETL == 'I'
         || memcmp(m_pSegment99->sCUR_RECON_ISS,m_pSegment99->sCUR_RECON_NET,3) == 0)
      {
         ::Template::instance()->map("SEGMENT14ALTNET",(const char*)p);
         ::Template::instance()->map("SEGMENT14ALTNETO",(const char*)p);
         string strAMT_RECON_NET;
         t->get("FIN_RECORDYYYYMM","AMT_RECON_NET",strAMT_RECON_NET);
         if (!strAMT_RECON_NET.empty())
         {
            m_pSegment99->dAMT_RECON_NET1 = atof(strAMT_RECON_NET.c_str());
            m_pSegment99->dAMT_RECON_NET2 = m_pSegment99->dAMT_RECON_NET1;
         }
      }
   }
   else
   {
      ::Template::instance()->map("SEGMENT14",(const char*)p);
      if (m_pSegment99->cEXCHG_SETL == 'I'
         || memcmp(m_pSegment99->sCUR_RECON_ISS,m_pSegment99->sCUR_RECON_NET,3) == 0)
      {
         ::Template::instance()->map("SEGMENT14NET",(const char*)p);
         ::Template::instance()->map("SEGMENT14NETO",(const char*)p);
         string strAMT_RECON_NET;
         t->get("FIN_RECORDYYYYMM","AMT_RECON_NET",strAMT_RECON_NET);
         if (!strAMT_RECON_NET.empty())
         {
            m_pSegment99->dAMT_RECON_NET1 = atof(strAMT_RECON_NET.c_str());
            m_pSegment99->dAMT_RECON_NET2 = m_pSegment99->dAMT_RECON_NET1;
         }
      }
   }
  //## end Financial::mapSegment14%5A52A3730351.body
}

void Financial::mapSegment15 (hFinancialSeg15* p)
{
  //## begin Financial::mapSegment15%5A52A37400FA.body preserve=yes
   ::Template::instance()->map("SEGMENT15",(const char*)p);
   memcpy(m_sTranDesc,p->sTranDesc,8);
  //## end Financial::mapSegment15%5A52A37400FA.body
}

void Financial::mapSegment16 (hFinancialSeg16* p)
{
  //## begin Financial::mapSegment16%5A52A374028A.body preserve=yes
   char sType[7] = {"123456"};
   string strToken1("SEGMENT16A ");
   string strToken2("SEGMENT16ANET ");
   if (m_pSegment99->cEXCHG_SETL == 'A')
      strToken2.replace(10,3,"ACQ",3);
   else
   if (m_pSegment99->cEXCHG_SETL == 'I')
      strToken2.replace(10,3,"ISS",3);
   for (int i = 0;i <= 5;++i)
   {
      strToken1[10] = sType[i];
      strToken2[13] = sType[i];
      strToken1[9] = 'A';
      ::Template::instance()->map(strToken1,(const char*)(&p->Seg16ASub[i]));
      strToken1[9] = 'B';
      ::Template::instance()->map(strToken1,(const char*)(&p->Seg16BSub[i]));
      if (m_pSegment99->cEXCHG_SETL == 'A')
      {
         strToken2[9] = 'A';
         ::Template::instance()->map(strToken2,(const char*)(&p->Seg16ASub[i]));
         strToken2[9] = 'B';
         ::Template::instance()->map(strToken2,(const char*)(&p->Seg16BSub[i]));
      }
      else
      if (m_pSegment99->cEXCHG_SETL == 'I')
      {
         strToken2[9] = 'A';
         ::Template::instance()->map(strToken2,(const char*)(&p->Seg16ASub[i]));
         strToken2[9] = 'B';
         ::Template::instance()->map(strToken2,(const char*)(&p->Seg16BSub[i]));
      }
      else
      {
         int lConvertedAmt = convertAmt((int)ntohl(p->Seg16ASub[i].lFeeAmt),m_cNetworkDecPos,m_sNetworkRate);
         p->Seg16ASub[i].lFeeAmt = htonl(lConvertedAmt);
         strToken2[9] = 'A';
         ::Template::instance()->map(strToken2,(const char*)(&p->Seg16ASub[i]));
         lConvertedAmt = convertAmt((int)ntohl(p->Seg16BSub[i].lFeeOrigAmt),m_cNetworkDecPos,m_sNetworkRate);
         p->Seg16BSub[i].lFeeOrigAmt = htonl(lConvertedAmt);
         strToken2[9] = 'B';
         ::Template::instance()->map(strToken2,(const char*)(&p->Seg16BSub[i]));
      }
   }
  //## end Financial::mapSegment16%5A52A374028A.body
}

void Financial::mapSegment17 (hFinancialSeg17* p)
{
  //## begin Financial::mapSegment17%5A52A3750031.body preserve=yes
   ::Template::instance()->map("SEGMENT17",(const char*)p);
  //## end Financial::mapSegment17%5A52A3750031.body
}

void Financial::mapSegment18 (hFinancialSeg18* p)
{
  //## begin Financial::mapSegment18%5A52A37501CB.body preserve=yes
   if (m_bReversal)
      m_cClass = p->sOdeMTI[1];
   reformatInstId(p->sOdeInstIdAcqr);
   memcpy(p->sOdeInstIdAcqr,m_sStdInstId,11);
   memcpy(m_pSegment99->sODE_TSTAMP_LOCL_TR,"20",2);
   memcpy(m_pSegment99->sODE_TSTAMP_LOCL_TR + 2,p->sOdeDateLocYYMMDD,6);
   memcpy(m_pSegment99->sODE_TSTAMP_LOCL_TR + 8,p->sOdeTimeLocHRMNSC,6);
   ::Template::instance()->map("SEGMENT18",(const char*)p);
  //## end Financial::mapSegment18%5A52A37501CB.body
}

void Financial::mapSegment19 (hFinancialSeg19* p)
{
  //## begin Financial::mapSegment19%5A52A3750359.body preserve=yes
   ::Template::instance()->map("SEGMENT19",(const char*)p);
   // !!! link DATA_PRIV_ACQ
  //## end Financial::mapSegment19%5A52A3750359.body
}

void Financial::mapSegment20 (hFinancialSeg20* p)
{
  //## begin Financial::mapSegment20%5A52A37600E5.body preserve=yes
   translate(p->sAdtlDataNatl,sizeof(hFinancialSeg20));
   if (memcmp(p->sAdtlDataNatl,"*3D*\\",5) == 0)
   {
      m_pSegment99->cMCI_AAV_RESULT_COD = m_pSegment99->cCAVV_RESULT;
      short siSkip = 9;
      char szTemp[3] = {"  "};
      if (memcmp(p->sAdtlDataNatl + siSkip,"SL",2) == 0)
      {
         siSkip += 2;
         memcpy(szTemp,p->sAdtlDataNatl + siSkip,2);
         siSkip += 2;
         memcpy(m_pSegment99->sMCI_ECS_LVL_IND,p->sAdtlDataNatl + siSkip,min(size_t(3),size_t(atoi(szTemp))));
         siSkip += atoi(szTemp);
      }
      if (memcmp(p->sAdtlDataNatl + siSkip,"CA",2) == 0)
      {
         siSkip += 4;
         if ((memcmp(p->sAdtlDataNatl + siSkip,"M3",2) == 0)
            || (memcmp(p->sAdtlDataNatl + siSkip,"M4",2) == 0))
         {
            memcpy(szTemp,p->sAdtlDataNatl + siSkip - 2,2);
            memcpy(m_pSegment99->sMCI_UCAF_DATA,p->sAdtlDataNatl + siSkip + 2,min(size_t(32),size_t(atoi(szTemp) - 2)));
         }
      }
      return;
   }
   string strDATA_PRIV_ACQ_FMT;
   m_pTransaction->get("FIN_RECORDYYYYMM","DATA_PRIV_ACQ_FMT",strDATA_PRIV_ACQ_FMT);
   if (strDATA_PRIV_ACQ_FMT == "30")
      ::Template::instance()->map("SEGMENT20",(const char*)p);
  //## end Financial::mapSegment20%5A52A37600E5.body
}

void Financial::mapSegment21 (hFinancialSeg21* p)
{
  //## begin Financial::mapSegment21%5A52A3C301A3.body preserve=yes
   translate(p->sAdtlDataPrivAcqr,sizeof(hFinancialSeg21));
   if (memcmp(p->sAdtlDataPrivAcqr,"MI",2) == 0
      || AdvantageMessageProcessor::instance()->getMessageCode() == "0401"
      || memcmp(p->sAdtlDataPrivAcqr,"PL",2) == 0
      || memcmp(p->sAdtlDataPrivAcqr,"IC",2) == 0)
   {
      // !!! string strADL_DATA_PRIV_ACQ(p->sAdtlDataPrivAcqr,255);
      // !!! size_t n = strADL_DATA_PRIV_ACQ.find_last_not_of(' ');
      // !!! if (n != string::npos)
      // !!!    m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ(strADL_DATA_PRIV_ACQ.data(),n + 1);
      if (memcmp(p->sAdtlDataPrivAcqr,"IC",2) == 0)
      {
         ::Template::instance()->map("SEGMENT21LINK",(const char*)p);
         /*
         link::segADL_DATA_PRIV_ACQ *r = (struct link::segADL_DATA_PRIV_ACQ*)strADL_DATA_PRIV_ACQ.data();
         m_pIntegratedCircuitCardSegment->setPresence(true);
         string strTemp;
         CodeTable::nibbleToByte(r->sTERM_CAPABILITIES,sizeof(r->sTERM_CAPABILITIES),strTemp);
         m_pIntegratedCircuitCardSegment->setTERM_CAPABILITIES(strTemp.data(),strTemp.length());
         CodeTable::nibbleToByte(r->sTERM_VERIFY_RESULT,sizeof(r->sTERM_VERIFY_RESULT),strTemp);
         m_pIntegratedCircuitCardSegment->setTERM_VERIFY_RESULT(strTemp.data(),strTemp.length());
         CodeTable::nibbleToByte(r->sUNPREDICTABLE_NO,sizeof(r->sUNPREDICTABLE_NO),strTemp);
         m_pIntegratedCircuitCardSegment->setUNPREDICTABLE_NO(strTemp.data(),strTemp.length());
         m_pIntegratedCircuitCardSegment->setTERM_SERIAL_NO(r->sTERM_SERIAL_NO,sizeof(r->sTERM_SERIAL_NO));
         CodeTable::nibbleToByte(r->sISS_APPL_DATA,sizeof(r->sISS_APPL_DATA),strTemp);
         m_pIntegratedCircuitCardSegment->setISS_APPL_DATA(strTemp.data(),((int)((unsigned char)r->sAcq_Icc_Map[4])));
         CodeTable::nibbleToByte(r->sAPPL_CRYPTOGRAM,sizeof(r->sAPPL_CRYPTOGRAM),strTemp);
         m_pIntegratedCircuitCardSegment->setAPPL_CRYPTOGRAM(strTemp.data(),strTemp.length());
         CodeTable::nibbleToByte(r->sAPPL_TRAN_COUNTER,sizeof(r->sAPPL_TRAN_COUNTER),strTemp);
         m_pIntegratedCircuitCardSegment->setAPPL_TRAN_COUNTER(strTemp.data(),strTemp.length());
         CodeTable::nibbleToByte(r->sAPPL_INTRCHG_PROF,sizeof(r->sAPPL_INTRCHG_PROF),strTemp);
         m_pIntegratedCircuitCardSegment->setAPPL_INTRCHG_PROF(strTemp.data(),strTemp.length());
         m_pIntegratedCircuitCardSegment->setISS_AUTH_DATA(r->sISS_AUTH_DATA,sizeof(r->sISS_AUTH_DATA));
         CodeTable::nibbleToByte(&r->sTRAN_TYPE,sizeof(r->sTRAN_TYPE),strTemp);
         m_pIntegratedCircuitCardSegment->setTRAN_TYPE(strTemp.data(),strTemp.length());
         CodeTable::nibbleToByte(r->sTERM_COUNTRY_CODE,sizeof(r->sTERM_COUNTRY_CODE),strTemp);
         m_pIntegratedCircuitCardSegment->setTERM_COUNTRY_CODE(strTemp.data() + 1,3);
         CodeTable::nibbleToByte(r->sTRAN_DATE,sizeof(r->sTRAN_DATE),strTemp);
         m_pIntegratedCircuitCardSegment->setTRAN_DATE(strTemp.data(),strTemp.length());
         CodeTable::nibbleToByte(r->sCRYPTOGRAM_AMOUNT,sizeof(r->sCRYPTOGRAM_AMOUNT),strTemp);
         m_pIntegratedCircuitCardSegment->setCRYPTOGRAM_AMOUNT(strTemp.data(),strTemp.length());
         CodeTable::nibbleToByte(r->sTRAN_CURRENCY_CODE,sizeof(r->sTRAN_CURRENCY_CODE),strTemp);
         m_pIntegratedCircuitCardSegment->setTRAN_CURRENCY_CODE(strTemp.data() + 1,3);
         if (*m_pFinancialBaseSegment->zTRAN_DISPOSITION() != '3')
         {
            CodeTable::nibbleToByte(r->sAMOUNT_OTHER,sizeof(r->sAMOUNT_OTHER),strTemp);
            if (strTemp != "202020202020")
               m_pIntegratedCircuitCardSegment->setAMOUNT_OTHER(strTemp.data(),strTemp.length());
         }
         CodeTable::nibbleToByte(&r->sCRYPT_INFO_DATA,sizeof(r->sCRYPT_INFO_DATA),strTemp);
         m_pIntegratedCircuitCardSegment->setCRYPT_INFO_DATA(strTemp.data(),strTemp.length());
         m_pIntegratedCircuitCardSegment->setTERMINAL_TYPE(&r->sTERMINAL_TYPE,1);
         m_pIntegratedCircuitCardSegment->setDEDICATED_FILE_NAM(r->sDEDICATED_FILE_NAM,sizeof(r->sDEDICATED_FILE_NAM));
         if (memcmp(r->sAPPL_VERSION_NO,"  ",2))
         {
            CodeTable::nibbleToByte(r->sAPPL_VERSION_NO,sizeof(r->sAPPL_VERSION_NO),strTemp);
            if (strTemp != "2020")
               m_pIntegratedCircuitCardSegment->setAPPL_VERSION_NO(strTemp.data(),strTemp.length());
         }
         CodeTable::nibbleToByte(r->sTRAN_SEQ_COUNTER,sizeof(r->sTRAN_SEQ_COUNTER),strTemp);
         if (strTemp != "20202020")
            m_pIntegratedCircuitCardSegment->setTRAN_SEQ_COUNTER(strTemp.data(),strTemp.length());
         m_pIntegratedCircuitCardSegment->setTRAN_CATEGORY_CODE(&r->cTRAN_CATEGORY_CODE,1);
         */
      }
   }
   else
   if (memcmp(p->sAdtlDataPrivAcqr,"MC",2) == 0)
   {
      // keep in sync with ADL_DATA_PRIV_ACQ in CXODRS63.hpp
      int nVarPos = 13;
      char sFixedFmt[255];
      int nFixedPos = 13;
      // pos 1: Merchant Advice (2)
      // pos 2: Fraud Data (9) = POS Entry Mode (3) - DE22
      //                         Response Code (2) - DE39
      //                         POS Data S1,S4,S11 (3) - DE61.1,61.4,61.11
      //                         POS Data S10 (1) - DE61.10
      // pos 3: Advice Detail Reason Code(4) - DE60.2
      // pos 4: Tag88(1)       -  DE48 Tag 88
      // pos 5: Tag89(1)       -  DE48 Tag 89
      // pos 6: Merchant Postal Code(10) - DE61 s14
      // pos 7: Card Presence (1) - DE61 s5
      short siMCFieldLen1[32] = {2,9,4,1,1,10,1,3,6,1,3,1,7,10,1,30,1,2,1,1,2,1,2,2,3,1,2,2,1,4,11,8};
      int nFieldNum = 0;
      char sBitMap[8];
      memcpy(sBitMap,p->sAdtlDataPrivAcqr + 5,8);
      memset(sFixedFmt,' ',255);
      memcpy(sFixedFmt,"MC118FFFFFFC0",13);
      char psBits[4];
      for (int i = 0; i < 8; i++)
      {
         convertBitMap(sBitMap[i],psBits);
         for (int j = 0;j <= 3;++j)   // four fields per byte
         {
               if (psBits[j] == '1')      //field is present
               {
                  if (!((i==7) && (j==3)))
                     memcpy(sFixedFmt+nFixedPos,p->sAdtlDataPrivAcqr+nVarPos,siMCFieldLen1[nFieldNum]);
                  nVarPos += siMCFieldLen1[nFieldNum];
               }
               nFixedPos += siMCFieldLen1[nFieldNum];
               ++nFieldNum;
         }
      }
      nFieldNum = 0;
      memcpy(sBitMap,p->sAdtlDataPrivAcqr+nVarPos-8,8);
      short siMCFieldLen2[12] = {11,15,1,3,2,1,3,2,2,0,0,0};
      for (int i = 0; i < 3; i++)
      {
         convertBitMap(sBitMap[i],psBits);
         for (int j = 0;j <= 3;++j)   // four fields per byte
         {
               if (psBits[j] == '1')      //field is present
               {
                  memcpy(sFixedFmt+nFixedPos-8,p->sAdtlDataPrivAcqr+nVarPos,siMCFieldLen2[nFieldNum]);
                  nVarPos += siMCFieldLen2[nFieldNum];
               }
               nFixedPos += siMCFieldLen2[nFieldNum];
               ++nFieldNum;
         }
      }
      // !!! string strTemp(sFixedFmt,nFixedPos);
      // !!! size_t n = strTemp.find_last_not_of(' ');
      // !!! if (n != string::npos)
      // !!!    m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ(strTemp.data(),n+1);
      memcpy(p->sAdtlDataPrivAcqr,sFixedFmt,255);
   }
   else
   if (memcmp(p->sAdtlDataPrivAcqr,"VD",2) == 0)
   {
      char sFixedFmt[255];
      memset(sFixedFmt,' ',255);
      int nVarPos = 0;
      struct visasms::segADL_DATA_PRIV_ACQ* pADL_DATA_PRIV_ACQ = (struct visasms::segADL_DATA_PRIV_ACQ*)sFixedFmt;
      memcpy(pADL_DATA_PRIV_ACQ->sData_Identifier,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Len,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sData_Len));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Len);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Byte_Map,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map);
      unsigned int lBitMap = 0;
      sscanf(pADL_DATA_PRIV_ACQ->sData_Byte_Map,"%08x",&lBitMap);
      if (lBitMap & 0x80000000)
      {  //01. char cAUTH_CHAR_FLAG; //     13    1   62.1
         memcpy(&pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG);
      }
      if (lBitMap & 0x40000000)
      {  //02. char cMARKET_FLAG; //     14    2   62.4
         memcpy(&pADL_DATA_PRIV_ACQ->cMARKET_FLAG,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cMARKET_FLAG));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cMARKET_FLAG);
      }
      if (lBitMap & 0x20000000)
      {  //03. char sDURATION[2]; //     15    3   62.5
         memcpy(pADL_DATA_PRIV_ACQ->sDURATION,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sDURATION));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sDURATION);
      }
      if (lBitMap & 0x10000000)
      {  //04. char cPRESTIGE_PROP_IND; //     17    4   62.6
         memcpy(&pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND);
      }
      if (lBitMap & 0x08000000)
      {  //05.   char cPRCH_ID_FRMT_FLG; //     18    5   62.7
         //      char sPURCHASE_IND[25]; //     19
         memcpy(&pADL_DATA_PRIV_ACQ->cPRCH_ID_FRMT_FLG,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cPRCH_ID_FRMT_FLG) + sizeof(pADL_DATA_PRIV_ACQ->sPURCHASE_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cPRCH_ID_FRMT_FLG) + sizeof(pADL_DATA_PRIV_ACQ->sPURCHASE_IND);
      }
      if (lBitMap & 0x04000000)
      {  //06. char sEventDate[6]; //     44    6   62.8
         memcpy(pADL_DATA_PRIV_ACQ->sEventDate,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sEventDate));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sEventDate);
      }
      if (lBitMap & 0x02000000)
      {  //07. char cNo_Show_Ind; //     50    7   62.9
         memcpy(&pADL_DATA_PRIV_ACQ->cNo_Show_Ind,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cNo_Show_Ind));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cNo_Show_Ind);
      }
      if (lBitMap & 0x01000000)
      {  //08. char sEXTRA_CHARGES_IND[6]; //     51    8  62.10
         memcpy(pADL_DATA_PRIV_ACQ->sEXTRA_CHARGES_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sEXTRA_CHARGES_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sEXTRA_CHARGES_IND);
      }
      if (lBitMap & 0x00800000)
      {  //09. char cRestr_Ticket_Ind; //     57    9  62.13
         memcpy(&pADL_DATA_PRIV_ACQ->cRestr_Ticket_Ind,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cRestr_Ticket_Ind));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cRestr_Ticket_Ind);
      }
      if (lBitMap & 0x00400000)
      {  //10. char cREQ_PAYM_SERV_IND; //     58   10  62.15
         memcpy(&pADL_DATA_PRIV_ACQ->cREQ_PAYM_SERV_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cREQ_PAYM_SERV_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cREQ_PAYM_SERV_IND);
      }
      if (lBitMap & 0x00200000)
      {  //11. char sCHB_RIGHTS_IND[2]; //     59   11  62.16
         memcpy(pADL_DATA_PRIV_ACQ->sCHB_RIGHTS_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sCHB_RIGHTS_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sCHB_RIGHTS_IND);
      }
      if (lBitMap & 0x00100000)
      {  //12. char sECOM_GOODS_IND[2]; //     61   12  62.19
         memcpy(pADL_DATA_PRIV_ACQ->sECOM_GOODS_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sECOM_GOODS_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sECOM_GOODS_IND);
      }
      if (lBitMap & 0x00080000)
      {  //13. char sMERCH_VERIFY_VALUE[10]; //     63   13  62.20
         memcpy(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE);
      }
      if (lBitMap & 0x00040000)
      {  //14. char cCAVV_RESULT; //     73   14  44.13
         memcpy(&pADL_DATA_PRIV_ACQ->cCAVV_RESULT,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cCAVV_RESULT));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cCAVV_RESULT);
      }
      if (lBitMap & 0x00020000)
      {  //15. char sRisk_Score[4]; //     74   15  62.21
         memcpy(pADL_DATA_PRIV_ACQ->sRisk_Score,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sRisk_Score));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sRisk_Score);
      }
      if (lBitMap & 0x00010000)
      {  //16. char sRisk_Condition_Code[6]; //     78   16  62.22
         memcpy(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code);
      }
      if (lBitMap & 0x00008000)
      {  //17. char sProcess_CODE[6]; //     84   17      3
         memcpy(pADL_DATA_PRIV_ACQ->sProcess_CODE,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sProcess_CODE));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sProcess_CODE);
      }
      if (lBitMap & 0x00004000)
      {  //18. char cTERM_TYPE_IND; //     90   18   60.1
         memcpy(&pADL_DATA_PRIV_ACQ->cTERM_TYPE_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cTERM_TYPE_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cTERM_TYPE_IND);
      }
      if (lBitMap & 0x00002000)
      {  //19. char sMOTO_IND[2]; //     91   19   60.8
         memcpy(pADL_DATA_PRIV_ACQ->sMOTO_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sMOTO_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sMOTO_IND);
      }
      if (lBitMap & 0x00001000)
      {  //20. char cEXCLD_TRAN_ID; //     93   20  62.18
         memcpy(&pADL_DATA_PRIV_ACQ->cEXCLD_TRAN_ID,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cEXCLD_TRAN_ID));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cEXCLD_TRAN_ID);
      }
      if (lBitMap & 0x00000800)
      {  //21. char sSTIP_SW_RESN_CODE[4]; //     94   21   63.4
         memcpy(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE);
      }
      if (lBitMap & 0x00000400)
      {  //22. char cVisaChargeIndicator; //     98   22  63.21
         memcpy(&pADL_DATA_PRIV_ACQ->cVisaChargeIndicator,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cVisaChargeIndicator));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cVisaChargeIndicator);
      }
      if (lBitMap & 0x00000200)
      {  //23. char sLatinISA[15]; //     99   23     46
         memcpy(pADL_DATA_PRIV_ACQ->sLatinISA,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sLatinISA));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sLatinISA);
      }
      if (lBitMap & 0x00000100)
      {  //24. char sPRODUCT_ID[2]; //    114   24  62.23
         memcpy(pADL_DATA_PRIV_ACQ->sPRODUCT_ID,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sPRODUCT_ID));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sPRODUCT_ID);
      }
      if (lBitMap & 0x00000080)
      {  //25. char cCardholderIDMethod;        //    116   25  60.93
         //    char sMISReasonCode[4];          //    117   25  63.3
         //    char cRecurringPaymentIndicator; //    121   25  126.13
         memcpy(&pADL_DATA_PRIV_ACQ->cCardholderIDMethod,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cCardholderIDMethod) );
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cCardholderIDMethod) ;

         memcpy(pADL_DATA_PRIV_ACQ->sMISReasonCode,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sMISReasonCode) );
         nVarPos+= sizeof(pADL_DATA_PRIV_ACQ->sMISReasonCode);

         memcpy(&pADL_DATA_PRIV_ACQ->cRecurringPaymentIndicator,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cRecurringPaymentIndicator) );
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cRecurringPaymentIndicator) ;
      }
      if (lBitMap & 0x00000040)
      {  //26. char sServiceIndicators[6]; //    122   26  126.12
         memcpy(pADL_DATA_PRIV_ACQ->sServiceIndicators,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sServiceIndicators));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sServiceIndicators);
      }
      if (lBitMap & 0x00000020)
      {  //27. char sResponseCode[2]; //    128   27  39
         memcpy(pADL_DATA_PRIV_ACQ->sResponseCode,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sResponseCode));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sResponseCode);
      }
      if (lBitMap & 0x00000010)
      {  //28. char cPaymentType; //    130   28  104(57)
         memcpy(&pADL_DATA_PRIV_ACQ->cPaymentType,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cPaymentType));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cPaymentType);
      }
      if (lBitMap & 0x00000008)
      {  //29. char sAirlineFields[38]; //    131   29  48,Usage 4
         memcpy(pADL_DATA_PRIV_ACQ->sAirlineFields,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sAirlineFields));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sAirlineFields);
      }
      if (lBitMap & 0x00000004)
      {  //30. char sBusinessApplicationID[2]; //    169   30  104,Usage 2
         memcpy(pADL_DATA_PRIV_ACQ->sBusinessApplicationID,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sBusinessApplicationID));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sBusinessApplicationID);
      }
      if (lBitMap & 0x00000002)
      {  //31. char cVisaAVSResult; //    171   31  44.2
         memcpy(&pADL_DATA_PRIV_ACQ->cVisaAVSResult,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cVisaAVSResult));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cVisaAVSResult);
      }
      if (lBitMap & 0x00000001)
      {  //32. 2nd bitmap
         memcpy(pADL_DATA_PRIV_ACQ->sData_Byte_Map2,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map2));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map2);
         sscanf(pADL_DATA_PRIV_ACQ->sData_Byte_Map2,"%08x",&lBitMap);
      }
      else
         lBitMap = 0;
      if (lBitMap & 0x80000000)
      {  //33. char cDCCInd; //    180   33  126.19
         memcpy(&pADL_DATA_PRIV_ACQ->cDCCInd,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cDCCInd));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cDCCInd);
      }
      if (lBitMap & 0x40000000)
      {  //34. char cSpendQualifiedIndicator; //    181   34  62.25
         memcpy(&pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator);
      }
      if (lBitMap & 0x20000000)
      {  //35. char sVisaMerchantIdentifier[8]; //   182 35 126.5
         memcpy(pADL_DATA_PRIV_ACQ->sVisaMerchantIdentifier,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sVisaMerchantIdentifier));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sVisaMerchantIdentifier);
      }
      if (lBitMap & 0x10000000)
      {  //35. char sAGENT_UNIQUE_ID[5];  //           190 36 126.18
         memcpy(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID);
      }
      if (lBitMap & 0x08000000)
      {  //36. char cAdlAuthInd;      //               195 37 60.10
         memcpy(&pADL_DATA_PRIV_ACQ->cAdlAuthInd,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cAdlAuthInd));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cAdlAuthInd);
      }
      // !!! int i = sizeof(struct visasms::segADL_DATA_PRIV_ACQ)-1;
      // !!! while( i >= 0 && ((char*)pADL_DATA_PRIV_ACQ)[i] == ' ')
      // !!!    i--;
      // !!! if (i >= 0)
      // !!!    m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ((char*)pADL_DATA_PRIV_ACQ,i+1);
      memcpy(p->sAdtlDataPrivAcqr,sFixedFmt,255);
      memcpy(m_pSegment99->sAPPLICATION_ID,pADL_DATA_PRIV_ACQ->sBusinessApplicationID,sizeof(pADL_DATA_PRIV_ACQ->sBusinessApplicationID));
   }
   else
   if (memcmp(p,"V2",2) == 0)
   {
      char sFixedFmt[255];
      memset(sFixedFmt,' ',255);
      int nVarPos = 0;
      struct visabaseii::segADL_DATA_PRIV_ACQ_BASEII* pADL_DATA_PRIV_ACQ = (struct visabaseii::segADL_DATA_PRIV_ACQ_BASEII*)sFixedFmt;
      memcpy(pADL_DATA_PRIV_ACQ->sData_Identifier,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Len,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sData_Len));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Len);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Byte_Map,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map);
      unsigned int lBitMap = 0;
      sscanf(pADL_DATA_PRIV_ACQ->sData_Byte_Map,"%08x",&lBitMap);
      if (lBitMap & 0x80000000)
      {  //01. char cAUTH_CHAR_FLAG; //     13    1   62.1
         memcpy(&pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG);
      }
      if (lBitMap & 0x40000000)
      {  //02. char cMARKET_FLAG; //     14    2   62.4
         memcpy(&pADL_DATA_PRIV_ACQ->cMARKET_FLAG,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cMARKET_FLAG));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cMARKET_FLAG);
      }
      if (lBitMap & 0x20000000)
      {  //03. char sDURATION[2]; //     15    3   62.5
         memcpy(pADL_DATA_PRIV_ACQ->sDURATION,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sDURATION));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sDURATION);
      }
      if (lBitMap & 0x10000000)
      {  //04. char cPRESTIGE_PROP_IND; //     17    4   62.6
         memcpy(&pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND);
      }
      if (lBitMap & 0x08000000)
      {  //05.   char cPRCH_ID_FRMT_FLG; //     18    5   62.7
         //      char sPURCHASE_IND[25]; //     19
         memcpy(&pADL_DATA_PRIV_ACQ->cPRCH_ID_FRMT_FLG,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cPRCH_ID_FRMT_FLG) + sizeof(pADL_DATA_PRIV_ACQ->sPURCHASE_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cPRCH_ID_FRMT_FLG) + sizeof(pADL_DATA_PRIV_ACQ->sPURCHASE_IND);
      }
      if (lBitMap & 0x04000000)
      {  //06. char sCheck_In_Out_Date[6]; //     44    6   62.8
         memcpy(pADL_DATA_PRIV_ACQ->sCheck_In_Out_Date,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sCheck_In_Out_Date));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sCheck_In_Out_Date);
      }
      if (lBitMap & 0x02000000)
      {  //07. char cNo_Show_Ind; //     50    7   62.9
         memcpy(&pADL_DATA_PRIV_ACQ->cNo_Show_Ind,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cNo_Show_Ind));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cNo_Show_Ind);
      }
      if (lBitMap & 0x01000000)
      {  //08. char sEXTRA_CHARGES_IND[6]; //     51    8  62.10
         memcpy(pADL_DATA_PRIV_ACQ->sEXTRA_CHARGES_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sEXTRA_CHARGES_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sEXTRA_CHARGES_IND);
      }
      if (lBitMap & 0x00800000)
      {  //09. char cRestr_Ticket_Ind; //     57    9  62.13
         memcpy(&pADL_DATA_PRIV_ACQ->cRestr_Ticket_Ind,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cRestr_Ticket_Ind));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cRestr_Ticket_Ind);
      }
      if (lBitMap & 0x00400000)
      {  //10. char cREQ_PAYM_SERV_IND; //     58   10  62.15
         memcpy(&pADL_DATA_PRIV_ACQ->cREQ_PAYM_SERV_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cREQ_PAYM_SERV_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cREQ_PAYM_SERV_IND);
      }
      if (lBitMap & 0x00200000)
      {  //11. char sCHB_RIGHTS_IND[2]; //     59   11  62.16
         memcpy(pADL_DATA_PRIV_ACQ->sCHB_RIGHTS_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sCHB_RIGHTS_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sCHB_RIGHTS_IND);
      }
      if (lBitMap & 0x00100000)
      {  //12. char sECOM_GOODS_IND[2]; //     61   12  62.19
         memcpy(pADL_DATA_PRIV_ACQ->sECOM_GOODS_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sECOM_GOODS_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sECOM_GOODS_IND);
      }
      if (lBitMap & 0x00080000)
      {  //13. char sMERCH_VERIFY_VALUE[10]; //     63   13  62.20
         memcpy(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE);
      }
      if (lBitMap & 0x00040000)
      {  //14. char cCAVV_RESULT; //     73   14  44.13
         memcpy(&pADL_DATA_PRIV_ACQ->cCAVV_RESULT,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cCAVV_RESULT));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cCAVV_RESULT);
      }
      if (lBitMap & 0x00020000)
      {  //15. char sRisk_Score[4]; //     74   15  62.21
         memcpy(pADL_DATA_PRIV_ACQ->sRisk_Score,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sRisk_Score));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sRisk_Score);
      }
      if (lBitMap & 0x00010000)
      {  //16. char sRisk_Condition_Code[6]; //     78   16  62.22
         memcpy(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code);
      }
      if (lBitMap & 0x00008000)
      {  //17. char sProcess_CODE[6]; //     84   17      3
         memcpy(pADL_DATA_PRIV_ACQ->sProcess_CODE,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sProcess_CODE));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sProcess_CODE);
      }
      if (lBitMap & 0x00004000)
      {  //18. char cTERM_TYPE_IND; //     90   18   60.1
         memcpy(&pADL_DATA_PRIV_ACQ->cTERM_TYPE_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cTERM_TYPE_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cTERM_TYPE_IND);
      }
      if (lBitMap & 0x00002000)
      {  //19. char sMOTO_IND[2]; //     91   19   60.8
         memcpy(pADL_DATA_PRIV_ACQ->sMOTO_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sMOTO_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sMOTO_IND);
      }
      if (lBitMap & 0x00001000)
      {  //20. char cEXCLD_TRAN_ID; //     93   20  62.18
         memcpy(&pADL_DATA_PRIV_ACQ->cEXCLD_TRAN_ID,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cEXCLD_TRAN_ID));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cEXCLD_TRAN_ID);
      }
      if (lBitMap & 0x00000800)
      {  //21. char sSTIP_SW_RESN_CODE[4]; //     94   21   63.4
         memcpy(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE);
      }
      if (lBitMap & 0x00000400)
      {  //22. char cVisaChargeIndicator; //     98   22  63.21
         memcpy(&pADL_DATA_PRIV_ACQ->cVisaChargeIndicator,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cVisaChargeIndicator));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cVisaChargeIndicator);
      }
      if (lBitMap & 0x00000200)
      {  //23. char sCardLevelResults[2]; //     99   23  62.23
         memcpy(pADL_DATA_PRIV_ACQ->sCardLevelResults,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sCardLevelResults));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sCardLevelResults);
      }
      if (lBitMap & 0x00000100)
      {  //24. char sBusinessApplicationID[2]; //     101  24  104
         memcpy(pADL_DATA_PRIV_ACQ->sBusinessApplicationID,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sBusinessApplicationID));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sBusinessApplicationID);
      }
      if (lBitMap & 0x00000080)
      {  //25. char cDCCInd; //     103  25  126.19
         memcpy(&pADL_DATA_PRIV_ACQ->cDCCInd,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cDCCInd));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cDCCInd);
      }
      if (lBitMap & 0x00000040)
      {  //26. char cFastFundsInd; //    104   26  TCR3
         memcpy(&pADL_DATA_PRIV_ACQ->cFastFundsInd,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cFastFundsInd));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cFastFundsInd);
      }
      if (lBitMap & 0x00000020)
      {  //27. char cSpendQualifiedIndicator; //    105   27  62.25
         memcpy(&pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator);
      }
      if (lBitMap & 0x00000010)
      {  //28. char sAGENT_UNIQUE_ID[5];  //          106 28 126.18
         memcpy(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID);
      }
      // !!! int i = sizeof(struct visabaseii::segADL_DATA_PRIV_ACQ_BASEII)-1;
      // !!! while( i >= 0 && ((char*)pADL_DATA_PRIV_ACQ)[i] == ' ')
      // !!!    i--;
      // !!! if (i >= 0)
      // !!!    m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ((char*)pADL_DATA_PRIV_ACQ,i+1);
      memcpy(p->sAdtlDataPrivAcqr,sFixedFmt,255);
   }
   else
   if (memcmp(p,"VE",2) == 0)
   {
      char sFixedFmt[255];
      memset(sFixedFmt,' ',255);
      int nVarPos = 0;
      struct visabaseii::segADL_DATA_PRIV_ACQ* pADL_DATA_PRIV_ACQ = (struct visabaseii::segADL_DATA_PRIV_ACQ*)sFixedFmt;
      memcpy(pADL_DATA_PRIV_ACQ->sData_Identifier,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Identifier);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Len,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sData_Len));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Len);
      memcpy(pADL_DATA_PRIV_ACQ->sData_Byte_Map,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map));
      nVarPos += sizeof(pADL_DATA_PRIV_ACQ->sData_Byte_Map);
      unsigned int lBitMap = 0;
      sscanf(pADL_DATA_PRIV_ACQ->sData_Byte_Map,"%08x",&lBitMap);
      if (lBitMap & 0x80000000)
      {  //01. char cAUTH_CHAR_FLAG; //     13    1   62.1
         memcpy(&pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cAUTH_CHAR_FLAG);
      }
      if (lBitMap & 0x40000000)
      {  //02. char cMARKET_FLAG; //     14    2   62.4
         memcpy(&pADL_DATA_PRIV_ACQ->cMARKET_FLAG,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cMARKET_FLAG));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cMARKET_FLAG);
      }
      if (lBitMap & 0x20000000)
      {  //03. char sDURATION[2]; //     15    3   62.5
         memcpy(pADL_DATA_PRIV_ACQ->sDURATION,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sDURATION));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sDURATION);
      }
      if (lBitMap & 0x10000000)
      {  //04. char cPRESTIGE_PROP_IND; //     17    4   62.6
         memcpy(&pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cPRESTIGE_PROP_IND);
      }
      if (lBitMap & 0x08000000)
      {  //05. char sMERCH_VERIFY_VALUE[10]; //     18    5  62.20
         memcpy(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sMERCH_VERIFY_VALUE);
      }
      if (lBitMap & 0x04000000)
      {  //06. char cCAVV_RESULT; //     28    6  44.13
         memcpy(&pADL_DATA_PRIV_ACQ->cCAVV_RESULT,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cCAVV_RESULT));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cCAVV_RESULT);
      }
      if (lBitMap & 0x02000000)
      {  //07. char sRisk_Score[4]; //     29    7  62.21
         memcpy(pADL_DATA_PRIV_ACQ->sRisk_Score,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sRisk_Score));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sRisk_Score);
      }
      if (lBitMap & 0x01000000)
      {  //08. char sRisk_Condition_Code[6]; //     33    8  62.22
         memcpy(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sRisk_Condition_Code);
      }
      if (lBitMap & 0x00800000)
      {  //09. char sPRODUCT_ID[2]; //     39    9  62.23
         memcpy(pADL_DATA_PRIV_ACQ->sPRODUCT_ID,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sPRODUCT_ID));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sPRODUCT_ID);
      }
      if (lBitMap & 0x00400000)
      {  //10. char sMSG_REASON_CODE[4]; //     41   10  63.3
         memcpy(pADL_DATA_PRIV_ACQ->sMSG_REASON_CODE,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sMSG_REASON_CODE));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sMSG_REASON_CODE);
      }
      if (lBitMap & 0x00200000)
      {  //11. char sSTIP_SW_RESN_CODE[4]; //     45   11  63.4
         memcpy(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sSTIP_SW_RESN_CODE);
      }
      if (lBitMap & 0x00100000)
      {  //12. char sResponseCode[2]; //     49   12  39
         memcpy(pADL_DATA_PRIV_ACQ->sResponseCode,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sResponseCode));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sResponseCode);
      }
      if (lBitMap & 0x00080000)
      {  //13. char sBusinessApplicationID[2]; //     51   13  104 usage 2 hex 57 Tag 01
         memcpy(pADL_DATA_PRIV_ACQ->sBusinessApplicationID,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sBusinessApplicationID));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sBusinessApplicationID);
      }
      if (lBitMap & 0x00040000)
      {  //14. char cVisaAVSResult; //     53   14  44.2
         memcpy(&pADL_DATA_PRIV_ACQ->cVisaAVSResult,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cVisaAVSResult));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cVisaAVSResult);
      }
      if (lBitMap & 0x00020000)
      {  //15. char cDCCInd; //     54   15  126.19
         memcpy(&pADL_DATA_PRIV_ACQ->cDCCInd,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cDCCInd));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cDCCInd);
	  }
	  if(lBitMap & 0x00010000)
      {  //16. char cCardholderIDMethod;    //     55   16  60.9
         memcpy(&pADL_DATA_PRIV_ACQ->cCardholderIDMethod,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cCardholderIDMethod));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cCardholderIDMethod);
      }
	  if(lBitMap & 0x00008000)
      {  //17. char cSpendQualifiedIndicator;    //     56   17  62.25
         memcpy(&pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cSpendQualifiedIndicator);
      }
     if(lBitMap & 0x00004000)
      {  //char sVisaMerchantIdentifier[8];    //     57 18 126.5
         memcpy(pADL_DATA_PRIV_ACQ->sVisaMerchantIdentifier,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sVisaMerchantIdentifier));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sVisaMerchantIdentifier);
      }

     if(lBitMap & 0x00002000)
      {  //char sServiceIndicators[6];         //    65 19 126.12
         memcpy(pADL_DATA_PRIV_ACQ->sServiceIndicators,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sServiceIndicators));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sServiceIndicators);
      }
     if(lBitMap & 0x00001000)
      {  //char sAGENT_UNIQUE_ID[5];             //    71 20 126.18
         memcpy(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->sAGENT_UNIQUE_ID);
      }
     if(lBitMap & 0x00000800)
      {  //17. char cPOSEnvironment;             //     76   21  126.13
         memcpy(&pADL_DATA_PRIV_ACQ->cPOSEnvironment,p->sAdtlDataPrivAcqr+nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cPOSEnvironment));
         nVarPos+=sizeof(pADL_DATA_PRIV_ACQ->cPOSEnvironment);
      }
      if(lBitMap & 0x00000400)
      {  //18. char cAdlAuthInd;               //       77  22  60.10
         memcpy(&pADL_DATA_PRIV_ACQ->cAdlAuthInd,p->sAdtlDataPrivAcqr + nVarPos,sizeof(pADL_DATA_PRIV_ACQ->cAdlAuthInd));
         nVarPos += sizeof(pADL_DATA_PRIV_ACQ->cAdlAuthInd);
      }
      // !!! int i = sizeof(struct visabaseii::segADL_DATA_PRIV_ACQ)-1;
      // !!! while( i >= 0 && ((char*)pADL_DATA_PRIV_ACQ)[i] == ' ')
      // !!!    i--;
      // !!! if (i >= 0)
      // !!!    m_pFinancialSettlementSegment->setADL_DATA_PRIV_ACQ((char*)pADL_DATA_PRIV_ACQ,i+1);
      memcpy(p->sAdtlDataPrivAcqr,sFixedFmt,255);
   }
   else
   if (memcmp(p->sAdtlDataPrivAcqr,"MD",2) == 0)
   {
      // pos 1: Merchant ID (6) bit 110 Master Card
      // pos 2: Cross-Border Flags (2)  bit 126 Master Card
      int nVarPos = 13;
      char sADL_DATA_PRIV_ACQ[255];
      memset(sADL_DATA_PRIV_ACQ,' ',255);
      int nFixedPos = 13;
      short siSubFieldLen1[32] = {6,2,1,2,1,1,1,1,1,1,2,3,6,1,1,1,2,2,2,1,11,15,3,2,2,1,1,4,11,11,15,8};
      int nFieldNum = 0;
      char sBitMap[8];
      memcpy(sBitMap,p->sAdtlDataPrivAcqr + 5,8);
      memset(sADL_DATA_PRIV_ACQ,' ',sizeof(sADL_DATA_PRIV_ACQ));
      memcpy(sADL_DATA_PRIV_ACQ,"MD078FFFFFFE00",13);
      char psBits[4];
      for (int i = 0; i<8; i++)
      {
         //convertBitMap(p->sAdtlDataPrivAcqr[5],psBits);
         convertBitMap(sBitMap[i],psBits);
         for (int j = 0;j <= 3;++j)   // four fields per byte
         {
            if (psBits[j] == '1')      //field is present
            {
               if (nFieldNum != 31) //don�t save the second bitmap
                  memcpy(sADL_DATA_PRIV_ACQ + nFixedPos,p->sAdtlDataPrivAcqr+nVarPos,siSubFieldLen1[nFieldNum]);
               nVarPos += siSubFieldLen1[nFieldNum];
               if (j==0 && i==0) // do only for 6 Bytes mertype
                  memcpy(m_pSegment99->sMERCH_TIER_ID,sADL_DATA_PRIV_ACQ+nFixedPos,siSubFieldLen1[nFieldNum]);
            }
            if (nFieldNum != 31)
               nFixedPos += siSubFieldLen1[nFieldNum++];
         }
      }
      nFieldNum = 0;
      memcpy(sBitMap,p->sAdtlDataPrivAcqr+nVarPos-8,8);
      short siSubFieldLen2[8] = {1,3,4,3,2,3,2,2};
      for (int i = 0; i < 2; i++)
      {
         convertBitMap(sBitMap[i],psBits);
         for (int j = 0;j <= 3;++j)   // four fields per byte
         {
            if (psBits[j] == '1')      //field is present
            {
               memcpy(sADL_DATA_PRIV_ACQ+nFixedPos,p->sAdtlDataPrivAcqr+nVarPos,siSubFieldLen2[nFieldNum]);
               nVarPos += siSubFieldLen2[nFieldNum];
            }
            nFixedPos += siSubFieldLen2[nFieldNum];
            ++nFieldNum;
         }
      }
      memcpy(p->sAdtlDataPrivAcqr,sADL_DATA_PRIV_ACQ,255);
   }
   else
   if (memcmp(p->sAdtlDataPrivAcqr,"AF",2) == 0)
   {
   // pos 1: Cross-Border Indicator Flag (1)
      int nVarPos = 13;
      char sADL_DATA_PRIV_ACQ[255];
      memset(sADL_DATA_PRIV_ACQ,' ',255);
      int nFixedPos = 13;
      short siSubFieldLen[8] = {1,0,0,0,0,0,0,0};
      int nFieldNum = 0;
      memset(sADL_DATA_PRIV_ACQ,' ',sizeof(sADL_DATA_PRIV_ACQ));
      memcpy(sADL_DATA_PRIV_ACQ,"AF00980000000",13);
      char psBits[4];
      convertBitMap(p->sAdtlDataPrivAcqr[5],psBits);
      for (int i = 0;i < 3;++i)   // four fields per byte
      {
         if (psBits[i] == '1')      //field is present
         {
            memcpy(sADL_DATA_PRIV_ACQ + nFixedPos,p->sAdtlDataPrivAcqr+nVarPos,siSubFieldLen[nFieldNum]);
            nVarPos += siSubFieldLen[nFieldNum];
         }
         nFixedPos += siSubFieldLen[nFieldNum];
         ++nFieldNum;
      }
      memcpy(p->sAdtlDataPrivAcqr,sADL_DATA_PRIV_ACQ,255);
   }
   else
   if (memcmp(p->sAdtlDataPrivAcqr,"ST",2) == 0)
   {
      int nVarPos = 13;
      char sADL_DATA_PRIV_ACQ[255];
      memset(sADL_DATA_PRIV_ACQ,' ',255);
      int nFixedPos = 13;
      short siSubFieldLen[16] = {2,1,10,1,1,1,2,15,1,23,3,15,3,0,0,0};
      int nFieldNum = 0;
      memset(sADL_DATA_PRIV_ACQ,' ',sizeof(sADL_DATA_PRIV_ACQ));
      memcpy(sADL_DATA_PRIV_ACQ,p->sAdtlDataPrivAcqr,2);
      memcpy(sADL_DATA_PRIV_ACQ + 2,p->sAdtlDataPrivAcqr+2,3);
      memcpy(sADL_DATA_PRIV_ACQ + 5,p->sAdtlDataPrivAcqr+5,8);
      char psBits[4];
      char sBitMap[8];
      memcpy(sBitMap,p->sAdtlDataPrivAcqr + 5,8);
      for (int i = 0; i < 4; i++)
      {
         convertBitMap(sBitMap[i],psBits);
         for (int j = 0; j <= 3; ++j)   // four fields per byte
         {
            if (psBits[j] == '1')      //field is present
            {
               memcpy(sADL_DATA_PRIV_ACQ + nFixedPos,p->sAdtlDataPrivAcqr + nVarPos,siSubFieldLen[nFieldNum]);
               nVarPos += siSubFieldLen[nFieldNum];
            }
            nFixedPos += siSubFieldLen[nFieldNum];
            ++nFieldNum;
         }
      }
      memcpy(p->sAdtlDataPrivAcqr,sADL_DATA_PRIV_ACQ,255);
   }
   ::Template::instance()->map("SEGMENT21",(const char*)p);
  //## end Financial::mapSegment21%5A52A3C301A3.body
}

void Financial::mapSegment22 (hFinancialSeg22* p)
{
  //## begin Financial::mapSegment22%5A52A3C402ED.body preserve=yes
   translate(p->sAdtlDataPrivIssr,sizeof(hFinancialSeg22));
   if (memcmp(p->sAdtlDataPrivIssr,"MC",2) == 0)
   {
      int nVarPos = 13;
      char sFixedFmt[255];
      int nFixedPos = 13;
      // pos 1: Merchant Advice (2)                               FINIPC Bit :1
      // pos 2: Magnetic Stripe Compliance Status Indicator (1)   FINIPC Bit :4
      // pos 3: Magnetic Stripe Compliance Error Indicator (1)    FINIPC Bit :5
     // pos 4: Paypass Ind - Account Number Indicator (1)        FINIPC Bit :6
     // pos 5: Paypass Ind - Account Number (19)                 FINIPC Bit :7
     // pos 6: Paypass Ind - Expiration Date (4)                 FINIPC Bit :8
     //pos 7: Original e-Com Security Level Indicator
              //and UCAF Collection Indicator(3)                 FINIPC Bit:12
     //pos 8: Reason for UCAF Collection Indicator
              //Downgrade Values                                 FINIPC Bit: 13
      short siMCFieldLen[16] = {2,0,0,1,1,1,19,4,2,1,1,3,1,0,0};
      int nFieldNum = 0;
      char sBitMap[8];
      memcpy(sBitMap,p->sAdtlDataPrivIssr + 5,8);
      memset(sFixedFmt,' ',sizeof(sFixedFmt));
      memcpy(sFixedFmt,p->sAdtlDataPrivIssr,13);
      char psBits[4];
      for (int i = 0; i<4; i++)
      {
         convertBitMap(sBitMap[i],psBits);
         for (int j = 0;j <= 3;++j)   // four fields per byte
         {
            if (psBits[j] == '1')      //field is present
            {
               memcpy(sFixedFmt+nFixedPos,p->sAdtlDataPrivIssr+nVarPos,siMCFieldLen[nFieldNum]);
               nVarPos += siMCFieldLen[nFieldNum];
            }
            nFixedPos += siMCFieldLen[nFieldNum];
            ++nFieldNum;
         }
      }
      memcpy(p->sAdtlDataPrivIssr,sFixedFmt,255);
   }
   else
   if (memcmp(p->sAdtlDataPrivIssr,"MD",2) == 0)
   {
      int nVarPos = 13;
      char sAdtlDataPrivIssr[255];
      int nFixedPos = 13;
      short siMCFieldLen[8] = {6,2,1,19,4,1,3,1};
      int nFieldNum = 0;
      char sBitMap[8];
      memcpy(sBitMap,p->sAdtlDataPrivIssr + 5,8);
      memset(sAdtlDataPrivIssr,' ',sizeof(sAdtlDataPrivIssr));
      memcpy(sAdtlDataPrivIssr,"MD043F8000000",13);
      char psBits[4];
      for (int i = 0; i<2; i++)
      {
         convertBitMap(sBitMap[i],psBits);
         for (int j = 0;j < 4;++j)
         {
            if (psBits[j] == '1')      //field is present
            {
               memcpy(sAdtlDataPrivIssr+nFixedPos,p->sAdtlDataPrivIssr+nVarPos,siMCFieldLen[nFieldNum]);
               nVarPos += siMCFieldLen[nFieldNum];
            }
            nFixedPos += siMCFieldLen[nFieldNum];
            ++nFieldNum;
         }
      }
      memcpy(p->sAdtlDataPrivIssr,sAdtlDataPrivIssr,255);
   }
   else
   if (memcmp(p->sAdtlDataPrivIssr,"VD",2) == 0)
   {
      int nVarPos = 13;
      char sADL_DATA_PRIV_ISS[255];
      int nFixedPos = 13;
      short siVDFieldLen[8] = {4,1,1,6,1,1,1,0};
      int nFieldNum = 0;
      char sBitMap[8];
      memcpy(sBitMap,p->sAdtlDataPrivIssr + 5,8);
      memset(sADL_DATA_PRIV_ISS,' ',sizeof(sADL_DATA_PRIV_ISS));
      memcpy(sADL_DATA_PRIV_ISS,"VD023FE000000",13);
      char psBits[4];
      for (int i = 0; i<2; i++)
      {
         convertBitMap(sBitMap[i],psBits);
         for (int j = 0;j <4; ++j)    // four fields per byte.
         {
            if (psBits[j] == '1')      //field is present
            {
               memcpy(sADL_DATA_PRIV_ISS+nFixedPos,p->sAdtlDataPrivIssr+nVarPos,siVDFieldLen[nFieldNum]);
               nVarPos += siVDFieldLen[nFieldNum];
            }
            nFixedPos += siVDFieldLen[nFieldNum];
            ++nFieldNum;
         }
      }
      memcpy(p->sAdtlDataPrivIssr,sADL_DATA_PRIV_ISS,255);
   }
   else
   if (memcmp(p->sAdtlDataPrivIssr,"VE",2) == 0)
   {
      int nVarPos = 13;
      char sADL_DATA_PRIV_ISS[255];
      int nFixedPos = 13;
      short siVDFieldLen[4] = {1,1,0,0};
      int nFieldNum = 0;
      char sBitMap[8];
      memcpy(sBitMap,p->sAdtlDataPrivIssr + 5,8);
      memset(sADL_DATA_PRIV_ISS,' ',sizeof(sADL_DATA_PRIV_ISS));
      memcpy(sADL_DATA_PRIV_ISS,"VE00980000000",13);
      char psBits[4];
      for (int i = 0; i<1; i++)
      {
         convertBitMap(sBitMap[i],psBits);
         for (int j = 0;j <4; ++j)    // four fields per byte.
         {
            if (psBits[j] == '1')      //field is present
            {
               memcpy(sADL_DATA_PRIV_ISS+nFixedPos,p->sAdtlDataPrivIssr+nVarPos,siVDFieldLen[nFieldNum]);
               nVarPos += siVDFieldLen[nFieldNum];
            }
            nFixedPos += siVDFieldLen[nFieldNum];
            ++nFieldNum;
         }
      }
      memcpy(p->sAdtlDataPrivIssr,sADL_DATA_PRIV_ISS,255);
   }
   else
   if (memcmp(p->sAdtlDataPrivIssr,"IC",2) == 0)
   {
      ::Template::instance()->map("SEGMENT22LINK",(const char*)p);
      // !!! string strADL_DATA_PRIV_ISS(p->sAdtlDataPrivIssr,255);
      // !!! size_t n = strADL_DATA_PRIV_ISS.find_last_not_of(' ');
      // !!! if (n != string::npos)
      // !!!    m_pFinancialSettlementSegment->setADL_DATA_PRIV_ISS(strADL_DATA_PRIV_ISS.data(),n + 1);
      /*
      link::segADL_DATA_PRIV_ISS* r = (struct link::segADL_DATA_PRIV_ISS*) strADL_DATA_PRIV_ISS.data();
      m_pIntegratedCircuitCardSegment->setPresence(true);
      // CodeTable::nibbleToByte(r->sAPPL_CRYPTOGRAM,sizeof(r->sAPPL_CRYPTOGRAM),strTemp,true);
      // m_pIntegratedCircuitCardSegment->setAPPL_CRYPTOGRAM(strTemp.data(),strTemp.length());
      string strTemp(r->sISS_SCRIPT1_DATA,sizeof(r->sISS_SCRIPT1_DATA));
      n = strTemp.find_last_not_of(' ');
      if (n != string::npos)
      {
         CodeTable::nibbleToByte(r->sISS_SCRIPT1_DATA,sizeof(r->sISS_SCRIPT1_DATA),strTemp,true);
         m_pIntegratedCircuitCardSegment->setISS_SCRIPT1_DATA(strTemp.data(),strTemp.length());
      }
      strTemp.assign(r->sISS_SCRIPT2_DATA,sizeof(r->sISS_SCRIPT2_DATA));
      n = strTemp.find_last_not_of(' ');
      if (n != string::npos)
      {
         CodeTable::nibbleToByte(r->sISS_SCRIPT2_DATA,sizeof(r->sISS_SCRIPT2_DATA),strTemp,true);
         m_pIntegratedCircuitCardSegment->setISS_SCRIPT2_DATA(strTemp.data(),strTemp.length());
      }
      */
   }
   ::Template::instance()->map("SEGMENT22",(const char*)p);
  //## end Financial::mapSegment22%5A52A3C402ED.body
}

void Financial::mapSegment23 (hFinancialSeg23* p)
{
  //## begin Financial::mapSegment23%5A52A3C5007F.body preserve=yes
   ::Template::instance()->map("SEGMENT23",(const char*)p);
  //## end Financial::mapSegment23%5A52A3C5007F.body
}

void Financial::mapSegment24 (hFinancialSeg24* p)
{
  //## begin Financial::mapSegment24%5A52A3C501B7.body preserve=yes
   UseCase hUseCase("TANDEM","## AI25 PARSE SEGMENT 24",false);
   short siNumTokens = ntohs(p->siNumTokens);
   hFinancialSeg24_TLV* pTLV = (hFinancialSeg24_TLV*)&p->firstTag;
   hFinancialSeg24_TLV_SUB* pTLV_SUB = 0;
   hFinancialSeg24_TLV_SUB_NI* pTLV_SUB_NI = 0;
   hFinancialSeg24_TLV_SUB_MI* pTLV_SUB_MI = 0;
   hFinancialSeg24_TLV_SUB_ID* pTLV_SUB_ID = 0;
   short j = 0;
   short k = 0;
   short m = ntohs(p->siSegmentLength);
   string strSeg24Data;
   for (int i = 0;i < siNumTokens;i++)
   {
      short siToken = ntohs(pTLV->siToken);
      short siTokenLength = ntohs(pTLV->siTokenLength);
      Trace::putHex(pTLV->sTokenValue,siTokenLength);
      short siWorkingLength = 0;
      m -= 4; // token ID and length
      m -= siTokenLength;
      m -= siTokenLength % 2; // slack byte
      if (m < 0)
      {
         UseCase::setSuccess(false);
         break;
      }
      if (siTokenLength > 0)
      {
         if (::Template::instance()->getSubToken().find(siToken) != ::Template::instance()->getSubToken().end())
         {
            map<string,string,less<string> > hTokens;
            if (Token::parse(siTokenLength,string(pTLV->sTokenValue,siTokenLength),1,hTokens))
            {
               map<string,string,less <string> >::iterator pToken;
               for (pToken = hTokens.begin();pToken != hTokens.end();++pToken)
               {
                  char pSegment [8 + PERCENTHD + 32];
                  sprintf(pSegment,"TOKEN-%hd-%s",siToken,(*pToken).first.c_str());
                  ::Template::instance()->map(pSegment,(*pToken).second.data(),(*pToken).second.length());
               }
            }
            return;
         }
         char pSegment[7 + PERCENTHD];
         sprintf(pSegment,"TOKEN-%hd",siToken);
         ::Template::instance()->map(pSegment,(const char*)pTLV->sTokenValue,siTokenLength);
      }
      pTLV = (hFinancialSeg24_TLV*)((char*)pTLV + siTokenLength + 4 + siTokenLength % 2);
   }
  //## end Financial::mapSegment24%5A52A3C501B7.body
}

void Financial::mapSegment99 (hFinancialSeg1* p)
{
  //## begin Financial::mapSegment99%5AB3B5FA021F.body preserve=yes
   string strProcCode;
   if (m_iLinkOption
      && m_cPreAuthFlag == 'Y'
      && !memcmp(p->sProcessCode,"590080",6))
      strProcCode.assign("590008");
   else
      strProcCode.assign(p->sProcessCode,6);
   strProcCode.append(&m_cClass,1);
   strProcCode.append(p->sAcctQual1,3);
   strProcCode.append(&m_cPreauthInd,1);
   if (p->bSeg15)
   {
      if (!memcmp(m_sTranDesc,"DLX",3))
         strProcCode.append(m_sTranDesc+3,4);
      else if (p->sProcessCode[0] == '9')
         strProcCode.append(m_sTranDesc,4);
      else
         strProcCode.append("    ");
   }
   else
      strProcCode.append("    ");
   bool bEvidence[] = {false,m_bAddEvidence};
   bool bFound = false;
   int iIterator = 0;
   string strTemp(strProcCode);
   string strTRAN_TYPE_ID;
   while (bFound == false && iIterator < 2)
   {
      if (iIterator == 1)
         strTemp.replace(7,3,"   ",3);
      if (ConfigurationRepository::instance()->translate("X_ADV_PROC_CODE",strTemp,strTRAN_TYPE_ID,"FIN_LOCATOR","TRAN_TYPE_ID",0,bEvidence[iIterator]))
      {
         memcpy(m_pSegment99->sACCT_TYPES_ISS,strTRAN_TYPE_ID.substr(2,4).data(),4);
         if (memcmp(p->sActionCode,"005",3) == 0)
         {
            memcpy(m_pSegment99->sACT_CODE,"000",3);
            strTRAN_TYPE_ID.replace(2,4,"0000",4);
         }
         memcpy(m_pSegment99->sTRAN_TYPE_ID,strTRAN_TYPE_ID.data(),strTRAN_TYPE_ID.length());
         bFound = true;
      }
      iIterator++;
   }
   if (bFound == false
      && m_bAddEvidence)
   {
      if (memcmp(p->sActionCode,"005",3) == 0)
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_SET_ACT_CODE);
      else
         ConfigurationRepository::instance()->getEvidenceSegment().setREASON_CODE(EVIDENCE_SET_ACCT_TYPES_ISS);
   }
   if (CRTransactionTypeIndicator::getDepositoryInd(strTRAN_TYPE_ID,strTemp)
      && strTemp == "A")
      m_pSegment99->cDEPOSIT_TYPE = 'C';
   m_pTransaction->get("FIN_FRAUD_RULE_YYYYMM","RULE_NAME",strTemp);
   if (!strTemp.empty())
   {
      m_pTransaction->get("FIN_LYYYYMM","INST_ID_RECON_ISS",strTemp);
      memcpy(m_pSegment99->sINST_ID_RECON_ISS,strTemp.data(),strTemp.length());
      m_pTransaction->get("FIN_LYYYYMM","INST_ID_RECON_ACQ",strTemp);
      memcpy(m_pSegment99->sINST_ID_RECON_ACQ,strTemp.data(),strTemp.length());
   }
   m_pTransaction->get("FIN_LYYYYMM","PAN_TOKEN",strTemp);
   if (strTemp.length() > 5)
   {
      memcpy(m_pSegment99->sPAN_TOKEN_PREFIX,strTemp.data(),6);
      memcpy(m_pSegment99->sPAN_TOKEN_SUFFIX,strTemp.data() + strTemp.length() - 4,4);
      memcpy(m_pSegment99->sPAN_TOKEN,strTemp.data(),strTemp.length());
   }
   ::Template::instance()->map("SEGMENT99",(const char*)m_pSegment99);
  //## end Financial::mapSegment99%5AB3B5FA021F.body
}

void Financial::translate (char* pBuffer, int ilen)
{
  //## begin Financial::translate%5AB100D6013D.body preserve=yes
#ifdef MVS
   if (m_bAsciiInput)
      CodeTable::translate(pBuffer,ilen,CodeTable::CX_ASCII_TO_EBCDIC);
#else
   if (!m_bAsciiInput)
      CodeTable::translate(pBuffer,ilen,CodeTable::CX_EBCDIC_TO_ASCII);
#endif
  //## end Financial::translate%5AB100D6013D.body
}

// Additional Declarations
  //## begin Financial%5A50EEA30372.declarations preserve=yes
  //## end Financial%5A50EEA30372.declarations

//## begin module%5A50EF1D0226.epilog preserve=yes
//## end module%5A50EF1D0226.epilog
