//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A50EF1C0098.cm preserve=no
//	$Date:   Sep 06 2018 07:35:26  $ $Author:   e1009839  $
//	$Revision:   1.4  $
//## end module%5A50EF1C0098.cm

//## begin module%5A50EF1C0098.cp preserve=no
//	Copyright (c) 1997 - 2018
//	FIS
//## end module%5A50EF1C0098.cp

//## Module: CXOSAI25%5A50EF1C0098; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI25.hpp

#ifndef CXOSAI25_h
#define CXOSAI25_h 1

//## begin module%5A50EF1C0098.additionalIncludes preserve=no
//## end module%5A50EF1C0098.additionalIncludes

//## begin module%5A50EF1C0098.includes preserve=yes
//## end module%5A50EF1C0098.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: DataNavigator Foundation::EntitySegment_CAT%394E275103DB
namespace entitysegment {
class Customer;
} // namespace entitysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class AdvantageMessageProcessor;
//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Extract;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Mask;
class Token;
} // namespace reusable

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class UniquenessKey;

} // namespace database

//## begin module%5A50EF1C0098.declarations preserve=no
//## end module%5A50EF1C0098.declarations

//## begin module%5A50EF1C0098.additionalDeclarations preserve=yes
//## end module%5A50EF1C0098.additionalDeclarations


//## begin Financial%5A50EEA30372.preface preserve=yes
//## end Financial%5A50EEA30372.preface

//## Class: Financial%5A50EEA30372
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5A577A8C0300;reusable::Token { -> F}
//## Uses: <unnamed>%5A5EB16901FE;IF::Extract { -> F}
//## Uses: <unnamed>%5A5FFE5103D2;reusable::Mask { -> F}
//## Uses: <unnamed>%5A600EED026C;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%5A60103601FF;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%5A60124700CC;entitysegment::Customer { -> F}
//## Uses: <unnamed>%5AB1655E030A;database::UniquenessKey { -> F}

class DllExport Financial : public AdvantageMessage  //## Inherits: <unnamed>%5A50EEDD004F
{
  //## begin Financial%5A50EEA30372.initialDeclarations preserve=yes
  //## end Financial%5A50EEA30372.initialDeclarations

  public:
    //## Constructors (generated)
      Financial();

    //## Destructor (generated)
      virtual ~Financial();


    //## Other Operations (specified)
      //## Operation: insert%5A50EEE402BE
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin Financial%5A50EEA30372.public preserve=yes
      //## end Financial%5A50EEA30372.public

  protected:
    // Additional Protected Declarations
      //## begin Financial%5A50EEA30372.protected preserve=yes
      //## end Financial%5A50EEA30372.protected

  private:

    //## Other Operations (specified)
      //## Operation: convertAmt%3C6195C2002E
      int convertAmt (int lAmount, char cDecPos, char* sRate);

      //## Operation: convertAmt%5AB1008F009E
      double convertAmt (double dAmount, char cDecPos, char* sRate);

      //## Operation: convertBitMap%5AB12B0402E0
      void convertBitMap (const char cCharBit, char* psBits);

      //## Operation: mapSegment1%5A5140CA012F
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>MS
      //	<!-- AdvantageFinancial::mapSegment1 : Preconditions -->
      //	<h3>Acquirer Business Relationships
      //	<p>
      //	The financial transactions in the Data Repository
      //	include a set of business entity values that may be
      //	different than the values logged by the acquiring
      //	platform.
      //	The parent business values are determined by a process
      //	referred to as entity rechaining.
      //	These business values are used in transaction research,
      //	exception processing and totals.
      //	<p>
      //	The acquiring business network terminal (FIN_
      //	L<i>yyyymm</i>.NET_TERM_ID) is set from the Connex on HP
      //	FINIPC data element NETWORK^TERM^ID (1).
      //	The acquirer business rechaining starts with network
      //	terminal to determine the following columns:
      //	<table>
      //	<tr>
      //	<th>Input
      //	<th>Translation Table
      //	<th>Derived Value
      //	<tr>
      //	<td>NETWORK^TERM^ID (1)
      //	<td>Devices
      //	<td>FIN_L<i>yyyymm</i>.INST_ID_RECN_ACQ_B
      //	<tr>
      //	<td>FIN_L<i>yyyymm</i>.INST_ID_RECN_ACQ_B
      //	<td>Institutions
      //	<td>FIN_L<i>yyyymm</i>.PROC_ID_ACQ_B
      //	<tr>
      //	<td>FIN_L<i>yyyymm</i>.PROC_ID_ACQ_B
      //	<td>Processors
      //	<td>FIN_L<i>yyyymm</i>.PROC_GRP_ID_ACQ_B
      //	</table>
      //	<p>
      //	The entity values are copied from FIS Connex on HP CED
      //	automatically; therefore manual maintenance is only
      //	needed to affect the business values in the financial
      //	transaction in DataNavigator.
      //	Devices, Institutions and Processors are in the
      //	EFT-Entity Tables folder in the CR Client for the Data
      //	Navigator Server.
      //	<p>
      //	<h3>Issuer Business Relationships
      //	<p>
      //	The financial transactions in the Data Repository
      //	include a set of business entity values that may be
      //	different than the values logged by the issuing platform.
      //	The parent business values are determined by a process
      //	referred to as entity rechaining.
      //	These business values are used in transaction research,
      //	exception processing and totals.
      //	<p>
      //	The issuing business institution ID (FIN_
      //	L<i>yyyymm</i>.INST_ID_RECN_ISS_B) is set from the
      //	Connex on HP FINIPC data element RPT^INST^ID^ISSR (1).
      //	The issuer business rechaining starts with issuer
      //	reporting institution to determine the following columns:
      //	<table>
      //	<tr>
      //	<th>Input
      //	<th>Translation Table
      //	<th>Derived Value
      //	<tr>
      //	<td>RPT^INST^ID^ISSR (1)
      //	<td>Institutions
      //	<td>FIN_L<i>yyyymm</i>.PROC_ID_ISS_B
      //	<tr>
      //	<td>FIN_L<i>yyyymm</i>.PROC_ID_ISS_B
      //	<td>Processors
      //	<td>FIN_L<i>yyyymm</i>.PROC_GRP_ID_ISS_B
      //	</table>
      //	<p>
      //	The entity values are copied from FIS Connex on HP CED
      //	automatically; therefore manual maintenance  is only
      //	needed to affect the business values in the financial
      //	transaction in DataNavigator.
      //	Institutions and Processors are in the EFT-Entity Tables
      //	folder in the CR Client for the DataNavigator Server.
      //	<!-- AdvantageFinancial::mapSegment2 : Preconditions -->
      //	<!-- release V02.1A.R001 -->
      //	<h3>Expiration Date
      //	<p>
      //	The DataNavigator data model for the financial
      //	transaction includes Bit 14 - Date expiration.
      //	This data element is no longer stored by default as PCI
      //	dictates it not be saved subsequent to authorization.
      //	<p>
      //	To populate FIN_RECORD<i>yyyymm</i>.DATE_EXP, add the
      //	value DATE_EXP to the FIS Advantage Transaction
      //	Interface task(s) (i.e. <i>ca</i>AI1, <i>ca</i>AI2, ...)
      //	user data.
      //	<p>
      //	Use the CR Client to change the User Data.  It is on the
      //	Detail : General tab in the Task definition.
      //	<!-- /release -->
      //	</body>
      void mapSegment1 (hFinancialSeg1* p);

      //## Operation: mapSegment2%5A5140CA0146
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>MS
      //	<!-- AdvantageFinancial::mapSegment2 : Preconditions -->
      //	<!-- release V01.9B.R001 -->
      //	<h3>Track 2
      //	<p>
      //	The DataNavigator data model for the financial
      //	transaction includes Bit 35 - Track 2 data.
      //	This data element is no longer stored by default as PCI
      //	dictates it not be saved subsequent to authorization.
      //	<p>
      //	To populate FIN_RECORD<i>yyyymm</i>.TRACK_2_DATA, add
      //	the value TRACK2 to the FIS Advantage Transaction
      //	Interface task(s) (i.e. <i>ca</i>AI1, <i>ca</i>AI2,
      //	...)  user data.
      //	<p>
      //	Use the CR Client to change the User Data.  It is on the
      //	Detail : General tab in the Task definition.
      //	<!-- /release -->
      //	</body>
      void mapSegment2 (hFinancialSeg2* p);

      //## Operation: mapSegment3%5A5140CA014F
      void mapSegment3 (hFinancialSeg3* p);

      //## Operation: mapSegment4%5A5140CA0157
      void mapSegment4 (hFinancialSeg4* p);

      //## Operation: mapSegment5%5A5140CA015F
      void mapSegment5 (hFinancialSeg5* p);

      //## Operation: mapSegment6%5A5140CA0167
      void mapSegment6 (hFinancialSeg6* p);

      //## Operation: mapSegment7%5A52A34D02AE
      void mapSegment7 (hFinancialSeg7* p);

      //## Operation: mapSegment8%5A52A34E0217
      void mapSegment8 (hFinancialSeg8* p, hFinancialSeg1* p1);

      //## Operation: mapSegment9%5A52A34F001A
      void mapSegment9 (hFinancialSeg9* p);

      //## Operation: mapSegment10%5A52A34F016E
      void mapSegment10 (hFinancialSeg10* p);

      //## Operation: mapSegment11%5A52A3700334
      void mapSegment11 (hFinancialSeg11* p);

      //## Operation: mapSegment12%5A52A37203AC
      void mapSegment12 (hFinancialSeg12* p);

      //## Operation: mapSegment13%5A52A37301B8
      void mapSegment13 (hFinancialSeg13* p);

      //## Operation: mapSegment14%5A52A3730351
      void mapSegment14 (hFinancialSeg14* p);

      //## Operation: mapSegment15%5A52A37400FA
      void mapSegment15 (hFinancialSeg15* p);

      //## Operation: mapSegment16%5A52A374028A
      void mapSegment16 (hFinancialSeg16* p);

      //## Operation: mapSegment17%5A52A3750031
      void mapSegment17 (hFinancialSeg17* p);

      //## Operation: mapSegment18%5A52A37501CB
      void mapSegment18 (hFinancialSeg18* p);

      //## Operation: mapSegment19%5A52A3750359
      void mapSegment19 (hFinancialSeg19* p);

      //## Operation: mapSegment20%5A52A37600E5
      void mapSegment20 (hFinancialSeg20* p);

      //## Operation: mapSegment21%5A52A3C301A3
      void mapSegment21 (hFinancialSeg21* p);

      //## Operation: mapSegment22%5A52A3C402ED
      void mapSegment22 (hFinancialSeg22* p);

      //## Operation: mapSegment23%5A52A3C5007F
      void mapSegment23 (hFinancialSeg23* p);

      //## Operation: mapSegment24%5A52A3C501B7
      void mapSegment24 (hFinancialSeg24* p);

      //## Operation: mapSegment99%5AB3B5FA021F
      void mapSegment99 (hFinancialSeg1* p);

      //## Operation: translate%5AB100D6013D
      void translate (char* pBuffer, int ilen);

    // Additional Private Declarations
      //## begin Financial%5A50EEA30372.private preserve=yes
      //## end Financial%5A50EEA30372.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: AddEvidence%5A600E930227
      //## begin Financial::AddEvidence%5A600E930227.attr preserve=no  private: bool {V} false
      bool m_bAddEvidence;
      //## end Financial::AddEvidence%5A600E930227.attr

      //## Attribute: AuthByAltRoute%5A574BD5012E
      //## begin Financial::AuthByAltRoute%5A574BD5012E.attr preserve=no  private: bool {V} false
      bool m_bAuthByAltRoute;
      //## end Financial::AuthByAltRoute%5A574BD5012E.attr

      //## Attribute: BufferStartp%5AB1097C00DB
      //## begin Financial::BufferStartp%5AB1097C00DB.attr preserve=no  private: int {V} 0
      int m_iBufferStartp;
      //## end Financial::BufferStartp%5AB1097C00DB.attr

      //## Attribute: Class%5AB10998024B
      //## begin Financial::Class%5AB10998024B.attr preserve=no  private: char {V} ' ' 
      char m_cClass;
      //## end Financial::Class%5AB10998024B.attr

      //## Attribute: ExpirationDate%5A5EAF8F005B
      //## begin Financial::ExpirationDate%5A5EAF8F005B.attr preserve=no  private: bool {V} false
      bool m_bExpirationDate;
      //## end Financial::ExpirationDate%5A5EAF8F005B.attr

      //## Attribute: INST_ID_RECN_ACQ_BandRPT_LVL_ID_B%5AB109550255
      //## begin Financial::INST_ID_RECN_ACQ_BandRPT_LVL_ID_B%5AB109550255.attr preserve=no  private: string {V} 
      string m_strINST_ID_RECN_ACQ_BandRPT_LVL_ID_B;
      //## end Financial::INST_ID_RECN_ACQ_BandRPT_LVL_ID_B%5AB109550255.attr

      //## Attribute: LinkOption%5A5EB07E039A
      //## begin Financial::LinkOption%5A5EB07E039A.attr preserve=no  private: int {V} 0
      int m_iLinkOption;
      //## end Financial::LinkOption%5A5EB07E039A.attr

      //## Attribute: NetworkDecPos%5AB10984005B
      //## begin Financial::NetworkDecPos%5AB10984005B.attr preserve=no  private: char {V} ' ' 
      char m_cNetworkDecPos;
      //## end Financial::NetworkDecPos%5AB10984005B.attr

      //## Attribute: NetworkRate%5AB1098D011B
      //## begin Financial::NetworkRate%5AB1098D011B.attr preserve=no  private: char[8] {V} 
      char m_sNetworkRate[8];
      //## end Financial::NetworkRate%5AB1098D011B.attr

      //## Attribute: PreAuthFlag%5AB679C603AF
      //## begin Financial::PreAuthFlag%5AB679C603AF.attr preserve=no  private: char {V} ' ' 
      char m_cPreAuthFlag;
      //## end Financial::PreAuthFlag%5AB679C603AF.attr

      //## Attribute: PreauthInd%5AB10966031C
      //## begin Financial::PreauthInd%5AB10966031C.attr preserve=no  private: char {V} ' ' 
      char m_cPreauthInd;
      //## end Financial::PreauthInd%5AB10966031C.attr

      //## Attribute: Reversal%5AB1096E030C
      //## begin Financial::Reversal%5AB1096E030C.attr preserve=no  private: bool {V} false
      bool m_bReversal;
      //## end Financial::Reversal%5AB1096E030C.attr

      //## Attribute: Segment%5A50F5F6007E
      //## begin Financial::Segment%5A50F5F6007E.attr preserve=no  private: char* {V} 0
      char* m_pSegment;
      //## end Financial::Segment%5A50F5F6007E.attr

      //## Attribute: Segment99%5A5EA8320247
      //## begin Financial::Segment99%5A5EA8320247.attr preserve=no  private: hSegment99* {V} 0
      hSegment99* m_pSegment99;
      //## end Financial::Segment99%5A5EA8320247.attr

      //## Attribute: TokenExpirationDate%5A5EB017025E
      //## begin Financial::TokenExpirationDate%5A5EB017025E.attr preserve=no  private: bool {V} false
      bool m_bTokenExpirationDate;
      //## end Financial::TokenExpirationDate%5A5EB017025E.attr

      //## Attribute: Track2%5A5EB0180203
      //## begin Financial::Track2%5A5EB0180203.attr preserve=no  private: bool {V} false
      bool m_bTrack2;
      //## end Financial::Track2%5A5EB0180203.attr

      //## Attribute: TranDesc%5AB67B5600EF
      //## begin Financial::TranDesc%5AB67B5600EF.attr preserve=no  private: char[8] {V} 
      char m_sTranDesc[8];
      //## end Financial::TranDesc%5AB67B5600EF.attr

    // Additional Implementation Declarations
      //## begin Financial%5A50EEA30372.implementation preserve=yes
      //## end Financial%5A50EEA30372.implementation

};

//## begin Financial%5A50EEA30372.postscript preserve=yes
//## end Financial%5A50EEA30372.postscript

//## begin module%5A50EF1C0098.epilog preserve=yes
//## end module%5A50EF1C0098.epilog


#endif
