//## begin module%1.3%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.3%.codegen_version

//## begin module%3C61397E01F4.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3C61397E01F4.cm

//## begin module%3C61397E01F4.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3C61397E01F4.cp

//## Module: CXOSAI13%3C61397E01F4; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Pvcswork\Dn\Server\Application\Ai\CXODAI13.hpp

#ifndef CXOSAI13_h
#define CXOSAI13_h 1

//## begin module%3C61397E01F4.additionalIncludes preserve=no
//## end module%3C61397E01F4.additionalIncludes

//## begin module%3C61397E01F4.includes preserve=yes
// $Date:   Jan 31 2018 14:07:10  $ $Author:   e1009839  $ $Revision:   1.13  $
//## end module%3C61397E01F4.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class FinancialFeeSegment;
class FinancialBaseSegment;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

//## Modelname: Connex Foundation::Process_CAT%3453F1510045
namespace process {
class Application;
} // namespace process

//## Modelname: Connex Foundation::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Foundation::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
class DateTime;
} // namespace IF

class AdvantageMessageProcessor;

//## begin module%3C61397E01F4.declarations preserve=no
//## end module%3C61397E01F4.declarations

//## begin module%3C61397E01F4.additionalDeclarations preserve=yes
//## end module%3C61397E01F4.additionalDeclarations


//## begin AdvantageStdFee%3C6133C800BB.preface preserve=yes
//## end AdvantageStdFee%3C6133C800BB.preface

//## Class: AdvantageStdFee%3C6133C800BB
//## Category: Platform \: Advantage::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n

//## Uses: <unnamed>%3C63EAE2035B;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%3C63EAE5003E;process::Application { -> F}
//## Uses: <unnamed>%3C63EAE7032C;IF::CodeTable { -> F}
//## Uses: <unnamed>%3C63EAEA01D4;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3C63EAED0177;IF::DateTime { -> F}
//## Uses: <unnamed>%3C63EB0B02BF;IF::Message { -> F}
//## Uses: <unnamed>%3C63EB0E0148;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C63F434002E;repositorysegment::FinancialBaseSegment { -> F}
//## Uses: <unnamed>%3C63F43F001F;repositorysegment::FinancialFeeSegment { -> F}

class AdvantageStdFee : public AdvantageMessage  //## Inherits: <unnamed>%3C63D85900FA
{
  //## begin AdvantageStdFee%3C6133C800BB.initialDeclarations preserve=yes
  //## end AdvantageStdFee%3C6133C800BB.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageStdFee();

    //## Destructor (generated)
      virtual ~AdvantageStdFee();


    //## Other Operations (specified)
      //## Operation: insert%3C63D85D0109
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantageStdFee%3C6133C800BB.public preserve=yes
      //## end AdvantageStdFee%3C6133C800BB.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageStdFee%3C6133C800BB.protected preserve=yes
      //## end AdvantageStdFee%3C6133C800BB.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageStdFee%3C6133C800BB.private preserve=yes
      //## end AdvantageStdFee%3C6133C800BB.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin AdvantageStdFee%3C6133C800BB.implementation preserve=yes
      //## end AdvantageStdFee%3C6133C800BB.implementation

};

//## begin AdvantageStdFee%3C6133C800BB.postscript preserve=yes
//## end AdvantageStdFee%3C6133C800BB.postscript

//## begin module%3C61397E01F4.epilog preserve=yes
//## end module%3C61397E01F4.epilog


#endif
