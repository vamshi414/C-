//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%528BC8A101E6.cm preserve=no
//	$Date:   May 20 2020 11:45:18  $ $Author:   e1009510  $
//	$Revision:   1.7  $
//## end module%528BC8A101E6.cm

//## begin module%528BC8A101E6.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%528BC8A101E6.cp

//## Module: CXOSAI21%528BC8A101E6; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXOSAI21.cpp

//## begin module%528BC8A101E6.additionalIncludes preserve=no
//## end module%528BC8A101E6.additionalIncludes

//## begin module%528BC8A101E6.includes preserve=yes
//## end module%528BC8A101E6.includes

#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSRS93_h
#include "CXODRS93.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSCF01_h
#include "CXODCF01.hpp"
#endif
#ifndef CXOSAI21_h
#include "CXODAI21.hpp"
#endif


//## begin module%528BC8A101E6.declarations preserve=no
//## end module%528BC8A101E6.declarations

//## begin module%528BC8A101E6.additionalDeclarations preserve=yes
//## end module%528BC8A101E6.additionalDeclarations


// Class InvalidAuthorization

InvalidAuthorization::InvalidAuthorization()
  //## begin InvalidAuthorization::InvalidAuthorization%528BC83A0388_const.hasinit preserve=no
  //## end InvalidAuthorization::InvalidAuthorization%528BC83A0388_const.hasinit
  //## begin InvalidAuthorization::InvalidAuthorization%528BC83A0388_const.initialization preserve=yes
   :AdvantageMessage("0430","S319")
  //## end InvalidAuthorization::InvalidAuthorization%528BC83A0388_const.initialization
{
  //## begin InvalidAuthorization::InvalidAuthorization%528BC83A0388_const.body preserve=yes
   memcpy(m_sID,"AI21",4);
  //## end InvalidAuthorization::InvalidAuthorization%528BC83A0388_const.body
}


InvalidAuthorization::~InvalidAuthorization()
{
  //## begin InvalidAuthorization::~InvalidAuthorization%528BC83A0388_dest.body preserve=yes
  //## end InvalidAuthorization::~InvalidAuthorization%528BC83A0388_dest.body
}



//## Other Operations (implementation)
bool InvalidAuthorization::insert (Message& hMessage)
{
  //## begin InvalidAuthorization::insert%528BC9870103.body preserve=yes
   FinancialExceptionSegment::instance()->reset();
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   hInvalidAuthorization* pAdjustment = (hInvalidAuthorization*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   char sTranId[4];
   memcpy(sTranId,pAdjustment->sTranId,4);
   char sMsgType[4];
   memcpy(sMsgType,pAdjustment->sMsgType,4);
   char sLen[5] = {"    "};
   memcpy(sLen,pAdjustment->sLength,4);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(sTranId,4,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(sMsgType,4,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pV13AdvantageHeader->sHdrSource,sizeof(pV13AdvantageHeader->sHdrSource),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sTranDate,12,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sUsageCode,2,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sUserField1,2,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(pAdjustment->sUserField2,6,CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(sLen,4,CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
   {
      CodeTable::translate(sTranId,4,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(sMsgType,4,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pV13AdvantageHeader->sHdrSource,sizeof(pV13AdvantageHeader->sHdrSource),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sTranDate,12,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sUsageCode,2,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sUserField1,2,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(pAdjustment->sUserField2,6,CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(sLen,4,CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   UseCase hUseCase("TANDEM","## AD30 READ 0430 INV AUTH",false);
   string strTSTAMP_TRANS("20");
   strTSTAMP_TRANS.append(pAdjustment->sTranDate,12);
   strTSTAMP_TRANS.append("00");
   if (getTestDate().length() > 0)
   {
      string strTemp(getTestDate());
      strTemp += strTSTAMP_TRANS.substr(8);
      strTSTAMP_TRANS = strTemp;
   }
   FinancialExceptionSegment::instance()->setTSTAMP_TRANS(strTSTAMP_TRANS.data(),strTSTAMP_TRANS.length());
   FinancialExceptionSegment::instance()->setMSG_SOURCE(pV13AdvantageHeader->sHdrSource,sizeof(pV13AdvantageHeader->sHdrSource));
   char szTemp[PERCENTD];
   snprintf(szTemp,sizeof(szTemp),"%04d",pV13AdvantageHeader->siHdrMsgCode);
   FinancialExceptionSegment::instance()->setMSG_CODE(szTemp,strlen(szTemp));
   snprintf(szTemp,sizeof(szTemp),"%02d",pV13AdvantageHeader->siHdrMsgStep);
   FinancialExceptionSegment::instance()->setSTEP_CODE(szTemp,strlen(szTemp));
   FinancialExceptionSegment::instance()->setMSG_USAGE("01",2);
   FinancialExceptionSegment::instance()->setUSER_FIELD1("03",2);
   FinancialExceptionSegment::instance()->setUSER_FIELD2("000000",6);
   char szTranDataFmt[3] = "00";
   szTranDataFmt[2] = '\0';
   if ( (memcmp(sMsgType,"01",2) == 0) || (memcmp(sMsgType,"02",2) == 0) || (memcmp(sMsgType,"04",2) == 0))
      memcpy(szTranDataFmt,"01",2);
   else
   if (memcmp(sMsgType,"05",2) == 0)
      memcpy(szTranDataFmt,"02",2);
   else
   if (memcmp(sMsgType,"08",2) == 0)
      memcpy(szTranDataFmt,"03",2);
   else
   if (memcmp(sMsgType,"06",2) == 0)
      memcpy(szTranDataFmt,"04",2);
   int iLen = atoi(sLen);
   FinancialExceptionSegment::instance()->setTRAN_DATA_FMT(szTranDataFmt,strlen(szTranDataFmt));
   FinancialExceptionSegment::instance()->setSizeofTRAN_DATA(iLen);
   FinancialExceptionSegment::instance()->setTRAN_DATA(pAdjustment->sTranData,iLen);
   string strFirst(pV13AdvantageHeader->sHdrSource,sizeof(pV13AdvantageHeader->sHdrSource));
   string strPROC_GRP_ID;
   ConfigurationRepository::instance()->translate("PROCESSORName",strFirst, strPROC_GRP_ID,"","",-1,false);
   FinancialExceptionSegment::instance()->setPROC_GRP_ID(strPROC_GRP_ID.data(),strPROC_GRP_ID.length());
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   FinancialExceptionSegment::instance()->write(&psBuffer);
   memcpy(psBuffer,"Z999",4);
   psBuffer += 4;
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end InvalidAuthorization::insert%528BC9870103.body
}

// Additional Declarations
  //## begin InvalidAuthorization%528BC83A0388.declarations preserve=yes
  //## end InvalidAuthorization%528BC83A0388.declarations

//## begin module%528BC8A101E6.epilog preserve=yes
//## end module%528BC8A101E6.epilog
