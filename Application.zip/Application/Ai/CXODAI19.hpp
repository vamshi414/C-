//## begin module%1.5%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.5%.codegen_version

//## begin module%46652DAF0144.cm preserve=no
//	$Date:   Feb 05 2014 16:18:04  $ $Author:   e1009839  $
//	$Revision:   1.12  $
//## end module%46652DAF0144.cm

//## begin module%46652DAF0144.cp preserve=no
//	Copyright (c) 1998 - 2007
//	EFD | eFunds Corporation
//## end module%46652DAF0144.cp

//## Module: CXOSAI19%46652DAF0144; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXODAI19.hpp

#ifndef CXOSAI19_h
#define CXOSAI19_h 1

//## begin module%46652DAF0144.additionalIncludes preserve=no
//## end module%46652DAF0144.additionalIncludes

//## begin module%46652DAF0144.includes preserve=yes
//## end module%46652DAF0144.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
#ifndef CXOSRS72_h
#include "CXODRS72.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class AdvantageMessageProcessor;
//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
class Message;
class DateTime;
class Trace;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%46652DAF0144.declarations preserve=no
//## end module%46652DAF0144.declarations

//## begin module%46652DAF0144.additionalDeclarations preserve=yes
//## end module%46652DAF0144.additionalDeclarations


//## begin AdvantageElectronicJournal%466CF0E00150.preface preserve=yes
//## end AdvantageElectronicJournal%466CF0E00150.preface

//## Class: AdvantageElectronicJournal%466CF0E00150
//## Category: Platform \: FNIS Advantage::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%466EA3BB02A6;process::Application { -> F}
//## Uses: <unnamed>%466EA3C301BC;monitor::UseCase { -> F}
//## Uses: <unnamed>%466EA3CD00F1;IF::Message { -> F}
//## Uses: <unnamed>%466EA3D302B6;IF::DateTime { -> F}
//## Uses: <unnamed>%466EAA8C03D3;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%4705DCE5009A;IF::CodeTable { -> F}
//## Uses: <unnamed>%47148E6B0370;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%4824422102EE;IF::Trace { -> F}
//## Uses: <unnamed>%482442240167;reusable::Buffer { -> F}

class AdvantageElectronicJournal : public AdvantageMessage  //## Inherits: <unnamed>%466CF1F400F1
{
  //## begin AdvantageElectronicJournal%466CF0E00150.initialDeclarations preserve=yes
  //## end AdvantageElectronicJournal%466CF0E00150.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageElectronicJournal();

    //## Destructor (generated)
      virtual ~AdvantageElectronicJournal();


    //## Other Operations (specified)
      //## Operation: insert%466E8A1B02A4
      virtual bool insert (IF::Message& hMessage);

    // Additional Public Declarations
      //## begin AdvantageElectronicJournal%466CF0E00150.public preserve=yes
      //## end AdvantageElectronicJournal%466CF0E00150.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageElectronicJournal%466CF0E00150.protected preserve=yes
      //## end AdvantageElectronicJournal%466CF0E00150.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageElectronicJournal%466CF0E00150.private preserve=yes
      //## end AdvantageElectronicJournal%466CF0E00150.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: FNIS Advantage::AcquirerInterface_CAT::<unnamed>%46DAC868019B
      //## Role: AdvantageElectronicJournal::<m_hElectronicJournalSegment>%46DAC86902B3
      //## begin AdvantageElectronicJournal::<m_hElectronicJournalSegment>%46DAC86902B3.role preserve=no  public: repositorysegment::ElectronicJournalSegment { -> VHgN}
      repositorysegment::ElectronicJournalSegment m_hElectronicJournalSegment;
      //## end AdvantageElectronicJournal::<m_hElectronicJournalSegment>%46DAC86902B3.role

    // Additional Implementation Declarations
      //## begin AdvantageElectronicJournal%466CF0E00150.implementation preserve=yes
      //## end AdvantageElectronicJournal%466CF0E00150.implementation

};

//## begin AdvantageElectronicJournal%466CF0E00150.postscript preserve=yes
//## end AdvantageElectronicJournal%466CF0E00150.postscript

//## begin module%46652DAF0144.epilog preserve=yes
//## end module%46652DAF0144.epilog


#endif
