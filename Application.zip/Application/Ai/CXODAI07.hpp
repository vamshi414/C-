//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C6137AA0138.cm preserve=no
//	$Date:   Feb 20 2019 09:53:34  $ $Author:   E5350313  $
//	$Revision:   1.15  $
//## end module%3C6137AA0138.cm

//## begin module%3C6137AA0138.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C6137AA0138.cp

//## Module: CXOSAI07%3C6137AA0138; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Dn_codes\V03.0A.R002\Dn\Server\Application\Ai\CXODAI07.hpp

#ifndef CXOSAI07_h
#define CXOSAI07_h 1

//## begin module%3C6137AA0138.additionalIncludes preserve=no
//## end module%3C6137AA0138.additionalIncludes

//## begin module%3C6137AA0138.includes preserve=yes
// $Date:   Feb 20 2019 09:53:34  $ $Author:   E5350313  $ $Revision:   1.15  $
//## end module%3C6137AA0138.includes

#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
#ifndef CXOSRSA7_h
#include "CXODRSA7.hpp"
#endif
#ifndef CXOSRS43_h
#include "CXODRS43.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class AdvantageMessageProcessor;
//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class DateTime;
class CodeTable;
class Message;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%3C6137AA0138.declarations preserve=no
//## end module%3C6137AA0138.declarations

//## begin module%3C6137AA0138.additionalDeclarations preserve=yes
//## end module%3C6137AA0138.additionalDeclarations


//## begin AdvantageNetstatStatus%3C61326C03A9.preface preserve=yes
//## end AdvantageNetstatStatus%3C61326C03A9.preface

//## Class: AdvantageNetstatStatus%3C61326C03A9
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3C62FB410119;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C62FB5103C8;IF::Message { -> F}
//## Uses: <unnamed>%3C62FB650167;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%3C62FB7602DE;IF::Message { -> F}
//## Uses: <unnamed>%3C62FB840000;process::Application { -> F}
//## Uses: <unnamed>%3C62FB8F0167;IF::DateTime { -> F}
//## Uses: <unnamed>%3C62FBCB038A;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3C62FC0F01B5;IF::CodeTable { -> F}
//## Uses: <unnamed>%5C6A81B8035A;AdvantageMessageProcessor { -> F}

class AdvantageNetstatStatus : public AdvantageMessage  //## Inherits: <unnamed>%3C61328A032C
{
  //## begin AdvantageNetstatStatus%3C61326C03A9.initialDeclarations preserve=yes
  //## end AdvantageNetstatStatus%3C61326C03A9.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageNetstatStatus();

    //## Destructor (generated)
      virtual ~AdvantageNetstatStatus();


    //## Other Operations (specified)
      //## Operation: insert%3C618A110232
      virtual bool insert (Message& hMessage);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: AD17Message%5C6C184F0313
      const bool& getAD17Message () const
      {
        //## begin AdvantageNetstatStatus::getAD17Message%5C6C184F0313.get preserve=no
        return m_bAD17Message;
        //## end AdvantageNetstatStatus::getAD17Message%5C6C184F0313.get
      }

      void setAD17Message (const bool& value)
      {
        //## begin AdvantageNetstatStatus::setAD17Message%5C6C184F0313.set preserve=no
        m_bAD17Message = value;
        //## end AdvantageNetstatStatus::setAD17Message%5C6C184F0313.set
      }


    // Additional Public Declarations
      //## begin AdvantageNetstatStatus%3C61326C03A9.public preserve=yes
      //## end AdvantageNetstatStatus%3C61326C03A9.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageNetstatStatus%3C61326C03A9.protected preserve=yes
      //## end AdvantageNetstatStatus%3C61326C03A9.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageNetstatStatus%3C61326C03A9.private preserve=yes
      //## end AdvantageNetstatStatus%3C61326C03A9.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin AdvantageNetstatStatus::AD17Message%5C6C184F0313.attr preserve=no  public: bool {V} false
      bool m_bAD17Message;
      //## end AdvantageNetstatStatus::AD17Message%5C6C184F0313.attr

    // Data Members for Associations

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C618A3B00AB
      //## Role: AdvantageNetstatStatus::<m_hListSegment>%3C618A3B038A
      //## begin AdvantageNetstatStatus::<m_hListSegment>%3C618A3B038A.role preserve=no  public: segment::ListSegment { -> VHgN}
      segment::ListSegment m_hListSegment;
      //## end AdvantageNetstatStatus::<m_hListSegment>%3C618A3B038A.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3D63A91D0290
      //## Role: AdvantageNetstatStatus::<m_hEntityStatusSegment>%3D63A91E00CB
      //## begin AdvantageNetstatStatus::<m_hEntityStatusSegment>%3D63A91E00CB.role preserve=no  public: repositorysegment::EntityStatusSegment { -> VHgN}
      repositorysegment::EntityStatusSegment m_hEntityStatusSegment;
      //## end AdvantageNetstatStatus::<m_hEntityStatusSegment>%3D63A91E00CB.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5C6A7FAB0204
      //## Role: AdvantageNetstatStatus::<m_hAIMSBillingSegment>%5C6A7FAC01FF
      //## begin AdvantageNetstatStatus::<m_hAIMSBillingSegment>%5C6A7FAC01FF.role preserve=no  public: repositorysegment::AIMSBillingSegment { -> VHgN}
      repositorysegment::AIMSBillingSegment m_hAIMSBillingSegment;
      //## end AdvantageNetstatStatus::<m_hAIMSBillingSegment>%5C6A7FAC01FF.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5C6A82AE0328
      //## Role: AdvantageNetstatStatus::<m_pAdvantageMessageProcessor>%5C6A82B00145
      //## begin AdvantageNetstatStatus::<m_pAdvantageMessageProcessor>%5C6A82B00145.role preserve=no  public: AdvantageMessageProcessor { -> RFHgN}
      AdvantageMessageProcessor *m_pAdvantageMessageProcessor;
      //## end AdvantageNetstatStatus::<m_pAdvantageMessageProcessor>%5C6A82B00145.role

    // Additional Implementation Declarations
      //## begin AdvantageNetstatStatus%3C61326C03A9.implementation preserve=yes
      //## end AdvantageNetstatStatus%3C61326C03A9.implementation

};

//## begin AdvantageNetstatStatus%3C61326C03A9.postscript preserve=yes
//## end AdvantageNetstatStatus%3C61326C03A9.postscript

//## begin module%3C6137AA0138.epilog preserve=yes
//## end module%3C6137AA0138.epilog


#endif
