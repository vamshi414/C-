//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A54316C0302.cm preserve=no
//	$Date:   Apr 09 2018 12:04:54  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%5A54316C0302.cm

//## begin module%5A54316C0302.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A54316C0302.cp

//## Module: CXOSAI37%5A54316C0302; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI37.cpp

//## begin module%5A54316C0302.additionalIncludes preserve=no
//## end module%5A54316C0302.additionalIncludes

//## begin module%5A54316C0302.includes preserve=yes
//## end module%5A54316C0302.includes

#ifndef CXOSAI37_h
#include "CXODAI37.hpp"
#endif
//## begin module%5A54316C0302.declarations preserve=no
//## end module%5A54316C0302.declarations

//## begin module%5A54316C0302.additionalDeclarations preserve=yes
//## end module%5A54316C0302.additionalDeclarations


// Class ProcessorAdvice 

ProcessorAdvice::ProcessorAdvice()
  //## begin ProcessorAdvice::ProcessorAdvice%5A542C000254_const.hasinit preserve=no
  //## end ProcessorAdvice::ProcessorAdvice%5A542C000254_const.hasinit
  //## begin ProcessorAdvice::ProcessorAdvice%5A542C000254_const.initialization preserve=yes
   : AdvantageMessage("0462","S907")
  //## end ProcessorAdvice::ProcessorAdvice%5A542C000254_const.initialization
{
  //## begin ProcessorAdvice::ProcessorAdvice%5A542C000254_const.body preserve=yes
  //## end ProcessorAdvice::ProcessorAdvice%5A542C000254_const.body
}


ProcessorAdvice::~ProcessorAdvice()
{
  //## begin ProcessorAdvice::~ProcessorAdvice%5A542C000254_dest.body preserve=yes
  //## end ProcessorAdvice::~ProcessorAdvice%5A542C000254_dest.body
}



//## Other Operations (implementation)
bool ProcessorAdvice::insert (Message& hMessage)
{
  //## begin ProcessorAdvice::insert%5A542C250200.body preserve=yes
   UseCase hUseCase("TANDEM","## AI37 READ 0462 PROC ADVICE",false);
   hProcessorAdvice* p = (hProcessorAdvice*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   if (memcmp(p->sTerminal,"        ",8) == 0)
   {
     memcpy(p->sENTITY_ID,p->sProc,6);
     memset(p->sENTITY_ID + 6,' ',2);
     memcpy(p->sENTITY_TYPE,"*P",2);
   }
   else
   {
     memcpy(p->sENTITY_ID,p->sTerminal,8);
     memcpy(p->sENTITY_TYPE,"AT",2);
   }
   ::Template::instance()->map("PROCESSORADVICE",(const char*)p);
   return deport(hMessage);
  //## end ProcessorAdvice::insert%5A542C250200.body
}

// Additional Declarations
  //## begin ProcessorAdvice%5A542C000254.declarations preserve=yes
  //## end ProcessorAdvice%5A542C000254.declarations

//## begin module%5A54316C0302.epilog preserve=yes
//## end module%5A54316C0302.epilog
