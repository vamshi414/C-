//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A5433000331.cm preserve=no
//	$Date:   31 Jan 2018 14:11:14  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5A5433000331.cm

//## begin module%5A5433000331.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A5433000331.cp

//## Module: CXOSAI39%5A5433000331; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI39.hpp

#ifndef CXOSAI39_h
#define CXOSAI39_h 1

//## begin module%5A5433000331.additionalIncludes preserve=no
//## end module%5A5433000331.additionalIncludes

//## begin module%5A5433000331.includes preserve=yes
//## end module%5A5433000331.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
//## begin module%5A5433000331.declarations preserve=no
//## end module%5A5433000331.declarations

//## begin module%5A5433000331.additionalDeclarations preserve=yes
//## end module%5A5433000331.additionalDeclarations


//## begin TerminalAdmin%5A542C930030.preface preserve=yes
//## end TerminalAdmin%5A542C930030.preface

//## Class: TerminalAdmin%5A542C930030
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport TerminalAdmin : public AdvantageMessage  //## Inherits: <unnamed>%5A542C9E03BC
{
  //## begin TerminalAdmin%5A542C930030.initialDeclarations preserve=yes
  //## end TerminalAdmin%5A542C930030.initialDeclarations

  public:
    //## Constructors (generated)
      TerminalAdmin();

    //## Destructor (generated)
      virtual ~TerminalAdmin();


    //## Other Operations (specified)
      //## Operation: insert%5A542CA9039D
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin TerminalAdmin%5A542C930030.public preserve=yes
      //## end TerminalAdmin%5A542C930030.public

  protected:
    // Additional Protected Declarations
      //## begin TerminalAdmin%5A542C930030.protected preserve=yes
      //## end TerminalAdmin%5A542C930030.protected

  private:
    // Additional Private Declarations
      //## begin TerminalAdmin%5A542C930030.private preserve=yes
      //## end TerminalAdmin%5A542C930030.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin TerminalAdmin%5A542C930030.implementation preserve=yes
      //## end TerminalAdmin%5A542C930030.implementation

};

//## begin TerminalAdmin%5A542C930030.postscript preserve=yes
//## end TerminalAdmin%5A542C930030.postscript

//## begin module%5A5433000331.epilog preserve=yes
//## end module%5A5433000331.epilog


#endif
