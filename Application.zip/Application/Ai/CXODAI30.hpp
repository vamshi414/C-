//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A541C6601DF.cm preserve=no
//	$Date:   31 Jan 2018 14:11:06  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5A541C6601DF.cm

//## begin module%5A541C6601DF.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A541C6601DF.cp

//## Module: CXOSAI30%5A541C6601DF; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI30.hpp

#ifndef CXOSAI30_h
#define CXOSAI30_h 1

//## begin module%5A541C6601DF.additionalIncludes preserve=no
//## end module%5A541C6601DF.additionalIncludes

//## begin module%5A541C6601DF.includes preserve=yes
//## end module%5A541C6601DF.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
//## begin module%5A541C6601DF.declarations preserve=no
//## end module%5A541C6601DF.declarations

//## begin module%5A541C6601DF.additionalDeclarations preserve=yes
//## end module%5A541C6601DF.additionalDeclarations


//## begin StdAdjustment%5A541BC002A6.preface preserve=yes
//## end StdAdjustment%5A541BC002A6.preface

//## Class: StdAdjustment%5A541BC002A6
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport StdAdjustment : public AdvantageMessage  //## Inherits: <unnamed>%5A541BD2036C
{
  //## begin StdAdjustment%5A541BC002A6.initialDeclarations preserve=yes
  //## end StdAdjustment%5A541BC002A6.initialDeclarations

  public:
    //## Constructors (generated)
      StdAdjustment();

    //## Destructor (generated)
      virtual ~StdAdjustment();


    //## Other Operations (specified)
      //## Operation: insert%5A541BDE024C
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin StdAdjustment%5A541BC002A6.public preserve=yes
      //## end StdAdjustment%5A541BC002A6.public

  protected:
    // Additional Protected Declarations
      //## begin StdAdjustment%5A541BC002A6.protected preserve=yes
      //## end StdAdjustment%5A541BC002A6.protected

  private:
    // Additional Private Declarations
      //## begin StdAdjustment%5A541BC002A6.private preserve=yes
      //## end StdAdjustment%5A541BC002A6.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin StdAdjustment%5A541BC002A6.implementation preserve=yes
      //## end StdAdjustment%5A541BC002A6.implementation

};

//## begin StdAdjustment%5A541BC002A6.postscript preserve=yes
//## end StdAdjustment%5A541BC002A6.postscript

//## begin module%5A541C6601DF.epilog preserve=yes
//## end module%5A541C6601DF.epilog


#endif
