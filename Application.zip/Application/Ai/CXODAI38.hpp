//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A5432690325.cm preserve=no
//	$Date:   31 Jan 2018 14:11:14  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5A5432690325.cm

//## begin module%5A5432690325.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A5432690325.cp

//## Module: CXOSAI38%5A5432690325; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI38.hpp

#ifndef CXOSAI38_h
#define CXOSAI38_h 1

//## begin module%5A5432690325.additionalIncludes preserve=no
//## end module%5A5432690325.additionalIncludes

//## begin module%5A5432690325.includes preserve=yes
//## end module%5A5432690325.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
//## begin module%5A5432690325.declarations preserve=no
//## end module%5A5432690325.declarations

//## begin module%5A5432690325.additionalDeclarations preserve=yes
//## end module%5A5432690325.additionalDeclarations


//## begin TerminalAdvice%5A542C4F004D.preface preserve=yes
//## end TerminalAdvice%5A542C4F004D.preface

//## Class: TerminalAdvice%5A542C4F004D
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport TerminalAdvice : public AdvantageMessage  //## Inherits: <unnamed>%5A542C600132
{
  //## begin TerminalAdvice%5A542C4F004D.initialDeclarations preserve=yes
  //## end TerminalAdvice%5A542C4F004D.initialDeclarations

  public:
    //## Constructors (generated)
      TerminalAdvice();

    //## Destructor (generated)
      virtual ~TerminalAdvice();


    //## Other Operations (specified)
      //## Operation: insert%5A542C640395
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin TerminalAdvice%5A542C4F004D.public preserve=yes
      //## end TerminalAdvice%5A542C4F004D.public

  protected:
    // Additional Protected Declarations
      //## begin TerminalAdvice%5A542C4F004D.protected preserve=yes
      //## end TerminalAdvice%5A542C4F004D.protected

  private:
    // Additional Private Declarations
      //## begin TerminalAdvice%5A542C4F004D.private preserve=yes
      //## end TerminalAdvice%5A542C4F004D.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin TerminalAdvice%5A542C4F004D.implementation preserve=yes
      //## end TerminalAdvice%5A542C4F004D.implementation

};

//## begin TerminalAdvice%5A542C4F004D.postscript preserve=yes
//## end TerminalAdvice%5A542C4F004D.postscript

//## begin module%5A5432690325.epilog preserve=yes
//## end module%5A5432690325.epilog


#endif
