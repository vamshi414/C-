//## begin module%1.4%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.4%.codegen_version

//## begin module%3F1D566E01A5.cm preserve=no
//	  %X% %Q% %Z% %W%
//## end module%3F1D566E01A5.cm

//## begin module%3F1D566E01A5.cp preserve=no
//	Copyright (c) 1998 - 2004
//	eFunds Corporation
//## end module%3F1D566E01A5.cp

//## Module: CXOSAI18%3F1D566E01A5; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Devel\Dn\Server\Application\Ai\CXOSAI18.cpp

//## begin module%3F1D566E01A5.additionalIncludes preserve=no
//## end module%3F1D566E01A5.additionalIncludes

//## begin module%3F1D566E01A5.includes preserve=yes
// $Date:   Jun 21 2017 08:37:38  $ $Author:   e1009839  $ $Revision:   1.5  $
#include "CXODIF03.hpp"
//## end module%3F1D566E01A5.includes

#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSPS01_h
#include "CXODPS01.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSAI18_h
#include "CXODAI18.hpp"
#endif


//## begin module%3F1D566E01A5.declarations preserve=no
//## end module%3F1D566E01A5.declarations

//## begin module%3F1D566E01A5.additionalDeclarations preserve=yes
//## end module%3F1D566E01A5.additionalDeclarations


// Class AdvantageVisaException

AdvantageVisaException::AdvantageVisaException()
  //## begin AdvantageVisaException::AdvantageVisaException%3F1D56A20109_const.hasinit preserve=no
  //## end AdvantageVisaException::AdvantageVisaException%3F1D56A20109_const.hasinit
  //## begin AdvantageVisaException::AdvantageVisaException%3F1D56A20109_const.initialization preserve=yes
   : AdvantageMessage("0466","VEXP")
  //## end AdvantageVisaException::AdvantageVisaException%3F1D56A20109_const.initialization
{
  //## begin AdvantageVisaException::AdvantageVisaException%3F1D56A20109_const.body preserve=yes
   memcpy(m_sID,"AI18",4);
  //## end AdvantageVisaException::AdvantageVisaException%3F1D56A20109_const.body
}


AdvantageVisaException::~AdvantageVisaException()
{
  //## begin AdvantageVisaException::~AdvantageVisaException%3F1D56A20109_dest.body preserve=yes
  //## end AdvantageVisaException::~AdvantageVisaException%3F1D56A20109_dest.body
}



//## Other Operations (implementation)
bool AdvantageVisaException::insert (Message& hMessage)
{
  //## begin AdvantageVisaException::insert%3F1D57EA0213.body preserve=yes
   m_hAuditSegment.reset();
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   m_lTstampHash = ntohl(pV13AdvantageHeader->lHdrTstamp2Hash);
   hVisaException* pException = (hVisaException*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   char sTranId[4];
   memcpy(sTranId,pException->sTranId,4);
#ifdef MVS
   if (AdvantageMessageProcessor::instance()->getAsciiInput())
     CodeTable::translate(sTranId,4,CodeTable::CX_ASCII_TO_EBCDIC);
#else
   if (!AdvantageMessageProcessor::instance()->getAsciiInput())
     CodeTable::translate(sTranId,4,CodeTable::CX_EBCDIC_TO_ASCII);
#endif
   if (memcmp(sTranId,"X107",4) == 0)
      ;
   else
      return false;
   UseCase hUseCase("DR","## DR68 IMPORT VISA EXCEPTION",false);
   hMessage.reset("AI LE ","S0002D");
   char* psBuffer = hMessage.data();
   m_hAuditSegment.setHashValue(m_lTstampHash);
   m_hAuditSegment.setSourceID(Application::instance()->name().c_str());
   m_hAuditSegment.write(&psBuffer);
   memcpy(psBuffer,"VEXP",4);
   psBuffer += 4;
   char szLen[5];
   memcpy(szLen, pException->sLength, 4);
   szLen[4] = '\0';
   memcpy(psBuffer,pException->sTranData,atoi(szLen));
   psBuffer += atoi(szLen);
   Message::instance(Message::INBOUND)->setDataLength(psBuffer - hMessage.data());
   return true;
  //## end AdvantageVisaException::insert%3F1D57EA0213.body
}

// Additional Declarations
  //## begin AdvantageVisaException%3F1D56A20109.declarations preserve=yes
  //## end AdvantageVisaException%3F1D56A20109.declarations

//## begin module%3F1D566E01A5.epilog preserve=yes
//## end module%3F1D566E01A5.epilog
