//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A512069034D.cm preserve=no
//	$Date:   Jul 27 2020 14:38:56  $ $Author:   e1009510  $
//	$Revision:   1.10  $
//## end module%5A512069034D.cm

//## begin module%5A512069034D.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A512069034D.cp

//## Module: CXOSAI26%5A512069034D; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI26.cpp

//## begin module%5A512069034D.additionalIncludes preserve=no
//## end module%5A512069034D.additionalIncludes

//## begin module%5A512069034D.includes preserve=yes
#ifdef _WIN32
#include <winsock2.h>
#endif
#ifdef _UNIX
#include <sys/types.h>
#include <netinet/in.h>
#include <inttypes.h>
#endif
#include <map>
#include "CXODIF10.hpp"
//## end module%5A512069034D.includes

#ifndef CXOSBC37_h
#include "CXODBC37.hpp"
#endif
#ifndef CXOSBS01_h
#include "CXODBS01.hpp"
#endif
#ifndef CXOSIF03_h
#include "CXODIF03.hpp"
#endif
#ifndef CXOSRS05_h
#include "CXODRS05.hpp"
#endif
#ifndef CXOSRU34_h
#include "CXODRU34.hpp"
#endif
#ifndef CXOSIF04_h
#include "CXODIF04.hpp"
#endif
#ifndef CXOSAI26_h
#include "CXODAI26.hpp"
#endif


//## begin module%5A512069034D.declarations preserve=no
//## end module%5A512069034D.declarations

//## begin module%5A512069034D.additionalDeclarations preserve=yes
//## end module%5A512069034D.additionalDeclarations


// Class Template

//## begin Template::Instance%5A512BD1015E.attr preserve=no  private: static Template* {V} 0
Template* Template::m_pInstance = 0;
//## end Template::Instance%5A512BD1015E.attr

Template::Template()
  //## begin Template::Template%5A51200D025B_const.hasinit preserve=no
  //## end Template::Template%5A51200D025B_const.hasinit
  //## begin Template::Template%5A51200D025B_const.initialization preserve=yes
  //## end Template::Template%5A51200D025B_const.initialization
{
  //## begin Template::Template%5A51200D025B_const.body preserve=yes
  //## end Template::Template%5A51200D025B_const.body
}


Template::~Template()
{
  //## begin Template::~Template%5A51200D025B_dest.body preserve=yes
  //## end Template::~Template%5A51200D025B_dest.body
}



//## Other Operations (implementation)
Template* Template::instance ()
{
  //## begin Template::instance%5A512BB8033B.body preserve=yes
   if (!m_pInstance)
      m_pInstance = new Template;
   return m_pInstance;
  //## end Template::instance%5A512BB8033B.body
}

int Template::map (const string& strToken, const char* pSegment, int iLength, short siRow)
{
  //## begin Template::map%5A512A08033D.body preserve=yes
   if (m_hTemplateToken.empty())
      if (!read())
         return -1;
   repositorysegment::Transaction* t = repositorysegment::Transaction::instance();
   multimap<string,TemplateToken,less <string> >::iterator p = m_hTemplateToken.find(strToken);
   pair<multimap<string,TemplateToken,less<string> >::iterator,multimap<string,TemplateToken,less<string> >::iterator> hRange;
   hRange = m_hTemplateToken.equal_range(strToken);
   if (hRange.first == hRange.second)
   {
      string strBuffer(strToken);
      strBuffer += " not mapped : ";
      IF::Trace::put(strBuffer.data(),strBuffer.length());
      return 0;
   }
   if (IF::Trace::getEnable())
   {
      string strBuffer(strToken);
      strBuffer += " is mapped : ";
      IF::Trace::put(strBuffer.data(),strBuffer.length());
   }
   multimap<string,TemplateToken,less<string> >::iterator pRange;
   int r = 0;
   for (pRange = hRange.first;pRange != hRange.second;++pRange)
      ++r;
   for (pRange = hRange.first;pRange != hRange.second;++pRange)
   {
      string strBuffer(strToken);
      strBuffer += " -> ";
      strBuffer += (*pRange).second.getName();
      strBuffer += " : ";
      const char* pszValue = pSegment + (*pRange).second.getOffset();
      int j = (iLength == -1 || r > 1) ? (*pRange).second.getLength() : iLength;
      char szTemp[PERCENTF];
      if ((*pRange).second.getType() == 'd')
      {
         double d = *(double*)pszValue;
         if (d == 0)
            pszValue = 0;
         else
         {
            j = sprintf(szTemp,"%01.0f",d);
            pszValue = szTemp;
         }
      }
      else
      if ((*pRange).second.getType() == 's'
         && (*pRange).second.getSigned() == true)
      {
         short k = ntohs(*(short*)pszValue);
         if ((*pRange).second.getVarChar())
         {
            j = k;
            pszValue += 2;
         }
         else
         {
            if (k == 0)
               pszValue = 0;
            else
            {
               j = sprintf(szTemp,"%01hd",k);
               pszValue = szTemp;
            }
         }
      }
      else
      if ((*pRange).second.getType() == 's'
         && (*pRange).second.getSigned() == false)
      {
         unsigned short k = ntohs(*(unsigned short*)pszValue);
         if ((*pRange).second.getVarChar())
         {
            j = k;
            pszValue += 2;
         }
         else
         {
            if (k == 0)
               pszValue = 0;
            else
            {
               j = sprintf(szTemp,"%01hu",k);
               pszValue = szTemp;
            }
         }
      }
      else
      if ((*pRange).second.getType() == 'i')
      {
         j = (*pRange).second.getLength();
         if (j == 4)
         {
            unsigned int k = ntohl(*(unsigned int*)pszValue);
            if (k == 0)
               pszValue = 0;
            else
            {
               if ((int)k < 0)
                  j = sprintf(szTemp, "%-01d", (int)k);
               else
                  j = sprintf(szTemp,"%01u",k);
               pszValue = szTemp;
            }
         }
         else
         {
            double k = Segment::lltof(ntohl(*(int*)pszValue),ntohl(*(int*)(pszValue + 4)));
            if (k == 0)
               pszValue = 0;
            else
            {
               j = sprintf(szTemp,"%01.0f",k);
               pszValue = szTemp;
            }
         }
      }
      else
      {
         int k = 0;
         for (k = 0;k < j;++k)
         {
            if (pszValue[k] != ' ')
               break;
         }
         if (j == k)
            pszValue = 0;
      }
      if (pszValue)
      {
         string strColumn((*pRange).second.getName());
         if ((*pRange).second.getHexToChar())
         {
            string strValue;
            CodeTable::nibbleToByte(pszValue,j,strValue);
            t->set((*pRange).second.getIndex(),(*pRange).second.getTable().c_str(),strColumn.c_str(),strValue.data(),strValue.length(),siRow);
            if (Trace::getEnable())
            {
               string strText(strColumn);
               strText += " = ";
               strText.append(strValue);
               Trace::put(strText.data(),strText.length());
            }
         }
         else
         {
            t->set((*pRange).second.getIndex(),(*pRange).second.getTable().c_str(),strColumn.c_str(),pszValue,j,siRow);
            if (Trace::getEnable())
            {
               string strText(strColumn);
               strText += " = ";
               if (j)
                  strText.append(pszValue,j);
               Trace::put(strText.data(),strText.length());
            }
         }
         string strSEQ_NO((*pRange).second.getTable().substr(0,2));
         if (strSEQ_NO > "00"
            && strSEQ_NO < "99")
         {
            std::map<string,int,less<string> >::iterator p = m_hSEQ_NO.find((*pRange).second.getTable());
            if (p == m_hSEQ_NO.end())
            {
               m_hSEQ_NO[(*pRange).second.getTable()] = ++m_iIndex;
               p = m_hSEQ_NO.find((*pRange).second.getTable());
            }
            t->set((*p).second,(*pRange).second.getTable().c_str(),"SEQ_NO",strSEQ_NO.c_str(),2,siRow);
         }
      }
   }
   return 0;
  //## end Template::map%5A512A08033D.body
}

bool Template::read ()
{
  //## begin Template::read%5A51202801BC.body preserve=yes
#ifdef MVS
   FlatFile  hTemplateFile("JCL","CXODRS28");
#else
   FlatFile hTemplateFile("SOURCE","CXODRS28");
#endif
   if (!hTemplateFile.open())
      return false;
   char* psBuffer = new char[256];
   memset(psBuffer,' ',256);
   size_t m = 0;
   char cSegment = ' ';
   string strTable;
   string strName;
   string strToken;
   while (hTemplateFile.read(psBuffer,256,&m))
   {
      if (memcmp(psBuffer," /* +",5) == 0)
      {
         strToken.assign(psBuffer,5,m - 8);
         vector<string> hTokens;
         Buffer::parse(strToken,"-",hTokens);
         if (hTokens.size() == 3
            && hTokens[0] == "TOKEN")
            m_hSubToken.insert(atoi(hTokens[1].c_str()));
      }
      if (strstr(psBuffer," ~"))
      {
         vector<string> hTokens;
         Buffer::parse(string(psBuffer,m)," [];,",hTokens);
         int i = (hTokens[3] == "//") ? 3 : 2;
         char cType = 'a';
         int iLength = 1;
         bool bSigned = true;
         if (hTokens[0] == "double")
         {
            cType = 'd';
            iLength = 8;
         }
         else
         if (hTokens[0] == "short")
         {
            cType = 's';
            iLength = 2;
         }
         else
         if (hTokens[0] == "unsigned"
            && hTokens[1] == "short")
         {
            cType = 's';
            iLength = 2;
            bSigned = false;
         }
         else
         if (hTokens[0] == "int")
         {
            cType = 'i';
            iLength = (i == 2) ? 4 : 8;
         }
         else
         if (i == 3)
            iLength = atoi(hTokens[2].c_str());
         int iOffset = atoi(hTokens[i + 1].c_str());
         string strTable(hTokens[i + 2].substr(1));
         if (strTable != "DEV_ADMIN"
            && strTable != "SUBJECT_STATE"
            && strTable != "T_ENTITY_CUTOFF")
            strTable.append("YYYYMM",6);
         string strName(hTokens[i + 3]);
         Segment* pSegment = 0;
         void* pAddress = 0;
         short int iSize = 0;
         if (strToken.find(":") == string::npos)
         {
            TemplateToken hTemplateToken(pSegment,strName,iOffset,iLength,cType,pAddress,iSize);
            hTemplateToken.setTable(strTable);
            hTemplateToken.setIndex(m_iIndex++);
            hTemplateToken.setSigned(bSigned);
            hTemplateToken.setHexToChar(hTokens[hTokens.size() - 1] == "HEXTOCHAR");
            hTemplateToken.setVarChar(hTokens[hTokens.size() - 1] == "VARCHAR");
            m_hTemplateToken.insert(multimap<string,TemplateToken,less<string> >::value_type(strToken,hTemplateToken));
         }
         else
         {
            vector<string> hTokens;
            Buffer::parse(strToken,":",hTokens);
            int j = atoi(hTokens[1].c_str());
            char sType[9] = {"01234567"};
            string strFirst(hTokens[0]);
            strFirst.append(" ",1);
            string strColumn(strName);
            strColumn.append(" ",1);
            for (int i = 0;i < j;++i)
            {
               strColumn[strColumn.length() - 1] = sType[i];
               TemplateToken hTemplateToken(pSegment,strColumn,iOffset,iLength,cType,pAddress,iSize);
               hTemplateToken.setTable(strTable);
               hTemplateToken.setIndex(m_iIndex++);
               hTemplateToken.setSigned(bSigned);
               hTemplateToken.setHexToChar(hTokens[hTokens.size() - 1] == "HEXTOCHAR");
               hTemplateToken.setVarChar(hTokens[hTokens.size() - 1] == "VARCHAR");
               strFirst[strFirst.length() - 1] = sType[i];
               m_hTemplateToken.insert(multimap<string,TemplateToken,less<string> >::value_type(strFirst,hTemplateToken));
            }

         }
      }
   }
   delete [] psBuffer;
   return true;
  //## end Template::read%5A51202801BC.body
}

// Additional Declarations
  //## begin Template%5A51200D025B.declarations preserve=yes
  //## end Template%5A51200D025B.declarations

//## begin module%5A512069034D.epilog preserve=yes
//## end module%5A512069034D.epilog
