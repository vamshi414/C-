//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EB1CAE30169.cm preserve=no
//	$Date:   May 08 2020 09:17:44  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5EB1CAE30169.cm

//## begin module%5EB1CAE30169.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5EB1CAE30169.cp

//## Module: CXOSAI45%5EB1CAE30169; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI45.cpp

//## begin module%5EB1CAE30169.additionalIncludes preserve=no
//## end module%5EB1CAE30169.additionalIncludes

//## begin module%5EB1CAE30169.includes preserve=yes
//## end module%5EB1CAE30169.includes

#ifndef CXOSAI45_h
#include "CXODAI45.hpp"
#endif
//## begin module%5EB1CAE30169.declarations preserve=no
//## end module%5EB1CAE30169.declarations

//## begin module%5EB1CAE30169.additionalDeclarations preserve=yes
//## end module%5EB1CAE30169.additionalDeclarations


// Class APSegment

APSegment::APSegment()
  //## begin APSegment::APSegment%5EB1C9A503A0_const.hasinit preserve=no
  //## end APSegment::APSegment%5EB1C9A503A0_const.hasinit
  //## begin APSegment::APSegment%5EB1C9A503A0_const.initialization preserve=yes
  //## end APSegment::APSegment%5EB1C9A503A0_const.initialization
{
  //## begin APSegment::APSegment%5EB1C9A503A0_const.body preserve=yes
  //## end APSegment::APSegment%5EB1C9A503A0_const.body
}


APSegment::~APSegment()
{
  //## begin APSegment::~APSegment%5EB1C9A503A0_dest.body preserve=yes
  //## end APSegment::~APSegment%5EB1C9A503A0_dest.body
}



//## Other Operations (implementation)
bool APSegment::reformat (const reusable::string& strRecType, char* psFrom, char* psOLD_VALUE, char* psNEW_VALUE, bool bAsciiInput)
{
  //## begin APSegment::reformat%5EB1D2A800BB.body preserve=yes
   map<string,Fields*,less<string> >::iterator p = m_hFields.find(strRecType);
   if (p == m_hFields.end())
      return false;
   int iBuffer = 0;
   setField((*p).second,'~',psFrom,iBuffer,&psOLD_VALUE,bAsciiInput);
   setField((*p).second,'~',psFrom + iBuffer,iBuffer,&psNEW_VALUE,bAsciiInput);
   return true;
  //## end APSegment::reformat%5EB1D2A800BB.body
}

// Additional Declarations
  //## begin APSegment%5EB1C9A503A0.declarations preserve=yes
  //## end APSegment%5EB1C9A503A0.declarations

//## begin module%5EB1CAE30169.epilog preserve=yes
//## end module%5EB1CAE30169.epilog
