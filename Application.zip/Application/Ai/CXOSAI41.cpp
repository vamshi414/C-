//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A5433E900EA.cm preserve=no
//	$Date:   Oct 22 2020 14:12:36  $ $Author:   e3023547  $
//	$Revision:   1.4  $
//## end module%5A5433E900EA.cm

//## begin module%5A5433E900EA.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A5433E900EA.cp

//## Module: CXOSAI41%5A5433E900EA; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI41.cpp

//## begin module%5A5433E900EA.additionalIncludes preserve=no
//## end module%5A5433E900EA.additionalIncludes

//## begin module%5A5433E900EA.includes preserve=yes
//## end module%5A5433E900EA.includes

#ifndef CXOSIF08_h
#include "CXODIF08.hpp"
#endif
#ifndef CXOSRU40_h
#include "CXODRU40.hpp"
#endif
#ifndef CXOSAI41_h
#include "CXODAI41.hpp"
#endif


//## begin module%5A5433E900EA.declarations preserve=no
//## end module%5A5433E900EA.declarations

//## begin module%5A5433E900EA.additionalDeclarations preserve=yes
//## end module%5A5433E900EA.additionalDeclarations


// Class APCardMaintenance

APCardMaintenance::APCardMaintenance()
  //## begin APCardMaintenance::APCardMaintenance%5A542E8B00D7_const.hasinit preserve=no
  //## end APCardMaintenance::APCardMaintenance%5A542E8B00D7_const.hasinit
  //## begin APCardMaintenance::APCardMaintenance%5A542E8B00D7_const.initialization preserve=yes
   : AdvantageMessage("0850","F001")
  //## end APCardMaintenance::APCardMaintenance%5A542E8B00D7_const.initialization
{
  //## begin APCardMaintenance::APCardMaintenance%5A542E8B00D7_const.body preserve=yes
   memcpy(m_sID,"AI41",4);
  //## end APCardMaintenance::APCardMaintenance%5A542E8B00D7_const.body
}


APCardMaintenance::~APCardMaintenance()
{
  //## begin APCardMaintenance::~APCardMaintenance%5A542E8B00D7_dest.body preserve=yes
  //## end APCardMaintenance::~APCardMaintenance%5A542E8B00D7_dest.body
}



//## Other Operations (implementation)
bool APCardMaintenance::insert (Message& hMessage)
{
  //## begin APCardMaintenance::insert%5A542EA30001.body preserve=yes
   UseCase hUseCase("TANDEM","## AI41 READ 0850 AP CARD",false);
   new_hCardHolder* p = (new_hCardHolder*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   memset((char*)p + 4096,'\0',4096);
   char sTSTAMP_TRANS[17] = {"                "};
   DateTime::calcCentury(p->sTimeStamp,sTSTAMP_TRANS);
   memcpy(sTSTAMP_TRANS + 2,p->sTimeStamp,14);
   m_pTransaction->setTSTAMP_TRANS(sTSTAMP_TRANS);
   int i = 0;
   if (p->sFRDABA[10] != ' ')
      i = 1;
   memcpy(p->sINST_ID,p->sFRDABA + i,9);
   memcpy(p->sBUSINESS_KEY,p->sCardGroup,6);
   p->sBUSINESS_KEY[6] = '~';
   KeyRing::instance()->tokenize(p->sPan,19);
   memcpy(p->sBUSINESS_KEY + 7,p->sPan,19);
   switch (ntohs(p->siStepNo))
   {
      case 5:
         p->cRECORD_ACTION = 'A';
         break;
      case 6:
         p->cRECORD_ACTION = 'D';
         break;
      case 8:
         p->cRECORD_ACTION = 'C';
         break;
      default:
         p->cRECORD_ACTION = 'U';
   }
   m_hAPCardMaintenanceSegment.reformat(string(p->sRecType,4),(char*)p + 98,p->sOLD_VALUE,p->sNEW_VALUE,true);
   unsigned short j = 0;
   i = 0;
   int k = strlen(p->sOLD_VALUE);
   for (i = 0;i < k;i++)
	   j = 33 * j + p->sOLD_VALUE[i];
   k = strlen(p->sNEW_VALUE);
   for (i = 0;i < k;i++)
	   j = 33 * j + p->sNEW_VALUE[i];
   if (j > 32767)
	   j -= 32768;
   m_pTransaction->setUNIQUENESS_KEY((int)j);
   ::Template::instance()->map("CARDMAINT",(const char*)p);
   return deport(hMessage);
  //## end APCardMaintenance::insert%5A542EA30001.body
}

// Additional Declarations
  //## begin APCardMaintenance%5A542E8B00D7.declarations preserve=yes
  //## end APCardMaintenance%5A542E8B00D7.declarations

//## begin module%5A5433E900EA.epilog preserve=yes
//## end module%5A5433E900EA.epilog
