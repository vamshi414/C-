//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A52540E01D6.cm preserve=no
//	$Date:   May 01 2020 08:56:48  $ $Author:   e1009839  $
//	$Revision:   1.3  $
//## end module%5A52540E01D6.cm

//## begin module%5A52540E01D6.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A52540E01D6.cp

//## Module: CXOSAI28%5A52540E01D6; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI28.cpp

//## begin module%5A52540E01D6.additionalIncludes preserve=no
//## end module%5A52540E01D6.additionalIncludes

//## begin module%5A52540E01D6.includes preserve=yes
#include <sstream>
//## end module%5A52540E01D6.includes

#ifndef CXOSAI28_h
#include "CXODAI28.hpp"
#endif
//## begin module%5A52540E01D6.declarations preserve=no
//## end module%5A52540E01D6.declarations

//## begin module%5A52540E01D6.additionalDeclarations preserve=yes
//## end module%5A52540E01D6.additionalDeclarations


// Class NetstatDisplay

NetstatDisplay::NetstatDisplay()
  //## begin NetstatDisplay::NetstatDisplay%5A52529E00F7_const.hasinit preserve=no
  //## end NetstatDisplay::NetstatDisplay%5A52529E00F7_const.hasinit
  //## begin NetstatDisplay::NetstatDisplay%5A52529E00F7_const.initialization preserve=yes
   : AdvantageMessage("1511","S907")
  //## end NetstatDisplay::NetstatDisplay%5A52529E00F7_const.initialization
{
  //## begin NetstatDisplay::NetstatDisplay%5A52529E00F7_const.body preserve=yes
   memcpy(m_sID,"AI28",4);
  //## end NetstatDisplay::NetstatDisplay%5A52529E00F7_const.body
}


NetstatDisplay::~NetstatDisplay()
{
  //## begin NetstatDisplay::~NetstatDisplay%5A52529E00F7_dest.body preserve=yes
  //## end NetstatDisplay::~NetstatDisplay%5A52529E00F7_dest.body
}



//## Other Operations (implementation)
bool NetstatDisplay::insert (Message& hMessage)
{
  //## begin NetstatDisplay::insert%5A52530D00FD.body preserve=yes
   UseCase hUseCase("TANDEM","## AI28 READ 1511 NETSTAT",false);
   hNetstatDisplay* p = (hNetstatDisplay*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   if (ntohs(p->siNumberMsgs) < 1)
      return false;
#ifdef MVS
   if (getAsciiInput())
   {
      CodeTable::translate(p->sMsgPrefix,sizeof(p->sMsgPrefix),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(p->sMsgPrefix2nd,sizeof(p->sMsgPrefix2nd),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(p->sSubject,sizeof(p->sSubject),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(p->sOperatorID,sizeof(p->sOperatorID),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(p->sOriginProcess,((char*)(&p->siParmCount) - p->sOriginProcess),CodeTable::CX_ASCII_TO_EBCDIC);
      CodeTable::translate(p->sParms,sizeof(p->sParms),CodeTable::CX_ASCII_TO_EBCDIC);
      for (short m = 0;m < (ntohs(p->siNumberMsgs));m++)
         CodeTable::translate(p->MsgData[m].sText,sizeof(p->MsgData[m].sText),CodeTable::CX_ASCII_TO_EBCDIC);
   }
#else
   if (!getAsciiInput())
   {
      CodeTable::translate(p->sMsgPrefix,sizeof(p->sMsgPrefix),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(p->sMsgPrefix2nd,sizeof(p->sMsgPrefix2nd),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(p->sSubject,sizeof(p->sSubject),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(p->sOperatorID,sizeof(p->sOperatorID),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(p->sOriginProcess,((char*)(&p->siParmCount) - p->sOriginProcess),CodeTable::CX_EBCDIC_TO_ASCII);
      CodeTable::translate(p->sParms,sizeof(p->sParms),CodeTable::CX_EBCDIC_TO_ASCII);
      for (short m = 0;m < (ntohs(p->siNumberMsgs));m++)
         CodeTable::translate(p->MsgData[m].sText,sizeof(p->MsgData[m].sText),CodeTable::CX_EBCDIC_TO_ASCII);
   }
#endif
   setTSTAMP_TRANS(p->sMsgTstamp);
   database::UniquenessKey::hash(p->sSubject,8);
   database::UniquenessKey::hash((const char*)&p->siMsgNumber,2);
   m_pTransaction->setUNIQUENESS_KEY(database::UniquenessKey::getHash());
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   short siFoo = ntohs(p->siSubjectType);
   if (ntohs(p->siSubjectType) < 0
      || ntohs(p->siSubjectType) > 9999)
      p->siSubjectType = 0;
   memset((void*)&p->lCED_BUILD_NO,' ',1024);
   p->lCED_BUILD_NO = pV13AdvantageHeader->lCED_BUILD_NO;
   p->siSUBJECT_TYPE = 0;
   p->siLAST_UNIQUENES_KEY = 0;
   for (short m = 0;m < ntohs(p->siNumberMsgs);m++)
   {
      short siMsgLevel = ntohs(p->MsgData[m].siMsgLevel) >= 0 && ntohs(p->MsgData[m].siMsgLevel) < 10000 ? ntohs(p->MsgData[m].siMsgLevel) : 0;
      p->MsgData[m].siMsgLevel = htons(siMsgLevel);
      string strDEVICE_STATUS(p->MsgData[m].sText,6);
      rtrim(strDEVICE_STATUS);
      strDEVICE_STATUS.erase(std::remove(strDEVICE_STATUS.begin(),strDEVICE_STATUS.end(),'-'),strDEVICE_STATUS.end());
      strDEVICE_STATUS.resize(5,' ');
      memcpy(p->sDEVICE_STATUS,strDEVICE_STATUS.data(),5);
      string strSecond;
      if (ConfigurationRepository::instance()->translate("X_GASPER_STATUS_CODE",strDEVICE_STATUS,strSecond,string(""),string(""),-1,false))
      {
         p->cSUBJECT_STATE1 = strSecond[0];
         memcpy(p->sSUBJECT,p->sSubject,8);
         p->siSUBJECT_TYPE = p->siSubjectType;
         memcpy(p->sLAST_TSTAMP_TRANS,m_pTransaction->getTSTAMP_TRANS().data(),16);
         p->siLAST_UNIQUENES_KEY = htons((short)atoi(m_pTransaction->getUNIQUENESS_KEY().c_str()));
         p->cSUBJECT_STATE2 = strSecond[0];
         std::ostringstream oss;
         oss << ntohs(p->siMsgNumber);
         memcpy(p->sSTATE_REASON,oss.str().data(),min(size_t(5),oss.str().length()));
         ::Template::instance()->map("NETSTATDISPLAYSTATE",(const char*)p,-1,m);
      }
      else
         p->cSUBJECT_STATE1 = ' ';
      ::Template::instance()->map("NETSTATDISPLAY",(const char*)p,-1,m);
      ::Template::instance()->map("NETSTATDISPLAYDATA",(const char*)(&p->MsgData[m]),-1,m);
      UseCase::addItem();
   }
   return deport(hMessage);
  //## end NetstatDisplay::insert%5A52530D00FD.body
}

// Additional Declarations
  //## begin NetstatDisplay%5A52529E00F7.declarations preserve=yes
  //## end NetstatDisplay%5A52529E00F7.declarations

//## begin module%5A52540E01D6.epilog preserve=yes
//## end module%5A52540E01D6.epilog
