//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A5120680296.cm preserve=no
//	$Date:   Oct 02 2018 13:15:06  $ $Author:   e1009839  $
//	$Revision:   1.2  $
//## end module%5A5120680296.cm

//## begin module%5A5120680296.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A5120680296.cp

//## Module: CXOSAI26%5A5120680296; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.9D.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI26.hpp

#ifndef CXOSAI26_h
#define CXOSAI26_h 1

//## begin module%5A5120680296.additionalIncludes preserve=no
//## end module%5A5120680296.additionalIncludes

//## begin module%5A5120680296.includes preserve=yes
#include <set>
#include <map>
//## end module%5A5120680296.includes

#ifndef CXOSRS08_h
#include "CXODRS08.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class Transaction;
} // namespace repositorysegment

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

namespace IF {
class Trace;
} // namespace IF

//## Modelname: Connex Library::Segment_CAT%3471F0BE0219
namespace segment {
class Segment;
} // namespace segment

//## Modelname: Connex Library::Command_CAT%3459269903E2
namespace command {
class TemplateToken;

} // namespace command

//## begin module%5A5120680296.declarations preserve=no
//## end module%5A5120680296.declarations

//## begin module%5A5120680296.additionalDeclarations preserve=yes
//## end module%5A5120680296.additionalDeclarations


//## begin Template%5A51200D025B.preface preserve=yes
//## end Template%5A51200D025B.preface

//## Class: Template%5A51200D025B
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5A51247401FF;command::TemplateToken { -> F}
//## Uses: <unnamed>%5A5126D002D4;segment::Segment { -> F}
//## Uses: <unnamed>%5A512B61011D;IF::Trace { -> F}
//## Uses: <unnamed>%5A512C6903B6;repositorysegment::Transaction { -> F}
//## Uses: <unnamed>%5A5136EB01B7;reusable::Buffer { -> F}
//## Uses: <unnamed>%5A576BF802B4;IF::CodeTable { -> F}

class DllExport Template : public repositorysegment::Template  //## Inherits: <unnamed>%5A51201C00CD
{
  //## begin Template%5A51200D025B.initialDeclarations preserve=yes
  //## end Template%5A51200D025B.initialDeclarations

  public:
    //## Constructors (generated)
      Template();

    //## Destructor (generated)
      virtual ~Template();


    //## Other Operations (specified)
      //## Operation: instance%5A512BB8033B
      static Template* instance ();

      //## Operation: map%5A512A08033D
      int map (const string& strToken, const char* pSegment, int iLength = -1, short siRow = 0);

      //## Operation: read%5A51202801BC
      virtual bool read ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: SubToken%5A58B1570044
      const set<short>& getSubToken () const
      {
        //## begin Template::getSubToken%5A58B1570044.get preserve=no
        return m_hSubToken;
        //## end Template::getSubToken%5A58B1570044.get
      }


    // Additional Public Declarations
      //## begin Template%5A51200D025B.public preserve=yes
      //## end Template%5A51200D025B.public

  protected:
    // Additional Protected Declarations
      //## begin Template%5A51200D025B.protected preserve=yes
      //## end Template%5A51200D025B.protected

  private:
    // Additional Private Declarations
      //## begin Template%5A51200D025B.private preserve=yes
      //## end Template%5A51200D025B.private

  private: //## implementation
    // Data Members for Class Attributes

      //## Attribute: Instance%5A512BD1015E
      //## begin Template::Instance%5A512BD1015E.attr preserve=no  private: static Template* {V} 0
      static Template* m_pInstance;
      //## end Template::Instance%5A512BD1015E.attr

      //## Attribute: SEQ_NO%5ACB6ED50095
      //## begin Template::SEQ_NO%5ACB6ED50095.attr preserve=no  private: std::map<string,int,less<string> > {V} 
      std::map<string,int,less<string> > m_hSEQ_NO;
      //## end Template::SEQ_NO%5ACB6ED50095.attr

      //## begin Template::SubToken%5A58B1570044.attr preserve=no  public: set<short> {V} 
      set<short> m_hSubToken;
      //## end Template::SubToken%5A58B1570044.attr

    // Additional Implementation Declarations
      //## begin Template%5A51200D025B.implementation preserve=yes
      //## end Template%5A51200D025B.implementation

};

//## begin Template%5A51200D025B.postscript preserve=yes
//## end Template%5A51200D025B.postscript

//## begin module%5A5120680296.epilog preserve=yes
//## end module%5A5120680296.epilog


#endif
