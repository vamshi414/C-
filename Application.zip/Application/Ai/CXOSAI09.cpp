//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C6138430148.cm preserve=no
//	$Date:   Sep 03 2013 11:31:44  $ $Author:   e1009839  $
//	$Revision:   1.27  $
//## end module%3C6138430148.cm

//## begin module%3C6138430148.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C6138430148.cp

//## Module: CXOSAI09%3C6138430148; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Repos\datanavigatorserver\Windows\Build\Dn\Server\Application\Ai\CXOSAI09.cpp

//## begin module%3C6138430148.additionalIncludes preserve=no
//## end module%3C6138430148.additionalIncludes

//## begin module%3C6138430148.includes preserve=yes
// $Date:   Dec 02 2013 10:50:56  $ $Author:   e1024360  $ $Revision:   1.18  $
//## end module%3C6138430148.includes

#ifndef CXOSMN05_h
#include "CXODMN05.hpp"
#endif
#ifndef CXOSAI17_h
#include "CXODAI17.hpp"
#endif
#ifndef CXOSIF11_h
#include "CXODIF11.hpp"
#endif
#ifndef CXOSIF16_h
#include "CXODIF16.hpp"
#endif
#ifndef CXOSAI09_h
#include "CXODAI09.hpp"
#endif


//## begin module%3C6138430148.declarations preserve=no
//## end module%3C6138430148.declarations

//## begin module%3C6138430148.additionalDeclarations preserve=yes
//## end module%3C6138430148.additionalDeclarations


// Class AdvantageException 

AdvantageException::AdvantageException()
  //## begin AdvantageException::AdvantageException%3C6132D702FD_const.hasinit preserve=no
  //## end AdvantageException::AdvantageException%3C6132D702FD_const.hasinit
  //## begin AdvantageException::AdvantageException%3C6132D702FD_const.initialization preserve=yes
   : AdvantageMessage("0466","S200")
  //## end AdvantageException::AdvantageException%3C6132D702FD_const.initialization
{
  //## begin AdvantageException::AdvantageException%3C6132D702FD_const.body preserve=yes
   memcpy(m_sID,"AI09",4);
  //## end AdvantageException::AdvantageException%3C6132D702FD_const.body
}


AdvantageException::~AdvantageException()
{
  //## begin AdvantageException::~AdvantageException%3C6132D702FD_dest.body preserve=yes
  //## end AdvantageException::~AdvantageException%3C6132D702FD_dest.body
}



//## Other Operations (implementation)
bool AdvantageException::insert (Message& hMessage)
{
  //## begin AdvantageException::insert%3C61B5BF03D8.body preserve=yes
   UseCase hUseCase("TANDEM","## AD19 READ 0466 EXCEPTION",false);
   setSegmentID("S200");
   AdvantageMessage::insert(hMessage);
   if (m_hAdvantageCirrusEx92Adjustment.insert(hMessage))
      return true;
   if (m_hAdvantageStdAdjustment.insert(hMessage))
      return true;
   if (m_hAdvantagePlusAdjustment.insert(hMessage))
      return true;
   if (Extract::instance()->getCustomCode() == "EFTPOS")
   {
      if (m_hAdvantageAS2805Adjustment.insert(hMessage))
         return true;
   }
   else
      if (m_hAdvantage0466Exception.insert(hMessage))
         return true;
   return m_hAdvantageStdFee.insert(hMessage);
  //## end AdvantageException::insert%3C61B5BF03D8.body
}

// Additional Declarations
  //## begin AdvantageException%3C6132D702FD.declarations preserve=yes
  //## end AdvantageException%3C6132D702FD.declarations

//## begin module%3C6138430148.epilog preserve=yes
//## end module%3C6138430148.epilog
