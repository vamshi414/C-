//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5EB1CFA00085.cm preserve=no
//	$Date:   May 08 2020 09:17:28  $ $Author:   e1009839  $
//	$Revision:   1.0  $
//## end module%5EB1CFA00085.cm

//## begin module%5EB1CFA00085.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5EB1CFA00085.cp

//## Module: CXOSAI46%5EB1CFA00085; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI46.hpp

#ifndef CXOSAI46_h
#define CXOSAI46_h 1

//## begin module%5EB1CFA00085.additionalIncludes preserve=no
//## end module%5EB1CFA00085.additionalIncludes

//## begin module%5EB1CFA00085.includes preserve=yes
//## end module%5EB1CFA00085.includes

#ifndef CXOSAI45_h
#include "CXODAI45.hpp"
#endif
//## begin module%5EB1CFA00085.declarations preserve=no
//## end module%5EB1CFA00085.declarations

//## begin module%5EB1CFA00085.additionalDeclarations preserve=yes
//## end module%5EB1CFA00085.additionalDeclarations


//## begin APCardMaintenanceSegment%5EB1CF5B0370.preface preserve=yes
//## end APCardMaintenanceSegment%5EB1CF5B0370.preface

//## Class: APCardMaintenanceSegment%5EB1CF5B0370
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



class DllExport APCardMaintenanceSegment : public APSegment  //## Inherits: <unnamed>%5EB1CF710089
{
  //## begin APCardMaintenanceSegment%5EB1CF5B0370.initialDeclarations preserve=yes
  //## end APCardMaintenanceSegment%5EB1CF5B0370.initialDeclarations

  public:
    //## Constructors (generated)
      APCardMaintenanceSegment();

    //## Destructor (generated)
      virtual ~APCardMaintenanceSegment();

    // Additional Public Declarations
      //## begin APCardMaintenanceSegment%5EB1CF5B0370.public preserve=yes
      //## end APCardMaintenanceSegment%5EB1CF5B0370.public

  protected:
    // Additional Protected Declarations
      //## begin APCardMaintenanceSegment%5EB1CF5B0370.protected preserve=yes
      //## end APCardMaintenanceSegment%5EB1CF5B0370.protected

  private:
    // Additional Private Declarations
      //## begin APCardMaintenanceSegment%5EB1CF5B0370.private preserve=yes
      //## end APCardMaintenanceSegment%5EB1CF5B0370.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin APCardMaintenanceSegment%5EB1CF5B0370.implementation preserve=yes
      //## end APCardMaintenanceSegment%5EB1CF5B0370.implementation

};

//## begin APCardMaintenanceSegment%5EB1CF5B0370.postscript preserve=yes
//## end APCardMaintenanceSegment%5EB1CF5B0370.postscript

//## begin module%5EB1CFA00085.epilog preserve=yes
//## end module%5EB1CFA00085.epilog


#endif
