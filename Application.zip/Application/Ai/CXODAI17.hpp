//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C613A8B036B.cm preserve=no
//	$Date:   Mar 16 2020 11:36:52  $ $Author:   e1009839  $
//	$Revision:   1.19  $
//## end module%3C613A8B036B.cm

//## begin module%3C613A8B036B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C613A8B036B.cp

//## Module: CXOSAI17%3C613A8B036B; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI17.hpp

#ifndef CXOSAI17_h
#define CXOSAI17_h 1

//## begin module%3C613A8B036B.additionalIncludes preserve=no
//## end module%3C613A8B036B.additionalIncludes

//## begin module%3C613A8B036B.includes preserve=yes
#include <map>
#include <vector>
#include "CXODAI25.hpp"
#include "CXODAI27.hpp"
#include "CXODAI28.hpp"
class AdvantageMessage450Lcm;
class AdvantageMessage600Lcm;
//## end module%3C613A8B036B.includes

#ifndef CXOSAI21_h
#include "CXODAI21.hpp"
#endif
#ifndef CXOSSI02_h
#include "CXODSI02.hpp"
#endif

//## Modelname: DataNavigator Foundation::RepositorySegment_CAT%394E273800F0
namespace repositorysegment {
class Transaction;
} // namespace repositorysegment

//## Modelname: DataNavigator Foundation::SwitchInterface_CAT%358EB6E20186
namespace switchinterface {
class Hash;
class SwitchInterface;
} // namespace switchinterface

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class Exception;
class SettledAdjustment;
class NetstatDisplay;
class NetstatStatus;
class Financial;
class AdvantageElectronicJournal;
class AdvantageTerminalAdmin;
class AdvantageTerminalAdvice;
class AdvantageProcessorAdvice;
class AdvantageException;
class AdvantageSettledAdjustment;
class AdvantageNetstatStatus;
class AdvantageNetstatDisplay;
class AdvantageAPAcctMaintenance;
class AdvantageAPCardMaintenance;
class AdvantageAPFraudMaintenance;
class AdvantageFinancial;
class Message622;
class AdvantageMessage622;
class APFraudMaintenance;
class APAcctMaintenance;
class APCardMaintenance;
class ElectronicJournal;
class TerminalAdmin;
class TerminalAdvice;
class ProcessorAdvice;
//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class Database;
} // namespace database

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class Buffer;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Log;
} // namespace IF

namespace database {
class License;
} // namespace database

namespace IF {
class Console;
class CodeTable;
class Message;
class Trace;
class Extract;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;

} // namespace monitor

//## begin module%3C613A8B036B.declarations preserve=no
//## end module%3C613A8B036B.declarations

//## begin module%3C613A8B036B.additionalDeclarations preserve=yes
class AdvantageMessage622;
//## end module%3C613A8B036B.additionalDeclarations


//## begin AdvantageMessageProcessor%3C612F8D0119.preface preserve=yes
//## end AdvantageMessageProcessor%3C612F8D0119.preface

//## Class: AdvantageMessageProcessor%3C612F8D0119
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3C63C81B0242;IF::Message { -> F}
//## Uses: <unnamed>%3C63C82A0157;IF::CodeTable { -> F}
//## Uses: <unnamed>%3C63C87C01C5;IF::Trace { -> F}
//## Uses: <unnamed>%3C63C87F038A;IF::Log { -> F}
//## Uses: <unnamed>%3C63C9C80119;database::Database { -> F}
//## Uses: <unnamed>%3C63C9CD02EE;database::License { -> F}
//## Uses: <unnamed>%3C63C9E403D8;switchinterface::SwitchInterface { -> F}
//## Uses: <unnamed>%3C63C9FC0196;switchinterface::Hash { -> F}
//## Uses: <unnamed>%3C64040D02BF;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3C6405730109;IF::Extract { -> F}
//## Uses: <unnamed>%3E96C01100AB;monitor::UseCase { -> F}
//## Uses: <unnamed>%3EF727A700AB;IF::Console { -> F}
//## Uses: <unnamed>%5114C79000A3;reusable::Buffer { -> F}
//## Uses: <unnamed>%5A54C35D0311;repositorysegment::Transaction { -> F}

class AdvantageMessageProcessor : public switchinterface::MessageProcessor  //## Inherits: <unnamed>%3C612FB302EE
{
  //## begin AdvantageMessageProcessor%3C612F8D0119.initialDeclarations preserve=yes
  //## end AdvantageMessageProcessor%3C612F8D0119.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageMessageProcessor();

    //## Destructor (generated)
      virtual ~AdvantageMessageProcessor();


    //## Other Operations (specified)
      //## Operation: dispatch%3C61A91B031C
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<!-- AdvantageMessageProcessor::dispatch : Preconditions
      //	-->
      //	<h3>FIS Advantage Log File
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface accepts
      //	messages in version 1.3 format.
      //	The Connex on NonStop message code (MSG^CODE (0)) value
      //	in the log header identifies the type of message.
      //	The DataNavigator server loads the following messages:
      //	<p>
      //	<table>
      //	<tr>
      //	<th>MSG^CODE (0)
      //	<th>Type
      //	<th>Data Repository Table
      //	<tr>
      //	<td>0400
      //	<td>Financial
      //	<td>FIN_L<i>yyyymm</i> and FIN_RECORD<i>yyyymm</i>
      //	<tr>
      //	<td>0401
      //	<td>Fraud alert
      //	<td>FIN_L<i>yyyymm</i> and FIN_RECORD<i>yyyymm</i>
      //	<tr>
      //	<td>0410
      //	<td>Settled exception
      //	<td>FIN_L<i>yyyymm</i> and FIN_RECORD<i>yyyymm</i>
      //	<tr>
      //	<td>0450
      //	<td>Negative file maintenance
      //	<td>AUDIT_MAINT_L<i>yyyymm</i>
      //	<tr>
      //	<td>0461
      //	<td>Device totals
      //	<td>DEV_ADMIN_L<i>yyyymm</i> and DEV_ADMIN
      //	<tr>
      //	<td>0461
      //	<td>Device cutoff
      //	<td>T_ENTITY_CUTOFF
      //	<tr>
      //	<td>0462
      //	<td>PI administration
      //	<td>T_ENTITY_CUTOFF
      //	<tr>
      //	<td>0466
      //	<td>Logged exception
      //	<td>FIN_L<i>yyyymm</i> and FIN_RECORD<i>yyyymm</i>
      //	<tr>
      //	<td>0483
      //	<td>ATM cash management
      //	<td>DEV_ADMIN_L<i>yyyymm</i> and DEV_ADMIN
      //	<tr>
      //	<td>0623
      //	<td>ATM electronic journal
      //	<td>ATM_EJ_REC<i>yyyymm</i>
      //	<tr>
      //	<td>0850
      //	<td>AP card maintenance
      //	<td>AUDIT_MAINT_L<i>yyyymm</i>
      //	<tr>
      //	<td>0860
      //	<td>AP account maintenance
      //	<td>AUDIT_MAINT_L<i>yyyymm</i>
      //	<tr>
      //	<td>1511
      //	<td>Status display
      //	<td>STAT_REC_L<i>yyyymm</i>
      //	<tr>
      //	<td>1521
      //	<td>Status alert
      //	<td>STAT_REC_L<i>yyyymm</i>
      //	</table>
      //	<p>
      //	For device totals messages, the following function codes
      //	are loaded:
      //	<ul>
      //	<li>570 - device totals
      //	<li>572 - device cutoff
      //	<li>573 - device subtotals
      //	<li>595 - device current condition
      //	</ul>
      //	<p>
      //	For ATM cash management messages, the following function
      //	codes are loaded:
      //	<ul>
      //	<li>583 - cash add
      //	<li>584 - cash subtract
      //	<li>585 - cash replace
      //	</ul>
      //	<p>
      //	<!-- release V02.1B.R001 -->
      //	The Connex on NonStop switch is integrated with FIS
      //	Fraud Navigator.
      //	FIS Fraud Navigator analyzes payment transactions that
      //	occur at the issuer, acquirer or transaction switch in
      //	real time as part of the inline authorization path, or
      //	post-authorization for subsequent follow-up.
      //	FIS Fraud Navigator combines flexible rules creation and
      //	management, system-generated alerts and a wide range of
      //	off-the-shelf reports in an economical, easy-to-use
      //	system.
      //	If a transaction is impacted (either blocked or allowed
      //	by rules) by Fraud Navigator, the rule names are logged
      //	with the financial transaction.
      //	DataNavigator saves the rule names in the financial
      //	transaction repository to provide the information during
      //	transaction research.
      //
      //	<!-- /release -->
      //	<p>
      //	PA-DSS:  this input file contains the PAN and expiration
      //	date in the clear.
      //	</p>
      //	</body>
      virtual int dispatch ();

      //## Operation: initialization%3C61A91D01F4
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>MS
      //	<!-- AdvantageMessageProcessor::initialization
      //	Preconditions -->
      //	<h3>Message Filter
      //	<p>
      //	By default, the Connex on HP interface processes
      //	financial, status, administrative, electronic journal
      //	and AP maintenance transactions.
      //	The message codes are listed above in the description of
      //	the log file.
      //	Message codes from this list can be dropped by
      //	configuring a DROPREC entry in the Custom Table Data for
      //	the Connex on HP interface task.
      //	Specify DROPREC as the key and a tilde-delimited list of
      //	message codes as the data (e.g. code DROPREC,0850~0860!
      //	to drop the AP maintenance records).
      //	<p>
      //	Custom Table Data definitions are in the Custom Tables
      //	folder in the CR Client for the DataNavigator Server.
      //	</body>
      virtual int initialization ();

      //## Operation: initialization2%5E6BA5C60208
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>MS
      //	<!-- AdvantageMessageProcessor::initialization
      //	Preconditions -->
      //	<h3>Message Filter
      //	<p>
      //	By default, the Connex on HP interface processes
      //	financial, status, administrative, electronic journal
      //	and AP maintenance transactions.
      //	The message codes are listed above in the description of
      //	the log file.
      //	Message codes from this list can be dropped by
      //	configuring a DROPREC entry in the Custom Table Data for
      //	the Connex on HP interface task.
      //	Specify DROPREC as the key and a tilde-delimited list of
      //	message codes as the data (e.g. code DROPREC,0850~0860!
      //	to drop the AP maintenance records).
      //	<p>
      //	Custom Table Data definitions are in the Custom Tables
      //	folder in the CR Client for the DataNavigator Server.
      //	</body>
      int initialization2 ();

      //## Operation: instance%3C62D8AE0213
      static AdvantageMessageProcessor* instance ();

      //## Operation: reset%3C643CBC003E
      virtual int reset ();

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: AsciiInput%3C62DA3E0290
      const bool getAsciiInput () const
      {
        //## begin AdvantageMessageProcessor::getAsciiInput%3C62DA3E0290.get preserve=no
        return m_bAsciiInput;
        //## end AdvantageMessageProcessor::getAsciiInput%3C62DA3E0290.get
      }

      void setAsciiInput (bool value)
      {
        //## begin AdvantageMessageProcessor::setAsciiInput%3C62DA3E0290.set preserve=no
        m_bAsciiInput = value;
        //## end AdvantageMessageProcessor::setAsciiInput%3C62DA3E0290.set
      }


      //## Attribute: MessageCode%3C62DAE200CB
      const reusable::string& getMessageCode () const
      {
        //## begin AdvantageMessageProcessor::getMessageCode%3C62DAE200CB.get preserve=no
        return m_strMessageCode;
        //## end AdvantageMessageProcessor::getMessageCode%3C62DAE200CB.get
      }


      //## Attribute: TranClassLength%3C62DC49002E
      const int& getTranClassLength () const
      {
        //## begin AdvantageMessageProcessor::getTranClassLength%3C62DC49002E.get preserve=no
        return m_lTranClassLength;
        //## end AdvantageMessageProcessor::getTranClassLength%3C62DC49002E.get
      }


      //## Attribute: TranClassOffset%3C62DC5D0196
      const int& getTranClassOffset () const
      {
        //## begin AdvantageMessageProcessor::getTranClassOffset%3C62DC5D0196.get preserve=no
        return m_lTranClassOffset;
        //## end AdvantageMessageProcessor::getTranClassOffset%3C62DC5D0196.get
      }


      //## Attribute: Version%3C62DAA50251
      const int getVersion () const
      {
        //## begin AdvantageMessageProcessor::getVersion%3C62DAA50251.get preserve=no
        return m_iVersion;
        //## end AdvantageMessageProcessor::getVersion%3C62DAA50251.get
      }

      void setVersion (int value)
      {
        //## begin AdvantageMessageProcessor::setVersion%3C62DAA50251.set preserve=no
        m_iVersion = value;
        //## end AdvantageMessageProcessor::setVersion%3C62DAA50251.set
      }


    // Additional Public Declarations
      //## begin AdvantageMessageProcessor%3C612F8D0119.public preserve=yes
#ifdef _WIN64
      void addToMessageList (const string& strMessageCode, const long long lMessageClass);
#else
      void addToMessageList (const string& strMessageCode, const long lMessageClass);
#endif
      //## end AdvantageMessageProcessor%3C612F8D0119.public
  protected:
    // Additional Protected Declarations
      //## begin AdvantageMessageProcessor%3C612F8D0119.protected preserve=yes
      //## end AdvantageMessageProcessor%3C612F8D0119.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageMessageProcessor%3C612F8D0119.private preserve=yes
#ifdef _WIN64
      typedef map<string,long long,less<string> > MessageList;
#else
      typedef map<string,long,less<string> > MessageList;
#endif
      //## end AdvantageMessageProcessor%3C612F8D0119.private
  private: //## implementation
    // Data Members for Class Attributes

      //## begin AdvantageMessageProcessor::AsciiInput%3C62DA3E0290.attr preserve=no  public: bool {V} true
      bool m_bAsciiInput;
      //## end AdvantageMessageProcessor::AsciiInput%3C62DA3E0290.attr

      //## Attribute: Instance%3C62D8C8037A
      //## begin AdvantageMessageProcessor::Instance%3C62D8C8037A.attr preserve=no  private: static AdvantageMessageProcessor* {V} 0
      static AdvantageMessageProcessor* m_pInstance;
      //## end AdvantageMessageProcessor::Instance%3C62D8C8037A.attr

      //## begin AdvantageMessageProcessor::MessageCode%3C62DAE200CB.attr preserve=no  public: reusable::string {V} 
      reusable::string m_strMessageCode;
      //## end AdvantageMessageProcessor::MessageCode%3C62DAE200CB.attr

      //## begin AdvantageMessageProcessor::TranClassLength%3C62DC49002E.attr preserve=no  public: int {V} 0
      int m_lTranClassLength;
      //## end AdvantageMessageProcessor::TranClassLength%3C62DC49002E.attr

      //## begin AdvantageMessageProcessor::TranClassOffset%3C62DC5D0196.attr preserve=no  public: int {V} 0
      int m_lTranClassOffset;
      //## end AdvantageMessageProcessor::TranClassOffset%3C62DC5D0196.attr

      //## begin AdvantageMessageProcessor::Version%3C62DAA50251.attr preserve=no  public: int {V} 130
      int m_iVersion;
      //## end AdvantageMessageProcessor::Version%3C62DAA50251.attr

    // Data Members for Associations

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%528CEC6A0075
      //## Role: AdvantageMessageProcessor::<m_pInvalidAuthorization>%528CEC6A03C0
      //## begin AdvantageMessageProcessor::<m_pInvalidAuthorization>%528CEC6A03C0.role preserve=no  public: InvalidAuthorization { -> RHgN}
      InvalidAuthorization *m_pInvalidAuthorization;
      //## end AdvantageMessageProcessor::<m_pInvalidAuthorization>%528CEC6A03C0.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5A5255A90178
      //## Role: AdvantageMessageProcessor::<m_pFinancial>%5A5255AA00AD
      //## begin AdvantageMessageProcessor::<m_pFinancial>%5A5255AA00AD.role preserve=no  public: Financial { -> RFHgN}
      Financial *m_pFinancial;
      //## end AdvantageMessageProcessor::<m_pFinancial>%5A5255AA00AD.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5A5255AF0151
      //## Role: AdvantageMessageProcessor::<m_pNetstatStatus>%5A5255B00006
      //## begin AdvantageMessageProcessor::<m_pNetstatStatus>%5A5255B00006.role preserve=no  public: NetstatStatus { -> RFHgN}
      NetstatStatus *m_pNetstatStatus;
      //## end AdvantageMessageProcessor::<m_pNetstatStatus>%5A5255B00006.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5A5255B402F1
      //## Role: AdvantageMessageProcessor::<m_pNetstatDisplay>%5A5255B50325
      //## begin AdvantageMessageProcessor::<m_pNetstatDisplay>%5A5255B50325.role preserve=no  public: NetstatDisplay { -> RFHgN}
      NetstatDisplay *m_pNetstatDisplay;
      //## end AdvantageMessageProcessor::<m_pNetstatDisplay>%5A5255B50325.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5AB2BAAC0195
      //## Role: AdvantageMessageProcessor::<m_pAPAcctMaintenance>%5AB2BAAD00DA
      //## begin AdvantageMessageProcessor::<m_pAPAcctMaintenance>%5AB2BAAD00DA.role preserve=no  public: APAcctMaintenance { -> RFHgN}
      APAcctMaintenance *m_pAPAcctMaintenance;
      //## end AdvantageMessageProcessor::<m_pAPAcctMaintenance>%5AB2BAAD00DA.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5AB2BAB5025D
      //## Role: AdvantageMessageProcessor::<m_pAPCardMaintenance>%5AB2BAB60233
      //## begin AdvantageMessageProcessor::<m_pAPCardMaintenance>%5AB2BAB60233.role preserve=no  public: APCardMaintenance { -> RFHgN}
      APCardMaintenance *m_pAPCardMaintenance;
      //## end AdvantageMessageProcessor::<m_pAPCardMaintenance>%5AB2BAB60233.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5AB2BABE0376
      //## Role: AdvantageMessageProcessor::<m_pAPFraudMaintenance>%5AB2BABF02BB
      //## begin AdvantageMessageProcessor::<m_pAPFraudMaintenance>%5AB2BABF02BB.role preserve=no  public: APFraudMaintenance { -> RFHgN}
      APFraudMaintenance *m_pAPFraudMaintenance;
      //## end AdvantageMessageProcessor::<m_pAPFraudMaintenance>%5AB2BABF02BB.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5AB2BADA032E
      //## Role: AdvantageMessageProcessor::<m_pElectronicJournal>%5AB2BADB0312
      //## begin AdvantageMessageProcessor::<m_pElectronicJournal>%5AB2BADB0312.role preserve=no  public: ElectronicJournal { -> RFHgN}
      ElectronicJournal *m_pElectronicJournal;
      //## end AdvantageMessageProcessor::<m_pElectronicJournal>%5AB2BADB0312.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5AB2BAE103C0
      //## Role: AdvantageMessageProcessor::<m_pException>%5AB2BAE203BB
      //## begin AdvantageMessageProcessor::<m_pException>%5AB2BAE203BB.role preserve=no  public: Exception { -> RFHgN}
      Exception *m_pException;
      //## end AdvantageMessageProcessor::<m_pException>%5AB2BAE203BB.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5AB2BAF2027B
      //## Role: AdvantageMessageProcessor::<m_pProcessorAdvice>%5AB2BAF30303
      //## begin AdvantageMessageProcessor::<m_pProcessorAdvice>%5AB2BAF30303.role preserve=no  public: ProcessorAdvice { -> RFHgN}
      ProcessorAdvice *m_pProcessorAdvice;
      //## end AdvantageMessageProcessor::<m_pProcessorAdvice>%5AB2BAF30303.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5AB2BAF901D2
      //## Role: AdvantageMessageProcessor::<m_pSettledAdjustment>%5AB2BAFA01F3
      //## begin AdvantageMessageProcessor::<m_pSettledAdjustment>%5AB2BAFA01F3.role preserve=no  public: SettledAdjustment { -> RFHgN}
      SettledAdjustment *m_pSettledAdjustment;
      //## end AdvantageMessageProcessor::<m_pSettledAdjustment>%5AB2BAFA01F3.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5AB2BB2A0286
      //## Role: AdvantageMessageProcessor::<m_pTerminalAdmin>%5AB2BB2B026B
      //## begin AdvantageMessageProcessor::<m_pTerminalAdmin>%5AB2BB2B026B.role preserve=no  public: TerminalAdmin { -> RFHgN}
      TerminalAdmin *m_pTerminalAdmin;
      //## end AdvantageMessageProcessor::<m_pTerminalAdmin>%5AB2BB2B026B.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5AB2BB33008A
      //## Role: AdvantageMessageProcessor::<m_pTerminalAdvice>%5AB2BB34011B
      //## begin AdvantageMessageProcessor::<m_pTerminalAdvice>%5AB2BB34011B.role preserve=no  public: TerminalAdvice { -> RFHgN}
      TerminalAdvice *m_pTerminalAdvice;
      //## end AdvantageMessageProcessor::<m_pTerminalAdvice>%5AB2BB34011B.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5ABEA43C01E4
      //## Role: AdvantageMessageProcessor::<m_pMessage622>%5ABEA43D0263
      //## begin AdvantageMessageProcessor::<m_pMessage622>%5ABEA43D0263.role preserve=no  public: Message622 { -> RFHgN}
      Message622 *m_pMessage622;
      //## end AdvantageMessageProcessor::<m_pMessage622>%5ABEA43D0263.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5E6BA88F012A
      //## Role: AdvantageMessageProcessor::<m_pAdvantageFinancial>%5E6BA890014D
      //## begin AdvantageMessageProcessor::<m_pAdvantageFinancial>%5E6BA890014D.role preserve=no  public: AdvantageFinancial { -> RFHgN}
      AdvantageFinancial *m_pAdvantageFinancial;
      //## end AdvantageMessageProcessor::<m_pAdvantageFinancial>%5E6BA890014D.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5E6BA89B02D5
      //## Role: AdvantageMessageProcessor::<m_pAdvantageException>%5E6BA89D027E
      //## begin AdvantageMessageProcessor::<m_pAdvantageException>%5E6BA89D027E.role preserve=no  public: AdvantageException { -> RFHgN}
      AdvantageException *m_pAdvantageException;
      //## end AdvantageMessageProcessor::<m_pAdvantageException>%5E6BA89D027E.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5E6BA8A70360
      //## Role: AdvantageMessageProcessor::<m_pAdvantageSettledAdjustment>%5E6BA8A9000C
      //## begin AdvantageMessageProcessor::<m_pAdvantageSettledAdjustment>%5E6BA8A9000C.role preserve=no  public: AdvantageSettledAdjustment { -> RFHgN}
      AdvantageSettledAdjustment *m_pAdvantageSettledAdjustment;
      //## end AdvantageMessageProcessor::<m_pAdvantageSettledAdjustment>%5E6BA8A9000C.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5E6BA8BB02AD
      //## Role: AdvantageMessageProcessor::<m_pAdvantageAPAcctMaintenance>%5E6BA8BD01D5
      //## begin AdvantageMessageProcessor::<m_pAdvantageAPAcctMaintenance>%5E6BA8BD01D5.role preserve=no  public: AdvantageAPAcctMaintenance { -> RFHgN}
      AdvantageAPAcctMaintenance *m_pAdvantageAPAcctMaintenance;
      //## end AdvantageMessageProcessor::<m_pAdvantageAPAcctMaintenance>%5E6BA8BD01D5.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5E6BA8E30395
      //## Role: AdvantageMessageProcessor::<m_pAdvantageAPCardMaintenance>%5E6BA8E50189
      //## begin AdvantageMessageProcessor::<m_pAdvantageAPCardMaintenance>%5E6BA8E50189.role preserve=no  public: AdvantageAPCardMaintenance { -> RFHgN}
      AdvantageAPCardMaintenance *m_pAdvantageAPCardMaintenance;
      //## end AdvantageMessageProcessor::<m_pAdvantageAPCardMaintenance>%5E6BA8E50189.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5E6BA8E90228
      //## Role: AdvantageMessageProcessor::<m_pAdvantageAPFraudMaintenance>%5E6BA8EA00F4
      //## begin AdvantageMessageProcessor::<m_pAdvantageAPFraudMaintenance>%5E6BA8EA00F4.role preserve=no  public: AdvantageAPFraudMaintenance { -> RFHgN}
      AdvantageAPFraudMaintenance *m_pAdvantageAPFraudMaintenance;
      //## end AdvantageMessageProcessor::<m_pAdvantageAPFraudMaintenance>%5E6BA8EA00F4.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5E6BA8FB01A9
      //## Role: AdvantageMessageProcessor::<m_pAdvantageProcessorAdvice>%5E6BA8FC032D
      //## begin AdvantageMessageProcessor::<m_pAdvantageProcessorAdvice>%5E6BA8FC032D.role preserve=no  public: AdvantageProcessorAdvice { -> RFHgN}
      AdvantageProcessorAdvice *m_pAdvantageProcessorAdvice;
      //## end AdvantageMessageProcessor::<m_pAdvantageProcessorAdvice>%5E6BA8FC032D.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5E6BA90202C1
      //## Role: AdvantageMessageProcessor::<m_pAdvantageTerminalAdvice>%5E6BA9030360
      //## begin AdvantageMessageProcessor::<m_pAdvantageTerminalAdvice>%5E6BA9030360.role preserve=no  public: AdvantageTerminalAdvice { -> RFHgN}
      AdvantageTerminalAdvice *m_pAdvantageTerminalAdvice;
      //## end AdvantageMessageProcessor::<m_pAdvantageTerminalAdvice>%5E6BA9030360.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5E6BA90702FB
      //## Role: AdvantageMessageProcessor::<m_pAdvantageTerminalAdmin>%5E6BA908039A
      //## begin AdvantageMessageProcessor::<m_pAdvantageTerminalAdmin>%5E6BA908039A.role preserve=no  public: AdvantageTerminalAdmin { -> RFHgN}
      AdvantageTerminalAdmin *m_pAdvantageTerminalAdmin;
      //## end AdvantageMessageProcessor::<m_pAdvantageTerminalAdmin>%5E6BA908039A.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5E6BA90E0386
      //## Role: AdvantageMessageProcessor::<m_pAdvantageNetstatDisplay>%5E6BA90F029F
      //## begin AdvantageMessageProcessor::<m_pAdvantageNetstatDisplay>%5E6BA90F029F.role preserve=no  public: AdvantageNetstatDisplay { -> RFHgN}
      AdvantageNetstatDisplay *m_pAdvantageNetstatDisplay;
      //## end AdvantageMessageProcessor::<m_pAdvantageNetstatDisplay>%5E6BA90F029F.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5E6BA9160063
      //## Role: AdvantageMessageProcessor::<m_pAdvantageNetstatStatus>%5E6BA917015E
      //## begin AdvantageMessageProcessor::<m_pAdvantageNetstatStatus>%5E6BA917015E.role preserve=no  public: AdvantageNetstatStatus { -> RFHgN}
      AdvantageNetstatStatus *m_pAdvantageNetstatStatus;
      //## end AdvantageMessageProcessor::<m_pAdvantageNetstatStatus>%5E6BA917015E.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5E6BA92100C7
      //## Role: AdvantageMessageProcessor::<m_pAdvantageElectronicJournal>%5E6BA9220108
      //## begin AdvantageMessageProcessor::<m_pAdvantageElectronicJournal>%5E6BA9220108.role preserve=no  public: AdvantageElectronicJournal { -> RFHgN}
      AdvantageElectronicJournal *m_pAdvantageElectronicJournal;
      //## end AdvantageMessageProcessor::<m_pAdvantageElectronicJournal>%5E6BA9220108.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5E6BA92A01DF
      //## Role: AdvantageMessageProcessor::<m_pAdvantageMessage622>%5E6BA92B02AC
      //## begin AdvantageMessageProcessor::<m_pAdvantageMessage622>%5E6BA92B02AC.role preserve=no  public: AdvantageMessage622 { -> RFHgN}
      AdvantageMessage622 *m_pAdvantageMessage622;
      //## end AdvantageMessageProcessor::<m_pAdvantageMessage622>%5E6BA92B02AC.role

    // Additional Implementation Declarations
      //## begin AdvantageMessageProcessor%3C612F8D0119.implementation preserve=yes
      MessageList m_hMessages;
      vector <string> m_hDropList;
      AdvantageMessage450Lcm* m_pAdvantageMessage450Lcm;
      AdvantageMessage600Lcm* m_pAdvantageMessage600Lcm;
      //## end AdvantageMessageProcessor%3C612F8D0119.implementation
};

//## begin AdvantageMessageProcessor%3C612F8D0119.postscript preserve=yes
//## end AdvantageMessageProcessor%3C612F8D0119.postscript

//## begin module%3C613A8B036B.epilog preserve=yes
//## end module%3C613A8B036B.epilog


#endif
