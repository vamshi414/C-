//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A543502007B.cm preserve=no
//	$Date:   May 08 2020 09:13:26  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%5A543502007B.cm

//## begin module%5A543502007B.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A543502007B.cp

//## Module: CXOSAI43%5A543502007B; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV03.0D.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI43.hpp

#ifndef CXOSAI43_h
#define CXOSAI43_h 1

//## begin module%5A543502007B.additionalIncludes preserve=no
//## end module%5A543502007B.additionalIncludes

//## begin module%5A543502007B.includes preserve=yes
//## end module%5A543502007B.includes

#ifndef CXOSAI48_h
#include "CXODAI48.hpp"
#endif
#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: Connex Library::Reusable_CAT%3453F15C01AA
namespace reusable {
class KeyRing;
} // namespace reusable

//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class DateTime;

} // namespace IF

//## begin module%5A543502007B.declarations preserve=no
//## end module%5A543502007B.declarations

//## begin module%5A543502007B.additionalDeclarations preserve=yes
//## end module%5A543502007B.additionalDeclarations


//## begin APFraudMaintenance%5A542F1A0357.preface preserve=yes
//## end APFraudMaintenance%5A542F1A0357.preface

//## Class: APFraudMaintenance%5A542F1A0357
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5A5697900334;IF::DateTime { -> F}
//## Uses: <unnamed>%5EB2D8340208;reusable::KeyRing { -> F}

class DllExport APFraudMaintenance : public AdvantageMessage  //## Inherits: <unnamed>%5A542F25008A
{
  //## begin APFraudMaintenance%5A542F1A0357.initialDeclarations preserve=yes
  //## end APFraudMaintenance%5A542F1A0357.initialDeclarations

  public:
    //## Constructors (generated)
      APFraudMaintenance();

    //## Destructor (generated)
      virtual ~APFraudMaintenance();


    //## Other Operations (specified)
      //## Operation: insert%5A5430E601CB
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin APFraudMaintenance%5A542F1A0357.public preserve=yes
      //## end APFraudMaintenance%5A542F1A0357.public

  protected:
    // Additional Protected Declarations
      //## begin APFraudMaintenance%5A542F1A0357.protected preserve=yes
      //## end APFraudMaintenance%5A542F1A0357.protected

  private:
    // Additional Private Declarations
      //## begin APFraudMaintenance%5A542F1A0357.private preserve=yes
      //## end APFraudMaintenance%5A542F1A0357.private

  private: //## implementation
    // Data Members for Associations

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5EB2CCCF004C
      //## Role: APFraudMaintenance::<m_hAPFraudMaintenanceSegment>%5EB2CCCF0341
      //## begin APFraudMaintenance::<m_hAPFraudMaintenanceSegment>%5EB2CCCF0341.role preserve=no  public: APFraudMaintenanceSegment { -> VHgN}
      APFraudMaintenanceSegment m_hAPFraudMaintenanceSegment;
      //## end APFraudMaintenance::<m_hAPFraudMaintenanceSegment>%5EB2CCCF0341.role

    // Additional Implementation Declarations
      //## begin APFraudMaintenance%5A542F1A0357.implementation preserve=yes
      //## end APFraudMaintenance%5A542F1A0357.implementation

};

//## begin APFraudMaintenance%5A542F1A0357.postscript preserve=yes
//## end APFraudMaintenance%5A542F1A0357.postscript

//## begin module%5A543502007B.epilog preserve=yes
//## end module%5A543502007B.epilog


#endif
