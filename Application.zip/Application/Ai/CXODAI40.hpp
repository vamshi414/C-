//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A5433660184.cm preserve=no
//	$Date:   May 15 2018 11:23:52  $ $Author:   e1009839  $
//	$Revision:   1.1  $
//## end module%5A5433660184.cm

//## begin module%5A5433660184.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A5433660184.cp

//## Module: CXOSAI40%5A5433660184; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXODAI40.hpp

#ifndef CXOSAI40_h
#define CXOSAI40_h 1

//## begin module%5A5433660184.additionalIncludes preserve=no
//## end module%5A5433660184.additionalIncludes

//## begin module%5A5433660184.includes preserve=yes
//## end module%5A5433660184.includes

#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif

//## Modelname: Connex Library::Database_CAT%3451F34D0218
namespace database {
class UniquenessKey;

} // namespace database

//## begin module%5A5433660184.declarations preserve=no
//## end module%5A5433660184.declarations

//## begin module%5A5433660184.additionalDeclarations preserve=yes
//## end module%5A5433660184.additionalDeclarations


//## begin ElectronicJournal%5A542CDF0095.preface preserve=yes
//## end ElectronicJournal%5A542CDF0095.preface

//## Class: ElectronicJournal%5A542CDF0095
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%5AF48BF4014B;database::UniquenessKey { -> F}

class DllExport ElectronicJournal : public AdvantageMessage  //## Inherits: <unnamed>%5A542CFC0358
{
  //## begin ElectronicJournal%5A542CDF0095.initialDeclarations preserve=yes
  //## end ElectronicJournal%5A542CDF0095.initialDeclarations

  public:
    //## Constructors (generated)
      ElectronicJournal();

    //## Destructor (generated)
      virtual ~ElectronicJournal();


    //## Other Operations (specified)
      //## Operation: insert%5A542D0100B4
      //## Preconditions:
      //	<body>
      //	<title>CG
      //	<h1>AI
      //	<h2>FI
      //	<h3>Configuration Repository
      //	<p>
      //	The FIS Connex on NonStop Transaction Interface uses the
      //	following tables to convert messages to the Data
      //	Navigator standard:
      //	<ul>
      //	<li><i>qualify</i>.DEVICE
      //	<li><i>qualify</i>.INSTITUTION
      //	<li><i>qualify</i>.ONLINE_NETWORK
      //	<li><i>qualify</i>.PROCESSOR
      //	<li><i>qualify</i>.X_ADV_CARD_LOGO
      //	<li><i>qualify</i>.X_ADV_CARD_TYPE
      //	<li><i>qualify</i>.X_ADV_PROC_CODE
      //	<li><i>qualify</i>.X_ADV_MSG_CODE
      //	<li><i>qualify</i>.X_CIRR_ADJ_REASON
      //	<li><i>qualify</i>.X_CIRR_PROC_CODE
      //	<li><i>qualify</i>.X_INST_ID_RECON
      //	<li><i>qualify</i>.X_PLUS_CRCT_REASON
      //	<li><i>qualify</i>.X_PLUS_PROC_CODE
      //	<li><i>qualify</i>.X_VISA_ADJ_REASON
      //	<li><i>qualify</i>.X_VISA_PROC_CODE
      //	</ul>
      //	</p>
      //	</body>
      virtual bool insert (Message& hMessage);

    // Additional Public Declarations
      //## begin ElectronicJournal%5A542CDF0095.public preserve=yes
      //## end ElectronicJournal%5A542CDF0095.public

  protected:
    // Additional Protected Declarations
      //## begin ElectronicJournal%5A542CDF0095.protected preserve=yes
      //## end ElectronicJournal%5A542CDF0095.protected

  private:
    // Additional Private Declarations
      //## begin ElectronicJournal%5A542CDF0095.private preserve=yes
      //## end ElectronicJournal%5A542CDF0095.private

  private: //## implementation
    // Additional Implementation Declarations
      //## begin ElectronicJournal%5A542CDF0095.implementation preserve=yes
      //## end ElectronicJournal%5A542CDF0095.implementation

};

//## begin ElectronicJournal%5A542CDF0095.postscript preserve=yes
//## end ElectronicJournal%5A542CDF0095.postscript

//## begin module%5A5433660184.epilog preserve=yes
//## end module%5A5433660184.epilog


#endif
