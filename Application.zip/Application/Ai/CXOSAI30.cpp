//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%5A541C6703D6.cm preserve=no
//	$Date:   May 20 2021 09:46:36  $ $Author:   E5350313  $
//	$Revision:   1.3  $
//## end module%5A541C6703D6.cm

//## begin module%5A541C6703D6.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%5A541C6703D6.cp

//## Module: CXOSAI30%5A541C6703D6; Package body
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\bV02.8B.R001\Windows\Build\Dn\Server\Application\Ai\CXOSAI30.cpp

//## begin module%5A541C6703D6.additionalIncludes preserve=no
//## end module%5A541C6703D6.additionalIncludes

//## begin module%5A541C6703D6.includes preserve=yes
//## end module%5A541C6703D6.includes

#ifndef CXOSAI30_h
#include "CXODAI30.hpp"
#endif
//## begin module%5A541C6703D6.declarations preserve=no
//## end module%5A541C6703D6.declarations

//## begin module%5A541C6703D6.additionalDeclarations preserve=yes
//## end module%5A541C6703D6.additionalDeclarations


// Class StdAdjustment 

StdAdjustment::StdAdjustment()
  //## begin StdAdjustment::StdAdjustment%5A541BC002A6_const.hasinit preserve=no
  //## end StdAdjustment::StdAdjustment%5A541BC002A6_const.hasinit
  //## begin StdAdjustment::StdAdjustment%5A541BC002A6_const.initialization preserve=yes
   : AdvantageMessage("0466","S200")
  //## end StdAdjustment::StdAdjustment%5A541BC002A6_const.initialization
{
  //## begin StdAdjustment::StdAdjustment%5A541BC002A6_const.body preserve=yes
  //## end StdAdjustment::StdAdjustment%5A541BC002A6_const.body
}


StdAdjustment::~StdAdjustment()
{
  //## begin StdAdjustment::~StdAdjustment%5A541BC002A6_dest.body preserve=yes
  //## end StdAdjustment::~StdAdjustment%5A541BC002A6_dest.body
}



//## Other Operations (implementation)
bool StdAdjustment::insert (Message& hMessage)
{
  //## begin StdAdjustment::insert%5A541BDE024C.body preserve=yes
   hStdAdjustment* p = (hStdAdjustment*)(hMessage.data() + sizeof(hV13AdvantageHeader));
   if (memcmp(p->sTranId,"X030",4) == 0
      && (memcmp(p->sUsageCode,"08",2) == 0
      || memcmp(p->sUsageCode,"10",2) == 0))
      return false;
   if (memcmp(p->sUsageCode,"08",2))
      return false;
   UseCase hUseCase("TANDEM","## AI30 READ 0466 EXCEPTION",false);
   hV13AdvantageHeader* pV13AdvantageHeader = (hV13AdvantageHeader*)hMessage.data();
   setTSTAMP_TRANS(pV13AdvantageHeader->sFiller);
   database::UniquenessKey::hash(p->sPan,16);
   database::UniquenessKey::hash(p->sTermRef,12);
   database::UniquenessKey::hash(p->sTermSeq,6);
   m_pTransaction->setUNIQUENESS_KEY(database::UniquenessKey::getHash());
   ::Template::instance()->map("STANDARDADJUSTMENT",(const char*)p);
   return deport(hMessage);
  //## end StdAdjustment::insert%5A541BDE024C.body
}

// Additional Declarations
  //## begin StdAdjustment%5A541BC002A6.declarations preserve=yes
  //## end StdAdjustment%5A541BC002A6.declarations

//## begin module%5A541C6703D6.epilog preserve=yes
//## end module%5A541C6703D6.epilog
