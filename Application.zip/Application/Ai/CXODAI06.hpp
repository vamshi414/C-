//## begin module%1.10%.codegen_version preserve=yes
//   Read the documentation to learn more about C++ code generator
//   versioning.
//## end module%1.10%.codegen_version

//## begin module%3C61375C0261.cm preserve=no
//	$Date:   Mar 13 2019 06:44:50  $ $Author:   E5350313  $
//	$Revision:   1.16  $
//## end module%3C61375C0261.cm

//## begin module%3C61375C0261.cp preserve=no
//	Copyright (c) 1997 - 2012
//	FIS
//## end module%3C61375C0261.cp

//## Module: CXOSAI06%3C61375C0261; Package specification
//## Subsystem: AI%3597E7CC007A
//	.
//## Source file: C:\Dn_codes\V03.0A.R002\Dn\Server\Application\Ai\CXODAI06.hpp

#ifndef CXOSAI06_h
#define CXOSAI06_h 1

//## begin module%3C61375C0261.additionalIncludes preserve=no
//## end module%3C61375C0261.additionalIncludes

//## begin module%3C61375C0261.includes preserve=yes
// $Date:   Mar 13 2019 06:44:50  $ $Author:   E5350313  $ $Revision:   1.16  $
//## end module%3C61375C0261.includes

#ifndef CXOSBS07_h
#include "CXODBS07.hpp"
#endif
#ifndef CXOSAI01_h
#include "CXODAI01.hpp"
#endif
#ifndef CXOSRS43_h
#include "CXODRS43.hpp"
#endif
#ifndef CXOSRSA7_h
#include "CXODRSA7.hpp"
#endif

//## Modelname: DataNavigator Foundation::Configuration_CAT%390F33ED01BC
namespace configuration {
class ConfigurationRepository;
} // namespace configuration

class AdvantageMessageProcessor;
//## Modelname: Connex Library::IF_CAT%3451F55F009E
namespace IF {
class Message;
class DateTime;
class CodeTable;
} // namespace IF

//## Modelname: Connex Library::Monitor_CAT%3451FA660166
namespace monitor {
class UseCase;
} // namespace monitor

//## Modelname: Connex Library::Process_CAT%3453F1510045
namespace process {
class Application;

} // namespace process

//## begin module%3C61375C0261.declarations preserve=no
//## end module%3C61375C0261.declarations

//## begin module%3C61375C0261.additionalDeclarations preserve=yes
//## end module%3C61375C0261.additionalDeclarations


//## begin AdvantageNetstatDisplay%3C61324602DE.preface preserve=yes
//## end AdvantageNetstatDisplay%3C61324602DE.preface

//## Class: AdvantageNetstatDisplay%3C61324602DE
//## Category: Platform \: FIS Connex on HP::AcquirerInterface_CAT%354B34020262
//## Subsystem: AI%3597E7CC007A
//## Persistence: Transient
//## Cardinality/Multiplicity: n



//## Uses: <unnamed>%3C712288035B;IF::DateTime { -> F}
//## Uses: <unnamed>%3C7122A603A9;IF::Message { -> F}
//## Uses: <unnamed>%3C71236302FD;process::Application { -> F}
//## Uses: <unnamed>%3C71239702FD;configuration::ConfigurationRepository { -> F}
//## Uses: <unnamed>%3C7123A20261;monitor::UseCase { -> F}
//## Uses: <unnamed>%3C7123EA032C;AdvantageMessageProcessor { -> F}
//## Uses: <unnamed>%3C7123EF009C;IF::CodeTable { -> F}

class AdvantageNetstatDisplay : public AdvantageMessage  //## Inherits: <unnamed>%3C61325C037A
{
  //## begin AdvantageNetstatDisplay%3C61324602DE.initialDeclarations preserve=yes
  //## end AdvantageNetstatDisplay%3C61324602DE.initialDeclarations

  public:
    //## Constructors (generated)
      AdvantageNetstatDisplay();

    //## Destructor (generated)
      virtual ~AdvantageNetstatDisplay();


    //## Other Operations (specified)
      //## Operation: insert%3C618D7501D4
      virtual bool insert (Message& hMessage);

    //## Get and Set Operations for Class Attributes (generated)

      //## Attribute: AD16Message%5C885F1D0079
      const bool& getAD16Message () const
      {
        //## begin AdvantageNetstatDisplay::getAD16Message%5C885F1D0079.get preserve=no
        return m_bAD16Message;
        //## end AdvantageNetstatDisplay::getAD16Message%5C885F1D0079.get
      }

      void setAD16Message (const bool& value)
      {
        //## begin AdvantageNetstatDisplay::setAD16Message%5C885F1D0079.set preserve=no
        m_bAD16Message = value;
        //## end AdvantageNetstatDisplay::setAD16Message%5C885F1D0079.set
      }


    // Additional Public Declarations
      //## begin AdvantageNetstatDisplay%3C61324602DE.public preserve=yes
      //## end AdvantageNetstatDisplay%3C61324602DE.public

  protected:
    // Additional Protected Declarations
      //## begin AdvantageNetstatDisplay%3C61324602DE.protected preserve=yes
      //## end AdvantageNetstatDisplay%3C61324602DE.protected

  private:
    // Additional Private Declarations
      //## begin AdvantageNetstatDisplay%3C61324602DE.private preserve=yes
      //## end AdvantageNetstatDisplay%3C61324602DE.private

  private: //## implementation
    // Data Members for Class Attributes

      //## begin AdvantageNetstatDisplay::AD16Message%5C885F1D0079.attr preserve=no  public: bool {V} false
      bool m_bAD16Message;
      //## end AdvantageNetstatDisplay::AD16Message%5C885F1D0079.attr

    // Data Members for Associations

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3C618D8F0203
      //## Role: AdvantageNetstatDisplay::<m_hListSegment>%3C618D90009C
      //## begin AdvantageNetstatDisplay::<m_hListSegment>%3C618D90009C.role preserve=no  public: segment::ListSegment { -> VHgN}
      segment::ListSegment m_hListSegment;
      //## end AdvantageNetstatDisplay::<m_hListSegment>%3C618D90009C.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%3D63A95101C5
      //## Role: AdvantageNetstatDisplay::<m_hEntityStatusSegment>%3D63A9510399
      //## begin AdvantageNetstatDisplay::<m_hEntityStatusSegment>%3D63A9510399.role preserve=no  public: repositorysegment::EntityStatusSegment { -> VHgN}
      repositorysegment::EntityStatusSegment m_hEntityStatusSegment;
      //## end AdvantageNetstatDisplay::<m_hEntityStatusSegment>%3D63A9510399.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5C8860A80304
      //## Role: AdvantageNetstatDisplay::<m_hAIMSBillingSegment>%5C8860A90268
      //## begin AdvantageNetstatDisplay::<m_hAIMSBillingSegment>%5C8860A90268.role preserve=no  public: repositorysegment::AIMSBillingSegment { -> VHgN}
      repositorysegment::AIMSBillingSegment m_hAIMSBillingSegment;
      //## end AdvantageNetstatDisplay::<m_hAIMSBillingSegment>%5C8860A90268.role

      //## Association: Platform \: FIS Connex on HP::AcquirerInterface_CAT::<unnamed>%5C8860F602E5
      //## Role: AdvantageNetstatDisplay::<m_pAdvantageMessageProcessor>%5C8860F7020A
      //## begin AdvantageNetstatDisplay::<m_pAdvantageMessageProcessor>%5C8860F7020A.role preserve=no  public: AdvantageMessageProcessor { -> RFHgN}
      AdvantageMessageProcessor *m_pAdvantageMessageProcessor;
      //## end AdvantageNetstatDisplay::<m_pAdvantageMessageProcessor>%5C8860F7020A.role

    // Additional Implementation Declarations
      //## begin AdvantageNetstatDisplay%3C61324602DE.implementation preserve=yes
      //## end AdvantageNetstatDisplay%3C61324602DE.implementation

};

//## begin AdvantageNetstatDisplay%3C61324602DE.postscript preserve=yes
//## end AdvantageNetstatDisplay%3C61324602DE.postscript

//## begin module%3C61375C0261.epilog preserve=yes
//## end module%3C61375C0261.epilog


#endif
