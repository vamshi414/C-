select * from nqp7fisa.ems_case where case_no = '20191229000021';
select case_no, C.case_id, T.reason_code from nqp7fisa.ems_case C INNER JOIN nqp7fisa.EMS_TRANSITION T
ON T.CASE_ID = C.CASE_ID AND T.TSTAMP_CREATED = C.STATE_TSTAMP
WHERE NET_RULES = 'VN3' AND REQUEST_TYPE = 'CHB1' AND STATUS = 'SDRC' 
AND C.PROC_ID_ACQ_B = 'INT148' AND T.REASON_CODE NOT IN ('10','11','12','13');
select ref_data_iss_fmt, net_id_iss, adl_data_priv_iss from nqp7fisa.fin_record201804 where tstamp_trans = '2018041615003483' and uniqueness_key = 1917;
select * from nqp7FISA.ems_case where case_id = 310031;
select * from nqp7fisa.ems_case where tstamp_trans = '2018050522495327';
select * from nqp7fisa.ems_phase where case_id = 286361;
select * from nqp7fisa.ems_case_vnt where case_id = 298049;
select * from nqp7fisa.ems_phase_vnt where 
--vrol_case_no = '1002402474';
case_id = 287575 order by tstamp_created asc;
select * from nqp7fisa.ems_phase_vnt_vrol where case_id = 296124;
select * from nqp7fisa.ems_document where case_id = 296124;
select * from nqp7fisa.ems_fraud_vnt where case_id = 7372387;
select acq_ref_no from nqp7fisa.ems_national_net where case_id = 290215;
select state_tstamp from nqp7fisa.ems_case c inner join nqp7fisa.ems_case_vnt v on v.case_id = c.case_id
where net_id_ems = 'VNT' and request_type = 'FDRA' AND STATUS in ('REJ1') AND VCR_IND = 'Y'
and state_tstamp < '2018042000000000';

select * from nqp7fisa.ems_data_chg where case_id = 283487 order by tstamp_created asc;
select * from nqp7fisa.di_data where import_key = '20180411004846';

select * from nqp7fisa.ems_transition where case_id = 310031 order by tstamp_created asc;

select * from nqp7fisa.api_queue_control where case_id = 286151 order by queue_id asc;
select * from nqp7fisa.api_queue_control where queue_id = 523;

select * from nqp7fisa.api_queue_control where API_RESULT = 'Error: Transition failed from CHB1/PNDR to CHB1/REJR';
select c.case_id,c.case_no,t.user_id,t.request_type_prev, t.status_prev, t.request_type_next, t.status_next, 
A.QUEUE_ID, A.API_RESULT, a.retry_count, a.api_state 
from nqp7fisa.ems_case c inner join nqp7fisa.api_queue_control a on a.case_id = c.case_id
inner join nqp7fisa.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
where request_type = 'CHB1' and STATUS = 'PNDR' order by c.case_id asc;
--and a.api_result = 'Error: Transition failed from CHB1/PNDR to CHB1/REJR';

select * from nqp7fisa.api_queue_request where queue_id in
(select queue_id from nqp7fisa.api_queue_control where case_id = 296124) order by queue_id asc;
select * from nqp7fisa.api_queue_request where queue_id in (select queue_id from nqp7fisa.api_queue_control where req_type = 'TII') order by queue_id desc; 
select * from nqp7fisa.api_queue_response where queue_id in
(select queue_id from nqp7fisa.api_queue_control where case_id = 296124) order by queue_id asc;
SELECT distinct case_id, tstamp_created from nqp7fisa.api_queue_control where queue_id in (
select queue_id from nqp7fisa.api_queue_response where data_buffer like '%User tried to submit%') order by case_id asc;
select * from nqp7fisa.api_qevent_log where queue_id =52234 order by tstamp_created asc;

--SELECT                                                 
--'INSERT INTO nqp7fisa.EMS_TRANSITION (CASE_ID,PHASE_TSTAMP,TSTAMP_CREATED,SEQ_NO,USER_ID,REQUEST_TYPE_PREV,STATUS_PREV,REQUEST_TYPE_NEXT,STATUS_NEXT,MANUAL_OVERRIDE,ACTION,ACTION_TO_CARDHLDR,REASON_CODE,AMT_ADJUSTMENT) VALUES (',               
--X.CASE_ID,','''||X.PHASE_TSTAMP||''',''2018042315300000''',                
-- '''1'',''SQL'','''||X.REQUEST_TYPE||''',',            
-- ''''||X.STATUS||''','''||X.REQUEST_TYPE||''',',       
--'''FWRD'',''N'','' '','''||X.ACTION_TO_CARDHLDR||''',',
--''''||X.REASON_CODE||''',',X.AMT_ADJUSTMENT,');'       
-- FROM                                                  
--   (                                                   
select c.case_id,request_type,status, t.phase_tstamp,t.reason_code,t.action_to_cardhldr,t.amt_adjustment,v.support_info
from nqp7fisa.ems_case c
inner join nqp7fisa.ems_transition t
on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7fisa.ems_phase_vnt v
on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
where support_info like '%Internal Error%';
--and request_type = 'FDRA')X;

select count(*)
from nqp7fisa.api_queue_response r
inner join nqp7fisa.api_queue_control a
on a.queue_id = r.queue_id
inner join nqp7fisa.ems_case c
on c.case_id = a.case_id
where data_buffer like '%settlement%'
and request_type = 'CHB1';

select * from nqp7fisa.assoc_tran_vnt where case_id = 7394750;
select * from nqp7fisa.assoc_tran where case_id = 7394750;

select c.case_id, c.state_tstamp, c.date_recon_net, n.acq_ref_no, a.arn, v.tran_type, v.tran_identifier
from nqp7fisa.ems_case c 
inner join nqp7fisa.ems_national_net n on n.case_id = c.case_id
inner join nqp7fisa.assoc_tran a on a.case_id = c.case_id
inner join nqp7fisa.assoc_tran_vnt v on v.ATR_SEQ_no = a.seq_no
where request_type = 'FDRA'
and status = 'REJ1';
--d state_tstamp > '2018042700000000';
AND v.tran_type like '02%';

SELECT DISTINCT A.CASE_ID, C.CASE_NO, c.status,p.tstamp_created,P.TI_EVENT_ID
FROM NQP1CAP1.API_QUEUE_CONTrOL A                                   
INNER JOIN NQP1CAP1.EMS_CASE C                                      
ON C.CASE_ID = A.CASE_ID                                            
inner join nqp1CAP1.ems_transition t                                
on t.case_id = C.CASE_ID                                            
AND T.TSTAMP_CREATED = C.STATE_TSTAMP                               
INNER JOIN NQP1CAP1.EMS_PHASE_VNT P                                 
ON P.CASE_ID = T.CASE_ID                                            
AND P.TSTAMP_CREATED = T.PHASE_TSTAMP                               
WHERE QUEUE_ID IN (                                                 
SELECT QUEUE_ID FROM                                                
NQP1CAP1.API_QUEUE_RESPONSE R                                       
WHERE R.DATA_BUFFER LIKE '%expire%');                                

--select c.case_id, acq_bin, net_id_iss,case_no, tstamp_trans,state_tstamp,c.request_type, status,merchant_cat_code, v.support_info
select c.case_id, case_no, pan_prefix, pan_suffix, retrieval_ref_no,iss_bin,acq_bin, net_id_ems,tstamp_local,c.amt_recon_net/100,
tran_identifier,h.reason_code,h.amt_adjustment/100,c.request_type,status,merchant_cat_code, state_tstamp,v.vrol_case_no,v.support_info
--select c.case_id, pan_prefix, net_id_acq,case_no, tstamp_trans,state_tstamp,c.request_type, status,merchant_cat_code, v.support_info
--select c.case_id, case_no, tstamp_trans,state_tstamp,rol_tran_id, request_type, status,v.support_info
from nqp7fisa.ems_case c
inner join nqp7fisa.ems_case_vnt u on u.case_id = c.case_id
inner join nqp7fisa.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7fisa.ems_phase_vnt v on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
inner join nqp7fisa.ems_phase h on h.case_id = t.case_id and h.tstamp_created = t.phase_tstamp
--inner join nqp7comn.institution i on i.inst_id = c.inst_id_recon_iss
where net_rules = 'VN3'
--and C.request_type like 'ADJ%' 
AND STATUS = 'CLOJ'
--and i.cust_id = 'FISB'
--and acq_bin in
--('272685','272906','277540','279058','292740','293593','298521','299074','299284','299991')
--AND V.SUPPORT_INFO LIKE '%access%'
--and h.user_role = 'I'
--AND ERR_VROL_MSG1 = 'W80';
order by support_info asc, state_tstamp asc;

Select c.case_id,case_no,status,rol_tran_id from nqp7fisa.ems_case c
inner join nqp7fisa.ems_case_vnt v on v.case_id = c.case_id
where case_type_ind = 'D' and tstamp_trans in ('2018010601465363',
'2018010601465366','2018030916363116','2018010320462963','2018040808284462','2018040603092527','2018041103093380');
Select queue_id,req_type from nqp7fisa.api_queue_control where case_id in (
Select case_id from nqp7fisa.ems_case where case_type_ind = 'D' and tstamp_trans in ('2018010601465363',
'2018010601465366','2018030916363116','2018010320462963','2018040808284462','2018040603092527','2018041103093380'))
And req_type like 'TI%';


select * from nqp7fisa.di_data where di_file_id = 4916169;

select c.inst_id_recon_acq,case_no,request_type,status,vrol_case_no from nqp7fisa.ems_case c 
inner join nqp7fisa.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7fisa.ems_phase_vnt v on v.case_id = c.case_id and v.tstamp_created = t.phase_tstamp
where c.case_id in (
286383,
286384,
286385,
286386,
286387,
286388,
286389,
286390,
286391,
286392,
286393,
286394,
286395,
286396,
286397,
286398,
286399,
286400,
286401,
286402,
286403)
and status NOT IN ('CLOA','CLTA','CLOC')
order by c.case_id asc;

select c.inst_id_recon_acq,case_no,request_type,status,vrol_case_no from nqp7mcdp.ems_case c 
inner join nqp7mcdp.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7mcdp.ems_phase_vnt v on v.case_id = c.case_id and v.tstamp_created = t.phase_tstamp
where c.case_id = 1629418;

select * from nqp7comn.institution where inst_id = '231379115';
select * from nqp7comn.x_net_inst_id where NET_INST_ID_CODE = '272685';


