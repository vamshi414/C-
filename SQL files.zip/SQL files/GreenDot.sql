select bank_id,'-',name,inst_id from nqp1comn.institution where bank_id in ('0GI5','0GI7','0GS5','0GU2','0G7P','0G8R','0R33') and cust_id = 'BCFS';



SELECT case_id, request_type_next,status_next FROM NQP1BCFS.EMS_TRANSITION WHERE TSTAMP_CREATED LIKE '201806%' 
AND CASE_ID IN (SELECT CASE_ID FROM NQP1BCFS.EMS_CASE WHERE INST_ID_ISS = '841091977')
AND status_next = 'SDRC' order by case_id;

select sum(amt_adjustment) from nqp1bcfs.ems_transition where case_id in 
(select case_id from nqp1bcFs.ems_case where inst_id_iss = '840235006' AND CASE_EXTENSION = 'VNT')
AND CASE_ID NOT IN (SELECT CASE_ID FROM NQP1BCFS.EMS_TRANSITION WHERE request_type_next = 'CHBQ' AND STATUS_NEXT = 'REJR' 
AND TSTAMP_CREATED LIKE '2018%')
and request_type_next = 'CHBQ' AND STATUS_NEXT = 'SDRC' AND TSTAMP_CREATED LIKE '2018%';

--Collaboration flow
--select COUNT(*) from nqp1bcfs.ems_transition where case_id in 
--select COUNT(*),sum(amt_adjustment) from nqp1bcfs.ems_transition where case_id in 
select C.CASE_ID, REQUEST_TYPE,STATUS,amt_adjustment from NQP1BCFS.EMS_CASE C
INNER JOIN nqp1bcfs.ems_transition T ON T.CASE_ID = C.CASE_ID where C.case_id in 
(select case_id from nqp1bcFs.ems_case where inst_id_iss = '881092431' AND CASE_EXTENSION = 'VNT' and casE_no like '2018%')
--and request_type_prev = 'PARB' and status_prev = 'SENT'
--and request_type_next = 'PARB' and status_next IN ('ACRD','CLTA') AND TSTAMP_CREATED LIKE '2018%';
and request_type_next = 'PARB' and status_next = 'SENT' AND T.TSTAMP_CREATED LIKE '2018%';

select COUNT(*),sum(amt_adjustment) from nqp1bcfs.ems_transition where case_id in 
(select case_id from nqp1bcFs.ems_case where inst_id_iss = '881092431' AND CASE_EXTENSION = 'VNT' and casE_no like '2018%')
and request_type_prev = 'PARB' and status_prev = 'SENT'
and request_type_next = 'PARB' and status_next = 'DNRD' AND TSTAMP_CREATED LIKE '2018%';

--Allocation flow
--select COUNT(*),sum(amt_adjustment) from nqp1bcfs.ems_transition where case_id in 
select C.CASE_ID, REQUEST_TYPE,STATUS,amt_adjustment,request_type_PREV,status_PREV from NQP1BCFS.EMS_CASE C
INNER JOIN nqp1bcfs.ems_transition T ON T.CASE_ID = C.CASE_ID where C.case_id in 
(select case_id from nqp1bcFs.ems_case where inst_id_iss = '840235006' AND CASE_EXTENSION = 'VNT' and casE_no like '2018%')
--AND CASE_ID NOT IN (SELECT CASE_ID FROM NQP1BCFS.EMS_TRANSITION WHERE request_type_next = 'ARB' AND STATUS_NEXT = 'RECD' 
--AND TSTAMP_CREATED LIKE '2018%')
and request_type_prev = 'PARB' and status_prev = 'RECD';
--And request_type_next = 'PARB' and status_next = 'DNST' AND TSTAMP_CREATED LIKE '2018%';
--And request_type_next = 'PARB' and status_next = 'CLTA' AND TSTAMP_CREATED LIKE '2018%';
--and request_type_next = 'PARB' and status_next = 'RECD' AND T.TSTAMP_CREATED LIKE '2018%';
--and request_type_next = 'ARB' and status_next = 'RECD' AND T.TSTAMP_CREATED LIKE '2018%';

select COUNT(*),sum(amt_adjustment) from nqp1bcfs.ems_transition where case_id in 
(select case_id from nqp1bcFs.ems_case where inst_id_iss = '840235006' AND CASE_EXTENSION = 'VNT' and casE_no like '2018%')
--and request_type_prev = 'PARB' and status_prev = 'SENT'
and request_type_next = 'PARB' and status_next = 'ACST' AND TSTAMP_CREATED LIKE '2018%';

select * from nqp1bcfs.ems_case where inst_id_iss ='881092431' and REQUEST_TYPE = 'PARB' AND STATUS ='SENT' AND CASE_EXTENSION='VNT';

select * from nqp1bcfs.ems_transition where case_id in 
(7269953,
7269952)
ORDER BY case_id asc,tstamp_Created asc;

select sum(amt_adjustment) from nqp1bcfs.ems_transition where case_id in 
(select case_id from nqp1bcFs.ems_case where inst_id_iss = '881092431' AND CASE_EXTENSION = 'VNT' and casE_no like '2018%')
and request_type_next = 'REP1' and TSTAMP_CREATED LIKE '2018%';

select case_no, bank_id, t.tstamp_created, request_type,status
from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_transition t on t.case_id = C.CaSE_ID
inner join nqp1comn.institution i on i.inst_id = c.inst_id_iss
where case_extension = 'VNT' AND INST_ID_ISS IN ('881092431','841091977','820410362','823620104','063100277','840235006')
AND STATUS LIKE 'CL%' AND T.REQUEST_TYPE_NEXT = 'CHB1' AND STATUS_NEXT LIKE 'CL%'
and i.cust_id = 'BCFS' order by bank_id asc;

990109545  

881092431  12 196935
841091977  14 203615
820410362  7  90865
823620104   3 45446 
063100277   3 13628
840235006  61 1207035

GreenDot
124302529
