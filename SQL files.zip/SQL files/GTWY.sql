select net_id_ems,PROC_ID_ACQ_B from nqp7mcdp.ems_case where proc_id_acq = 'INT010'; where case_no = '20200529000150';
select * from nqp7gtwy.ems_transition where request_type_prev = 'CHBQ' AND REQUEST_TYPE_NEXT = 'REP1' AND STATUS_NEXT = 'GETD'
ORDER BY TSTAMP_CREATED DESC;case_id = 2468513 order by tstamp_created;

select * from nqp7gtwy.ems_case where case_id = 2466505;
select * from nqp7gtwy.ems_phase where case_id = 2436633;
select * from nqp7gtwy.ems_case_vnt where case_id = 2361675;
select * from nqp7gtwy.ems_case_mci where case_id = 2466505;
select * from nqp7gtwy.ems_case_mci where claim_id = '200520820977';
select * from nqp7gtwy.ems_phase_mci where caSE_id = 2475229 order by tstamp_created asc;
select * from nqp7gtwy.ems_phase_vnt where case_id = 2468559 order by tstamp_created asc;
select * from nqp7gtwy.ems_phase_vnt_vrol where question_fields like '%<DisputeDueTo>NR</DisputeDueTo>%' order by case_id desc;--case_id= 2436990;
select * from nqp7gtwy.ems_document where case_id = 2449419 order by seq_no asc;
select * from nqp7gtwy.ems_data_chg where case_id = 2475229 order by tstamp_created asc;
select * from nqp7gtwy.ems_national_net where acq_ref_no = '55429509344637877361957';

SELECT * FROM NQP7GTWY.fin_l202006 where pan = 'EdILWqWiiRLcDsMn' and retrieval_ref_no = '20039912913';

select c.case_id,c.case_no,claim_id, request_Type,status, doc_type,export_ind, STATE_TSTAMP from nqp7gtwy.ems_case c
inner join nqp7gtwy.ems_case_mci m on m.case_id = c.case_id 
left outer join nqp7gtwy.ems_document d on d.case_id = c.case_id
where claim_id <> ' '  and export_ind not in ('X','N')
and request_type = 'CHB1'
order by claim_id asc;

select * from nqp7gtwy.assoc_tran_mci where case_id = 2419108;

select request_type,status from nqp7gtwy.ems_case c
inner join nqp7gtwy.api_queue_control a on a.case_id = c.case_id
where api_result like '%Socket%';

select * from nqp7gtwy.api_queue_control where case_id = 2442618 order by queue_id asc;
select * from nqp7gtwy.api_queue_control where queue_id = 208027;

select * from nqp7gtwy.api_queue_control where api_type = 'MQUE' and REQ_TYPE = 'MCIIREPUNW' order by queue_id desc;
select * from nqp7gtwy.api_queue_control where api_type = 'MQUE' and REQ_TYPE = 'MCIDOCCOMP' order by queue_id desc;
select * from nqp7gtwy.api_queue_control where api_type = 'MCOM' and req_type = 'CBStatusResponse' order by queue_id desc;
select * from nqp7gtwy.api_queue_control where api_type = 'VCR' and req_type = 'TII' order by queue_id desc;
select * from nqp7gtwy.api_queue_response where queue_id = 208027 ORDER BY SEQ_NO ASC;
select * from nqp7gtwy.api_queue_request where queue_id = 277350 ORDER BY SEQ_NO ASC;
select * from nqp7gtwy.message_log where tstamp_transmit like '20200511%' and msg_session = '265798';
select * from nqp7gtwy.message_log where sender = 'WSCLIENT';
select * from nqp7gtwy.api_queue_control where api_type = 'MCOM' and api_state = 'AF'
--in ('SP','PE','AS') AND RETRY_COUNT < 5
order by TSTamp_event desc;

select * from nqp7gtwy.api_qevent_log where queue_id = 208449 order by tstamp_created asc;

select * from nqp7gtwy.dx_data_control where date_recon = '20191031' and dx_file_type = 'MCTQR4' ORDER BY sched_time asc;
select * from nqp7gtwy.dx_data_control where date_recon = '20200319' and dx_file_type = 'MCMIN' ORDER BY dx_file_id DESC;
select * from nqp7gtwy.dx_data_20200319 where dx_file_id = 517165 and data_buffer like '%249641%' order by seq_no asc;
select * from nqp7gtwy.dx_data_20200319 where dx_file_id = 517165 and seq_no > 211 order by seq_no asc;
select * from nqp7gtwy.dx_data_control where dx_file_type LIKE '%DNB%' ORDER BY dx_file_id DESC;
select * from nqp7gtwy.dx_data_20200207 where dx_file_id = 515092 ORDER BY SEQ_NO ASC; 
--data_buffer like '%200243133372%';
dx_file_id in (509011,
509027,
509028,
509029,
509035,
509038,
509041,
509030,
509000);

select * from nqp7gtwy.di_data where 
di_file_id = 692095 order by transaction_no asc;
--data_buffer like '%200243049874%';
seLect a.queue_id,tstamp_event,tstamp_created,retry_count,REQ_TYPE
--req_type,request_type,status,c.case_id
,data_buffer 
from nqp7gtwy.api_queue_control a 
inner join nqp7gtwy.api_queue_response r on r.queue_id = a.queue_id
--inner join nqp7gtwy.ems_case c on c.case_id = a.case_id
--where data_buffer like '%Read timed out%'
where api_TYPE = 'MCOM'
and req_type = 'CBStatusResponse'
order by a.queue_id desc;

select * from nqp7gtwy.api_queue_request where queue_id in 
(select queue_id from nqp7gtwy.api_queue_control where case_id = 2463319) order by queue_id asc;
    select * from nqp7gtwy.api_queue_response where queue_id in
    --(select queue_id from nqp7gtwy.api_queue_control where api_type = 'MCOM' and req_type = 'CBStatusResponse') order by queue_id asc, seq_no asc;
    (select queue_id from nqp7gtwy.api_queue_control where case_id = 2463319) order by queue_id asc, seq_no asc;
SELECT * from nqp7gtwy.api_queue_control where queue_id in (
select queue_id from nqp7gtwy.api_queue_response where data_buffer like '%200521728602%') order by queue_id desc;


--select c.case_id,case_no,tstamp_trans,state_tstamp,rol_tran_id, c.request_type, status,vrol_case_no,tran_identifier,v.support_info
select distinct trim(leading '0' from iss_ica)iss_ica 
--c.CASE_id, case_no, t.tstamp_created, REASON_CODE, state_tstamp
--select C.case_id,case_no,tstamp_trans,c.request_type,status,STATE_TSTAMP,t.reason_code,doc_ind,reject_info
--, REQUEST_TYPE_PREV,STATUS_PREV,REQUEST_TYPE_NEXT,STATUS_NEXT
--select c.case_id, acq_bin, net_id_iss,case_no, tstamp_trans,state_tstamp,c.request_type, status,merchant_cat_code, v.support_info
--select distinct c.case_id, pan_prefix, net_id_acq,case_no, tstamp_trans,state_tstamp,c.request_type, status,merchant_cat_code, v.support_info
--select c.case_id, case_no, pan_prefix, pan_suffix, retrieval_ref_no,iss_bin,acq_bin, net_id_EMs,tstamp_local,c.amt_recon_net/100,
--tran_identifier,h.reason_code,h.amt_adjustment/100,c.request_type,status,merchant_cat_code, state_tstamp,v.vrol_case_no,v.support_info
from nqp7gtwy.ems_case c
--inner join nqp7gtwy.ems_case_vnt u on u.case_id = c.case_id
inner join nqp7gtwy.ems_case_mci m on m.case_id = c.case_id
--inner join nqp7gtwy.ems_transition t on t.case_id = c.case_id --and t.tstamp_created = c.state_tstamp
--inner join nqp7gtwy.ems_phase_vnt v on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
--inner join nqp7gtwy.ems_phase_mci m on m.case_id = t.case_id and m.tstamp_created = t.phase_tstamp
--inner join nqp7gtwy.ems_phase h on h.case_id = t.case_id and h.tstamp_created = t.phase_tstamp
--inner join nqp7gtwy.api_queue_control q on q.case_id = c.case_id
--inner join nqp7gtwy.api_queue_request r on r.queue_id = q.queue_id
where net_id_acq = 'MCI'
--and TSTAMP_CREATED between '2019041300000000' and '2019051300000000'
and net_rules = 'MC3'
and case_no > '20200501000000'
--and request_type = 'CHBQ'
--and status = 'PNDR'
--group by iss_ica
--order by iss_ica ASC;
--and t.amt_adjustment < c.amt_recon_net
--AND API_STATE = 'AC' AND REQ_TYPE = 'CBCreateResponse' and data_buffer like '<chargebackId>%';
--and request_type_prev  in ('DOC4','REP1')
--and request_type_next  = 'CHB2'
--and STATUS_prev  = 'SDRC'
--and STATUS_next  = 'FWRD';
--and case_no > '20190901000000'
--and c.request_type in ('CHBQ','CH2Q')
--AND STATUS  = 'PNDR'
--and t.reason_code = '4855'
--AND T.amt_adjustment < c.amt_recon_net
--and h.user_role = 'I'
--AND V.SUPPORT_INFO LIKE '%access%'
order by iss_ica asc;
--and case_type_ind = 'X'
--and state_tstamp > '2018052400000000'
--and net_id_ems <> 'ILK'
--and r.data_buffer like '%DuplicateTranId%';

select * from nqp7gtwy.task_context where TASKID = 'GTEI' and context_key in ('ACKNLG','MCINOFLN','FRDIN');

select * from nqp7comn.emsr_action_detail where ACTION_ID LIKE 'UPD_DOC%' AND rule_set_id = 'MC3'; 
select * from nqp7comn.as_user_logon where user_id = 'WZ99149';
select * from nqp7comn.as_user_profile where user_id = 'E041499' and cust_id = 'IFSA';
select * from nqp7comn.as_profile_entity where profile_id = 'PR_EMS_LEVEL_5';

select * from nqp7comn.x_net_inst_id where pan_prefix like '%557963%';
select distinct x.inst_id, x.cust_id,name
from nqp7comn.x_net_inst_id x
inner join nqp7comn.institution i on i.inst_id = x.inst_id and i.cust_id = x.cust_id
where net_inst_id_code like '%5971%' and net_id = 'MCI';
from nqp7gtwy.ems_case c
inner join nqp7gtwy.ems_case_mci m on m.case_id = c.case_id
inner join q
where case_no > '20180101000000' and iss_ica like '%5971%'
and inst_id_recon_iss <> '272481567';

select * from nqp7gtwy.fee_billing where fee_date = '201809' and entity_id = '000001407';

select CASE_NO from nqp7gtwy.ems_case c
inner join nqp7gtwy.ems_transition t 
on t.case_id = c.case_id 
where c.case_extension = 'VNT' 
AND (C.INST_ID_RECON_ISS = '000001407' 
OR C.INST_ID_RECON_ACQ = '000001407') 
AND T.TSTAMP_CREATED LIKE '201809%' 
AND T.ACTION LIKE '%RespT1%';

select c.case_id,case_no, REQUEST_TYPE,STATUS,di_file_id, TSTAMP_parsed,data_buffer from nqp7gtwy.di_data d
inner join nqp7gtwy.ems_case c on c.case_no = d.import_key
where tstamp_parsed > '2018101500000000' 
and reject_codes like 'CASE UPDATED WITH DOC,TRANSITION FAILED:%'
and data_buffer like '%INFR%'
and c.case_extension = 'MCI'
and request_type IN ('REP1','DOC4') AND STATUS = 'CLOA'
order by di_file_id desc;


--select case_no, inst_id_recon_iss, i.proc_id 
select case_no, inst_id_recon_iss, i.proc_id 
from nqp7gtwy.api_queue_control q
inner join nqp7gtwy.ems_case c on c.case_id = q.case_id
inner join nqp7comn.institution i on i.inst_id = c.inst_id_recon_iss
inner join nqp7gtwy.ems_phase p on p.case_id = c.case_id and p.request_type = c.request_type
where q.req_type = 'TII'
and q.api_state = 'AC'
and q.api_result not like 'Internal Error%'
and q.tstamp_created between '2018090000000000' and '2018099999999999'
and i.cust_id = 'GTWY'
and c.inst_id_recon_iss = '840256535'
--order by case_no asc;
--group by case_no,inst_id_Recon_iss,i.proc_id
--order by case_no asc;
union all
--select case_no, inst_id_recon_iss, i.proc_id 
select case_no, inst_id_recon_iss, i.proc_id 
from nqp7gtwy.api_queue_control q
inner join nqp7gtwy.ems_case c on c.case_id = q.case_id
inner join nqp7comn.institution i on i.inst_id = c.inst_id_recon_iss
inner join nqp7gtwy.ems_phase p on p.case_id = c.case_id and p.request_type = c.request_type
inner Join nqp7gtwy.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.tstamp_updated
where q.req_type = 'TII'
and q.api_state = 'AC'
and c.inst_id_recon_iss = '840256535'
and i.cust_id = 'GTWY'
and t.status_prev = 'REJR' AND T.STATUS_NEXT = 'FWRD'
and q.tstamp_created between '2018090000000000' and '2018099999999999'
group by case_no,inst_id_Recon_iss,i.proc_id
order by case_no asc;

select * from nqp7gtwy.fee_billing where fee_date = '201902' order by fee_data asc;-- and entity_id = '840256535';

select * from nqp7gtwy.ems_case where request_type = 'DOC4' AND STATUS = 'SDRC' ORDER BY CASE_ID DESC;
select * from nqp7comn.processor where proc_id = 'PRC130';
select * from nqp7comn.emsr_transition where RULE_SET_ID = 'MC3' 
AND PHASE_ID like 'CHBQ' AND STATUS_ID = 'REJR'
--AND NEXT_PHASE_ID = 'CHB1' AND NEXT_statuS_ID = 'SDRC' 
and role_ind = 'I';
select * from nqp7comn.emsr_desc_text where description_id = '0000015572';
select * from nqp7comn.emsr_action_detail a where RULE_sET_ID = 'MC3' 
--and a.RESN_CODE_ID = '4808';
and action_id = 'UPD_DOCFLG' and phase_id like 'CHB%';
--AND PHASE_ID = 'MANO'; --AND STATUS_ID = 'SDRC';
--AND phase_id = 'CHB1' AND STATUS_ID = 'SDRC';
select * from nqp7comn.emsr_action_instr where instruction_ptr = '1706523833';
select * from nqp7comn.emsr_rule_set where net_id_ems = 'U2F'; -- AND CUST_ID = 'FISB';
select resn_code_id,d.DESCRIPTION_TEXT from nqp7comn.emsr_resn_detail r
inner join nqp7comn.emsr_desc_text d on d.description_id = r.description_id
where rule_set_id = 'MC3' and phase_id = 'FEEA' and resn_code_id in (
'7600', '7601', '7602', '7604', '7605', '7606', '7607', '7608', '7613', '7617', '7618', '7619', '7700', '7750');
select * from nqp7comn.emsr_rule_set where RULE_SET_ID = 'ALS';
select * from nqp7comn.emsr_net_rule_use where CUST_ID = 'MCDP' AND ACQ_PROC = 'INT045' order by network_rules asc;network_rules = 'U2F' order by network_rules asc;
select * from NQP7COMN.EMSR_MMT_MSG 
--WHERE FORMAT LIKE '%"Comment"USER-ENTERED%';
 where rule_set_id = 'NBO';
select * from NQP7COMN.EMSR_MMT_DETAIL where rule_set_id = 'NBO';

select c.case_id,di_file_id from nqp7gtwy.di_data d
inner join nqp7gtwy.ems_case c on c.case_no = d.import_key
where tstamp_parsed > '2018101500000000' 
and reject_codes like 'CASE UPDATED WITH DOC,TRANSITION FAILED:'
and c.case_extension = 'MCI';
select * from nqp7comn.institution where inst_id = '263078918';

--select distinct data_VALUE, cfg_description from nqp7comn.misc_cfg_data
select * from nqp7comn.misc_cfg_data 
where DATA_VALUE LIKE '%REQ_DOC007%' order by data_value asc;

select * from nqp7gtwy.ems_fraud_mci where AUDIT_CTRL_NO = '000000003949299';
select * from NQP7COMN.CURRENCY_CODE where currency_code = '360';

SELECT * FROM NQP7COMN.CRTASKT WHERE TASKID = 'GTEB01';
SELECT * FROM NQP7COMN.CRTAGLT WHERE TAGLID = 'GTEB01';
SELECT * FROM NQP7COMN.CRTAGET WHERE TASKID = 'GTEB02';
SELECT * FROM NQP7COMN.CRTBDET WHERE TBDTID = 'GTEB01';
SELECT * FROM NQP7COMN.CRTBDTT WHERE TBDTID = 'GTEB01';
SELECT * FROM NQP7COMN.CRFILET WHERE TASKID = 'GTEB01';

select * from NQP7COMN.CQC_COLUMN_QUAL WHERE COLUMN_NAME = 'PAN';

SELECT count(*),net_id_acq from nqp7gtwy.ems_case where case_no > '20180101000000'
group by net_id_acq;
select * from nqp7gtwy.ems_case where case_no > '20180101000000' and net_id_acq = 'ALP';
select card_iss_ref_data from nqp7gtwy.ems_phase_mci order by tstamp_created desc;

SELECT c.TSTAMP_TRANS,c.UNiQUeNESS_KEY,c.CARD_ACPT_ID,c.POS_CRD_DAT_IN_MOD,r.card_acpt_id,r.pos_Crd_dat_in_mod,c.net_id_ems
FROM NQP7GTWY.EMS_CASE c
inner join nqp7gtwy.fin_record201906 r on r.tstamp_trans = c.tstamp_trans and r.uniqueness_key = c.uniqueness_key
WHERE CASE_NO > '20190601000000';

select * from nqp7comn.crevntt WHERE PROCID = 'GTEI';
select * from nqp7comn.crevcdt where evclid = 'GTQUEUE1';
select * from nqp7comn.CREVCDT where evclid = 'GTQUEUE1';
select * from nqp7comn.crtaskt where taskid = 'GTEB02';

select * from nqp7comn.x_net_inst_id where net_inst_Id_code like '%5458%' and pan_prefix  like '4%';
select * from nqp7comn.x_net_inst_id where pan_prefix like '%551010%';

select * from NQP7ispa.ems_case c
inner join nqp7comn.institution i on c.inst_id_recon_iss = i.inst_id
where name like '%FIRST MERCHANT%'
and net_id_ems <> 'VNT';


select * from nqp7comn.institution where inst_id = '840258287';

--**REGIONAL BILLING****                                     
--SELECT COUNT(*),C.CASE_NO,C.INST_ID_RECON_ISS,C.NET_ID_EMS,
-- SELECT COUNT(*),C.CASE_ID,C.CASE_NO,                      
---SELECT COUNT(*),                                          
--SELECT C.CASE_ID,C.CASE_NO,                                
SELECT COUNT(*),                                
C.INST_ID_RECON_ISS,--C.NET_ID_EMS,                          
C.PROC_ID_ISS,P.REQUEST_TYPE                               
FROM NQP7IFSA.EMS_CASE C                                   
INNER JOIN NQP7IFSA.EMS_PHASE P                            
ON C.CASE_ID = P.CASE_ID                                   
INNER JOIN (SELECT EMS_PHASE.CASE_ID,                      
MIN(EMS_PHASE.TSTAMP_CREATED) TSTAMP_CREATED               
FROM NQP7IFSA.EMS_PHASE EMS_PHASE                          
GROUP BY EMS_PHASE.CASE_ID) TISS                           
ON C.CASE_ID = TISS.CASE_ID                                
AND P.TSTAMP_CREATED = TISS.TSTAMP_CREATED                 
WHERE P.TSTAMP_CREATED BETWEEN '2019040100000000'          
AND '2019043123595999'                                     
AND C.INST_ID_RECON_ISS = '001700163'                     
--AND C.PROC_ID_ISS = 'PRC018'                               
AND P.USER_ROLE = 'I'                                      
AND C.NET_ID_EMS NOT IN ('MCI','VNT')                   
GROUP BY C.PROC_ID_ISS,C.INST_ID_RECON_ISS,
--P.REQUEST_TYPE,C.NET_ID_EMS                            
P.REQUEST_TYPE--,C.NET_ID_EMS,C.CASE_NO,C.CASE_ID         
UNION ALL                                               
---SELECT COUNT(*) ROW_COUNT,C.CASE_ID,C.CASE_NO,         
--SELECT COUNT(*), C.CASE_ID,C.CASE_NO,                   
SELECT COUNT(*),                                
--SELECT C.CASE_ID,C.CASE_NO,                            
C.INST_ID_RECON_ACQ,                                    
--C.NET_ID_EMS,
C.PROC_ID_ACQ,P.REQUEST_TYPE               
FROM NQP7IFSA.EMS_CASE C INNER JOIN NQP7IFSA.EMS_PHASE P
ON C.CASE_ID = P.CASE_ID INNER JOIN                     
(SELECT EMS_PHASE.CASE_ID,                              
MIN(EMS_PHASE.TSTAMP_CREATED) TSTAMP_CREATED            
FROM NQP7IFSA.EMS_PHASE EMS_PHASE                       
GROUP BY EMS_PHASE.CASE_ID) TACQ                        
ON C.CASE_ID = TACQ.CASE_ID                             
AND P.TSTAMP_CREATED = TACQ.TSTAMP_CREATED              
WHERE P.TSTAMP_CREATED BETWEEN '2019040100000000'       
AND '2019043123595999'                                  
AND C.INST_ID_RECON_ACQ = '001700163'                    
--AND C.PROC_ID_ACQ IN ('INT653','INT655','INT656','INT657' 
--,'INT658')                                                
AND P.USER_ROLE = 'A'                                     
AND C.NET_ID_EMS NOT IN ('MCI','VNT')                     
GROUP BY C.PROC_ID_ACQ,C.INST_ID_RECON_ACQ,P.REQUEST_TYPE,
---C.NET_ID_EMS                                             
C.NET_ID_EMS--,C.CASE_NO,C.CASE_ID
ORDER BY proc_id_iss,REQUEST_TYPE;
--ORDER BY 6, 4, 7, 5 FOR READ ONLY                         
---ORDER BY 6, 4, 5 FOR READ ONLY     

select distinct C.case_id from nqp7ifsa.ems_case c
inner join nqp7ifsa.ems_phase p on c.case_id = p.case_id
where c.net_id_ems  in ('MCI','VNT')
AND INST_ID_RECON_ISS = '840258287'
AND P.TSTAMP_CREATED BETWEEN '2019040100000000' AND '2019043123595999'
AND P.USER_ROLE = 'I';                              

select c.case_id,claim_id from nqp7gtwy.ems_case c
inner join nqp7gtwy.ems_case_mci m on m.case_id = c.case_id 
where net_rules = 'MC3' AND cur_tran <> '840' and case_type_ind = 'X';

select device_id,PROC_NAME from nqp7comn.device d
inner join nqp7comn.institution i on i.inst_id = d.inst_id
inner join nqp7comn.processor p on p.proc_id = i.proc_id
where d.CUST_ID = 'TFND' AND I.CUST_ID = 'TFND' AND P.CUST_ID = 'TFND';
AND P.PROC_NAME LIKE '%VISA%';

SELECT TRAN_DISPOSITION FROM NQP7GTWY.FIN_RECORD201907 WHERE TRAN_DISPOSITION NOT IN ('1','2','3') AND O_AMT_TRAN <> 0;
select * FROM nqp7gtwy.fin_record201907 where TSTAMP_TRANS IN ('2019070100033662','2019070100035586') 
AND UNIQUENESS_KEY IN (26745,26919);

select case_no,claim_id,DOC_IND from nqp7gtwy.ems_case c inner join nqp7gtwy.ems_case_mci m on m.case_id = c.case_id
inner join nqp7gtwy.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7gtwy.ems_phase_mci m on m.case_id = t.case_id and m.tstamp_created = t.phase_tstamp
where case_no in (
'20190823000019',
'20190822000205',
'20190822000204',
'20190822000091',
'20190822000050',
'20190822000030',
'20190822000016',
'20190821000054',
'20190821000052',
'20190816000045',
'20190816000044',
'20190816000027',
'20190816000026',
'20190816000020',
'20190815000030',
'20190815000029',
'20190815000023',
'20190815000021',
'20190812000004',
'20190809000196',
'20190807000034',
'20190807000028',
'20190807000026',
'20190807000025',
'20190807000023',
'20190807000022',
'20190807000021',
'20190806000194',
'20190806000192');

select * from nqp7gtwy.di_data_control where di_file_id = 650594;--tstamp_initiated like '20191022%' order by di_file_id desc;
select * from nqp7gtwy.di_data where data_buffer like '%200247453910%';
select * from nqp7gtwy.api_queue_response where data_buffer like '%200247453910%';

select c.case_id,case_no,request_Type,status,NET_RULES, STATE_TSTAMP,M.ISS_ICA from nqp7gtwy.ems_case c
inner join nqp7gtwy.ems_case_mci m on m.case_id = c.case_id
where m.iss_ica like '%5971%' and case_type_ind = 'X'
and net_id_acq = 'MCI' order by case_id desc;

select c.case_id,claim_id,request_type,status from nqp7gtwy.ems_case c
inner join nqp7gtwy.ems_transition T on t.case_id = c.case_id
inner join nqp7gtwy.ems_case_mci m on m.case_id = c.case_id
where net_id_acq = 'MCI' AND NET_RULES = 'MC3' 
and t.request_type_prev = 'CHB1' AND T.STATUS_PREV = 'SDRC'
AND T.REQUEST_TYPE_NEXT = 'DOC4' AND T.STATUS_NEXT = 'SDRC';

select distinct c.case_id,case_no,request_type,status,request_type_next,status_next,t.amt_adjustment,pan,acq_ref_no
from nqp7cusa.ems_case c
inner join nqp7CUSA.ems_national_net n on n.case_id = c.case_id
inner join nqp7CUSA.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7CUSA.ems_case_mci m on m.case_id = c.case_id
where case_type_ind = 'X'
and pan in (
select distinct pan from nqp7comn.ems_unmatched_msg where tstamp_created BETWEEN '2020012008000000' AND '2020012009000000'
and net_id ='MCI' AND PAN <> ' ' and home_switch = 'CUSA' and msg_id = '1240')
and n.acq_ref_no in (
select distinct acq_ref_no from nqp7comn.ems_unmatched_msg where tstamp_created BETWEEN '2020012008000000' AND '2020012009000000'
and net_id ='MCI' AND PAN <> ' ' and home_switch = 'CUSA' and msg_id = '1240')
and m.claim_id = ' ' 
AND NOT (REQUEST_TYPE_NEXT = 'REP1' AND STATUS = 'SDRC')
order by case_Id asc;

select case_id from nqp7cusa.ems_transition
where request_type_next = 'REP1' AND STATUS_NEXT = 'SDRC'
AND CASE_ID in (
243354989,
243358248);

select *
--distinct pan,amt_adjustment,acq_ref_no,home_switch 
from nqp7comn.ems_unmatched_msg where tstamp_created like '20200120%' and net_id = 'MCI' and msg_id not in ('RO09', ' ','RO22');
where tstamp_created BETWEEN '2020011808000000' AND '2020011808300000'
and net_id ='MCI' AND PAN <> ' ' and msg_id = '1240' and home_switch = 'CUSA' order by pan asc,acq_ref_no asc;

select * from nqp7comn.ems_mci_sent where src_msg_no = '5971' and file_id = '2019112608';

select tstamp_Created, user_id, request_type_prev,status_prev,t.REQUEST_TYPE_NEXT,status_next 
from nqp7fisa.ems_case c
inner join nqp7fisa.ems_Transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
where state_tstamp > '20190101000000' and case_type_ind = 'D' and request_type = 'FDRA' and STATUS = 'PNDR'
--and net_rules = 'MC2' 
order by tstamp_created asc;

select queue_id,api_state,a.case_id,case_no,retry_count,api_result,request_type,status,state_tstamp
from nqp7gtwy.ems_case c 
inner join nqp7gtwy.api_queue_control a on a.case_id = c.case_id where REQ_TYPE = 'CBGetDocumentResponse' 
/*and a.case_id in (
select DISTINCT c.case_id
from nqp7gtwy.ems_case c
inner join nqp7gtwy.ems_transition t on t.case_id = C.CASE_ID
where net_rules = 'MC3' and request_type_next = 'REP1' AND STATUS_NEXT = 'GETD')*/
--and request_type not in ('CHB2','DOC4','CH2Q') 
and request_type = 'REP1' and status = 'SDRC'
order by a.case_id desc;

SELECT a.queue_id,api_state,a.case_id,request_type,status,api_result,RETRY_COUNT,data_buffer
from nqp7gtwy.api_queue_control a
inner join nqp7gtwy.ems_case c on c.case_id = a.case_id 
inner join nqp7gtwy.api_queue_response r on r.queue_id = a.queue_id
where api_result like '%ME53: Do not recognize status%' 
and request_type = 'REP1' AND STATUS = 'SDRC' ORDER BY CASE_ID ASC;

SELECT a.queue_id,api_state,a.case_id,request_type,status,api_result, data_buffer 
from nqp7gtwy.api_queue_control a
inner join nqp7gtwy.ems_case c on c.case_id = a.case_id 
inner join nqp7gtwy.api_queue_response r on r.queue_id = a.queue_id
where api_result like '%ME53: Do not recognize status%'
and data_buffer like '%documentIndicator>false%' order by case_id asc;

select c.case_id,case_no,claim_id,request_type,status from nqp7gtwy.ems_case c
inner join nqp7gtwy.ems_case_mci m on m.case_id = c.case_id
where c.case_id in (
2432557	,
2439019	,
2439231	,
2440165	,
2440166	,
2440167	,
2440279	,
2440476	,
2440907	,
2440908	,
2440909	,
2440919	,
2440921	,
2440997	,
2441127	,
2441203	,
2441678	,
2441952	,
2441953	,
2442474	,
2442475	,
2442479	,
2442505	,
2442799	,
2442800	,
2442828	,
2442995	,
2442996	,
2442997	,
2443092	,
2443329	,
2443477	,
2443516	,
2443517	,
2443526	,
2443669	,
2443670	,
2443671	,
2443672	,
2443795	,
2443796	,
2443804	,
2443805	,
2443811	,
2443813	,
2443820	,
2443829	,
2443905	,
2444133	,
2444142	,
2444145	,
2444229	,
2444233	,
2444734	,
2444735	,
2444761	,
2444764	,
2444795	,
2444797	,
2444967	,
2444971	,
2445289);

select * from nqp7comn.dx_proc_dest where dx_file_group = 'VROL';

select * from nqp7comn.processor where cust_id = 'TFND' and proc_id = 'INT002';
select i.name,i.inst_id,device_id,i.cust_id from nqp7comn.device d 
inner join nqp7comn.institution i on d.inst_id = i.inst_id
and i.name like '%MAST%';
where i.proc_id = 'PRC822';
select distinct net_rules from nqp7mcdp.ems_case;

SELECT COUNT(*), substr(state_tstamp,1,8) D1 FROM NQP7GTWY.EMS_CASE 
WHERE NET_RULES = 'MC3' AND REQUEST_TYPE = 'CHB1' AND STATUS = 'PNDR' and state_tstamp > '2020060400000000'
group by substr(state_tstamp,1,8)
order by substr(state_tstamp,1,8) asc;

select * from nqp7gtwy.gdg_data_control;
select * from nqp7gtwy.ems_case_context where net_id = 'MCC' and context_type = 'SETTLE' order by tstamp_updated desc;
select * from nqp7comn.crevntt where EVNTID = 'GTDOCSTA';
select * from nqp7comn.CREVCDT where EVCLID = 'GTDOCSTA';
select * from nqp7comn.CREVCLT where EVCLID = 'GTDOCSTA';

