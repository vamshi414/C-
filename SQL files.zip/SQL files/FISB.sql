select distinct net_rules from nqp7fisb.ems_case where case_extension not in ('VNT','MCI'); order by case_id desc;
select * from nqp7fisb.ems_case where case_no = '20200423000408';
select * from nqp7fisb.ems_transition where case_id = 925882 order by tstamp_created asc;

select request_type,status,net_rules from nqp7fisb.ems_case where net_id_ems = 'MCI' order by case_id desc;
select * from nqp7fisb.ems_case where pan_prefix = '413760' and net_id_ems = 'VNT';pan_suffix = '0972' and case_type_ind = 'X';
select * from nqp7fisb.fin_l202001 where tstamp_trans = '2020012017100351' and uniqueness_key = 23535;--pan_suffix = '4530' and retrieval_ref_no = '000000000534';
select ref_data_acq from nqp7fisb.fin_record202004 where tstamp_trans = '2020040300255280' and uniqueness_key = 2194;
select * from nqp7fisb.ems_case where case_id = 940171;
select * from nqp7fisb.ems_case where tstamp_trans = '2018112716382343';
select * from nqp7fisb.ems_phase where case_id = 940171;
select * from nqp7fisb.ems_case_vnt where case_id = 925883;
select * from nqp7fisb.ems_case_mci where case_id in (940171,940178);
select * from nqp7fisb.ems_case_mci where claim_id = '200689060334';
--select case_no,request_type,status from nqp7fisb.ems_case c inner join nqp7fisb.ems_case_mci m on m.case_id = c.case_id
select case_no,request_type,status from nqp7fisb.ems_case c inner join nqp7fisb.ems_national_net n on n.case_id = c.case_id
where acq_ref_no = '75345339265900010800521';
--where CLAIM_ID = '200271228246';

select * from nqp7fisb.ems_phase_vnt where 
--vrol_case_no = '1839921840' order by tstamp_created asc;
case_id = 925882 order by tstamp_created asc;
select * from nqp7fisb.ems_phase_mci where case_id = 940171 order by tstamp_created asc;
select * from nqp7fisb.ems_phase_vnt_vrol where case_id = 925882;
select * from nqp7fisb.ems_document where case_id = 905799;
select * from nqp7fisb.ems_fraud_vnt where case_id = 7372387;
select * from nqp7fisb.ems_national_net where acq_ref_no = '75345339265900010800521';--case_id = 7041317;
select state_tstamp from nqp7fisb.ems_case c inner join nqp7fisb.ems_case_vnt v on v.case_id = c.case_id
where net_id_ems = 'VNT' and request_type = 'FDRA' AND STATUS in ('REJ1') AND VCR_IND = 'Y'
and state_tstamp < '2018042000000000';

select * from nqp7fisb.ems_data_chg where case_id = 925882 order by tstamp_created asc;
select * from nqp7cusa.ems_data_chg where tstamp_created = '2019072408150500' order by case_id asc;
select * from nqp7fisb.di_data where di_file_id = 668840;--import_key = '20180411004846';

select * from nqp7fisb.api_queue_control where case_id = 925882 order by queue_id asc;
select * from nqp7fisb.api_queue_control where queue_id = 254065;
select * from nqp7fisb.api_queue_control where api_state = 'PE' and api_type = 'MCOM' and req_type <> 'RRGetDocumentResponse' and api_result not in 
('Error: Transition failed from CHBQ/PNDR to CHBQ/PNDR','Error: Transition failed from CH2Q/PNDR to CH2Q/PNDR')  order by queue_id desc;--queue_id = 1641961;

select * from nqp7fisb.api_queue_control where api_state = 'AS' order by tstamp_event asc;--queue_id asc;-- where queue_id = 173083;
select * from nqp7fisb.api_queue_control where api_type = 'MQUE' and REQ_TYPE = 'MCIIREPUNW' order by queue_id desc;
select * from nqp7fisb.api_queue_control where api_type = 'MQUE' and REQ_TYPE = 'MCIDOCCOMP' order by queue_id desc;
select * from nqp7fisb.api_queue_control where api_type = 'MCOM' and REQ_TYPE = 'TransactionInquiryResponse';--'ClaimsRetrieveResponse' order by queue_id desc;
select * from nqp7fisb.api_queue_control where api_type = 'MCOM' and req_type = 'CBStatusResponse' order by queue_id desc;
select * from nqp7fisb.api_queue_control where api_type = 'MCOM' and req_type = 'CBUpdateDOCResponse' order by queue_id desc;
--and api_result like '%Service error%' order by case_id asc;
select * from nqp7fisb.api_queue_control where api_type = 'MCOM' and api_state not in ('AC','PE','XY','AF')  order by tstamp_event Asc;
select * from nqp7fisb.api_queue_response where queue_id = 199994 ORDER BY SEQ_NO ASC;
select * from nqp7fisb.api_queue_request where queue_id = 356073 ORDER BY SEQ_NO ASC;

select * from nqp7fisb.api_qevent_log where queue_id = 218865 order by tstamp_created asc;

select * from nqp7fisb.api_queue_control where API_RESULT = 'Error: Transition failed from CHB1/PNDR to CHB1/REJR';

--select a.queue_id,tstamp_event,req_type,data_buffer 
select A.QUEUE_ID,a.tstamp_created, A.case_id,request_type,status,data_buffer
--claim_id,acq_ref_no,ISS_ICA
from nqp7fisb.api_queue_control a 
inner join nqp7fisb.api_queue_response r on r.queue_id = a.queue_id
inner join nqp7fisb.ems_case c on c.case_id = a.case_id
--inner join nqp7fisb.ems_case_mci m on m.case_id = c.case_id
--inner join nqp7fisb.ems_national_net n on n.case_id = c.case_id
--where data_buffer like '%><faultstring>One or more errors occurred while processing the request.</faultstring><detail><SIErrors xmlns="http://www.visa.com/ROLSI"><Status><Code>I-300300000</Code>%'
where REQ_TYPE = 'CBStatusResponse' and api_type = 'MCOM'
--and request_type = 'CHB2'
order by a.queue_id desc;

select * from nqp7fisb.api_queue_request where queue_id in
(select queue_id from nqp7fisb.api_queue_control where case_id = 925882) order by queue_id asc;
select * from nqp7fisb.api_queue_request where queue_id in (select queue_id from nqp7fisb.api_queue_control where req_type = 'TII') order by queue_id desc; 
select * from nqp7fisb.api_queue_response where queue_id in
(select queue_id from nqp7fisb.api_queue_control where case_id = 940178) order by queue_id asc;
SELECT * from nqp7fisb.api_queue_control where queue_id in (
select queue_id from nqp7fisb.api_queue_response where data_buffer like '%200521728602%') order by queue_id desc;
SELECT distinct case_id, tstamp_created from nqp7fisb.api_queue_control where queue_id in (
select queue_id from nqp7fisb.api_queue_response where data_buffer like '%User tried to submit%') order by case_id asc;
select * from nqp7fisb.api_qevent_log where queue_id =52234 order by tstamp_created asc;

SELECT a.queue_id,api_state,a.case_id,request_type,status,api_result,RETRY_COUNT,data_buffer
from nqp7fisb.api_queue_control a
inner join nqp7fisb.ems_case c on c.case_id = a.case_id 
inner join nqp7fisb.api_queue_response r on r.queue_id = a.queue_id
where api_result like '%ME53: Do not recognize status%' 
and request_type = 'REP1' AND STATUS = 'SDRC' ORDER BY CASE_ID ASC;
and status <> 'CLOA' order by queue_id desc; 

SELECT a.queue_id,api_state,a.case_id,request_type,status,api_result, data_buffer 
from nqp7fisb.api_queue_control a
inner join nqp7fisb.ems_case c on c.case_id = a.case_id 
inner join nqp7fisb.api_queue_response r on r.queue_id = a.queue_id
where api_result like '%ME53: Do not recognize status%'
and data_buffer like '%documentIndicator>false%' order by case_id asc;

--SELECT                                                 
--'INSERT INTO nqp7fisb.EMS_TRANSITION (CASE_ID,PHASE_TSTAMP,TSTAMP_CREATED,SEQ_NO,USER_ID,REQUEST_TYPE_PREV,STATUS_PREV,REQUEST_TYPE_NEXT,STATUS_NEXT,MANUAL_OVERRIDE,ACTION,ACTION_TO_CARDHLDR,REASON_CODE,AMT_ADJUSTMENT) VALUES (',               
--X.CASE_ID,','''||X.PHASE_TSTAMP||''',''2018042315300000''',                
-- '''1'',''SQL'','''||X.REQUEST_TYPE||''',',            
-- ''''||X.STATUS||''','''||X.REQUEST_TYPE||''',',       
--'''FWRD'',''N'','' '','''||X.ACTION_TO_CARDHLDR||''',',
--''''||X.REASON_CODE||''',',X.AMT_ADJUSTMENT,');'       
-- FROM                                                  
--   (                                                   
select c.case_id,request_type,status, t.phase_tstamp,t.reason_code,t.action_to_cardhldr,t.amt_adjustment,v.support_info
from nqp7fisb.ems_case c
inner join nqp7fisb.ems_transition t
on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7fisb.ems_phase_vnt v
on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
where support_info like '%Internal Error%';
--and request_type = 'FDRA')X;

select count(*)
from nqp7fisb.api_queue_response r
inner join nqp7fisb.api_queue_control a
on a.queue_id = r.queue_id
inner join nqp7fisb.ems_case c
on c.case_id = a.case_id
where data_buffer like '%settlement%'
and request_type = 'CHB1';

select * from nqp7fisb.assoc_tran_vnt where case_id = 941615;
select * from nqp7fisb.assoc_tran_mci where case_id = 940171;
select * from nqp7fisb.assoc_tran where case_id = 940171;

select c.case_id, c.state_tstamp, c.date_recon_net, n.acq_ref_no, a.arn, v.tran_type, v.tran_identifier
from nqp7fisb.ems_case c 
inner join nqp7fisb.ems_national_net n on n.case_id = c.case_id
inner join nqp7fisb.assoc_tran a on a.case_id = c.case_id
inner join nqp7fisb.assoc_tran_vnt v on v.ATR_SEQ_no = a.seq_no
where request_type = 'FDRA'
and status = 'REJ1';
--d state_tstamp > '2018042700000000';
AND v.tran_type like '02%';

--Select case_id from nqp7fisb.ems_case where case_type_ind = 'D' and tstamp_trans in (
--select c.case_id, pan_prefix, net_id_acq,case_no, tstamp_trans,state_tstamp,c.request_type, status,merchant_cat_code,v.support_info
--select c.case_id, acq_bin, net_id_iss,card_acpt_name,case_no, tstamp_trans,state_tstamp,c.request_type, status,merchant_cat_code, v.support_info
--select c.case_id, case_no, inst_id_recon_iss,i.name,pan_prefix, pan_suffix, retrieval_ref_no,iss_bin,acq_bin, net_id_ems,tstamp_local,c.amt_recon_net/100,
--tran_identifier,h.reason_code,h.amt_adjustment/100,c.request_type,status,merchant_cat_code, state_tstamp,v.vrol_case_no,v.support_info
--select c.CASE_id, case_no, vrol_case_no,request_type, status,INST_ID_RECON_ISS, NAME, state_tstamp,v.support_info
--select c.case_id,vrol_case_no,tran_identifier, tstamp_local,amt_adjustment, dispute_condition, acq_ref_no
--select case_no, tstamp_trans,request_type, status,INST_ID_RECON_ISS, NAME,v.support_info
--select c.case_id,case_no,tran_type_id,process_code,tstamp_trans,state_tstamp,rol_tran_id, c.request_type, status,vrol_case_no,tran_identifier,v.support_info
select c.case_id
--select c.case_id,case_no,pan_prefix,net_id_acq,tstamp_trans,state_tstamp,tran_identifier, tstamp_local,date_recon_net,c.request_type, status,v.support_info,
--r.DATA_BUFFER
from nqp7fisb.ems_case c
--inner join nqp7fisb.ems_case_vnt u on u.case_id = c.case_id
--inner join nqp7fisb.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
--inner join nqp7fisb.ems_phase_vnt v on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
--inner join nqp7fisb.ems_national_net n on n.case_id = c.case_id
--inner join nqp7fisb.ems_document d on d.case_id = c.case_id
--inner join nqp7comn.institution i on i.inst_id = c.inst_id_recon_iss
--inner join nqp7fisb.ems_phase h on h.case_id = t.case_id and h.tstamp_created = t.phase_tstamp
--inner join nqp7fisb.api_queue_control q on q.case_id = c.case_id
--inner join nqp7fisb.api_queue_request r on r.queue_id = q.queue_id
where net_rules = 'MC3'
and c.request_type = 'DOC4'
and status = 'SDRC'
and state_tstamp > '2019120100000000'
and c.case_id not in (
select c.case_id from nqp7fisb.ems_case c
inner join nqp7fisb.ems_document d on d.case_id = c.case_id
where net_rules = 'MC3'
and c.request_type = 'DOC4'
and status = 'SDRC'
and state_tstamp > '2019120100000000'
and doc_type = 'REQ_DOC005');
--and h.user_role = 'I'
--and i.cust_id = 'FISB'
--and r.data_buffer not like '%<ARN>%'
--AND V.SUPPORT_INFO LIKE '%Invalid Account%'
--AND V.SUPPORT_INFO LIKE '%access%'
--AND I.CUST_ID = 'FISB'
--and pan_prefix in ('431458','431600','438528','442612')
--order by acq_bin asc;
--WHERE CASE_EXTENSION = 'VNT'
--and t.request_type_prev = 'INIT' AND T.STATUS_PREV = 'TEMP' AND T.REQUEST_TYPE_NEXT = 'CHB1' AND T.STATUS_next = 'SDRC'
--AND CUR_TRAN <> '840'
--ORDER BY INST_ID_RECON_ISS ASC;
--AND h.user_role = 'A'
--AND ERR_VROL_MSG1 = 'W80';
order by support_info asc, state_tstamp asc;
--AND ERR_VROL_MSG1 = 'E-122000079';

--select distinct net_inst_id_code,x.cust_id,x.inst_id, i.name from nqp7comn.x_net_inst_id x 
select * from nqp7comn.x_net_inst_id x 
--inner join nqp7comn.institution i on i.inst_id = x.inst_id
/*where pan_prefix in (
'403101','418505','431458','431600','434020','438528','442612','442859','442939','448224','449224','449351',
'453266','453269','453584','460204','467129','468910','473808','475060','475471','488875','489272','491716')
and x.CUST_ID = 'FISA';*/
where net_inst_id_code in (
'272685','272906','277540','279058','292740','293593','298521','299074','299284','299991')
--and I.cust_id = 'IFSA'
order by net_inst_id_code asc;

Select c.case_id,case_no,status,rol_tran_id from nqp7fisb.ems_case c
inner join nqp7fisb.ems_case_vnt v on v.case_id = c.case_id
where case_type_ind = 'D' and tstamp_trans in ('2018010601465363',
'2018010601465366','2018030916363116','2018010320462963','2018040808284462','2018040603092527','2018041103093380');
Select queue_id,req_type from nqp7fisb.api_queue_control where case_id in (
Select case_id from nqp7fisb.ems_case where case_type_ind = 'D' and tstamp_trans in ('2018010601465363',
'2018010601465366','2018030916363116','2018010320462963','2018040808284462','2018040603092527','2018041103093380'))
And req_type like 'TI%';

select * from nqp7fisb.di_data where di_file_id = 4916169;

select count(*), inst_id_recon_iss, i.proc_id 
from nqp7fisb.api_queue_control q
inner join nqp7fisb.ems_case c on c.case_id = q.case_id
inner join nqp7comn.institution i on i.inst_id = c.inst_id_recon_iss
where q.req_type = 'TII'
and q.tstamp_created between '2018050100000000' and '2018052923595999'
and i.cust_id = 'FISB'
group by inst_id_Recon_iss,i.proc_id
order by inst_id_recon_iss;

--select c.case_id, case_no, state_tstamp,request_type, status,support_info
select c.CASE_id, case_no, pan_prefix,vrol_case_no,inst_id_recon_iss,name,c.request_type, status, v.support_info
--select c.case_id, state_tstamp,request_type, status,d.doc_type, d.export_ind
from nqp7fisb.ems_case c
inner join nqp7fisb.ems_case_vnt u on u.case_id = c.case_id
--inner join nqp7fisb.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7fisb.ems_phase_vnt v on v.case_id = c.case_id --and v.tstamp_created = t.phase_tstamp
--inner join nqp7fisb.ems_document d on d.case_id = c.case_id
inner join nqp7comn.institution i on i.inst_id = c.inst_id_recon_iss
where net_rules = 'VN3'
--and c.request_type like 'ADJ%'
and status = 'REJR'
--and acq_bin in
--('272685','272906','277540','279058','292740','293593','298521','299074','299284','299991')
and pan_prefix in ('403101','431458','431600','438528','442612','449224','453266','453269','453584','473808','475060','491716')
AND (V.SUPPORT_INFO LIKE '%access%' or V.SUPPORT_INFO LIKE '%No matching%')
and i.cust_id = 'FISB'
order by support_info asc,pan_prefix asc;
--and support_info like '%Invalid%'
--and doc_type like 'QTN_CB%'
--and d.export_ind <> 'N'
--and request_type <> 'REPQ'
order by state_tstamp desc;

select count(*),net_rules,request_type,status from nqp7FISB.ems_case
where case_extension = 'PUL'
and status not like 'CL%'
group by net_rules,request_type,status
ORDER BY NET_RULES ASC;

--SELECT
--'UPDATE NQP7FISB.EMS_DOCUMENT SET EXPORT_IND = ''R'' WHERE CASE_ID = ',
--X.CASE_ID,
--';'
-- FROM                                                  
--   (                                                   
--select distinct c.case_id, case_no, doc_type,export_ind from nqp7fisb.ems_case c
select distinct case_no from nqp7fisb.ems_case c
inner join nqp7fisb.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7fisb.ems_phase_vnt v on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
inner join nqp7fisb.ems_document d on d.case_id = c.case_id
where c.case_type_ind = 'X' and v.vrol_case_no in (
'1650685591',
'1651119472');

select case_no, support_info from nqp7fisb.ems_case c
inner join nqp7fisb.ems_case_vnt v on v.case_id = c.case_id
inner join nqp7fisb.ems_phase_vnt h on h.case_id = c.case_id
where case_no > '20180413000000' and v.acq_bin = '273512';

select case_no, vrol_case_no, support_info from nqp7fisb.ems_case c
inner join nqp7fisb.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7fisb.ems_phase_vnt v on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
where case_type_ind ='X' and case_no in
('20180526000059','20180528000025','20180528000029','20180528000041',
'20180528000071','20180528000073','20180525000069','20180525000074');

select * from nqp7fisb.ems_data_chg where table_changed = 'EMS_CASE_MCI' AND COLUMN_CHANGED = 'MC_RTR_CTRL_NO' ORDER BY CASE_ID DESC;
SELECT * FROM NQP7FISB.EMS_CASE_MCI WHERE MC_RTR_CTRL_NO <> ' ' ORDER BY CASE_ID DESC;

select c.case_id,case_no,request_Type,status,NET_RULES, STATE_TSTAMP,M.ISS_ICA from NQP7FISB.ems_case c
inner join NQP7FISB.ems_case_mci m on m.case_id = c.case_id
where m.iss_ica like '%5458%' and case_type_ind = 'X'
and net_id_acq = 'MCI' order by case_id desc;
and request_type = 'CHB1'
order by state_tstamp desc;-- and request_type = 'UNW1' AND STATUS = 'PNDR';

select * from nqp7fisb.ems_case_mci where case_id in (
827870,
820717,
817771,
820607,
821617,
821685,
821646,
818291,
821739,
821737,
813194,
821621,
821648,
821738,
820600,
813506,
821626,
821702,
821693,
821735,
820752,
821683,
821652,
821740,
813192,
821630,
818006);

select C.case_id,case_no,tstamp_trans,c.request_type,status,STATE_TSTAMP,t.reason_code,doc_ind,reject_info
from nqp7fisb.ems_case c
inner join nqp7fisb.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7fisb.ems_phase_mci m on m.case_id = t.case_id and m.tstamp_created = t.phase_tstamp
where net_rules = 'MC3'
and case_no > '20190901000000'
AND STATUS  = 'REJR'
order by c.state_tstamp desc;

select case_no,c.case_id,claim_id,request_Type,status,state_tstamp from nqp7fisb.ems_case c
inner join nqp7fisb.ems_case_mci m on m.case_id = c.case_id
--inner join nqp7fisb.ems_transition t on t.case_id =c.case_id and t.tstamp_created = c.state_tstamp
where case_no IN (
'20191107000273',
'20191107000271',
'20191107000266',
'20191107000264',
'20191107000262',
'20191107000258',
'20191107000256',
'20191107000253') order by case_id asc;

SELECT * FROM NQP7FISB.API_QUEUE_CONTROL API_QUEUE_CONTROL 
WHERE API_QUEUE_CONTROL.TSTAMP_EVENT IN (SELECT MIN(API_QUEUE_CONTROL.TSTAMP_EVENT) TSTAMP_EVENT 
FROM NQP7FISB.API_QUEUE_CONTROL API_QUEUE_CONTROL WHERE API_QUEUE_CONTROL.API_STATE IN ('AS','PE','SP') 
AND API_QUEUE_CONTROL.API_TYPE IN ('MCOM','MQUE') AND API_QUEUE_CONTROL.TSTAMP_EVENT <= '2020010610042102' AND API_QUEUE_CONTROL.RETRY_COUNT < 5) 
ORDER BY API_QUEUE_CONTROL.TSTAMP_EVENT ASC,API_QUEUE_CONTROL.QUEUE_ID ASC;

select ref_data_acq_fmt, ref_data_acq,data_priv_acq,adl_data_priv_acq
from nqp7fisb.fin_record201910 where tstamp_trans between '2019100100000000' and '2019100200000000'
and net_id_acq = 'VNT' and func_code = '200';

select c.case_id,case_no,claim_id,request_type,status from nqp7fisb.ems_case c
inner join nqp7fisb.ems_case_mci m on m.case_id = c.case_id
where c.case_id in (
874333	,
874935	,
874942	,
875012	,
875072	,
877118	,
877428	,
881603	,
881605	,
882075	,
882113	,
882143	,
882147	,
882150	,
884487	,
884488	,
884493	,
884495	,
884504	,
884509	,
884516	,
884518	,
884523	,
884530	,
884535	,
884537	,
884539	,
884542	,
884544	,
884546	,
884548	,
884551	,
884561	,
884574	,
884576	,
884578	,
884586	,
884609	,
887773	,
887777	,
887793	,
887795	,
887797	,
887819	,
888897	,
890028	,
890389	,
890392	,
890394	,
890400	,
890402	,
890404	,
890406	,
890408	,
890410	,
890412	,
890414	,
890416	,
890418	,
890421	,
890423	,
890425	,
890427	,
890429	,
890465	,
891029);

SELECT EC.CASE_ID, CASE_NO, claim_id,STATE_TSTAMP FROM NQP7cusa.EMS_CASE EC 
INNER JOIN NQP7cusa.EMS_TRANSITION T ON T.CASE_ID = EC.CASE_ID AND T.TSTAMP_CREATED = EC.STATE_TSTAMP
INNER JOIN NQP7cusa.EMS_PHASE_MCI EPM ON EPM.CASE_ID = T.CASE_ID AND EPM.TSTAMP_CREATED =T.PHASE_TSTAMP
INNER JOIN NQP7cusa.EMS_CASE_MCI M ON M.CASE_ID = T.CASE_ID
WHERE NET_RULES = 'MC3' AND REQUEST_TYPE = 'CHB1' AND STATUS = 'SDRC' AND DOC_IND = '1' 
and state_tstamp > '2020060400000000' ORDER BY STATE_TSTAMP; 
