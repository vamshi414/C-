select * from nqp1bcfs.ems_case where case_no = '20200520006041';
select state_tstamp from nqp1bcfs.ems_case where pan_prefix = '521105' and request_type = 'REP1' AND STATUS = 'CLUN' order by state_tstamp asc;
select * from nqp1bcfs.ems_transition where case_id = 11268829 order by tstamp_created asc;
select distinct count(*),net_id_ems from nqp1bcfs.ems_case where proc_grp_id_acq_b = 'VISA' group by net_id_ems;
select * from nqp1comn.institution where name = '0G2W-KEYBANK';  841098501  

select * from nqp1bcfs.ems_data_chg where case_id = 11154809 order by tstamp_created asc;
select * from nqp1bcfs.assoc_tran_mci where case_id = 10374402;
select * from nqp1bcfs.assoc_tran where case_id = 10828900;

select * from nqp1bcfs.ems_fraud_mci where case_id = 11315775;AUDIT_CTRL_NO = '000000003898818';
select * from nqp1bcfs.ems_case where tstamp_trans = '2019120620084468';

select * from nqp1bcfs.ems_case where pan_prefix = '511165' and 
pan_suffix = '0827' and net_id_ems = 'MCI' and amt_recon_net = 2700;
select * from nqp1bcfs.ems_case where tstamp_trans = '2020062209253467';
select * from nqp1bcfs.fin_l202004 where pan_prefix = '511565' and pan_suffix = '3215' --and amt_recon_net = 137300
and sys_trace_audit_no = '886866';
--and retrieval_ref_no = '00004436640';
select data_priv_acq_fmt,data_priv_iss_fmt from nqp1bcfs.fin_record201912 where tstamp_trans = '2019123109124946' and uniqueness_key = 28611;
select l.tstamp_trans,l.uniqueness_key,act_code,pan_prefix,pan_suffix,l.amt_recon_net,r.amt_tran,r.cur_tran,retrieval_ref_no,sys_trace_audit_no,l.APPROVAL_CODE
from nqp1bcfs.fin_l201908 l --where pan = 'smemQHSYuyFGIoxM' and amt_Recon_net = 1172 and retrieval_ref_no = '920231670881' order by tstamp_trans asc;
inner join nqp1bcfs.fin_record201908 r on r.tstamp_trans = l.tstamp_trans and r.uniqueness_key = l.uniqueness_key
where l.tstamp_trans between '2019080100000000' and '2019080123595999' and r.cur_tran <> '840' 
and net_id_acq = 'CRS';--pan_prefix = '511165' and pan_suffix = '7642' and  retrieval_ref_no = '832100294153';
select * from nqp1bcfs.fin_record201912 where tstamp_trans = '2019120208521857' and uniqueness_key = 21654;
select adl_data_priv_acq from nqp1bcfs.fin_record201911 where tstamp_trans = '2019110622521277' and uniqueness_key = 29006;

--select ref_data_iss_fmt,ref_data_acq_fmt,net_id_acq,data_priv_acq_fmt, data_priv_iss_fmt,net_id_iss, ADL_DATA_PRIV_ACQ, REF_DATA_ACQ, DATA_PRIV_ACQ,
--DATA_PRIV_ISS,func_code, ref_data_iss 
select * from nqp1bcfs.fin_record201906 where tstamp_trans = '2019120620084468' and uniqueness_key = 30642;
select * from nqp1bcfs.fin_l201912 where pan = 'pCCtXTfRLWPERGQF' and approval_code = '040004';
select * from nqp1bcfs.ems_case where pan_prefix = '511565' and pan_suffix = '6127' and retrieval_ref_no = '85227003724';
select * from nqp1bcfs.ems_case where tstamp_trans = '2020070410415094';
select * from nqp1bcfs.ems_case where case_id = 11415095;
select * from nqp1bcfs.ems_phase where case_id = 11324773 order by tstamp_created asc;
select * from nqp1bcfs.ems_case_vnt where case_id = 11312186;
select * from nqp1bcfs.ems_case_mci where case_id = 11415095;
select * from nqp1bcfs.ems_case_mci where claim_id = '200182267224';
select * from nqp1bcfs.ems_fraud_mci where case_id = 10553907;
select * from nqp1bcfs.ems_phase_vnt where 
--vrol_case_no = '1699112614';
case_id = 10829186 order by tstamp_created asc;
select * from nqp1bcfs.ems_phase_mci where case_id = 11382130 order by tstamp_created asc;
select * from nqp1bcfs.ems_phase_vnt_vrol where case_id = 10305664;
select * from nqp1bcfs.ems_phase_vnt_vrol where question_fields like '%Cardholder resides in Arizona not New York</Ex%';
    
select * from nqp1bcfs.ems_document where case_id = 11154809 ORDER by seq_no asc;
select * from nqp1bcfs.ems_fraud_vnt where case_id = 10072805;
select * from nqp1bcfs.ems_fraud_mci where case_id = 10553907;
select * from nqp1bcfs.ems_national_net where case_id = 11348480;
select * from nqp1bcfs.ems_national_net n inner join nqp1bcfs.ems_case c on c.case_id = n.case_id
where acq_ref_no = '02305370070600055944315' and case_type_ind = 'X';
select state_tstamp from nqp1bcfs.ems_case c inner join nqp1bcfs.ems_case_vnt v on v.case_id = c.case_id
where net_id_ems = 'VNT' and request_type = 'FDRA' AND STATUS in ('REJ1') AND VCR_IND = 'Y'
and state_tstamp < '2018042000000000';

select * from nqp1bcfs.ems_data_chg where case_id = 11272185 order by tstamp_created asc;
select * from nqp1bcfs.di_data where import_key = '20200602003254' order by TSTAMP_PARSED asc;
select c.case_id,REQUEST_TYPE,STATUS,di_file_id, TSTAMP_parsed,data_buffer from nqp1bcfs.di_data d
inner join nqp1bcfs.ems_case c on c.case_no = d.import_key
where tstamp_parsed > '2018101500000000' 
and reject_codes like 'CASE UPDATED WITH DOC,TRANSITION FAILED:%'
and data_buffer like '%INFR%'
and c.case_extension = 'MCI'
and request_type IN ('REP1','DOC4') AND STATUS = 'CLOA'
order by di_file_id desc;

select * from nqp1bcfs.ems_comment where case_id = 5422126;

select * from nqp1comn.institution where inst_id= '071901604';
SELECT card_system FROM NQP1COMN.INSTITUTION_BIN WHERE INST_ID = '075901561';

select * from nqp1bcfs.api_queue_control where case_id = 10828900 order by queue_id asc;
select * from nqp1bcfs.api_queue_control order by queue_id desc;where queue_id = 3014456;
select count(*) from nqp1bcfs.api_queue_control where api_state = 'AS' ORDER by tstamp_created asc;
and req_type = 'CBAckResponse' order by substr(tstamp_created,1,8) desc,case_id asc;
api_state = 'PE' and api_type = 'MCOM' and req_type = 'RRGetDocumentResponse' and api_result not in 
('Error: Transition failed from CHBQ/PNDR to CHBQ/PNDR','Error: Transition failed from CH2Q/PNDR to CH2Q/PNDR')  order by queue_id desc;--queue_id = 1641961;

select * from nqp1bcfs.api_queue_control where api_type = 'MQUE' and REQ_TYPE = 'MCIIREPUNW' order by queue_id desc;
select * from nqp1bcfs.api_queue_control where api_type = 'MQUE' and REQ_TYPE = 'MCIDOCCOMP' order by queue_id desc;
select * from nqp1bcfs.api_queue_control where api_type = 'MCOM' and REQ_TYPE like '%Status%'--CBCreateResponse
and api_state = 'AC' order by queue_id desc;
select * from nqp1bcfs.api_queue_control where api_type = 'MCOM' and api_state = 'PE' order by queue_id desc;
select * from nqp1bcfs.api_queue_response where queue_id = 3086580 ORDER BY SEQ_NO ASC;
select * from nqp1bcfs.api_queue_request where queue_id = 3521908 ORDER BY SEQ_NO ASC;
select * from nqp1bcfs.message_log where tstamp_transmit like '20200707%' and data_buffer like '%20200622006676%' order by tstamp_transmit desc;-- where msg_session = '193387';
select * from nqp1bcfs.message_log where tstamp_transmit like '20200626%' and msg_session = '8bd33f98-f593-44a4-a0f0-776b5d90e2a0' order by tstamp_transmit asc;-- where msg_session = '193387';
select * from nqp1bcfs.message_log where tstamp_transmit like '2020050611%' and ((sender = 'DRCClien' and receiver like 'PRDWS%')
--order by TSTAMP_TRANSMIT desc;
or (sender = 'XICASE' and receiver = 'DRCClien'))order by msg_session asc,tstamp_transmit asc;-- AND RECEIVER <> 'MCOM';
select * from nqp1bcfs.message_log where tstamp_transmit like '2020050608%' order by tstamp_transmit desc;
select * from nqp1bcfs.api_qevent_log where queue_id = 2745360 order by tstamp_created asc;

select * from nqp1bcfs.message_log where tstamp_transmit > '2020011013000000' and sender in ('PRDWS2','XICASE')
/*msg_session in ('1dc780a2-af37-4721-8da4-bdd10bb51b1b',
'9b4fc724-281c-4e1f-aac9-6823e92c4985',
'17a560b4-8ec5-4a69-b973-3b15964485bd',
'dc0584ff-7bb7-4879-abc3-7514f63707bb',
'438245ef-b76d-4944-84cc-e26171d756ba',
'9a8732be-281b-4ea4-ba50-a62387c410d6',
'07424087-a20c-4067-868d-a8ee29fe915d',
'8b087093-2fec-405c-8912-6d11547e1077')*/
order by tstamp_transmit desc;
order by msg_session asc,tstamp_transmit asc;
select * from nqp1bcfs.api_queue_request where queue_id in
--(select queue_id from nqp1bcfs.api_qevent_log where tstamp_created like '201805170439%' and api_state ='SP');
(select queue_id from nqp1bcfs.api_queue_control where case_id = 11264240) order by queue_id asc,seq_no asc;
select * from nqp1bcfs.api_queue_request where queue_id in (select queue_id from nqp1bcfs.api_queue_control where req_type = 'TII') order by queue_id desc; 
select * from nqp1bcfs.api_queue_response where queue_id IN
--(select queue_id from nqp1bcfs.api_queue_control where req_type = 'TII') order by queue_id asc;
(select queue_id from nqp1bcfs.api_queue_control where case_id = 11264240) order by queue_id asc;
--(select queue_id from nqp1bcfs.api_queue_control where REQ_TYPE = 'CBAckResponse') order by queue_id desc;
SELECT * from nqp1bcfs.api_queue_control where queue_id in (
select queue_id from nqp1bcfs.api_queue_response where data_buffer like '%200824513571%') order by queue_id desc;

SELECT * from nqp1cap1.api_queue_control where api_result like '%ME53: Do not recognize status%';
select a.queue_id,A.case_id,req_type from nqp1bcfs.api_queue_control a
where API_TYPE = 'MCOM' and api_state = 'AF'
and case_id in (
5743526,
5743784,
5744914,
5734245,
5745797,
5745740,
5744862,
5743989,
5678860,
5680205,
5673608,
5743533,
5743551,
5735685,
5744284,
5744223,
5745218,
5743585,
5735351,
5743595,
5743544,
5678521,
5758795,
5639015,
5779486,
5758152,
5737380,
5720141,
5714299,
5708019,
5707614,
5705366,
5705360,
5705353,
5697963,
5691293,
5690878,
5657789,
5621124,
5576166,
5576147,
5565411,
5560109,
5558628,
5558237,
5552068,
5455359,
5659790,
5659578);

--select a.queue_id,tstamp_event,req_type,data_buffer 
--select A.QUEUE_ID,a.tstamp_created, A.case_id,request_type,status,claim_id,acq_ref_no,ISS_ICA,r.data_buffer
select distinct A.case_id,case_no,a.Queue_id,REQUEST_TYPE,status,state_tstamp,a.tstamp_Created,acq_ref_no,claim_id
from nqp1bcfs.api_queue_control a 
--inner join nqp1bcfs.api_queue_response r on r.queue_id = a.queue_id
inner join nqp1bcfs.ems_case c on c.case_id = a.case_id
inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
inner join nqp1bcfs.ems_national_net n on n.case_id = c.case_id
--where data_buffer like '%AUTHORIZATION_FAILED%'
where api_state = 'AF'
and net_Rules = 'PPM'
--where request_type = 'DOC4' AND STATUS = 'GETD'
and REQ_TYPE = 'CBAckResponse'
--and a.tstamp_created > '2020050700000000'
--and status = 'REJR'
order by a.case_id ASC,tstamp_created desc;

select * from nqp1bcfs.api_qevent_log where queue_id  IN
(select queue_id from nqp1bcfs.api_queue_control where case_id = 10017553) order by tstamp_created asc;--queue_id asc,tstamp_created asc;
select * from nqp1bcfs.api_queue_request where data_buffer like '%SubmitFraud%' order by queue_id desc;

select * from nqp1bcfs.message_log where tstamp_transmit like '20200706%' and data_buffer like '%20200706002828%' order by tstamp_transmit asc;
select * from nqp1bcfs.message_log where tstamp_transmit like '20200706%' and msg_session = '87c6375a-eff2-4d5f-9759-a23e11abdf68' order by tstamp_transmit asc,seq_no asc;

select c.queue_id,api_result, data_buffer
from nqp1bcfs.api_queue_request r inner join nqp1bcfs.api_queue_control c
on c.queue_id =r.queue_id
where data_buffer like '%SIInitiateDisputeFromTransactionOrCaseRequest%'
and c.API_STATE = 'AC'
order by queue_id desc;

select * from nqp1bcfs.task_context where CONTEXT_KEY = '@BCBEGIN';
--select pan_prefix,',',pan_suffix,',',sys_trace_audit_no,',',retrieval_ref_no,',',substr(tstamp_local,0,8),',',
--substr(tstamp_trans,0,8),',',amt_tran,',',reason_code,',',frd_posted_date,',',frd_report_date,','
--substr(tstamp_trans,0,8),',',amt_tran,',04,',frd_posted_date,',',frd_report_date,','
--select case_no,tstamp_trans,tstamp_local,pan_prefix,pan_suffix,
select
'delete * from nqp1bcfs.ems_case where case_id = ',x.case_id,';'
--'update nqp1bcfs.fin_l',substr(x.tstamp_trans,1,6),'  set fin_type = ''010'' where tstamp_trans = ',
--''''||x.tstamp_trans||''' and uniqueness_key = ',x.uniqueness_key,';'
from 
(select c.case_id,tstamp_trans,uniqueness_key 
--select c.case_id,case_no,state_tstamp,substr(acq_ref_no,1,23),substr(ref_data_acq,1,23)
from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id and t.tstamp_Created = c.state_tstamp
--inner join nqp1bcfs.ems_phase_mci p on p.case_id = t.case_id and p.tstamp_Created = t.phase_tstamp
--inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
inner join nqp1bcfs.ems_national_net n on n.case_id = c.case_id
inner join nqp1bcfs.ems_fraud_mci f on f.case_id = c.case_id
WHERE c.request_type = 'FDRA'
AND status = 'REJR' 
AND NET_ID_EMS = 'MCI'
and reason_code = ' '
and tstamp_trans <> ' '
and acq_ref_no = ' '
--and acq_ref_no <> ' '
--and substr(acq_ref_no,1,23) <> substr(ref_data_acq,1,23)
--and state_tstamp > '2020062100000000'
--and substr(tstamp_local,0,6) = substr(tstamp_trans,0,6)
and substr(tstamp_trans,0,6) > '201905')x;
order by c.state_tstamp asc;

select * from nqp1comn.x_net_inst_id where pan_prefix like '%521105%';--pan_prefix like '%522132%' and net_id = 'MCI';

--select distinct trim(leading '0' from iss_ica)iss_ica 
--select C.case_id,case_no,request_type,status,STATE_TSTAMP, iss_ica, amt_tran 
--select c.CASE_id, case_no, PAN_PREFIX,pan_suffix,state_tstamp,tran_identifier, retrieval_ref_no, sys_trace_audit_no,amt_tran,
--card_acpt_loc
--SELECT c.case_id,case_no,state_tstamp, err_msg_1,err_de_1,err_msg_2,err_de_2
--select count(*)
--select C.case_id,case_no,t.tstamp_created,request_type,status,STATE_TSTAMP, REQUEST_TYPE_PREV,STATUS_PREV,REQUEST_TYPE_NEXT,STATUS_NEXT
--select distinct acq_bin, net_id_iss,request_type, status,merchant_cat_code, v.support_info
--select c.case_id,case_no,pan_prefix,net_id_acq,tstamp_trans,state_tstamp,tran_identifier, tstamp_local,date_recon_net,c.request_type, status,v.support_info
--,r.DATA_BUFFER
--select a.queue_id,c.case_no
--select count(*),request_type,status
--select count(*),sum(amt_adjustment)
--select count(*),substr(t.tstamp_created,1,8) D1,request_type_next,status_next,SUM(amt_adjustment)
select count(*),substr(tstamp_trans,1,6)
--select c.case_no, c.case_id,request_type,status--,a.queue_id,data_buffer
from nqp1bcfs.ems_case c
--inner join nqp1bcfs.assoc_tran_vnt t on t.case_id = c.case_id
--inner join nqp1bcfs.ems_case_vnt u on u.case_id = c.case_id
inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
--inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id and T.tstamp_created = C.state_tstamp
--inner join nqp1bcfs.ems_phase_mci m on m.case_id = c.case_id and m.tstamp_created = t.phase_tstamp
--inner join nqp1bcfs.ems_national_net n on n.case_id = c.case_id
--inner join nqp1bcfs.ems_phase p on p.case_id = t.case_id and p.tstamp_created = t.phase_tstamp
--inner join nqp1bcfs.ems_document d on d.case_id = c.case_id
--inner join nqp1bcfs.api_queue_control a on a.case_id = c.case_id
--inner join nqp1bcfs.api_queue_ReQUEST r on r.queue_id = a.queue_id
--where c.case_id in (
--select distinct case_id from nqp1bcfs.ems_transition where user_id = 'P951DRCP'
--and request_type_next not in ('UNW1','FDRA'))
--and case_type_ind in ('D','N')
where net_id_ems = 'MCI'
and case_no > '20200621000000'
and m.process_code = ' ' group by substr(tstamp_trans,1,6) order by substr(tstamp_trans,1,6) asc;
--and request_type = 'UNW1'
--and status = 'PNDR';
--and err_de_1 not in ('04','05')
--order by err_msg_1 asc,err_de_1 asc,err_msg_2 asc,err_de_2 asc;
--and STATE_TSTAMP between '2020040300000000' and '2020041100000000'
--and net_rules = 'PPM'
and request_type = 'UNW1'
and status = 'CLOC'
and user_id = 'P951DRCP'
--and api_result like '%BIN%'
and c.case_id not in (
select c.case_id
from nqp1bcfs.ems_case c
left outer join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id and T.tstamp_created = C.state_tstamp
where net_id_ems = 'MCI'
and case_no > '20200621000000'
and request_type = 'UNW1'
and status = 'CLOC'
and user_id = 'P951DRCP'
and iss_ica <> ' ')
--and tstamp_trans <> ' '
--and iss_ica like '%10116%'
group by substr(tstamp_trans,1,6)
order by substr(tstamp_trans,1,6);
--order by C.case_ID asc;
--and t.amt_adjustment < c.amt_recon_net
--AND API_STATE = 'AC' AND REQ_TYPE = 'CBCreateResponse' and data_buffer like '<chargebackId>%';
--and request_type_prev  in ('CHB1','CHB2')
--and STATUS_prev  = 'REJ1'
--and STATUS_next  = 'FWRD'
--AND STATUS  = 'SENT'
--AND T.REASON_CODE = '13'
--and t.tstamp_created > '2020052112000000';
--AND USER_ID = 'SYSTEM'
--and r.data_buffer like '%DuplicateTranId%';
--and r.data_buffer not like '%<ARN>%'
--AND V.SUPPORT_INFO LIKE '%User tried%';
--and p.reason_code = '10'
--and case_type_ind = 'X'
--and state_tstamp > '2018041500000000'
--and api_result like '%EMS_DOCUMENT%'
--and d.doc_type = 'DCF_REQ'
--and r.data_buffer like '%DisputeQuestionnaire%';
--and net_id_ems <> 'ILK'
--and institution_name like '0C98%';
--AND ERR_VROL_MSG1 = 'W80';
--AND p.user_role = 'A'
--order by state_tstamp asc;

--select count(*),sum(amt_adjustment)
select pan_prefix,pan_suffix,acq_ref_no,amt_adjustment
from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_national_net n on n.case_id = c.case_id
inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id --and T.tstamp_created = C.state_tstamp
where net_id_ems = 'MCI'
and iss_ica like '%1965%'
and ((request_type_next = 'CHB1' and status_next = 'PNDR') OR (request_type_next = 'CHB2' and status_next = 'PNDR'))
and t.tstamp_created between '2020040308000099' and '2020040408000099'
and t.user_id = 'SYSTEM'
order by pan_prefix asc,pan_suffix asc,acq_Ref_no desc;

select * from nqp1bcfs.dX_data_control where DX_FILE_TYPE = 'VRRDM5' and date_recon = '20200717' and entity_id = 'BCFS' ORDER BY DATE_RECON DESC;
select * from nqp1bcfs.dX_data_control where DX_FILE_TYPE = 'MCTQR4' and date_recon = '20191206' ORDER BY DATE_RECON DESC;
select * from nqp1bcfs.dx_data_control where date_recon = '20200702' and dx_file_type = 'MCMIN' ORDER BY dx_file_id DESC;
select * from nqp1bcfs.dx_data_20200718 where dx_file_id = 4453335; and data_buffer like '%200824513571%' order by seq_no asc;
select * from nqp1bcfs.dx_data_20200630 where dx_file_id = 4451247 and seq_no > 5566 order by seq_no asc;
select * from nqp1bcfs.dx_data_20200421 where dx_file_id = 4440406 and seq_no > 1233 and data_buffer like '%20200314003100%' order by seq_no asc;
select * from nqp1bcfs.dX_data_control where DX_FILE_TYPE = 'ECOUT' and date_recon = '20200717';
select * from nqp1comn.dx_report_column where dx_report_id = 12;

select * from nqp1bcfs.di_data where di_file_id = 6877942;--data_buffer like '%10127152%';
select * from nqp1bcfs.di_data_control where DI_FILE_ID = 6877942;
select * from nqp1comn.institution where cust_id = 'BCFS' and name like '%PLAINS%';

--*** PPDEXC QUERY/AIMS BILLING ***--                                   
--SELECT C.CASE_NO,C.INST_ID_RECON_ISS, c.REQUEST_TYPE                  
SELECT C.CASE_NO,C.INST_ID_RECON_ISS,INSTITUTION.BANK_ID              
---SELECT COUNT(*) , INSTITUTION.BANK_ID, C.CASE_ID                     
--,C.INST_ID_ISS                                                        
FROM NQP1BCFS.EMS_CASE C INNER JOIN NQP1BCFS.EMS_PHASE P              
ON C.CASE_ID = P.CASE_ID INNER JOIN                                   
(SELECT EMS_PHASE.CASE_ID,MIN(EMS_PHASE.TSTAMP_CREATED) TSTAMP_CREATED
FROM NQP1BCFS.EMS_PHASE EMS_PHASE                                     
GROUP BY EMS_PHASE.CASE_ID) TISS                                      
ON C.CASE_ID = TISS.CASE_ID                                           
AND P.TSTAMP_CREATED = TISS.TSTAMP_CREATED                            
INNER JOIN NQP1COMN.INSTITUTION INSTITUTION                           
ON INSTITUTION.INST_ID = C.INST_ID_RECON_ISS                          
---ON INSTITUTION.INST_ID = C.INST_ID_ISS                               
WHERE C.CASE_NO LIKE '201908%'                                        
AND INST_ID_RECON_ISS = '842500289'                                   
AND C.NET_ID_EMS NOT IN ('MCI','VNT')                                 
AND P.USER_ROLE = 'I'                                                 
AND INSTITUTION.CUST_ID = 'BCFS'                                      
AND INSTITUTION.CC_CHANGE_GRP_ID IS NULL                      
AND INSTITUTION.CC_STATE IN ('A','I')                         
--AND BANK_ID = '0G2W'                                          
GROUP BY INSTITUTION.BANK_ID, INST_ID_RECON_ISS,C.CASE_NO                      
--UNION SELECT C.CASE_NO,C.INST_ID_RECON_ACQ                    
UNION SELECT C.CASE_NO,C.INST_ID_RECON_ACQ,INSTITUTION.BANK_ID
---UNION SELECT COUNT(*),INSTITUTION.BANK_ID, C.CASE_ID         
--,C.INST_ID_ACQ                                                
FROM NQP1BCFS.EMS_CASE C                                      
INNER JOIN NQP1BCFS.EMS_PHASE P                               
ON C.CASE_ID = P.CASE_ID INNER JOIN                           
(SELECT EMS_PHASE.CASE_ID,MIN(EMS_PHASE.TSTAMP_CREATED)       
 TSTAMP_CREATED FROM NQP1BCFS.EMS_PHASE EMS_PHASE             
GROUP BY EMS_PHASE.CASE_ID) TISS                              
ON C.CASE_ID = TISS.CASE_ID                                   
AND P.TSTAMP_CREATED = TISS.TSTAMP_CREATED                    
INNER JOIN NQP1COMN.INSTITUTION INSTITUTION                   
ON INSTITUTION.INST_ID = C.INST_ID_RECON_ACQ                  
---ON INSTITUTION.INST_ID = C.INST_ID_ACQ                       
WHERE  C.CASE_NO LIKE '201908%'                               
AND C.INST_ID_RECON_ACQ = '842500289'   
AND C.NET_ID_EMS NOT IN ('MCI','VNT')   
AND P.USER_ROLE = 'A'                   
AND INSTITUTION.CUST_ID = 'BCFS'        
AND INSTITUTION.CC_CHANGE_GRP_ID IS NULL
AND INSTITUTION.CC_STATE IN ('A','I')   
--AND BANK_ID = '0G2W'                    
GROUP BY INSTITUTION.BANK_ID,INST_ID_RECON_ACQ,C.CASE_NO; 

SELECT * FROM NQP1COMN.INSTITUTION WHERE BANK_ID LIKE '%N37%';
select * from nqp1comn.institution_bin where inst_id = '841097065';

select c.case_id,case_no,t.tstamp_Created,t.request_type_next,t.status_next
--select count(*),inst_id_recon_iss
from nqp1bcfs.ems_case c inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id
where case_extension = 'VNT' 
and inst_id_recon_acq = '841097065' 
and t.tstamp_created like '201911%' and t.action like '%RespT3%';
--group by inst_id_recon_iss order by inst_id_recon_iss;

select fee_date,ENTITY_ID ,ITEM_COUNT,FEE_DATA 
from nqp1bcfs.fee_billing where FEE_DATE = '201911' 
and entity_id = '841097065';-- and fee_data = '220504360' order by entity_id;
select * from nqp1bcfs.di_data where import_key = '20190924006353' order by di_file_id desc;

select
--'update nqp1bcfs.ems_case_vnt set rol_tran_id = '' '' where case_id = ',
--x.case_id,';'
'update nqp1bcfs.api_queue_control set req_type = ''TIII'' where queue_id = ',
x.queue_id,';'
from
(SELECT queue_id from nqp1bcfs.api_queue_control
where req_type = 'TII'
and case_id in 
(select case_id from nqp1bcfs.ems_case where 
case_type_ind = 'D' and tstamp_trans in (
select tstamp_trans from nqp1bcfs.ems_case where case_id in
(7495664,7501550,7511200,7511202,7511204,7511207,7511208,7511210,7509519,7501533,7500258,7500257,7515627,7498288,7500381,7511007,7515277,7501528,7497884,7510712,
7516518,7516520,7516522,7551101,7510294,7510293,7510292,7511266,7509234,7511152,7508714,7510374,7508545,7500831,7510922,7511457,7511312,7509296,7508978,7514453,
7518657,7507673,7507672,7509076,7510785,7510784,7510783,7510782,7510780,7516448,7517534,7514758,7508541,7507669,7509518,7549390,7549952,7549951,7549950,7549949,
7511418,7517957,7517956,7508942,7514109,7514857,7515272,7510040,7509075,7549387,7549386,7549947,7511531,7509650,7509047,7509046,7509045,7507155,7508979,7509894,
7554275,7510824,7507304,7507303,7507302,7507301,7507300,7510776,7509937,7509172,7513918,7510542,7511532,7510541,7507200,7509012,7509011,7549392,7549402,7549400,
7516510,7516511,7517975,7508192,7511441,7511389,7508538,7508537,7508535,7507611,7507604,7507602,7507603,7507601,7514357,7508534,7517877,7507600,7507599,7507598,
7507597,7507596,7507595,7516512,7518563,7518121,7518534,7518533,7508531,7507610,7507609,7507608,7507607,7507606,7515786,7540919,7540916,7507605,7507722,7516513,
7516514,7516516,7508553,7518743,7514435,7516519,7516521,7518697,7544665,7546836,7565401,7585550,7585679,7554994,7578697,7579410)))) x;

select * from nqp1bcfs.di_data where import_key = '20180605005288';

select c.case_id, case_type_ind,case_no,tstamp_trans, vrol_case_no
from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp1bcfs.ems_phase_vnt v on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
inner join nqp1bcfs.ems_phase p on p.case_id = t.case_id and p.tstamp_created = t.phase_tstamp
where net_rules in ('VN3','PV3')
and c.request_type = 'CHBQ'
AND STATUS  = 'REJR'
and p.reason_code = '10'
and case_type_ind = 'X'
and v.support_info like '%Internal%'
union all
select c.case_id, case_type_ind,case_no,tstamp_trans, vrol_case_no
from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp1bcfs.ems_phase_vnt v on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
where case_type_ind = 'D'
and request_type = 'FDRA'
AND STATUS in ('SDRC','REJ2')
and tstamp_trans in (
select tstamp_trans from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp1bcfs.ems_phase_vnt v on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
inner join nqp1bcfs.ems_phase p on p.case_id = t.case_id and p.tstamp_created = t.phase_tstamp
where net_rules in ('VN3','PV3')
and c.request_type = 'CHBQ'
AND STATUS = 'REJR'
and p.reason_code = '10'
and case_type_ind = 'X'
--and state_tstamp > '2018052400000000'
and v.support_info like '%Internal%')
--AND V.SUPPORT_INFO not LIKE '%Internal%'
order by tstamp_trans, case_type_ind asc;

SELECT * from nqp1comn.emsr_rule_set where net_id_ems = 'MC3';
select * from nqp1comn.emsr_net_rule_use where network_rules = 'MC2';
select * FROM nqp1comn.emsr_resn_detail where rule_set_id = 'VISA 3' 
AND PHASE_ID = 'PARB' AND RESN_CODE_ID IN ('10','11','12','13','F','P');

select * from nqp1comn.emsr_action_detail where phase_id = 'PARB' AND STATUS_ID = 'ACPC' AND SEQ_NO = 25;

select * from nqp1comn.emsr_transition where RULE_SET_ID = 'PULSE 3' 
AND PHASE_ID = 'DOCR' AND STATUS_ID = 'SDRC'
--AND NEXT_PHASE_ID = 'CHB1' AND NEXT_STATUS_ID = 'FWRD';
and role_ind = 'A';
select * from nqp1comn.emsr_desc_text where description_id = '0000028037';

select * from nqp1bcfs.ems_case where tstamp_trans = ' ' and cur_tran NOT IN ('840',' ')
and case_extension = 'VNT' order by case_no desc;

select c.case_id,CASE_NO, STATE_TSTAMP,PAN_PREFIX,PAN_SUFFIX,AMT_TRAN, retrieval_ref_no
from nqp7ispa.ems_case c 
where NET_RULES = 'V3I' and request_Type = 'CHB1' AND STATUS = 'SDRC' and STATE_TSTAMP < '2018072000000000'
and case_extension = 'VNT' order by pan_prefix asc, pan_suffix asc, retrieval_ref_no;

SELECT * FROM NQP1COMN.EMSR_ACCOUNT_ENTRY WHERE RULE_SET_ID = 'VISA 3';

SELECT DISTINCT C.CASE_ID,t.amt_adjustment,REQUEST_TYPE,STATUS,INST_ID_ISS,d.COLUMN_CHANGED ,d.COLUMN_NEW_VALUE 
--SELECT DISTINCT C.CASE_ID,t.amt_adjustment,REQUEST_TYPE,STATUS,INST_ID_ISS,M.ERR_DE_1 ,M.ERR_MSG_1, M.ERR_SUBFIELD_ID_1 
FROM NQP1BCFS.EMS_CASE C
INNER JOIN NQP1BCFS.EMS_TRANSITION T ON T.CASE_ID = C.CASE_ID
LEFT OUTER join nqp1bcfs.ems_data_chg d on d.case_id = t.case_id and d.tstamp_created = t.tstamp_created
--INNER JOIN NQP1BCFS.EMS_PHASE_MCI M ON M.CASE_ID = T.CASE_ID AND M.TSTAMP_CREATED = T.TSTAMP_CREATED
WHERE CASE_EXTENSION IN ('VNT')
AND T.TSTAMP_cREATED LIKE '2018%'
AND T.REQUEST_TYPE_NEXT = 'PARB' AND T.STATUS_NEXT = 'REJR'
and inst_id_iss in(
'990109545',
'881092431',
'841091977',
'820410362',
'823620104',
'063100277', 
'840235006',
'124302529')
and d.column_changed = 'SUPPORT_INFO'
AND D.COLUMN_NEW_VALUE NOT LIKE 'Internal%'
--and c.status <> 'SDRC'
ORDER BY INST_ID_ISS ASC;

select distinct case_no, vrol_case_no, r.queue_id
from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp1bcfs.ems_phase_vnt v on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
inner join nqp1bcfs.api_queue_control a on a.case_id = c.case_id
inner join nqp1bcfs.api_queue_request r on r.queue_id = a.queue_id
inner join nqp1bcfs.api_qevent_log l on l.queue_id = r.queue_id
where case_no in (
'20180430003935','20180427001207','20180410004193','20180503006381',
'20180511003453','20180423006372','20180426006925','20180426006870','20180502005772',
'20180508006982','20180508002184','20180502005886',	'20180521004893',
'20180524002165','20180423005449','20180508001816','20180504006179','20180530004172','20180508004025',
'20180611002291','20180611002290','20180611002289','20180424003598','20180504003896','20180503004226',
'20180510001630','20180510001596','20180523006854','20180608005103','20180514005752','20180427003523',
'20180514002413','20180511006061','20180613006426','20180510003126','20180509003001','20180510005830',
'20180510005831','20180515001795','20180510005827','20180515006585','20180504005252','20180606003943',
'20180510003981','20180516003169','20180516003170','20180516003156','20180607007127','20180531005444',
'20180508002447','20180525003435','20180511005732','20180515005225','20180612004098','20180612004101',
'20180514002480','20180518002979','20180524006213','20180514002455','20180605001564','20180608002979',
'20180608002980','20180611003232','20180615005239','20180615005240','20180608001764','20180608001761',
'20180604005753','20180515005120','20180612004976','20180608005174')
and r.data_buffer like '%SICreateDisputePreArbResponseRequest%'
order by case_no asc;
--and l.api_result like '%Socket%';

select case_no,amt_adjustment from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
where case_no in (
'20180410004193','20180423005449','20180423006372','20180424003598','20180426006870','20180426006925',
'20180427001207','20180427003523','20180430003935','20180502005772','20180502005886','20180503004226',
'20180503006381','20180504003896','20180504005252','20180504006179','20180508001816','20180508002184',
'20180508002447','20180508004025','20180508006982','20180509003001','20180510001596','20180510001630',
'20180510003126','20180510003981','20180510005827','20180510005830','20180510005831','20180511003453',
'20180511005732','20180511006061','20180514002413','20180514002455','20180514002480','20180514005752',
'20180515001795','20180515005120','20180515005225','20180515006585','20180516003156','20180516003169',
'20180516003170','20180518002979','20180523006854','20180524006213','20180525003435','20180530004172',
'20180531005444','20180604005753','20180605001564','20180606003943','20180607007127','20180608001761',
'20180608001764','20180608002979','20180608002980','20180608005103','20180608005174','20180611002289',
'20180611002290','20180611002291','20180611003232','20180612004098','20180612004101','20180612004976',
'20180613006426','20180615005239','20180615005240')
order by case_no asc;

SELECT DISTINCT
C.CASE_NO,
C.PAN,
C.AMT_RECON_NET,                            
C.TSTAMP_TRANS,
C.STATUS,
C.TSTAMP_LOCAL,
D.DOC_TYPE,
D.SEQ_NO,
T.EMS_COMMENT,
M.CFG_DESCRIPTION                          
FROM NQP1BCFS.EMS_CASE C               
INNER JOIN NQP1BCFS.EMS_COMMENT T 
ON C.CASE_ID = T.CASE_ID               
LEFT OUTER JOIN NQP1BCFS.EMS_DOCUMENT D
ON T.CASE_ID = D.CASE_ID    
LEFT OUTER JOIN NQP1COMN.MISC_CFG_DATA M
ON D.DOC_TYPE = M.DATA_VALUE 
WHERE D.DOC_TYPE LIKE 'REQ_DOC%'
AND C.INST_ID_RECON_ISS = '880109040'
and c.case_id = 6980923;--6860041;
--AND C.CASE_NO LIKE '2018%';
--order by case_no asc;

select * from nqp1comn.misc_cfg_data where DATA_VALUE = 'REQ_DOC070';

select * from nqp1comn.as_user_logon where user_id = 'W951B6X';
select * from nqp1comn.as_user_profile where user_id = 'WZ99149';
select * from nqp1BCFS.DX_DATA_CONTROL where dx_file_TYPE = 'EMSACT' ORDER BY DX_FILE_ID DESC;
select * from nqp1comn.dx_proc_dest;-- where DX_FILE_GROUP = 'SWITCH';
select * from nqp1bcfs.ems_case_context where case_id = 10553907;

select * from nqp1bcfs.ems_case where NET_RULES = 'PPG' order by case_id desc;
select * from nqp1comn.emsr_net_rule_use where ACQ_PROC_GRP = 'MCI';
select * from nqp1comn.emsr_rule_set where net_id_ems = 'PPM'; -- AND CUST_ID = 'FISB';
select * from nqp1comn.emsr_transition where rule_set_id = 'MC2-PPM';

select q.queue_id, c.case_no, c.case_id, c.request_type, c.status       
,q.tstamp_event, q.req_type , q.api_state, q.retry_count, q.api_result,tran_identifier,data_buffer
from nqp1bcfs.api_queue_control Q  
inner join nqp1bcfs.api_queue_request r
on r.queue_id = q.queue_id
inner join nqp1bcfs.ems_case c                              
on q.case_id = c.case_id       
inner join nqp1bcfs.ems_case_vnt v
on v.case_id = c.case_id
where (api_state = 'AF' and c.status = 'FWRD') 
--or (api_state in ('AW','AP')                                
--and tstamp_event < TO_CHAR(CURRENT_TIMESTAMP -  NUMTODSINTERVAL(1, 'HOUR'), 'yyyymmddhh24MISS'))   
order by queue_id asc; 

select * from nqp1comn.institution where bank_id like '%ZS4%';

select case_no from nqp1bcfs.ems_case where case_no like '20181213000002' order by case_no desc;
select * from nqp1bcfs.ems_case where case_no = '20181214000001';
select * from nqp1bcfs.di_data order by tstamp_parsed asc; --where IMPORT_KEY = '20181214000001';
select * from nqp1bcfs.di_data where di_file_id in (5543192,5543194) order by tstamp_parsed asc;
SELECT * FROM NQP1COMN.CRTAGET WHERE TAGLID = 'BCCIAS';
SELECT * FROM NQP1COMN.CRTAGET WHERE TASKID = 'BCEB02';

SELECT COUNT(*) ROW_COUNT,C.INST_ID_RECON_ISS,I.BANK_ID FROM NQP1BCFS.API_QUEUE_CONTROL Q 
INNER JOIN NQP1BCFS.EMS_CASE C ON Q.CASE_ID = C.CASE_ID 
INNER JOIN NQP1COMN.INSTITUTION I ON C.INST_ID_RECON_ISS = I.INST_ID 
WHERE Q.REQ_TYPE = 'TII' AND Q.API_STATE = 'AC' 
AND (Q.API_RESULT NOT LIKE 'Internal Error%') 
AND Q.TSTAMP_EVENT BETWEEN '2018120100000000' AND  '2018120123595999' 
AND I.CUST_ID = 'BCFS'
GROUP BY I.BANK_ID,C.INST_ID_RECON_ISS;

select * from nqp1comn.ems_mci_sent s inner join nqp1bcfs.ems_case_mci m on m.case_id = s.case_id
where cust_id = 'BCFS' and case_type_ind = 'E' and iss_ica like '%21601%';

--select entity_id,fee_data,i.bank_id from NQP1BCFS.fee_billing f
select * from NQP1BCFS.fee_billing f
--inner join nqp1comn.institution i on i.inst_id = f.entity_id
--inner join nqp1comn.institution_bin b on b.inst_id = f.entity_id
where fee_date = '201903' 
--and fee_data like '%4310%'
--and b.card_system = 'PREPDCDC'
--and i.cust_id = 'BCFS'
--and fee_data not like '22050%' and fee_data not like '22000%'
--and entity_id = '000002516'
order by fee_data asc;

SELECT name FROM nqp1comn.institution where inst_id = '101089700';
select card_system from nqp1comn.institution_bin WHERE INST_ID = '000002862';

select c.case_id,inst_id_recon_acq,t.request_type_prev,t.status_prev,t.request_type_next,t.status_next,t.action 
from nqp1bcfs.ems_case c 
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id
--inner join nqp1comn.institution_bin i on i.inst_id = c.inst_id_recon_iss
where inst_id_recon_iss = '067005158' 
and t.tstamp_created like '201903%' and action like '%RespT1%'
order by inst_id_recon_acq desc;

select c.case_id, STATUS from nqp1bcfs.ems_case c inner join nqp1bcfs.ems_transition t
on t.case_id = c.case_id 
--and t.tstamp_created = c.state_tstamp
where net_id_ems = 'VNT' AND CASE_NO > '20180501000000' AND REQUEST_TYPE_PREV = 'PARB' AND STATUS_PREV = 'DNST' 
ORDER BY C.CASE_ID DESC;

select c.case_id from nqp1cap1.ems_case c
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id
where net_id_ems = 'MCI' and request_type_next = 'DOC3' and status_next = 'DNYF';

--select distinct iss_ica,inst_id_recon_iss,i.name from nqp1bcfs.ems_case c
select case_no,iss_ica,inst_id_recon_iss,i.name from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
inner join nqp1comn.institution i on i.inst_Id = c.inst_id_recon_iss
where c.net_id_ems = 'MCI'
and case_no > '20180601000000'-- and '20180701000000'
and inst_id_recon_iss = '073910091'
and i.cust_id = 'BCFS'
and iss_ica = '5478'
order by iss_ica asc, name asc;

select * from nqp1comn.ems_unmatched_msg where tstamp_created like '20190704%' and acq_ref_no = '55429509160740224913875';
select * from nqp1bcfs.ems_case c inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
where case_no > '20191001000000' and iss_ica like '%20864%' order by case_no desc;

select * from nqp1bcfs.dx_data_control where dx_file_type = 'EMEMCI' ORDER BY DX_FILE_ID DESC;
select c.case_id,case_no,vrol_case_no from nqp1bcfs.ems_case c 
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp1bcfs.ems_phase_vnt v on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
where case_extension = 'VNT' and request_type like 'ADJ%'
order by c.case_no desc;

select * from nqp1comn.emsr_net_rule_use where network_rules = 'MC3';
select * from nqp1comn.emsr_rule_set where rule_set_id = 'MC3';--net_id_ems = 'VN2' and cust_id = 'CUSA';
select c.case_id,request_Type,status,net_rules,case_no from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
where m.iss_ica like '%20864%' and case_type_ind = 'X'
and net_id_acq = 'MCI' and net_rules = 'MC3' order by case_no asc; 
and request_type = 'UNW1' order by case_no desc;-- and request_type = 'UNW1' AND STATUS = 'PNDR';

select c.case_id,case_no,request_type,status,net_rules, claim_id
from nqp1bcfs.ems_case c 
inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id where c.case_id in (
select case_id from nqp1bcfs.api_queue_control q
inner join nqp1bcfs.api_queue_response r on q.queue_id = r.queue_id
where r.data_buffer like '%Search returned 0 records.%');

select * from nqp1bcfs.dx_data_control where dx_file_type = 'EMSACT' ORDER BY dx_file_id DESC;

select * from nqp1bcfs.message_log where (sender like 'DRC%' or receiver like 'DRC%') and tstamp_transmit > '20191021170000' and tstamp_transmit<'20191022050000' order by tstamp_transmit asc;
select * from nqp1bcfs.dx_data_control where dx_file_type = 'EMSACT' and dx_report_id = 12 order by dx_file_id desc;
select * from nqp1bcfs.dx_data_20191030 where data_buffer like '%55488729277207786209672%';
select * from nqp1bcfs.dx_data_control where dx_file_id = 4411573;
select c.case_id,claim_id,request_type,status from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_transition T on t.case_id = c.case_id
inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
where net_id_acq = 'MCI' AND NET_RULES = 'MC3' 
and t.request_type_prev = 'CHBQ' AND T.STATUS_PREV = 'SDRC'
AND T.REQUEST_TYPE_NEXT = 'DOC4' AND T.STATUS_NEXT = 'SDRC';
select * from nqp1bcfs.ems_comment order by case_id desc;

   SELECT C.CASE_ID,M.EMS_COMMENT
   FROM nqp1bcfs.EMS_CASE C                         
   INNER JOIN nqp1bcfs.EMS_COMMENT M                 
     ON M.CASE_ID = C.CASE_ID
WHERE C.CASE_Id IN (10127809,10127810)
and m.tstamp_created in (
select tstamp_created
group by c.case_id,m.ems_comment;

select c.request_type,status,amt_adjustment,claim_id,iss_ica, STATE_TSTAMP from nqp1bcfs.ems_case c 
inner join nqp1bcfs.ems_case_mci m on m.case_id =c.case_id
inner join nqp1bcfs.ems_phase p on p.case_id = c.case_id and p.request_type = c.request_type
where case_type_ind = 'X' and iss_ica like '%15220%' and status = 'SDRC'
order by state_tstamp desc;-- AND STATE_TSTAMP > '2019111600000000';

select distinct case_no,proc_id_iss_b from nqp1bcfs.ems_case c inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id
where net_id_ems = 'VNT' and t.user_id = 'P951DRCP';

select c.case_id,DOC_TYPE,EXPORT_IND from nqp1bcfs.ems_case c 
inner join nqp1bcfs.ems_phase p on p.case_id = c.case_id
inner join nqp1bcfs.ems_phase_mci m on m.case_id = p.case_id and m.tstamp_created = p.tstamp_created
inner join nqp1bcfs.ems_document d on d.case_id = c.case_id
where net_rules in ('MC2','PPM')
AND P.REQUEST_TYPE = 'CHB2'
AND M.DOC_IND = '0'
AND DOC_TYPE = 'REQ_DOC016' ORDER BY M.TSTAMP_CREATED DESC;

select * from nqp1COMN.emsr_transition where RULE_SET_ID = 'MC2-PPM' 
--AND PHASE_ID like 'CHB2' AND STATUS_ID = 'SDRC'
--AND NEXT_PHASE_ID = 'LTRS' 
AND NEXT_STATUS_ID = 'LTRS'
and role_ind = 'I';

select 
distinct pan,amt_adjustment,acq_ref_no,home_switch 
from nqp1comn.ems_unmatched_msg where tstamp_created like '20200113%' and net_id = 'MCI' AND PAN <> ' ' 
and msg_id not in ('RO09', ' ','RO22','RO01','RO24') 
--and home_switch = ' '
and pan_prefix in (
select pan_prefix from nqp1comn.x_net_inst_id where net_id = 'MCI' and CUST_ID = 'CAP1');

select * from nqp1comn.x_net_inst_id where net_inst_id_code like '%10116%';

select case_no,net_rules, acq_ref_no, t.tstamp_created,request_type from nqp1bcfs.ems_case c 
inner join nqp1bcfs.ems_national_net n on n.case_id = c.case_id
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id
where case_type_ind = 'X' and acq_ref_no in (
'55432869336200787459925',
'75418239243078792569522',
'55432869302200769466302',
'55541869304004027233942',
'55432869266200002555881',
'55432869295200945117091',
'55432869302200769493983',
'55429509303637461030975',
'15270219274000096733734',
'55432869328200789268787',
'55432869328200789268993',
'55432869327200622407882',
'55429509325852011817722')
and request_type_prev = 'CHB2' and status_prev = 'PNDR'
AND REQUEST_TYPE_NEXT = 'CHB2' AND STATUS_NEXT = 'SDRC';

select case_id from nqp1bcfs.ems_case where request_type = 'REP1' AND STATUS = 'SDRC' AND NET_RULES IN ('MC2','PPM')
ORDER BY CASE_ID DESC;

SELECT a.queue_id,api_state,a.case_id,request_type,status,api_result,tstamp_event,data_buffer
from nqp1bcfs.api_queue_control a
inner join nqp1bcfs.ems_case c on c.case_id = a.case_id 
inner join nqp1bcfs.api_queue_response r on r.queue_id = a.queue_id
where api_result like '%ME53: Do not recognize status%' 
and request_type = 'REP1' AND STATUS = 'GETD' ORDER BY CASE_ID ASC;
--and request_type not in ('CHB2','CH2Q','DOC4')
--and status not in ('CLOA','GETD') order by case_id asc; 

SELECT a.queue_id,api_state,a.case_id,request_type,status,api_result, data_buffer 
from nqp1bcfs.api_queue_control a
inner join nqp1bcfs.ems_case c on c.case_id = a.case_id 
inner join nqp1bcfs.api_queue_response r on r.queue_id = a.queue_id
where api_result like '%ME53: Do not recognize status%'
and data_buffer like '%documentIndicator>false%' order by case_id asc;


SELECT * FROM nqp1bcfs.API_QUEUE_CONTROL API_QUEUE_CONTROL 
WHERE API_QUEUE_CONTROL.TSTAMP_EVENT IN (SELECT MIN(API_QUEUE_CONTROL.TSTAMP_EVENT) TSTAMP_EVENT 
FROM nqp1bcfs.API_QUEUE_CONTROL API_QUEUE_CONTROL WHERE API_QUEUE_CONTROL.API_STATE IN ('AS','PE','SP') 
AND API_QUEUE_CONTROL.API_TYPE IN ('MCOM','MQUE') AND API_QUEUE_CONTROL.TSTAMP_EVENT <= '2020012910082102' AND API_QUEUE_CONTROL.RETRY_COUNT < 5) 
ORDER BY API_QUEUE_CONTROL.TSTAMP_EVENT ASC,API_QUEUE_CONTROL.QUEUE_ID ASC;

select tstamp_trans,uniqueness_key,inst_id_recon_acq,inst_id_recon_iss from nqp1bcfs.fin_l201911 where tstamp_trans in ('2019112913513776','2019112913513799')
and uniqueness_key in (28829,17799);
select * from nqp1comn.institution where inst_id in ('000013152','825150533','841097751','000013194');

select
'insert into nqp1cap1.api_queue_request(queue_id, seq_no,data_buffer) values (',
' ,0,''<chargebackList><claimId>',x.claim_id,'</claimId><chargebackId>',x.api_chargeback_id,'</chargebackId></chargebackList>'');'
--'insert into nqp1cap1.api_queue_control (queue_id,tstamp_event,api_state,api_type,case_id,req_type,retry_count,tstamp_created,',
--'api_result) values ( ,''2020032017150000'',''AW'',''MCOM'',',
--x.case_id,',''CBAckResponse'',-1,''2020032008150000'','' '');'
from
(select trim(trailing ' ' from claim_id)claim_id,trim(trailing ' ' from api_chargeback_id)api_chargeback_id
--(select c.case_id
from nqp1cap1.ems_case c
inner join nqp1cap1.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp1cap1.ems_phase_mci p on p.case_id = t.case_id and p.tstamp_created = t.phase_tstamp
inner join nqp1cap1.ems_case_mci m on c.case_id = m.case_id
where CASE_NO in (
'20200216000173',
'20200218005877',
'20200218005244',
'20200218005115',
'20200218005572',
'20200216000164',
'20200218005102',
'20200218005443',
'20200218004967',
'20200218004280',
'20200211003964',
'20200211003410'))x; 
and request_type = 'DOC4' AND STATUS = 'CLOA' order by claim_id asc) x;
group by request_type,status;
 
select * from nqp1bcfs.fin_record202002 where tstamp_trans = 
(select tstamp_trans from nqp1bcfs.fin_l202002 where pan_prefix = '511565' and pan_suffix = '5299' and sys_trace_audit_no = '258171') 
and uniqueness_key = 
(select uniqueness_key from nqp1bcfs.fin_l202002 where pan_prefix = '511565' and pan_suffix = '5299' and sys_trace_audit_no = '258171')
and amt_tran = 351;
select * from nqp1bcfs.fin_l202002 where pan_prefix = '511565' and pan_suffix = '5299' and tran_type_id like '______2___';
select * from nqp1bcfs.fin_l202002 l inner join nqp1bcfs.fin_record202002 r on r.tstamp_trans = l.tstamp_trans
and r.uniqueness_key = l.uniqueness_key
where pan_prefix = '511565' and pan_suffix = '5299' and amt_tran =351;

select l.tstamp_trans,l.uniqueness_key,pan_prefix,pan_suffix,sys_Trace_audit_no,retrieval_ref_no,amt_tran,cur_tran,tstamp_local
from nqp1bcfs.fin_l201902 l inner join nqp1bcfs.fin_l201902 r on r.tstamp_trans = l.tstamp_trans
and r.uniqueness_key = l.uniqueness_key
where l.tstamp_trans in (
'2019020320503992',
'2019020806564198',
'2019021221244376',
'2019022011213690',
'2019022512404064',
'2020030321550144',
'2020030321571791',
'2020030321574683',
'2020030321581912',
'2020030321581963',
'2020030322005874',
'2020030322013090',
'2020030322013141',
'2020030322020810',
'2020030322020887',
'2020030322022376',
'2020030322033588',
'2020030322035285',
'2020030322041180',
'2020030322042538',
'2020030322045772',
'2020030322091651',
'2020030322091703',
'2020030322112091',
'2020030322120536',
'2020030322120587',
'2020030322123291',
'2020030322125691',
'2020030322125741',
'2020030322130272',
'2020030322130526',
'2020030322133376',
'2020030322134034',
'2020030322230728',
'2020030322332340') and l.uniqueness_key in (
16527,
3274,
5387,
2902,
8397,
14957,
8765,
17382,
8969,
10039,
14157,
32173,
10838,
12614,
31966,
15311,
17623,
30119,
30433,
5491,
2681,
9803,
17911,
18330,
16241,
15686,
22169,
18717,
13724,
31467,
30817,
31086,
14313,
8906,
16377);

--select
--'update nqp1bcfs.api_queue_request set data_buffer = '''||x.data_buffer||''' where queue_id = ',
--x.queue_id,';'
--from
select c.case_id,r.queue_id,data_buffer from nqp1bcfs.api_queue_control c
inner join nqp1bcfs.api_queue_request r on r.queue_id = c.queue_id
where req_type = 'CBGetDocumentResponse' and case_id in (
10390594,
10488030,
10510082,
10510083,
10510084,
10531365,
10610409,
10668970,
10701504,
10720802,
10668970,
10610409) order by case_id asc;

select * from nqp1comn.institution where name like '%BMO%';
select * from nqp1comn.x_net_inst_id where net_id = 'MCI' and inst_id in (
'067014330',
'071025661',
'071905040',
'122105249',
'840109789',
'841097007',
'975000067',
'975000070');
select case_no, c.case_id,request_type,status
from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
inner join nqp1bcfs.ems_Transition t on t.case_id = c.case_id
where iss_ica like '%1965%' 
and tstamp_Created like '20200423%'
and request_type_next = 'REP1' AND STATUS_NEXT = 'GETD';

select c.case_id,r.queue_id,tstamp_event,data_buffer
from nqp1cap1.ems_case c
inner join nqp1cap1.api_queue_control a on a.case_id = c.case_id
inner join nqp1cap1.api_queue_response r on r.queue_id = a.queue_id
where net_id_ems = 'MCI' and request_type = 'CHBQ' and status = 'SDRC'
and req_type = 'CBStatusResponse' order by r.queue_id desc;

select a.queue_id,CASE_ID,DATA_BUFFER from nqp1bcfs.api_queue_control a
inner join nqp1bcfs.api_queue_request r on r.queue_id = a.queue_id
where api_state = 'PE' and case_id in (
11262709,
11262710	,
11262713	,
11262714	,
11262716	,
11262717	,
11262729	,
11262730	,
11262731	,
11262732	,
11262733	,
11262736	,
11262737	,
11262738	,
11262749	,
11262756	,
11262779	,
11262816	,
11262817	,
11262818	,
11262831	,
11262834	,
11262857	,
11262858	,
11262873	,
11262885	,
11262886	,
11262888	,
11262926	,
11262927	,
11262950	,
11262951	,
11262952	,
11262953	,
11262954	,
11262955	,
11262956	,
11262967	,
11262968	,
11262970	,
11262971	,
11263034	,
11263089	,
11263103	,
11263104	,
11263136	,
11263137	,
11263138	,
11263139	,
11263140	,
11263141	,
11263165	,
11263166	,
11263310	,
11263593	,
11263594	,
11264188	,
11264189	,
11264190	,
11264191	,
11264317	,
11264318	,
11264359	,
11264403	,
11264405	,
11264438	,
11264439	,
11264440	,
11264442	,
11264494	,
11264539	,
11264586	,
11264606	,
11264614	,
11264616	,
11264694	,
11264874	,
11264875	,
11264876	,
11264877	,
11264930	,
11264940	,
11266620	,
11266736	,
11267033	,
11267132	,
11270294	,
11270400	,
11272179	,
11272185	,
11274699	,
11274925	,
11274977	,
11274978	,
11279073	,
11279084	,
11279089	,
11279090	,
11279112	,
11279131	,
11279142	,
11279157	,
11279179	,
11279181	,
11279193	,
11279198	,
11279257	,
11279258	,
11279329	,
11279340	,
11279418	,
11279507	,
11279511	,
11279556	,
11279558	,
11279573	,
11279574	,
11279575	,
11279576	,
11279577	,
11279666	,
11279667	,
11279688	,
11279689	,
11279695	,
11279696	,
11279709	,
11279711	,
11279719	,
11279728	,
11279777	,
11279781	,
11279820	,
11279822	,
11279833	,
11279842	,
11279846	,
11279869	,
11279871	,
11279899	,
11279900	,
11279901	,
11279902	,
11279919	,
11279928	,
11279975	,
11279977	,
11279993	,
11279998	,
11280031	,
11280032	,
11280038	,
11280041	,
11280051	,
11280058	,
11280065	,
11280067	,
11280155	,
11280181	,
11280182	,
11280187	,
11280188	,
11280195	,
11280245	,
11280255	,
11280339	,
11280341	,
11280357	,
11280492	,
11280520	,
11280523	,
11280620	,
11280626	,
11280650	,
11280679	,
11280680	,
11280682	,
11280684	,
11280703	,
11280713	,
11280715	,
11280752	,
11280759	,
11280794	,
11280800	,
11280801	,
11280802	,
11280804	,
11280818	,
11280859	,
11280868	,
11280926	,
11280950	,
11281083	,
11281116	,
11281263	,
11281789	,
11281792	,
11281893	,
11282017	,
11282063	,
11282073	,
11282112	,
11282700	,
11282701	,
11282702	,
11282704	,
11282706	,
11282711	,
11282745	,
11282747	,
11282757	,
11282785	,
11282786	,
11282790	,
11284322	,
11284360	,
11284396	,
11284415	,
11284440	,
11284527	,
11284549	,
11284602	,
11284627	,
11284628	,
11284797	,
11284856	,
11284857	,
11287262	,
11287264	,
11287265	,
11287268	,
11287270	,
11287271	,
11287273	,
11287276	,
11287283	,
11287284	,
11287285	,
11287439	,
11287469	,
11287472	,
11287499	,
11287538	,
11287539	,
11287590	,
11287604	,
11287632	,
11287633	,
11287643	,
11287644	,
11287645	,
11287664	,
11287693	,
11287703	,
11287708	,
11287711	,
11287720	,
11287744	,
11287745	,
11287748	,
11287749	,
11287751	,
11287752	,
11287758	,
11287769	,
11287771	,
11287823	,
11287853	,
11287857	,
11287866	,
11287867	,
11287868	,
11287870	,
11287874	,
11287875	,
11287894	,
11287895	,
11287896	,
11287897	,
11287899	,
11287901	,
11287902	,
11287904	,
11287905	,
11287909	,
11287911	,
11287923	,
11287930	,
11287931	,
11287932	,
11287935	,
11287940	,
11287967	,
11287973	,
11287974	,
11287975	,
11287976	,
11287977	,
11287978	,
11287980	,
11287981	,
11287982	,
11287983	,
11287984	,
11287985	,
11287986	,
11287987	,
11287990	,
11288000	,
11288015	,
11288019	,
11288020	,
11288021	,
11288032	,
11288034	,
11288040	,
11288041	,
11288044	,
11288045	,
11288046	,
11288048	,
11288050	,
11288051	,
11288053	,
11288054	,
11288055	,
11288056	,
11288057	,
11288058	,
11288060	,
11288061	,
11288069	,
11288072	,
11288078	,
11288082	,
11288085	,
11288095	,
11288099	,
11288100	,
11288111	,
11288114	,
11288115	,
11288133	,
11288135	,
11288145	,
11288147	,
11288217	,
11288239	,
11288240	,
11288242	,
11288247	,
11288248	,
11288253	,
11288261	,
11288262	,
11288268	,
11288270	,
11288283	,
11288285	,
11288298	,
11288329	,
11288357	,
11288417	,
11288427	,
11288498	,
11288518	,
11288521	,
11288557	,
11288558	,
11288584	,
11288673	,
11288794	,
11288795	,
11288796	,
11288799	,
11288800	,
11288801	,
11288802	,
11288807	,
11288808	,
11288809	,
11288810	,
11288813	,
11289073	,
11289132	,
11289350	,
11289371	,
11289612	,
11289711	,
11289754	,
11289830	,
11289865	,
11289872	,
11289880	,
11289909	,
11289959	,
11290000	,
11290004	,
11290011	,
11290013	,
11290101	,
11290184	,
11290188	,
11290194	,
11290225	,
11290226	,
11290227	,
11290249	,
11290336	,
11290338	,
11290369	,
11290377	,
11290403	,
11290493	,
11290512	,
11290586	,
11290712	,
11290817	,
11290883	,
11290922	,
11291050	,
11291085	,
11291171	,
11294904	,
11294908	,
11294913	,
11294916	,
11264240)
order by case_id asc;

