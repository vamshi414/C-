select * from nqp7ifsa.ems_case where case_no = '20200306000061';
select * from nqp7ifsa.ems_transition where case_id = 1213712 order by tstamp_created asc;
SELECT * from nqp7COMN.processor where CUST_ID = 'CUSA' AND PROC_NAME = 'IFSA THIRD PARTY LINK #2';--proc_id = 'PRKS10';

select count(*) from nqp7ifsa.ems_case
WHERE case_no between '20191107000000' and '20191108000000' 
and net_id_ems = 'PLS'
and request_type = 'ADJC' and institution_name = ' ';

select case_id,tstamp_created,ti_event_id from nqp7ifsa.ems_phase_vnt where case_id in (
1008771,929394,973306,915759,985312,986040,986292,986286,986424,986414,
986408,986404,986398,986428,988443,987864,986992,986978,986130,986129,
986048,986015,985703,984734,984730,985156,995444)
and ti_event_id <> ' ';

select * from nqp7ifsa.fin_l201908 where pan = 'lcYSuiXLxbQjccWX' and retrieval_ref_no = '000000000954';--pan_prefix = '415222' and pan_suffix = '4549';
select * from nqp7ifsa.ems_case where pan_prefix = '430586' and pan_suffix = '1684';
select * from nqp7ifsa.fin_record201908 where tstamp_trans = '2019081614040822' and uniqueness_key =20941;
select * from nqp7ifsa.ems_case where tstamp_trans = '2018031501492347';
select * from nqp7ifsa.ems_case where case_id = 1197472;
select * from nqp7ifsa.ems_phase where case_id = 1187030;
select * from nqp7ifsa.ems_case_vnt where case_id = 1188072;
select * from nqp7ifsa.ems_phase_vnt where 
--vrol_case_no = '1630963354'; 
case_id = 1205798 order by tstamp_created asc;
select * from nqp7ifsa.ems_fraud_vnt where case_id = 1021051;
select * from nqp7ifsa.ems_document where case_id = 913643;
select * from nqp7ifsa.ems_phase_vnt_vrol where case_id = 909199;

select * from nqp7ifsa.ems_case c
inner join nqp7ifsa.ems_phase p on p.case_id = c.case_id
where c.request_type like 'ADJ%' and status = 'REJR' and net_rules = 'VN3'
and p.user_role = 'A';

select * from nqp7ifsa.ems_data_chg where case_id = 1197472 order by tstamp_created asc;

select * from nqp7ifsa.assoc_tran where case_id = 910667;

select * from nqp7ifsa.api_queue_control where case_id = 1205798 order by queue_id asc;
select * from nqp7ifsa.api_queue_control where queue_id = 514164;
select * from nqp7ifsa.api_queue_control where api_state = 'AF' and retry_count = 3 order by queue_id asc;
select * from nqp7ifsa.api_queue_control where api_result like 'Error: No event avail%' order by queue_id desc; --queue_id = 49315;

select * from nqp7ifsa.api_queue_request where data_buffer like '%1647548347%'; 
select * from nqp7ifsa.api_queue_response  where data_buffer like '%faultstring%'; 
select * from nqp7ifsa.api_queue_request where queue_id in
(select queue_id from nqp7ifsa.api_queue_control where case_id = 1021051) order by queue_id asc;
select * from nqp7ifsa.api_queue_response where queue_id in
(select queue_id from nqp7ifsa.api_queue_control where case_id = 998146) order by queue_id asc;

select * from nqp7ifsa.api_qevent_log where queue_id = 167558 order by tstamp_created asc;

select c.case_no, vrol_case_no from nqp7ifsa.ems_case c
inner join nqp7ifsa.ems_transition t on c.case_id = t.case_id
inner join nqp7ifsa.ems_phase_vnt p on p.case_id = t.case_id and p.tstamp_created = t.phase_tstamp
where request_Type_prev = 'CHBQ' AND STATUS_PREV = 'DOCF'
AND REQUEST_TYPE_NEXT = 'CHBQ' AND STATUS_NEXT = 'DOCS'
AND T.TSTAMP_CREATED LIKE '2018052909%';

select case_id, case_no from nqp7ifsa.ems_case
where tstamp_trans in (
select tstamp_trans from nqp7ifsa.ems_case 
where case_type_ind = 'D' and status in ('SDRC','REJ2'))
and requesT_Type = 'CHB1' AND STATUS = 'FWRD'
and net_rules = 'VN3';

select a.queue_id, case_no
from nqp7ifsa.ems_case c
inner join nqp7ifsa.api_queue_control a on a.case_id = c.case_id
inner join nqp7ifsa.api_queue_response r on r.queue_id = a.queue_id
where request_type = 'CHBQ' AND STATUS = 'DOCF'
--and data_buffer like '%Successfully%'
AND a.req_type = 'DOC';

--Select c.case_id,case_no,status,rol_tran_id from nqp7ifsa.ems_case c
--inner join nqp7ifsa.ems_case_vnt v on v.case_id = c.case_id
--where case_type_ind = 'D' and tstamp_trans in (
--select tstamp_trans
--select c.CASE_id, case_no, pan_prefix,vrol_case_no,c.request_type, status, v.support_info
--select c.case_id, case_no, pan_prefix, pan_suffix, retrieval_ref_no,iss_bin,acq_bin, net_id_ems,tstamp_local,c.amt_recon_net/100,
t--ran_identifier,h.reason_code,h.amt_adjustment/100,c.request_type,status,merchant_cat_code, state_tstamp,v.vrol_case_no,v.support_info
--select c.case_id, pan_prefix, net_id_acq,case_no, tstamp_trans,state_tstamp,c.request_type, status,merchant_cat_code, v.support_info
--select c.case_id,case_no,vrol_case_no,tran_identifier, tstamp_local,amt_adjustment, dispute_condition, acq_ref_no
--select c.case_id,case_no,pan_prefix,net_id_acq,tstamp_trans,state_tstamp, ROL_TRAN_ID,ti_event_id,c.request_type, status,v.support_info
--r.DATA_BUFFER
select count(*)
from nqp7fisb.ems_case c
--inner join nqp7ifsa.ems_case_vnt u on u.case_id = c.case_id
--inner join nqp7ifsa.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
--inner join nqp7ifsa.ems_phase_vnt v on v.case_id = c.case_id and v.tstamp_created = t.phase_tstamp
--inner join nqp7ifsa.ems_national_net n on n.case_id = c.case_id
--inner join nqp7ifsa.ems_phase h on h.case_id = t.case_id and h.tstamp_created = t.phase_tstamp
--inner join nqp7ifsa.api_queue_control q on q.case_id = c.case_id
--inner join nqp7ifsa.api_queue_request r on r.queue_id = q.queue_id
where net_rules = 'MC3'
and case_no like '20200311%';
--WHERE CASE_EXTENSION = 'VNT'
--AND TSTAMP_TRANS = ' '
--and t.request_type_prev = 'INIT' AND T.STATUS_PREV = 'TEMP' AND T.REQUEST_TYPE_NEXT = 'CHB1' AND T.STATUS_next = 'SDRC'
--AND CUR_TRAN <> '840'-- AND CUR_RECON_NET = '840';
--and c.request_type = 'CHBQ' 
--AND STATUS = 'REJR'
--AND ERR_VROL_MSG1 = 'E-900000083'
--AND STATE_TSTAMP > '2018041300000000'
--and c.request_type NOT IN ('CHB1','CHBQ')
--and status NOT IN ('SDRC','REJ2','CLOA','CLOJ','CLOC','RECD')
--and api_state = 'PE' and tstamp_event > '2018110715000000'
--and api_result = 'VE23:Transition failed to PNDR.'
--and acq_bin in
--('272685','272906','277540','279058','292740','293593','298521','299074','299284','299991')
--and pan_prefix in ('442859','448224','449224','449351','468910','475471','489272')
--AND V.SUPPORT_INFO LIKE '%access%'
order by support_info asc,state_tstamp asc;
--and u.acq_bin = '279058'; --not in ('279058','293593')
--and c.inst_id_recon_acq = '001700338';
--and r.data_buffer not like '%<ARN>%'
--and date_recon_net <> ' '
--AND V.SUPPORT_INFO LIKE '%expired%'
--and r.data_buffer like '%DuplicateTranId%';
--AND h.user_role = 'I'
--AND ERR_VROL_MSG1 = 'E-900000081';
order by case_no desc;
--AND ERR_VROL_MSG1 = 'W80';
--order by acq_bin asc;

select C.case_id, case_type_ind, status
from nqp7ifsa.ems_case c             
where case_type_ind = 'D'            
and tstamp_trans in (
select c.tstamp_trans from NQP7IFSA.ems_case c                                          
where case_id in (
898894,898896,898898,898900,898906,898910,898912,898914,898916,898918,898920,898922,898924,898926,
898930,898932,898935,898937,898939,898941,898943,898947,898949,898951,898953,898957,898959,898979)
);

select c.case_id, case_no,c.request_type,c.status, vrol_case_no from nqp7ifsa.ems_case c
inner join nqp7ifsa.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7ifsa.ems_phase_vnt v on v.case_id = c.case_id and v.tstamp_created = t.phase_tstamp
where c.case_id in (
898945,
906331,
912801,
913932,
913970,
914892,
915074,
916077,
917137,
917290,
917292,
917294,
917296,
918104,
918108,
918138,
919055,
919071,
919073,
920409,
920413,
920576,
920580,
920588,
920600,
920650,
920954,
920961,
921178,
921973,
922072,
922123,
922125,
922133,
922195,
922615,
922632,
922634,
922771,
922781,
923706,
924810,
924978,
924995,
924999,
926044,
926565,
926716,
927672,
927968,
929267,
930604,
930743,
933330,
933331,
933332,
933333,
933334,
933335,
933336,
933337,
933338,
933339,
933340,
933341,
933342,
933414,
933428,
933429,
933430,
933431,
933432,
933433,
933434,
933435,
933436,
933437,
933438,
933439,
933440,
933441,
933442,
933443,
933444,
933445)
and status NOT IN ('CLOA','CLTA','CLOC')
order by case_id asc;

select * from nqp7comn.x_generic where x_type = 'ADMIN_ISO_NETID';
select distinct PAN_PREFIX, cust_id from nqp7comn.x_net_inst_id where pan_prefix  = '478950';

SELECT COUNT(*) ROW_COUNT,C.CASE_ID,C.CASE_NO,C.INST_ID_RECON_ISS,C.NET_ID_EMS,C.PROC_ID_ISS,C.STATUS,P.REQUEST_TYPE,V.VCR_IND 
FROM NQP7IFSA.EMS_CASE C INNER JOIN NQP7IFSA.EMS_PHASE P ON C.CASE_ID = P.CASE_ID 
INNER JOIN (SELECT EMS_PHASE.CASE_ID,MIN(EMS_PHASE.TSTAMP_CREATED) TSTAMP_CREATED 
FROM NQP7IFSA.EMS_PHASE EMS_PHASE GROUP BY EMS_PHASE.CASE_ID) TISS 
ON C.CASE_ID = TISS.CASE_ID AND P.TSTAMP_CREATED = TISS.TSTAMP_CREATED 
LEFT OUTER JOIN NQP7IFSA.EMS_CASE_VNT EMS_CASE_VNT ON P.CASE_ID = EMS_CASE_VNT.CASE_ID,NQP7IFSA.EMS_CASE_VNT V 
WHERE P.TSTAMP_CREATED BETWEEN '2018070000000000' AND '2018079999999999' AND P.USER_ROLE = 'I' 
AND C.NET_ID_EMS NOT IN ('MCI','VNT') 
GROUP BY C.PROC_ID_ISS,C.INST_ID_RECON_ISS,P.REQUEST_TYPE,C.STATUS,C.NET_ID_EMS,C.CASE_NO,C.CASE_ID,V.VCR_IND 
UNION ALL SELECT COUNT(*) ROW_COUNT,C.CASE_ID,C.CASE_NO,C.INST_ID_RECON_ACQ,C.NET_ID_EMS,C.PROC_ID_ACQ,C.STATUS,P.REQUEST_TYPE,V.VCR_IND 
FROM NQP7IFSA.EMS_CASE C INNER JOIN NQP7IFSA.EMS_PHASE P ON C.CASE_ID = P.CASE_ID 
INNER JOIN (SELECT EMS_PHASE.CASE_ID,MIN(EMS_PHASE.TSTAMP_CREATED) TSTAMP_CREATED 
FROM NQP7IFSA.EMS_PHASE EMS_PHASE GROUP BY EMS_PHASE.CASE_ID) TISS 
ON C.CASE_ID = TISS.CASE_ID AND P.TSTAMP_CREATED = TISS.TSTAMP_CREATED 
LEFT OUTER JOIN NQP7IFSA.EMS_CASE_VNT EMS_CASE_VNT ON P.CASE_ID = EMS_CASE_VNT.CASE_ID,NQP7IFSA.EMS_CASE_VNT V 
WHERE P.TSTAMP_CREATED BETWEEN '2018070000000000' AND '2018079999999999' AND P.USER_ROLE = 'A' 
AND C.NET_ID_EMS NOT IN ('MCI','VNT') 
GROUP BY C.PROC_ID_ACQ,C.INST_ID_RECON_ACQ,P.REQUEST_TYPE,C.STATUS,C.NET_ID_EMS,C.CASE_NO,C.CASE_ID,V.VCR_IND 
ORDER BY 6, 4, 7, 5;

select c.case_id,request_type,status from nqp7ifsa.ems_case c
inner join nqp7ifsa.ems_case_vnt v on v.case_id = c.case_id
where net_rules = 'VN3' and v.iss_bin = '473490';

select case_id, tstamp_created,support_info from nqp7ifsa.ems_phase_vnt where case_id in
(899346,900981,900983,900984,900988,900989,
900990,900994,900996,901260,901264,902977,902986,902991,905941,915759,953095,969379,969413,
969471,969473,969477,969481,969491,970992,970997,971006,971016,973000,973306)
order by case_id asc, tstamp_created asc;

select * from nqp7comn.as_user_logon where user_name like '%Amber%';

select * from nqp7ifsa.ems_case_context where case_id = 1184487;--context_type = 'SETTLE' and processed_flg = 'Y' order by tstamp_created desc;

select * from nqp7comn.cqc_constraint where description like '%PULSE%';
select * from nqp7comn.cqc_column_qual where constraint_id = 1618;
select * from nqp7comn.as_user_logon where user_id in (
select user_id from nqp7comn.cqc_user where constraint_id = 1618);