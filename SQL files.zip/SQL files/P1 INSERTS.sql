select
'INSERT INTO NQP1CAP1.EMS_TRANSITION (CASE_ID,PHASE_TSTAMP,TSTAMP_CREATED,SEQ_NO,USER_ID,REQUEST_TYPE_PREV,STATUS_PREV,REQUEST_TYPE_NEXT,STATUS_NEXT,MANUAL_OVERRIDE,ACTION,ACTION_TO_CARDHLDR,REASON_CODE,AMT_ADJUSTMENT) VALUES (',
x.case_id,',''2020071607450000'',''2020071607450000'',''1'',''SQL'','''||x.request_type_next||''','''||x.status_next||''',''REP1'',''GETD'',''N'','' '',',
--x.case_id,','''||X.PHASE_TSTAMP||''',''2020041609450000'',''1'',''SQL'','''||x.request_type_next||''','''||x.status_next||''','''||x.request_type_next||''',''SDRC'',''N'','' '',',
''''||x.action_to_cardhldr||''','''||X.reason_code||''',',
x.amt_adjustment,');'
from
(SELECT t.case_id, t.phase_tstamp,t.action_to_cardhldr,amt_adjustment,request_type_next,status_next,reason_code
from NQP1CAP1.ems_case c
inner join NQP1CAP1.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join NQP1CAP1.ems_case_mci m on m.case_id = c.case_id
inner join NQP1CAP1.ems_national_net n on n.case_id = c.case_id
where c.case_ID IN (
SELECT CASE_ID FROM NQP1CAP1.EMS_NATIONAL_NET WHERE ACQ_REF_NO IN (
SELECT N.ACQ_REF_NO FROM NQP1BCFS.EMS_CASE C INNER JOIN NQP1BCFS.EMS_NATIONAL_NET N ON N.CASE_ID = C.CASE_ID
WHERE C.REQUEST_TYPE = 'REP1' AND C.STATUS = 'CLUN' and net_id_ems = 'MCI') and net_id_ems = 'MCI' 
and REQUEST_TYPE = 'CHB1' AND STATUS = 'CLTA')
ORDER by acq_ref_no asc)x;
AND REQUEST_TYPE in ('CHBQ','CH2Q') AND STATUS = 'PNDR') x;

select
'UPDATE NQP1CAP1.EMS_CASE SET TSTAMP_UPDATED = ''2020071507450000'',STATE_TSTAMP = ''2020071507450000'',',
'REQUEST_TYPE = ''REP1'', STATUS = ''GETD'' WHERE CASE_ID = ',
--'STATUS = ''SDRC'' WHERE CASE_ID = ',
x.case_id,';'
from
(select c.case_id from NQP1CAP1.ems_case c
inner join NQP1CAP1.ems_national_net N on n.case_id = c.case_id
where c.case_ID in(
SELECT CASE_ID FROM NQP1CAP1.EMS_NATIONAL_NET WHERE ACQ_REF_NO IN (
SELECT N.ACQ_REF_NO FROM NQP1BCFS.EMS_CASE C INNER JOIN NQP1BCFS.EMS_NATIONAL_NET N ON N.CASE_ID = C.CASE_ID
WHERE C.REQUEST_TYPE = 'REP1' AND C.STATUS = 'CLUN' and net_id_ems = 'MCI') and net_id_ems = 'MCI' 
and REQUEST_TYPE = 'CHB1' AND STATUS = 'CLTA')
order by acq_ref_no asc)x;
AND REQUEST_TYPE = 'REP1' AND STATUS = 'GETS') x;

--SELECT                                                 
--'INSERT INTO NQP1CAP1.EMS_TRANSITION (CASE_ID,PHASE_TSTAMP,TSTAMP_CREATED,SEQ_NO,USER_ID,REQUEST_TYPE_PREV,STATUS_PREV,REQUEST_TYPE_NEXT,STATUS_NEXT,MANUAL_OVERRIDE,ACTION,ACTION_TO_CARDHLDR,REASON_CODE,AMT_ADJUSTMENT) VALUES (',               
--X.CASE_ID,','''||X.PHASE_TSTAMP||''',''2018092415300000'',',                
-- '''1'',''SQL'','''||X.REQUEST_TYPE||''',',            
-- ''''||X.STATUS||''',''FDRA'',',       
--- ''''||X.STATUS||''','''||X.REQUEST_TYPE||''',',       
--'''SDRC'',''N'','' '','''||X.ACTION_TO_CARDHLDR||''',',
--''''||X.REASON_CODE||''',',X.AMT_ADJUSTMENT,');'       
--SELECT
--'UPDATE NQP1CAP1.EMS_CASE SET STATE_TSTAMP = ''2018092415300000'',STATUS = ''SDRC'' WHERE CASE_ID = ',
--X.CASE_ID,
--';'
-- FROM                                                  
--   (                                                   
select c.case_id,case_no,request_type,status, state_tstamp,t.phase_tstamp,t.reason_code,t.action_to_cardhldr,t.amt_adjustment,v.support_info
from NQP1CAP1.ems_case c
inner join NQP1CAP1.ems_transition t
on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join NQP1CAP1.ems_phase_vnt v
on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
--where c.case_id = 7578157) x;
--where support_info like '%Internal Error%';
WHERE request_type = 'FDRA'
AND status = 'REJ2' 
--and inst_id_Recon_iss = '031176110') x;
AND (ERR_VROL_MSG1 = 'R97' OR ERR_VROL_MSG1 = 'W80')
order by state_tstamp desc;
--AND ERR_VROL_MSG1 = 'E-121004004') X;


select
'INSERT INTO NQP1cap1.EMS_PHASE (CASE_ID,TSTAMP_CREATED,REQUEST_TYPE,REASON_CODE,AMT_ADJUSTMENT,CUR_ADJUSTMENT,ACTION_TO_CARDHLDR,ACCOUNT_TYPE,USER_ROLE,CONTROL_NO,REC_CONTACT_NAME,REC_CONTACT_PHONE,REC_CONTACT_FAX, REQ_CONTACT_NAME,REQ_CONTACT_PHONE,REQ_CONTACT_FAX,COMPLETED_LATE, FRAUD_REASON,AMT_ADJ_TRAN,CUR_ADJ_TRAN,AMT_ADJ_CARD_BILL,CUR_CARDH_BILL,DATE_CONV,DATE_EXPIRATION,AMT_SURCHARGE,DATE_RECONYYYYMMDD,SURCHARGE_IND,FORCED_RESN_CD_FLG,FEE_REL_CASE_NO,FEE_REL_TSTAMP,DATE_RECON) VALUES (',
X.CASE_ID,',''2020071507450000'',''REP1'','''||X.REASON_CODE||''',',
X.AMT_ADJUSTMENT,','''||X.CUR_ADJUSTMENT||''','''||X.ACTION_TO_CARDHLDR||''','''||X.ACCOUNT_TYPE||''',',
''''||X.USER_ROLE||''','' '','' '','' '','' '', '''||X.REQ_CONTACT_NAME||''','''||X.REQ_CONTACT_PHONE||''','''||X.REQ_CONTACT_FAX||''',',
''' '','' '',',
X.AMT_ADJ_TRAN,','''||X.CUR_ADJ_TRAN||''',0,''840'','' '','' '',',
X.AMT_SURCHARGE,','''||X.DATE_RECONYYYYMMDD||''','' '','' '','''||X.FEE_REL_CASE_NO||''','''||X.FEE_REL_TSTAMP||''','''||X.DATE_RECON||''');'
FROM
(select p.case_id,p.amt_adjustment,p.cur_adjustment,p.action_to_cardhldr,p.account_type,p.user_role,p.req_contact_name,
p.req_contact_phone,p.req_contact_fax,p.amt_adj_tran,p.cur_adj_tran,p.amt_surcharge,p.date_reconyyyymmdd,p.fee_rel_case_no,
p.fee_rel_tstamp,p.date_recon,p.reason_code
from NQP1cap1.ems_case c
inner join NQP1cap1.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join NQP1cap1.ems_phase p  on p.case_id = t.case_id and p.tstamp_created = t.phase_tstamp
where c.case_id in (
SELECT CASE_ID FROM NQP1CAP1.EMS_NATIONAL_NET WHERE ACQ_REF_NO IN (
SELECT N.ACQ_REF_NO FROM NQP1BCFS.EMS_CASE C INNER JOIN NQP1BCFS.EMS_NATIONAL_NET N ON N.CASE_ID = C.CASE_ID
WHERE C.REQUEST_TYPE = 'REP1' AND C.STATUS = 'CLUN' and net_id_ems = 'MCI') and net_id_ems = 'MCI' 
and c.REQUEST_TYPE = 'CHB1' AND STATUS = 'CLTA')) x;


/*select
'INSERT INTO EMS_PHASE_VNT (CASE_ID,TSTAMP_CREATED,EXCLD_TRAN_ID,PROCESS_CODE,TRANSMIT_DATE_TIME,POS_COND_CODE,RESP_CODE,DOC_IND,NETW_MGMT_CODE,MMT_KEY, MMT_MOD_FLG,FIELD_ID,USAGE_CODE,CHB_REF_NO,ISSUER_CNTL_NO,RETURN_REASON_1,RETURN_REASON_2,RETURN_REASON_3,RETURN_REASON_4, RETURN_REASON_5,RETURN_REASON_6,RETURN_REASON_7,RETURN_REASON_8,RETURN_REASON_9,RETURN_REASON_10,ADDL_TRACE_DATA, STIP_SW_RESN_CODE,ORIG_RESP_CODE,ERR_RETURN_FLG,PURCHASE_DATE,REASON_CODE,ISS_REQ_FUL_METH,ACQ_ESTB_FUL_METH,DISPU_RESN_CD, DISPU_RTN_RESN_CD,DISPU_RULE_RESN_CD,DISPU_REQ_DATE,VCRFS_ACCT_NO_FLG,VCRFS_PUR_DATE_FLG,VCRFS_TRAN_AMT_FLG,VCRFS_EXP_DATE_FLG, VCRFS_MERCH_FLG,DISPUTE_CONDITION,FINANCIAL_SENT_IND,REJECT_CODE,B2_CPD_VISA_FMT,B2_CPD_DN_FMT,B2_SEC_ADV_TYPE,VROL_CASE_NO, FEE_CHARGE_FLG,ERR_VROL_MSG1,ERR_VROL_MSG2,ERR_VROL_MSG3,ERR_VROL_MSG4,ERR_VROL_MSG5,SUPPORT_INFO,VISA_MMT,TI_EVENT_ID,DISPUTE_ID,NOT_ASSOC_REASON) VALUES (',
x.case_id,',''2018061809150000'','' '','''||x.process_code||''','''||x.transmit_date_time||''','' '','''||x.resp_code||''',',
''' '','' '','' '','' '','' '','' '','' '','''||x.issuer_cntl_no||''','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '',',
''' '','''||x.stip_sw_resn_code||''','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '',',
''''||x.dispute_condition||''','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '');'
from*/

SELECT
'INSERT INTO NQP1CAP1.EMS_PHASE_MCI (CASE_ID,TSTAMP_CREATED,SETL_IND,DOC_IND,CARD_ISS_REF_DATA,MC_MMT,MMT_KEY,MMT_MOD_FLG,DOC_CODE_IND,INTRCHG_LIFE_CYCLE,',
'ERR_DE_1,ERR_SEV_CODE_1,ERR_MSG_1,ERR_SUBFIELD_ID_1,ERR_DE_2,ERR_SEV_CODE_2,ERR_MSG_2,ERR_SUBFIELD_ID_2,',
'ERR_DE_3,ERR_SEV_CODE_3,ERR_MSG_3,ERR_SUBFIELD_ID_3,ERR_DE_4,ERR_SEV_CODE_4,ERR_MSG_4,ERR_SUBFIELD_ID_4,',
'ERR_DE_5,ERR_SEV_CODE_5,ERR_MSG_5,ERR_SUBFIELD_ID_5,ERR_DE_6,ERR_SEV_CODE_6,ERR_MSG_6,ERR_SUBFIELD_ID_6,',
'ERR_DE_7,ERR_SEV_CODE_7,ERR_MSG_7,ERR_SUBFIELD_ID_7,ERR_DE_8,ERR_SEV_CODE_8,ERR_MSG_8,ERR_SUBFIELD_ID_8,',
'ERR_DE_9,ERR_SEV_CODE_9,ERR_MSG_9,ERR_SUBFIELD_ID_9,ERR_DE_10,ERR_SEV_CODE_10,ERR_MSG_10,ERR_SUBFIELD_ID_10,',
'MCOM_ACQ_RR_RESP,MCOM_ISS_REJ_RESN,MCOM_ISS_RESP_CD,MCOM_RECORD_ID,MCOM_REJ_MEMO,REJECT_INFO,API_CHARGEBACK_ID,REQUEST_ID) VALUES (',
--x.case_id,','''||x.phase_tstamp||''',''M'','' '','' '','' '',',
x.case_id,',''2020071507450000'','''||x.setl_ind||''','' '','''||x.CARD_ISS_REF_DATA||''','''||x.mc_mmt||''',',
--''' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '',',
''''||x.mmt_key||''','''||x.mmt_mod_flg||''',''1'','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '',',
''' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '',',
--''' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '');'
''' '','' '','' '','' '','''||x.mcom_acq_rr_resp||''','' '','' '','''||x.mcom_record_id||''','' '','' '','''||x.api_chargeback_id||''','' '');'
from
(select v.case_id,v.setl_ind,v.doc_ind,v.card_iss_Ref_data,v.mc_mmt,v.mmt_key,v.mmt_mod_flg,v.mcom_acq_rr_resp,v.mcom_record_id,
api_chargeback_id
--(select t.phase_tstamp,c.case_id
from NQP1CAP1.ems_case c
inner join NQP1CAP1.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join NQP1CAP1.ems_phase_mci v  on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
inner join NQP1CAP1.ems_national_net N on n.case_id = c.case_id
where c.case_id in (
SELECT CASE_ID FROM NQP1CAP1.EMS_NATIONAL_NET WHERE ACQ_REF_NO IN (
SELECT N.ACQ_REF_NO FROM NQP1BCFS.EMS_CASE C INNER JOIN NQP1BCFS.EMS_NATIONAL_NET N ON N.CASE_ID = C.CASE_ID
WHERE C.REQUEST_TYPE = 'REP1' AND C.STATUS = 'CLUN' and net_id_ems = 'MCI') and net_id_ems = 'MCI' 
and c.REQUEST_TYPE = 'CHB1' AND STATUS = 'CLTA')order by acq_ref_no asc) x;

SELECT
'INSERT INTO nqp1bcfs.EMS_CASE_MCI (CASE_ID,ISS_ICA,ACQ_ICA,CARD_INP_CAP_IND,CARDH_AUTH_CAP_IND,CARD_CAPT_CAP_IND,TERM_OPER_ENVI_IND,CARDH_PRESENT_IND,CARD_PRESENT_IND,CARD_INP_MODE_IND,CARDH_AUTHMOD_IND,CARDH_AUTHENT_IND,CARD_OUT_CAP_IND,TERM_OUT_CAP_IND,PIN_CAPT_CAP_IND,TERMINAL_TYPE,MC_RTR_CTRL_NO,MC_CHB_CTRL_NO,ACPT_BRAND_CODE,BUS_SERV_LVL_IND,BUS_SERV_CODE,INTRCHG_RATE_DSG,BUS_DATE,BUS_CYCLE,CUST_SERV_PHONE,MERCH_PHONE,ADDL_CONTACT_INFO,MC_DATE,MC_TIME,LIFECYCLE_SUP_IND,LIFECYCLE_TRACE_ID,PROCESS_CODE,FEE_CNTL_NO,ORIG_RTR_RESN,MCI_ECS_LVL_IND,MAC_VALUE,MCI_AAV_RESULT_COD,DATE_ACTION,ICCR_EFFECT_DATE,CARD_ACPT_URL,PRES_BUS_DATE,PGM_REG_ID,MASTERCOM_CTRL_NO,MCI_ASSIGNED_ID,AMT_POI,CUR_POI,PYMT_TRAN_INIT,QPS_ELIGIBLE_IND,CVC2_PGM_IND,TRANSIT_TRAN_IND,TRANSPORT_MODE_IND,FRD_NOTIFY_DATE,REMOTE_PGM_IND,FRD_NOTIFY_SVC_COUNTER,PPOL_PGM_DATA,PAYMENT_FID,SALES_ORG_ID,MERCHANT_ID,AUTH_CLEARING_ID,AUTH_TRAN_ID,CLAIM_ID) VALUES(',
X.CASE_ID,','''||X.net_inst_id_code||''','''||x.acq_id||''','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '',',
''' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','''||x.process_code||''','' '','' '','' '','' '',',
''' '','' '','' '','' '','' '','' '','' '','' '','' '',0,'' '','' '','' '','' '','' '','' '','' '','' '','' '',',
''' '','' '','' '','' '','' '','' '','' '');'
from
(select c.case_id,net_inst_id_code,substr(adl_data_priv_acq,6,6)process_code,substr(inst_id_acq,2)acq_id
from nqp1bcfs.ems_case c 
inner join nqp1bcfs.fin_record202007 r on r.tstamp_trans = c.tstamp_trans and r.uniqueness_key = c.uniqueness_key
left outer join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id and T.tstamp_created = C.state_tstamp
inner join nqp1comn.x_net_inst_id i on i.pan_prefix = c.pan_prefix
where net_id_ems = 'MCI'
and case_no > '20200621000000'
and request_type = 'UNW1'
and status = 'CLOC'
and user_id = 'P951DRCP'
and c.case_id not in (
select c.case_id
from nqp1bcfs.ems_case c
left outer join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id and T.tstamp_created = C.state_tstamp
where net_id_ems = 'MCI'
and case_no > '20200621000000'
and request_type = 'UNW1'
and status = 'CLOC'
and user_id = 'P951DRCP'
and iss_ica <> ' ')
and i.cust_id = 'BCFS' AND I.NET_ID = 'MCI' order by c.case_id asc)x;

SELECT
'UPDATE NQP1CAP1.EMS_FIN_PRE_AUTH SET ECOM_SECURITY_IND = ''*'' WHERE CASE_ID = ',
X.CASE_ID,
';'
from
(select case_id from nqp1cap1.ems_case
where case_no in (
'20181031003845','20181031003826','20181031003760','20181031003752','20181031003584','20181031003493','20181031003476','20181031003466',
'20181018004515','20181017006532','20181017006515','20181017006514','20181017006380','20181017005140','20181017005126')) x;

SELECT                                          
  'INSERT INTO NQP1CAP1.EMS_CASE_CONTEXT (',    
  'CASE_ID,TSTAMP_CREATED,CONTEXT_TYPE',        
  ',TSTAMP_PHASE,NET_ID,PROCESSED_FLG',         
  ',TSTAMP_UPDATED,CONTEXT_DATA) VALUES (',     
  X.CASE_ID,',''2019073109300000'',''EXPORT'',',
--  ''''||X.TSTAMP_CREATED||''',''NYC'',',        
  '''2019073009300000'',''MCI'',',              
  '''N'',''2019073109300000'',',                
  ''' '');'                                     
FROM 
(select C.case_id
from nqp1cap1.ems_case c
where c.CASE_NO IN (
'20190627012530',
'20190627012539',
'20190627006281',
'20190627006260')
AND REQUEST_TYPE = 'CHB1' AND STATUS = 'REVS') x;

select
'UPDATE NQP1CAP1.EMS_PHASE_MCI SET CARD_ISS_REF_DATA = '' ''',
'WHERE CASE_ID = ',
x.case_id,'AND TSTAMP_CREATED = '''||x.TSTAMP_CREATED||''';'
FROM 
(select C.case_id,m.tstamp_created
from nqp1cap1.ems_case c
inner join nqp1cap1.ems_Transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp1cap1.ems_phase_mci m on m.case_id = t.case_id and m.tstamp_created = t.phase_tstamp
where c.request_type = 'CHB1'
AND STATUS = 'REJR'
AND ERR_DE_1 = 'D0095' AND ERR_MSG_1 = '0649') x;

SELECT 
'UPDATE NQP1CAP1.EMS_PHASE_MCI SET CARD_ISS_REF_DATA = '' '' WHERE TSTAMP_CREATED = '''||X.TSTAMP_CREATED||''' AND CASE_ID = ',
x.case_id,';'
from
(select C.case_id,P.TSTAMP_CREATED
from nqp1cap1.ems_CAse c
inner join nqp1cap1.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp1cap1.ems_phase_mci p on p.case_id = t.case_id and p.tstamp_created = t.phase_tstamp
WHERE CASE_NO IN ('20190627005159'))x;

SELECT 
'UPDATE NQP1CAP1.EMS_DOCUMENT SET EXPORT_IND = ''S'' WHERE EXPORT_IND = ''R'' AND DELETE_FLG = ''N'' AND CASE_ID = ',
x.case_id,';'
from
(select C.case_id
from NQP1CAP1.ems_CAse c
inner join NQP1CAP1.ems_document d on d.case_id = c.case_id
WHERE c.CASE_id IN (
5174926,
5057491,
5057558,
5058083,
5058111,
5058306,
5058350)
and export_ind = 'R' and delete_flg = 'N') x;

SELECT 
'UPDATE NQP1CAP1.EMS_DOCUMENT SET EXPORT_IND = ''R'' WHERE EXPORT_IND = ''S'' AND CASE_ID = ',
x.case_id,';'
from
(select C.case_id
from nqp1cap1.ems_CAse c
inner join nqp1cap1.ems_document d on d.case_id = c.case_id
WHERE CASE_NO IN (
'20190627012530')
and request_type = 'CHB1' AND STATUS = 'REVS' and export_ind = 'S') x;

SELECT
'INSERT INTO NQP1CAP1.EMS_FIN_PRE_AUTH(CASE_ID,POS_ENTRY_MOD,CARD_ACPT_PST_CODE,AUTH_RESP_CD,POS_TERM_ATTND_IND,CVV_CVC_RESULT,',
'ECOM_SECURITY_IND,POS_CRDIN_TERM_IND,POS_CRDH_PRES_IND,AVS_RESULT_CD,APPROVAL_CODE,ACTION_CODE,DATE_EXPIRATION,EXCLD_TRAN_ID,EXIST_DEBT_FLG,',
'MOTO_IND,MULTI_CLR_SEQ_NO,TERM_TYPE_IND,TRAN_IDENTIFIER,TERM_ENTRY_CAP_IND,POS_COND_CODE,CASHBACK_AMT,CARD_TYPE,',
'CVC2_ISS_RESULT,CVC2_ACQ_RESULT,TERM_PART_APP_IND) VALUES(',
x.case_id,',''01'',''12345'',''00'',''9'',''*'','' '',''0'','' '',''U'','' '','' '','' '','' '','' '','' '','' '',''*'','' '','' '',',
''' '',0,''MCD'','' '','' '','' '');'
from
(select case_id from nqp1cap1.ems_case where case_id in (
4998385)) x;

select
'INSERT INTO NQP1CAP1.EMS_CASE_MCI(CASE_ID, ISS_ICA, ACQ_ICA, CARD_INP_CAP_IND,CARDH_AUTH_CAP_IND, CARD_CAPT_CAP_IND, TERM_OPER_ENVI_IND,',
'CARDH_PRESENT_IND, CARD_PRESENT_IND, CARD_INP_MODE_IND,CARDH_AUTHMOD_IND, CARDH_AUTHENT_IND, CARD_OUT_CAP_IND,',
'TERM_OUT_CAP_IND, PIN_CAPT_CAP_IND, TERMINAL_TYPE,MC_RTR_CTRL_NO, MC_CHB_CTRL_NO, ACPT_BRAND_CODE,BUS_SERV_LVL_IND, BUS_SERV_CODE, INTRCHG_RATE_DSG,',
'BUS_DATE, BUS_CYCLE, CUST_SERV_PHONE, MERCH_PHONE,ADDL_CONTACT_INFO, MC_DATE, MC_TIME, LIFECYCLE_SUP_IND,',
'LIFECYCLE_TRACE_ID, PROCESS_CODE, FEE_CNTL_NO, ORIG_RTR_RESN,MCI_ECS_LVL_IND, MAC_VALUE, MCI_AAV_RESULT_COD, DATE_ACTION,',
'ICCR_EFFECT_DATE, CARD_ACPT_URL, PRES_BUS_DATE, PGM_REG_ID,MASTERCOM_CTRL_NO, MCI_ASSIGNED_ID, AMT_POI, CUR_POI,',
'PYMT_TRAN_INIT, QPS_ELIGIBLE_IND, CVC2_PGM_IND,TRANSIT_TRAN_IND, TRANSPORT_MODE_IND, FRD_NOTIFY_DATE,REMOTE_PGM_IND, FRD_NOTIFY_SVC_COUNTER,',
'PPOL_PGM_DATA, PAYMENT_FID, SALES_ORG_ID, MERCHANT_ID,AUTH_TRAN_ID,AUTH_CLEARING_ID,CLAIM_ID) VALUES(',
x.case_id,','' '',''1234'',''0'','' '','' '',''9'','' '',''9'','' '','' '','' '','' '','' '','' '',''NA'','' '','' '',''DMC'','' '','' '',',
'''LF'','' '','' '','' '','' '','' '','' '','' '','' '','' '',''000000'','' '','' '','' '','' '','' '','' '','' '','' '','' '',',
''' '','' '','' '',0,'' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '');'
from
(select case_id from nqp1cap1.ems_case where case_id in (
4998385)) x;

select
'INSERT INTO NQP1CAP1.EMS_NATIONAL_NET (',
'CASE_ID,DUPLICATE_FLG,DUP_ACQ_REF_NO,NO_AUTH_FLG,AUTH_DECLINE_DATE,NO_AUTH_IN_POS_FLG,CARD_FRAUD_IND,',
'CARD_FRAUD_DATE,AMT_CORRECT_BILL,AMT_LODGING,AMT_VEHICLE,INCORRECT_TRAN_FLG,MERCH_REFUSE_IND,',
'MERCH_DELIVRY_DATE,MERCH_CANCEL_DATE,MERCH_DAMAGE_FLG,UNAUTH_PH_TRN_FLG,CONTR_SERVICE_DATE,CHG_BY_OTHER_FLG,',
'ATM_TRAN_DISP_FLG,RESERV_SERV_FLG,RESERV_SERV_DATE,RESERV_CANCEL_DATE,RESERV_CANCEL_NO,CD_NOT_RECV_FLG,',
'CD_AS_SALE_FLG,RECURE_CANCEL_DATE,RTR_DOC_OK_FLG,RTR_RECEIVED_DATE,RTR_ILLEGIBLE_FLG,RTR_NOT_IMPRIN_FLG,',
'RTR_NOT_SIGNED_FLG,RTR_INCORR_PAN_FLG,RTR_INCORR_AMT_FLG,REP_DOC_OK_FLG,REP_RECEIVED_DATE,REP_ILLEGIBLE_FLG,',
'REP_NOT_IMPRIN_FLG,REP_NOT_SIGNED_FLG,REP_INCORR_PAN_FLG,REP_INCORR_AMT_FLG,REP_AUTH_APPRD_FLG,REP_CVV_AVS_OK_FLG,',
'REP_PRF_DELVRY_FLG,RS5_ACQ_REF_NO,INCORRECT_TRAN_ARN,VEHICLE_RETN_DATE,MERCH_RETN_DATE,',
'MERCH_CONTACT_DATE,POSTING_DATE,VEHICLE_RENTAL_FLG,AMT_AUTHORIZED,NUM_TIMES_POSTED,ACQ_REF_NO,AUTH_ID_RESP,',
'WARN_BULLETIN_DATE,WARN_BULLETIN_NO,CATASTROPHE_FLG,UNRECOV_GD_SRV_FLG,AUTH_FOUND_FLG,CREDIT_SLIP_DATE,',
'INCORRECT_ARN_FLG,SNR_MERCH_CON_DATE,DESCRIPTION,DISCOVERY_DATE) VALUES(',
x.case_id,','' '','' '','' '','' '','' '','' '','' '',0,0,0,'' '','' '','' '','' '','' '','' '','' '','' '',0,',
''' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '',',
''' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '',0,'' '','' '','' '','' '','' '','' '','' '','' '',',
''' '','' '','' '','' '','' '');'
from
(select case_id from nqp1cap1.ems_case where case_id in (
4998385,
)) x;

select
'UPDATE nqp1cap1.EMS_phase_mci SET DOC_CODE_IND = ''N''  WHERE CASE_ID = ',
x.case_id,' AND TSTAMP_CREATED = '''||X.TSTAMP_CREATED||''';'
from
(select M.CASE_ID,M.TSTAMP_CREATED from nqp1cap1.ems_case c
INNER JOIN nqp1cap1.EMS_TRANSITION T ON T.CASE_ID = C.CASE_ID AND T.TSTAMP_cREATED = C.STATE_TSTAMP
INNER JOIN nqp1cap1.EMS_PHASE_MCI M ON M.CASE_ID = T.CASE_ID AND M.TSTAMP_CREATED = T.PHASE_TSTAMP
where c.case_id in (
5527436,
5534797,
5534666,
5533887,
5528426,
5528298,
5528052,
5515890,
5658188,
5653445,
5600401,
5527630,
5488389))x;

select
--'insert into nqp1cap1.api_queue_request(queue_id, seq_no,data_buffer) values (',
--' ,0,''<chargebackList><claimId>',x.claim_id,'</claimId><chargebackId>',x.api_chargeback_id,'</chargebackId></chargebackList>'');'
--' ,0,''<claim-id>',x.claim_id,'</claim-id>'');'
'insert into nqp1cap1.api_queue_control (queue_id,tstamp_event,api_state,api_type,case_id,req_type,retry_count,tstamp_created,',
--'api_result) values ( ,''2020053103150000'',''AW'',''MQUE'',0,''MCIIREPUNW'',-1,''2020053103150000'';'
'api_result) values ( ,''2020071611150000'',''AW'',''MCOM'',',
x.case_id,',''ClaimsRetrieveResponse'',-1,''2020071611150000'','' '');'
from
(select trim(trailing ' ' from claim_id)claim_id,c.case_id
--,trim(trailing ' ' from api_chargeback_id)api_chargeback_id
--(select c.case_id
from nqp1cap1.ems_case c
--inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
--inner join nqp1bcfs.ems_phase_mci p on p.case_id = t.case_id and p.tstamp_created = t.phase_tstamp
inner join nqp1cap1.ems_case_mci m on c.case_id = m.case_id
where c.case_id in (
5736475,5706463,5696688,5698644,5737334,5714824,5697817,5724051,5735658,5734954,5744144,5734103,5737282,5735716,5743124,5737146,
5750980,5690889,5713392,5753778,5724269,5705969,5706826,5706379,5705966,5743258))x;
and request_type = 'REP1' and status = 'GETD' order by claim_id asc) x;

select
--'update nqp1cap1.api_queue_request set data_buffer = '''||x.data_buffer||''' where queue_id = ',
'update nqp1bcfs.api_queue_control set api_state = ''AW'',retry_count = 0 where queue_id = ',
x.queue_id,';'
from
(select a.queue_id,A.case_id,data_buffer from nqp1cap1.api_queue_control a
inner join nqp1cap1.api_queue_request r on r.queue_id = a.queue_id
inner join nqp1cap1.ems_case c on c.case_id = a.case_id
where API_TYPE = 'MCOM' and req_type = 'CBGetDocumentResponse' 
and data_buffer like '%fileAttachment%' 
and a.case_id in (
5527171,
5760709,
5761496))x;
--and api_state = 'AF' and request_type = 'DOC4' and status = 'GETD' order by queue_id desc)x;

select 'update nqp1bcfs.ems_national_net set acq_ref_no = '''||x.ACQ_REF_NO||''' where case_id =', 
x.case_id,';'
from 
(select c.case_id,substr(ref_data_acq,1,23) acq_ref_no from nqp1bcfs.ems_case c
where case_id in (
select c.case_id from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_national_net n on n.case_id = c.case_id
where net_id_ems = 'MCI'
and request_type = 'FDRA'
and status = 'REJR'
and tstamp_trans <> ' '
and n.acq_ref_no = ' ')
and substr(ref_data_acq,1,1) <> ' ')x;
--on c.tstamp_trans = d.tstamp_trans and c.uniqueness_key = d.uniqueness_key where c.request_type != d.request_type and c.request_type = 'FDRA' and c.status = 'REJR' and 
--c.PROCESSING_SOURCE = 'X' and c.case_no between '20200223' and '2020029') order by case_id asc)x;

select 'update nqp1bcfs.ems_case set net_rules = ''PPM'' where case_id =', 
x.case_id,';'
from 
(select c.case_id from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
where case_no > '20200205000000'
and net_rules = 'MC3' and claim_id = ' '
and request_type in ('CHB1','CHBQ','REP1','DOC4') and (
iss_ica like '%10116%' or iss_ica like '%14424%' or iss_ica like '%14425%' or iss_ica like '%14426%' or
iss_ica like '%14427%' or iss_ica like '%14428%'))x;

--select
--'UPDATE NQP7cap1.EMS_phase_mci SET API_CHARGEBACK_ID = '''||x.api_chargeback_id||'''  WHERE CASE_ID = ',
--x.case_id,' AND TSTAMP_CREATED = '''||X.TSTAMP_CREATED||''';'
--from
select M.CASE_ID,M.TSTAMP_CREATED,claim_id,m.api_chargeback_id,request_type,status from NQP1cap1.ems_case c
INNER JOIN NQP1cap1.EMS_TRANSITION T ON T.CASE_ID = C.CASE_ID AND T.TSTAMP_cREATED = C.STATE_TSTAMP
INNER JOIN NQP1cap1.EMS_PHASE_MCI M ON M.CASE_ID = T.CASE_ID AND M.TSTAMP_CREATED = T.PHASE_TSTAMP
INNER JOIN NQP1cap1.EMS_cASE_MCI a ON a.CASE_ID = c.CASE_ID
where claim_id in (
'200468707470',
'200477492583',
'200477566935') order by claim_id asc;

select 'update nqp1cap1.fin_l', substr(x.tstamp_trans,1,6),
' set fin_type = ''010'' where tstamp_trans = '''||x.tstamp_trans||''' and uniqueness_key =',x.uniqueness_key,';'
from 
(select tstamp_trans,uniqueness_key from nqp1cap1.ems_case c where  c.request_type = 'FDRA' and c.status = 'REJR' and 
c.PROCESSING_SOURCE = 'X' and c.case_no between '20200223' and '2020029')x;

(select tstamp_trans,uniqueness_key from nqp1cap1.ems_case e where e.case_id in (
select d.case_id from nqp1cap1.ems_case c inner join nqp1cap1.ems_case d
on c.tstamp_trans = d.tstamp_trans and c.uniqueness_key = d.uniqueness_key where c.request_type != d.request_type and c.request_type = 'FDRA' and c.status = 'REJR' and 
c.PROCESSING_SOURCE = 'X' and c.case_no between '20200223' and '2020029'))x;

select count(*) from nqp1cap1.ems_case c where  c.request_type = 'FDRA' and c.status = 'REJR' and 
c.PROCESSING_SOURCE = 'X' and c.case_no between '20200223' and '2020029';

--BCFS billing extract to see when cases were settled
select substr(t.tstamp_created,1,8) D1,substr(t.tstamp_created,9,6) D2,pan_prefix,pan_suffix,acq_ref_No,request_type_next,status_next,amt_adjustment,err_msg_1
from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_national_net n on n.case_id = c.case_id
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id --and T.tstamp_created = C.state_tstamp
inner join nqp1bcfs.ems_phase_mci m on m.case_id = t.case_id and m.tstamp_created = t.phase_tstamp
where c.case_id in (
select c.case_id
from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id --and T.tstamp_created = C.state_tstamp
where net_id_ems = 'MCI'
and iss_ica like '%1965%'
and ((request_type_next = 'CHB1' and status_next = 'PNDR') OR (request_type_next = 'CHB2' and status_next = 'PNDR'))
and t.tstamp_created between '2020040408000000' and '2020040608000000'
and t.user_id = 'SYSTEM')
and t.phase_tstamp in (
select t.phase_tstamp
from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id --and T.tstamp_created = C.state_tstamp
where net_id_ems = 'MCI'
and iss_ica like '%1965%'
and ((request_type_next = 'CHB1' and status_next = 'PNDR') OR (request_type_next = 'CHB2' and status_next = 'PNDR'))
and t.tstamp_created between '2020040408000000' and '2020040608000000'
and t.user_id = 'SYSTEM')
and (request_type_prev in ('CHB1','CHB2') and status_prev = 'PNDR') --OR (request_type_prev = ' and status_prev = 'PNDR'))
--group by substr(t.tstamp_created,1,8),request_type_next,status_next
order by pan_prefix asc,pan_suffix asc,acq_ref_no desc,request_type_next,status_next;

select
'update nqp1bcfs.ems_case_mci set process_code = '''||x.proc_code||''' where case_id = ',
x.case_id,';'
from
(select case_id, substr(adl_data_priv_acq,6,6)proc_code from nqp1bcfs.ems_case c
inner join nqp1bcfs.fin_record201910 r on r.tstamp_trans = c.tstamp_trans and r.uniqueness_key = c.uniqueness_key
where case_id in (
11307611	,
11307848))x;

select
'update nqp1bcfs.ems_national_net set acq_ref_no = '''||x.arn||''' where case_id = ',
x.case_id,';'
from
(select c.case_id,substr(ref_data_acq,1,23)arn
from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id and t.tstamp_Created = c.state_tstamp
inner join nqp1bcfs.ems_national_net n on n.case_id = c.case_id
WHERE c.request_type = 'FDRA'
AND status = 'REJR' 
AND NET_ID_EMS = 'MCI'
and reason_code <> ' '
and tstamp_trans <> ' '
and acq_ref_no <> ' '
and substr(acq_ref_no,1,23) <> substr(ref_data_acq,1,23)
and state_tstamp > '2020062100000000'
and substr(tstamp_trans,0,6) > '201905'
order by c.case_id asc)x;

select
'insert into nqp1bcfs.ems_data_chg (case_id,tstamp_created,seq_no,user_id,table_changed,column_changed,column_old_value,column_new_value) values (',
x.case_id,',''2020071308450000'',0,''SQL'',''EMS_NATIONAL_NET'',''ACQ_REF_NO'','''||x.old_arn||''','''||x.new_arn||''';'
from
(select c.case_id,substr(acq_ref_no,1,23)old_arn,substr(ref_data_acq,1,23)new_arn
from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_transition t on t.case_id = c.case_id and t.tstamp_Created = c.state_tstamp
inner join nqp1bcfs.ems_national_net n on n.case_id = c.case_id
WHERE c.request_type = 'FDRA'
AND status = 'REJR' 
AND NET_ID_EMS = 'MCI'
and reason_code <> ' '
and tstamp_trans <> ' '
and acq_ref_no <> ' '
and substr(acq_ref_no,1,23) <> substr(ref_data_acq,1,23)
and state_tstamp > '2020062100000000'
and substr(tstamp_trans,0,6) > '201905'
order by c.case_id asc)x;

select
'update nqp1bcfs.ems_case_mci set acq_ica = '''||x.acq_id||''' where case_id = ',
x.case_id,';'
from
(select c.case_id,status,substr(inst_id_acq,2)acq_id
from nqp1bcfs.ems_case c
inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
where NET_ID_EMS = 'MCI'
and case_type_ind = 'D'
and acq_ica = ' '
and status = 'REJR'
and state_tstamp > '2020062100000000'
order by c.case_id asc)x;

select
'update nqp1bcfs.ems_case_mci set process_code = ''000000'' where case_id = ',
x.case_id,';'
from
(select c.case_id
from nqp1bcfs.ems_case c 
--inner join nqp1bcfs.fin_record202007 r on r.tstamp_trans = c.tstamp_trans and r.uniqueness_key = c.uniqueness_key
inner join nqp1bcfs.ems_case_mci m on m.case_id = c.case_id
where net_id_ems = 'MCI'
and case_no > '20200621000000'
and process_code = ' ' and tstamp_trans = ' ')x;
