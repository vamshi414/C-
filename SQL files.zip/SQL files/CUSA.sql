select * from nqp7cusa.ems_case where case_no = '20200417002753';
select * from nqp7cusa.ems_transition where case_id = 243844751 order by tstamp_created asc;

select case_no,request_type,status,TSTAMP_AUTO_TRANS,state_tstamp,iss_cust_id from nqp7cusa.ems_case
where net_rules = 'S2S' AND acq_case_no <> ' ' and case_no > '20190101000000' order by state_tstamp desc;

select * from nqp7cusa.ems_case where NET_ID_ACQ = 'MAP' and CASE_TYPE_IND = 'D' AND STATUS = 'SDRC' ORDER BY CASE_ID DESC;
select * from nqp7cusa.ems_case where pan_prefix = '55101' and pan_suffix = '3580' and case_type_ind = 'X';

select * from nqp7cusa.ems_case where case_id = 243402485;

select * from nqp7cusa.ems_case where tstamp_trans = '2019070819393739';
select * from nqp7cusa.fin_record201810 where tstamp_trans = '2018102616324380' and uniqueness_key = 17052;
select * from nqp7cusa.fin_l202004 l 
inner join nqp7cusa.fin_record202004 r on r.tstamp_trans = l.tstamp_trans
and r.uniqueness_key = l.uniqueness_key where pan_prefix = '551010' and pan_suffix = '7062' and l.amt_recon_net = 10500;
l.tstamp_trans = '2019061711143556' and l.uniqueness_key = 29002;
select net_id_acq,net_id_iss,amt_tran from nqp7cusa.fin_record201811 where tstamp_trans ='2018111508301325' and uniqueness_key = 23138;
select * from nqp7cusa.ems_phase where case_id = 243356713 ORDER BY TSTAMP_cREATED ASC;
select * from nqp7cusa.ems_fraud_mci where case_id = 242484893;
select * from nqp7gtwy.ems_fraud_mci where audit_ctrl_no = '000000003708432';
select * from nqp7cusa.ems_case_vnt where case_id = 243047199;
select * from nqp7cusa.ems_case_mci where case_id = 243557898;
select * from nqp7cusa.ems_case_mci where claim_id = '200227719668';
select * from nqp7cusa.ems_phase_mci where case_id = 243832795 ORDER by tstamp_Created asc;
select * from nqp7cusa.ems_phase_vnt where 
--vrol_case_no = '1664905799';
case_id =242979517 order by tstamp_created asc;
select * from nqp7cusa.ems_phase_vnt_vrol where case_id = 241902216;
select * from nqp7cusa.ems_document where case_id = 243832795;
select * from nqp7cusa.ems_fraud_vnt where case_id = 7372387;
select ACQ_REF_NO from nqp7cusa.ems_national_net where case_id = 243561589;
select * from nqp7cusa.ems_national_net where acq_ref_no = '85482989350702121941040';
select state_tstamp from nqp7cusa.ems_case c inner join nqp7cusa.ems_case_vnt v on v.case_id = c.case_id
where net_id_ems = 'VNT' and request_type = 'FDRA' AND STATUS in ('REJ1') AND VCR_IND = 'Y'
and state_tstamp < '2018042000000000';

select * from nqp7cusa.ems_fin_pre_auth where case_id = 242429889;

select * from nqp7cusa.ems_data_chg where case_id = 243848591 order by tstamp_created asc;
select * from nqp7cusa.di_data where import_key = '20200226002804';
select * from nqp7cusa.di_data_control where di_file_id = 1403662;
select * from nqp7cusa.assoc_tran where case_id = 242160458;

select request_type,status from nqp7cusa.ems_case c
inner join nqp7cusa.api_queue_control a on a.case_id = c.case_id
where api_result like '%Socket%';

select * from nqp7cusa.api_queue_control where case_id = 243718327 order by queue_id asc;
select * from nqp7cusa.api_queue_control order by queue_id desc;where queue_id = 808721;
select * from nqp7cusa.api_queue_control a 
inner join nqp7cusa.ems_case c on c.case_id = a.case_id
where api_state = 'AF' and api_type = 'MCOM' and req_type = 'CBGetDocumentResponse' 
and request_type = 'DOC4' AND STATUS = 'GETD';
and api_result not in 
('Error: Transition failed from CHBQ/PNDR to CHBQ/PNDR','Error: Transition failed from CH2Q/PNDR to CH2Q/PNDR')  order by queue_id desc;--queue_id = 1641961;

select * from nqp7cusa.api_queue_control where api_type = 'MCOM' and tstamp_created > '2019122100000000' order by queue_id desc;
select * from nqp7cusa.api_queue_control where api_type = 'MQUE' and REQ_TYPE = 'MCIDOCCOMP' order by queue_id desc;
select * from nqp7cusa.api_queue_response where queue_id = 808721 ORDER BY SEQ_NO ASC;
select * from nqp7cusa.api_queue_request where queue_id = 791107 ORDER BY SEQ_NO ASC;
select * from nqp7cusa.message_log where msg_session = '193387';
select * from nqp7cusa.message_log where sender = 'WSCLIENT';

seLect a.queue_id,tstamp_event,tstamp_created,retry_count,REQ_TYPE
--req_type,request_type,status,c.case_id
,data_buffer 
from nqp7cusa.api_queue_control a 
inner join nqp7cusa.api_queue_response r on r.queue_id = a.queue_id
--inner join nqp7gtwy.ems_case c on c.case_id = a.case_id
--where data_buffer like '%Read timed out%'
where REQ_TYPE = 'MCIDOCCOMP'
order by a.queue_id desc;

select * from nqp7cusa.api_queue_request where queue_id in
(select queue_id from nqp7cusa.api_queue_control where case_id = 243306783) order by queue_id asc;
select * from nqp7cusa.api_queue_request where queue_id in (select queue_id from nqp7cusa.api_queue_control where req_type = 'TII') order by queue_id desc; 
select * from nqp7cusa.api_queue_response where queue_id in
(select queue_id from nqp7cusa.api_queue_control where case_id = 243374323) order by queue_id asc;
SELECT distinct case_id, tstamp_created from nqp7cusa.api_queue_control where queue_id in (
select queue_id from nqp7cusa.api_queue_response where data_buffer like '%25140619279058169023469%') order by case_id asc;
select * from nqp7cusa.api_qevent_log where queue_id =781449 order by tstamp_created asc;

SELECT a.queue_id,api_state,a.case_id,request_type,status,api_result,RETRY_COUNT,data_buffer
from nqp7cusa.api_queue_control a
inner join nqp7cusa.ems_case c on c.case_id = a.case_id 
inner join nqp7cusa.api_queue_response r on r.queue_id = a.queue_id
where api_result like '%ME53: Do not recognize status%' 
and request_type = 'REP1' AND STATUS = 'SDRC' ORDER BY CASE_ID ASC;
and status <> 'CLOA' order by queue_id desc; 

SELECT a.queue_id,api_state,a.case_id,request_type,status,api_result, data_buffer 
from nqp7cusa.api_queue_control a
inner join nqp7cusa.ems_case c on c.case_id = a.case_id 
inner join nqp7cusa.api_queue_response r on r.queue_id = a.queue_id
where api_result like '%ME53: Do not recognize status%'
and data_buffer like '%documentIndicator>false%' order by case_id asc;

--SELECT                                                 
--'INSERT INTO nqp7cusa.EMS_TRANSITION (CASE_ID,PHASE_TSTAMP,TSTAMP_CREATED,SEQ_NO,USER_ID,REQUEST_TYPE_PREV,STATUS_PREV,REQUEST_TYPE_NEXT,STATUS_NEXT,MANUAL_OVERRIDE,ACTION,ACTION_TO_CARDHLDR,REASON_CODE,AMT_ADJUSTMENT) VALUES (',               
--X.CASE_ID,','''||X.PHASE_TSTAMP||''',''2018042315300000''',                
-- '''1'',''SQL'','''||X.REQUEST_TYPE||''',',            
-- ''''||X.STATUS||''','''||X.REQUEST_TYPE||''',',       
--'''FWRD'',''N'','' '','''||X.ACTION_TO_CARDHLDR||''',',
--''''||X.REASON_CODE||''',',X.AMT_ADJUSTMENT,');'       
-- FROM                                                  
--   (                                                   
select c.case_id,request_type,status, t.phase_tstamp,t.reason_code,t.action_to_cardhldr,t.amt_adjustment,v.support_info
from nqp7cusa.ems_case c
inner join nqp7cusa.ems_transition t
on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7cusa.ems_phase_vnt v
on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
where support_info like '%Internal Error%';
--and request_type = 'FDRA')X;

select count(*)
from nqp7cusa.api_queue_response r
inner join nqp7cusa.api_queue_control a
on a.queue_id = r.queue_id
inner join nqp7cusa.ems_case c
on c.case_id = a.case_id
where data_buffer like '%settlement%'
and request_type = 'CHB1';

select * from nqp7cusa.assoc_tran_vnt where case_id = 7394750;
select * from nqp7cusa.assoc_tran where case_id = 7394750;

select c.case_id, c.state_tstamp, c.date_recon_net, n.acq_ref_no, a.arn, v.tran_type, v.tran_identifier
from nqp7cusa.ems_case c 
inner join nqp7cusa.ems_national_net n on n.case_id = c.case_id
inner join nqp7cusa.assoc_tran a on a.case_id = c.case_id
inner join nqp7cusa.assoc_tran_vnt v on v.ATR_SEQ_no = a.seq_no
where request_type = 'FDRA'
and status = 'REJ1';
--d state_tstamp > '2018042700000000';
AND v.tran_type like '02%';

--select c.case_id, case_no, case_type_ind, tstamp_trans,v.vrol_case_no
select c.case_id, case_no, pan_prefix,request_type,status,state_tstamp, iss_ica
--select distinct c.case_id,case_no,tstamp_trans,state_tstamp,rol_tran_id, c.request_type, status,vrol_case_no,v.support_info
--select c.case_id, acq_bin, net_id_iss,case_no, tstamp_trans,state_tstamp,c.request_type, status,merchant_cat_code, v.support_info
--select c.case_id, pan_prefix, net_id_acq,case_no, tstamp_trans,state_tstamp,c.request_type, status,merchant_cat_code, v.support_info
--select c.CASE_id, case_no, pan_prefix,net_id_ems,vrol_case_no,state_tstamp,c.request_type, status,merchant_cat_code, v.support_info
--select c.case_id, case_no, pan_prefix, pan_suffix, retrieval_ref_no,iss_bin,acq_bin, net_id_ems,tstamp_local,c.amt_recon_net/100,
--tran_identifier,h.reason_code,h.amt_adjustment/100,c.request_type,status,merchant_cat_code, state_tstamp,v.vrol_case_no,v.support_info
--select c.case_id,case_no,pan_prefix,net_id_acq,tstamp_trans,state_tstamp,tran_identifier, tstamp_local,date_recon_net,c.request_type, status,v.support_info
--,r.DATA_BUFFER
from nqp7cusa.ems_case c
--inner join nqp7cusa.ems_case_vnt u on u.case_id = c.case_id
inner join nqp7cusa.ems_case_mci m on m.case_id = c.case_id
--inner join nqp7cusa.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
--inner join nqp7cusa.ems_phase_mci m on m.case_id = c.case_id and m.tstamp_created = t.phase_tstamp
--inner join nqp7cusa.ems_phase_vnt v on v.case_id = c.case_id and v.tstamp_created = t.phase_tstamp
--inner join nqp7cusa.ems_phase h on h.case_id = t.case_id and h.tstamp_created = t.phase_tstamp
--inner join nqp7cusa.api_queue_control q on q.case_id = c.case_id
--inner join nqp7cusa.api_queue_request r on r.queue_id = q.queue_id
where net_rules = 'MC3'
and iss_ica like '%6878%'
and case_type_ind = 'X'
--and request_type_prev = 'REP1' 
--AND STATUS_prev = 'GETD'
--and request_type = 'CHB1' 
--AND STATUS = 'PNDR'
--AND ERR_VROL_MSG1 = 'E-900000083'
--AND STATE_TSTAMP > '2020011300000000'
--and r.data_buffer not like '%<ARN>%'
--AND V.SUPPORT_INFO LIKE '%access%'
--and err_msg_1 = '2668'
--and err_de_1 = 'D093'
order by state_tstamp desc;

--and r.data_buffer like '%DuplicateTranId%';
--AND ERR_VROL_MSG1 = 'E-900000081';
--AND h.user_role = 'A'
--order by acq_bin asc;
/*union all
select c.case_id, case_no, case_type_ind, tstamp_trans,v.vrol_case_no
from nqp7cusa.ems_case c
inner join nqp7cusa.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7cusa.ems_phase_vnt v on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
where case_type_ind = 'D'
and tstamp_trans in (
select tstamp_trans
from nqp7cusa.ems_case c
inner join nqp7cusa.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7cusa.ems_phase_vnt v on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
where net_rules = 'VN3'
and request_type = 'CHBQ' AND STATUS = 'REJR'
AND V.SUPPORT_INFO LIKE '%Internal%')
order by tstamp_trans, case_type_ind;*/
--order by pan_prefix asc;

Select c.case_id,case_no,state_tstamp,status,tstamp_trans,rol_tran_id, net_rules, support_info
from nqp7cusa.ems_case c
inner join nqp7cusa.ems_case_vnt u on u.case_id = c.case_id
inner join nqp7cusa.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7cusa.ems_phase_vnt v on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
where case_type_ind = 'D' and tstamp_trans in (select tstamp_trans
from nqp7cusa.ems_case c
inner join nqp7cusa.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7cusa.ems_phase_vnt v on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
where net_rules = 'VN3'
and request_type = 'CHBQ' AND STATUS = 'REJR'
AND V.SUPPORT_INFO LIKE '%Internal%')
and net_rules = 'VN3'
and v.support_info like '%DisputeAmtCurrCode%';
--order by net_rules asc;

Select queue_id,req_type from nqp7cusa.api_queue_control where case_id in (
Select case_id from nqp7cusa.ems_case where case_type_ind = 'D' and tstamp_trans in ('2018010601465363',
'2018010601465366','2018030916363116','2018010320462963','2018040808284462','2018040603092527','2018041103093380'))
And req_type like 'TI%';


select * from nqp7gtwy.di_data where data_buffer like '%811515607923%';

select
'INSERT INTO nqp7cusa.EMS_PHASE_VNT (CASE_ID,TSTAMP_CREATED,EXCLD_TRAN_ID,PROCESS_CODE,TRANSMIT_DATE_TIME,POS_COND_CODE,RESP_CODE,DOC_IND,NETW_MGMT_CODE,MMT_KEY, MMT_MOD_FLG,FIELD_ID,USAGE_CODE,CHB_REF_NO,ISSUER_CNTL_NO,RETURN_REASON_1,RETURN_REASON_2,RETURN_REASON_3,RETURN_REASON_4, RETURN_REASON_5,RETURN_REASON_6,RETURN_REASON_7,RETURN_REASON_8,RETURN_REASON_9,RETURN_REASON_10,ADDL_TRACE_DATA, STIP_SW_RESN_CODE,ORIG_RESP_CODE,ERR_RETURN_FLG,PURCHASE_DATE,REASON_CODE,ISS_REQ_FUL_METH,ACQ_ESTB_FUL_METH,DISPU_RESN_CD, DISPU_RTN_RESN_CD,DISPU_RULE_RESN_CD,DISPU_REQ_DATE,VCRFS_ACCT_NO_FLG,VCRFS_PUR_DATE_FLG,VCRFS_TRAN_AMT_FLG,VCRFS_EXP_DATE_FLG, VCRFS_MERCH_FLG,DISPUTE_CONDITION,FINANCIAL_SENT_IND,REJECT_CODE,B2_CPD_VISA_FMT,B2_CPD_DN_FMT,B2_SEC_ADV_TYPE,VROL_CASE_NO, FEE_CHARGE_FLG,ERR_VROL_MSG1,ERR_VROL_MSG2,ERR_VROL_MSG3,ERR_VROL_MSG4,ERR_VROL_MSG5,SUPPORT_INFO,VISA_MMT,TI_EVENT_ID,DISPUTE_ID,NOT_ASSOC_REASON) VALUES (',
x.case_id,',''2018061507150000'','' '','''||x.process_code||''','''||x.transmit_date_time||''','' '','''||x.resp_code||''',',
''' '','' '','' '','' '','' '','' '','' '','''||x.issuer_cntl_no||''','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '',',
''' '','''||x.stip_sw_resn_code||''','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '',',
''''||x.dispute_condition||''','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '','' '');'
from
(SELECT v.case_id, process_code, transmit_date_time, resp_code,issuer_cntl_no,stip_sw_resn_code, dispute_condition
from nqp7cusa.ems_phase_vnt v
inner join nqp7cusa.ems_phase h on v.case_id = h.case_id and v.tstamp_created = h.tstamp_created
where h.case_id in
(241872519,241874525,241902569,241874551,241874564,241874572,241876545,241876805,
241876817,241876819,241876846,241876881,241876899,241878257,241878282,241878289,
241878376,241878378,241878456,241878462,241879351,241882755,241884986,241885036,
241885202,241889188,241889194,241890201,241890267,241894546,241894920,241894921,
241894922,241894923,241894924,241894927,241897896,241900686,241901748,241901749,
241901750,241901751,241901752,241901753,241901754,241901755,241901756,241901757,
241902568,241902570,241902571,241928359,241929573,241945265,241903329,241905844,
241906323,241910984,241913097,241913476,241913554,241913589,241914190,241914209,
241917094,241917877,241919995,241920207,241920408,241920463,241921443,241921455,
241921512,241921524,241921539,241922041,241924000,241924136,241924279,241926379,
241926380,241928280,241929173,241930106,241930119,241930162,241930946,241932062,
241932432,241934575,241934589,241938122,241938941,241939008,241940068,241942609,
241942610,241942611,241944229,241944236,241996662,241998019,242003465,242002106,
241947568,241947569,241948954,241983161,241989593,241996050,242000795,242000798,
242001575,242002100)
and request_type = 'CHBQ') x;

select
'INSERT INTO nqp7cusa.EMS_TRANSITION (CASE_ID,PHASE_TSTAMP,TSTAMP_CREATED,SEQ_NO,USER_ID,REQUEST_TYPE_PREV,STATUS_PREV,REQUEST_TYPE_NEXT,STATUS_NEXT,MANUAL_OVERRIDE,ACTION,ACTION_TO_CARDHLDR,REASON_CODE,AMT_ADJUSTMENT) VALUES (',
x.case_id,',''2018061507150000'',''2018061507150000'',''1'',''SQL'',''CHBQ'',''REJR'',''CHB1'',''REJR'',''Y'','' '',',
''''||x.action_to_cardhldr||''',''10'',',
x.amt_adjustment,');'
from
(SELECT t.case_id, t.action_to_cardhldr,amt_adjustment
from nqp7cusa.ems_transition t
inner join nqp7cusa.ems_case c on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
where c.case_id in
(241872519,241874525,241902569,241874551,241874564,241874572,241876545,241876805,
241876817,241876819,241876846,241876881,241876899,241878257,241878282,241878289,
241878376,241878378,241878456,241878462,241879351,241882755,241884986,241885036,
241885202,241889188,241889194,241890201,241890267,241894546,241894920,241894921,
241894922,241894923,241894924,241894927,241897896,241900686,241901748,241901749,
241901750,241901751,241901752,241901753,241901754,241901755,241901756,241901757,
241902568,241902570,241902571,241928359,241929573,241945265,241903329,241905844,
241906323,241910984,241913097,241913476,241913554,241913589,241914190,241914209,
241917094,241917877,241919995,241920207,241920408,241920463,241921443,241921455,
241921512,241921524,241921539,241922041,241924000,241924136,241924279,241926379,
241926380,241928280,241929173,241930106,241930119,241930162,241930946,241932062,
241932432,241934575,241934589,241938122,241938941,241939008,241940068,241942609,
241942610,241942611,241944229,241944236,241996662,241998019,242003465,242002106,
241947568,241947569,241948954,241983161,241989593,241996050,242000795,242000798,
242001575,242002100)) x;

select
--'update nqp7cusa.ems_case_vnt set rol_tran_id = '' '' where case_id = ',
--x.case_id,';'
'UPDATE nqp7cusa.EMS_CASE SET TSTAMP_UPDATED = ''2018061507150000'',STATE_TSTAMP = ''2018061507150000'',',
'REQUEST_TYPE = ''CHB1'', STATUS = ''REJR'' WHERE CASE_ID = ',
x.case_id,';'
from
(SELECT * from nqp7cusa.ems_case
where case_id in
(241872519,241874525,241902569,241874551,241874564,241874572,241876545,241876805,
241876817,241876819,241876846,241876881,241876899,241878257,241878282,241878289,
241878376,241878378,241878456,241878462,241879351,241882755,241884986,241885036,
241885202,241889188,241889194,241890201,241890267,241894546,241894920,241894921,
241894922,241894923,241894924,241894927,241897896,241900686,241901748,241901749,
241901750,241901751,241901752,241901753,241901754,241901755,241901756,241901757,
241902568,241902570,241902571,241928359,241929573,241945265,241903329,241905844,
241906323,241910984,241913097,241913476,241913554,241913589,241914190,241914209,
241917094,241917877,241919995,241920207,241920408,241920463,241921443,241921455,
241921512,241921524,241921539,241922041,241924000,241924136,241924279,241926379,
241926380,241928280,241929173,241930106,241930119,241930162,241930946,241932062,
241932432,241934575,241934589,241938122,241938941,241939008,241940068,241942609,
241942610,241942611,241944229,241944236,241996662,241998019,242003465,242002106,
241947568,241947569,241948954,241983161,241989593,241996050,242000795,242000798,
242001575,242002100)) x;


select
'update nqp7cusa.ems_case_vnt set rol_tran_id = '' '' where case_id = ',
x.case_id,';'
--'update nqp7cusa.api_queue_control set req_type = ''TIII'' where queue_id = ',
--x.queue_id,';'
from
--(SELECT queue_id from nqp7cusa.api_queue_control
--where req_type = 'TII'
--and case_id in 
(select case_id from nqp7cusa.ems_case where 
case_type_ind = 'D' and tstamp_trans in (
select tstamp_trans from nqp7cusa.ems_case where case_id in
(241872519,241874525,241902569,241874551,241874564,241874572,241876545,241876805,
241876817,241876819,241876846,241876881,241876899,241878257,241878282,241878289,
241878376,241878378,241878456,241878462,241879351,241882755,241884986,241885036,
241885202,241889188,241889194,241890201,241890267,241894546,241894920,241894921,
241894922,241894923,241894924,241894927,241897896,241900686,241901748,241901749,
241901750,241901751,241901752,241901753,241901754,241901755,241901756,241901757,
241902568,241902570,241902571,241928359,241929573,241945265,241903329,241905844,
241906323,241910984,241913097,241913476,241913554,241913589,241914190,241914209,
241917094,241917877,241919995,241920207,241920408,241920463,241921443,241921455,
241921512,241921524,241921539,241922041,241924000,241924136,241924279,241926379,
241926380,241928280,241929173,241930106,241930119,241930162,241930946,241932062,
241932432,241934575,241934589,241938122,241938941,241939008,241940068,241942609,
241942610,241942611,241944229,241944236,241996662,241998019,242003465,242002106,
241947568,241947569,241948954,241983161,241989593,241996050,242000795,242000798,
242001575,242002100))) x;

select c.case_id,CASE_NO,request_type,status,vrol_case_no from nqp7cusa.ems_case c 
inner join nqp7cusa.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7cusa.ems_phase_vnt v on v.case_id = c.case_id and v.tstamp_created = t.phase_tstamp
where c.case_id in (
241871306,
241934189,
)
and status NOT IN ('CLOA','CLTA','CLOC');
order by c.case_id asc;

select question_fields from nqp7cusa.ems_case c
inner join nqp7cusa.ems_phase_vnt_vrol v on v.case_id = c.case_id
where c.net_Rules = 'VN3' 
and question_fields like '%<WhatIncorrectAboutTransaction>D</WhatIncorrectAboutTransaction>%'
order by state_tstamp desc;

select * from nqp7comn.institution where INST_ID = '104000210' AND cust_id = 'CUSA';
SELECT * FROM NQP7COMN.emsr_NET_RULE_USE where network_rules = 'MCI' and cust_id = 'CUSA';
select * from nqp7gtwy.DX_DATA_CONTROL WHERE DX_FILE_TYPE = 'EMEMCC';
select * from nqp7cusa.ems_case_context where case_id = 243844751;

select * from nqp7cusa.ems_case c 
inner join nqp7cusa.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
where net_id_acq = 'CPP' and request_type = 'CHB1' and status = 'SDRC' 
and t.user_id = 'SYSTEM' order by c.case_id desc;

Select * from nqp7comn.institution where inst_id = '733001350' and cust_id = 'CUSA';
select dispute_proc_id from nqp7comn.processor where proc_id = 'PRK772' and cust_id = 'CUSA';
select * from nqp7cusa.ems_case_context where case_id = 242303721;
select * from nqp7cusa.di_data order by tstamp_parsed asc;

explain plan for
SELECT /*+ INDEX (FIN_LOCATOR X1FL201811) INDEX (R X2FIN_RECORD201811) */ FIN_LOCATOR.ACT_CODE,FIN_LOCATOR.AMT_RECON_NET,FIN_LOCATOR.APPROVAL_CODE,FIN_LOCATOR.AUTH_BY,FIN_LOCATOR.CARD_ACPT_TERM_ID,FIN_LOCATOR.CUR_RECON_NET,FIN_LOCATOR.DATE_RECON_ACQ,FIN_LOCATOR.FIN_TYPE,FIN_LOCATOR.FUNC_CODE,FIN_LOCATOR.INST_ID_ACQ,FIN_LOCATOR.INST_ID_ISS,FIN_LOCATOR.INST_ID_RECN_ACQ_B,FIN_LOCATOR.INST_ID_RECN_ISS_B,FIN_LOCATOR.INST_ID_RECON_ACQ,FIN_LOCATOR.INST_ID_RECON_ISS,FIN_LOCATOR.INV_ORDER_NO,FIN_LOCATOR.MAPPED_DUP_DATA,FIN_LOCATOR.MERCH_TYPE,FIN_LOCATOR.NET_TERM_ID,FIN_LOCATOR.PAN,FIN_LOCATOR.PROC_GRP_ID_ACQ_B,FIN_LOCATOR.PROC_GRP_ID_ISS_B,FIN_LOCATOR.PROC_ID_ACQ,FIN_LOCATOR.PROC_ID_ACQ_B,FIN_LOCATOR.PROC_ID_ISS,FIN_LOCATOR.PROC_ID_ISS_B,FIN_LOCATOR.RETRIEVAL_REF_NO,FIN_LOCATOR.RPT_LVL_ID_B,FIN_LOCATOR.SUBSCRIBER_IND,FIN_LOCATOR.SYS_TRACE_AUDIT_NO,FIN_LOCATOR.TRAN_CLASS,FIN_LOCATOR.TRAN_TYPE_ID,FIN_LOCATOR.TSTAMP_LOCAL,FIN_LOCATOR.TSTAMP_TRANS,FIN_LOCATOR.UNIQUENESS_KEY,FIN_PAYMENT.AMT_FIRST,FIN_PAYMENT.AMT_SUBSEQUENT,FIN_PAYMENT.ANNUAL_PERCNT_RATE,FIN_PAYMENT.CUR_INSTALLMENT,FIN_PAYMENT.F_AMT_INSTALLMENT,FIN_PAYMENT.INSTALLMENT_TYPE,FIN_PAYMENT.ISS_INTER_RATE,FIN_PAYMENT.NUM_INSTALLMENTS,FIN_PAYMENT.PROMOTION_CODE,FIN_PAYMENT.TAX_ID,FIN_PAYMENT.TSTAMP_TRANS,FIN_PAYMENT.UNIQUENESS_KEY,R.AAM_VELOCITY_RESULT,R.ACCT_ID_1,R.ACCT_ID_2,R.ACCT_ID_3,R.ACCT_QUAL_1,R.ACCT_QUAL_2,R.ACCT_TYPES_ISS,R.ACCT_TYPE_1,R.ACCT_TYPE_2,R.ACCT_TYPE_3,R.ACQ_PLAT_PROD_ID,R.ACQ_ROUTING_NO,R.ADDL_TRAN_DISP,R.ADDL_TRAN_RESULT,R.ADL_DATA_NATIONAL,R.ADL_DATA_PRIV_ACQ,R.ADL_DATA_PRIV_ISS,R.ADL_RESP_ACCT_IDX0,R.ADL_RESP_ACCT_IDX1,R.ADL_RESP_ACCT_IDX2,R.ADL_RESP_ACCT_IDX3,R.ADL_RESP_ACCT_IDX4,R.ADL_RESP_ACCT_IDX5,R.ADL_RESP_ACCT_TYP0,R.ADL_RESP_ACCT_TYP1,R.ADL_RESP_ACCT_TYP2,R.ADL_RESP_ACCT_TYP3,R.ADL_RESP_ACCT_TYP4,R.ADL_RESP_ACCT_TYP5,R.ADL_RESP_AMT0,R.ADL_RESP_AMT1,R.ADL_RESP_AMT2,R.ADL_RESP_AMT3,R.ADL_RESP_AMT4,R.ADL_RESP_AMT5,R.ADL_RESP_AMT_TYP0,R.ADL_RESP_AMT_TYP1,R.ADL_RESP_AMT_TYP2,R.ADL_RESP_AMT_TYP3,R.ADL_RESP_AMT_TYP4,R.ADL_RESP_AMT_TYP5,R.ADL_RESP_CUR_CODE0,R.ADL_RESP_CUR_CODE1,R.ADL_RESP_CUR_CODE2,R.ADL_RESP_CUR_CODE3,R.ADL_RESP_CUR_CODE4,R.ADL_RESP_CUR_CODE5,R.ADL_RESP_DATA,R.ADL_RQST_ACCT_IDX0,R.ADL_RQST_ACCT_IDX1,R.ADL_RQST_ACCT_IDX2,R.ADL_RQST_ACCT_IDX3,R.ADL_RQST_ACCT_IDX4,R.ADL_RQST_ACCT_IDX5,R.ADL_RQST_ACCT_TYP0,R.ADL_RQST_ACCT_TYP1,R.ADL_RQST_ACCT_TYP2,R.ADL_RQST_ACCT_TYP3,R.ADL_RQST_ACCT_TYP4,R.ADL_RQST_ACCT_TYP5,R.ADL_RQST_AMT0,R.ADL_RQST_AMT1,R.ADL_RQST_AMT2,R.ADL_RQST_AMT3,R.ADL_RQST_AMT4,R.ADL_RQST_AMT5,R.ADL_RQST_AMT_TYP0,R.ADL_RQST_AMT_TYP1,R.ADL_RQST_AMT_TYP2,R.ADL_RQST_AMT_TYP3,R.ADL_RQST_AMT_TYP4,R.ADL_RQST_AMT_TYP5,R.ADL_RQST_CUR_CODE0,R.ADL_RQST_CUR_CODE1,R.ADL_RQST_CUR_CODE2,R.ADL_RQST_CUR_CODE3,R.ADL_RQST_CUR_CODE4,R.ADL_RQST_CUR_CODE5,R.ALT_ROUTE_FLG,R.AMT_CARD_BILL,R.AMT_RECON_ACQ,R.AMT_RECON_ISS,R.AMT_RECON_NET,R.AMT_TRAN,R.AP_APPROVAL_CODE,R.AP_CARD_GRP,R.AP_DATA,R.AP_ERROR_NO,R.AP_ERROR_TRACE_LOC,R.AP_FLG,R.AP_REJ_REASON_CODE,R.AUTH_LCYCLE_TCODE,R.AUTH_LCYCLE_TRACE,R.AUTH_LIFECYCLE_INT,R.AUTH_RQST_TIMEOUT,R.BIN_EXCLUSION_GRP,R.BRANCH_ID_ACQ,R.CAN_ITEM_VALUE0,R.CAN_ITEM_VALUE1,R.CAN_ITEM_VALUE2,R.CAN_ITEM_VALUE3,R.CAN_ITEM_VALUE4,R.CAN_ITEM_VALUE5,R.CAN_ITEM_VALUE6,R.CAN_ITEM_VALUE7,R.CAN_NO_ITEMS_DISP0,R.CAN_NO_ITEMS_DISP1,R.CAN_NO_ITEMS_DISP2,R.CAN_NO_ITEMS_DISP3,R.CAN_NO_ITEMS_DISP4,R.CAN_NO_ITEMS_DISP5,R.CAN_NO_ITEMS_DISP6,R.CAN_NO_ITEMS_DISP7,R.CAN_ORIG_NO_ITEMS0,R.CAN_ORIG_NO_ITEMS1,R.CAN_ORIG_NO_ITEMS2,R.CAN_ORIG_NO_ITEMS3,R.CAN_ORIG_NO_ITEMS4,R.CAN_ORIG_NO_ITEMS5,R.CAN_ORIG_NO_ITEMS6,R.CAN_ORIG_NO_ITEMS7,R.CARD_ACPT_BUS_CODE,R.CARD_ACPT_COUNTRY,R.CARD_ACPT_COUNTY,R.CARD_ACPT_ID,R.CARD_ACPT_NAME_LOC,R.CARD_ACPT_PST_CODE,R.CARD_ACPT_REGION,R.CARD_ACPT_SPNSR_ID,R.CARD_CAPT_FLG,R.CARD_INTRCHG_ID,R.CARD_LOGO_ID,R.CARD_OWNER,R.CARD_SEQ_NO,R.CARD_TYPE,R.CAVV_RESULT,R.CED_BUILD_NO,R.CIRC_ID_ACQ,R.CIRC_ID_ISS,R.CLERK_ID,R.CNTRY_RCN_ACQ_INST,R.CNTRY_RCN_ISS_INST,R.CNTRY_REC_INST_ADJ,R.CNTRY_REQ_INST_ADJ,R.CNV_CRD_BIL_DE_POS,R.CNV_CRD_BIL_RATE,R.CNV_RCN_ACQ_DE_POS,R.CNV_RCN_ACQ_RATE,R.CNV_RCN_ISS_DE_POS,R.CNV_RCN_ISS_RATE,R.CNV_RCN_NET_DE_POS,R.CNV_RCN_NET_RATE,R.COUNTRY_ACQ_INST,R.COUNTRY_ISS_INST,R.CRD_ACP_NAM_FMTFLG,R.CUR_CARD_BILL,R.CUR_RECON_ACQ,R.CUR_RECON_ISS,R.CUR_RECON_NET,R.CUR_TRAN,R.CUR_TYPE,R.CVV2_CVC2_RESULT,R.CVV_CVC_RESULT,R.DATA_PRIV_ACQ,R.DATA_PRIV_ACQ_FMT,R.DATA_PRIV_ISS,R.DATA_PRIV_ISS_FMT,R.DATE_ACTION,R.DATE_CAPTURE,R.DATE_CNV_ACQ,R.DATE_CNV_ISS,R.DATE_EFFECTIVE,R.DATE_EXP,R.DATE_RECON_ACQ,R.DATE_RECON_ISS,R.DATE_RECON_NET,R.DEPOSIT_ONLY_FLG,R.DEST_ROUTING_NO,R.DRAFT_CAPTURE_FLG,R.EXCHG_MASTER,R.EXCHG_SETL,R.EXTENDED_PAY_DATA,R.FUNC_CODE,R.F_ADL_DEC_POS0,R.F_ADL_DEC_POS1,R.F_ADL_DEC_POS2,R.F_ADL_DEC_POS3,R.F_ADL_DEC_POS4,R.F_ADL_DEC_POS5,R.F_AMT0,R.F_AMT1,R.F_AMT2,R.F_AMT3,R.F_AMT4,R.F_AMT5,R.F_AMT_RECON_ACQ0,R.F_AMT_RECON_ACQ1,R.F_AMT_RECON_ACQ2,R.F_AMT_RECON_ACQ3,R.F_AMT_RECON_ACQ4,R.F_AMT_RECON_ACQ5,R.F_AMT_RECON_ISS0,R.F_AMT_RECON_ISS1,R.F_AMT_RECON_ISS2,R.F_AMT_RECON_ISS3,R.F_AMT_RECON_ISS4,R.F_AMT_RECON_ISS5,R.F_AMT_RECON_NET0,R.F_AMT_RECON_NET1,R.F_AMT_RECON_NET2,R.F_AMT_RECON_NET3,R.F_AMT_RECON_NET4,R.F_AMT_RECON_NET5,R.F_CNV_ACQ_DEC_POS0,R.F_CNV_ACQ_DEC_POS1,R.F_CNV_ACQ_DEC_POS2,R.F_CNV_ACQ_DEC_POS3,R.F_CNV_ACQ_DEC_POS4,R.F_CNV_ACQ_DEC_POS5,R.F_CNV_ACQ_RATE0,R.F_CNV_ACQ_RATE1,R.F_CNV_ACQ_RATE2,R.F_CNV_ACQ_RATE3,R.F_CNV_ACQ_RATE4,R.F_CNV_ACQ_RATE5,R.F_CNV_ISS_DEC_POS0,R.F_CNV_ISS_DEC_POS1,R.F_CNV_ISS_DEC_POS2,R.F_CNV_ISS_DEC_POS3,R.F_CNV_ISS_DEC_POS4,R.F_CNV_ISS_DEC_POS5,R.F_CNV_ISS_RATE0,R.F_CNV_ISS_RATE1,R.F_CNV_ISS_RATE2,R.F_CNV_ISS_RATE3,R.F_CNV_ISS_RATE4,R.F_CNV_ISS_RATE5,R.F_CUR_CODE0,R.F_CUR_CODE1,R.F_CUR_CODE2,R.F_CUR_CODE3,R.F_CUR_CODE4,R.F_CUR_CODE5,R.F_CUR_RECON_ACQ0,R.F_CUR_RECON_ACQ1,R.F_CUR_RECON_ACQ2,R.F_CUR_RECON_ACQ3,R.F_CUR_RECON_ACQ4,R.F_CUR_RECON_ACQ5,R.F_CUR_RECON_ISS0,R.F_CUR_RECON_ISS1,R.F_CUR_RECON_ISS2,R.F_CUR_RECON_ISS3,R.F_CUR_RECON_ISS4,R.F_CUR_RECON_ISS5,R.F_INITIATOR0,R.F_INITIATOR1,R.F_INITIATOR2,R.F_INITIATOR3,R.F_INITIATOR4,R.F_INITIATOR5,R.F_MEMO0,R.F_MEMO1,R.F_MEMO2,R.F_MEMO3,R.F_MEMO4,R.F_MEMO5,R.F_TYPE0,R.F_TYPE1,R.F_TYPE2,R.F_TYPE3,R.F_TYPE4,R.F_TYPE5,R.HCE_ACTIVATE_RESULT,R.HOST_RECV_FLG,R.HOST_SENT_FLG,R.IFSC_CODE,R.INST_ID_REC_ADJ,R.INST_ID_REQ_ADJ,R.INST_TIER,R.ISS_ROUTING_NO,R.LOCAL_RETRIEVAL_REF_NO,R.LUK_AMT_TRAN,R.LUK_ELAPSED_TIME,R.LUK_TRAN_COUNT,R.MCI_AAV_RESULT_COD,R.MCI_ECS_LVL_IND,R.MCI_UCAF_DATA,R.MERCH_TIER_ID,R.MERCH_TYPE,R.MSG_RESON_CODE_ACQ,R.MSG_RESON_CODE_ISS,R.MTI,R.MULTI_CLEAR_COUNT,R.MULTI_CLEAR_SEQ_NO,R.NETWORK_PROGRAM,R.NET_ID_ACQ,R.NET_ID_ISS,R.NET_IND_ADJ,R.NET_INTRCHG_TIER,R.OAR_RQST_FLG,R.ORIG_AMT_TRAN_ADJ,R.PAN_INDICATOR,R.PAN_RANGE,R.PAN_TOKEN,R.PARTITION_KEY,R.PAYEE,R.PIN_DATA_FMT,R.PIN_FLG,R.PIN_RESULT,R.PMC_ERROR,R.POS_CARD_CAPT_CAP,R.POS_CARD_PRES,R.POS_CRDHLDR_AUTH,R.POS_CRDHLDR_AUTH_C,R.POS_CRDHLDR_A_METH,R.POS_CRDHLDR_PRESNT,R.POS_CRD_DAT_IN_CAP,R.POS_CRD_DAT_IN_MOD,R.POS_CRD_DAT_OT_CAP,R.POS_OPER_ENV,R.POS_PIN_CAPT_CAP,R.POS_TERM_OUT_CAP,R.PREAUTH_COMP_OPT,R.PRINT_MASK_ID,R.PROC_BILLING_FLGS1,R.PROC_BILLING_FLGS2,R.PROC_BILLING_FLGS3,R.PROC_BILLING_FLGS4,R.PROC_FLGS1,R.PROC_FLGS2,R.PROC_FLGS3,R.PROC_FLGS4,R.PROGRAM_ID,R.RECON_IND_ACQ,R.REF_DATA_ACQ,R.REF_DATA_ACQ_FMT,R.REF_DATA_ISS,R.REF_DATA_ISS_FMT,R.REIMBURSEMENT_ATTR,R.REQ_ACQ_ISS_IND,R.RESTRIC_INTCHG_GRP,R.REV_BY,R.SOURCE_ROUTE_ID,R.SRV_GRP_INTCHG_IND,R.SRV_GRP_SERV_CODE,R.STANDIN_ACT,R.STANDIN_OPTION,R.SWIFT_CODE,R.TERM_CLASS,R.TIME_AT_AP,R.TIME_AT_ISS,R.TIME_AT_RESP_QUE,R.TIME_AT_RESP_SWTCH,R.TIME_AT_RQST_QUE,R.TIME_AT_RQST_SWTCH,R.TOKEN_ASSURANCE,R.TOKEN_CARD_SEQ_NO,R.TOKEN_DEVICE_LOC,R.TOKEN_DEVICE_TYPE,R.TOKEN_EXP_DATE,R.TOKEN_REF_NUMBER,R.TOKEN_REF_NUMBER_EXT,R.TOKEN_REQUESTOR_ID,R.TOKEN_SER_PROVIDER,R.TOKEN_STATUS,R.TOKEN_TRANID,R.TOKEN_TYPE,R.TOKEN_VERSION,R.TRACE_DATA_ADJ,R.TRACINF_KEYTRAC_NO,R.TRACK_2_DATA,R.TRACK_INFO_KEY_ID,R.TRANS_ROUTING_NO,R.TRAN_DESC,R.TRAN_DISPOSITION,R.TRAN_FROM_ACCT_FLG,R.TRAN_TO_ACCT_FLG,R.TRAN_UNIQUE_DATA,R.TRAN_UNIQ_DATA_FMT,R.TSTAMP_LOCAL_ADJ,R.TSTAMP_TRANS_ADJ,R.UNFORMATTED_MICR_DATA,R.USAGE_UPDATE_BITS,R.VISA_ATM_TRAN_ID,R.WEIGHTED_AVE_FLG FROM NQP7CUSA.FIN_L201811 FIN_LOCATOR LEFT OUTER JOIN NQP7CUSA.FIN_ICC201811 FIN_ICC ON FIN_LOCATOR.TSTAMP_TRANS = FIN_ICC.TSTAMP_TRANS AND FIN_LOCATOR.UNIQUENESS_KEY = FIN_ICC.UNIQUENESS_KEY LEFT OUTER JOIN NQP7CUSA.FIN_PAYMENT201811 FIN_PAYMENT ON FIN_LOCATOR.TSTAMP_TRANS = FIN_PAYMENT.TSTAMP_TRANS AND FIN_LOCATOR.UNIQUENESS_KEY = FIN_PAYMENT.UNIQUENESS_KEY LEFT OUTER JOIN NQP7CUSA.FIN_RECORD201811 R ON FIN_LOCATOR.TSTAMP_TRANS = R.TSTAMP_TRANS AND FIN_LOCATOR.UNIQUENESS_KEY = R.UNIQUENESS_KEY WHERE (FIN_LOCATOR.PAN = 'EFNKBcJsNnawQmdA') AND FIN_LOCATOR.RETRIEVAL_REF_NO = '000000008982' AND (R.AMT_TRAN = 605000 OR R.AMT_TRAN IS NULL) AND FIN_LOCATOR.FUNC_CODE <> '208' AND FIN_LOCATOR.FIN_TYPE NOT IN ('011') AND ((FIN_LOCATOR.FUNC_CODE NOT LIKE '1%')) AND (R.NET_ID_ACQ = 'CPN' OR R.NET_ID_ACQ IS NULL) AND FIN_LOCATOR.TSTAMP_LOCAL BETWEEN '20181129000000' AND '20181201235959' AND FIN_LOCATOR.SYS_TRACE_AUDIT_NO = '006222' ORDER BY FIN_LOCATOR.FUNC_CODE DESC, FIN_LOCATOR.FIN_TYPE DESC;

select * from nqp7comn.x_generic where x_type = 'CARD_TYPE';
select net_rules,iss_ica from nqp7cusa.ems_case c
inner join nqp7cusa.ems_case_mci m on m.case_id = c.case_id
where case_no > '20181215000000' and net_id_ems = 'MCI';

select c.case_id,acq_ica,inst_id_acq,err_msg_1,err_de_1, request_type,status,STATE_TSTAMP from nqp7cusa.ems_case c
inner join nqp7cusa.ems_case_mci m on m.case_id = c.case_id
inner join nqp7cusa.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
inner join nqp7cusa.ems_phase_mci p on p.case_id = t.case_id and p.TSTAMP_CREATED = t.phase_tstamp
where case_no > '20180901000000' and net_id_ems = 'CRS' and case_type_ind = 'D'
and request_type <> 'UNWF' and status not in ('FWRD','PNDR')
order by c.state_tstamp desc;

select * from nqp7cusa.task_context where CONTEXT_KEY = 'CPPIN';

select distinct iss_ica,inst_id_recon_iss,i.name from nqp7CUSW.ems_case c
inner join nqp7CUSW.ems_case_mci m on m.case_id = c.case_id
inner join nqp7comn.institution i on i.inst_Id = c.inst_id_recon_iss
where c.net_id_ems = 'MCI'
and case_no > '20180601000000'
and i.cust_id = 'CUSW'
order by iss_ica asc, name asc;

select * from nqp7cusa.di_data where di_file_id = 1285710;

select c.case_id,case_no,request_type,status, state_tstamp,t.user_id,t.phase_tstamp,t.reason_code,t.action_to_cardhldr,t.amt_adjustment,v.support_info
from nqp7cusa.ems_case c
inner join nqp7cusa.ems_transition t
on t.case_id = c.case_id --and t.tstamp_created = c.state_tstamp
inner join nqp7cusa.ems_phase_vnt v
on v.case_id = t.case_id and v.tstamp_created = t.phase_tstamp
--where c.case_id = 7578157) x;
--where support_info like '%Internal Error%';
WHERE T.case_id in (
select case_id from nqp7cusa.ems_case
where request_type = 'CHB1'
AND status = 'PNDR'
AND CASE_TYPE_IND = 'D')
and t.request_type_NEXT = 'CHB1' AND T.STATUS_NEXT = 'FWRD'
--and inst_id_Recon_iss = '031176110') x;
--AND (ERR_VROL_MSG1 = 'R97' OR ERR_VROL_MSG1 = 'W80')
order by CASE_NO desc;

select PHASE_ID,STATUS_ID,DESCRIPTION_TEXT from NQP7COMN.EMSR_STATE S
--INNER JOIN NQP7COMN.EMSR_DESC_TEXT D ON D.DESCRIPTION_ID = S.TRAN_DESCRIPTION ORDER BY STATUS_ID ASC;
INNER JOIN NQP7COMN.EMSR_DESC_TEXT D ON D.DESCRIPTION_ID = S.DESCRIPTION_ID 
WHERE RULE_SET_ID = 'MC3' ORDER BY PHASE_ID ASC,STATUS_ID ASC;

select * from nqp7cusa.ems_case where net_id_ems = 'PLS' order by case_id desc;

select * from nqp7cusa.ems_comment where case_id = 243022759 order by tstamp_created asc;
select * from nqp7cusa.ems_case_context where case_id = 243022759;

select c.case_id,request_Type,status,net_rules,state_tstamp,pan_prefix,case_no from nqp7cusa.ems_case c
inner join nqp7cusa.ems_case_mci m on m.case_id = c.case_id
where m.iss_ica like '%15828%' and case_type_ind = 'X'
and net_id_acq = 'MCI' order by state_tstamp desc;-- and request_type = 'UNW1' AND STATUS = 'PNDR';

select * from nqp7cusa.di_data where import_key in (
'20191204002708',
'20191204002189',
'20191204002734',
'20191204002707',
'20191204002188',
'20191204002266',
'20191204002872');

select c.case_id,t.reason_code, request_type,status
from nqp7cusa.ems_case c
inner join nqp7cusa.ems_national_net n on n.case_id = c.case_id
inner join nqp7cusa.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
where case_type_ind = 'X' and request_type <> 'REP1'
and acq_ref_no in (
'05436849340500137802139',
'05123489311300234130213',
'05123489317300237660970',
'05140489323710035241198',
'05436849338600030580339',
'05436849342600030094244',
'15265679313007952184949',
'15265679348000026770651',
'15265679348000058273756',
'15265679348000040823726',
'15265679348000064600752',
'15265679348000017300641',
'15265679348000021393723',
'15265679348000057680639',
'15265679348000023251549',
'15410199311096640517201',
'15410199321503935057304',
'15410199324503938087834',
'15410199330741431482944',
'15410199333741573320701',
'15410199338503015037888',
'15410199338503015083957',
'15410199338503016012070',
'15410199344741987494347',
'15410199351741214729317',
'15410199352741215266425',
'15410199359741217859188',
'15410199360741218220247',
'55310209337004623634922',
'55310209350083736025444',
'55429500001637026338610',
'55429500003637144934421',
'55429509315637128971641',
'55429509325852000658137',
'55429509327713349564170',
'55429509328852143340798',
'55429509330637953272322',
'55429509330637912026967',
'55429509331854327314057',
'55429509332637053173840',
'55429509333854289284197',
'55429509334740293814716',
'55429509335637297529267',
'55429509335637223680218',
'55429509336740235943738',
'55429509336854246487229',
'55429509336854236003499',
'55429509336854248539746',
'55429509337854288762504',
'55429509338719076561807',
'55429509338719077396013',
'55429509338740330037624',
'55429509339854171186470',
'55429509340717238836253',
'55429509340717239142495',
'55429509341637687778591',
'55429509342719386167430',
'55429509343637769845043',
'55429509343637803705096',
'55429509347637992897130',
'55429509349637117717450',
'55429509349637149325009',
'55429509349740202897771',
'55429509349740202919781',
'55429509349854202820871',
'55429509349854202821796',
'55429509349854202918832',
'55429509350637188726980',
'55429509350637223236771',
'55429509351854267979799',
'55429509352740273298184',
'55429509352740273335978',
'55429509352740273418378',
'55429509352854273355207',
'55429509354637405309483',
'55429509359637667586328',
'55429509360637685075871',
'55429509360717720634641',
'55429509360717720719558',
'55429509364637884853074',
'55429509365637936343073',
'55460299330083857557963',
'55460299332083772450896',
'55460299351083729256095',
'55480779330026475794028',
'55480779346207603802295',
'55480779347207603001368',
'55480779347207603001392',
'55480779347207603001400',
'55480779347207603001459',
'55499679355696411050742',
'55500360004083759376261',
'55500369328083737973569',
'55500369330083330370805',
'55500369330083738391692',
'55500369331083751547351',
'55500369343083349215046',
'55500369346083302069981',
'55500369349083024424065',
'55500369349083308274459',
'55500369356400962175162',
'55541869346004032361001',
'55541869346004033079701',
'75347099270033447088816',
'75347099298034588311916',
'75347099326035763131918',
'85309609351080080511631',
'85482989339702117621990',
'85482989340702171944723',
'85482989350702150712734',
'85482989351702150753166',
'95209149333000010013425');

select c.case_id, case_no, state_tstamp
from nqp7FISB.ems_case c
inner join nqp7FISB.ems_transition t on t.case_id = c.case_id and t.tstamp_created = c.state_tstamp
where net_rules = 'MC3'
and request_type_next = 'REP1' 
AND STATUS_next = 'GETD'
AND TSTAMP_CREATED > '2020011300000000'
order by state_tstamp desc;

select * from nqp7comn.ems_unmatched_msg where pan = 'xHFqJvtKXVKKtOpr' and tstamp_created like '20200226%';

select c.case_id,r.queue_id,tstamp_event,data_buffer
from nqp7cusa.ems_case c
inner join nqp7cusa.api_queue_control a on a.case_id = c.case_id
inner join nqp7cusa.api_queue_response r on r.queue_id = a.queue_id
where net_id_ems = 'MCI' and request_type = 'CHBQ' and status = 'SDRC'
and req_type = 'CBStatusResponse' order by r.queue_id desc;

select * from nqp7cusw.di_data where import_key = '20200601000006';