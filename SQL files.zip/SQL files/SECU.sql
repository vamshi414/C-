select * from dndbpink.ems_case where case_no = '20200625000004';
select * from dndbpink.ems_case where case_id = 534;
select * from dndbpink.ems_case where tstamp_trans = '2020021901405313';
select * from dndbpink.ems_transition where case_id = 690 order by tstamp_created asc;
select * from dndbpink.ems_phase where case_id = 690;

select * from dndbpink.ems_document where case_id = 653;

select c.case_id,case_no,doc_type,batch_id from dndbpink.ems_case c inner join dndbpink.ems_document d
on c.case_id = d.case_id where tstamp_transmitted like '20200224%' order by doc_type asc;--case_id in (346,);
select * from dndbpink.ems_data_chg where case_id = 721 order by tstamp_Created asc;

select * from dndbpink.ems_acct_history where case_id = 634;

select * from dndbpink.api_queue_control where case_id = 440;
select * from dndbpink.di_data where di_file_id = 167;
select * from dndbpink.di_data_control order by tstamp_initiated desc;
select * from dndbpink.task_context where CONTEXT_KEY like '%ACCOUNTING%';
select * from dndbcomn.cardholder where pan = '4010210400000064';

select * from dndbcomn.emsr_net_rule_use;
select * from dndbcomn.emsr_rule_set;
select * from dndbcomn.emsr_transition where RULE_SET_ID = 'GN2-SECU' 
AND PHASE_ID like 'UNW1' AND STATUS_ID = 'PNDR'
--AND NEXT_PHASE_ID = 'UNW1' and next_status_id = 'CLOW' 
and role_ind = 'A'; order by phase_id asc; and constraint_expresn = ' ';
select * from dndbcomn.emsr_desc_text where description_id = '0000005967';
select * from dndbcomn.emsr_account_entry; where action_id = 'SETTLE315';
select * from dndbcomn.emsr_action_detail WHERE rule_set_id = 'GN2-SECU'
AND action_id = 'SYS_DOC023';
--AND phase_id = 'UNW1' and status_id = 'PNDR' AND SEQ_NO = 95; 
SELECT * FROM DNDBCOMN.emsr_data_def where field_name = 'AMT_INST_FEE';

select * from dndbpink.fin_record202001 where net_id_acq in ('VSN','VNT') and card_acpt_bus_code = '6011';
select * from dndbpink.fin_l202001 where tstamp_trans in (
'2020010217330943',
'2020010217340748',
'2020010316000352');

select * from dndbpink.dx_data_control where dx_file_type = 'BULK' and date_recon = '20200301';--order by dx_file_id desc;
select * from dndbpink.dx_data_20200301 where dx_file_id =4712 order by seq_no asc;

select * from dndbcomn.x_net_inst_id;
update dndbcomn.x_net_inst_id set cc_state = 'A',cc_last_operation = 'INS'; commit;

select * from dndbcomn.as_widget_restrict;
select * from dndbcomn.as_profile_entry where PERMISSION_ID = 'PM_EMSAUTOSND';
select * from DNDBCOMN.AS_USER_PROFILE where user_id = 'E1009122';
insert into dndbcomn.as_user_profile (user_id,ENTITY_ID,profile_id,cust_id,cust_stat) values (
'E1009122','*','PR_EMS_SUPER','PINK',' ');

select * from dndbcomn.dx_file_group;
select * from dndbcomn.dx_PROC_DEST;

select * from dndbcomn.event_cntl;
select * from dndbcomn.crevCDT where EVCLID = 'ACCTFL';
update dndbcomn.crevcdt set evnttime = '14100000' where EVCLID = 'ACCTFL';
select * from dndbcomn.crevCLT;
SELECT * FROM dndbcomn.crevelt;
select * from dndbcomn.crevntt;
--delete from dndbcomn.crevntt where evntid = 'PKACCTFL';
select * from dndbcomn.crfilet where taskid LIKE '%DT%';

commit;


