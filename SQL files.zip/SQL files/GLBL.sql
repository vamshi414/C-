select * from nqp5glbl.ems_case where net_id_ems = 'MCI'  and tstamp_trans <> ' ' order by case_id desc;case_no = '20200617000018';
select * from nqp5glbl.ems_case where case_id = 1045035;
select * from nqp5glbl.ems_phase where case_id = 1045706;
select * from nqp5glbl.ems_case_vnt where case_id = 1045248;
select * from nqp5glbl.ems_phase_vnt where case_id = 1045706 order by tstamp_created asc;
select * from nqp5glbl.ems_case_mci where case_id = 1044480;

select * from nqp5glbl.ems_transition where case_id = 1045035 order by tstamp_created;

select * from nqp5glbl.ems_acct_history order by tstamp_created desc;
select acq_ref_no from nqp5glbl.ems_national_net where case_id = 1045035;

select * from nqp5glbl.ems_case where tstamp_trans = '2020022207032561';
select data_priv_acq_FMT,data_priv_iss_fmt,ref_data_iss_fmt from nqp5glbl.fin_record202004 where tstamp_trans = '2020042108292244';
select * from nqp5comn.misc_cfg_data where cfg_data_type = 'POS_CH_AUTH_CPB';

select * from nqp5glbl.ems_data_chg where case_id = 1045035 order by tstamp_created asc;
select request_type,status from nqp5glbl.ems_case c
inner join nqp5glbl.api_queue_control a on a.case_id = c.case_id
where api_result like '%Socket%';

select * from nqp5glbl.api_queue_control where case_id = 902723 order by queue_id asc;
select * from nqp5glbl.api_queue_control; where queue_id = 35526;

select * from nqp5glbl.api_queue_request where queue_id in
(select queue_id from nqp5glbl.api_queue_control where case_id = 1045706) order by queue_id asc;
select * from nqp5glbl.api_queue_response where queue_id in
(select queue_id from nqp5glbl.api_queue_control where case_id = 1045706) order by queue_id asc;

select * from nqp5comn.emsr_rule_set order by rule_set_id asc;
select * from nqp5comn.emsr_net_rule_use; where network_rules = 'VNA';
select * from nqp5comn.emsr_transition where RULE_SET_ID = 'MCS' 
AND PHASE_ID = 'UNW1' AND STATUS_ID = 'PNDR'
--AND NEXT_PHASE_ID = 'REP1' AND NEXT_STATUS_ID = 'FWRD';
and role_ind = 'I';

select * from nqp5comn.processor where proc_id in ('INT064','INT110','INT115','PRC057');
select * from nqp5glbl.ems_case where net_rules = 'CUP' order by case_id desc;

select * from nqp5comn.emsr_action_detail where action_id = 'SETTLE252';
select * from nqp5comn.emsr_action_instr where instruction_ptr = '1061196202';

select * from nqp5glbl.ems_case_vnt where vcrfs_rtr_req_id <> ' ';

select * from nqp5glbl.dx_data_control where DX_file_type = 'ECPOST' order by dx_file_id desc;

select net_inst_id_code,pan_prefix,x.inst_id,name 
from nqp5comn.x_net_inst_id x
inner join nqp5comn.institution i on i.inst_id = x.inst_id
where net_id = 'MCI' order by net_inst_id_code asc;

select * from nqp5comn.dx_proc_dest;
select * from nqp5comn.dx_procgrp_dest;
select * from nqp5comn.dx_file_type where dx_file_type <> 'TXNACT';

select * from nqp5comn.as_user_profile where user_id = 'Y713045';
select * from nqp5comn.as_widget_restrict where widget_id = 'EMS_ALL_REASONS';
select * from NQP5COMN.AS_PROFILE_ENTRY where permission_id in ('EMS_SIG_ALL_RC','PM_EMSREASONS');
select widget_id from nqp5comn.as_widget_restrict w
inner join NQP5COMN.AS_PROFILE_ENTRY p on w.PERMISSION_ID =p.PERMISSION_ID
where p.profile_id = 'SIG-EMS-ALL-RC';

SELECT * FROM NQP5COMN.CRTASKT WHERE TASKID = 'GLEB01';
SELECT * FROM NQP5COMN.CRTAGLT WHERE TAGLID = 'GLEB01';
SELECT * FROM NQP5COMN.CRTAGET WHERE TASKID = 'GLEB02';
SELECT * FROM NQP5COMN.CRTBDET WHERE TBDTID = 'GLEB01';
SELECT * FROM NQP5COMN.CRTBDTT WHERE TBDTID = 'GLEB01';
SELECT * FROM NQP5COMN.CRFILET WHERE TASKID = 'GLEB01';

select * from NQP5COMN.CURRENCY_CODE where currency_code = '952';

select * from nqp5glbl.ems_case c inner join nqp5glbl.ems_phase p on p.case_id = c.case_id
where net_id_ems = 'MCI' and tstamp_trans <> ' ' and p.user_role = 'A' order by c.case_id desc;