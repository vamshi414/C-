SELECT EC.CASE_ID,CASE_NO,STATE_TSTAMP,request_type_prev,status_prev
FROM NQP1cap1.EMS_CASE EC 
INNER JOIN NQP1cap1.EMS_TRANSITION T ON T.CASE_ID = EC.CASE_ID AND T.TSTAMP_CREATED = EC.STATE_TSTAMP
INNER JOIN NQP1cap1.EMS_PHASE_MCI EPM ON EPM.CASE_ID = T.CASE_ID AND EPM.TSTAMP_CREATED = T.PHASE_TSTAMP
WHERE NET_RULES = 'MC3' AND REQUEST_TYPE = 'REP1' AND STATUS = 'SDRC' AND epm.DOC_CODE_IND = '1' 
and state_tstamp > '2020070100000000' ORDER BY STATE_TSTAMP;

select a.queue_id,A.case_id,api_state,req_type,api_result,data_buffer from NQP1cap1.api_queue_control a
inner join NQP1cap1.api_queue_request r on r.queue_id = a.queue_id
where API_TYPE = 'MCOM' 
--and api_state = 'AP'
and case_id in (
5640069,
5638706,
5638682,
5638491,
5644310,
5594151)
and req_type = 'CBGetDocumentResponse';
--and request_type = 'DOC4' and status = 'GETD' order by queue_id desc;

SELECT CASE_ID,CASE_NO,STATE_TSTAMP FROM NQP1cap1.EMS_CASE WHERE NET_RULES = 'MC3' AND REQUEST_TYPE = 'REP1' AND STATUS = 'GETD' ORDER BY STATE_TSTAMP;

