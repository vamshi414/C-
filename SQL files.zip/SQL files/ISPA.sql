select * from nqp7ispa.ems_case where case_no = '20200306000061';
select
'select c.case_id,CASE_NO, request_Type,status,STATE_TSTAMP,PAN_PREFIX,PAN_SUFFIX,AMT_TRAN, retrieval_ref_no',
'from nqp1bcfs.ems_case c where pan_prefix = '''||x.pan_prefix||''' and pan_suffix = '''||x.pan_suffix||'''',
' and retrieval_ref_no = '''||x.retrieval_ref_no||''' and amt_tran = ',
x.amt_tran,';commit;'
from (
select c.case_id,CASE_NO, STATE_TSTAMP,PAN_PREFIX,PAN_SUFFIX,AMT_TRAN, retrieval_ref_no
from nqp7ispa.ems_case c 
--inner join nqp7ispa.ems_transition t on t.case_id = c.case_id
where NET_RULES = 'V3I' and request_Type = 'REP1' AND STATUS = 'FWRD' and STATE_TSTAMP < '2018072000000000'
--AND request_type_prev = 'INIT' and STATUS_PREV = 'TEMP' 
--AND REQUEST_TYPE_NEXT = 'CHB1' AND STATUS_NEXT = 'SDRC' AND USER_ID <> 'SYSTEM' AND STATE_TSTAMP > '2018070100000000'
and case_extension = 'VNT' order by pan_prefix asc, pan_suffix asc, retrieval_ref_no) x;
select * from nqp7ispa.ems_case where pan_prefix = '497814' and pan_suffix = '9000';
select * from nqp7ispa.ems_case where pan_prefix = '459954' and pan_suffix = '6517';
select * from nqp7ispa.ems_case where tstamp_trans = '2018031501492347';
select * from nqp7ispa.ems_case where case_id = 70001;
select * from nqp7ispa.ems_phase where case_id = 81148;
select * from nqp7ispa.ems_case_vnt where case_id in (910667,910637);
select * from nqp7ispa.ems_phase_vnt where 
vrol_case_no = '1690621807';
--case_id = 910667;
select * from nqp7ispa.ems_document where case_id = 79659;

select * from nqp7ispa.ems_transition where case_id = 81148 order by tstamp_created asc;
select * from nqp7ispa.ems_data_chg where case_id = 85750 order by tstamp_created asc;

select * from nqp7ispa.assoc_tran where case_id = 910667;

select * from nqp7ispa.api_queue_control order by tstamp_created desc;-- where case_id = 910667;
select * from nqp7ispa.api_queue_control where queue_id = 28120;

select * from nqp7ispa.api_queue_request where data_buffer like '%1647548347%'; 
select * from nqp7ispa.api_queue_response where data_buffer like '%1647554147%'; 
select * from nqp7ispa.api_queue_request where queue_id in
(select queue_id from nqp7ispa.api_queue_control where case_id = 910667) order by queue_id asc;
select * from nqp7ispa.api_queue_response where queue_id in
(select queue_id from nqp7ispa.api_queue_control where case_id = 910667) order by queue_id asc;

select * from nqp7ispa.api_qevent_log where queue_id = 28194 order by tstamp_created asc;

select case_id, case_no from nqp7ispa.ems_case
where tstamp_trans in (
select tstamp_trans from nqp7ispa.ems_case 
where case_type_ind = 'D' and status in ('SDRC','REJ2'))
and requesT_Type = 'CHB1' AND STATUS = 'FWRD'
and net_rules = 'VN3';

select a.queue_id, case_no
from nqp7ispa.ems_case c
inner join nqp7ispa.api_queue_control a on a.case_id = c.case_id
inner join nqp7ispa.api_queue_response r on r.queue_id = a.queue_id
where request_type = 'CHBQ' AND STATUS = 'DOCF'
--and data_buffer like '%Successfully%'
AND a.req_type = 'DOC';


select c.case_id, case_no,acq_bin, net_id_iss,case_no, tstamp_trans,state_tstamp,request_type, status,merchant_cat_code --, v.support_info
from nqp7ispa.ems_case c
inner join nqp7ispa.ems_case_vnt u on u.case_id = c.case_id
inner join nqp7ispa.ems_transition t on t.case_id = c.case_id --and t.tstamp_created = c.state_tstamp
WHERE case_extension = 'VNT'
and t.request_type_prev = 'INIT' AND T.STATUS_PREV = 'TEMP' AND T.REQUEST_TYPE_NEXT = 'CHB1' AND T.STATUS_next = 'SDRC'
AND CUR_TRAN <> '840'
ORDER BY state_tstamp deSC;


select C.case_id, case_type_ind, status
from nqp7ispa.ems_case c             
where case_type_ind = 'D'            
and tstamp_trans in (
select c.tstamp_trans from nqp7ispa.ems_case c                                          
where case_id in (
898894,898896,898898,898900,898906,898910,898912,898914,898916,898918,898920,898922,898924,898926,
898930,898932,898935,898937,898939,898941,898943,898947,898949,898951,898953,898957,898959,898979)
);

select * from nqp7ISPA.dX_data_control where DX_FILE_TYPE = 'AUDRM5' ORDER BY DATE_RECON DESC;
select * from nqp7ispa.dx_data_20180504 where dx_file_id = 35775;
select * from nqp7comn.emsr_transition where rule_set_id = 'V3I';
select * from nqp7comn.processor where proc_id = 'ISOKIC';