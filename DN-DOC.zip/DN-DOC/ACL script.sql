    SELECT                                                   
   (P.USER_ID) AS USER_ID,                                        
                                                
 CASE                                                    
    WHEN SUBSTR(L.EMPLOYEE_ID,1,1) IN ('E','L','e','l')  
         THEN SUBSTR(L.EMPLOYEE_ID,1,10)                 
    ELSE        (' ')                                  
 END AS EMPLOYEE_ID,                                                    
                                                
   (' ') AS SOLUTION,                                              
                                                
 CASE L.USER_STATUS                     
   WHEN 'A' THEN   ('ACTIVE   ')                    
   WHEN 'R' THEN   ('RESET    ')                    
   WHEN 'S' THEN   ('SUSPENDED')                    
   ELSE            ('         ')                    
 END AS USER_STATUS,                                                 
                                             
   (L.USER_NAME) AS USER_NAME,                                   
                                             
 CASE L.LAST_LOGON_DATE                               
   WHEN ' ' THEN   ('Not Available')                
ELSE (to_char(to_date(SUBSTR(L.LAST_LOGON_DATE,1,8),'yyyy/mm/dd'),'MM/DD/YYYY'))  
END AS LAST_LOGON_DATE,                                                
                                             
L.CREATION_DATE AS CREATION_DATE,
 
 (P.ENTITY_ID) AS ENTITY_ID,
 
 (P.PROFILE_ID) AS PROFILE_ID,

 (AP.DESCRIPTION) AS DESCRIPTION,
 
 (P.CUST_ID) AS SWITCH,                                                 
                                                         
  ('NQP1 ') AS SYSTEM,                                                    
                                                         
CASE L.EMPLOYEE_ID                                                
  WHEN ' '         THEN   ('E1035120')    
  WHEN 'SYSTEMID'  THEN   ('E1035120')    
  ELSE                    ('        ')    
END AS ApproverProcessEID ,     
CASE L.EMPLOYEE_ID                                                
  WHEN ' '         THEN   ('QUIMBY,TIM')    
  WHEN 'SYSTEMID'  THEN   ('QUIMBY,TIM')    
  ELSE                    ('FOSTER,DAVE')    
END AS ResourceOwner,
CASE L.EMPLOYEE_ID                                                
  WHEN ' '         THEN   ('E1035120')    
  WHEN 'SYSTEMID'  THEN   ('E1035120')    
  ELSE                    ('E1009644')    
END AS RO_E_ID
FROM NQP1COMN.AS_USER_PROFILE P                                   
INNER JOIN NQP1COMN.AS_USER_LOGON L ON P.USER_ID = L.USER_ID
INNER JOIN NQP1COMN.AS_PROFILE AP on P.PROFILE_ID = AP.PROFILE_ID
WHERE upper(substr(L.OWNING_ENTITY,1,3)) = 'FIS' or L.OWNING_ENTITY = ' ' AND (CASE WHEN SUBSTR(L.EMPLOYEE_ID,1,1) IN ('E','L','e','l')  
         THEN SUBSTR(L.EMPLOYEE_ID,1,10)                 
    ELSE        (' ')                                  
 END) <> ' ' 
 AND 
 (CASE L.EMPLOYEE_ID                                                
  WHEN ' '         THEN   ('E1035120')    
  WHEN 'SYSTEMID'  THEN   ('E1035120')    
  ELSE                    ('        ')    
END) <> '        '