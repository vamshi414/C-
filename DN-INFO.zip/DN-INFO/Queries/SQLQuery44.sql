select * from DN1PGTWY.EMS_CASE where CASE_ID='3'

select TSTAMP_TRANS,PAN,ACCT_ID_1  from DN1PGTWY.EMS_CASE where CASE_ID='3'


delete from DN1PGTWY.EMS_CASE where CASE_ID='3'


