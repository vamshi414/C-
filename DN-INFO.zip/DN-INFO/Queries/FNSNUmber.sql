select * from DN1PGTWY.GDG_DATA_CONTROL

select * from DN1PGTWY.FIN_RECORD202107

select * from DN1PGTWY.FIN_L202106

select * from DN1PGTWY.FIN_L202107 where FUNC_CODE='200'

select TSTAMP_TRANS,UNIQUENESS_KEY,PAN,TSTAMP_LOCAL,FUNC_CODE, ACT_CODE from DN1PGTWY.FIN_L202107 where PAN='5510660000380272'
select TSTAMP_TRANS,UNIQUENESS_KEY,PAN,TSTAMP_LOCAL,FUNC_CODE, ACT_CODE from DN1PGTWY.FIN_L202107 where FUNC_CODE='200'



select * from DN1PGTWY.FIN_L202107 where PAN='5510660000380272'

select * from DN1PGTWY.FIN_L202106 where PAN='4761733125553552'


alter table DN1PGTWY.FIN_RECORD202107 add TOKEN_CRYPTOGRAM char(28);
alter table DN1PGTWY.FIN_RECORD202107 add PAY_SENDER_NAME varchar(41);
alter table DN1PGTWY.FIN_RECORD202107 add PAY_RECEIVER_NAME varchar(41);
alter table DN1PGTWY.FIN_RECORD202107 add FEE_GROUP char(6);


delete from DN1P.DN1PGTWY.GDG_DATA_CONTROL where GDG_FILE_TYPE='IBMLOG'


update DN1PGTWY.FIN_RECORD202107 set ADL_DATA_PRIV_ACQ='EB04800000021VB                                                2503340000 1000      500000002                       4    R                                                  08000000               0' where TSTAMP_TRANS='2021070318452818'




















































