/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [DX_FILE_ID]
      ,[SEQ_NO]
      ,[ALT_REC_KEY]
      ,[DATA_BUFFER]
  FROM [DN1P].[DN1PGTWY].[DX_DATA_20210531]


   	delete from DN1P.DN1PGTWY.[DX_DATA_20210528]


	select * from [DN1P].[DN1PGTWY].[DX_DATA_20210602]


	


