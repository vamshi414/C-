/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [DI_FILE_ID]
      ,[TRANSACTION_NO]
      ,[SEQ_NO]
      ,[DI_STATE]
      ,[TSTAMP_PARSED]
      ,[TSTAMP_NEXT_PARSE]
      ,[TSTAMP_RETRY_COUNT]
      ,[IMPORT_KEY]
      ,[REJECT_CODES]
      ,[DATA_BUFFER]
  FROM [DN1P].[DN1PGTWY].[DI_DATA]


  
	delete from DN1P.DN1PGTWY.DI_DATA where DI_FILE_ID=13


